enum PluginTypes {
  MonthSelect = 'monthSelect',
  WeekSelect = 'weekSelect'
}

export default PluginTypes;
