import { numberFormat } from 'core-utilities';

export const { getNumberFormat } = numberFormat;

export default {
  getNumberFormat
};
