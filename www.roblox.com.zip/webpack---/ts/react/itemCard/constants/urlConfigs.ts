export const urlConfigs = {
  assetRootUrlTemplate: 'catalog',
  bundleRootUrlTemplate: 'bundles'
};

export default urlConfigs;
