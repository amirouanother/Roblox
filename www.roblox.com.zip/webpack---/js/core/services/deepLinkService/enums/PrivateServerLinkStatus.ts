enum PrivateServerLinkStatus {
  INVALID = 'Invalid',
  VALID = 'Valid',
  EXPIRED = 'Expired'
}

export default PrivateServerLinkStatus;
