enum ExternalWebUrlDomains {
  Zendesk = 'zendesk'
}

export default ExternalWebUrlDomains;
