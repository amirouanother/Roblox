enum ProfileShareStatus {
  VALID = 'Valid',
  SENDER_BLOCKED_RECIPIENT = 'SenderBlockedRecipient',
  INVALID = 'Invalid'
}

export default ProfileShareStatus;
