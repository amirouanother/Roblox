enum ProfileShareFriendshipSourceType {
  PROFILE_SHARE = 'ProfileShare',
  QR_CODE = 'QrCode'
}

export default ProfileShareFriendshipSourceType;
