enum ExperienceInviteStatus {
  VALID = 'Valid',
  EXPIRED = 'Expired',
  INVITER_NOT_IN_EXPERIENCE = 'InviterNotInExperience'
}

export default ExperienceInviteStatus;
