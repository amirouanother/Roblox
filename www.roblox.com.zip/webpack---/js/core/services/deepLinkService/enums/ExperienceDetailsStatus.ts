enum ExperienceDetailsStatus {
  INVALID = 'Invalid',
  EXPIRED = 'Expired',
  VALID = 'Valid'
}

export default ExperienceDetailsStatus;
