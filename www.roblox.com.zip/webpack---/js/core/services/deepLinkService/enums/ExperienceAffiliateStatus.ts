enum ExperienceAffiliateStatus {
  INVALID = 'Invalid',
  VALID = 'Valid'
}

export default ExperienceAffiliateStatus;
