enum AvatarItemDetailsStatus {
  INVALID = 'Invalid',
  EXPIRED = 'Expired',
  VALID = 'Valid'
}

export default AvatarItemDetailsStatus;
