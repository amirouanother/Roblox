import intl from './lib/intl';

const Roblox = window.Roblox || {};
Roblox.Intl = intl;
window.Roblox = Roblox;

export default intl;