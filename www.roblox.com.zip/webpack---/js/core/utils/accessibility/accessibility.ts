import createKeyboardEventHandler from './createKeyboardEventHandler';

export default {
  createKeyboardEventHandler
};
