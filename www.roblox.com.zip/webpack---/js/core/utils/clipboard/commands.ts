enum commands {
  copy = 'Copy'
}

export default commands;
