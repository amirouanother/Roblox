const suffixes = {
  withPlus: ['', 'K+', 'M+', 'B+', 'T+'],
  withoutPlus: ['', 'K', 'M', 'B', 'T']
};

export default suffixes;
