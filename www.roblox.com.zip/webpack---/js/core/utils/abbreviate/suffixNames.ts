enum suffixNames {
  withPlus = 'withPlus',
  withoutPlus = 'withoutPlus'
}

export default suffixNames;
