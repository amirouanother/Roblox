export default {
    fill: 'fill',
    contain: 'contain'
};