export const OPEN = 'OPEN';
export const CLOSE = 'CLOSE';