import {
    makeActionCreator
} from 'react-utilities';
import {
    OPEN
} from './actionTypes';

export default makeActionCreator(OPEN);