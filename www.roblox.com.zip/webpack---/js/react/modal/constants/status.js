export default {
    none: 'NONE',
    action: 'ACTION',
    neutral: 'NEUTRAL'
};