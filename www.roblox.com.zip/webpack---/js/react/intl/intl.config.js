export const namespaceDelimiter = '.';
export const requiredNamespaceNestingLevel = 2;