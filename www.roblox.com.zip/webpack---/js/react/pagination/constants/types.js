export default {
    Basic: 'basic',
    Extended: 'extended'
};