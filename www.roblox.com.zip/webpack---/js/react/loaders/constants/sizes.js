export default {
    default: 'spinner-default',
    small: 'spinner-sm'
};