export default {
    loading: 'alert-loading',
    success: 'alert-success',
    warning: 'alert-warning'
};