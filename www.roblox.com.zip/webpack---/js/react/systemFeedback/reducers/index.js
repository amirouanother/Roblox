import systemFeedback from './systemFeedback';

export default systemFeedback;