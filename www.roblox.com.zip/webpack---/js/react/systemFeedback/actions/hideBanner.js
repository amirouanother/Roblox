import {
    makeActionCreator
} from 'react-utilities';
import {
    HIDE_BANNER
} from './actionTypes';

export default makeActionCreator(HIDE_BANNER);