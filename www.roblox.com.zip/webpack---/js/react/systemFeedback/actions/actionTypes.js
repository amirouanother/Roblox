export const SHOW_BANNER = 'SHOW_BANNER';
export const HIDE_BANNER = 'HIDE_BANNER';