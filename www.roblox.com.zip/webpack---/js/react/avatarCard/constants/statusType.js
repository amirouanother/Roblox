export default {
    STATUS_TYPES: {
        OFFLINE: 'offline',
        ONLINE: 'online',
        GAME: 'game',
        STUDIO: 'studio'
    }
};