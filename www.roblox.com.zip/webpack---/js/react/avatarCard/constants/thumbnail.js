export default {
    THUMBNAIL_STATUS: {
        Completed: 'Completed',
        Error: 'Error',
        InReview: 'InReview',
        Blocked: 'Blocked',
        Pending: 'Pending'
    }
};