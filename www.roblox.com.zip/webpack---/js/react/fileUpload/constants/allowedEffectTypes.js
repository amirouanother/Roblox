export default {
    copy: 'copy'
};