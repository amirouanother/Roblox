export default {
    image: 'image/png, image/jpeg'
};