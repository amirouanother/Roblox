const operationNames = {
    httpRequest: 'Web::HTTPRequest'
};

export default {
    operationNames
};