import environmentUrls from './environmentUrls';

window.Roblox = window.Roblox || {};
window.Roblox.EnvironmentUrls = environmentUrls;