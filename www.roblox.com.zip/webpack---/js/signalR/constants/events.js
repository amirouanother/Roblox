const realtimeEvents = {
    Notification: 'Roblox.RealTime.Events.Notification',
    ConnectionEvent: 'Roblox.RealTime.Events.ConnectionEvent',
    RequestForConnectionStatus: 'Roblox.RealTime.Events.RequestForConnectionStatus'
};

export default realtimeEvents;