export default {
    hybridSourceDisabled: null
};