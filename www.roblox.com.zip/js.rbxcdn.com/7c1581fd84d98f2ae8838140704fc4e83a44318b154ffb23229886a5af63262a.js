var Roblox = Roblox || {};
Roblox.LangDynamic = Roblox.LangDynamic || {};
Roblox.LangDynamic["Feature.PeopleList"] = {
    "Label.Chat": "Chat with {username}",
    "Label.ViewProfile": "View Profile",
    "Action.Join": "Join",
    "Action.Buy": "Buy to Join",
    "Action.ViewDetails": "View Details",
    "Heading.Friends": "Friends",
    "Heading.SeeAll": "See All",
    "Label.PresenceError": "User status may not be up to date",
    "FriendsError": "Unable to load friends",
    "Label.FriendsError": "Unable to load friends"
};
window.Roblox && window.Roblox.BundleDetector && window.Roblox.BundleDetector.bundleDetected("DynamicLocalizationResourceScript_Feature.PeopleList");