var Roblox = Roblox || {};
Roblox.LangDynamic = Roblox.LangDynamic || {};
Roblox.LangDynamic["Common.Presence"] = {
    "Label.Online": "Online",
    "Label.Offline": "Offline",
    "Label.Playing": "Active",
    "Label.Creating": "Creating",
    "Label.PlayingGame": "Active in {placeName}",
    "Label.CreatingGame": "Creating {placeName}",
    "Label.Invisible": "Invisible"
};
window.Roblox && window.Roblox.BundleDetector && window.Roblox.BundleDetector.bundleDetected("DynamicLocalizationResourceScript_Common.Presence");