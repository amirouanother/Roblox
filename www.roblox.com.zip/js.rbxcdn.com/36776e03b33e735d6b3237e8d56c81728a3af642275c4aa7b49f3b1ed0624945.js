! function() {
    "use strict";

    function c() {
        return {
            retryable: !0,
            withCredentials: !0,
            url: "".concat(oe, "/v1/email")
        }
    }
    var r = {
            n: function(e) {
                var t = e && e.__esModule ? function() {
                    return e.default
                } : function() {
                    return e
                };
                return r.d(t, {
                    a: t
                }), t
            },
            d: function(e, t) {
                for (var n in t) r.o(t, n) && !r.o(e, n) && Object.defineProperty(e, n, {
                    enumerable: !0,
                    get: t[n]
                })
            },
            o: function(e, t) {
                return Object.prototype.hasOwnProperty.call(e, t)
            }
        },
        d = CoreUtilities,
        O = React,
        M = r.n(O),
        p = ReactDOM,
        m = Roblox,
        e = r.n(m),
        t = PropTypes,
        n = r.n(t),
        i = ReactUtilities,
        o = "verificationUpsell-container",
        a = {
            common: [],
            feature: "Feature.VerificationUpsell"
        },
        l = "SET_USER_EMAIL_STATES",
        s = "SET_MODAL_STATES",
        u = "SET_PAGENAME_STATE",
        f = "SET_INPUT_STATE",
        h = "SET_ERROR_STATE",
        y = "SET_EMAIL_SENT_STATE",
        v = "SET_RESEND_EMAIL_STATE",
        b = "SET_EMAIL_UPDATING_STATE",
        g = "SET_TRIGGER_ORIGIN",
        E = "SET_INPUT_CLEAR",
        P = "SET_EMAIL_ADDED_STATE",
        x = "Verification",
        S = "UpdateEmail",
        w = "UpdatePassword",
        N = "logout",
        C = "buyRobuxPage",
        T = "homepage",
        A = "premiumSubscriptionPage",
        k = "purchaseWarning",
        R = "notApprovedPage",
        I = "https://en.help.roblox.com/hc/articles/115004630823-Roblox-Privacy-and-Cookie-Policy",
        D = "Enter",
        L = "Action.ChangeEmail",
        j = "Action.ResendConfirmationEmail",
        U = "Action.SendConfirmationEmail",
        _ = "Action.Logout",
        K = "Action.GenericSkip",
        B = "Action.Continue",
        H = "Action.PrivacyPolicy",
        q = "Description.PleaseEnterEmail",
        V = "Description.PleaseEnterParentEmail",
        F = "Description.AddEmailTextOver13",
        G = "Description.AddEmailTextUnder13",
        W = "Description.LogoutAddEmailTextOver13",
        z = "Description.LogoutAddEmailTextUnder13",
        $ = "Description.VerifyEmailBody",
        Y = "Heading.PleaseAddEmail",
        X = "Heading.AddEmail",
        J = "Heading.VerifyEmail",
        Q = "Heading.VerifyOnLogout",
        Z = "Label.EmailInputPlaceholderOver13",
        ee = "Label.EmailInputPlaceholderUnder13",
        te = "Message.ConfirmationEmailNotSent",
        ne = "Message.InvalidEmailAddress",
        re = "Response.ErrorTryAgain",
        ie = "Response.TooManyAttemptsTryAgainLater",
        oe = m.EnvironmentUrls.accountSettingsApi,
        ae = m.EnvironmentUrls.authApi,
        ce = m.EnvironmentUrls.apiGatewayUrl,
        le = m.EnvironmentUrls.accountInformationApi,
        se = {
            header: "alt_title",
            body: "alt_body",
            primaryButton: "alt_primary_button_text",
            secondaryButton: "alt_secondary_button_text"
        };

    function ue(e, t) {
        return function(e) {
            if (Array.isArray(e)) return e
        }(e) || function(e, t) {
            if ("undefined" == typeof Symbol || !(Symbol.iterator in Object(e))) return;
            var n = [],
                r = !0,
                i = !1,
                o = void 0;
            try {
                for (var a, c = e[Symbol.iterator](); !(r = (a = c.next()).done) && (n.push(a.value), !t || n.length !== t); r = !0);
            } catch (e) {
                i = !0, o = e
            } finally {
                try {
                    r || null == c.return || c.return()
                } finally {
                    if (i) throw o
                }
            }
            return n
        }(e, t) || function(e, t) {
            if (!e) return;
            if ("string" == typeof e) return de(e, t);
            var n = Object.prototype.toString.call(e).slice(8, -1);
            "Object" === n && e.constructor && (n = e.constructor.name);
            if ("Map" === n || "Set" === n) return Array.from(e);
            if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return de(e, t)
        }(e, t) || function() {
            throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }

    function de(e, t) {
        (null == t || t > e.length) && (t = e.length);
        for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
        return r
    }

    function pe(t, e) {
        var n, r = Object.keys(t);
        return Object.getOwnPropertySymbols && (n = Object.getOwnPropertySymbols(t), e && (n = n.filter(function(e) {
            return Object.getOwnPropertyDescriptor(t, e).enumerable
        })), r.push.apply(r, n)), r
    }

    function me(r) {
        for (var e = 1; e < arguments.length; e++) {
            var i = null != arguments[e] ? arguments[e] : {};
            e % 2 ? pe(Object(i), !0).forEach(function(e) {
                var t, n;
                t = r, e = i[n = e], n in t ? Object.defineProperty(t, n, {
                    value: e,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[n] = e
            }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(r, Object.getOwnPropertyDescriptors(i)) : pe(Object(i)).forEach(function(e) {
                Object.defineProperty(r, e, Object.getOwnPropertyDescriptor(i, e))
            })
        }
        return r
    }

    function fe(e, t) {
        switch (t.type) {
            case E:
                return me(me({}, e), {}, {
                    userEmailInput: ""
                });
            case g:
                return me(me({}, e), {}, {
                    origin: t.origin,
                    skipCallback: t.skipCallback,
                    closeCallback: t.closeCallback
                });
            case l:
                return me(me({}, e), {}, {
                    isEmailVerified: t.isEmailVerified,
                    userEmail: t.userEmail
                });
            case u:
                return me(me({}, e), {}, {
                    pageName: t.pageName
                });
            case h:
                return me(me({}, e), {}, {
                    errorMsg: t.errorMsg
                });
            case b:
                return me(me({}, e), {}, {
                    isEmailUpdating: t.isEmailUpdating
                });
            case y:
                return me(me({}, e), {}, {
                    isEmailSent: !0
                });
            case P:
                return me(me({}, e), {}, {
                    isEmailAdded: !0
                });
            case v:
                return me(me({}, e), {}, {
                    isEmailSent: !1
                });
            case f:
                return e.pageName === S ? me(me({}, e), {}, {
                    userEmailInput: t.value,
                    errorMsg: ""
                }) : e;
            case s:
                if (e.pageName !== S) return me(me({}, e), {}, {
                    pageName: x,
                    titleText: Te,
                    bodyText: xe,
                    primaryButtonText: ve,
                    secondaryButtonText: be,
                    errorMsg: ""
                });
                var n, r, i, o = m.CurrentUser && !m.CurrentUser.isUnder13,
                    a = ye,
                    c = "";
                switch (e.skipCallback && (c = Ee), e.origin) {
                    case N:
                        r = Oe, i = o ? Ne : Ce, c = ge, t.experimentParameters && (r = null !== (n = t.experimentParameters[se.header]) && void 0 !== n ? n : r, i = null !== (n = t.experimentParameters[se.body]) && void 0 !== n ? n : i, a = null !== (n = t.experimentParameters[se.primaryButton]) && void 0 !== n ? n : a, c = null !== (n = t.experimentParameters[se.secondaryButton]) && void 0 !== n ? n : c);
                        break;
                    case T:
                    case R:
                        r = ke, i = o ? Ie : De, a = Pe;
                        break;
                    default:
                        r = Ae, i = o ? Se : we
                }
                return me(me({}, e), {}, {
                    pageName: S,
                    titleText: r,
                    bodyText: i,
                    primaryButtonText: a,
                    secondaryButtonText: c,
                    errorMsg: "",
                    userEmailInputPlaceholder: o ? Me : Re
                });
            default:
                return e
        }
    }

    function he(e) {
        var t = e.children,
            e = (n = ue((0, O.useReducer)(fe, Le), 2))[0],
            n = n[1];
        return M().createElement(je.Provider, {
            value: {
                emailUpsellState: e,
                dispatch: n
            }
        }, t)
    }
    var ye = U,
        ve = j,
        be = L,
        ge = _,
        Ee = K,
        Pe = B,
        xe = $,
        Se = F,
        we = G,
        Ne = W,
        Ce = z,
        Te = J,
        Ae = X,
        ke = Y,
        Oe = Q,
        Me = Z,
        Re = ee,
        Ie = q,
        De = V,
        Le = {
            pageName: "",
            isModalOpen: !1,
            isEmailVerified: !1,
            isEmailSent: !1,
            isEmailUpdating: !1,
            isEmailAdded: !1,
            origin: "",
            experimentParameters: null,
            userEmail: "",
            userEmailInput: "",
            userEmailInputPlaceholder: Me,
            errorMsg: "",
            titleText: Te,
            bodyText: xe,
            primaryButtonText: ve,
            secondaryButtonText: be,
            skipCallback: null,
            closeCallback: null
        },
        je = (0, O.createContext)(Le);

    function Ue() {
        return (0, O.useContext)(je)
    }
    he.propTypes = {
        children: n().node.isRequired
    };
    var _e = ReactStyleGuide,
        Ke = HeaderScripts,
        Be = (!!m.DeviceMeta && (0, m.DeviceMeta)()).isAndroidApp;

    function He(e) {
        var t = e.show,
            n = e.onHide,
            r = e.onPrimaryAction,
            i = e.onSecondaryAction,
            o = e.onInputChange,
            a = e.onBackAction,
            c = e.onInputFocus,
            l = e.onKeyDown,
            s = e.translate,
            u = Ue().emailUpsellState,
            d = u.pageName,
            p = u.titleText,
            m = u.bodyText,
            f = u.primaryButtonText,
            h = u.secondaryButtonText,
            y = u.userEmailInput,
            v = u.userEmailInputPlaceholder,
            b = u.userEmail,
            g = u.errorMsg,
            E = u.isEmailSent,
            e = u.isEmailUpdating,
            u = null === Ke.authenticatedUser || void 0 === Ke.authenticatedUser ? void 0 : Ke.authenticatedUser.isUnder13;
        return M().createElement(_e.Modal, {
            show: t,
            onHide: n,
            className: "".concat(Be ? "verification-android-modal" : "", " verification-modal"),
            size: "lg",
            "aria-labelledby": "contained-modal-title-vcenter",
            scrollable: "true",
            centered: "true"
        }, M().createElement(_e.Modal.Header, {
            useBaseBootstrapComponent: !0
        }, M().createElement("div", {
            className: "verification-upsell-title-container"
        }, d === w ? M().createElement("button", {
            type: "button",
            className: "verification-upsell-title-button",
            onClick: a
        }, M().createElement("span", {
            className: "icon-back"
        })) : M().createElement("button", {
            type: "button",
            className: "verification-upsell-title-button",
            onClick: n
        }, M().createElement("span", {
            className: "close icon-close"
        })), M().createElement(_e.Modal.Title, {
            id: "contained-modal-title-vcenter"
        }, s(p)))), M().createElement(_e.Modal.Body, null, M().createElement("div", {
            className: "email-verification-upsell-image"
        }), M().createElement("p", {
            className: "verification-upsell-text-body"
        }, s(m, {
            emailAddress: b
        })), d === S && M().createElement("input", {
            type: "email",
            autoFocus: !0,
            className: "".concat(g ? "input-field-error" : "", " form-control input-field verification-upsell-modal-input"),
            placeholder: s(v),
            autoComplete: "email",
            value: y,
            onChange: function(e) {
                return o(e.target.value)
            },
            onFocus: function() {
                return c()
            },
            onKeyDown: function(e) {
                return l(e.key)
            }
        }), g && M().createElement("p", {
            className: "text-error modal-error-message sms-code-error"
        }, s(g)), d === S && u && M().createElement("div", {
            className: "privacy-policy-button"
        }, M().createElement("a", {
            href: I,
            target: "_blank",
            rel: "noreferrer"
        }, s(H)))), M().createElement(_e.Modal.Footer, null, M().createElement("div", {
            className: "verification-upsell-footer-container"
        }, d !== x && M().createElement(_e.Button, {
            className: "modal-button verification-upsell-btn",
            variant: _e.Button.variants.cta,
            size: _e.Button.sizes.medium,
            isDisabled: e,
            onClick: r
        }, s(f)), d === x && M().createElement("button", {
            type: "button",
            className: "".concat(E ? "resend-button-disabled" : "", " resend-verification-email-button"),
            disabled: E || g,
            onClick: r
        }, s(f)), h && M().createElement("button", {
            type: "button",
            className: "change-email-button",
            onClick: i
        }, s(h)))))
    }

    function qe(e) {
        var t = null == e || null === (t = e.data) || void 0 === t ? void 0 : t.errors;
        return t && t[0] && t[0].code
    }
    He.propTypes = {
        translate: n().func.isRequired,
        onHide: n().func.isRequired,
        show: n().bool.isRequired,
        onPrimaryAction: n().func.isRequired,
        onSecondaryAction: n().func.isRequired,
        onInputChange: n().func.isRequired,
        onKeyDown: n().func.isRequired,
        onBackAction: n().func.isRequired,
        onInputFocus: n().func.isRequired
    };
    var Ve = He,
        Fe = "addEmail",
        Ge = "verifyEmail",
        We = "addPhone",
        ze = "verifyPhone",
        $e = "phoneAdded",
        Ye = "discoverabilityConsent",
        Xe = "unset",
        Je = "homepage";

    function Qe(e, t, n, r, i, o, a) {
        try {
            var c = e[o](a),
                l = c.value
        } catch (e) {
            return void n(e)
        }
        c.done ? t(l) : Promise.resolve(l).then(r, i)
    }

    function Ze(c) {
        return function() {
            var e = this,
                a = arguments;
            return new Promise(function(t, n) {
                var r = c.apply(e, a);

                function i(e) {
                    Qe(r, t, n, i, o, "next", e)
                }

                function o(e) {
                    Qe(r, t, n, i, o, "throw", e)
                }
                i(void 0)
            })
        }
    }

    function et() {
        var e = {
            retryable: !0,
            withCredentials: !0,
            url: "".concat(oe, "/v1/email/verify")
        };
        return d.httpService.post(e).then(function() {
            return !0
        }, qe)
    }

    function tt(n) {
        var e = c();
        return d.httpService.get(e).then(function(e) {
            var t = e.data;
            return null != t && t.emailAddress && (!n.requireVerification || t.verified) || (e = new CustomEvent("OpenVerificationModal", {
                detail: {
                    isEmailVerified: t.verified,
                    email: null == t ? void 0 : t.emailAddress,
                    skipCallback: n.skipCallback,
                    origin: n.origin,
                    experimentParameters: null == n ? void 0 : n.experimentParameters,
                    requireVerification: n.requireVerification,
                    closeCallback: n.closeCallback
                }
            }), window.dispatchEvent(e)), t
        }, function(e) {
            return console.log(e), !1
        })
    }

    function nt(e) {
        return tt({
            origin: T,
            closeCallback: e
        })
    }

    function rt(e) {
        switch (e) {
            case x:
                return Ge;
            case S:
                return Fe;
            default:
                return ""
        }
    }
    var it = function() {
            var e = Ze(regeneratorRuntime.mark(function e() {
                var t;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                        case 0:
                            return t = {
                                retryable: !0,
                                withCredentials: !0,
                                url: "".concat(ae, "/v2/metadata")
                            }, e.abrupt("return", d.httpService.get(t));
                        case 2:
                        case "end":
                            return e.stop()
                    }
                }, e)
            }));
            return function() {
                return e.apply(this, arguments)
            }
        }(),
        ot = function() {
            var e = Ze(regeneratorRuntime.mark(function e() {
                var t, n;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                        case 0:
                            return t = {
                                retryable: !0,
                                withCredentials: !0,
                                url: "".concat(ce, "/product-experimentation-platform/v1/projects/1/layers/Website.Logout.ContactMethodModal/values")
                            }, n = {
                                parameters: Object.values(se).join(",")
                            }, e.abrupt("return", d.httpService.get(t, n));
                        case 3:
                        case "end":
                            return e.stop()
                    }
                }, e)
            }));
            return function() {
                return e.apply(this, arguments)
            }
        }(),
        at = function() {
            var e = Ze(regeneratorRuntime.mark(function e(t) {
                var n, r;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                        case 0:
                            return e.next = 2, it();
                        case 2:
                            if (n = e.sent, null !== (n = n.data) && void 0 !== n && n.IsEmailUpsellAtLogoutEnabled) {
                                e.next = 5;
                                break
                            }
                            return e.abrupt("return", !1);
                        case 5:
                            return r = {}, e.prev = 6, e.next = 9, ot();
                        case 9:
                            r = e.sent, e.next = 14;
                            break;
                        case 12:
                            e.prev = 12, e.t0 = e.catch(6);
                        case 14:
                            return e.abrupt("return", tt({
                                origin: N,
                                experimentParameters: null === (n = r) || void 0 === n ? void 0 : n.data,
                                skipCallback: t
                            }));
                        case 16:
                        case "end":
                            return e.stop()
                    }
                }, e, null, [
                    [6, 12]
                ])
            }));
            return function() {
                return e.apply(this, arguments)
            }
        }(),
        ct = ne,
        lt = ie,
        st = re,
        ut = Dn = 9,
        dt = 6,
        pt = CoreRobloxUtilities;

    function mt(t, e) {
        var n, r = Object.keys(t);
        return Object.getOwnPropertySymbols && (n = Object.getOwnPropertySymbols(t), e && (n = n.filter(function(e) {
            return Object.getOwnPropertyDescriptor(t, e).enumerable
        })), r.push.apply(r, n)), r
    }

    function ft(r) {
        for (var e = 1; e < arguments.length; e++) {
            var i = null != arguments[e] ? arguments[e] : {};
            e % 2 ? mt(Object(i), !0).forEach(function(e) {
                var t, n;
                t = r, e = i[n = e], n in t ? Object.defineProperty(t, n, {
                    value: e,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[n] = e
            }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(r, Object.getOwnPropertyDescriptors(i)) : mt(Object(i)).forEach(function(e) {
                Object.defineProperty(r, e, Object.getOwnPropertyDescriptor(i, e))
            })
        }
        return r
    }

    function ht(e, t) {
        pt.eventStreamService.sendEventWithTarget(e.type, e.context, ft(ft({}, e.params), {}, {
            origin: t.origin,
            section: t.section
        }))
    }

    function yt(e, t) {
        return (e = ft({}, e)).params = ft(ft({}, e.params), {}, {
            errorCode: t
        }), e
    }
    var vt = pt.eventStreamService.eventTypes,
        bt = "verificationUpsell",
        gt = {
            showModal: {
                name: "showModal",
                type: vt.modalAction,
                context: bt,
                params: {
                    aType: "shown"
                }
            },
            dismissModal: {
                name: "dismissModal",
                type: vt.modalAction,
                context: bt,
                params: {
                    aType: "dismissed"
                }
            },
            touchEmail: {
                name: "touchEmail",
                type: vt.formInteraction,
                context: bt,
                params: {
                    aType: "focus",
                    field: "email"
                }
            },
            showError: {
                name: "showError",
                type: vt.formInteraction,
                context: bt,
                params: {
                    aType: "shown",
                    field: "errorMessage"
                }
            },
            clickContinue: {
                name: "clickContinue",
                type: vt.formInteraction,
                context: bt,
                params: {
                    btn: "continue"
                }
            },
            clickSendConfirmationEmail: {
                name: "clickSendConfirmationEmail",
                type: vt.formInteraction,
                context: bt,
                params: {
                    aType: "click",
                    btn: "sendConfirmation"
                }
            },
            clickResendConfirmationEmail: {
                name: "clickResendConfirmationEmail",
                type: vt.formInteraction,
                context: bt,
                params: {
                    aType: "click",
                    btn: "resendConfirmation"
                }
            },
            clickChangeEmail: {
                name: "clickChangeEmail",
                type: vt.formInteraction,
                context: bt,
                params: {
                    aType: "click",
                    btn: "changeEmail"
                }
            },
            skipLogoutAnyway: {
                name: "skipLogoutAnyway",
                type: vt.formInteraction,
                context: bt,
                params: {
                    aType: "click",
                    btn: "skipLogoutAnyway"
                }
            },
            skipPrepurchaseVerification: {
                name: "skipPrepurchaseVerification",
                type: vt.formInteraction,
                context: bt,
                params: {
                    aType: "click",
                    btn: "skipPrepurchaseVerification"
                }
            }
        };

    function Et(e, t) {
        return function(e) {
            if (Array.isArray(e)) return e
        }(e) || function(e, t) {
            if ("undefined" == typeof Symbol || !(Symbol.iterator in Object(e))) return;
            var n = [],
                r = !0,
                i = !1,
                o = void 0;
            try {
                for (var a, c = e[Symbol.iterator](); !(r = (a = c.next()).done) && (n.push(a.value), !t || n.length !== t); r = !0);
            } catch (e) {
                i = !0, o = e
            } finally {
                try {
                    r || null == c.return || c.return()
                } finally {
                    if (i) throw o
                }
            }
            return n
        }(e, t) || function(e, t) {
            if (!e) return;
            if ("string" == typeof e) return Pt(e, t);
            var n = Object.prototype.toString.call(e).slice(8, -1);
            "Object" === n && e.constructor && (n = e.constructor.name);
            if ("Map" === n || "Set" === n) return Array.from(e);
            if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return Pt(e, t)
        }(e, t) || function() {
            throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }

    function Pt(e, t) {
        (null == t || t > e.length) && (t = e.length);
        for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
        return r
    }
    var xt = te,
        St = ne,
        wt = Dn;

    function Nt(e) {
        var t = e.translate,
            n = Et((0, O.useState)(!1), 2),
            e = n[0],
            r = n[1],
            n = Ue(),
            i = n.emailUpsellState,
            o = n.dispatch;

        function a() {
            var e, t, r = rt(i.pageName);
            switch (i.pageName) {
                case x:
                    ht(gt.clickResendConfirmationEmail, {
                        origin: i.origin,
                        section: r
                    }), et().then(function(e) {
                        !0 !== e ? (o({
                            type: h,
                            errorMsg: xt
                        }), e = yt(gt.showError, e), ht(e, {
                            origin: i.origin,
                            section: r
                        })) : (o({
                            type: y
                        }), setTimeout(function() {
                            o({
                                type: v
                            })
                        }, 15e3))
                    });
                    break;
                case S:
                    ht(gt.clickContinue, {
                        origin: i.origin,
                        section: r
                    }), t = i.userEmailInput, /\S+@\S+\.\S+/.test(t) ? (ht(gt.clickSendConfirmationEmail, {
                        origin: i.origin,
                        section: r
                    }), o({
                        type: b,
                        isEmailUpdating: !0
                    }), e = {
                        emailAddress: i.userEmailInput
                    }, t = c(), d.httpService.post(t, e).then(function() {
                        return !0
                    }, qe).then(function(e) {
                        var t, n;
                        !0 !== e ? (n = function(e) {
                            switch (e) {
                                case dt:
                                    return lt;
                                case ut:
                                    return ct;
                                default:
                                    return st
                            }
                        }(e), t = yt(gt.showError, e), ht(t, {
                            origin: i.origin,
                            section: r
                        }), o({
                            type: h,
                            errorMsg: n
                        }), o({
                            type: b,
                            isEmailUpdating: !1
                        })) : (o({
                            type: l,
                            isEmailVerified: !1,
                            userEmail: (e = i.userEmailInput, t = e.indexOf("@"), n = e.substring(0, 1), "".concat(n, "*****").concat(e.substring(t)))
                        }), o({
                            type: E
                        }), o({
                            type: u,
                            pageName: x
                        }), o({
                            type: s
                        }), o({
                            type: b,
                            isEmailUpdating: !1
                        }), o({
                            type: P
                        }))
                    }), o({
                        type: s
                    })) : (e = yt(gt.showError, wt), ht(e, {
                        origin: i.origin,
                        section: r
                    }), o({
                        type: h,
                        errorMsg: St
                    }))
            }
        }
        return (0, O.useEffect)(function() {
            i.pageName && ht(gt.showModal, {
                origin: i.origin,
                section: rt(i.pageName)
            })
        }, [i.pageName]), (0, O.useEffect)(function() {
            window.addEventListener("OpenVerificationModal", function(e) {
                r(!0), o({
                    type: g,
                    origin: e.detail.origin,
                    skipCallback: e.detail.skipCallback,
                    closeCallback: e.detail.closeCallback
                }), o({
                    type: l,
                    isEmailVerified: e.detail.isEmailVerified,
                    userEmail: e.detail.email
                });
                var t = e.detail.requireVerification && e.detail.email ? x : S;
                o({
                    type: u,
                    pageName: t
                }), o({
                    type: s,
                    experimentParameters: null === (e = e.detail) || void 0 === e ? void 0 : e.experimentParameters
                })
            }, !1)
        }, []), M().createElement("div", null, M().createElement(Ve, {
            show: e,
            onHide: function() {
                return ht(gt.dismissModal, {
                    origin: i.origin,
                    section: rt(i.pageName)
                }), o({
                    type: E
                }), i.closeCallback && i.closeCallback(i.isEmailAdded), void r(!1)
            },
            onPrimaryAction: a,
            onSecondaryAction: function() {
                var e = rt(i.pageName);
                switch (i.pageName) {
                    case x:
                        ht(gt.clickChangeEmail, {
                            origin: i.origin,
                            section: e
                        }), o({
                            type: u,
                            pageName: S
                        }), o({
                            type: s
                        });
                        break;
                    case S:
                        i.skipCallback && (ht(i.origin === N ? gt.skipLogoutAnyway : gt.skipPrepurchaseVerification, {
                            origin: i.origin,
                            section: e
                        }), i.skipCallback()), o({
                            type: E
                        }), r(!1)
                }
            },
            onInputFocus: function() {
                ht(gt.touchEmail, {
                    origin: i.origin,
                    section: rt(i.pageName)
                })
            },
            onInputChange: function(e) {
                o({
                    type: f,
                    pageName: S,
                    value: e
                })
            },
            onKeyDown: function(e) {
                return e === D && a()
            },
            onBackAction: function() {
                return o({
                    type: u,
                    pageName: S
                }), void o({
                    type: s
                })
            },
            translate: t
        }))
    }
    Nt.propTypes = {
        translate: n().func.isRequired
    };
    var Ct = Nt;

    function Tt(e) {
        e = e.translate;
        return M().createElement(he, null, M().createElement(Ct, {
            translate: e
        }))
    }
    Tt.propTypes = {
        translate: n().func.isRequired
    };
    var At = (0, i.withTranslations)(Tt, a),
        kt = "CLOSE_PHONE_NUMBER_MODAL",
        Ot = "SET_ERROR_MESSAGE",
        Mt = "SET_PHONE_NUMBER",
        Rt = "SET_COUNTRY",
        It = "SET_PAGE",
        Dt = "SET_PHONE_VERIFICATION_STATUS",
        Lt = "SET_PREFIX_OPTIONS_LIST",
        jt = "SET_LOGGING_VALUES",
        Ut = "SET_DISCOVERABILITY_CONSENT_PREFILL",
        _t = "Action.Done",
        Kt = "Action.Continue",
        Bt = "Action.AddPhoneNumber",
        Ht = "Action.ChangePhoneNumber",
        qt = "Action.ResendCode",
        Vt = "Action.CodeResent",
        Ft = "Heading.VerifyYourPhone",
        Gt = "Label.EnterCode",
        Wt = "Label.PhoneNumber",
        zt = "Heading.VerificationCode",
        $t = "Message.InvalidSmsCode",
        Yt = "Description.VerificationCodeSmsFeesMayApply",
        t = "Description.PhoneNumberNeverPublic",
        U = "Description.ShortCodeLegalDisclaimer",
        j = "Heading.PhoneIsVerified",
        L = "Description.PhoneForRecovery",
        _ = "Response.PhoneNumberAlreadyLinked",
        K = "Response.TooManyVerificationAttempts",
        B = "Response.PhoneHasTooManyAssociatedAccounts",
        $ = "Response.ErrorPhoneFormatInvalid",
        F = "Response.InvalidPhoneNumberError",
        G = "Response.ErrorTryAgain",
        W = "Label.Dialog.EditPhoneCurrentNumber",
        z = "Description.Dialog.EditPhoneWarning",
        J = "Action.Dialog.EditPhonePrimary",
        X = "Action.Dialog.EditPhoneSecondary",
        Xt = "Heading.Dialog.RemovePhone",
        Jt = "Action.Dialog.RemovePhonePrimary",
        Qt = "Action.Dialog.RemovePhoneSecondary",
        Zt = "Description.Dialog.RemovePhoneWarning",
        Y = '<a href="https://en.help.roblox.com/hc/articles/9483830673556-Roblox-SMS-Terms-of-Service">',
        Q = '<a href="https://en.help.roblox.com/hc/articles/115004630823">',
        Z = "</a>",
        en = "Action.Done",
        tn = "Action.LearnMore",
        nn = "Description.PhoneDiscoverabilityPrivacy",
        rn = "Description.WantToBeRecommendedViaPhone",
        on = "Header.LetFriendsFindYou",
        an = "Label.No",
        cn = "Label.Yes",
        ln = "Response.ErrorTryAgain",
        sn = "Heading.VerificationRequired",
        un = "Heading.DontGetLockedOut",
        dn = "Label.RecoverIfPasswordLost",
        pn = "Heading.ImproveAccountSecurity",
        mn = "Label.KeepBadActorsOut",
        fn = "Action.AddPhoneNumber",
        hn = "Action.AddEmailAddress",
        yn = "Action.LogOutText",
        vn = "Action.Support",
        ee = "US",
        bn = function(e) {
            return "+".concat(e)
        },
        gn = function(e, t) {
            return "".concat(e, " +(").concat(t, ")")
        },
        En = function(e, t) {
            return "\n+".concat(e).concat(t)
        },
        Pn = "Enter",
        xn = " (",
        Sn = ")",
        wn = 6,
        Nn = 10,
        Cn = "US",
        q = 2,
        V = 3,
        ie = 6,
        re = 8,
        vt = 9,
        bt = 7,
        te = 6,
        Tn = "upsell-phone-number-number",
        An = "verification-code-input",
        kn = "ADD_PHONE_NUMBER_PAGE",
        On = "VERIFY_PHONE_NUMBER_PAGE",
        Mn = "ADD_PHONE_SUCCESS_PAGE",
        Rn = "DELETE_PHONE_CONFIRM_PAGE",
        In = "PHONE_DISCOVERABILITY_CONSENT_PAGE",
        ne = pt.eventStreamService.eventTypes,
        Dn = "verificationUpsell",
        Ln = {
            phoneNumberModalDismissed: {
                name: "phoneNumberModalDismissed",
                type: ne.modalAction,
                context: Dn,
                params: {
                    aType: "dismissed"
                }
            },
            phoneNumberModalShown: {
                name: "phoneNumberModalShown",
                type: ne.modalAction,
                context: Dn,
                params: {
                    aType: "shown"
                }
            },
            phoneNumberModalErrorShown: {
                name: "phoneNumberModalErrorShown",
                type: ne.modalAction,
                context: Dn,
                params: {
                    aType: "shown",
                    field: "errorMessage"
                }
            },
            addPhonePrefixPressed: {
                name: "addPhonePrefixPressed",
                type: ne.formInteraction,
                context: Dn,
                params: {
                    aType: "focus",
                    field: "countryPrefix"
                }
            },
            addPhonePhoneNumberPressed: {
                name: "addPhonePhoneNumberPressed",
                type: ne.formInteraction,
                context: Dn,
                params: {
                    aType: "focus",
                    field: "phoneNumber"
                }
            },
            addPhoneContinuePressed: {
                name: "addPhoneContinuePressed",
                type: ne.formInteraction,
                context: Dn,
                params: {
                    btn: "continue"
                }
            },
            verifyPhoneChangePhoneNumberPressed: {
                name: "verifyPhoneChangePhoneNumberPressed",
                type: ne.formInteraction,
                context: Dn,
                params: {
                    btn: "changePhoneNumber"
                }
            },
            verifyPhoneCodeFieldPressed: {
                name: "verifyPhoneCodeFieldPressed",
                type: ne.formInteraction,
                context: Dn,
                params: {
                    aType: "focus",
                    field: "verificationCode"
                }
            },
            verifyPhoneContinuePressed: {
                name: "verifyPhoneContinuePressed",
                type: ne.formInteraction,
                context: Dn,
                params: {
                    btn: "continue"
                }
            },
            verifyPhoneResendPressed: {
                name: "verifyPhoneResendPressed",
                type: ne.formInteraction,
                context: Dn,
                params: {
                    btn: "resendCode"
                }
            },
            phoneAddedDonePressed: {
                name: "phoneAddedDonePressed",
                type: ne.formInteraction,
                context: Dn,
                params: {
                    btn: "done"
                }
            }
        };

    function jn(e, t) {
        return function(e) {
            if (Array.isArray(e)) return e
        }(e) || function(e, t) {
            if ("undefined" == typeof Symbol || !(Symbol.iterator in Object(e))) return;
            var n = [],
                r = !0,
                i = !1,
                o = void 0;
            try {
                for (var a, c = e[Symbol.iterator](); !(r = (a = c.next()).done) && (n.push(a.value), !t || n.length !== t); r = !0);
            } catch (e) {
                i = !0, o = e
            } finally {
                try {
                    r || null == c.return || c.return()
                } finally {
                    if (i) throw o
                }
            }
            return n
        }(e, t) || function(e, t) {
            if (!e) return;
            if ("string" == typeof e) return Un(e, t);
            var n = Object.prototype.toString.call(e).slice(8, -1);
            "Object" === n && e.constructor && (n = e.constructor.name);
            if ("Map" === n || "Set" === n) return Array.from(e);
            if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return Un(e, t)
        }(e, t) || function() {
            throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }

    function Un(e, t) {
        (null == t || t > e.length) && (t = e.length);
        for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
        return r
    }

    function _n(t, e) {
        var n, r = Object.keys(t);
        return Object.getOwnPropertySymbols && (n = Object.getOwnPropertySymbols(t), e && (n = n.filter(function(e) {
            return Object.getOwnPropertyDescriptor(t, e).enumerable
        })), r.push.apply(r, n)), r
    }

    function Kn(r) {
        for (var e = 1; e < arguments.length; e++) {
            var i = null != arguments[e] ? arguments[e] : {};
            e % 2 ? _n(Object(i), !0).forEach(function(e) {
                var t, n;
                t = r, e = i[n = e], n in t ? Object.defineProperty(t, n, {
                    value: e,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[n] = e
            }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(r, Object.getOwnPropertyDescriptors(i)) : _n(Object(i)).forEach(function(e) {
                Object.defineProperty(r, e, Object.getOwnPropertyDescriptor(i, e))
            })
        }
        return r
    }

    function Bn(e, t) {
        var n;
        switch (t.type) {
            case Mt:
                return Kn(Kn({}, e), {}, {
                    phone: t.phone,
                    errorMessage: ""
                });
            case Rt:
                return Kn(Kn({}, e), {}, {
                    phonePrefixPickerIndex: t.phonePrefixPickerIndex,
                    errorMessage: ""
                });
            case Ot:
                return Kn(Kn({}, e), {}, {
                    errorMessage: t.errorMessage
                });
            case It:
                return Kn(Kn({}, e), {}, {
                    errorMessage: "",
                    pageName: t.pageName
                });
            case Dt:
                return Kn(Kn({}, e), {}, {
                    isPhoneVerified: t.isPhoneVerified
                });
            case Ut:
                return Kn(Kn({}, e), {}, {
                    shouldPrefillAffirmativeDiscoverabilityConsent: null !== (n = null == t ? void 0 : t.shouldPrefillAffirmativeDiscoverabilityConsent) && void 0 !== n && n
                });
            case Lt:
                return Kn(Kn({}, e), {}, {
                    phonePrefixOptionsList: t.phonePrefixOptionsList
                });
            case jt:
                return Kn(Kn({}, e), {}, {
                    origin: t.origin
                });
            case kt:
                return Kn(Kn({}, qn), {}, {
                    isOpen: !1,
                    errorMessage: ""
                });
            default:
                return qn
        }
    }

    function Hn(e) {
        var t = e.children,
            e = (n = jn((0, O.useReducer)(Bn, qn), 2))[0],
            n = n[1];
        return M().createElement(Vn.Provider, {
            value: {
                phoneUpsellState: e,
                dispatch: n
            }
        }, t)
    }
    var qn = {
            isOpen: !0,
            pageName: kn,
            errorMessage: "",
            origin: Xe,
            phone: "",
            isPhoneVerified: !1,
            phonePrefixPickerIndex: 0,
            phonePrefixOptionsList: [],
            shouldDiscoverabilityConsentDefaultYes: !1
        },
        Vn = (0, O.createContext)(qn);

    function Fn() {
        return (0, O.useContext)(Vn)
    }

    function Gn() {
        var e = {
            retryable: !0,
            withCredentials: !0,
            url: "".concat(ce, "/phone-number-api/v1/phone-prefix-list")
        };
        return d.httpService.get(e).then(function(e) {
            var t, n = e.data,
                e = n.find(function(e) {
                    return !0 === e.isDefault
                }),
                r = null !== (e = null == e ? void 0 : e.code) && void 0 !== e ? e : Qn;
            return n.filter(function(e) {
                return e.code !== r || (t = e, !1)
            }), t && n.unshift(t), n
        }, function(e) {
            return !1
        })
    }

    function Wn(e) {
        var t = e.phone,
            n = e.prefix,
            r = e.countryCode,
            e = {
                retryable: !0,
                withCredentials: !0,
                url: "".concat(le, "/v1/phone")
            },
            t = {
                countryCode: r,
                prefix: n,
                phone: t
            };
        return d.httpService.post(e, t)
    }

    function zn(e) {
        var t = {
                code: 0 < arguments.length && void 0 !== e ? e : ""
            },
            e = {
                retryable: !0,
                withCredentials: !0,
                url: "".concat(le, "/v1/phone/verify")
            };
        return d.httpService.post(e, t)
    }

    function $n(e) {
        var t = {
                retryable: !0,
                withCredentials: !0,
                url: "".concat(le, "/v1/phone/resend")
            },
            e = (e = e) || {};
        return d.httpService.post(t, e).then(function(e) {
            e.data;
            return !0
        }, function(e) {
            return !1
        })
    }

    function Yn() {
        var e = {
            retryable: !0,
            withCredentials: !0,
            url: "".concat(le, "/v1/phone/delete")
        };
        return d.httpService.post(e, {})
    }

    function Xn(e) {
        switch (e) {
            case ar:
                return Zn;
            case cr:
                return er;
            case sr:
                return tr;
            case ur:
                return nr;
            case lr:
                return ir;
            default:
                return rr
        }
    }

    function Jn(e) {
        switch (e) {
            case kn:
                return We;
            case On:
                return ze;
            case Mn:
                return $e;
            case In:
                return Ye;
            default:
                return ""
        }
    }
    Hn.propTypes = {
        children: n().node.isRequired
    };
    var Qn = ee,
        Zn = _,
        er = K,
        tr = $,
        nr = F,
        rr = G,
        ir = B,
        or = $t,
        ar = V,
        cr = ie,
        lr = vt,
        sr = q,
        ur = re,
        dr = bt,
        pr = te;

    function mr(e) {
        var t = e.translate,
            e = Fn().phoneUpsellState;
        return M().createElement("p", {
            className: "input-field-error-text sms-code-error text-error modal-error-message"
        }, e.errorMessage ? t(e.errorMessage) : null)
    }
    mr.propTypes = {
        translate: n().func.isRequired
    };
    var fr = mr;

    function hr(e, t, n, r, i, o, a) {
        try {
            var c = e[o](a),
                l = c.value
        } catch (e) {
            return void n(e)
        }
        c.done ? t(l) : Promise.resolve(l).then(r, i)
    }

    function yr(e) {
        var t = e.translate,
            n = Fn(),
            r = n.phoneUpsellState,
            i = n.dispatch,
            o = bn,
            a = gn,
            c = r.phone,
            e = r.phonePrefixPickerIndex,
            l = r.phonePrefixOptionsList,
            n = r.pageName,
            s = r.origin,
            r = Tn,
            u = Jn(n);
        (0, O.useEffect)(function() {
            function e() {
                var c;
                return c = regeneratorRuntime.mark(function e() {
                    var t;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                if (0 === (t = l).length) return e.next = 4, Gn();
                                e.next = 6;
                                break;
                            case 4:
                                t = e.sent, i({
                                    type: Lt,
                                    phonePrefixOptionsList: t
                                });
                            case 6:
                            case "end":
                                return e.stop()
                        }
                    }, e)
                }), (e = function() {
                    var e = this,
                        a = arguments;
                    return new Promise(function(t, n) {
                        var r = c.apply(e, a);

                        function i(e) {
                            hr(r, t, n, i, o, "next", e)
                        }

                        function o(e) {
                            hr(r, t, n, i, o, "throw", e)
                        }
                        i(void 0)
                    })
                }).apply(this, arguments)
            }! function() {
                e.apply(this, arguments)
            }()
        }, []);
        var d = null !== (d = null == l || null === (d = l[e]) || void 0 === d ? void 0 : d.prefix) && void 0 !== d ? d : "";
        return M().createElement("div", null, M().createElement("label", {
            htmlFor: r
        }, M().createElement("p", {
            className: "verification-code-label font-caption-header text-primary"
        }, t(Wt))), M().createElement("div", {
            id: "upsell-phone",
            className: "phone-number-input-container input-field form-control"
        }, M().createElement("div", {
            id: "upsell-phonenumber",
            className: "phone-input-row"
        }, M().createElement("span", {
            className: "phone-prefix-wrapper"
        }, M().createElement("div", {
            className: "phone-prefix-selected text"
        }, o(d)), M().createElement("select", {
            className: "phone-prefix-dropdown input-field rbx-select",
            onChange: function(e) {
                e = e.target.value;
                i({
                    type: Rt,
                    phonePrefixPickerIndex: e
                })
            },
            onFocus: function() {
                ht(Ln.addPhonePrefixPressed, {
                    origin: s,
                    section: u
                })
            },
            value: e
        }, l.map(function(e, t) {
            return M().createElement("option", {
                className: "prefix-option",
                value: t
            }, a(e.localizedName, e.prefix))
        }))), M().createElement("div", {
            id: "upsell-phonenumber-divider",
            className: "phone-divider"
        }), M().createElement("input", {
            id: r,
            type: "tel",
            value: c,
            className: "phone-input form-control",
            placeholder: t(Wt),
            autoComplete: "tel-national",
            onChange: function(e) {
                return i({
                    type: Mt,
                    phone: e.target.value
                })
            },
            onFocus: function() {
                ht(Ln.addPhonePhoneNumberPressed, {
                    origin: s,
                    section: u
                })
            }
        }))))
    }
    yr.propTypes = {
        translate: n().func.isRequired
    };
    var vr = yr;

    function br(e, t, n, r, i, o, a) {
        try {
            var c = e[o](a),
                l = c.value
        } catch (e) {
            return void n(e)
        }
        c.done ? t(l) : Promise.resolve(l).then(r, i)
    }

    function gr(e, t) {
        return function(e) {
            if (Array.isArray(e)) return e
        }(e) || function(e, t) {
            if ("undefined" == typeof Symbol || !(Symbol.iterator in Object(e))) return;
            var n = [],
                r = !0,
                i = !1,
                o = void 0;
            try {
                for (var a, c = e[Symbol.iterator](); !(r = (a = c.next()).done) && (n.push(a.value), !t || n.length !== t); r = !0);
            } catch (e) {
                i = !0, o = e
            } finally {
                try {
                    r || null == c.return || c.return()
                } finally {
                    if (i) throw o
                }
            }
            return n
        }(e, t) || function(e, t) {
            if (!e) return;
            if ("string" == typeof e) return Er(e, t);
            var n = Object.prototype.toString.call(e).slice(8, -1);
            "Object" === n && e.constructor && (n = e.constructor.name);
            if ("Map" === n || "Set" === n) return Array.from(e);
            if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return Er(e, t)
        }(e, t) || function() {
            throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }

    function Er(e, t) {
        (null == t || t > e.length) && (t = e.length);
        for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
        return r
    }
    var te = Bt,
        Bt = Kt,
        Yt = Yt,
        Pr = t,
        U = U,
        xr = W,
        Sr = z,
        wr = J,
        Nr = X,
        Cr = Z,
        Tr = Q,
        Ar = Y;

    function kr(e) {
        var t = e.translate,
            n = e.onHide,
            r = e.existingPhoneNumber,
            i = e.alwaysShowLegalText,
            o = e.requireLegalTextCheckbox,
            a = e.headingKey,
            c = e.descriptionKey,
            l = e.legalTextKey,
            s = e.buttonKey,
            u = Fn(),
            d = u.phoneUpsellState,
            p = u.dispatch,
            m = d.phone,
            f = d.phonePrefixPickerIndex,
            h = d.phonePrefixOptionsList,
            y = d.pageName,
            v = d.origin,
            e = gr((0, O.useState)(!1), 2),
            u = e[0],
            b = e[1],
            d = gr((0, O.useState)(!1), 2),
            e = d[0],
            g = d[1],
            d = gr((0, O.useState)(!1), 2),
            E = d[0],
            P = d[1],
            x = Jn(y);
        (0, O.useEffect)(function() {
            var e = null == h || null === (e = h[f]) || void 0 === e ? void 0 : e.code;
            g(!i && e !== Cn)
        }, [i, h, f]);
        var l = t(l, {
                linkTagWithSmsTos: Ar,
                linkTagWithPrivacyPolicy: Tr,
                linkTagEnd: Cr
            }),
            S = function() {
                var c, e = (c = regeneratorRuntime.mark(function e() {
                    var t, n;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return b(!0), n = h[f], t = n.prefix, n = n.code, ht(Ln.addPhoneContinuePressed, {
                                    origin: v,
                                    section: x
                                }), e.next = 5, Wn({
                                    phone: m,
                                    prefix: t,
                                    countryCode: n
                                }).then(function() {
                                    p({
                                        type: It,
                                        pageName: On
                                    })
                                }).catch(function(e) {
                                    var t = qe(e),
                                        e = yt(Ln.phoneNumberModalErrorShown, t);
                                    ht(e, {
                                        origin: v,
                                        section: x
                                    }), p({
                                        type: Ot,
                                        errorMessage: Xn(t)
                                    })
                                }).finally(function() {
                                    b(!1)
                                });
                            case 5:
                            case "end":
                                return e.stop()
                        }
                    }, e)
                }), function() {
                    var e = this,
                        a = arguments;
                    return new Promise(function(t, n) {
                        var r = c.apply(e, a);

                        function i(e) {
                            br(r, t, n, i, o, "next", e)
                        }

                        function o(e) {
                            br(r, t, n, i, o, "throw", e)
                        }
                        i(void 0)
                    })
                });
                return function() {
                    return e.apply(this, arguments)
                }
            }();
        return M().createElement("div", null, M().createElement(_e.Modal.Header, {
            useBaseBootstrapComponent: !0
        }, M().createElement("div", {
            className: "verification-upsell-title-container"
        }, M().createElement("button", {
            type: "button",
            className: "verification-upsell-title-button",
            onClick: n
        }, M().createElement("span", {
            className: "close icon-close"
        })), M().createElement(_e.Modal.Title, {
            id: "contained-modal-title-vcenter"
        }, t(r ? wr : a)))), M().createElement(_e.Modal.Body, null, M().createElement("div", {
            className: "phone-number-submission-container"
        }, M().createElement("div", {
            className: "verification-upsell-text-body text-description"
        }, t(c)), r && M().createElement(M().Fragment, null, M().createElement("div", {
            className: "verification-upsell-text-body text-description"
        }, t(xr), " ", r), M().createElement("div", {
            className: "border-warning two-step-warning"
        }, M().createElement("span", {
            className: "icon-warning-orange"
        }), M().createElement("span", {
            className: "small text-warning form-warning-text"
        }, t(Sr)))), M().createElement(vr, {
            translate: t
        }), M().createElement("div", {
            className: "phone-verification-nonpublic-text text-description font-caption-body"
        }, t(Pr)), M().createElement(fr, {
            translate: t
        }))), M().createElement(_e.Modal.Footer, null, o ? M().createElement("div", {
            className: "phone-verification-legal-container checkbox"
        }, M().createElement("input", {
            id: "phone-verification-legal-checkbox",
            className: "checkbox",
            type: "checkbox",
            checked: E,
            onChange: function() {
                return P(!E)
            }
        }), M().createElement("label", {
            className: "text-description font-caption-body phone-verification-legal-text",
            hidden: e,
            htmlFor: "phone-verification-legal-checkbox",
            dangerouslySetInnerHTML: {
                __html: l
            }
        })) : M().createElement("div", {
            className: "text-description font-caption-body phone-verification-legal-text",
            hidden: e,
            dangerouslySetInnerHTML: {
                __html: l
            }
        }), M().createElement("div", {
            className: "buttons-section"
        }, M().createElement(_e.Button, {
            type: "button",
            id: "add-phone-number-continue-button",
            className: "accept-btn",
            variant: _e.Button.variants.primary,
            isDisabled: u || 0 === m.length || o && !E,
            onClick: function() {
                return S()
            }
        }, t(s))), M().createElement("div", null, r && M().createElement("span", {
            className: "text-report remove-phone-label",
            onClick: function() {
                return p({
                    type: It,
                    pageName: Rn
                })
            },
            onKeyDown: function() {
                return p({
                    type: It,
                    pageName: Rn
                })
            },
            role: "button",
            tabIndex: 0
        }, t(Nr)))))
    }
    kr.propTypes = {
        translate: n().func.isRequired,
        onHide: n().func.isRequired,
        existingPhoneNumber: n().string,
        alwaysShowLegalText: n().bool,
        requireLegalTextCheckbox: n().bool,
        headingKey: n().string,
        descriptionKey: n().string,
        legalTextKey: n().string,
        buttonKey: n().string
    }, kr.defaultProps = {
        existingPhoneNumber: null,
        alwaysShowLegalText: !1,
        requireLegalTextCheckbox: !1,
        headingKey: te,
        descriptionKey: Yt,
        legalTextKey: U,
        buttonKey: Bt
    };
    var Or = kr;

    function Mr(e) {
        var t = e.translate,
            n = e.onHide,
            r = e.headingKey,
            i = e.descriptionKey,
            o = Fn().phoneUpsellState,
            a = o.origin,
            e = o.pageName,
            o = _t,
            c = Jn(e);
        return M().createElement("div", null, M().createElement(_e.Modal.Body, null, M().createElement("div", {
            className: "phone-number-verification-upsell-image"
        }), M().createElement("div", {
            className: "verification-upsell-title-container phone-number-verification-success-page-title page-title"
        }, M().createElement(_e.Modal.Title, {
            id: "contained-modal-title-vcenter"
        }, t(r))), M().createElement("div", {
            className: "phone-number-verification-text-body text-description"
        }, t(i))), M().createElement(_e.Modal.Footer, null, M().createElement("button", {
            type: "button",
            className: "btn-cta-md btn-max-width phone-number-verify-button",
            onClick: function() {
                ht(Ln.phoneAddedDonePressed, {
                    origin: a,
                    section: c
                }), n()
            }
        }, t(o))))
    }

    function Rr() {
        var e = {
            retryable: !0,
            withCredentials: !0,
            url: "".concat(ce, "/user-settings-api/v1/user-settings/metadata")
        };
        return d.httpService.get(e).then(function(e) {
            return e.data
        }, function(e) {
            return null
        })
    }

    function Ir(e) {
        var t = {
                retryable: !0,
                withCredentials: !0,
                url: "".concat(ce, "/user-settings-api/v1/user-settings")
            },
            e = {
                phoneNumberDiscoverability: e
            };
        return d.httpService.post(t, e).then(function(e) {
            return !0
        }).catch(function() {
            return !1
        })
    }
    Mr.propTypes = {
        translate: n().func.isRequired,
        onHide: n().func.isRequired,
        headingKey: n().string,
        descriptionKey: n().string
    }, Mr.defaultProps = {
        headingKey: j,
        descriptionKey: L
    };
    var Dr = Mr,
        Lr = "Unset",
        jr = "NotDiscoverable",
        Ur = "Discoverable",
        _r = "discoverabilityPageLoad",
        Kr = "discoverabilityPageClick",
        Br = "discoverabilityPageRadioButtonClick";

    function Hr(e, t) {
        return function(e) {
            if (Array.isArray(e)) return e
        }(e) || function(e, t) {
            if ("undefined" == typeof Symbol || !(Symbol.iterator in Object(e))) return;
            var n = [],
                r = !0,
                i = !1,
                o = void 0;
            try {
                for (var a, c = e[Symbol.iterator](); !(r = (a = c.next()).done) && (n.push(a.value), !t || n.length !== t); r = !0);
            } catch (e) {
                i = !0, o = e
            } finally {
                try {
                    r || null == c.return || c.return()
                } finally {
                    if (i) throw o
                }
            }
            return n
        }(e, t) || function(e, t) {
            if (!e) return;
            if ("string" == typeof e) return qr(e, t);
            var n = Object.prototype.toString.call(e).slice(8, -1);
            "Object" === n && e.constructor && (n = e.constructor.name);
            if ("Map" === n || "Set" === n) return Array.from(e);
            if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return qr(e, t)
        }(e, t) || function() {
            throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }

    function qr(e, t) {
        (null == t || t > e.length) && (t = e.length);
        for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
        return r
    }

    function Vr(e) {
        var t = e.translate,
            n = e.shouldPrefillAffirmativeDiscoverabilityConsent,
            r = e.origin,
            i = e.onHide,
            o = e.headingKey,
            a = e.descriptionKey,
            c = Fn().dispatch,
            l = en,
            s = tn,
            u = nn,
            d = rn,
            p = on,
            m = an,
            f = cn,
            h = ln,
            y = _r,
            v = Kr,
            b = Br,
            g = Hr((0, O.useState)(n ? Ur : Lr), 2),
            E = g[0],
            P = g[1],
            e = Hr((0, O.useState)(!1), 2),
            g = e[0],
            x = e[1],
            e = function(e) {
                P(e.currentTarget.value), pt.eventStreamService.sendEventWithTarget(b, e.currentTarget.value, {
                    origin: r
                })
            };
        return (0, O.useEffect)(function() {
            pt.eventStreamService.sendEventWithTarget(y, "phoneVerificationUpsell", {
                version: n ? "non_eu_version" : "eu_version",
                origin: r
            })
        }, []), M().createElement("div", {
            className: "phone-discoverability-consent"
        }, M().createElement(_e.Modal.Body, {
            className: "verification-grid"
        }, M().createElement("span", {
            className: "icon-spot-success-xl verification-grid-icon"
        }), M().createElement("div", {
            className: "discoverability-text-section"
        }, M().createElement("div", {
            className: "verification-upsell-title-container page-title "
        }, M().createElement(_e.Modal.Title, null, t(o))), M().createElement("div", {
            className: "text-description"
        }, t(a))), M().createElement("span", {
            className: "icon-spot-find-friends-xl verification-grid-icon"
        }), M().createElement("div", {
            className: "discoverability-text-section"
        }, M().createElement("div", {
            className: "verification-upsell-title-container page-title"
        }, M().createElement(_e.Modal.Title, null, t(p))), M().createElement("div", {
            className: "text-description"
        }, t(d))), M().createElement("div", {
            className: "verification-grid-icon"
        }), M().createElement("div", {
            className: "discoverability-radio-button-section"
        }, M().createElement("div", {
            className: "radio discoverability-consent-option"
        }, M().createElement("input", {
            type: "radio",
            name: "discoverability-options",
            id: "consent-radio-button",
            value: Ur,
            checked: E === Ur,
            onClick: e
        }), M().createElement("label", {
            className: "text-description",
            htmlFor: "consent-radio-button"
        }, t(f))), M().createElement("div", {
            className: "radio discoverability-consent-option"
        }, M().createElement("input", {
            type: "radio",
            name: "discoverability-options",
            id: "no-consent-radio-button",
            value: jr,
            checked: E === jr,
            onClick: e
        }), M().createElement("label", {
            className: "text-description",
            htmlFor: "no-consent-radio-button"
        }, t(m)))), M().createElement("div", {
            className: "verification-grid-icon"
        }), M().createElement("div", null, M().createElement("div", {
            className: "text-secondary"
        }, t(u)), M().createElement("a", {
            className: "text-secondary text-link learn-more-link",
            target: "_blank",
            rel: "noreferrer",
            href: "https://en.help.roblox.com/hc/articles/7416652004884"
        }, t(s)))), M().createElement(_e.Modal.Footer, null, M().createElement(fr, {
            translate: t
        }), M().createElement("button", {
            type: "button",
            className: "btn-cta-md btn-max-width phone-number-verify-button",
            disabled: g,
            onClick: function() {
                x(!0), pt.eventStreamService.sendEventWithTarget(v, E, {
                    origin: r
                }), Ir(E).then(function(e) {
                    return !0 !== e ? (x(!1), void c({
                        type: Ot,
                        errorMessage: h
                    })) : (c({
                        type: Ot,
                        errorMessage: ""
                    }), void i())
                })
            }
        }, t(l))))
    }

    function Fr(e) {
        return e.replace(/[^0-9]/g, "").substring(0, Wr)
    }
    Vr.propTypes = {
        origin: n().string.isRequired,
        translate: n().func.isRequired,
        shouldPrefillAffirmativeDiscoverabilityConsent: n().bool.isRequired,
        onHide: n().func.isRequired,
        headingKey: n().string,
        descriptionKey: n().string
    }, Vr.defaultProps = {
        headingKey: j,
        descriptionKey: L
    };
    var Gr = Vr,
        Wr = wn;

    function zr(t, e) {
        var n, r = Object.keys(t);
        return Object.getOwnPropertySymbols && (n = Object.getOwnPropertySymbols(t), e && (n = n.filter(function(e) {
            return Object.getOwnPropertyDescriptor(t, e).enumerable
        })), r.push.apply(r, n)), r
    }

    function $r(r) {
        for (var e = 1; e < arguments.length; e++) {
            var i = null != arguments[e] ? arguments[e] : {};
            e % 2 ? zr(Object(i), !0).forEach(function(e) {
                var t, n;
                t = r, e = i[n = e], n in t ? Object.defineProperty(t, n, {
                    value: e,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[n] = e
            }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(r, Object.getOwnPropertyDescriptors(i)) : zr(Object(i)).forEach(function(e) {
                Object.defineProperty(r, e, Object.getOwnPropertyDescriptor(i, e))
            })
        }
        return r
    }

    function Yr(e, t, n, r, i, o, a) {
        try {
            var c = e[o](a),
                l = c.value
        } catch (e) {
            return void n(e)
        }
        c.done ? t(l) : Promise.resolve(l).then(r, i)
    }

    function Xr(e, t) {
        return function(e) {
            if (Array.isArray(e)) return e
        }(e) || function(e, t) {
            if ("undefined" == typeof Symbol || !(Symbol.iterator in Object(e))) return;
            var n = [],
                r = !0,
                i = !1,
                o = void 0;
            try {
                for (var a, c = e[Symbol.iterator](); !(r = (a = c.next()).done) && (n.push(a.value), !t || n.length !== t); r = !0);
            } catch (e) {
                i = !0, o = e
            } finally {
                try {
                    r || null == c.return || c.return()
                } finally {
                    if (i) throw o
                }
            }
            return n
        }(e, t) || function(e, t) {
            if (!e) return;
            if ("string" == typeof e) return Jr(e, t);
            var n = Object.prototype.toString.call(e).slice(8, -1);
            "Object" === n && e.constructor && (n = e.constructor.name);
            if ("Map" === n || "Set" === n) return Array.from(e);
            if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return Jr(e, t)
        }(e, t) || function() {
            throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }

    function Jr(e, t) {
        (null == t || t > e.length) && (t = e.length);
        for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
        return r
    }

    function Qr(e) {
        var t = e.translate,
            n = e.onHide,
            r = e.onVerify,
            i = Fn(),
            o = i.phoneUpsellState,
            a = i.dispatch,
            c = o.phone,
            l = o.phonePrefixOptionsList,
            s = o.phonePrefixPickerIndex,
            u = o.pageName,
            d = o.origin,
            p = Xr((0, O.useState)({
                code: "",
                isReadyToSubmitCode: ""
            }), 2),
            m = p[0],
            f = p[1],
            h = Jn(u),
            y = Xr((0, O.useState)(0), 2),
            v = y[0],
            b = y[1],
            g = Xr((0, O.useState)(!1), 2),
            E = g[0],
            P = g[1],
            x = Ft,
            S = Ht,
            w = Kt,
            N = qt,
            e = Vt,
            i = Gt,
            p = zt,
            u = An,
            C = Pn,
            T = wn,
            y = xn,
            g = Sn,
            A = Nn,
            c = En(l[s].prefix, c);

        function k() {
            var c;
            return c = regeneratorRuntime.mark(function e() {
                var t, n;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                        case 0:
                            if (ht(Ln.verifyPhoneContinuePressed, {
                                    origin: d,
                                    section: h
                                }), m.code.length !== T) return e.abrupt("return");
                            e.next = 3;
                            break;
                        case 3:
                            return P(!0), a({
                                type: Ot,
                                errorMessage: ""
                            }), e.prev = 5, e.next = 8, zn(m.code);
                        case 8:
                            return a({
                                type: Dt,
                                isPhoneVerified: !0
                            }), e.next = 11, r();
                        case 11:
                            e.next = 20;
                            break;
                        case 13:
                            e.prev = 13, e.t0 = e.catch(5), n = qe(e.t0), t = function(e) {
                                switch (e) {
                                    case pr:
                                        return er;
                                    case dr:
                                        return or;
                                    default:
                                        return rr
                                }
                            }(n), n = yt(Ln.phoneNumberModalErrorShown, n), ht(n, {
                                origin: d,
                                section: h
                            }), a({
                                type: Ot,
                                errorMessage: t
                            });
                        case 20:
                            return e.prev = 20, f($r($r({}, m), {}, {
                                isReadyToSubmitCode: !1
                            })), P(!1), e.finish(20);
                        case 24:
                        case "end":
                            return e.stop()
                    }
                }, e, null, [
                    [5, 13, 20, 24]
                ])
            }), (k = function() {
                var e = this,
                    a = arguments;
                return new Promise(function(t, n) {
                    var r = c.apply(e, a);

                    function i(e) {
                        Yr(r, t, n, i, o, "next", e)
                    }

                    function o(e) {
                        Yr(r, t, n, i, o, "throw", e)
                    }
                    i(void 0)
                })
            }).apply(this, arguments)
        }
        return (0, O.useEffect)(function() {
            m.isReadyToSubmitCode && function() {
                k.apply(this, arguments)
            }()
        }, [m]), M().createElement("div", null, M().createElement(_e.Modal.Header, {
            useBaseBootstrapComponent: !0
        }, M().createElement("div", {
            className: "verification-upsell-title-container"
        }, M().createElement("button", {
            type: "button",
            className: "verification-upsell-title-button",
            onClick: n
        }, M().createElement("span", {
            className: "close icon-close"
        })), M().createElement(_e.Modal.Title, {
            id: "contained-modal-title-vcenter"
        }, t(x)))), M().createElement(_e.Modal.Body, null, M().createElement("div", {
            className: "phone-number-verification-upsell-image"
        }), M().createElement("div", {
            className: "verification-upsell-text-body text-description"
        }, t(i, {
            phoneNumber: c
        })), M().createElement("button", {
            type: "button",
            className: "phone-number-change-number-button phone-number-text-button",
            onClick: function() {
                ht(Ln.verifyPhoneChangePhoneNumberPressed, {
                    origin: d,
                    section: h
                }), a({
                    type: It,
                    pageName: kn
                })
            }
        }, t(S)), M().createElement("label", {
            htmlFor: u
        }, M().createElement("p", {
            className: "verification-code-label font-caption-header text-primary"
        }, t(p))), M().createElement("input", {
            id: u,
            type: "text",
            inputMode: "numeric",
            className: "".concat(o.errorMessage ? "input-field-error" : "", " form-control input-field input-number verification-code-input"),
            onChange: function(e) {
                return e = e.target.value, a({
                    type: Ot,
                    errorMessage: ""
                }), void f($r($r({}, m), {}, {
                    code: Fr(e)
                }))
            },
            onPaste: function(e) {
                e = (e.clipboardData || window.clipboardData).getData("text"), e = Fr(e), f({
                    code: e,
                    isReadyToSubmitCode: !0
                })
            },
            autoComplete: "one-time-code",
            placeholder: "000000",
            onKeyDown: function(e) {
                e.key === C && f($r($r({}, m), {}, {
                    isReadyToSubmitCode: !0
                }))
            },
            onFocus: function() {
                ht(Ln.verifyPhoneCodeFieldPressed, {
                    origin: d,
                    section: h
                })
            },
            value: m.code
        }), M().createElement(fr, {
            translate: t
        })), M().createElement(_e.Modal.Footer, null, M().createElement("button", {
            type: "button",
            className: "btn-cta-md btn-max-width phone-number-verify-button",
            disabled: E || 6 !== m.code.length,
            onClick: function() {
                f($r($r({}, m), {}, {
                    isReadyToSubmitCode: !0
                }))
            }
        }, t(w)), 0 === v ? M().createElement("button", {
            type: "button",
            className: " btn-secondary-md btn-max-width phone-number-resent-button",
            disabled: E,
            onClick: function() {
                var t;
                ht(Ln.verifyPhoneResendPressed, {
                    origin: d,
                    section: h
                }), 0 === v && ($n(), 0 === v && (t = setInterval(function() {
                    b(function(e) {
                        return 1 === e && clearInterval(t), e - 1
                    })
                }, 1e3)), b(A))
            }
        }, t(N)) : M().createElement("button", {
            type: "button",
            className: " btn-secondary-md btn-max-width phone-number-resent-button btn-max-width resend-button-disabled"
        }, t(e), M().createElement("span", null, y + v + g))))
    }
    Qr.propTypes = {
        translate: n().func.isRequired,
        onHide: n().func.isRequired,
        onVerify: n().func.isRequired
    };
    var Zr = Qr;

    function ei(e, t, n, r, i, o, a) {
        try {
            var c = e[o](a),
                l = c.value
        } catch (e) {
            return void n(e)
        }
        c.done ? t(l) : Promise.resolve(l).then(r, i)
    }

    function ti(e, t) {
        return function(e) {
            if (Array.isArray(e)) return e
        }(e) || function(e, t) {
            if ("undefined" == typeof Symbol || !(Symbol.iterator in Object(e))) return;
            var n = [],
                r = !0,
                i = !1,
                o = void 0;
            try {
                for (var a, c = e[Symbol.iterator](); !(r = (a = c.next()).done) && (n.push(a.value), !t || n.length !== t); r = !0);
            } catch (e) {
                i = !0, o = e
            } finally {
                try {
                    r || null == c.return || c.return()
                } finally {
                    if (i) throw o
                }
            }
            return n
        }(e, t) || function(e, t) {
            if (!e) return;
            if ("string" == typeof e) return ni(e, t);
            var n = Object.prototype.toString.call(e).slice(8, -1);
            "Object" === n && e.constructor && (n = e.constructor.name);
            if ("Map" === n || "Set" === n) return Array.from(e);
            if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return ni(e, t)
        }(e, t) || function() {
            throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }

    function ni(e, t) {
        (null == t || t > e.length) && (t = e.length);
        for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
        return r
    }

    function ri(e) {
        var t = e.translate,
            n = e.existingPhoneNumber,
            r = e.onHide,
            i = Fn().dispatch,
            o = Xt,
            a = Zt,
            c = Jt,
            l = Qt,
            s = ti((0, O.useState)(!1), 2),
            e = s[0],
            u = s[1],
            s = function() {
                var c, e = (c = regeneratorRuntime.mark(function e() {
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return u(!0), e.next = 3, Yn().then(function() {
                                    r()
                                }).catch(function(e) {
                                    e = qe(e);
                                    i({
                                        type: Ot,
                                        errorMessage: Xn(e)
                                    })
                                }).finally(function() {
                                    u(!1)
                                });
                            case 3:
                            case "end":
                                return e.stop()
                        }
                    }, e)
                }), function() {
                    var e = this,
                        a = arguments;
                    return new Promise(function(t, n) {
                        var r = c.apply(e, a);

                        function i(e) {
                            ei(r, t, n, i, o, "next", e)
                        }

                        function o(e) {
                            ei(r, t, n, i, o, "throw", e)
                        }
                        i(void 0)
                    })
                });
                return function() {
                    return e.apply(this, arguments)
                }
            }(),
            n = n.match(/\d+$/);
        return M().createElement("div", null, M().createElement(_e.Modal.Header, {
            useBaseBootstrapComponent: !0
        }, M().createElement("div", {
            className: "verification-upsell-title-container"
        }, M().createElement("button", {
            type: "button",
            className: "verification-upsell-title-button",
            onClick: r
        }, M().createElement("span", {
            className: "close icon-close"
        })), M().createElement(_e.Modal.Title, {
            id: "contained-modal-title-vcenter"
        }, t(o)))), M().createElement(_e.Modal.Body, null, M().createElement("div", {
            className: "phone-number-verification-text-body text-description"
        }, t(a, {
            phoneLast4: n
        }))), M().createElement(_e.Modal.Footer, null, M().createElement(fr, {
            translate: t
        }), M().createElement(_e.Button, {
            className: "delete-phone-btn",
            variant: _e.Button.variants.primary,
            size: _e.Button.sizes.medium,
            isLoading: e,
            onClick: s
        }, t(c)), M().createElement(_e.Button, {
            variant: _e.Button.variants.secondary,
            size: _e.Button.sizes.medium,
            isLoading: e,
            onClick: r
        }, t(l))))
    }
    ri.propTypes = {
        translate: n().func.isRequired,
        onHide: n().func.isRequired,
        existingPhoneNumber: n().string
    }, ri.defaultProps = {
        existingPhoneNumber: null
    };
    var ii = ri;

    function oi(e, t, n, r, i, o, a) {
        try {
            var c = e[o](a),
                l = c.value
        } catch (e) {
            return void n(e)
        }
        c.done ? t(l) : Promise.resolve(l).then(r, i)
    }
    var ai = function() {
        var c, e = (c = regeneratorRuntime.mark(function e() {
            var t, n, r;
            return regeneratorRuntime.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                    case 0:
                        return n = !(t = Mn), e.next = 4, Rr();
                    case 4:
                        return !0 === (null == (r = e.sent) ? void 0 : r.isDiscoverabilitySettingsEnabled) && !0 === (null == r ? void 0 : r.showDiscoverabilityUpsells) && (t = In, n = !0 === (null == r ? void 0 : r.prefillDiscoverabilitySetting)), e.abrupt("return", {
                            successPage: t,
                            shouldPrefillAffirmativeDiscoverabilityConsent: n
                        });
                    case 7:
                    case "end":
                        return e.stop()
                }
            }, e)
        }), function() {
            var e = this,
                a = arguments;
            return new Promise(function(t, n) {
                var r = c.apply(e, a);

                function i(e) {
                    oi(r, t, n, i, o, "next", e)
                }

                function o(e) {
                    oi(r, t, n, i, o, "throw", e)
                }
                i(void 0)
            })
        });
        return function() {
            return e.apply(this, arguments)
        }
    }();

    function ci(e, t, n, r, i, o, a) {
        try {
            var c = e[o](a),
                l = c.value
        } catch (e) {
            return void n(e)
        }
        c.done ? t(l) : Promise.resolve(l).then(r, i)
    }

    function li(c) {
        return function() {
            var e = this,
                a = arguments;
            return new Promise(function(t, n) {
                var r = c.apply(e, a);

                function i(e) {
                    ci(r, t, n, i, o, "next", e)
                }

                function o(e) {
                    ci(r, t, n, i, o, "throw", e)
                }
                i(void 0)
            })
        }
    }

    function si(e, t) {
        return function(e) {
            if (Array.isArray(e)) return e
        }(e) || function(e, t) {
            if ("undefined" == typeof Symbol || !(Symbol.iterator in Object(e))) return;
            var n = [],
                r = !0,
                i = !1,
                o = void 0;
            try {
                for (var a, c = e[Symbol.iterator](); !(r = (a = c.next()).done) && (n.push(a.value), !t || n.length !== t); r = !0);
            } catch (e) {
                i = !0, o = e
            } finally {
                try {
                    r || null == c.return || c.return()
                } finally {
                    if (i) throw o
                }
            }
            return n
        }(e, t) || function(e, t) {
            if (!e) return;
            if ("string" == typeof e) return ui(e, t);
            var n = Object.prototype.toString.call(e).slice(8, -1);
            "Object" === n && e.constructor && (n = e.constructor.name);
            if ("Map" === n || "Set" === n) return Array.from(e);
            if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return ui(e, t)
        }(e, t) || function() {
            throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }

    function ui(e, t) {
        (null == t || t > e.length) && (t = e.length);
        for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
        return r
    }

    function di(e) {
        function t() {
            ht(Ln.phoneNumberModalDismissed, {
                origin: m.origin,
                section: P
            }), r(m.isPhoneVerified), f({
                type: kt
            })
        }
        var n = e.translate,
            r = e.onClose,
            i = e.origin,
            o = e.existingPhoneNumber,
            a = e.addPhoneAlwaysShowLegalText,
            c = e.addPhoneRequireLegalTextCheckbox,
            l = e.addPhoneHeadingKey,
            s = e.addPhoneDescriptionKey,
            u = e.addPhoneLegalTextKey,
            d = e.addPhoneButtonKey,
            p = e.beforeSuccess,
            e = Fn(),
            m = e.phoneUpsellState,
            f = e.dispatch,
            e = si((0, O.useState)(Mn), 2),
            h = e[0],
            y = e[1],
            e = si((0, O.useState)(void 0), 2),
            v = e[0],
            b = e[1],
            e = si((0, O.useState)(void 0), 2),
            g = e[0],
            E = e[1],
            P = Jn(m.pageName),
            x = function() {
                var e = li(regeneratorRuntime.mark(function e() {
                    var t, n;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                if (p) return e.prev = 1, e.next = 4, p();
                                e.next = 15;
                                break;
                            case 4:
                                t = e.sent, n = si(t, 2), t = n[0], n = n[1], b(t), E(n), e.next = 15;
                                break;
                            case 12:
                                e.prev = 12, e.t0 = e.catch(1), console.error("Error from before success hook in phone verification: ".concat(e.t0), e.t0);
                            case 15:
                                f({
                                    type: It,
                                    pageName: h
                                });
                            case 16:
                            case "end":
                                return e.stop()
                        }
                    }, e, null, [
                        [1, 12]
                    ])
                }));
                return function() {
                    return e.apply(this, arguments)
                }
            }();
        return (0, O.useEffect)(function() {
            m.origin !== Xe && ht(Ln.phoneNumberModalShown, {
                origin: m.origin,
                section: P
            })
        }, [m.pageName, m.origin]), (0, O.useEffect)(function() {
            f({
                type: jt,
                origin: i
            })
        }, []), (0, O.useEffect)(function() {
            function e() {
                return (e = li(regeneratorRuntime.mark(function e() {
                    var t, n;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return e.next = 2, ai();
                            case 2:
                                n = e.sent, t = n.successPage, n = n.shouldPrefillAffirmativeDiscoverabilityConsent, f({
                                    type: Ut,
                                    shouldPrefillAffirmativeDiscoverabilityConsent: n
                                }), y(t);
                            case 7:
                            case "end":
                                return e.stop()
                        }
                    }, e)
                }))).apply(this, arguments)
            }! function() {
                e.apply(this, arguments)
            }()
        }, []), M().createElement(_e.Modal, {
            show: m.isOpen,
            onHide: t,
            className: "verification-modal",
            size: "lg",
            "aria-labelledby": "contained-modal-title-vcenter",
            scrollable: "true",
            centered: "true"
        }, function() {
            switch (m.pageName) {
                case kn:
                    return M().createElement(Or, {
                        translate: n,
                        onHide: t,
                        existingPhoneNumber: o,
                        alwaysShowLegalText: a,
                        requireLegalTextCheckbox: c,
                        headingKey: l,
                        descriptionKey: s,
                        legalTextKey: u,
                        buttonKey: d
                    });
                case On:
                    return M().createElement(Zr, {
                        translate: n,
                        onHide: t,
                        onVerify: x
                    });
                case Mn:
                    return M().createElement(Dr, {
                        translate: n,
                        onHide: t,
                        headingKey: v,
                        descriptionKey: g
                    });
                case Rn:
                    return M().createElement(ii, {
                        translate: n,
                        existingPhoneNumber: o,
                        onHide: t
                    });
                case In:
                    return M().createElement(Gr, {
                        translate: n,
                        onHide: t,
                        origin: m.origin,
                        shouldPrefillAffirmativeDiscoverabilityConsent: m.shouldPrefillAffirmativeDiscoverabilityConsent,
                        headingKey: v,
                        descriptionKey: g
                    });
                default:
                    return M().createElement(Or, {
                        translate: n,
                        onHide: t
                    })
            }
        }())
    }
    di.propTypes = {
        translate: n().func.isRequired,
        onClose: n().func.isRequired,
        origin: n().string,
        existingPhoneNumber: n().string,
        addPhoneAlwaysShowLegalText: n().bool,
        addPhoneRequireLegalTextCheckbox: n().bool,
        addPhoneHeadingKey: n().string,
        addPhoneDescriptionKey: n().string,
        addPhoneLegalTextKey: n().string,
        addPhoneButtonKey: n().string,
        beforeSuccess: n().func
    }, di.defaultProps = {
        origin: Je,
        existingPhoneNumber: null,
        addPhoneAlwaysShowLegalText: void 0,
        addPhoneRequireLegalTextCheckbox: void 0,
        addPhoneHeadingKey: void 0,
        addPhoneDescriptionKey: void 0,
        addPhoneLegalTextKey: void 0,
        addPhoneButtonKey: void 0,
        beforeSuccess: null
    };
    var pi = di;

    function mi(e) {
        var t = e.translate,
            n = e.onClose,
            r = e.origin,
            i = e.existingPhoneNumber,
            o = e.addPhoneAlwaysShowLegalText,
            a = e.addPhoneRequireLegalTextCheckbox,
            c = e.addPhoneHeadingKey,
            l = e.addPhoneDescriptionKey,
            s = e.addPhoneLegalTextKey,
            u = e.addPhoneButtonKey,
            e = e.beforeSuccess;
        return M().createElement(Hn, null, M().createElement(pi, {
            translate: t,
            onClose: n,
            origin: r,
            existingPhoneNumber: i,
            addPhoneAlwaysShowLegalText: o,
            addPhoneRequireLegalTextCheckbox: a,
            addPhoneHeadingKey: c,
            addPhoneDescriptionKey: l,
            addPhoneLegalTextKey: s,
            addPhoneButtonKey: u,
            beforeSuccess: e
        }))
    }
    mi.propTypes = {
        translate: n().func.isRequired,
        origin: n().string,
        onClose: n().func,
        existingPhoneNumber: n().string,
        addPhoneAlwaysShowLegalText: n().bool,
        addPhoneRequireLegalTextCheckbox: n().bool,
        addPhoneHeadingKey: n().string,
        addPhoneDescriptionKey: n().string,
        addPhoneLegalTextKey: n().string,
        addPhoneButtonKey: n().string,
        beforeSuccess: n().func
    }, mi.defaultProps = {
        origin: void 0,
        onClose: function() {
            return null
        },
        existingPhoneNumber: null,
        addPhoneAlwaysShowLegalText: void 0,
        addPhoneRequireLegalTextCheckbox: void 0,
        addPhoneHeadingKey: void 0,
        addPhoneDescriptionKey: void 0,
        addPhoneLegalTextKey: void 0,
        addPhoneButtonKey: void 0,
        beforeSuccess: void 0
    };
    var fi = (0, i.withTranslations)(mi, a),
        hi = "CLOSE_CONTACT_METHOD_PROMPT_MODAL",
        yi = "SET_LOGGING_VALUES";

    function vi(e, t) {
        return function(e) {
            if (Array.isArray(e)) return e
        }(e) || function(e, t) {
            if ("undefined" == typeof Symbol || !(Symbol.iterator in Object(e))) return;
            var n = [],
                r = !0,
                i = !1,
                o = void 0;
            try {
                for (var a, c = e[Symbol.iterator](); !(r = (a = c.next()).done) && (n.push(a.value), !t || n.length !== t); r = !0);
            } catch (e) {
                i = !0, o = e
            } finally {
                try {
                    r || null == c.return || c.return()
                } finally {
                    if (i) throw o
                }
            }
            return n
        }(e, t) || function(e, t) {
            if (!e) return;
            if ("string" == typeof e) return bi(e, t);
            var n = Object.prototype.toString.call(e).slice(8, -1);
            "Object" === n && e.constructor && (n = e.constructor.name);
            if ("Map" === n || "Set" === n) return Array.from(e);
            if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return bi(e, t)
        }(e, t) || function() {
            throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }

    function bi(e, t) {
        (null == t || t > e.length) && (t = e.length);
        for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
        return r
    }

    function gi(t, e) {
        var n, r = Object.keys(t);
        return Object.getOwnPropertySymbols && (n = Object.getOwnPropertySymbols(t), e && (n = n.filter(function(e) {
            return Object.getOwnPropertyDescriptor(t, e).enumerable
        })), r.push.apply(r, n)), r
    }

    function Ei(r) {
        for (var e = 1; e < arguments.length; e++) {
            var i = null != arguments[e] ? arguments[e] : {};
            e % 2 ? gi(Object(i), !0).forEach(function(e) {
                var t, n;
                t = r, e = i[n = e], n in t ? Object.defineProperty(t, n, {
                    value: e,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[n] = e
            }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(r, Object.getOwnPropertyDescriptors(i)) : gi(Object(i)).forEach(function(e) {
                Object.defineProperty(r, e, Object.getOwnPropertyDescriptor(i, e))
            })
        }
        return r
    }

    function Pi(e, t) {
        switch (t.type) {
            case hi:
                return Ei(Ei({}, e), {}, {
                    isOpen: !1
                });
            case yi:
                return Ei(Ei({}, e), {}, {
                    origin: t.origin,
                    section: t.section
                });
            default:
                return Si
        }
    }

    function xi(e) {
        var t = e.children,
            e = (n = vi((0, O.useReducer)(Pi, Si), 2))[0],
            n = n[1];
        return M().createElement(wi.Provider, {
            value: {
                contactMethodPromptModalState: e,
                dispatch: n
            }
        }, t)
    }
    var Si = {
            isOpen: !0,
            origin: "",
            section: ""
        },
        wi = (0, O.createContext)(Si);
    xi.propTypes = {
        children: n().node.isRequired
    };
    var L = pt.eventStreamService.eventTypes,
        Je = "contactMethodModal",
        Ni = {
            contactMethodPromptShown: {
                name: "contactMethodPromptShown",
                type: L.modalAction,
                context: Je,
                params: {
                    aType: "shown"
                }
            },
            contactMethodPromptDismissed: {
                name: "contactMethodPromptDismissed",
                type: L.modalAction,
                context: Je,
                params: {
                    aType: "dismissed"
                }
            },
            contactMethodPromptEmailClicked: {
                name: "contactMethodPromptEmailClicked",
                type: L.buttonClick,
                context: Je,
                params: {
                    btn: "email"
                }
            },
            contactMethodPromptPhoneClicked: {
                name: "contactMethodPromptPhoneClicked",
                type: L.buttonClick,
                context: Je,
                params: {
                    btn: "phone"
                }
            },
            contactMethodPromptSupportClicked: {
                name: "contactMethodPromptSupportClicked",
                type: L.buttonClick,
                context: Je,
                params: {
                    btn: "support"
                }
            },
            contactMethodPromptLogoutClicked: {
                name: "contactMethodPromptLogoutClicked",
                type: L.buttonClick,
                context: Je,
                params: {
                    btn: "logout"
                }
            }
        };

    function Ci() {
        return (0, O.useContext)(wi)
    }

    function Ti(e) {
        function t(e) {
            e || null !== m.UpsellService && void 0 !== m.UpsellService && m.UpsellService.renderContactMethodPromptModal({
                origin: i.origin,
                section: i.section
            })
        }
        var n = e.translate,
            r = e.onHide,
            i = Ci().contactMethodPromptModalState,
            o = sn,
            a = un,
            c = dn,
            l = pn,
            s = mn,
            u = fn,
            d = yn,
            p = vn,
            e = hn;
        return M().createElement("div", null, M().createElement(_e.Modal.Header, {
            useBaseBootstrapComponent: !0
        }, M().createElement("div", {
            className: "verification-upsell-title-container"
        }, M().createElement(_e.Modal.Title, {
            id: "contained-modal-title-vcenter"
        }, n(o)))), M().createElement(_e.Modal.Body, {
            className: "verification-grid"
        }, M().createElement("span", {
            className: "icon-spot-passcode-xl verification-grid-icon"
        }), M().createElement("div", null, M().createElement("div", {
            className: "verification-upsell-title-container page-title "
        }, M().createElement("div", {
            className: "font-header-2"
        }, n(a))), M().createElement("div", {
            className: "text-description"
        }, n(c))), M().createElement("span", {
            className: "icon-spot-success-xl verification-grid-icon"
        }), M().createElement("div", null, M().createElement("div", {
            className: "verification-upsell-title-container page-title"
        }, M().createElement("div", {
            className: "font-header-2"
        }, n(l))), M().createElement("div", {
            className: "text-description"
        }, n(s)))), M().createElement(_e.Modal.Footer, null, M().createElement("button", {
            type: "button",
            className: "btn-cta-md btn-max-width phone-number-verify-button",
            onClick: function() {
                r(), ht(Ni.contactMethodPromptPhoneClicked, {
                    origin: i.origin,
                    section: i.section
                }), null !== m.UpsellService && void 0 !== m.UpsellService && m.UpsellService.renderPhoneUpsell({
                    onClose: t
                })
            }
        }, n(u)), M().createElement("button", {
            type: "button",
            className: " btn-secondary-md btn-max-width phone-number-resent-button",
            onClick: function() {
                r(), ht(Ni.contactMethodPromptEmailClicked, {
                    origin: i.origin,
                    section: i.section
                }), null !== m.UpsellService && void 0 !== m.UpsellService && m.UpsellService.renderEmailUpsell(t)
            }
        }, n(e)), M().createElement("div", null, M().createElement("div", {
            className: "contact-method-prompt-links"
        }, M().createElement(_e.Link, {
            className: "text-default contact-method-link-button",
            href: "https://en.help.roblox.com/hc/articles/203313350",
            target: "_blank",
            onClick: function() {
                ht(Ni.contactMethodPromptSupportClicked, {
                    origin: i.origin,
                    section: i.section
                })
            }
        }, n(p)), M().createElement("button", {
            type: "button",
            className: "text-default contact-method-link-button",
            onClick: function() {
                ht(Ni.contactMethodPromptLogoutClicked, {
                    origin: i.origin,
                    section: i.section
                }), m.NavigationService.logoutAndRedirect()
            }
        }, n(d))))))
    }
    Ti.propTypes = {
        translate: n().func.isRequired,
        onHide: n().func.isRequired
    };
    var Ai = Ti;

    function ki(e) {
        function t() {
            ht(Ni.contactMethodPromptDismissed, {
                origin: o.origin,
                section: o.section
            }), a({
                type: hi
            })
        }
        var n = e.translate,
            r = e.origin,
            i = e.section,
            e = Ci(),
            o = e.contactMethodPromptModalState,
            a = e.dispatch;
        return (0, O.useEffect)(function() {
            a({
                type: yi,
                origin: r,
                section: i
            })
        }, []), (0, O.useEffect)(function() {
            o.origin && o.section && ht(Ni.contactMethodPromptShown, {
                origin: o.origin,
                section: o.section
            })
        }, [o.origin, o.section]), M().createElement(_e.Modal, {
            show: o.isOpen,
            onHide: t,
            keyboard: !1,
            className: "verification-modal",
            backdrop: "static",
            size: "lg",
            "aria-labelledby": "contained-modal-title-vcenter",
            scrollable: "true",
            centered: "true"
        }, M().createElement(Ai, {
            translate: n,
            onHide: t
        }))
    }
    ki.propTypes = {
        translate: n().func.isRequired,
        section: n().string.isRequired,
        origin: n().string.isRequired
    };
    var Oi = ki;

    function Mi(e) {
        var t = e.translate,
            n = e.origin,
            e = e.section;
        return M().createElement(xi, null, M().createElement(Oi, {
            translate: t,
            origin: n,
            section: e
        }))
    }
    Mi.propTypes = {
        translate: n().func.isRequired,
        origin: n().string.isRequired,
        section: n().string.isRequired
    };
    var Ri = (0, i.withTranslations)(Mi, a);
    e().UpsellService = {
        renderEmailUpsell: function(t) {
            (0, d.ready)(function() {
                var e = document.getElementById(o);
                e && ((0, p.unmountComponentAtNode)(e), (0, p.render)(M().createElement(At, null), e), nt(t))
            })
        },
        renderPhoneUpsell: function(e) {
            var e = 0 < arguments.length && void 0 !== e ? e : {},
                t = e.onClose,
                n = e.origin,
                r = e.existingPhoneNumber,
                i = e.addPhoneAlwaysShowLegalText,
                o = e.addPhoneRequireLegalTextCheckbox,
                a = e.addPhoneHeadingKey,
                c = e.addPhoneDescriptionKey,
                l = e.addPhoneLegalTextKey,
                s = e.addPhoneButtonKey,
                u = e.beforeSuccess;
            (0, d.ready)(function() {
                var e = document.getElementById("phoneVerificationUpsell-container");
                e && ((0, p.unmountComponentAtNode)(e), (0, p.render)(M().createElement(fi, {
                    onClose: t,
                    origin: n,
                    existingPhoneNumber: r,
                    addPhoneAlwaysShowLegalText: i,
                    addPhoneRequireLegalTextCheckbox: o,
                    addPhoneHeadingKey: a,
                    addPhoneDescriptionKey: c,
                    addPhoneLegalTextKey: l,
                    addPhoneButtonKey: s,
                    beforeSuccess: u
                }), e))
            })
        },
        renderContactMethodPromptModal: function(e) {
            var t = e.origin,
                n = e.section;
            (0, d.ready)(function() {
                var e = document.getElementById("contactMethodPrompt-container");
                e && ((0, p.unmountComponentAtNode)(e), (0, p.render)(M().createElement(Ri, {
                    origin: t,
                    section: n
                }), e))
            })
        }
    }, e().EmailVerificationService = {
        handleUserEmailUpsellAtLogout: at,
        handleUserEmailUpsellAtBuyRobux: function(e) {
            return tt({
                origin: C,
                skipCallback: e
            })
        },
        handleUserEmailUpsellOnHomePage: nt,
        handleUserEmailVerificationRequiredByPurchaseWarning: function() {
            return tt({
                origin: k,
                requireVerification: !0
            })
        },
        handleUserEmailUpsellAtPremiumSubscription: function(e) {
            return tt({
                origin: A,
                skipCallback: e
            })
        },
        handleUserEmailVerificationRequiredByBan: function() {
            return tt({
                origin: R,
                requireVerification: !0
            })
        }
    }, (0, d.ready)(function() {
        document.getElementById(o) && (0, p.render)(M().createElement(At, null), document.getElementById(o))
    })
}();
//# sourceMappingURL=https://js.rbxcdn.com/a665ac730a47fc141f69529c79dd3be8-verificationUpsell.bundle.min.js.map

/* Bundle detector */
window.Roblox && window.Roblox.BundleDetector && window.Roblox.BundleDetector.bundleDetected("VerificationUpsell");