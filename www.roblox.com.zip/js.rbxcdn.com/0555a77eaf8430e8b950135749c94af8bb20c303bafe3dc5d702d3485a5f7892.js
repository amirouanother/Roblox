! function() {
    "use strict";
    var M, o = {
            n: function(e) {
                var t = e && e.__esModule ? function() {
                    return e.default
                } : function() {
                    return e
                };
                return o.d(t, {
                    a: t
                }), t
            },
            d: function(e, t) {
                for (var n in t) o.o(t, n) && !o.o(e, n) && Object.defineProperty(e, n, {
                    enumerable: !0,
                    get: t[n]
                })
            },
            o: function(e, t) {
                return Object.prototype.hasOwnProperty.call(e, t)
            }
        },
        t = Roblox,
        e = o.n(t),
        A = React,
        R = o.n(A),
        m = ReactDOM,
        N = ReactStyleGuide,
        D = ReactUtilities,
        I = "enterEmail",
        B = "enterCode",
        f = "Label.Email",
        S = "Response.InvalidEmail",
        T = "Action.SendCode",
        P = "Label.SixDigitCode",
        L = "Label.CodeSent",
        F = "Action.Resend",
        V = "Action.Continue",
        G = "Action.ChangeEmail",
        U = "Description.EnterCodeHelpV3",
        z = "Action.DidntReceiveCode",
        H = "Response.TooManyAttemptsPleaseWait",
        K = "Response.ErrorUseCorporateNetwork",
        W = "Response.UnknownError",
        j = "Response.IncorrectOtpCode",
        X = 3,
        Y = 6,
        q = 8,
        $ = 2,
        J = 429,
        Q = "email",
        i = function() {
            return (i = Object.assign || function(e) {
                for (var t, n = 1, o = arguments.length; n < o; n++)
                    for (var i in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i]);
                return e
            }).apply(this, arguments)
        };

    function r(e, t) {
        var n = i({}, e);
        switch (t.type) {
            case M.SET_ENTER_EMAIL_PAGE:
                return n.emailVerifyCodeModalPage = I, n;
            case M.SET_ENTER_CODE_PAGE:
                return n.emailVerifyCodeModalPage = B, n;
            case M.SET_EMAIL:
                return n.email = t.email, n;
            case M.SET_SESSION_TOKEN:
                return n.sessionToken = t.sessionToken, n;
            case M.SET_OTP_CODE:
                return n.code = t.code, n;
            case M.SET_LEGAL_CHECK:
                return n.isChecked = t.isChecked, n;
            case M.SET_CODE_VALID:
                return n.isCodeValid = t.isCodeValid, n;
            case M.SET_LOADING:
                return n.isLoading = t.isLoading, n;
            case M.SET_CHECKBOX_AND_CONTINUE_BUTTON_STATE:
                return n.isContinueButtonEnabled = t.isContinueButtonEnabled, n.isCheckboxEnabled = t.isCheckboxEnabled, n;
            case M.SET_ERROR:
                return n.errorMessage = t.errorMessage, n;
            case M.CLOSE_MODAL:
                return n.isModalOpen = !1, n;
            default:
                return e
        }
    }

    function g(e) {
        var t = e.children,
            e = (n = (0, A.useReducer)(r, c))[0],
            n = n[1];
        return R().createElement(l.Provider, {
            value: {
                state: e,
                dispatch: n
            }
        }, t)
    }

    function C(e) {
        return new RegExp("^\\w+([-+.]\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*$").test(e)
    }

    function Z(e) {
        var t = e.ctx,
            n = e.field,
            o = e.origin,
            i = e.entered,
            r = e.state;
        (e = {}).field = n, i && (e.entered = i), r && (e.state = r), o && (e.origin = o), se.eventStreamService.sendEventWithTarget(le.schematizedEventTypes.authFormInteraction, t, e)
    }

    function a(e) {
        var t;
        return ((t = {})[le.context.validateOTP] = le.context.schematizedEnterOTP, t[le.context.enterOTP] = le.context.schematizedEnterOTP, t[le.context.sendOTP] = le.context.schematizedSendOTP, t)[e] || e
    }

    function ee(e) {
        var t = e.ctx,
            n = e.field,
            o = e.btn,
            i = e.aType,
            r = e.errorCode,
            a = e.origin;
        (e = {}).field = n, o && (e.btn = o), i && (e.aType = i), r && (e.errorCode = r), a && (e.origin = a), se.eventStreamService.sendEventWithTarget(ue.formInteraction, t, e)
    }

    function te(e, t, n) {
        ee({
            ctx: e,
            field: le.field.errorMessage,
            aType: le.aType.shown,
            errorCode: t,
            origin: n
        }), se.eventStreamService.sendEventWithTarget(le.schematizedEventTypes.authMsgShown, a(e), {
            field: e === le.context.enterOTP ? le.field.resendErrorMessage : le.field.errorMessage,
            errorCode: t,
            origin: n
        })
    }

    function ne(e, t, n) {
        se.eventStreamService.sendEventWithTarget(ue.buttonClick, e, {
            btn: t,
            origin: n
        }), se.eventStreamService.sendEventWithTarget(le.schematizedEventTypes.authButtonClick, a(e), {
            btn: t,
            origin: n
        })
    }

    function oe(e, t, n) {
        se.eventStreamService.sendEventWithTarget(ue.modalAction, e, {
            aType: t,
            origin: n
        })
    }

    function ie(e, t) {
        se.eventStreamService.sendEventWithTarget(le.schematizedEventTypes.authPageLoad, a(e), {
            origin: t
        })
    }

    function re(e) {
        var t = e.id,
            n = e.legalText,
            o = void 0 !== (i = e.isChecked) && i,
            i = void 0 !== (i = e.disabled) && i,
            e = e.onCheckBoxChanged;
        return R().createElement("div", {
            className: "legal-text-container"
        }, R().createElement("div", {
            className: "terms-agreement terms-agreement-checkbox"
        }, R().createElement("input", {
            id: t,
            className: "checkbox",
            type: "checkbox",
            checked: o,
            onChange: e,
            disabled: i
        }), R().createElement("label", {
            htmlFor: t,
            dangerouslySetInnerHTML: {
                __html: n
            }
        })))
    }

    function ae(e) {
        return t.EnvironmentUrls.apiGatewayUrl + "/otp-service/v1/" + e
    }(n = M = M || {})[n.SET_ENTER_EMAIL_PAGE = 0] = "SET_ENTER_EMAIL_PAGE", n[n.SET_ENTER_CODE_PAGE = 1] = "SET_ENTER_CODE_PAGE", n[n.SET_EMAIL = 2] = "SET_EMAIL", n[n.SET_SESSION_TOKEN = 3] = "SET_SESSION_TOKEN", n[n.SET_OTP_CODE = 4] = "SET_OTP_CODE", n[n.SET_LEGAL_CHECK = 5] = "SET_LEGAL_CHECK", n[n.SET_CODE_VALID = 6] = "SET_CODE_VALID", n[n.SET_LOADING = 7] = "SET_LOADING", n[n.SET_CHECKBOX_AND_CONTINUE_BUTTON_STATE = 8] = "SET_CHECKBOX_AND_CONTINUE_BUTTON_STATE", n[n.SET_ERROR = 9] = "SET_ERROR", n[n.CLOSE_MODAL = 10] = "CLOSE_MODAL";
    var c = {
            emailVerifyCodeModalPage: I,
            email: "",
            sessionToken: "",
            code: "",
            isChecked: !1,
            isCheckboxEnabled: !1,
            isLoading: !1,
            isCodeValid: !1,
            isContinueButtonEnabled: !1,
            errorMessage: "",
            isModalOpen: !0
        },
        l = (0, A.createContext)(null),
        ce = function() {
            var e = (0, A.useContext)(l);
            if (null === e) throw new Error("EmailVerifyCodeModalContext was not provided in the current scope");
            return e
        },
        n = {
            common: ["Common.Captcha"],
            feature: "Authentication.Login"
        },
        le = {
            schematizedEventTypes: {
                authFormInteraction: "authFormInteraction",
                authButtonClick: "authButtonClick",
                authMsgShown: "authMsgShown",
                authPageLoad: "authPageload",
                authModalShown: "authModalShown",
                authClientError: "authClientError",
                usernameSuggestionShown: "usernameSuggestionShown"
            },
            eventName: {
                loginOtherDevice: "loginOtherDevice",
                formValidation: "formValidation",
                authPageLoad: "authPageload",
                authFormInteraction: "authFormInteraction",
                authButtonClick: "authButtonClick"
            },
            context: {
                loginPage: "loginPage",
                loginForm: "LoginForm",
                schematizedLoginForm: "loginForm",
                landingPage: "Multiverse",
                signupForm: "MultiverseSignupForm",
                sendOTP: "sendOTP",
                schematizedSendOTP: "sendOtp",
                enterOTP: "enterOTP",
                schematizedEnterOTP: "enterOtp",
                validateOTP: "validateOTP",
                disambiguationOTP: "disambiguationOTP",
                disambiguationEmail: "disambiguationEmail",
                disambiguationPhone: "disambiguationPhone",
                disambigOTP: "disambigOtp",
                revertAccount: "revertAccount",
                finishParentalSignup: "finishParentalSignup",
                accountSwitcherConfirmation: "accountSwitcherConfirmation",
                accountSwitcherModal: "accountSwitcherModal",
                accountSwitcherLimitError: "accountSwitcherLimitError",
                accountSwitcherLogin: "accountSwitcherLogin",
                accountSwitcherSignup: "accountSwitcherSignup",
                accountSwitcherBackendRequestFailure: "accountSwitcherBackendRequestFailure",
                accountSwitcherLocalStorageFailure: "accountSwitcherLocalStorageFailure",
                accountSwitcherVpcLogin: "accountSwitcherVpcLogin",
                accountSwitcherVpcSignup: "accountSwitcherVpcSignup"
            },
            aType: {
                buttonClick: "buttonClick",
                click: "click",
                offFocus: "offFocus",
                focus: "focus",
                shown: "shown",
                dismissed: "dismissed"
            },
            field: {
                loginOtherDevice: "loginOtherDevice",
                loginOTP: "loginOTP",
                OTP: "otp",
                loginSubmitButtonName: "loginSubmit",
                password: "password",
                username: "username",
                signupSubmitButtonName: "signupSubmit",
                appButtonClickName: "AppLink",
                showPassword: "showPassword",
                hidePassword: "hidePassword",
                birthdayDay: "birthdayDay",
                birthdayMonth: "birthdayMonth",
                birthdayYear: "birthdayYear",
                signupUsername: "signupUsername",
                signupPassword: "signupPassword",
                signupEmail: "signupEmail",
                parentEmail: "parentEmail",
                genderMale: "genderMale",
                genderFemale: "genderFemale",
                email: "email",
                code: "code",
                otpCode: "OTPcode",
                errorMessage: "errorMessage",
                resendErrorMessage: "resendErrorMessage",
                accountSelection: "accountSelection",
                checked: "checked",
                unchecked: "unchecked",
                usernameValid: "usernameValid",
                revertAccountSubmitButtonName: "revertAccountSubmit",
                birthday: "birthday",
                accountSwitcher: "accountSwitcher"
            },
            btn: {
                cancel: "cancel",
                sendCode: "sendCode",
                resendCode: "resendCode",
                resend: "resend",
                login: "login",
                logoutAll: "logoutAll",
                signup: "signup",
                continue: "continue",
                changeEmail: "changeEmail",
                select: "select",
                parentalConsentCheckbox: "pc_checkbox",
                termsOfServiceCheckbox: "tos_checkbox",
                privacyPolicyCheckbox: "pp_checkbox",
                submitRevertAccount: "submitRevertAccount",
                dismiss: "dismiss",
                switch: "switch",
                addAccount: "addAccount",
                primaryButton: "primaryButton",
                secondaryButton: "secondaryButton",
                usernameSuggestion: "usernameSuggestion"
            },
            input: {
                redacted: "[Redacted]"
            },
            origin: {
                webVerifiedSignup: "WebVerifiedSignup",
                signup: "signup",
                login: "login"
            },
            text: {
                finishCreatingYourAccount: "Finish Creating Your Account",
                signup: "Sign Up"
            },
            clientErrorTypes: {
                userInfoFetchFailed: "userInfoFetchFailed",
                localStorageSetFailure: "localStorageSetFailure",
                localStorageGetFailure: "localStorageGetFailure",
                localStorageRemoveFailure: "localStorageRemoveFailure",
                logoutAllAccountSwitcherAccounts: "logoutAllAccountSwitcherAccounts"
            }
        },
        se = CoreRobloxUtilities,
        ue = se.eventStreamService.eventTypes,
        de = (0, D.withTranslations)(function(e) {
            function t() {
                m(!0), ne(g, le.btn.sendCode, n), r()
            }
            var n = e.origin,
                o = e.titleText,
                i = e.descriptionText,
                r = e.onSendCode,
                a = e.errorMessage,
                c = e.onClose,
                l = e.translate,
                e = ce(),
                s = e.state.email,
                u = e.dispatch,
                e = (0, A.useState)(!0),
                d = e[0],
                E = e[1],
                e = (0, A.useState)(!1),
                h = e[0],
                m = e[1],
                g = le.context.sendOTP,
                p = (0, D.useDebounce)(s, 200);
            (0, A.useEffect)(function() {
                var e;
                d && 0 < s.length && (E(!1), e = n, ee({
                    ctx: le.context.sendOTP,
                    field: le.field.email,
                    origin: e
                }), Z({
                    ctx: le.context.schematizedSendOTP,
                    field: le.field.email,
                    origin: e
                })), !C(p) && 0 < p.length ? u({
                    type: M.SET_ERROR,
                    errorMessage: l(S)
                }) : u({
                    type: M.SET_ERROR,
                    errorMessage: ""
                })
            }, [p]), (0, A.useEffect)(function() {
                a && m(!1)
            }, [a]);
            return (0, A.useEffect)(function() {
                oe(g, le.aType.shown, n), ie(g, n)
            }, []), R().createElement(A.Fragment, null, R().createElement(N.Modal.Header, {
                title: o,
                onClose: function() {
                    ne(g, le.btn.cancel, n), oe(g, le.aType.dismissed, n), c()
                }
            }), R().createElement(N.Modal.Body, null, R().createElement("p", {
                className: "email-verify-code-help-text"
            }, i), R().createElement("input", {
                placeholder: l(f),
                onChange: function(e) {
                    return e = e.target.value, void u({
                        type: M.SET_EMAIL,
                        email: e
                    })
                },
                type: "email",
                autoFocus: !0,
                className: "form-control input-field email-verify-code-input",
                autoComplete: "email",
                maxLength: 320,
                onKeyPress: function(e) {
                    "Enter" === e.key && C(s) && !h && t()
                },
                value: s
            }), R().createElement("p", {
                className: "text-error input-validation email-verify-code-error-text"
            }, a), R().createElement(N.Button, {
                className: "email-verify-code-button",
                variant: N.Button.variants.secondary,
                isDisabled: h || !C(s),
                onClick: t
            }, l(T))))
        }, n),
        Ee = (0, D.withTranslations)(function(e) {
            function t() {
                var t;
                y(!1), 0 === O && (t = setInterval(function() {
                    _(function(e) {
                        return 1 === e && (clearInterval(t), y(!0)), e - 1
                    })
                }, 1e3)), _(30)
            }

            function n() {
                ne(k, le.btn.resendCode, i), h(), t()
            }

            function o(e) {
                var t, n, o;
                v({
                    type: M.SET_LEGAL_CHECK,
                    isChecked: e.target.checked
                }), t = k, n = le.btn.parentalConsentCheckbox, o = e.target.checked, e = i, se.eventStreamService.sendEventWithTarget(ue.buttonClick, t, {
                    btn: n,
                    field: o ? le.field.checked : le.field.unchecked,
                    origin: e
                })
            }
            var i = e.origin,
                r = e.titleText,
                a = e.descriptionText,
                c = e.legalCheckboxLabel,
                l = e.code,
                s = e.codeLength,
                u = e.isCheckboxEnabled,
                d = e.isContinueButtonEnabled,
                E = e.onContinueButtonPressed,
                h = e.onResendCode,
                m = e.onClose,
                g = e.translate,
                p = e.isChangeEmailEnabled,
                f = ce(),
                S = f.state,
                e = S.email,
                T = S.isChecked,
                C = S.isLoading,
                S = S.errorMessage,
                v = f.dispatch,
                f = (0, A.useState)(!0),
                b = f[0],
                y = f[1],
                f = (0, A.useState)(0),
                O = f[0],
                _ = f[1],
                f = (0, A.useState)(!0),
                w = f[0],
                x = f[1],
                f = (0, D.useDebounce)(l, 200),
                k = le.context.enterOTP;
            (0, A.useEffect)(function() {
                var e;
                w && 0 < l.length && (x(!1), e = i, ee({
                    ctx: le.context.enterOTP,
                    field: le.field.otpCode,
                    origin: e
                }), Z({
                    ctx: le.context.schematizedEnterOTP,
                    field: le.field.code,
                    origin: e
                }))
            }, [f]);
            e = R().createElement("div", {
                className: "email-verify-code-help-text",
                dangerouslySetInnerHTML: {
                    __html: "<p className='email-verify-code-help-text'>" + g(U, {
                        email: "<b>" + e + "</b>"
                    }) + "</p>"
                }
            });
            return (0, A.useEffect)(function() {
                oe(k, le.aType.shown, i), ie(k, i), t()
            }, []), R().createElement(A.Fragment, null, R().createElement(N.Modal.Header, {
                title: r,
                onClose: function() {
                    ne(k, le.btn.cancel, i), oe(k, le.aType.dismissed, i), m()
                }
            }), R().createElement(N.Modal.Body, null, p ? R().createElement(A.Fragment, null, e, R().createElement("div", {
                className: "email-verify-code-email-display"
            }, R().createElement("button", {
                className: "email-verify-code-change-email-link text-link",
                type: "button",
                onClick: function() {
                    v({
                        type: M.SET_ENTER_EMAIL_PAGE
                    }), ne(k, le.btn.changeEmail, i)
                }
            }, g(G)))) : R().createElement("p", {
                className: "email-verify-code-help-text"
            }, a), R().createElement("input", {
                placeholder: g(P),
                onChange: function(e) {
                    return function(e) {
                        v({
                            type: M.SET_ERROR,
                            errorMessage: ""
                        });
                        e = e.replace(/\D/g, "");
                        v({
                            type: M.SET_OTP_CODE,
                            code: e
                        })
                    }(e.target.value)
                },
                type: "text",
                inputMode: "numeric",
                maxLength: s,
                autoFocus: !0,
                className: "form-control input-field email-verify-code-input",
                value: l,
                disabled: C
            }), R().createElement("p", {
                className: "text-error email-verify-code-error-text"
            }, S), R().createElement(function() {
                return c ? R().createElement("div", {
                    className: "legal-checkbox-container"
                }, R().createElement(re, {
                    id: "parent-consent",
                    legalText: c,
                    isChecked: T,
                    disabled: !u,
                    onCheckBoxChanged: o
                })) : null
            }, null), R().createElement(function() {
                return c ? R().createElement(N.Button, {
                    className: "email-verify-code-button",
                    variant: N.Button.variants.primary,
                    onClick: E,
                    isDisabled: !d
                }, g(V)) : null
            }, null), R().createElement(function() {
                return C ? R().createElement(N.Loading, null) : R().createElement(N.Button, {
                    className: "email-verify-code-button",
                    variant: N.Button.variants.secondary,
                    onClick: n,
                    isDisabled: !b
                }, b ? g(F) : g(L) + " (" + O + ")")
            }, null), R().createElement(function() {
                return c ? null : R().createElement("div", {
                    className: "font-caption-header email-verify-code-help-link"
                }, R().createElement("a", {
                    className: "text-link",
                    href: "https://en.help.roblox.com/hc/articles/11014749736980",
                    target: "_blank",
                    rel: "noreferrer"
                }, g(z)))
            }, null)))
        }, {
            common: [],
            feature: "Authentication.OneTimePasscode"
        }),
        he = CoreUtilities,
        me = function(e, a, c, l) {
            return new(c = c || Promise)(function(n, t) {
                function o(e) {
                    try {
                        r(l.next(e))
                    } catch (e) {
                        t(e)
                    }
                }

                function i(e) {
                    try {
                        r(l.throw(e))
                    } catch (e) {
                        t(e)
                    }
                }

                function r(e) {
                    var t;
                    e.done ? n(e.value) : ((t = e.value) instanceof c ? t : new c(function(e) {
                        e(t)
                    })).then(o, i)
                }
                r((l = l.apply(e, a || [])).next())
            })
        },
        ge = function(n, o) {
            var i, r, a, c = {
                    label: 0,
                    sent: function() {
                        if (1 & a[0]) throw a[1];
                        return a[1]
                    },
                    trys: [],
                    ops: []
                },
                e = {
                    next: t(0),
                    throw: t(1),
                    return: t(2)
                };
            return "function" == typeof Symbol && (e[Symbol.iterator] = function() {
                return this
            }), e;

            function t(t) {
                return function(e) {
                    return function(t) {
                        if (i) throw new TypeError("Generator is already executing.");
                        for (; c;) try {
                            if (i = 1, r && (a = 2 & t[0] ? r.return : t[0] ? r.throw || ((a = r.return) && a.call(r), 0) : r.next) && !(a = a.call(r, t[1])).done) return a;
                            switch (r = 0, a && (t = [2 & t[0], a.value]), t[0]) {
                                case 0:
                                case 1:
                                    a = t;
                                    break;
                                case 4:
                                    return c.label++, {
                                        value: t[1],
                                        done: !1
                                    };
                                case 5:
                                    c.label++, r = t[1], t = [0];
                                    continue;
                                case 7:
                                    t = c.ops.pop(), c.trys.pop();
                                    continue;
                                default:
                                    if (!(a = 0 < (a = c.trys).length && a[a.length - 1]) && (6 === t[0] || 2 === t[0])) {
                                        c = 0;
                                        continue
                                    }
                                    if (3 === t[0] && (!a || t[1] > a[0] && t[1] < a[3])) {
                                        c.label = t[1];
                                        break
                                    }
                                    if (6 === t[0] && c.label < a[1]) {
                                        c.label = a[1], a = t;
                                        break
                                    }
                                    if (a && c.label < a[2]) {
                                        c.label = a[2], c.ops.push(t);
                                        break
                                    }
                                    a[2] && c.ops.pop(), c.trys.pop();
                                    continue
                            }
                            t = o.call(n, c)
                        } catch (e) {
                            t = [6, e], r = 0
                        } finally {
                            i = a = 0
                        }
                        if (5 & t[0]) throw t[1];
                        return {
                            value: t[0] ? t[1] : void 0,
                            done: !0
                        }
                    }([t, e])
                }
            }
        },
        pe = function(e, a, c, l) {
            return new(c = c || Promise)(function(n, t) {
                function o(e) {
                    try {
                        r(l.next(e))
                    } catch (e) {
                        t(e)
                    }
                }

                function i(e) {
                    try {
                        r(l.throw(e))
                    } catch (e) {
                        t(e)
                    }
                }

                function r(e) {
                    var t;
                    e.done ? n(e.value) : ((t = e.value) instanceof c ? t : new c(function(e) {
                        e(t)
                    })).then(o, i)
                }
                r((l = l.apply(e, a || [])).next())
            })
        },
        fe = function(n, o) {
            var i, r, a, c = {
                    label: 0,
                    sent: function() {
                        if (1 & a[0]) throw a[1];
                        return a[1]
                    },
                    trys: [],
                    ops: []
                },
                e = {
                    next: t(0),
                    throw: t(1),
                    return: t(2)
                };
            return "function" == typeof Symbol && (e[Symbol.iterator] = function() {
                return this
            }), e;

            function t(t) {
                return function(e) {
                    return function(t) {
                        if (i) throw new TypeError("Generator is already executing.");
                        for (; c;) try {
                            if (i = 1, r && (a = 2 & t[0] ? r.return : t[0] ? r.throw || ((a = r.return) && a.call(r), 0) : r.next) && !(a = a.call(r, t[1])).done) return a;
                            switch (r = 0, a && (t = [2 & t[0], a.value]), t[0]) {
                                case 0:
                                case 1:
                                    a = t;
                                    break;
                                case 4:
                                    return c.label++, {
                                        value: t[1],
                                        done: !1
                                    };
                                case 5:
                                    c.label++, r = t[1], t = [0];
                                    continue;
                                case 7:
                                    t = c.ops.pop(), c.trys.pop();
                                    continue;
                                default:
                                    if (!(a = 0 < (a = c.trys).length && a[a.length - 1]) && (6 === t[0] || 2 === t[0])) {
                                        c = 0;
                                        continue
                                    }
                                    if (3 === t[0] && (!a || t[1] > a[0] && t[1] < a[3])) {
                                        c.label = t[1];
                                        break
                                    }
                                    if (6 === t[0] && c.label < a[1]) {
                                        c.label = a[1], a = t;
                                        break
                                    }
                                    if (a && c.label < a[2]) {
                                        c.label = a[2], c.ops.push(t);
                                        break
                                    }
                                    a[2] && c.ops.pop(), c.trys.pop();
                                    continue
                            }
                            t = o.call(n, c)
                        } catch (e) {
                            t = [6, e], r = 0
                        } finally {
                            i = a = 0
                        }
                        if (5 & t[0]) throw t[1];
                        return {
                            value: t[0] ? t[1] : void 0,
                            done: !0
                        }
                    }([t, e])
                }
            }
        },
        p = (0, D.withTranslations)(function(e) {
            e.containerId;
            var t = e.codeLength,
                n = e.onEmailCodeEntered,
                o = e.onComplete,
                i = e.onModalAbandoned,
                r = e.enterEmailTitle,
                a = e.enterEmailDescription,
                c = e.enterCodeTitle,
                l = e.enterCodeDescription,
                s = e.legalCheckboxLabel,
                u = e.origin,
                d = e.translate,
                E = e.isChangeEmailEnabled,
                h = void 0 !== E && E,
                m = ce(),
                g = m.state,
                p = g.emailVerifyCodeModalPage,
                f = g.email,
                S = g.sessionToken,
                T = g.code,
                C = g.isChecked,
                v = g.isCheckboxEnabled,
                b = g.isLoading,
                y = g.isCodeValid,
                e = g.errorMessage,
                E = g.isModalOpen,
                O = g.isContinueButtonEnabled,
                _ = m.dispatch,
                w = (0, D.useDebounce)(T, 200);
            (0, A.useEffect)(function() {
                n && !s && w.length === t ? (L(), _({
                    type: M.SET_LOADING,
                    isLoading: !0
                }), ne(le.context.enterOTP, le.btn.login, u)) : s && _({
                    type: M.SET_CHECKBOX_AND_CONTINUE_BUTTON_STATE,
                    isContinueButtonEnabled: w.length === t && C,
                    isCheckboxEnabled: w.length === t
                })
            }, [w, C]), (0, A.useEffect)(function() {
                s && o && y ? (_({
                    type: M.CLOSE_MODAL
                }), oe(le.context.enterOTP, le.aType.dismissed, u), ne(le.context.enterOTP, le.btn.signup, u), o({
                    otpSessionToken: S,
                    otpContactType: Q
                })) : n && n(S, w)
            }, [y]), (0, A.useEffect)(function() {
                function e(e) {
                    if (e.detail) {
                        if (e.detail.shouldCloseModal) return void k();
                        _({
                            type: M.SET_ERROR,
                            errorMessage: e.detail.errorMessage
                        })
                    }
                    _({
                        type: M.SET_OTP_CODE,
                        code: ""
                    }), _({
                        type: M.SET_LOADING,
                        isLoading: !1
                    })
                }
                return window.addEventListener("onEnterEmailVerifyCodeError", e),
                    function() {
                        window.removeEventListener("onEnterEmailVerifyCodeError", e)
                    }
            }, []), (0, A.useEffect)(function() {
                window.addEventListener("closeEmailVerifyCodeModal", k)
            }, []);

            function x(e, t) {
                var n = e.data,
                    e = e.status;
                return _({
                    type: M.SET_LOADING,
                    isLoading: !1
                }), n === Y ? (_({
                    type: M.SET_ERROR,
                    errorMessage: d(H)
                }), void te(t, String(n), u)) : n === q ? (_({
                    type: M.SET_ERROR,
                    errorMessage: d(K)
                }), void te(t, String(n), u)) : n === $ ? (_({
                    type: M.SET_ERROR,
                    errorMessage: d(j)
                }), void te(t, String(n), u)) : e === J ? (_({
                    type: M.SET_ERROR,
                    errorMessage: d(H)
                }), void te(t, String(e), u)) : n === X ? (te(t, String(n), u), void P()) : (te(t, String(n), u), void _({
                    type: M.SET_ERROR,
                    errorMessage: d(W)
                }))
            }
            var k = function() {
                    i(), _({
                        type: M.CLOSE_MODAL
                    })
                },
                P = function() {
                    return pe(void 0, void 0, void 0, function() {
                        var t;
                        return fe(this, function(e) {
                            switch (e.label) {
                                case 0:
                                    return e.trys.push([0, 2, , 3]), [4, (n = {
                                        origin: u,
                                        contactType: Q,
                                        contactValue: f
                                    }, me(void 0, void 0, Promise, function() {
                                        var t;
                                        return ge(this, function(e) {
                                            switch (e.label) {
                                                case 0:
                                                    return t = ae("sendCode"), t = {
                                                        url: t,
                                                        withCredentials: !0
                                                    }, [4, he.httpService.post(t, n)];
                                                case 1:
                                                    return [2, e.sent().data]
                                            }
                                        })
                                    }))];
                                case 1:
                                    return t = e.sent(), _({
                                        type: M.SET_SESSION_TOKEN,
                                        sessionToken: null !== (t = null == t ? void 0 : t.otpSessionToken) && void 0 !== t ? t : ""
                                    }), _({
                                        type: M.SET_ERROR,
                                        errorMessage: ""
                                    }), _({
                                        type: M.SET_ENTER_CODE_PAGE
                                    }), [3, 3];
                                case 2:
                                    return t = e.sent(), x(t, le.context.sendOTP), [3, 3];
                                case 3:
                                    return [2]
                            }
                            var n
                        })
                    })
                },
                L = function() {
                    return pe(void 0, void 0, void 0, function() {
                        var t;
                        return fe(this, function(e) {
                            switch (e.label) {
                                case 0:
                                    return e.trys.push([0, 2, , 3]), [4, (n = {
                                        passCode: w,
                                        otpSessionToken: S,
                                        contactType: Q,
                                        origin: u
                                    }, me(void 0, void 0, Promise, function() {
                                        var t;
                                        return ge(this, function(e) {
                                            switch (e.label) {
                                                case 0:
                                                    return t = ae("validateCode"), t = {
                                                        url: t,
                                                        withCredentials: !0
                                                    }, [4, he.httpService.post(t, n)];
                                                case 1:
                                                    return [2, e.sent().data]
                                            }
                                        })
                                    }))];
                                case 1:
                                    return e.sent(), _({
                                        type: M.SET_CODE_VALID,
                                        isCodeValid: !0
                                    }), [3, 3];
                                case 2:
                                    return t = e.sent(), x(t, le.context.validateOTP), [3, 3];
                                case 3:
                                    return [2]
                            }
                            var n
                        })
                    })
                };
            return R().createElement(N.Modal, {
                className: "email-verify-code-modal",
                show: E,
                size: "lg",
                backdrop: "static",
                onHide: k
            }, R().createElement(A.Fragment, null, p === I && R().createElement(de, {
                origin: u,
                titleText: r,
                descriptionText: a,
                onSendCode: P,
                errorMessage: e,
                onClose: k,
                translate: d
            }), p === B && S && R().createElement(Ee, {
                origin: u,
                titleText: c,
                descriptionText: l,
                legalCheckboxLabel: s,
                code: T,
                codeLength: t,
                onContinueButtonPressed: function() {
                    O && (ne(le.context.enterOTP, le.btn.continue, u), L())
                },
                onResendCode: function() {
                    return pe(void 0, void 0, void 0, function() {
                        var t;
                        return fe(this, function(e) {
                            switch (e.label) {
                                case 0:
                                    return e.trys.push([0, 2, , 3]), [4, (n = {
                                        contactType: Q,
                                        origin: u,
                                        otpSessionToken: S
                                    }, me(void 0, void 0, Promise, function() {
                                        var t;
                                        return ge(this, function(e) {
                                            switch (e.label) {
                                                case 0:
                                                    return t = ae("resendCode"), t = {
                                                        url: t,
                                                        withCredentials: !0
                                                    }, [4, he.httpService.post(t, n)];
                                                case 1:
                                                    return [2, e.sent().data]
                                            }
                                        })
                                    }))];
                                case 1:
                                    return t = e.sent(), _({
                                        type: M.SET_SESSION_TOKEN,
                                        sessionToken: null !== (t = null == t ? void 0 : t.otpSessionToken) && void 0 !== t ? t : ""
                                    }), _({
                                        type: M.SET_ERROR,
                                        errorMessage: ""
                                    }), [3, 3];
                                case 2:
                                    return t = e.sent(), x(t, le.context.enterOTP), [3, 3];
                                case 3:
                                    return [2]
                            }
                            var n
                        })
                    })
                },
                isLoading: b,
                isContinueButtonEnabled: O,
                isCheckboxEnabled: v,
                isChecked: C,
                errorMessage: e,
                onClose: k,
                translate: d,
                isChangeEmailEnabled: h
            })))
        }, n),
        n = {
            renderEmailVerifyCodeModal: n = function(e) {
                var t = e.containerId,
                    n = e.codeLength,
                    o = e.onEmailCodeEntered,
                    i = e.onComplete,
                    r = e.onModalAbandoned,
                    a = e.enterEmailTitle,
                    c = e.enterEmailDescription,
                    l = e.enterCodeTitle,
                    s = e.enterCodeDescription,
                    u = e.legalCheckboxLabel,
                    d = e.origin,
                    E = e.translate,
                    h = e.isChangeEmailEnabled,
                    e = document.getElementById(t);
                return null != e && ((0, m.unmountComponentAtNode)(e), (0, m.render)(R().createElement(g, null, R().createElement(p, {
                    containerId: t,
                    codeLength: n,
                    onEmailCodeEntered: o,
                    onModalAbandoned: r,
                    legalCheckboxLabel: u,
                    onComplete: i,
                    enterEmailTitle: a,
                    enterEmailDescription: c,
                    enterCodeTitle: l,
                    enterCodeDescription: s,
                    origin: d,
                    translate: E,
                    isChangeEmailEnabled: h
                })), e), !0)
            }
        };
    Object.assign(e(), {
        EmailVerifyCodeModalService: n
    })
}();
//# sourceMappingURL=https://js.rbxcdn.com/4e637e1fa5fa00862a6a859a38944e82-emailVerifyCodeModal.bundle.min.js.map

/* Bundle detector */
window.Roblox && window.Roblox.BundleDetector && window.Roblox.BundleDetector.bundleDetected("EmailVerifyCodeModal");