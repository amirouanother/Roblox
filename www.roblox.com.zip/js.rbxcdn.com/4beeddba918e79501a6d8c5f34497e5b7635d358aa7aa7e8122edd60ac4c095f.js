! function() {
    var n = {
            779: function(e, t) {
                var n;
                /*!
                	Copyright (c) 2018 Jed Watson.
                	Licensed under the MIT License (MIT), see
                	http://jedwatson.github.io/classnames
                */
                ! function() {
                    "use strict";
                    var i = {}.hasOwnProperty;

                    function c() {
                        for (var e = [], t = 0; t < arguments.length; t++) {
                            var n = arguments[t];
                            if (n) {
                                var r, a = typeof n;
                                if ("string" == a || "number" == a) e.push(n);
                                else if (Array.isArray(n)) !n.length || (r = c.apply(null, n)) && e.push(r);
                                else if ("object" == a)
                                    if (n.toString === Object.prototype.toString || n.toString.toString().includes("[native code]"))
                                        for (var o in n) i.call(n, o) && n[o] && e.push(o);
                                    else e.push(n.toString())
                            }
                        }
                        return e.join(" ")
                    }
                    e.exports ? (c.default = c, e.exports = c) : void 0 === (n = function() {
                        return c
                    }.apply(t, [])) || (e.exports = n)
                }()
            },
            226: function(e) {
                e.exports = 'module.exports = __webpack_public_path__ + "../html/navigation.html";'
            },
            937: function(e) {
                e.exports = "https://images.rbxcdn.com/a7676f02feaa6a5d1e61145284cfaf51-PlatformEventLeftNav_DE.jpg"
            },
            371: function(e) {
                e.exports = "https://images.rbxcdn.com/c343f87e315da7537604e45fe3e50d23-PlatformEventLeftNav_EN.jpg"
            },
            417: function(e) {
                e.exports = "https://images.rbxcdn.com/df2840b964a7abdac43d60bad14d08c1-PlatformEventLeftNav_JP.jpg"
            },
            223: function(e) {
                e.exports = "https://images.rbxcdn.com/e8ee786f6114cc331fe764c3d54bf3e0-PlatformEventLeftNav_PL.jpg"
            },
            359: function(e) {
                e.exports = "https://images.rbxcdn.com/a10a28689f8f0f4c81b3ac587e75e95d-PlatformEventLeftNav_PTBR.jpg"
            },
            729: function(e) {
                e.exports = "https://images.rbxcdn.com/13d17e598fae835c902625dbe9d11b5e-PlatformEventLeftNav_TR.jpg"
            },
            927: function(e) {
                e.exports = "https://images.rbxcdn.com/629771246ef6e5476948449efba846a6-PlatformEventLeftNav_VN.jpg"
            }
        },
        r = {};

    function ko(e) {
        if (r[e]) return r[e].exports;
        var t = r[e] = {
            exports: {}
        };
        return n[e](t, t.exports, ko), t.exports
    }
    ko.n = function(e) {
            var t = e && e.__esModule ? function() {
                return e.default
            } : function() {
                return e
            };
            return ko.d(t, {
                a: t
            }), t
        }, ko.d = function(e, t) {
            for (var n in t) ko.o(t, n) && !ko.o(e, n) && Object.defineProperty(e, n, {
                enumerable: !0,
                get: t[n]
            })
        }, ko.o = function(e, t) {
            return Object.prototype.hasOwnProperty.call(e, t)
        },
        function() {
            "use strict";
            var L = React,
                j = ko.n(L),
                D = CoreUtilities,
                e = ReactDOM,
                M = Roblox,
                t = ko.n(M),
                k = HeaderScripts,
                _ = ReactUtilities,
                q = {
                    arrowUp: 38,
                    arrowDown: 40,
                    tab: 9,
                    enter: 13
                },
                n = "container-main",
                r = {
                    name: "Roblox.Logout"
                },
                a = 1,
                o = {
                    clickMerchandise: "clickMerchandiseInLeftNav",
                    goToAmazonStore: "clickContinueToAmazonStore"
                },
                i = {
                    friendshipNotifications: "FriendshipNotifications",
                    requestCountChanged: "Roblox.Friends.CountChanged",
                    friendshipCreated: "FriendshipCreated",
                    friendshipDestroyed: "FriendshipDestroyed",
                    friendshipDeclined: "FriendshipDeclined",
                    friendshipRequested: "FriendshipRequested"
                },
                c = {
                    name: "Roblox.Messages.CountChanged"
                },
                g = "?",
                P = "Response.InternalServerErrorDescription",
                u = {
                    name: "headerMenuIconClick"
                },
                l = {
                    quickLogin: "quickLogin",
                    logout: "logout",
                    settings: "settings",
                    switchAccountKey: "switchAccountKey"
                },
                h = {
                    robuxTruncateThreshold: 1e4,
                    creditTruncateThreshold: 1e4
                },
                U = {
                    control: "control",
                    hideCreditAndRobux: "hideCreditAndRobux",
                    showCreditAndRobux: "showCreditAndRobux"
                },
                B = {
                    accountSwitchedFlag: "RBXASAccountSwitched",
                    accountSwitchedMessage: "Description.AccountSwitchedConfirmationBannerText"
                },
                s = {
                    common: ["CommonUI.Features", "CommonUI.Messages", "Common.AlertsAndOptions", "Common.Presence"],
                    feature: "Feature.ShopDialog"
                },
                f = PropTypes,
                d = ko.n(f),
                m = ko(779),
                x = ko.n(m),
                A = ReactStyleGuide,
                p = RobloxThumbnails,
                v = RobloxBadges,
                b = function(e, t) {
                    for (var n = 0, r = t.length, a = e.length; n < r; n++, a++) e[a] = t[n];
                    return e
                },
                y = M.Endpoints.getAbsoluteUrl,
                S = M.EnvironmentUrls.authApi,
                E = {
                    url: y("/discover/?Keyword="),
                    label: "Label.Experience",
                    pageSort: ["home", "games", "discover"],
                    icon: "icon-menu-games-off"
                },
                w = {
                    url: y("/catalog?CatalogContext=1&Keyword="),
                    label: "Heading.Marketplace",
                    pageSort: ["catalog", "inventory", "bundles", "my/avatar", "trades"],
                    icon: "icon-menu-shop"
                },
                C = [{
                    url: y("/search/users?keyword="),
                    label: "Label.Players",
                    pageSort: ["users"],
                    icon: "icon-menu-profile"
                }, w, {
                    url: y("/search/groups?keyword="),
                    label: "Label.sGroups",
                    pageSort: ["groups"],
                    icon: "icon-menu-groups"
                }, {
                    url: y("/develop/library?CatalogContext=2&Category=6&Keyword="),
                    label: "Label.CreatorMarketplace",
                    pageSort: ["develop"],
                    icon: "icon-menu-library"
                }],
                F = {
                    creatorMarketplaceUrl: "https://create." + M.EnvironmentUrls.domain + "/marketplace/models?keyword=",
                    scrollListItems: {
                        home: {
                            url: y("/"),
                            idSelector: "nav-home",
                            iconClass: "icon-nav-home",
                            name: "home",
                            labelTranslationKey: "Label.sHome"
                        },
                        profile: {
                            url: y("/users/" + k.authenticatedUser.id + "/profile"),
                            idSelector: "nav-profile",
                            iconClass: "icon-nav-profile",
                            name: "profile",
                            labelTranslationKey: "Label.sProfile"
                        },
                        messages: {
                            url: y("/my/messages/#!/inbox"),
                            urlForNotification: y("/my/messages/#!/inbox"),
                            idSelector: "nav-message",
                            iconClass: "icon-nav-message",
                            name: "messages",
                            labelTranslationKey: "Label.sMessages"
                        },
                        friends: {
                            url: y("/users/friends"),
                            urlForNotification: y("/users/friends#!/friend-requests"),
                            idSelector: "nav-friends",
                            iconClass: "icon-nav-friends",
                            name: "friends",
                            labelTranslationKey: "Label.sFriends"
                        },
                        avatar: {
                            url: y("/my/avatar"),
                            idSelector: "nav-character",
                            iconClass: "icon-nav-charactercustomizer",
                            name: "avatar",
                            labelTranslationKey: "Label.sAvatar"
                        },
                        inventory: {
                            url: y("/users/" + k.authenticatedUser.id + "/inventory"),
                            idSelector: "nav-inventory",
                            iconClass: "icon-nav-inventory",
                            name: "inventory",
                            labelTranslationKey: "Label.sInventory"
                        },
                        trade: {
                            url: y("/trades"),
                            urlForNotification: y("/trades"),
                            idSelector: "nav-trade",
                            iconClass: "icon-nav-trade",
                            name: "trade",
                            labelTranslationKey: "Label.sTrade"
                        },
                        groups: {
                            url: y("/my/groups"),
                            idSelector: "nav-group",
                            iconClass: "icon-nav-group",
                            name: "groups",
                            labelTranslationKey: "Label.sGroups"
                        },
                        blog: {
                            url: y("https://blog.roblox.com"),
                            idSelector: "nav-blog",
                            iconClass: "icon-nav-blog",
                            name: "blog",
                            labelTranslationKey: "Label.sBlog",
                            blankTarget: !0
                        },
                        shop: {
                            isModal: !0,
                            idSelector: "nav-shop",
                            iconClass: "icon-nav-shop",
                            name: "shop",
                            labelTranslationKey: "Label.OfficialStore"
                        },
                        giftcards: {
                            url: y("/giftcards-us"),
                            idSelector: "nav-giftcards",
                            iconClass: "icon-nav-giftcards",
                            name: "giftcards",
                            labelTranslationKey: "Label.GiftCards"
                        }
                    },
                    upgradeButton: {
                        url: y("/premium/membership?ctx=leftnav"),
                        labelTranslationKey: k.authenticatedUser.isPremiumUser ? "ActionsPremium" : "ActionsGetPremium"
                    },
                    sponsorEvents: {
                        label: {
                            labelTranslationKey: "Label.sEvents"
                        },
                        events: {}
                    },
                    gameSearchLink: E,
                    avatarSearchLink: w,
                    miscSearchLink: C,
                    universalSearchUrls: [{
                        url: y("/search/users?keyword="),
                        label: "Label.Players",
                        pageSort: []
                    }, {
                        url: y("/discover/?Keyword="),
                        label: "Label.Experience",
                        pageSort: ["home", "games", "discover"]
                    }, {
                        url: y("/catalog/browse.aspx?CatalogContext=1&Keyword="),
                        label: "Label.sCatalog",
                        pageSort: ["catalog", "inventory", "bundles"]
                    }, {
                        url: y("/search/groups?keyword="),
                        label: "Label.sGroups",
                        pageSort: ["groups"]
                    }, {
                        url: y("/develop/library?CatalogContext=2&Category=6&Keyword="),
                        label: "Label.CreatorMarketplace",
                        pageSort: ["develop"]
                    }],
                    newUniversalSearchUrls: b([E], C),
                    settingsUrl: {
                        settings: {
                            url: y("/my/account"),
                            label: "Label.sSettings"
                        },
                        quickLogin: {
                            url: y("/home"),
                            label: "Label.sQuickLogin"
                        },
                        safetySupport: {
                            url: y("/help-safety"),
                            label: "Label.HelpAndSafety"
                        },
                        switchAccountKey: {
                            url: y("/home"),
                            label: "Label.sSwitchAccount"
                        },
                        logout: {
                            url: S + "/v2/logout",
                            label: "Label.sLogout"
                        }
                    },
                    buyRobuxUrl: {
                        myTransactions: {
                            url: y("/transactions"),
                            label: "Label.MyMoney"
                        },
                        buyRobux: {
                            url: y("/upgrades/robux?ctx=navpopover"),
                            label: "Label.sBuyRobux",
                            name: "Label.sRobux"
                        },
                        buyRobuxOnVng: {
                            url: M.EnvironmentUrls.vngGamesShopUrl,
                            label: "Label.sBuyRobux",
                            cacheKey: "isEligibleForVng"
                        }
                    },
                    userDataUrl: y("/navigation/userData"),
                    quickLoginUrl: y("/crossdevicelogin/ConfirmCode"),
                    redeemUrl: {
                        url: y("/redeem"),
                        label: "Heading.RedeemRobloxCodes"
                    },
                    buyGiftCardUrl: {
                        url: "https://roblox.cashstar.com/gift-card/buy/?ref=1023buygc",
                        label: "Label.sBuyGiftCard",
                        cacheKey: "giftCardExp"
                    }
                },
                N = M.Endpoints.getAbsoluteUrl,
                R = M.EnvironmentUrls.authApi,
                O = M.EnvironmentUrls.accountSettingsApi,
                I = (M.EnvironmentUrls.websiteUrl, M.EnvironmentUrls.adsApi, M.EnvironmentUrls.economyApi),
                T = M.EnvironmentUrls.privateMessagesApi,
                G = M.EnvironmentUrls.tradesApi,
                V = M.EnvironmentUrls.friendsApi,
                K = M.EnvironmentUrls.apiGatewayUrl,
                W = M.EnvironmentUrls.universalAppConfigurationApi,
                H = function() {
                    return N("/account/signupredir")
                },
                Q = function() {
                    return N("/home")
                },
                z = function(e, t) {
                    return N("/".concat(e.toLowerCase(), "/").concat(t))
                },
                $ = function() {
                    return N("/login")
                },
                f = function() {
                    return N("/newLogin")
                },
                m = function() {
                    return N("/CreateAccount")
                },
                w = function() {
                    return "".concat(W, "/v1/behaviors/intl-auth-compliance/content")
                },
                X = function() {
                    return "".concat(O, "/v1/email")
                },
                Y = function() {
                    return "".concat(R, "/v2/logout")
                },
                J = function() {
                    return "".concat(T, "/v1/messages/unread/count")
                },
                Z = function(e) {
                    return "".concat(I, "/v1/users/").concat(e, "/currency")
                },
                ee = function() {
                    return "".concat(K, "/universal-app-configuration/v1/behaviors/navigation-header-ui/content")
                },
                te = function() {
                    return "".concat(G, "/v1/trades/inbound/count")
                },
                ne = function() {
                    return "".concat(V, "/v1/user/friend-requests/count")
                },
                re = function() {
                    return "".concat(K, "/credit-balance/v1/get-credit-balance-for-navigation")
                },
                ae = function() {
                    return "".concat(K, "/credit-balance/v1/get-conversion-metadata")
                },
                oe = function() {
                    return "".concat(K, "/credit-balance/v1/get-gift-card-visibility")
                },
                ie = function() {
                    var e = {
                        url: J(),
                        withCredentials: !0
                    };
                    return D.httpService.get(e)
                },
                ce = function(e) {
                    e = {
                        url: Z(e),
                        withCredentials: !0
                    };
                    return D.httpService.get(e)
                },
                ue = function() {
                    var e = {
                        url: ee(),
                        withCredentials: !0
                    };
                    return D.httpService.get(e)
                },
                le = function() {
                    var e = {
                        url: te(),
                        withCredentials: !0
                    };
                    return D.httpService.get(e)
                },
                se = function() {
                    var e = {
                        url: ne(),
                        withCredentials: !0
                    };
                    return D.httpService.get(e)
                },
                fe = function() {
                    var e = {
                        url: X(),
                        withCredentials: !0
                    };
                    return D.httpService.get(e)
                },
                de = function() {
                    var e = {
                        url: Y(),
                        withCredentials: !0
                    };
                    return D.httpService.post(e)
                },
                me = function() {
                    var e = {
                        url: re(),
                        withCredentials: !0
                    };
                    return D.httpService.get(e)
                },
                pe = function() {
                    var e = {
                        url: ae(),
                        withCredentials: !0
                    };
                    return D.httpService.get(e)
                },
                ve = function() {
                    var e = {
                        url: oe(),
                        withCredentials: !0
                    };
                    return D.httpService.get(e)
                },
                be = CoreRobloxUtilities;

            function ye(e, t, n) {
                return t in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e
            }
            var ge = be.dataStores.userDataStore.maxFriendRequestNotificationCount,
                he = be.dataStores.userDataStore.maxMessagesNotificationCount;

            function Se(e) {
                var t = e.translate,
                    n = e.idSelector,
                    r = e.isModal,
                    a = e.name,
                    o = e.iconClass,
                    i = e.labelTranslationKey,
                    c = e.url,
                    u = e.urlForNotification,
                    l = e.onClickShopLink,
                    s = e.friendsData,
                    f = e.messagesData,
                    d = e.tradeData,
                    m = e.blankTarget,
                    e = (ye(e = {}, F.scrollListItems.friends.name, s), ye(e, F.scrollListItems.messages.name, f), ye(e, F.scrollListItems.trade.name, d), e)[a],
                    c = null != e && e.count ? u : c,
                    m = m ? "_blank" : "_self";
                return r ? j().createElement("li", {
                    key: a
                }, j().createElement("button", {
                    id: n,
                    type: "button",
                    onClick: l,
                    className: "dynamic-overflow-container text-nav"
                }, j().createElement("div", null, j().createElement("span", {
                    className: o
                })), j().createElement("span", {
                    className: "font-header-2 dynamic-ellipsis-item"
                }, t(i)))) : j().createElement("li", {
                    key: a
                }, j().createElement(A.Link, {
                    url: c,
                    id: n,
                    className: "dynamic-overflow-container text-nav",
                    target: m
                }, j().createElement("div", null, j().createElement("span", {
                    className: o
                })), j().createElement("span", {
                    className: "font-header-2 dynamic-ellipsis-item"
                }, t(i)), e && 0 < e.count && j().createElement("div", {
                    className: "dynamic-width-item align-right"
                }, j().createElement("span", {
                    className: "notification-blue notification",
                    title: D.numberFormat.getNumberFormat(e.count)
                }, function(e, t) {
                    if (e === F.scrollListItems.friends.name && ge <= t) return "".concat(ge, "+");
                    if (e === F.scrollListItems.messages.name && he <= t) return "".concat(he, "+");
                    return D.abbreviateNumber.getTruncValue(t, 1e3)
                }(a, e.count)))))
            }
            Se.defaultProps = {
                idSelector: "",
                url: "",
                urlForNotification: "",
                isModal: !1,
                blankTarget: !1,
                friendsData: {
                    count: 0
                },
                messagesData: {
                    count: 0
                },
                tradeData: {
                    count: 0
                }
            }, Se.propTypes = {
                idSelector: d().string,
                translate: d().func.isRequired,
                isModal: d().bool,
                name: d().string.isRequired,
                iconClass: d().string.isRequired,
                labelTranslationKey: d().string.isRequired,
                url: d().string,
                urlForNotification: d().string,
                onClickShopLink: d().func.isRequired,
                blankTarget: d().bool,
                friendsData: d().shape({
                    count: d().number
                }),
                messagesData: d().shape({
                    count: d().number
                }),
                tradeData: d().shape({
                    count: d().number
                })
            };
            var Ee = Se;

            function we(e, t) {
                return function(e) {
                    if (Array.isArray(e)) return e
                }(e) || function(e, t) {
                    if ("undefined" == typeof Symbol || !(Symbol.iterator in Object(e))) return;
                    var n = [],
                        r = !0,
                        a = !1,
                        o = void 0;
                    try {
                        for (var i, c = e[Symbol.iterator](); !(r = (i = c.next()).done) && (n.push(i.value), !t || n.length !== t); r = !0);
                    } catch (e) {
                        a = !0, o = e
                    } finally {
                        try {
                            r || null == c.return || c.return()
                        } finally {
                            if (a) throw o
                        }
                    }
                    return n
                }(e, t) || xe(e, t) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function Ce(e) {
                return function(e) {
                    if (Array.isArray(e)) return Ae(e)
                }(e) || function(e) {
                    if ("undefined" != typeof Symbol && Symbol.iterator in Object(e)) return Array.from(e)
                }(e) || xe(e) || function() {
                    throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function xe(e, t) {
                if (e) {
                    if ("string" == typeof e) return Ae(e, t);
                    var n = Object.prototype.toString.call(e).slice(8, -1);
                    return "Object" === n && e.constructor && (n = e.constructor.name), "Map" === n || "Set" === n ? Array.from(e) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? Ae(e, t) : void 0
                }
            }

            function Ae(e, t) {
                (null == t || t > e.length) && (t = e.length);
                for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
                return r
            }

            function Ne() {
                return document.getElementById("navigation-container")
            }(b = be.eventStreamService.eventTypes).pageLoad, d().func.isRequired, d().instanceOf(Array);
            var Re = F.universalSearchUrls,
                Oe = F.newUniversalSearchUrls,
                Ie = F.avatarSearchLink,
                Te = a,
                ke = !k.authenticatedUser.isAuthenticated,
                E = function() {
                    var r = k.authenticatedUser.created;
                    return fe().then(function(e) {
                        var t, n = e.data.verified;
                        return t = r, e = n, n = new Date, t = new Date(t), +(Te < (n - t) / 864e5 && !e)
                    }).catch(function(e) {
                        console.debug(e)
                    })
                },
                Pe = function(e) {
                    M.EventStream && M.EventStream.SendEventWithTarget(e, "click", {}, M.EventStream.TargetTypes.WWW)
                },
                Ue = function(e) {
                    if (ke || !M.RealTime) return function() {};
                    document.addEventListener(i.requestCountChanged, e);
                    var t = M.RealTime.Factory.GetClient();
                    return t.Subscribe(i.friendshipNotifications, e),
                        function() {
                            document.removeEventListener(i.requestCountChanged, e), t.Unsubscribe(i.friendshipNotifications, e)
                        }
                },
                Le = function(e) {
                    return ke || !M.RealTime ? function() {} : (document.addEventListener(c, e), function() {
                        document.removeEventListener(c, e)
                    })
                },
                je = function() {
                    var e;
                    return null !== (e = (null === (e = window) || void 0 === e ? void 0 : e.innerWidth) < 543) && e
                },
                De = function() {
                    var e = Ce(Re);
                    return e.sort(function(e) {
                        return e.pageSort.reduce(function(e, t) {
                            return e || -1 < window.location.href.indexOf(t)
                        }, !1) ? -1 : 1
                    }), e
                },
                Me = function() {
                    var e = Ce(Oe),
                        t = e.filter(function(e) {
                            return e.pageSort.some(function(e) {
                                return -1 < window.location.pathname.indexOf(e)
                            })
                        }),
                        e = e.filter(function(e) {
                            return e.pageSort.every(function(e) {
                                return -1 === window.location.pathname.indexOf(e)
                            })
                        });
                    return [].concat(Ce(t), Ce(e))
                },
                _e = function() {
                    return Ie.pageSort.some(function(e) {
                        return -1 < window.location.pathname.indexOf(e)
                    })
                },
                qe = function() {
                    return document.getElementById("navigation-container") && document.getElementById("navigation-container").className
                },
                Be = function(e) {
                    var n = {};
                    return ("?" === e[0] ? e.substr(1) : e).split("&").forEach(function(e) {
                        var t;
                        e.includes("=") && (e = (t = we(e.split("="), 2))[0], t = t[1], n[null === (e = decodeURIComponent(e)) || void 0 === e ? void 0 : e.toLowerCase()] = decodeURIComponent(t))
                    }), n
                },
                C = M.EnvironmentUrls.apiGatewayUrl,
                S = M.EnvironmentUrls.apiGatewayCdnUrl,
                Fe = (M.EnvironmentUrls.localeApi, {
                    experimentLayer: "Website.TopNavSearchBox",
                    debounceTimeout: 100,
                    debouncedSearchInputMaxLength: 35,
                    expiryTimeout: 5e3,
                    variationId: 1,
                    trendingVariationId: 0,
                    avatarAutocompleteQueryPaddingAmount: 10,
                    requestSuggestionUrl: {
                        url: C + "/games-autocomplete/v1/request-suggestion",
                        withCredentials: !0
                    },
                    getSuggestionUrl: {
                        url: C + "/games-autocomplete/v1/get-suggestion/",
                        withCredentials: !0
                    },
                    avatarRequestSuggestionUrl: {
                        url: C + "/autocomplete-avatar/v2/suggest",
                        withCredentials: !0
                    },
                    avatarRequestSuggestionCdnUrl: {
                        url: S + "/autocomplete-avatar/v2/suggest",
                        withCredentials: !0
                    },
                    englishLanguageCode: "en",
                    avatarAutocompleteUrlLocations: ["Catalog", "Trades", "Inventory", "Avatar", "CatalogItem"],
                    avatarAutocompleteSuggestionLimit: 5,
                    isSpecialTreatmentAutocompleteRestricted: function() {
                        return 7 === parseInt(Ne().dataset.numberOfAutocompleteSuggestions, 10) && F.miscSearchLink.reduce(function(e, t) {
                            return e.push.apply(e, t.pageSort), e
                        }, []).reduce(function(e, t) {
                            return e || -1 < window.location.pathname.indexOf(t)
                        }, !1)
                    },
                    isSpecialTreatment: function() {
                        var e;
                        return 7 === parseInt(null === (e = Ne()) || void 0 === e ? void 0 : e.dataset.numberOfAutocompleteSuggestions, 10)
                    },
                    numberOfSpecialTreatmentAutocompleteSuggestions: 3,
                    isAutocompleteSuggestionsIXPTestEnabled: function() {
                        var e;
                        return 0 < parseInt(null === (e = Ne()) || void 0 === e ? void 0 : e.dataset.numberOfAutocompleteSuggestions, 10)
                    },
                    numberOfAutocompleteSuggestions: function() {
                        var e;
                        return parseInt(null === (e = Ne()) || void 0 === e ? void 0 : e.dataset.numberOfAutocompleteSuggestions, 10) || 0
                    },
                    isRedirectLibraryToCreatorMarketplaceEnabled: function() {
                        var e;
                        return "True" === (null === (e = Ne()) || void 0 === e ? void 0 : e.dataset.isRedirectLibraryToCreatorMarketplaceEnabled)
                    }
                }),
                y = ko(927),
                z = ko.n(y),
                b = ko(729),
                a = ko.n(b),
                C = ko(359),
                S = ko.n(C),
                y = ko(223),
                b = ko.n(y),
                C = ko(417),
                y = ko.n(C),
                C = ko(371),
                Ge = ko.n(C),
                C = ko(937),
                C = ko.n(C),
                Ve = {
                    vi_vn: z(),
                    tr_tr: a(),
                    pt_br: S(),
                    pl_pl: b(),
                    ja_jp: y(),
                    en_us: Ge(),
                    de_de: C()
                },
                Ke = function() {
                    var e;
                    return null !== (e = Ne()) && void 0 !== e && e.dataset.platformEventLeftNavEntryStartTime ? new Date(Date.parse("".concat(null === (e = Ne()) || void 0 === e ? void 0 : e.dataset.platformEventLeftNavEntryStartTime, " UTC"))) : new Date("01/01/2001")
                },
                We = function() {
                    var e;
                    return null !== (e = Ne()) && void 0 !== e && e.dataset.platformEventLeftNavEntryEndTime ? new Date(Date.parse("".concat(null === (e = Ne()) || void 0 === e ? void 0 : e.dataset.platformEventLeftNavEntryEndTime, " UTC"))) : new Date("01/01/2001")
                },
                He = function() {
                    var e;
                    return null !== (e = Ne()) && void 0 !== e && e.dataset.platformEventLeftNavUrl ? null === (e = Ne()) || void 0 === e ? void 0 : e.dataset.platformEventLeftNavUrl : ""
                },
                Qe = function(e) {
                    return Ve[e] || Ge()
                };

            function ze() {
                return (ze = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n, r = arguments[t];
                        for (n in r) Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n])
                    }
                    return e
                }).apply(this, arguments)
            }

            function $e(t, e) {
                var n, r = Object.keys(t);
                return Object.getOwnPropertySymbols && (n = Object.getOwnPropertySymbols(t), e && (n = n.filter(function(e) {
                    return Object.getOwnPropertyDescriptor(t, e).enumerable
                })), r.push.apply(r, n)), r
            }

            function Xe(r) {
                for (var e = 1; e < arguments.length; e++) {
                    var a = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? $e(Object(a), !0).forEach(function(e) {
                        var t, n;
                        t = r, e = a[n = e], n in t ? Object.defineProperty(t, n, {
                            value: e,
                            enumerable: !0,
                            configurable: !0,
                            writable: !0
                        }) : t[n] = e
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(r, Object.getOwnPropertyDescriptors(a)) : $e(Object(a)).forEach(function(e) {
                        Object.defineProperty(r, e, Object.getOwnPropertyDescriptor(a, e))
                    })
                }
                return r
            }

            function Ye(e, t) {
                return function(e) {
                    if (Array.isArray(e)) return e
                }(e) || function(e, t) {
                    if ("undefined" == typeof Symbol || !(Symbol.iterator in Object(e))) return;
                    var n = [],
                        r = !0,
                        a = !1,
                        o = void 0;
                    try {
                        for (var i, c = e[Symbol.iterator](); !(r = (i = c.next()).done) && (n.push(i.value), !t || n.length !== t); r = !0);
                    } catch (e) {
                        a = !0, o = e
                    } finally {
                        try {
                            r || null == c.return || c.return()
                        } finally {
                            if (a) throw o
                        }
                    }
                    return n
                }(e, t) || function(e, t) {
                    if (!e) return;
                    if ("string" == typeof e) return Je(e, t);
                    var n = Object.prototype.toString.call(e).slice(8, -1);
                    "Object" === n && e.constructor && (n = e.constructor.name);
                    if ("Map" === n || "Set" === n) return Array.from(e);
                    if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return Je(e, t)
                }(e, t) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function Je(e, t) {
                (null == t || t > e.length) && (t = e.length);
                for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
                return r
            }

            function Ze(e, t) {
                if (null == e) return {};
                var n, r = function(e, t) {
                    if (null == e) return {};
                    var n, r, a = {},
                        o = Object.keys(e);
                    for (r = 0; r < o.length; r++) n = o[r], 0 <= t.indexOf(n) || (a[n] = e[n]);
                    return a
                }(e, t);
                if (Object.getOwnPropertySymbols)
                    for (var a = Object.getOwnPropertySymbols(e), o = 0; o < a.length; o++) n = a[o], 0 <= t.indexOf(n) || Object.prototype.propertyIsEnumerable.call(e, n) && (r[n] = e[n]);
                return r
            }
            var et = o;

            function tt(e) {
                var t = e.translate,
                    n = Ze(e, ["translate"]),
                    r = Ye((0, L.useState)(!1), 2),
                    a = r[0],
                    o = r[1],
                    i = (0, L.useCallback)(function() {
                        o(function(e) {
                            return !e
                        }), Pe(et.clickMerchandise)
                    }, []),
                    c = function() {
                        o(!1)
                    },
                    u = Object.values(F.scrollListItems).map(function(e) {
                        return j().createElement(Ee, ze({
                            key: e.name
                        }, Xe(Xe({
                            translate: t,
                            onClickShopLink: i
                        }, e), n)))
                    }),
                    l = j().createElement("li", {
                        className: "rbx-upgrade-now"
                    }, j().createElement("a", {
                        href: F.upgradeButton.url,
                        className: "btn-growth-md btn-secondary-md",
                        onClick: function() {
                            be.paymentFlowAnalyticsService.sendUserPurchaseFlowEvent(be.paymentFlowAnalyticsService.ENUM_TRIGGERING_CONTEXT.WEB_PREMIUM_PURCHASE, !1, be.paymentFlowAnalyticsService.ENUM_VIEW_NAME.LEFT_NAVIGATION_BAR, be.paymentFlowAnalyticsService.ENUM_PURCHASE_EVENT_TYPE.USER_INPUT, k.authenticatedUser.isPremiumUser ? be.paymentFlowAnalyticsService.ENUM_VIEW_MESSAGE.PREMIUM : be.paymentFlowAnalyticsService.ENUM_VIEW_MESSAGE.GET_PREMIUM)
                        },
                        id: "upgrade-now-button"
                    }, t(F.upgradeButton.labelTranslationKey))),
                    s = j().createElement(j().Fragment, null, j().createElement("p", {
                        className: "shop-description"
                    }, t("Description.RetailWebsiteRedirect")), j().createElement("p", {
                        className: "shop-warning"
                    }, t("Description.PurchaseAgeWarning"))),
                    f = j().createElement(A.SimpleModal, {
                        title: t("Heading.LeavingRoblox"),
                        body: s,
                        show: a,
                        actionButtonShow: !0,
                        actionButtonText: t("Action.Continue"),
                        neutralButtonText: t("Action.Cancel"),
                        onAction: function() {
                            var e = decodeURIComponent(M.EnvironmentUrls.amazonWebStoreLink);
                            window.open(e, "_blank"), Pe(et.goToAmazonStore)
                        },
                        onNeutral: c,
                        onClose: c
                    }),
                    e = new Date,
                    r = Ke(),
                    s = We(),
                    a = He(),
                    c = M.Intl && new M.Intl,
                    c = Qe(c.getRobloxLocale()),
                    c = j().createElement("a", {
                        href: a,
                        className: "rbx-platform-event-container"
                    }, j().createElement("div", {
                        className: "rbx-platform-event-header dynamic-overflow-container"
                    }, j().createElement("span", {
                        className: "rbx-event-icon"
                    }), j().createElement("span", {
                        className: "rbx-event-header-text dynamic-ellipsis-item"
                    }, t("Label.sEvents"))), j().createElement("img", {
                        className: "rbx-platform-event-thumbnail",
                        src: c,
                        alt: t("Label.TheHunt")
                    }));
                return j().createElement("ul", {
                    className: "left-col-list"
                }, u, l, !1, f, r < e && e < s && a && c)
            }
            tt.defaultProps = {
                sponsoredPagesData: []
            }, tt.propTypes = {
                sponsoredPagesData: d().instanceOf(Array),
                translate: d().func.isRequired
            };
            var nt = tt;

            function rt(t, e) {
                var n, r = Object.keys(t);
                return Object.getOwnPropertySymbols && (n = Object.getOwnPropertySymbols(t), e && (n = n.filter(function(e) {
                    return Object.getOwnPropertyDescriptor(t, e).enumerable
                })), r.push.apply(r, n)), r
            }

            function at(r) {
                for (var e = 1; e < arguments.length; e++) {
                    var a = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? rt(Object(a), !0).forEach(function(e) {
                        var t, n;
                        t = r, e = a[n = e], n in t ? Object.defineProperty(t, n, {
                            value: e,
                            enumerable: !0,
                            configurable: !0,
                            writable: !0
                        }) : t[n] = e
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(r, Object.getOwnPropertyDescriptors(a)) : rt(Object(a)).forEach(function(e) {
                        Object.defineProperty(r, e, Object.getOwnPropertyDescriptor(a, e))
                    })
                }
                return r
            }

            function ot(e, t) {
                return function(e) {
                    if (Array.isArray(e)) return e
                }(e) || function(e, t) {
                    if ("undefined" == typeof Symbol || !(Symbol.iterator in Object(e))) return;
                    var n = [],
                        r = !0,
                        a = !1,
                        o = void 0;
                    try {
                        for (var i, c = e[Symbol.iterator](); !(r = (i = c.next()).done) && (n.push(i.value), !t || n.length !== t); r = !0);
                    } catch (e) {
                        a = !0, o = e
                    } finally {
                        try {
                            r || null == c.return || c.return()
                        } finally {
                            if (a) throw o
                        }
                    }
                    return n
                }(e, t) || function(e, t) {
                    if (!e) return;
                    if ("string" == typeof e) return it(e, t);
                    var n = Object.prototype.toString.call(e).slice(8, -1);
                    "Object" === n && e.constructor && (n = e.constructor.name);
                    if ("Map" === n || "Set" === n) return Array.from(e);
                    if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return it(e, t)
                }(e, t) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function it(e, t) {
                (null == t || t > e.length) && (t = e.length);
                for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
                return r
            }

            function ct(e) {
                var n = k.authenticatedUser.isAuthenticated,
                    t = ot((0, L.useState)({}), 2),
                    r = t[0],
                    a = t[1],
                    o = (c = ot((0, L.useState)({}), 2))[0],
                    i = c[1],
                    c = (t = ot((0, L.useState)({}), 2))[0],
                    u = t[1];
                return (0, L.useEffect)(function() {
                    var e = function() {},
                        t = function() {};
                    return n && (e = Ue(function() {
                            se().then(function(e) {
                                e = e.data;
                                a(e)
                            }, function(e) {
                                console.debug(e)
                            })
                        }), t = Le(function() {
                            ie().then(function(e) {
                                e = e.data;
                                i(e)
                            })
                        }), se().then(function(e) {
                            e = e.data;
                            a(e)
                        }, function(e) {
                            console.debug(e)
                        }), ie().then(function(e) {
                            e = e.data;
                            i(e)
                        }, function(e) {
                            console.debug(e)
                        }), le().then(function(e) {
                            e = e.data;
                            u(e)
                        }, function(e) {
                            console.debug(e)
                        })),
                        function() {
                            e(), t()
                        }
                }, []), j().createElement(nt, at({
                    friendsData: r,
                    messagesData: o,
                    tradeData: c
                }, e))
            }
            var y = k.authenticatedUser.name,
                C = k.authenticatedUser.displayName,
                ut = {
                    nameForDisplay: null !== M.DisplayNames && void 0 !== M.DisplayNames && M.DisplayNames.Enabled() ? C : y,
                    nameForHeader: null !== M.DisplayNames && void 0 !== M.DisplayNames && M.DisplayNames.Enabled() ? D.concatTexts.concat(["", y]) : y
                };

            function lt(e, t, n, r, a, o, i) {
                try {
                    var c = e[o](i),
                        u = c.value
                } catch (e) {
                    return void n(e)
                }
                c.done ? t(u) : Promise.resolve(u).then(r, a)
            }

            function st(e, t) {
                return function(e) {
                    if (Array.isArray(e)) return e
                }(e) || function(e, t) {
                    if ("undefined" == typeof Symbol || !(Symbol.iterator in Object(e))) return;
                    var n = [],
                        r = !0,
                        a = !1,
                        o = void 0;
                    try {
                        for (var i, c = e[Symbol.iterator](); !(r = (i = c.next()).done) && (n.push(i.value), !t || n.length !== t); r = !0);
                    } catch (e) {
                        a = !0, o = e
                    } finally {
                        try {
                            r || null == c.return || c.return()
                        } finally {
                            if (a) throw o
                        }
                    }
                    return n
                }(e, t) || function(e, t) {
                    if (!e) return;
                    if ("string" == typeof e) return ft(e, t);
                    var n = Object.prototype.toString.call(e).slice(8, -1);
                    "Object" === n && e.constructor && (n = e.constructor.name);
                    if ("Map" === n || "Set" === n) return Array.from(e);
                    if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return ft(e, t)
                }(e, t) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function ft(e, t) {
                (null == t || t > e.length) && (t = e.length);
                for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
                return r
            }

            function dt(e, t) {
                if (null == e) return {};
                var n, r = function(e, t) {
                    if (null == e) return {};
                    var n, r, a = {},
                        o = Object.keys(e);
                    for (r = 0; r < o.length; r++) n = o[r], 0 <= t.indexOf(n) || (a[n] = e[n]);
                    return a
                }(e, t);
                if (Object.getOwnPropertySymbols)
                    for (var a = Object.getOwnPropertySymbols(e), o = 0; o < a.length; o++) n = a[o], 0 <= t.indexOf(n) || Object.prototype.propertyIsEnumerable.call(e, n) && (r[n] = e[n]);
                return r
            }

            function mt(e) {
                var t = e.isLeftNavOpen,
                    n = dt(e, ["isLeftNavOpen"]),
                    r = st((0, L.useState)(!1), 2),
                    e = r[0],
                    a = r[1],
                    o = (0, L.useRef)(null);
                (0, L.useEffect)(function() {
                    (function() {
                        var c, e = (c = regeneratorRuntime.mark(function e() {
                            return regeneratorRuntime.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        e.next = 4;
                                        break;
                                    case 4:
                                        return e.prev = 4, e.next = 7, (0, v.robloxBadgesReadyForRender)();
                                    case 7:
                                        e.sent && a((0, v.currentUserHasVerifiedBadge)()), e.next = 14;
                                        break;
                                    case 11:
                                        e.prev = 11, e.t0 = e.catch(4), a(!1);
                                    case 14:
                                    case "end":
                                        return e.stop()
                                }
                            }, e, null, [
                                [4, 11]
                            ])
                        }), function() {
                            var e = this,
                                i = arguments;
                            return new Promise(function(t, n) {
                                var r = c.apply(e, i);

                                function a(e) {
                                    lt(r, t, n, a, o, "next", e)
                                }

                                function o(e) {
                                    lt(r, t, n, a, o, "throw", e)
                                }
                                a(void 0)
                            })
                        });
                        return function() {
                            return e.apply(this, arguments)
                        }
                    })()().catch(function() {})
                }, [t, o]);
                r = e && v.VerifiedBadgeIconContainer ? j().createElement("section", {
                    ref: function(e) {
                        o.current = e
                    }
                }, j().createElement(v.VerifiedBadgeIconContainer, {
                    overrideImgClass: "verified-badge-icon-header",
                    size: v.BadgeSizes.CAPTIONHEADER
                })) : null, t = x()("rbx-left-col", {
                    "nav-show": t
                }), e = x()("font-header-2 dynamic-ellipsis-item", {
                    "verified-badge-left-nav": e
                });
                return j().createElement("div", {
                    id: "navigation",
                    className: t
                }, j().createElement("ul", null, j().createElement("li", {
                    key: "username"
                }, j().createElement(A.Link, {
                    className: "dynamic-overflow-container text-nav",
                    role: "link",
                    url: F.scrollListItems.profile.url
                }, j().createElement("span", {
                    className: "avatar avatar-headshot-xs"
                }, j().createElement(p.Thumbnail2d, {
                    containerClass: "avatar-card-image",
                    targetId: k.authenticatedUser.id,
                    type: p.ThumbnailTypes.avatarHeadshot,
                    altName: k.authenticatedUser.name
                })), j().createElement("div", {
                    className: e
                }, ut.nameForDisplay), r)), j().createElement("li", {
                    key: "divider",
                    className: "rbx-divider"
                })), j().createElement(A.ScrollBar, {
                    className: "rbx-scrollbar"
                }, j().createElement(ct, n)))
            }
            mt.propTypes = {
                isLeftNavOpen: d().bool.isRequired
            };
            var pt = mt;

            function vt(t, e) {
                var n, r = Object.keys(t);
                return Object.getOwnPropertySymbols && (n = Object.getOwnPropertySymbols(t), e && (n = n.filter(function(e) {
                    return Object.getOwnPropertyDescriptor(t, e).enumerable
                })), r.push.apply(r, n)), r
            }

            function bt(r) {
                for (var e = 1; e < arguments.length; e++) {
                    var a = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? vt(Object(a), !0).forEach(function(e) {
                        var t, n;
                        t = r, e = a[n = e], n in t ? Object.defineProperty(t, n, {
                            value: e,
                            enumerable: !0,
                            configurable: !0,
                            writable: !0
                        }) : t[n] = e
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(r, Object.getOwnPropertyDescriptors(a)) : vt(Object(a)).forEach(function(e) {
                        Object.defineProperty(r, e, Object.getOwnPropertyDescriptor(a, e))
                    })
                }
                return r
            }

            function yt(e, t) {
                return function(e) {
                    if (Array.isArray(e)) return e
                }(e) || function(e, t) {
                    if ("undefined" == typeof Symbol || !(Symbol.iterator in Object(e))) return;
                    var n = [],
                        r = !0,
                        a = !1,
                        o = void 0;
                    try {
                        for (var i, c = e[Symbol.iterator](); !(r = (i = c.next()).done) && (n.push(i.value), !t || n.length !== t); r = !0);
                    } catch (e) {
                        a = !0, o = e
                    } finally {
                        try {
                            r || null == c.return || c.return()
                        } finally {
                            if (a) throw o
                        }
                    }
                    return n
                }(e, t) || function(e, t) {
                    if (!e) return;
                    if ("string" == typeof e) return gt(e, t);
                    var n = Object.prototype.toString.call(e).slice(8, -1);
                    "Object" === n && e.constructor && (n = e.constructor.name);
                    if ("Map" === n || "Set" === n) return Array.from(e);
                    if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return gt(e, t)
                }(e, t) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function gt(e, t) {
                (null == t || t > e.length) && (t = e.length);
                for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
                return r
            }
            var ht, St = u,
                Et = (0, _.withTranslations)(function(e) {
                    var t = k.authenticatedUser.isAuthenticated,
                        n = yt((0, L.useState)(!1), 2),
                        r = n[0],
                        a = n[1],
                        o = (0, L.useCallback)(function() {
                            a(!r)
                        }, [r]);
                    return (0, L.useEffect)(function() {
                        return document.addEventListener(St.name, o),
                            function() {
                                document.removeEventListener(St.name, o)
                            }
                    }, [o]), t ? j().createElement(pt, bt({
                        isLeftNavOpen: r
                    }, e)) : null
                }, s),
                wt = function() {
                    return (wt = Object.assign || function(e) {
                        for (var t, n = 1, r = arguments.length; n < r; n++)
                            for (var a in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
                        return e
                    }).apply(this, arguments)
                },
                Ct = function(e, i, c, u) {
                    return new(c = c || Promise)(function(n, t) {
                        function r(e) {
                            try {
                                o(u.next(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function a(e) {
                            try {
                                o(u.throw(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function o(e) {
                            var t;
                            e.done ? n(e.value) : ((t = e.value) instanceof c ? t : new c(function(e) {
                                e(t)
                            })).then(r, a)
                        }
                        o((u = u.apply(e, i || [])).next())
                    })
                },
                xt = function(n, r) {
                    var a, o, i, c = {
                            label: 0,
                            sent: function() {
                                if (1 & i[0]) throw i[1];
                                return i[1]
                            },
                            trys: [],
                            ops: []
                        },
                        e = {
                            next: t(0),
                            throw: t(1),
                            return: t(2)
                        };
                    return "function" == typeof Symbol && (e[Symbol.iterator] = function() {
                        return this
                    }), e;

                    function t(t) {
                        return function(e) {
                            return function(t) {
                                if (a) throw new TypeError("Generator is already executing.");
                                for (; c;) try {
                                    if (a = 1, o && (i = 2 & t[0] ? o.return : t[0] ? o.throw || ((i = o.return) && i.call(o), 0) : o.next) && !(i = i.call(o, t[1])).done) return i;
                                    switch (o = 0, i && (t = [2 & t[0], i.value]), t[0]) {
                                        case 0:
                                        case 1:
                                            i = t;
                                            break;
                                        case 4:
                                            return c.label++, {
                                                value: t[1],
                                                done: !1
                                            };
                                        case 5:
                                            c.label++, o = t[1], t = [0];
                                            continue;
                                        case 7:
                                            t = c.ops.pop(), c.trys.pop();
                                            continue;
                                        default:
                                            if (!(i = 0 < (i = c.trys).length && i[i.length - 1]) && (6 === t[0] || 2 === t[0])) {
                                                c = 0;
                                                continue
                                            }
                                            if (3 === t[0] && (!i || t[1] > i[0] && t[1] < i[3])) {
                                                c.label = t[1];
                                                break
                                            }
                                            if (6 === t[0] && c.label < i[1]) {
                                                c.label = i[1], i = t;
                                                break
                                            }
                                            if (i && c.label < i[2]) {
                                                c.label = i[2], c.ops.push(t);
                                                break
                                            }
                                            i[2] && c.ops.pop(), c.trys.pop();
                                            continue
                                    }
                                    t = r.call(n, c)
                                } catch (e) {
                                    t = [6, e], o = 0
                                } finally {
                                    a = i = 0
                                }
                                if (5 & t[0]) throw t[1];
                                return {
                                    value: t[0] ? t[1] : void 0,
                                    done: !0
                                }
                            }([t, e])
                        }
                    }
                },
                At = D.httpService.createCancelToken();

            function Nt(e) {
                return void 0 === (null == e ? void 0 : e.label)
            }

            function Rt(e) {
                return void 0 !== (null == e ? void 0 : e.Query)
            }

            function Ot(e) {
                if (Rt(e)) return "avatar";
                switch (e.type) {
                    case ht.QuerySuggestion:
                        return "keyword";
                    case ht.GameSuggestion:
                        return "game";
                    default:
                        throw Error("Unrecognized autocomplete suggestion, ".concat(JSON.stringify(e)))
                }
            }

            function It(e) {
                switch (e.label) {
                    case "Label.Players":
                        return "defaultPlayers";
                    case "Heading.Marketplace":
                    case "Label.AvatarShop":
                    case "Label.sCatalog":
                        return "defaultShops";
                    case "Label.sGroups":
                        return "defaultGroups";
                    case "Label.CreatorMarketplace":
                        return "defaultLibrary";
                    case "Label.Experience":
                        return "defaultGames";
                    default:
                        throw Error("Unrecognized default suggestion, ".concat(JSON.stringify(e)))
                }
            }(o = ht = ht || {})[o.GameSuggestion = 0] = "GameSuggestion", o[o.QuerySuggestion = 1] = "QuerySuggestion", o[o.TrendingQuerySuggestion = 2] = "TrendingQuerySuggestion";
            var Tt = function(t) {
                    return Ct(void 0, void 0, Promise, function() {
                        return xt(this, function(e) {
                            switch (e.label) {
                                case 0:
                                    return At.cancel(), At = D.httpService.createCancelToken(), [4, D.httpService.get(wt(wt({}, Fe.getSuggestionUrl), {
                                        url: Fe.getSuggestionUrl.url + encodeURIComponent(t.toLowerCase()),
                                        cancelToken: At.token
                                    }))];
                                case 1:
                                    return [2, e.sent().data]
                            }
                        })
                    })
                },
                kt = function(n, r, a, o, i) {
                    return void 0 === i && (i = !1), Ct(void 0, void 0, Promise, function() {
                        var t;
                        return xt(this, function(e) {
                            switch (e.label) {
                                case 0:
                                    return null === (t = r) && (t = Fe.englishLanguageCode), t = {
                                        prefix: n.toLowerCase(),
                                        limit: a,
                                        lang: t,
                                        q: o
                                    }, At.cancel(), At = D.httpService.createCancelToken(), i ? [4, D.httpService.get(wt(wt({}, Fe.avatarRequestSuggestionUrl), {
                                        timeout: Fe.expiryTimeout,
                                        cancelToken: At.token,
                                        fullError: !0
                                    }), t)] : [3, 2];
                                case 1:
                                    return [2, e.sent().data];
                                case 2:
                                    return [4, D.httpService.get(wt(wt({}, Fe.avatarRequestSuggestionCdnUrl), {
                                        timeout: Fe.expiryTimeout,
                                        cancelToken: At.token,
                                        fullError: !0
                                    }), t)];
                                case 3:
                                    return [2, e.sent().data]
                            }
                        })
                    })
                },
                Pt = Nt,
                Ut = Rt,
                Lt = Ot,
                jt = It,
                Dt = function(e, t) {
                    var n;
                    return Nt(e) && Rt(e) ? F.avatarSearchLink.url + encodeURIComponent(e.Query) : Nt(e) ? F.gameSearchLink.url + encodeURIComponent(e.searchQuery) : null != t && null !== (n = t.target) && void 0 !== n && n.value ? e.url + encodeURIComponent(t.target.value) : ""
                },
                Mt = function() {
                    var e = (new M.TranslationResourceProvider).intl.locale,
                        t = e.indexOf("-");
                    return (e = e.substring(0, -1 !== t ? t : e.length)) !== Fe.englishLanguageCode && (e += ",".concat(Fe.englishLanguageCode)), e
                },
                _t = function(e, t) {
                    return e.map(function(e) {
                        return Nt(e) ? "".concat(Ot(e), "|").concat(e.searchQuery) : "".concat(It(e), "|").concat(t)
                    }).join(",")
                },
                qt = be.eventStreamService.eventTypes,
                Bt = "searchAutocomplete",
                Ft = {
                    actionTypes: {
                        open: "open",
                        submit: "submit",
                        close: "close"
                    },
                    generateSessionInfo: D.uuidService.generateRandomUuid,
                    searchTextTrim: function(e, t, n, r) {
                        return [{
                            name: "searchTextTrim",
                            type: qt.formInteraction,
                            context: Bt
                        }, {
                            kwd: e,
                            resultingKwd: t,
                            searchType: n,
                            sessionInfo: r
                        }]
                    },
                    searchClear: function(e, t, n, r) {
                        return [{
                            name: "searchClear",
                            type: qt.formInteraction,
                            context: Bt
                        }, {
                            kwd: e,
                            searchType: t,
                            sessionInfo: n,
                            page: r
                        }]
                    },
                    searchSuggestionClicked: function(e, t, n, r, a, o, i) {
                        return [{
                            name: "searchSuggestionClicked",
                            type: qt.formInteraction,
                            context: Bt
                        }, {
                            kwd: e,
                            searchType: t,
                            suggestionPosition: n,
                            suggestionClicked: r,
                            suggestionType: a,
                            suggestions: o,
                            sessionInfo: i
                        }]
                    },
                    searchAutocomplete: function(e, t, n, r, a, o, i, c, u, l) {
                        return [{
                            name: "searchAutocomplete",
                            type: qt.formInteraction,
                            context: Bt
                        }, {
                            kwd: e,
                            previousKwd: t,
                            fromLocalCache: n,
                            suggestions: r,
                            algorithm: a,
                            latency: o,
                            timeoutDelayMs: i,
                            sessionInfo: c,
                            page: u,
                            isPersonalizedBasedOnPreviousQuery: l
                        }]
                    },
                    search: function(e, t, n) {
                        return [{
                            name: "search",
                            type: qt.formInteraction,
                            context: Bt
                        }, {
                            kwd: e,
                            actionType: t,
                            sessionInfo: n
                        }]
                    },
                    catalogSearch: function(e, t) {
                        return [{
                            name: "catalogSearch",
                            type: qt.formInteraction,
                            context: Bt
                        }, {
                            autocompleteFlag: e,
                            previousPage: t
                        }]
                    }
                };

            function Gt(e) {
                return function(e) {
                    if (Array.isArray(e)) return Wt(e)
                }(e) || function(e) {
                    if ("undefined" != typeof Symbol && Symbol.iterator in Object(e)) return Array.from(e)
                }(e) || Kt(e) || function() {
                    throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function Vt(e, t) {
                return function(e) {
                    if (Array.isArray(e)) return e
                }(e) || function(e, t) {
                    if ("undefined" == typeof Symbol || !(Symbol.iterator in Object(e))) return;
                    var n = [],
                        r = !0,
                        a = !1,
                        o = void 0;
                    try {
                        for (var i, c = e[Symbol.iterator](); !(r = (i = c.next()).done) && (n.push(i.value), !t || n.length !== t); r = !0);
                    } catch (e) {
                        a = !0, o = e
                    } finally {
                        try {
                            r || null == c.return || c.return()
                        } finally {
                            if (a) throw o
                        }
                    }
                    return n
                }(e, t) || Kt(e, t) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function Kt(e, t) {
                if (e) {
                    if ("string" == typeof e) return Wt(e, t);
                    var n = Object.prototype.toString.call(e).slice(8, -1);
                    return "Object" === n && e.constructor && (n = e.constructor.name), "Map" === n || "Set" === n ? Array.from(e) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? Wt(e, t) : void 0
                }
            }

            function Wt(e, t) {
                (null == t || t > e.length) && (t = e.length);
                for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
                return r
            }

            function Ht(e) {
                var o = e.translate,
                    i = e.searchInput,
                    c = e.indexOfSelectedOption,
                    u = e.autocompleteSessionInfo,
                    l = e.resetAutocompleteSessionInfo,
                    s = De();
                return j().createElement(j().Fragment, null, Object.entries(s).map(function(e) {
                    var t = Vt(e, 2),
                        n = t[0],
                        r = t[1],
                        a = r.url,
                        e = r.label,
                        t = x()("navbar-search-option rbx-clickable-li", parseInt(n, 10) === c ? " selected" : "");
                    return j().createElement("li", {
                        key: n,
                        className: t
                    }, j().createElement(A.Link, {
                        className: "navbar-search-anchor",
                        url: a + i,
                        onClick: function() {
                            be.eventStreamService.sendEvent.apply(be.eventStreamService, Gt(Ft.searchSuggestionClicked(i, void 0, n, i, jt(r), _t(s, i), u))), l()
                        }
                    }, o("Label.sSearchPhrase", {
                        phrase: i,
                        location: o(e)
                    })))
                }))
            }
            Ht.propTypes = {
                translate: d().func.isRequired,
                searchInput: d().string.isRequired,
                indexOfSelectedOption: d().number.isRequired,
                autocompleteSessionInfo: d().string.isRequired,
                resetAutocompleteSessionInfo: d().func.isRequired
            };
            var Qt = Ht;

            function zt(e, t) {
                return function(e) {
                    if (Array.isArray(e)) return e
                }(e) || function(e, t) {
                    if ("undefined" == typeof Symbol || !(Symbol.iterator in Object(e))) return;
                    var n = [],
                        r = !0,
                        a = !1,
                        o = void 0;
                    try {
                        for (var i, c = e[Symbol.iterator](); !(r = (i = c.next()).done) && (n.push(i.value), !t || n.length !== t); r = !0);
                    } catch (e) {
                        a = !0, o = e
                    } finally {
                        try {
                            r || null == c.return || c.return()
                        } finally {
                            if (a) throw o
                        }
                    }
                    return n
                }(e, t) || function(e, t) {
                    if (!e) return;
                    if ("string" == typeof e) return $t(e, t);
                    var n = Object.prototype.toString.call(e).slice(8, -1);
                    "Object" === n && e.constructor && (n = e.constructor.name);
                    if ("Map" === n || "Set" === n) return Array.from(e);
                    if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return $t(e, t)
                }(e, t) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function $t(e, t) {
                (null == t || t > e.length) && (t = e.length);
                for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
                return r
            }
            var Xt = F.gameSearchLink,
                Yt = F.avatarSearchLink,
                Jt = F.creatorMarketplaceUrl;

            function Zt(e) {
                var t = e.translate,
                    n = e.selected,
                    r = e.suggestion,
                    a = e.onClick,
                    o = x()("navbar-search-option rbx-clickable-li", {
                        "new-selected": n
                    }),
                    i = r.type,
                    c = r.universeId,
                    e = r.searchQuery,
                    n = zt((0, L.useState)(!1), 2),
                    r = n[0],
                    u = n[1];
                return i === ht.GameSuggestion ? j().createElement("li", {
                    className: o
                }, j().createElement(A.Link, {
                    className: "new-navbar-search-anchor",
                    url: Xt.url + encodeURIComponent(e),
                    onClick: a
                }, j().createElement("span", {
                    className: x()(Xt.icon, "navbar-list-option-icon")
                }), j().createElement("span", {
                    className: "navbar-list-option-text"
                }, e), j().createElement("span", {
                    className: "navbar-list-option-suffix"
                }, t("Label.sSearchPhraseV2", {
                    location: t(Xt.label)
                })), j().createElement("span", {
                    className: x()("navbar-list-option-thumbnail", {
                        "navbar-list-option-thumbnail-visible": r
                    })
                }, j().createElement("span", {
                    className: "background-icon"
                }), j().createElement(p.Thumbnail2d, {
                    type: p.ThumbnailTypes.gameIcon,
                    size: p.DefaultThumbnailSize,
                    targetId: c,
                    containerClass: "thumbnail-icon",
                    format: p.ThumbnailFormat.jpeg,
                    onLoad: function() {
                        u(!0)
                    }
                })))) : j().createElement("li", {
                    className: o
                }, j().createElement(A.Link, {
                    className: "new-navbar-search-anchor",
                    url: Xt.url + encodeURIComponent(e),
                    onClick: a
                }, j().createElement("span", {
                    className: x()(Xt.icon, "navbar-list-option-icon")
                }), j().createElement("span", {
                    className: "navbar-list-option-text"
                }, e), j().createElement("span", {
                    className: "navbar-list-option-suffix"
                }, t("Label.sSearchPhraseV2", {
                    location: t(Xt.label)
                }))))
            }

            function en(e) {
                var t = e.translate,
                    n = e.selected,
                    r = e.suggestion,
                    e = e.onClick,
                    n = x()("navbar-search-option rbx-clickable-li", {
                        "new-selected": n
                    }),
                    r = r.Query;
                return j().createElement("li", {
                    className: n
                }, j().createElement(A.Link, {
                    className: "new-navbar-search-anchor",
                    url: Yt.url + encodeURIComponent(r),
                    onClick: e
                }, j().createElement("span", {
                    className: x()(Yt.icon, "navbar-list-option-icon")
                }), j().createElement("span", {
                    className: "navbar-list-option-text"
                }, r), j().createElement("span", {
                    className: "navbar-list-option-suffix"
                }, t("Label.sSearchPhraseV2", {
                    location: t(Yt.label)
                }))))
            }

            function tn(e) {
                var t = e.translate,
                    n = e.selected,
                    r = e.searchInput,
                    a = e.suggestion,
                    o = e.onClick,
                    i = a.url,
                    e = a.label,
                    a = a.icon,
                    i = (0, Fe.isRedirectLibraryToCreatorMarketplaceEnabled)() && "Label.CreatorMarketplace" === e ? Jt : i,
                    n = x()("navbar-search-option rbx-clickable-li", {
                        "new-selected": n
                    });
                return j().createElement("li", {
                    className: n
                }, j().createElement(A.Link, {
                    className: "new-navbar-search-anchor",
                    url: i + encodeURIComponent(r),
                    onClick: o
                }, j().createElement("span", {
                    className: x()(a, "navbar-list-option-icon")
                }), j().createElement("span", {
                    className: "navbar-list-option-text"
                }, r.toLowerCase()), j().createElement("span", {
                    className: "navbar-list-option-suffix"
                }, t("Label.sSearchPhraseV2", {
                    location: t(e)
                }))))
            }

            function nn(e) {
                return function(e) {
                    if (Array.isArray(e)) return rn(e)
                }(e) || function(e) {
                    if ("undefined" != typeof Symbol && Symbol.iterator in Object(e)) return Array.from(e)
                }(e) || function(e, t) {
                    if (!e) return;
                    if ("string" == typeof e) return rn(e, t);
                    var n = Object.prototype.toString.call(e).slice(8, -1);
                    "Object" === n && e.constructor && (n = e.constructor.name);
                    if ("Map" === n || "Set" === n) return Array.from(e);
                    if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return rn(e, t)
                }(e) || function() {
                    throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function rn(e, t) {
                (null == t || t > e.length) && (t = e.length);
                for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
                return r
            }

            function an(e) {
                function r(t, n) {
                    return function() {
                        var e = c[n];
                        be.eventStreamService.sendEvent.apply(be.eventStreamService, nn(Ft.searchSuggestionClicked(o, void 0, n, Pt(e) ? e.searchQuery : o, t, _t(c, o), u))), l();
                        e = t.includes("default") ? 0 : 1;
                        be.eventStreamService.sendEvent.apply(be.eventStreamService, nn(Ft.catalogSearch(e, D.pageName.PageNameProvider.getInternalPageName())))
                    }
                }
                var a = e.translate,
                    o = e.searchInput,
                    i = e.indexOfSelectedOption,
                    c = e.searchSuggestions,
                    u = e.autocompleteSessionInfo,
                    l = e.resetAutocompleteSessionInfo;
                return c.map(function(e, t) {
                    var n = parseInt(t, 10) === i;
                    return Pt(e) && Ut(e) ? j().createElement(en, {
                        key: e.Query,
                        translate: a,
                        selected: n,
                        suggestion: e,
                        onClick: r(Lt(e), t)
                    }) : Pt(e) ? j().createElement(Zt, {
                        key: e.searchQuery,
                        translate: a,
                        selected: n,
                        suggestion: e,
                        onClick: r(Lt(e), t)
                    }) : j().createElement(tn, {
                        key: e.url,
                        translate: a,
                        selected: n,
                        suggestion: e,
                        searchInput: o,
                        onClick: r(jt(e), t)
                    })
                })
            }
            Zt.propTypes = {
                translate: d().func.isRequired,
                selected: d().bool.isRequired,
                suggestion: d().shape({
                    type: d().number.isRequired,
                    score: d().number.isRequired,
                    universeId: d().number,
                    canonicalTitle: d().string,
                    thumbnailUrl: d().string,
                    searchQuery: d().string.isRequired,
                    trendingSearchStartDateTime: d().string
                }).isRequired,
                onClick: d().func.isRequired
            }, en.propTypes = {
                translate: d().func.isRequired,
                selected: d().bool.isRequired,
                suggestion: d().shape({
                    Query: d().string
                }).isRequired,
                onClick: d().func.isRequired
            }, tn.propTypes = {
                translate: d().func.isRequired,
                selected: d().bool.isRequired,
                searchInput: d().string.isRequired,
                suggestion: d().shape({
                    url: d().string.isRequired,
                    label: d().string.isRequired,
                    pageSort: d().arrayOf(d().string).isRequired,
                    icon: d().string.isRequired
                }).isRequired,
                onClick: d().func.isRequired
            }, an.propTypes = {
                translate: d().func.isRequired,
                searchInput: d().string.isRequired,
                indexOfSelectedOption: d().number.isRequired,
                searchSuggestions: d().arrayOf(d().oneOfType([d().shape({
                    type: d().number.isRequired,
                    score: d().number.isRequired,
                    universeId: d().number.isRequired,
                    canonicalTitle: d().string,
                    thumbnailUrl: d().string,
                    searchQuery: d().string.isRequired,
                    trendingSearchStartDateTime: d().string
                }), d().shape({
                    url: d().string.isRequired,
                    label: d().string.isRequired,
                    pageSort: d().arrayOf(d().string).isRequired,
                    icon: d().string.isRequired
                }), d().shape({
                    Query: d().string.isRequired,
                    Score: d().number.isRequired
                })])).isRequired,
                autocompleteSessionInfo: d().string.isRequired,
                resetAutocompleteSessionInfo: d().func.isRequired
            };
            var on = an;

            function cn(e) {
                return function(e) {
                    if (Array.isArray(e)) return un(e)
                }(e) || function(e) {
                    if ("undefined" != typeof Symbol && Symbol.iterator in Object(e)) return Array.from(e)
                }(e) || function(e, t) {
                    if (!e) return;
                    if ("string" == typeof e) return un(e, t);
                    var n = Object.prototype.toString.call(e).slice(8, -1);
                    "Object" === n && e.constructor && (n = e.constructor.name);
                    if ("Map" === n || "Set" === n) return Array.from(e);
                    if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return un(e, t)
                }(e) || function() {
                    throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function un(e, t) {
                (null == t || t > e.length) && (t = e.length);
                for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
                return r
            }

            function ln(e) {
                var t = e.translate,
                    n = e.searchInput,
                    r = e.isMenuOpen,
                    a = e.openMenu,
                    o = e.closeMenu,
                    i = e.handleSearch,
                    c = e.setIsMenuHover,
                    u = e.indexOfSelectedOption,
                    l = e.onSubmit,
                    s = e.onKeyDown,
                    f = e.onKeyUp,
                    d = e.isUniverseSearchShown,
                    m = e.searchSuggestions,
                    p = e.autocompleteSessionInfo,
                    v = e.resetAutocompleteSessionInfo,
                    b = e.isAvatarAutocompleteEnabled,
                    y = (0, L.createRef)(),
                    g = (0, L.createRef)(),
                    e = function() {
                        var e;
                        be.eventStreamService.sendEvent.apply(be.eventStreamService, cn(Ft.searchClear(n, void 0, p, null === D.pageName || void 0 === D.pageName || null === (e = D.pageName.PageNameProvider) || void 0 === e ? void 0 : e.getInternalPageName()))), null == y || null !== (e = y.current) && void 0 !== e && e.focus(), i({
                            target: {
                                value: ""
                            }
                        })
                    },
                    d = x()("navbar-left navbar-search col-xs-5 col-sm-6 col-md-2 col-lg-3", {
                        "navbar-search-open": r,
                        shown: d
                    }),
                    b = Fe.isAutocompleteSuggestionsIXPTestEnabled() || b;
                return (0, _.useOnClickOutside)([y, g], o), j().createElement("div", {
                    "data-testid": "navigation-search-input",
                    className: d,
                    role: "search"
                }, j().createElement("div", {
                    className: "input-group"
                }, j().createElement("form", {
                    name: "search-form",
                    onSubmit: l,
                    action: "/search"
                }, b ? j().createElement("div", {
                    className: "form-has-feedback"
                }, j().createElement("input", {
                    ref: y,
                    id: "navbar-search-input",
                    type: "search",
                    name: "search-bar",
                    "data-testid": "navigation-search-input-field",
                    className: "form-control input-field new-input-field",
                    value: n,
                    onChange: i,
                    placeholder: t("Label.sSearch"),
                    maxLength: "120",
                    onFocus: a,
                    onKeyDown: s,
                    onKeyUp: f,
                    autoComplete: "off",
                    autoCorrect: "off",
                    autoCapitalize: "off",
                    spellCheck: "false"
                }), 0 < n.length && j().createElement("span", {
                    "data-testid": "navigation-search-input-clear-button",
                    tabIndex: 0,
                    role: "button",
                    "aria-label": "Clear Search",
                    onClick: e,
                    onKeyDown: e,
                    className: "clear-search icon-actions-clear-sm"
                }, j().createElement("span", null))) : j().createElement("input", {
                    ref: y,
                    id: "navbar-search-input",
                    type: "search",
                    name: "search-bar",
                    "data-testid": "navigation-search-input-field",
                    className: "form-control input-field",
                    value: n,
                    onChange: i,
                    placeholder: t("Label.sSearch"),
                    maxLength: "120",
                    onFocus: a,
                    onKeyDown: s,
                    onKeyUp: f,
                    autoComplete: "off"
                })), j().createElement("div", {
                    className: "input-group-btn"
                }, j().createElement("button", {
                    "data-testid": "navigation-search-input-search-button",
                    className: "input-addon-btn",
                    type: "submit"
                }, j().createElement("span", {
                    className: "icon-common-search-sm"
                })))), j().createElement("ul", {
                    ref: g,
                    className: x()("dropdown-menu", {
                        "new-dropdown-menu": b
                    }),
                    role: "menu",
                    onMouseEnter: function() {
                        c(!0)
                    },
                    onMouseLeave: function() {
                        c(!1)
                    }
                }, b ? j().createElement(on, {
                    translate: t,
                    searchInput: n,
                    indexOfSelectedOption: u,
                    searchSuggestions: m,
                    autocompleteSessionInfo: p,
                    resetAutocompleteSessionInfo: v
                }) : j().createElement(Qt, {
                    translate: t,
                    searchInput: n,
                    indexOfSelectedOption: u,
                    autocompleteSessionInfo: p,
                    resetAutocompleteSessionInfo: v
                })))
            }
            ln.defaultProps = {
                isUniverseSearchShown: !0,
                isAvatarAutocompleteEnabled: !1
            }, ln.propTypes = {
                translate: d().func.isRequired,
                searchInput: d().string.isRequired,
                isMenuOpen: d().bool.isRequired,
                openMenu: d().func.isRequired,
                closeMenu: d().func.isRequired,
                handleSearch: d().func.isRequired,
                setIsMenuHover: d().func.isRequired,
                indexOfSelectedOption: d().number.isRequired,
                onSubmit: d().func.isRequired,
                onKeyDown: d().func.isRequired,
                onKeyUp: d().func.isRequired,
                isUniverseSearchShown: d().bool,
                isAvatarAutocompleteEnabled: d().bool,
                searchSuggestions: d().arrayOf(d().oneOfType([d().shape({
                    type: d().number.isRequired,
                    score: d().number.isRequired,
                    universeId: d().number.isRequired,
                    canonicalTitle: d().string,
                    thumbnailUrl: d().string,
                    searchQuery: d().string.isRequired,
                    trendingSearchStartDateTime: d().string
                }), d().shape({
                    url: d().string.isRequired,
                    label: d().string.isRequired,
                    pageSort: d().arrayOf(d().string).isRequired,
                    icon: d().string
                }), d().shape({
                    query: d().string.isRequired,
                    score: d().number.isRequired
                })])).isRequired,
                autocompleteSessionInfo: d().string.isRequired,
                resetAutocompleteSessionInfo: d().func.isRequired
            };
            var sn = ln;

            function fn(e, t, n, r, a, o, i) {
                try {
                    var c = e[o](i),
                        u = c.value
                } catch (e) {
                    return void n(e)
                }
                c.done ? t(u) : Promise.resolve(u).then(r, a)
            }

            function dn(e) {
                return function(e) {
                    if (Array.isArray(e)) return vn(e)
                }(e) || function(e) {
                    if ("undefined" != typeof Symbol && Symbol.iterator in Object(e)) return Array.from(e)
                }(e) || pn(e) || function() {
                    throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function mn(e, t) {
                return function(e) {
                    if (Array.isArray(e)) return e
                }(e) || function(e, t) {
                    if ("undefined" == typeof Symbol || !(Symbol.iterator in Object(e))) return;
                    var n = [],
                        r = !0,
                        a = !1,
                        o = void 0;
                    try {
                        for (var i, c = e[Symbol.iterator](); !(r = (i = c.next()).done) && (n.push(i.value), !t || n.length !== t); r = !0);
                    } catch (e) {
                        a = !0, o = e
                    } finally {
                        try {
                            r || null == c.return || c.return()
                        } finally {
                            if (a) throw o
                        }
                    }
                    return n
                }(e, t) || pn(e, t) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function pn(e, t) {
                if (e) {
                    if ("string" == typeof e) return vn(e, t);
                    var n = Object.prototype.toString.call(e).slice(8, -1);
                    return "Object" === n && e.constructor && (n = e.constructor.name), "Map" === n || "Set" === n ? Array.from(e) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? vn(e, t) : void 0
                }
            }

            function vn(e, t) {
                (null == t || t > e.length) && (t = e.length);
                for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
                return r
            }

            function bn(e) {
                var t = e.translate,
                    n = e.isUniverseSearchShown,
                    r = mn((0, L.useState)(Be(window.location.search).keyword || ""), 2),
                    o = r[0],
                    a = r[1],
                    i = (0, _.useDebounce)(o, Fe.debounceTimeout),
                    u = (0, _.usePrevious)(i),
                    e = mn((0, L.useState)(null), 2),
                    c = e[0],
                    l = e[1],
                    r = mn((0, L.useState)(Ft.generateSessionInfo()), 2),
                    s = r[0],
                    f = r[1],
                    e = mn((0, L.useState)(!1), 2),
                    d = e[0],
                    m = e[1],
                    r = mn((0, L.useState)(!0), 2),
                    p = r[0],
                    v = r[1],
                    e = mn((0, L.useState)(!1), 2),
                    b = e[0],
                    r = e[1],
                    e = mn((0, L.useState)(0), 2),
                    y = e[0],
                    g = e[1],
                    e = mn((0, L.useState)(!1), 2),
                    h = e[0],
                    S = e[1],
                    e = mn((0, L.useState)(!1), 2),
                    E = e[0],
                    w = e[1],
                    C = q,
                    e = mn((0, L.useState)((Fe.isAutocompleteSuggestionsIXPTestEnabled() ? Me : De)()), 2),
                    x = e[0],
                    A = e[1],
                    N = x.findIndex(function(e) {
                        return e.label === F.gameSearchLink.label
                    }),
                    R = Me().findIndex(function(e) {
                        return e.label === F.avatarSearchLink.label
                    }),
                    O = Mt();
                (0, L.useEffect)(function() {
                    M.ExperimentationService && M.ExperimentationService.getAllValuesForLayer(Fe.experimentLayer).then(function(e) {
                        e.ixpDisableGamesAutocomplete && S(!0)
                    })
                }, []);

                function I(e) {
                    if (e) {
                        if (T) {
                            var t = -1 === c.findIndex(function(e) {
                                    return e.searchQuery === i.toLowerCase() && Ut(e)
                                }),
                                n = e.filter(function(e) {
                                    return e.searchQuery !== i.toLowerCase() || Ut(e)
                                });
                            return [].concat(dn(x.slice(0, t ? R + 1 : R)), dn(n), dn(x.slice(R + 1)))
                        }
                        if (Fe.isSpecialTreatmentAutocompleteRestricted()) return x;
                        n = -1 === e.findIndex(function(e) {
                            return e.searchQuery === i.toLowerCase() && e.type === ht.GameSuggestion
                        }), e = e.filter(function(e) {
                            return e.searchQuery !== i.toLowerCase() || e.type === ht.GameSuggestion
                        }).slice(0, Fe.isSpecialTreatment() ? Fe.numberOfSpecialTreatmentAutocompleteSuggestions : Fe.numberOfAutocompleteSuggestions());
                        return [].concat(dn(x.slice(0, n ? N + 1 : N)), dn(e), dn(x.slice(N + 1)))
                    }
                    return x
                }
                var T = _e(),
                    k = (0, L.useMemo)(function() {
                        return I(c)
                    }, [c, x]),
                    P = k.length;
                (0, L.useEffect)(function() {
                    p || be.eventStreamService.sendEvent.apply(be.eventStreamService, dn(Ft.search(o, Ft.actionTypes.submit, s))), v(!1);
                    var e = function() {
                        var c, e = (c = regeneratorRuntime.mark(function e() {
                            var t, n, r, a, o;
                            return regeneratorRuntime.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        if (!("" !== i && i.length <= Fe.debouncedSearchInputMaxLength)) {
                                            e.next = 34;
                                            break
                                        }
                                        if (l(null), t = Date.now(), T) return e.prev = 4, n = Date.now(), e.next = 8, kt(i, O, Fe.avatarAutocompleteQueryPaddingAmount, u, E);
                                        e.next = 20;
                                        break;
                                    case 8:
                                        a = e.sent, o = function(e, t) {
                                            var n = 0,
                                                r = [];
                                            return e.forEach(function(e) {
                                                n < Fe.avatarAutocompleteSuggestionLimit && e.Query !== t && (r.push(e), n += 1)
                                            }), r
                                        }(a.Data, i), be.eventStreamService.sendEvent.apply(be.eventStreamService, dn(Ft.searchAutocomplete(i, u, !1, o, a.Args.Algo, n - t, Fe.debounceTimeout, "", D.pageName.PageNameProvider.getInternalPageName(), "" !== u))), l(o), e.next = 18;
                                        break;
                                    case 14:
                                        e.prev = 14, e.t0 = e.catch(4), D.httpService.isCancelled(e.t0) || l([]), w(!0);
                                    case 18:
                                        e.next = 34;
                                        break;
                                    case 20:
                                        if (Fe.isAutocompleteSuggestionsIXPTestEnabled() && !h) return e.prev = 21, e.next = 24, Tt(i);
                                        e.next = 34;
                                        break;
                                    case 24:
                                        r = e.sent, a = Date.now(), o = I(r.entries), be.eventStreamService.sendEvent.apply(be.eventStreamService, dn(Ft.searchAutocomplete(i, u, !1, _t(o, i), r.algorithmName, a - t, Fe.debounceTimeout, s, D.pageName.PageNameProvider.getInternalPageName(), !1))), l(r.entries), e.next = 34;
                                        break;
                                    case 31:
                                        e.prev = 31, e.t1 = e.catch(21), D.httpService.isCancelled(e.t1) || l([]);
                                    case 34:
                                    case "end":
                                        return e.stop()
                                }
                            }, e, null, [
                                [4, 14],
                                [21, 31]
                            ])
                        }), function() {
                            var e = this,
                                i = arguments;
                            return new Promise(function(t, n) {
                                var r = c.apply(e, i);

                                function a(e) {
                                    fn(r, t, n, a, o, "next", e)
                                }

                                function o(e) {
                                    fn(r, t, n, a, o, "throw", e)
                                }
                                a(void 0)
                            })
                        });
                        return function() {
                            return e.apply(this, arguments)
                        }
                    }();
                    T && A(Me()), e()
                }, [i]);

                function U() {
                    f(Ft.generateSessionInfo())
                }
                return j().createElement(sn, {
                    searchInput: o,
                    handleSearch: function(e) {
                        e = e.target.value;
                        e.length < o.length && be.eventStreamService.sendEvent.apply(be.eventStreamService, dn(Ft.searchTextTrim(o, e, void 0, s))), 0 === e.length && U(), g(0), m(0 < e.length), a(e)
                    },
                    openMenu: function() {
                        var e = Ft.generateSessionInfo();
                        be.eventStreamService.sendEvent.apply(be.eventStreamService, dn(Ft.search(o, Ft.actionTypes.open, e))), f(e), 0 === o.length || b || m(!0)
                    },
                    closeMenu: function() {
                        d && (be.eventStreamService.sendEvent.apply(be.eventStreamService, dn(Ft.search(o, Ft.actionTypes.close, s))), m(!1))
                    },
                    setIsMenuHover: r,
                    isMenuOpen: d,
                    indexOfSelectedOption: y,
                    onSubmit: function(e) {
                        e.preventDefault(), e.stopPropagation()
                    },
                    onKeyDown: function(e) {
                        var t = y;
                        !d || e.keyCode !== C.arrowUp && e.keyCode !== C.arrowDown && e.keyCode !== C.tab || (e.stopPropagation(), e.preventDefault(), e.keyCode === C.arrowUp ? --t : t += 1, (t %= P) < 0 && (t = P + t), g(t))
                    },
                    onKeyUp: function(e) {
                        var t, n, r, a;
                        e.keyCode === C.enter && (e.stopPropagation(), e.preventDefault(), t = k[y], Pt(t) ? (be.eventStreamService.sendEvent.apply(be.eventStreamService, dn(Ft.searchSuggestionClicked(i, void 0, y, t.searchQuery, Lt(t), _t(k, o), s))), be.eventStreamService.sendEvent.apply(be.eventStreamService, dn(Ft.catalogSearch(1, D.pageName.PageNameProvider.getInternalPageName())))) : (be.eventStreamService.sendEvent.apply(be.eventStreamService, dn(Ft.searchSuggestionClicked(i, void 0, y, i, jt(t), _t(k, o), s))), be.eventStreamService.sendEvent.apply(be.eventStreamService, dn(Ft.catalogSearch(0, D.pageName.PageNameProvider.getInternalPageName())))), U(), (a = Dt(t, e)) && (n = Fe.isRedirectLibraryToCreatorMarketplaceEnabled, a = a, "Label.CreatorMarketplace" === t.label && n() && (a = F.creatorMarketplaceUrl, null != e && null !== (r = e.target) && void 0 !== r && r.value && (a += encodeURIComponent(e.target.value))), window.location = a))
                    },
                    isUniverseSearchShown: n,
                    translate: t,
                    searchSuggestions: k,
                    autocompleteSessionInfo: s,
                    resetAutocompleteSessionInfo: U,
                    isAvatarAutocompleteEnabled: T
                })
            }
            bn.defaultProps = {
                isUniverseSearchShown: !0
            }, bn.propTypes = {
                translate: d().func.isRequired,
                isUniverseSearchShown: d().bool
            };
            var yn = (0, _.withTranslations)(bn, s),
                o = angular,
                gn = ko.n(o);

            function hn(e) {
                return (hn = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                    return typeof e
                } : function(e) {
                    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                })(e)
            }

            function Sn(e, t) {
                for (var n = 0; n < t.length; n++) {
                    var r = t[n];
                    r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
                }
            }

            function En(e, t) {
                return (En = Object.setPrototypeOf || function(e, t) {
                    return e.__proto__ = t, e
                })(e, t)
            }

            function wn(n) {
                var r = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Date.prototype.toString.call(Reflect.construct(Date, [], function() {})), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var e, t = Cn(n);
                    return e = r ? (e = Cn(this).constructor, Reflect.construct(t, arguments, e)) : t.apply(this, arguments), t = this, !(e = e) || "object" !== hn(e) && "function" != typeof e ? function(e) {
                        if (void 0 !== e) return e;
                        throw new ReferenceError("this hasn't been initialised - super() hasn't been called")
                    }(t) : e
                }
            }

            function Cn(e) {
                return (Cn = Object.setPrototypeOf ? Object.getPrototypeOf : function(e) {
                    return e.__proto__ || Object.getPrototypeOf(e)
                })(e)
            }
            var xn = function() {
                ! function(e, t) {
                    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
                    e.prototype = Object.create(t && t.prototype, {
                        constructor: {
                            value: e,
                            writable: !0,
                            configurable: !0
                        }
                    }), t && En(e, t)
                }(a, j().Component);
                var e, t, n, r = wn(a);

                function a() {
                    return function(e) {
                        if (!(e instanceof a)) throw new TypeError("Cannot call a class as a function")
                    }(this), r.apply(this, arguments)
                }
                return e = a, (t = [{
                    key: "componentDidMount",
                    value: function() {
                        try {
                            gn().module("notificationStreamIcon"), gn().bootstrap(this.container, ["notificationStreamIcon"])
                        } catch (e) {
                            console.log(e)
                        }
                    }
                }, {
                    key: "render",
                    value: function() {
                        var t = this;
                        return j().createElement("span", {
                            ref: function(e) {
                                t.container = e
                            },
                            className: "nav-robux-icon rbx-menu-item"
                        }, j().createElement("span", {
                            id: "notification-stream-icon-container",
                            "notification-stream-indicator": "true"
                        }))
                    }
                }]) && Sn(e.prototype, t), n && Sn(e, n), a
            }();

            function An(e) {
                return (An = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                    return typeof e
                } : function(e) {
                    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                })(e)
            }

            function Nn(e, t) {
                for (var n = 0; n < t.length; n++) {
                    var r = t[n];
                    r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
                }
            }

            function Rn(e, t) {
                return (Rn = Object.setPrototypeOf || function(e, t) {
                    return e.__proto__ = t, e
                })(e, t)
            }

            function On(n) {
                var r = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Date.prototype.toString.call(Reflect.construct(Date, [], function() {})), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var e, t = In(n);
                    return e = r ? (e = In(this).constructor, Reflect.construct(t, arguments, e)) : t.apply(this, arguments), t = this, !(e = e) || "object" !== An(e) && "function" != typeof e ? function(e) {
                        if (void 0 !== e) return e;
                        throw new ReferenceError("this hasn't been initialised - super() hasn't been called")
                    }(t) : e
                }
            }

            function In(e) {
                return (In = Object.setPrototypeOf ? Object.getPrototypeOf : function(e) {
                    return e.__proto__ || Object.getPrototypeOf(e)
                })(e)
            }
            var Tn = function() {
                    ! function(e, t) {
                        if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
                        e.prototype = Object.create(t && t.prototype, {
                            constructor: {
                                value: e,
                                writable: !0,
                                configurable: !0
                            }
                        }), t && Rn(e, t)
                    }(a, j().Component);
                    var e, t, n, r = On(a);

                    function a() {
                        return function(e) {
                            if (!(e instanceof a)) throw new TypeError("Cannot call a class as a function")
                        }(this), r.apply(this, arguments)
                    }
                    return e = a, (t = [{
                        key: "componentDidMount",
                        value: function() {
                            try {
                                gn().module("notificationStream"), gn().bootstrap(this.container, ["notificationStream"])
                            } catch (e) {
                                console.log(e)
                            }
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var t = this,
                                e = qe(),
                                e = x()("notification-stream-base", e);
                            return j().createElement("div", {
                                ref: function(e) {
                                    t.container = e
                                },
                                className: e,
                                "notification-stream-base-view": "true"
                            })
                        }
                    }]) && Nn(e.prototype, t), n && Nn(e, n), a
                }(),
                kn = {
                    name: "nsCloseContent",
                    context: "click",
                    additionalProperties: {}
                };

            function Pn() {
                var e = (0, L.useRef)();
                return j().createElement("li", {
                    id: "navbar-stream",
                    ref: e,
                    className: "navbar-icon-item navbar-stream notification-margins"
                }, j().createElement(A.Popover, {
                    id: "notification-stream-popover",
                    trigger: "click",
                    placement: "bottom",
                    closeOnClick: !1,
                    button: j().createElement("button", {
                        type: "button",
                        className: "btn-uiblox-common-common-notification-bell-md"
                    }, j().createElement(xn, null)),
                    container: e.current,
                    onExit: function() {
                        window.dispatchEvent(new Event("Roblox.NotificationStream.StreamClosed")), be.eventStreamService.sendEventWithTarget(kn.name, kn.context, kn.additionalProperties)
                    },
                    role: "menu"
                }, j().createElement(Tn, null)))
            }
            Pn.propTypes = {};
            var Un = Pn;

            function Ln(e) {
                var t = e.accountNotificationCount,
                    e = x()("notification-red notification nav-setting-highlight", {
                        hidden: 0 === t
                    });
                return j().createElement("span", {
                    id: "settings-icon",
                    className: "nav-settings-icon rbx-menu-item"
                }, j().createElement("span", {
                    className: "icon-nav-settings roblox-popover-close",
                    id: "nav-settings"
                }), j().createElement("span", {
                    className: e
                }, t))
            }

            function jn() {
                return Mn(void 0, void 0, Promise, function() {
                    var t;
                    return _n(this, function(e) {
                        switch (e.label) {
                            case 0:
                                return t = {
                                    url: qn(),
                                    withCredentials: !0
                                }, [4, D.httpService.get(t)];
                            case 1:
                                return [2, e.sent().data]
                        }
                    })
                })
            }
            Ln.defaultProps = {
                accountNotificationCount: 0
            }, Ln.propTypes = {
                accountNotificationCount: d().number
            };
            var Dn = Ln,
                Mn = function(e, i, c, u) {
                    return new(c = c || Promise)(function(n, t) {
                        function r(e) {
                            try {
                                o(u.next(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function a(e) {
                            try {
                                o(u.throw(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function o(e) {
                            var t;
                            e.done ? n(e.value) : ((t = e.value) instanceof c ? t : new c(function(e) {
                                e(t)
                            })).then(r, a)
                        }
                        o((u = u.apply(e, i || [])).next())
                    })
                },
                _n = function(n, r) {
                    var a, o, i, c = {
                            label: 0,
                            sent: function() {
                                if (1 & i[0]) throw i[1];
                                return i[1]
                            },
                            trys: [],
                            ops: []
                        },
                        e = {
                            next: t(0),
                            throw: t(1),
                            return: t(2)
                        };
                    return "function" == typeof Symbol && (e[Symbol.iterator] = function() {
                        return this
                    }), e;

                    function t(t) {
                        return function(e) {
                            return function(t) {
                                if (a) throw new TypeError("Generator is already executing.");
                                for (; c;) try {
                                    if (a = 1, o && (i = 2 & t[0] ? o.return : t[0] ? o.throw || ((i = o.return) && i.call(o), 0) : o.next) && !(i = i.call(o, t[1])).done) return i;
                                    switch (o = 0, i && (t = [2 & t[0], i.value]), t[0]) {
                                        case 0:
                                        case 1:
                                            i = t;
                                            break;
                                        case 4:
                                            return c.label++, {
                                                value: t[1],
                                                done: !1
                                            };
                                        case 5:
                                            c.label++, o = t[1], t = [0];
                                            continue;
                                        case 7:
                                            t = c.ops.pop(), c.trys.pop();
                                            continue;
                                        default:
                                            if (!(i = 0 < (i = c.trys).length && i[i.length - 1]) && (6 === t[0] || 2 === t[0])) {
                                                c = 0;
                                                continue
                                            }
                                            if (3 === t[0] && (!i || t[1] > i[0] && t[1] < i[3])) {
                                                c.label = t[1];
                                                break
                                            }
                                            if (6 === t[0] && c.label < i[1]) {
                                                c.label = i[1], i = t;
                                                break
                                            }
                                            if (i && c.label < i[2]) {
                                                c.label = i[2], c.ops.push(t);
                                                break
                                            }
                                            i[2] && c.ops.pop(), c.trys.pop();
                                            continue
                                    }
                                    t = r.call(n, c)
                                } catch (e) {
                                    t = [6, e], o = 0
                                } finally {
                                    a = i = 0
                                }
                                if (5 & t[0]) throw t[1];
                                return {
                                    value: t[0] ? t[1] : void 0,
                                    done: !0
                                }
                            }([t, e])
                        }
                    }
                },
                qn = w,
                Bn = {
                    schematizedEventTypes: {
                        authButtonClick: "authButtonClick",
                        authPageLoad: "authPageLoad"
                    },
                    context: {
                        homepage: "homepage",
                        accountSwitcherStatus: "accountSwitcherStatus"
                    },
                    btn: {
                        logout: "logout",
                        switchAccount: "switchAccount"
                    }
                };

            function Fn(e, t, n, r, a, o, i) {
                try {
                    var c = e[o](i),
                        u = c.value
                } catch (e) {
                    return void n(e)
                }
                c.done ? t(u) : Promise.resolve(u).then(r, a)
            }

            function Gn(c) {
                return function() {
                    var e = this,
                        i = arguments;
                    return new Promise(function(t, n) {
                        var r = c.apply(e, i);

                        function a(e) {
                            Fn(r, t, n, a, o, "next", e)
                        }

                        function o(e) {
                            Fn(r, t, n, a, o, "throw", e)
                        }
                        a(void 0)
                    })
                }
            }

            function Vn() {
                var e = Hn("returnUrl") || window.location.href;
                return e = e === $n() || e === Jn() ? "" : e
            }

            function Kn() {
                var e = null !== M.AccountSwitcherService && void 0 !== M.AccountSwitcherService && M.AccountSwitcherService.isAccountSwitcherAvailable() ? Vn() : Hn("returnUrl") || window.location.href,
                    t = $n();
                return "".concat(t, "?").concat(Qn({
                    returnUrl: e
                }))
            }

            function Wn() {
                return de().then(Gn(regeneratorRuntime.mark(function e() {
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                window.location.reload();
                            case 1:
                            case "end":
                                return e.stop()
                        }
                    }, e)
                })))
            }
            var Hn = D.urlService.getQueryParam,
                Qn = D.urlService.composeQueryString,
                zn = H,
                $n = $,
                Xn = f,
                Yn = Q,
                Jn = m,
                Zn = r,
                r = {
                    getSignupUrl: function(e) {
                        var t, n, e = 0 < arguments.length && void 0 !== e && e;
                        return n = k.authenticatedUser.isAuthenticated && e ? (t = Vn(), Jn()) : (t = (n = (t = Hn("returnUrl") || window.location.href).toLowerCase()).startsWith($n().toLowerCase()) || n.startsWith(Xn().toLowerCase()) ? "" : t, zn()), "".concat(n, "?").concat(Qn({
                            returnUrl: t
                        }))
                    },
                    getLoginLinkUrl: Kn,
                    logoutUser: function(e) {
                        e.stopPropagation(), e.preventDefault(), document.dispatchEvent(new CustomEvent(Zn.name)), be.eventStreamService.sendEventWithTarget(Bn.schematizedEventTypes.authButtonClick, Bn.context.homepage, {
                            btn: Bn.btn.logout
                        }), gn().isUndefined(gn().element("#chat-container").scope()) || (e = gn().element("#chat-container").scope()).$digest(e.$broadcast("Roblox.Chat.destroyChatCookie")), null !== M.EmailVerificationService && void 0 !== M.EmailVerificationService && M.EmailVerificationService.handleUserEmailUpsellAtLogout(Wn).then(function(e) {
                            e && !e.emailAddress || Wn()
                        })
                    },
                    logoutAndRedirect: Wn,
                    isLoginLinkAvailable: function() {
                        var e = (null === (e = window) || void 0 === e ? void 0 : e.location).pathname,
                            e = null !== (e = null == e ? void 0 : e.toLowerCase()) && void 0 !== e ? e : "";
                        return !e.startsWith("/login") && !e.startsWith("/newlogin")
                    },
                    switchAccount: function(e) {
                        e.stopPropagation(), e.preventDefault(), e = window.location.href, be.eventStreamService.sendEventWithTarget(Bn.schematizedEventTypes.authButtonClick, Bn.context.homepage, {
                            btn: Bn.btn.switchAccount,
                            state: e.toString()
                        }), gn().isUndefined(gn().element("#chat-container").scope()) || (e = gn().element("#chat-container").scope()).$digest(e.$broadcast("Roblox.Chat.destroyChatCookie"));
                        var t = {
                            containerId: "navigation-account-switcher-container",
                            onAccountSwitched: function() {
                                be.localStorageService.setLocalStorage(B.accountSwitchedFlag, !0), window.location.href = Yn()
                            },
                            handleAddAccount: function() {
                                window.location.href = $()
                            }
                        };
                        (function() {
                            var e = Gn(regeneratorRuntime.mark(function e() {
                                return regeneratorRuntime.wrap(function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            return e.next = 2, null === M.AccountSwitcherService || void 0 === M.AccountSwitcherService ? void 0 : M.AccountSwitcherService.isAccountSwitcherAvailable();
                                        case 2:
                                            if (!e.sent) {
                                                e.next = 4;
                                                break
                                            }
                                            null === M.AccountSwitcherService || void 0 === M.AccountSwitcherService || M.AccountSwitcherService.renderAccountSwitcher(t);
                                        case 4:
                                        case "end":
                                            return e.stop()
                                    }
                                }, e)
                            }));
                            return function() {
                                return e.apply(this, arguments)
                            }
                        })()()
                    },
                    getIsVNGLandingRedirectEnabled: function() {
                        var e = Gn(regeneratorRuntime.mark(function e() {
                            var t, n;
                            return regeneratorRuntime.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        return e.prev = 0, e.next = 3, M.ExperimentationService.getAllValuesForLayer("Website.LandingPage");
                                    case 3:
                                        return t = e.sent, t = null !== (n = null == t ? void 0 : t.IsVngLandingPageRedirectEnabled) && void 0 !== n && n, e.next = 7, jn();
                                    case 7:
                                        return n = e.sent, n = n.isVNGComplianceEnabled, e.abrupt("return", n && t);
                                    case 12:
                                        return e.prev = 12, e.t0 = e.catch(0), e.abrupt("return", !1);
                                    case 15:
                                    case "end":
                                        return e.stop()
                                }
                            }, e, null, [
                                [0, 12]
                            ])
                        }));
                        return function() {
                            return e.apply(this, arguments)
                        }
                    }(),
                    navigateToLoginWithRedirect: function() {
                        window.location.href = Kn()
                    }
                },
                er = F.settingsUrl,
                tr = F.quickLoginUrl,
                nr = r.logoutUser,
                rr = r.switchAccount,
                ar = l.quickLogin,
                or = l.settings,
                ir = l.logout,
                cr = l.switchAccountKey;

            function ur(e) {
                var r = e.translate,
                    t = e.accountNotificationCount,
                    a = void 0 === t ? 0 : t,
                    o = void 0 !== (e = e.isCrossDeviceLoginCodeValidationDisplayed) && e,
                    i = x()("notification-blue notification nav-setting-highlight", {
                        hidden: 0 === a
                    }),
                    c = (null !== (e = null === M.AccountSwitcherService || void 0 === M.AccountSwitcherService ? void 0 : M.AccountSwitcherService.useIsAccountSwitcherAvailableForBrowser()) && void 0 !== e ? e : [!1])[0],
                    e = Object.entries(er).map(function(e) {
                        var t = e[0],
                            n = e[1],
                            e = n.url,
                            n = n.label;
                        return j().createElement("li", {
                            key: t
                        }, t === ir && j().createElement(A.Link, {
                            className: "rbx-menu-item logout-menu-item",
                            key: t,
                            onClick: nr,
                            url: "#"
                        }, r(n)), t === cr && c && j().createElement(A.Link, {
                            className: "rbx-menu-item account-switch-menu-item",
                            key: t,
                            onClick: rr,
                            url: "#"
                        }, r(n)), t === ar && o && j().createElement(A.Link, {
                            className: "rbx-menu-item",
                            key: t,
                            url: tr
                        }, r(n)), t !== ir && t !== ar && t !== cr && j().createElement(A.Link, {
                            cssClasses: "rbx-menu-item",
                            key: t,
                            url: e
                        }, r(n), t === or && j().createElement("span", {
                            className: i
                        }, a)))
                    });
                return j().createElement(j().Fragment, null, e)
            }

            function lr(e, t, n, r, a, o, i) {
                try {
                    var c = e[o](i),
                        u = c.value
                } catch (e) {
                    return void n(e)
                }
                c.done ? t(u) : Promise.resolve(u).then(r, a)
            }

            function sr(e, t) {
                return function(e) {
                    if (Array.isArray(e)) return e
                }(e) || function(e, t) {
                    if ("undefined" == typeof Symbol || !(Symbol.iterator in Object(e))) return;
                    var n = [],
                        r = !0,
                        a = !1,
                        o = void 0;
                    try {
                        for (var i, c = e[Symbol.iterator](); !(r = (i = c.next()).done) && (n.push(i.value), !t || n.length !== t); r = !0);
                    } catch (e) {
                        a = !0, o = e
                    } finally {
                        try {
                            r || null == c.return || c.return()
                        } finally {
                            if (a) throw o
                        }
                    }
                    return n
                }(e, t) || function(e, t) {
                    if (!e) return;
                    if ("string" == typeof e) return fr(e, t);
                    var n = Object.prototype.toString.call(e).slice(8, -1);
                    "Object" === n && e.constructor && (n = e.constructor.name);
                    if ("Map" === n || "Set" === n) return Array.from(e);
                    if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return fr(e, t)
                }(e, t) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function fr(e, t) {
                (null == t || t > e.length) && (t = e.length);
                for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
                return r
            }

            function dr(e) {
                var t = e.translate,
                    n = e.accountNotificationCount,
                    r = sr((0, L.useState)(!1), 2),
                    e = r[0],
                    a = r[1],
                    r = (0, L.useRef)();
                return (0, L.useEffect)(function() {
                    var e, t = function() {
                        var c, e = (c = regeneratorRuntime.mark(function e() {
                            return regeneratorRuntime.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        return e.prev = 0, e.next = 3, null === M.AccountSwitcherService || void 0 === M.AccountSwitcherService ? void 0 : M.AccountSwitcherService.syncAccountSwitcherBlobIfNeeded();
                                    case 3:
                                        e.next = 8;
                                        break;
                                    case 5:
                                        e.prev = 5, e.t0 = e.catch(0), console.warn("account switching has issues", e.t0);
                                    case 8:
                                    case "end":
                                        return e.stop()
                                }
                            }, e, null, [
                                [0, 5]
                            ])
                        }), function() {
                            var e = this,
                                i = arguments;
                            return new Promise(function(t, n) {
                                var r = c.apply(e, i);

                                function a(e) {
                                    lr(r, t, n, a, o, "next", e)
                                }

                                function o(e) {
                                    lr(r, t, n, a, o, "throw", e)
                                }
                                a(void 0)
                            })
                        });
                        return function() {
                            return e.apply(this, arguments)
                        }
                    }();
                    a(!0), e = !(null === M.AccountSwitcherService || void 0 === M.AccountSwitcherService || !M.AccountSwitcherService.getStoredAccountSwitcherBlob()), be.eventStreamService.sendEventWithTarget(Bn.schematizedEventTypes.authPageLoad, Bn.context.accountSwitcherStatus, {
                        state: e.toString()
                    }), t()
                }, []), j().createElement("li", {
                    id: "navbar-settings",
                    ref: r,
                    className: "navbar-icon-item"
                }, j().createElement(A.Popover, {
                    id: "settings-popover",
                    trigger: "click",
                    placement: "bottom",
                    className: qe(),
                    containerPadding: 20,
                    button: j().createElement("button", {
                        type: "button",
                        className: "btn-navigation-nav-settings-md"
                    }, j().createElement(Dn, {
                        accountNotificationCount: n
                    })),
                    container: r.current,
                    role: "menu"
                }, j().createElement("div", {
                    className: qe()
                }, j().createElement("ul", {
                    id: "settings-popover-menu",
                    className: "dropdown-menu"
                }, j().createElement(ur, {
                    isCrossDeviceLoginCodeValidationDisplayed: e,
                    translate: t,
                    accountNotificationCount: n
                })))))
            }
            dr.defaultProps = {
                accountNotificationCount: 0
            }, dr.propTypes = {
                translate: d().func.isRequired,
                accountNotificationCount: d().number
            };
            var mr = dr;

            function pr(e) {
                var t = e.robuxAmount,
                    n = e.isGetCurrencyCallDone,
                    r = e.robuxError,
                    e = e.creditDisplayConfig,
                    t = r ? g : D.abbreviateNumber.getTruncValue(t),
                    t = j().createElement(L.Fragment, null, j().createElement("span", {
                        className: "icon-robux-28x28 roblox-popover-close",
                        id: "nav-robux"
                    }), e !== U.hideCreditAndRobux && j().createElement("span", {
                        className: "rbx-text-navbar-right text-header",
                        id: "nav-robux-amount"
                    }, n && t));
                return j().createElement("span", {
                    id: "nav-robux-icon",
                    className: "nav-robux-icon rbx-menu-item"
                }, r ? j().createElement(A.Tooltip, {
                    id: "current-error",
                    content: r,
                    placement: "bottom",
                    containerClassName: "nav-buy-robux-icon-tooltip-container"
                }, t) : t)
            }
            pr.defaultProps = {
                robuxAmount: 0,
                robuxError: ""
            }, pr.propTypes = {
                robuxAmount: d().number,
                robuxError: d().string,
                isGetCurrencyCallDone: d().bool.isRequired,
                creditDisplayConfig: d().string.isRequired
            };
            var vr = pr;

            function br(e, t) {
                return function(e) {
                    if (Array.isArray(e)) return e
                }(e) || function(e, t) {
                    if ("undefined" == typeof Symbol || !(Symbol.iterator in Object(e))) return;
                    var n = [],
                        r = !0,
                        a = !1,
                        o = void 0;
                    try {
                        for (var i, c = e[Symbol.iterator](); !(r = (i = c.next()).done) && (n.push(i.value), !t || n.length !== t); r = !0);
                    } catch (e) {
                        a = !0, o = e
                    } finally {
                        try {
                            r || null == c.return || c.return()
                        } finally {
                            if (a) throw o
                        }
                    }
                    return n
                }(e, t) || function(e, t) {
                    if (!e) return;
                    if ("string" == typeof e) return yr(e, t);
                    var n = Object.prototype.toString.call(e).slice(8, -1);
                    "Object" === n && e.constructor && (n = e.constructor.name);
                    if ("Map" === n || "Set" === n) return Array.from(e);
                    if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return yr(e, t)
                }(e, t) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function yr(e, t) {
                (null == t || t > e.length) && (t = e.length);
                for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
                return r
            }
            var gr = F.buyRobuxUrl,
                hr = F.redeemUrl,
                Sr = F.buyGiftCardUrl,
                Er = new Map,
                wr = new Map;

            function Cr(e) {
                var t = e.creditAmount,
                    n = e.creditDisplayConfig,
                    r = e.creditError,
                    a = e.currencyCode,
                    o = e.isEligibleForVng,
                    i = e.robuxAmount,
                    c = e.robuxError,
                    u = e.openConvertCreditModal,
                    l = e.onBuyGiftCardClick,
                    s = e.onBuyRobuxExternalClick,
                    f = e.translate,
                    d = br((0, L.useState)(!0), 2),
                    m = d[0],
                    p = d[1],
                    v = br((0, L.useState)(!1), 2),
                    e = v[0],
                    b = v[1],
                    d = br((0, L.useState)(!1), 2),
                    v = d[0],
                    y = d[1],
                    c = c ? g : D.numberFormat.getNumberFormat(i);
                return (0, L.useEffect)(function() {
                    i < h.robuxTruncateThreshold && t < h.creditTruncateThreshold && n !== U.hideCreditAndRobux && p(!1)
                }, [i, t, n]), (0, L.useEffect)(function() {
                    window.dispatchEvent(new CustomEvent("price-tag:render", {
                        detail: {
                            targetSelector: ".dropdown-credit-balance"
                        }
                    }))
                }, [n]), (0, L.useEffect)(function() {
                    0 === t ? b(!1) : Er.has(t) ? b(Er.get(t)) : pe().then(function(e) {
                        0 < e.data.robuxConversionAmount ? (Er.set(t, !0), b(!0)) : (Er.set(t, !1), b(!1))
                    })
                }, [t]), (0, L.useEffect)(function() {
                    wr.has(Sr.cacheKey) ? y(wr.get(Sr.cacheKey)) : ve().then(function(e) {
                        e = e.data;
                        y(e.displayBuyGiftCardOption), wr.set(Sr.cacheKey, e.displayBuyGiftCardOption)
                    })
                }, []), j().createElement(L.Fragment, null, j().createElement("div", {
                    className: m ? "" : "wallet-hidden"
                }, j().createElement("li", {
                    className: "dropdown-wallet"
                }, j().createElement(A.Link, {
                    className: "dropdown-wallet-section"
                }, j().createElement("span", {
                    className: "icon-robux-28x28",
                    id: "nav-robux"
                }), j().createElement("span", {
                    id: "nav-robux-balance"
                }, c))), n !== U.control && j().createElement("li", {
                    className: "dropdown-wallet"
                }, j().createElement(A.Link, {
                    className: "dropdown-wallet-section"
                }, j().createElement("span", {
                    className: "icon-menu-wallet"
                }), r ? g : j().createElement("span", {
                    className: "dropdown-credit-balance",
                    "data-amount": t,
                    "data-currency-code": a
                }))), j().createElement("li", {
                    className: "rbx-divider"
                })), o ? j().createElement("li", null, j().createElement("button", {
                    type: "button",
                    cssClasses: "rbx-menu-item",
                    onClick: s
                }, f(gr.buyRobux.label))) : j().createElement("li", null, j().createElement(A.Link, {
                    cssClasses: "rbx-menu-item",
                    url: gr.buyRobux.url,
                    onClick: function() {
                        return e = be.paymentFlowAnalyticsService.ENUM_VIEW_MESSAGE.BUY_ROBUX, void be.paymentFlowAnalyticsService.sendUserPurchaseFlowEvent(be.paymentFlowAnalyticsService.ENUM_TRIGGERING_CONTEXT.WEB_ROBUX_PURCHASE, !1, be.paymentFlowAnalyticsService.ENUM_VIEW_NAME.NAVIGATION_DROPDOWN_MENU, be.paymentFlowAnalyticsService.ENUM_PURCHASE_EVENT_TYPE.USER_INPUT, e);
                        var e
                    }
                }, f(gr.buyRobux.label))), v && j().createElement("li", null, j().createElement("button", {
                    type: "button",
                    cssClasses: "rbx-menu-item",
                    onClick: l
                }, f(Sr.label) || "Buy Gift Card")), j().createElement("li", null, j().createElement(A.Link, {
                    cssClasses: "rbx-menu-item",
                    url: gr.myTransactions.url
                }, f(gr.myTransactions.label))), j().createElement("li", null, j().createElement(A.Link, {
                    cssClasses: "rbx-menu-item",
                    url: hr.url
                }, f(hr.label))), n !== U.control && e && j().createElement("li", null, j().createElement(A.Link, {
                    cssClasses: "rbx-menu-item",
                    onClick: u
                }, f("Label.ConvertCreditSuccess"))))
            }
            Cr.defaultProps = {
                isEligibleForVng: !1,
                robuxAmount: 0,
                robuxError: "",
                creditAmount: 0,
                currencyCode: "",
                creditError: ""
            }, Cr.propTypes = {
                isEligibleForVng: d().bool,
                translate: d().func.isRequired,
                robuxAmount: d().number,
                robuxError: d().string,
                creditAmount: d().number,
                currencyCode: d().string,
                creditError: d().string,
                creditDisplayConfig: d().string.isRequired,
                openConvertCreditModal: d().func.isRequired,
                onBuyGiftCardClick: d().func.isRequired,
                onBuyRobuxExternalClick: d().func.isRequired
            };
            var xr = Cr;

            function Ar(e) {
                var t = e.creditAmount,
                    n = e.currencyCode,
                    e = e.creditError,
                    e = j().createElement(L.Fragment, null, j().createElement("span", {
                        className: "icon-menu-wallet roblox-popover-close",
                        id: "nav-credit-icon"
                    }), j().createElement("span", {
                        className: "rbx-text-navbar-right text-header",
                        id: "nav-robux-amount"
                    }, e ? j().createElement("div", {
                        className: "nav-credit-text"
                    }, g) : j().createElement("div", {
                        className: "credit-balance",
                        "data-amount": t,
                        "data-currency-code": n
                    })));
                return (0, L.useEffect)(function() {
                    window.dispatchEvent(new CustomEvent("price-tag:render", {
                        detail: {
                            targetSelector: ".credit-balance",
                            tagClassName: "navbar-compact nav-credit-text"
                        }
                    }))
                }, [t, n]), j().createElement(L.Fragment, null, j().createElement("span", {
                    id: "nav-robux-icon",
                    className: "nav-robux-icon rbx-menu-item nav-credit"
                }, e))
            }
            Ar.defaultProps = {
                creditAmount: 0,
                creditError: "",
                currencyCode: "USD"
            }, Ar.propTypes = {
                creditAmount: d().number,
                creditError: d().string,
                currencyCode: d().string
            };
            var Nr = Ar;

            function Rr(e) {
                var t = e.translate,
                    n = e.isShopModalOpen,
                    r = e.closeShopModal,
                    a = e.onModalContinue,
                    e = j().createElement(j().Fragment, null, j().createElement("p", {
                        className: "shop-description"
                    }, t("Description.RetailWebsiteRedirect")), j().createElement("p", {
                        className: "shop-warning"
                    }, t("Description.PurchaseAgeWarning")));
                return j().createElement(A.SimpleModal, {
                    title: t("Heading.LeavingRoblox"),
                    body: e,
                    show: n,
                    actionButtonShow: !0,
                    actionButtonText: t("Action.Continue"),
                    neutralButtonText: t("Action.Cancel"),
                    onAction: a,
                    onNeutral: r,
                    onClose: r
                })
            }
            Rr.propTypes = {
                translate: d().func.isRequired,
                isShopModalOpen: d().bool.isRequired,
                closeShopModal: d().func.isRequired,
                onModalContinue: d().func.isRequired
            };
            var Or = (0, _.withTranslations)(Rr, s);

            function Ir(e) {
                var t = e.translate,
                    n = e.isOpen,
                    r = e.onClose,
                    a = e.onContinue,
                    e = j().createElement(j().Fragment, null, j().createElement("p", {
                        className: "modal-body"
                    }, t("Description.RedirectToPartnerWebsite") || "This purchase must be completed on our partner’s website. You will be returned to Roblox after the purchase is completed.\n\nProceed to partner website for payment?"));
                return j().createElement(A.SimpleModal, {
                    title: t("Heading.LeaveRoblox") || "Leaving Roblox",
                    body: e,
                    show: n,
                    actionButtonShow: !0,
                    actionButtonText: t("Action.ContinueToPayment") || "Continue to Payment",
                    neutralButtonText: t("Action.Cancel") || "Cancel",
                    onAction: a,
                    onNeutral: r,
                    onClose: r
                })
            }
            Ir.propTypes = {
                translate: d().func.isRequired,
                isOpen: d().bool.isRequired,
                onClose: d().func.isRequired,
                onContinue: d().func.isRequired
            };
            var Tr = (0, _.withTranslations)(Ir, s);

            function kr(e, t) {
                return function(e) {
                    if (Array.isArray(e)) return e
                }(e) || function(e, t) {
                    if ("undefined" == typeof Symbol || !(Symbol.iterator in Object(e))) return;
                    var n = [],
                        r = !0,
                        a = !1,
                        o = void 0;
                    try {
                        for (var i, c = e[Symbol.iterator](); !(r = (i = c.next()).done) && (n.push(i.value), !t || n.length !== t); r = !0);
                    } catch (e) {
                        a = !0, o = e
                    } finally {
                        try {
                            r || null == c.return || c.return()
                        } finally {
                            if (a) throw o
                        }
                    }
                    return n
                }(e, t) || function(e, t) {
                    if (!e) return;
                    if ("string" == typeof e) return Pr(e, t);
                    var n = Object.prototype.toString.call(e).slice(8, -1);
                    "Object" === n && e.constructor && (n = e.constructor.name);
                    if ("Map" === n || "Set" === n) return Array.from(e);
                    if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return Pr(e, t)
                }(e, t) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function Pr(e, t) {
                (null == t || t > e.length) && (t = e.length);
                for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
                return r
            }

            function Ur(e) {
                function t(e) {
                    be.paymentFlowAnalyticsService.sendUserPurchaseFlowEvent(v.WEB_ROBUX_PURCHASE, !1, b.NAVIGATION_DROPDOWN_MENU, g.USER_INPUT, e)
                }
                var n = e.creditAmount,
                    r = e.creditDisplayConfig,
                    a = e.creditError,
                    o = e.currencyCode,
                    i = e.isEligibleForVng,
                    c = e.isExperimentCallDone,
                    u = e.isGetCurrencyCallDone,
                    l = e.openConvertCreditModal,
                    s = e.robuxAmount,
                    f = e.robuxError,
                    d = e.translate,
                    m = F.buyGiftCardUrl,
                    p = F.buyRobuxUrl.buyRobuxOnVng,
                    v = be.paymentFlowAnalyticsService.ENUM_TRIGGERING_CONTEXT,
                    b = be.paymentFlowAnalyticsService.ENUM_VIEW_NAME,
                    y = be.paymentFlowAnalyticsService.ENUM_VIEW_MESSAGE,
                    g = be.paymentFlowAnalyticsService.ENUM_PURCHASE_EVENT_TYPE,
                    h = (0, L.useRef)(),
                    S = kr((0, L.useState)(!1), 2),
                    E = S[0],
                    w = S[1],
                    e = kr((0, L.useState)(!1), 2),
                    S = e[0],
                    C = e[1];
                return j().createElement("li", {
                    id: "navbar-robux",
                    ref: h,
                    className: x()("navbar-icon-item", {
                        "robux-popover-margins": r === U.hideCreditAndRobux
                    })
                }, j().createElement(Or, {
                    isShopModalOpen: E,
                    closeShopModal: function() {
                        w(!1)
                    },
                    onModalContinue: function() {
                        t(y.CONTINUE_TO_CASHSTAR);
                        var e = decodeURIComponent(m.url);
                        window.open(e, "_blank")
                    }
                }), i && j().createElement(Tr, {
                    isOpen: S,
                    onClose: function() {
                        C(!1)
                    },
                    onContinue: function() {
                        t(y.CONTINUE_TO_VNG);
                        var e = decodeURIComponent(p.url);
                        window.open(e, "_blank").focus(), C(!1)
                    }
                }), c && j().createElement(A.Popover, {
                    id: "buy-robux-popover",
                    trigger: "click",
                    placement: "bottom",
                    button: j().createElement("button", {
                        type: "button",
                        className: "btn-navigation-nav-robux-md"
                    }, j().createElement(vr, {
                        robuxAmount: s,
                        isGetCurrencyCallDone: u,
                        robuxError: f,
                        creditDisplayConfig: r
                    }), r === U.showCreditAndRobux && j().createElement(Nr, {
                        creditAmount: n,
                        currencyCode: o,
                        creditError: a
                    })),
                    role: "menu",
                    container: h.current
                }, j().createElement("div", {
                    className: qe()
                }, j().createElement("ul", {
                    id: "buy-robux-popover-menu",
                    className: "dropdown-menu"
                }, j().createElement(xr, {
                    isEligibleForVng: i,
                    translate: d,
                    robuxAmount: s,
                    robuxError: f,
                    creditAmount: n,
                    currencyCode: o,
                    creditError: a,
                    creditDisplayConfig: r,
                    openConvertCreditModal: l,
                    onBuyGiftCardClick: function() {
                        t(y.BUY_GIFT_CARD), w(!0)
                    },
                    onBuyRobuxExternalClick: function() {
                        t(y.EXTERNAL_LINK_MODAL), C(!0)
                    }
                })))))
            }
            Ur.defaultProps = {
                robuxAmount: 0,
                robuxError: "",
                creditAmount: 0,
                creditError: "",
                currencyCode: "USD",
                creditDisplayConfig: U.control,
                isExperimentCallDone: !1,
                isEligibleForVng: !1
            }, Ur.propTypes = {
                translate: d().func.isRequired,
                robuxAmount: d().number,
                robuxError: d().string,
                isGetCurrencyCallDone: d().bool.isRequired,
                creditAmount: d().number,
                currencyCode: d().string,
                creditError: d().string,
                creditDisplayConfig: d().string,
                isExperimentCallDone: d().bool,
                openConvertCreditModal: d().func.isRequired,
                isEligibleForVng: d().bool
            };
            var Lr = Ur;

            function jr(e) {
                e = e.toggleUniverseSearch;
                return j().createElement("li", {
                    className: "rbx-navbar-right-search"
                }, j().createElement("button", {
                    type: "button",
                    className: "rbx-menu-item btn-navigation-nav-search-white-md",
                    onClick: e
                }, j().createElement("span", {
                    className: "icon-nav-search-white"
                })))
            }
            jr.propTypes = {
                toggleUniverseSearch: d().func.isRequired
            };
            var Dr = jr,
                Mr = RobloxPresence;

            function _r(e, t, n, r, a, o, i) {
                try {
                    var c = e[o](i),
                        u = c.value
                } catch (e) {
                    return void n(e)
                }
                c.done ? t(u) : Promise.resolve(u).then(r, a)
            }

            function qr(e, t) {
                return function(e) {
                    if (Array.isArray(e)) return e
                }(e) || function(e, t) {
                    if ("undefined" == typeof Symbol || !(Symbol.iterator in Object(e))) return;
                    var n = [],
                        r = !0,
                        a = !1,
                        o = void 0;
                    try {
                        for (var i, c = e[Symbol.iterator](); !(r = (i = c.next()).done) && (n.push(i.value), !t || n.length !== t); r = !0);
                    } catch (e) {
                        a = !0, o = e
                    } finally {
                        try {
                            r || null == c.return || c.return()
                        } finally {
                            if (a) throw o
                        }
                    }
                    return n
                }(e, t) || function(e, t) {
                    if (!e) return;
                    if ("string" == typeof e) return Br(e, t);
                    var n = Object.prototype.toString.call(e).slice(8, -1);
                    "Object" === n && e.constructor && (n = e.constructor.name);
                    if ("Map" === n || "Set" === n) return Array.from(e);
                    if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return Br(e, t)
                }(e, t) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function Br(e, t) {
                (null == t || t > e.length) && (t = e.length);
                for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
                return r
            }

            function Fr(e) {
                var t = e.translate,
                    n = (0, L.useRef)(null),
                    r = k.authenticatedUser.isUnder13,
                    a = (0, v.currentUserHasVerifiedBadge)() && v.VerifiedBadgeIconContainer ? j().createElement("section", {
                        ref: function(e) {
                            n.current = e
                        }
                    }, j().createElement(v.VerifiedBadgeIconContainer, {
                        overrideImgClass: "verified-badge-icon-header",
                        size: v.BadgeSizes.CAPTIONHEADER
                    })) : null,
                    o = qr((0, L.useState)(!1), 2),
                    e = o[0],
                    i = o[1];
                return (0, L.useEffect)(function() {
                    function e() {
                        var c;
                        return c = regeneratorRuntime.mark(function e() {
                            var t;
                            return regeneratorRuntime.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        return e.prev = 0, e.next = 4, M.ExperimentationService.getAllValuesForLayer("Social.Friends");
                                    case 4:
                                        t = e.sent, i(null !== (t = t.invisibleModeAllowed) && void 0 !== t && t), e.next = 11;
                                        break;
                                    case 8:
                                        e.prev = 8, e.t0 = e.catch(0), console.error(e.t0);
                                    case 11:
                                    case "end":
                                        return e.stop()
                                }
                            }, e, null, [
                                [0, 8]
                            ])
                        }), (e = function() {
                            var e = this,
                                i = arguments;
                            return new Promise(function(t, n) {
                                var r = c.apply(e, i);

                                function a(e) {
                                    _r(r, t, n, a, o, "next", e)
                                }

                                function o(e) {
                                    _r(r, t, n, a, o, "throw", e)
                                }
                                a(void 0)
                            })
                        }).apply(this, arguments)
                    }! function() {
                        e.apply(this, arguments)
                    }()
                }, []), j().createElement("div", {
                    className: "age-bracket-label text-header"
                }, j().createElement(A.Link, {
                    className: "text-link dynamic-overflow-container",
                    url: F.scrollListItems.profile.url
                }, j().createElement("span", {
                    className: "avatar avatar-headshot-xs"
                }, j().createElement(p.Thumbnail2d, {
                    containerClass: "avatar-card-image",
                    targetId: k.authenticatedUser.id,
                    type: p.ThumbnailTypes.avatarHeadshot,
                    altName: k.authenticatedUser.name
                }), e && M.CurrentUser.userId && j().createElement(Mr.PresenceStatusIcon, {
                    translate: t,
                    className: "avatar-status",
                    userId: Number.parseInt(M.CurrentUser.userId, 10)
                })), j().createElement("span", {
                    className: "text-overflow age-bracket-label-username font-caption-header"
                }, ut.nameForDisplay), a), j().createElement("span", {
                    className: "xsmall age-bracket-label-age text-secondary"
                }, r ? "<13" : "13+"))
            }

            function Gr() {
                return wa(void 0, void 0, Promise, function() {
                    var t;
                    return Ca(this, function(e) {
                        return t = {
                            withCredentials: !0,
                            url: M.EnvironmentUrls.apiGatewayUrl + "/credit-balance/v1/get-next-purchasable-metadata"
                        }, [2, D.httpService.get(t)]
                    })
                })
            }

            function Vr(r) {
                return wa(void 0, void 0, Promise, function() {
                    var t, n;
                    return Ca(this, function(e) {
                        return t = {
                            paymentProviderType: "Credit",
                            providerPayload: {
                                product_id: 0 === r || null == r ? void 0 : r
                            }
                        }, n = {
                            withCredentials: !0,
                            url: M.EnvironmentUrls.apiGatewayUrl + "/payments-gateway/v1/process-payment"
                        }, [2, D.httpService.post(n, t)]
                    })
                })
            }
            Fr.propTypes = {
                translate: d().func.isRequired
            };
            var Kr = Fr,
                Wr = window.EventTracker ? EventTracker : {
                    fireEvent: console.log,
                    start: console.log,
                    endSuccess: console.log,
                    endCancel: console.log,
                    endFailure: console.log
                },
                Hr = "Label.AvailableCreditWithColon",
                Qr = "Label.BalanceDue",
                zr = "Label.CreditAfterTransaction",
                $r = "Action.Buy",
                Xr = "Action.Cancel",
                Yr = "Action.ConvertToRobux",
                Jr = "Label.ConvertCreditSuccess",
                Zr = "Heading.BuyRobuxWithCredit",
                ea = "Message.Step1LargestAvailablePackageYouCanBuy",
                ta = "Message.Step2NextLargestPackage",
                na = "Message.Step3ConvertRobux",
                ra = "Message.ConvertCreditToRobux",
                aa = "Alert.RobuxPackagePurchased",
                oa = "Alert.RobuxPackagePurchaseFailed",
                ia = "Alert.SuccessfullyConvertedCreditToRobux",
                ca = "Heading.CreditConversionFail",
                ua = "Alert.GenericFailure",
                la = "NewCreditConversionGetNextPurchasableFailedStatusCode",
                sa = "NewCreditConversionGetNextPurchasableCreditBalanceZero",
                fa = "NewCreditConversionGetNextPurchasableUnexpectedException",
                da = "NewCreditConversionGetNextPurchasableConversion",
                ma = "NewCreditConversionGetNextPurchasableProductPurchase",
                pa = "ProcessPaymentRequestFailedStatusCode",
                va = "ProcessPaymentNextStep",
                ba = "ProcessPaymentNotSuccessful",
                ya = "ProcessPaymentNotSuccessful",
                ga = "ProcessPaymentUnexpectedException",
                ha = "ConversionCancelClicked",
                Sa = "ProductPurchaseCancelClicked",
                Ea = {
                    common: ["CommonUI.Controls", "CommonUI.Features"],
                    feature: "Purchasing.RedeemGameCard"
                },
                wa = function(e, i, c, u) {
                    return new(c = c || Promise)(function(n, t) {
                        function r(e) {
                            try {
                                o(u.next(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function a(e) {
                            try {
                                o(u.throw(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function o(e) {
                            var t;
                            e.done ? n(e.value) : ((t = e.value) instanceof c ? t : new c(function(e) {
                                e(t)
                            })).then(r, a)
                        }
                        o((u = u.apply(e, i || [])).next())
                    })
                },
                Ca = function(n, r) {
                    var a, o, i, c = {
                            label: 0,
                            sent: function() {
                                if (1 & i[0]) throw i[1];
                                return i[1]
                            },
                            trys: [],
                            ops: []
                        },
                        e = {
                            next: t(0),
                            throw: t(1),
                            return: t(2)
                        };
                    return "function" == typeof Symbol && (e[Symbol.iterator] = function() {
                        return this
                    }), e;

                    function t(t) {
                        return function(e) {
                            return function(t) {
                                if (a) throw new TypeError("Generator is already executing.");
                                for (; c;) try {
                                    if (a = 1, o && (i = 2 & t[0] ? o.return : t[0] ? o.throw || ((i = o.return) && i.call(o), 0) : o.next) && !(i = i.call(o, t[1])).done) return i;
                                    switch (o = 0, i && (t = [2 & t[0], i.value]), t[0]) {
                                        case 0:
                                        case 1:
                                            i = t;
                                            break;
                                        case 4:
                                            return c.label++, {
                                                value: t[1],
                                                done: !1
                                            };
                                        case 5:
                                            c.label++, o = t[1], t = [0];
                                            continue;
                                        case 7:
                                            t = c.ops.pop(), c.trys.pop();
                                            continue;
                                        default:
                                            if (!(i = 0 < (i = c.trys).length && i[i.length - 1]) && (6 === t[0] || 2 === t[0])) {
                                                c = 0;
                                                continue
                                            }
                                            if (3 === t[0] && (!i || t[1] > i[0] && t[1] < i[3])) {
                                                c.label = t[1];
                                                break
                                            }
                                            if (6 === t[0] && c.label < i[1]) {
                                                c.label = i[1], i = t;
                                                break
                                            }
                                            if (i && c.label < i[2]) {
                                                c.label = i[2], c.ops.push(t);
                                                break
                                            }
                                            i[2] && c.ops.pop(), c.trys.pop();
                                            continue
                                    }
                                    t = r.call(n, c)
                                } catch (e) {
                                    t = [6, e], o = 0
                                } finally {
                                    a = i = 0
                                }
                                if (5 & t[0]) throw t[1];
                                return {
                                    value: t[0] ? t[1] : void 0,
                                    done: !0
                                }
                            }([t, e])
                        }
                    }
                },
                xa = "ar-",
                Aa = "en-",
                Na = ["JPY"],
                Ra = {
                    PRICE_DATA_NOT_VALID: (l = "PriceTag") + "DataNotValid",
                    NUMBER_FORMAT_LOCALE_EXCEPTION: l + "NumberFormatLocaleException",
                    ARABIC_LOCALE_TRIGGERED: l + "ArabicLocale"
                };

            function Oa(e) {
                var t = e.amount,
                    n = e.currencyCode,
                    r = e.tagClassName,
                    e = t < 0,
                    a = Math.abs(t),
                    o = "" + a + n,
                    i = x()("price-tag", r);
                try {
                    var c = (u = Intl.NumberFormat().resolvedOptions().locale).startsWith(xa) ? ((0, Wr.fireEvent)(Ra.ARABIC_LOCALE_TRIGGERED), u.replace(xa, Aa)) : u,
                        u = {
                            style: "currency",
                            currency: n,
                            notation: "standard"
                        };
                    1e4 <= a && !Na.includes(n) && (u.minimumFractionDigits = 0, u.maximumFractionDigits = 2, u.maximumSignificantDigits = 21, u.notation = "compact"), i.split(" ").includes("navbar-compact") && (u.maximumSignificantDigits = 4), o = Intl.NumberFormat(c, u).format(a)
                } catch (e) {
                    (0, Wr.fireEvent)(Ra.NUMBER_FORMAT_LOCALE_EXCEPTION)
                }
                return j().createElement("div", {
                    className: "d-flex-inline gap-1 justify-content-start align-items-center"
                }, e && j().createElement("span", {
                    className: i
                }, "-"), j().createElement("span", {
                    className: i
                }, o))
            }
            Oa.propTypes = {
                amount: d().number.isRequired,
                currencyCode: d().string.isRequired
            };
            var Ia, Ta, ka = Oa,
                Pa = function(e, i, c, u) {
                    return new(c = c || Promise)(function(n, t) {
                        function r(e) {
                            try {
                                o(u.next(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function a(e) {
                            try {
                                o(u.throw(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function o(e) {
                            var t;
                            e.done ? n(e.value) : ((t = e.value) instanceof c ? t : new c(function(e) {
                                e(t)
                            })).then(r, a)
                        }
                        o((u = u.apply(e, i || [])).next())
                    })
                },
                Ua = function(n, r) {
                    var a, o, i, c = {
                            label: 0,
                            sent: function() {
                                if (1 & i[0]) throw i[1];
                                return i[1]
                            },
                            trys: [],
                            ops: []
                        },
                        e = {
                            next: t(0),
                            throw: t(1),
                            return: t(2)
                        };
                    return "function" == typeof Symbol && (e[Symbol.iterator] = function() {
                        return this
                    }), e;

                    function t(t) {
                        return function(e) {
                            return function(t) {
                                if (a) throw new TypeError("Generator is already executing.");
                                for (; c;) try {
                                    if (a = 1, o && (i = 2 & t[0] ? o.return : t[0] ? o.throw || ((i = o.return) && i.call(o), 0) : o.next) && !(i = i.call(o, t[1])).done) return i;
                                    switch (o = 0, i && (t = [2 & t[0], i.value]), t[0]) {
                                        case 0:
                                        case 1:
                                            i = t;
                                            break;
                                        case 4:
                                            return c.label++, {
                                                value: t[1],
                                                done: !1
                                            };
                                        case 5:
                                            c.label++, o = t[1], t = [0];
                                            continue;
                                        case 7:
                                            t = c.ops.pop(), c.trys.pop();
                                            continue;
                                        default:
                                            if (!(i = 0 < (i = c.trys).length && i[i.length - 1]) && (6 === t[0] || 2 === t[0])) {
                                                c = 0;
                                                continue
                                            }
                                            if (3 === t[0] && (!i || t[1] > i[0] && t[1] < i[3])) {
                                                c.label = t[1];
                                                break
                                            }
                                            if (6 === t[0] && c.label < i[1]) {
                                                c.label = i[1], i = t;
                                                break
                                            }
                                            if (i && c.label < i[2]) {
                                                c.label = i[2], c.ops.push(t);
                                                break
                                            }
                                            i[2] && c.ops.pop(), c.trys.pop();
                                            continue
                                    }
                                    t = r.call(n, c)
                                } catch (e) {
                                    t = [6, e], o = 0
                                } finally {
                                    a = i = 0
                                }
                                if (5 & t[0]) throw t[1];
                                return {
                                    value: t[0] ? t[1] : void 0,
                                    done: !0
                                }
                            }([t, e])
                        }
                    }
                },
                La = (l = (m = (0, A.createModal)(), Ia = m[0], [function(e) {
                    var t = e.availableBalance,
                        n = e.totalBalanceDue,
                        r = e.currencyCode,
                        a = e.numberOfPurchase,
                        o = e.robuxAmountInPackage,
                        i = e.loading,
                        c = e.onNeutral,
                        u = e.onPurchase,
                        e = e.translate;
                    return j().createElement(Ia, {
                        id: "purchase-product-modal",
                        title: e(Zr),
                        body: j().createElement("div", {
                            className: "d-flex justify-content-center flex-direction-column text-center"
                        }, j().createElement("div", {
                            className: "purchase-prompt"
                        }, 1 === a ? e(ea) || "Largest package you can buy with your available credit:" : e(ta)), j().createElement("div", {
                            className: "purchase-logo"
                        }, j().createElement("div", {
                            className: x()("robux-product-logo", "margin-auto", "robux-graphic", "robux-" + o)
                        }), j().createElement("div", null, j().createElement("span", {
                            className: "icon-robux-16x16"
                        }), j().createElement("span", {
                            className: "text-robux"
                        }, o))), j().createElement("div", {
                            className: "purchase-summary d-flex flex-direction-column text-left"
                        }, j().createElement("div", {
                            className: "available-credit d-flex justify-content-between"
                        }, j().createElement("span", null, e(Hr)), j().createElement(ka, {
                            amount: t,
                            currencyCode: r
                        })), j().createElement("div", {
                            className: "balance-due d-flex justify-content-between"
                        }, j().createElement("span", null, e(Qr)), j().createElement(ka, {
                            amount: -1 * n,
                            currencyCode: r
                        })), j().createElement("div", {
                            className: "rbx-divider"
                        }), j().createElement("div", {
                            className: "credit-after-transaction d-flex justify-content-between"
                        }, j().createElement("span", null, e(zr)), j().createElement(ka, {
                            amount: t - n,
                            currencyCode: r
                        })))),
                        neutralButtonText: e(Xr),
                        actionButtonText: e($r),
                        onNeutral: c,
                        onAction: u,
                        loading: i,
                        actionButtonShow: !0
                    })
                }, m[1]]))[0],
                ja = l[1],
                Da = (l = (m = (0, A.createModal)(), Ta = m[0], [function(e) {
                    var t = e.remainingCreditBalance,
                        n = e.currencyCode,
                        r = e.robuxConversionAmount,
                        a = e.loading,
                        o = e.numberOfPurchase,
                        i = e.onConvert,
                        c = e.onNeutral,
                        e = e.translate,
                        r = j().createElement("div", {
                            className: "text-center conversion-message",
                            dangerouslySetInnerHTML: {
                                __html: 1 === o ? e(ra, {
                                    robuxAmount: '<br /><span class="icon-robux-16x16"></span>' + r
                                }) : e(na, {
                                    remainingCreditBalance: "<span class='fiat-price-tag ml-1' data-amount=" + t + " data-currency-code=" + n + "></span>",
                                    lineBreaker: "<br />",
                                    robuxConversionAmount: '<span class="icon-robux-16x16"></span>' + r
                                })
                            },
                            ref: function() {
                                window.dispatchEvent(new CustomEvent("price-tag:render", {
                                    detail: {
                                        targetSelector: ".fiat-price-tag"
                                    }
                                }))
                            }
                        });
                    return j().createElement(Ta, {
                        id: "convert-credit-modal",
                        title: e(Jr),
                        body: r,
                        neutralButtonText: e(Xr),
                        actionButtonText: e(Yr),
                        onNeutral: c,
                        onAction: i,
                        loading: a,
                        actionButtonShow: !0
                    })
                }, m[1]]))[0],
                Ma = l[1],
                _a = function(e) {
                    function a() {
                        f.warning(d(ua) || "Something went wrong! Please try again later."), ja.close(), Ma.close(), window.location.href = D.urlService.getAbsoluteUrl("/upgrades/robux")
                    }

                    function o(e, t) {
                        t = 0 === t || null == t, e ? f.success(d(t ? ia : aa)) : f.warning(d(t ? ca : oa) || d(ua) || "Something went wrong! Please try again later.")
                    }

                    function i() {
                        return Pa(t, void 0, void 0, function() {
                            var t;
                            return Ua(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        w(!0), e.label = 1;
                                    case 1:
                                        return e.trys.push([1, 3, 4, 5]), [4, Gr()];
                                    case 2:
                                        return 200 !== (t = e.sent()).status ? (f.warning(d(ua) || "Something went wrong! Please try again later."), w(!1), (0, Wr.fireEvent)(la), (0, Wr.fireEvent)("" + la + t.status), [2]) : 0 === (t = t.data).creditBalance || 0 === t.productId && 0 === t.robuxConversionAmount ? (w(!1), Ma.close(), ja.close(), r(t.creditBalance), (0, Wr.fireEvent)(sa), [2]) : (r(t.creditBalance), u(t.currencyCode), s(t.robuxConversionAmount), p(t.productId), g(t.balanceDue), S(t.robuxAmountProductGrant), 0 === t.productId ? (Ma.open(), ja.close(), (0, Wr.fireEvent)(da)) : (ja.open(), (0, Wr.fireEvent)(ma)), [3, 5]);
                                    case 3:
                                        return e.sent(), a(), (0, Wr.fireEvent)(fa), [3, 5];
                                    case 4:
                                        return w(!1), [7];
                                    case 5:
                                        return [2]
                                }
                            })
                        })
                    }
                    var t = this,
                        n = e.creditBalance,
                        r = e.setCreditBalance,
                        c = e.currencyCode,
                        u = e.setCurrencyCode,
                        l = e.convertedRobuxAmount,
                        s = e.setConvertedRobuxAmount,
                        f = e.systemFeedbackService,
                        d = e.translate,
                        m = (e = (0, L.useState)(0))[0],
                        p = e[1],
                        v = (e = (0, L.useState)(0))[0],
                        b = e[1],
                        y = (e = (0, L.useState)(0))[0],
                        g = e[1],
                        h = (e = (0, L.useState)(0))[0],
                        S = e[1],
                        E = (e = (0, L.useState)(!1))[0],
                        w = e[1],
                        C = function() {
                            return Pa(t, void 0, void 0, function() {
                                var t, n, r;
                                return Ua(this, function(e) {
                                    switch (e.label) {
                                        case 0:
                                            w(!0), e.label = 1;
                                        case 1:
                                            return e.trys.push([1, 6, 7, 8]), [4, Vr(m)];
                                        case 2:
                                            return 200 !== (t = e.sent()).status ? (o(!1, m), w(!1), (0, Wr.fireEvent)(pa), (0, Wr.fireEvent)("" + pa + t.status), [2]) : (n = t.data, o(n.isSuccess, m), n.isSuccess && null !== (r = n.providerPayload) && void 0 !== r && r.IsSuccessful ? [4, i()] : [3, 4]);
                                        case 3:
                                            return e.sent(), b(v + 1), (0, Wr.fireEvent)(va), [3, 5];
                                        case 4:
                                            ja.close(), Ma.close(), (0, Wr.fireEvent)(ba), e.label = 5;
                                        case 5:
                                            return (0, Wr.fireEvent)(ya + n.providerPayload.ResponseMessage), [3, 8];
                                        case 6:
                                            return e.sent(), a(), (0, Wr.fireEvent)(ga), [3, 8];
                                        case 7:
                                            return w(!1), [7];
                                        case 8:
                                            return [2]
                                    }
                                })
                            })
                        };
                    return [(0, _.withTranslations)(function() {
                        function e() {
                            0 === m ? (Ma.close(), (0, Wr.fireEvent)(ha)) : (ja.close(), (0, Wr.fireEvent)(Sa))
                        }
                        return j().createElement(L.Fragment, null, j().createElement(La, {
                            availableBalance: n,
                            totalBalanceDue: y,
                            currencyCode: c,
                            numberOfPurchase: v,
                            robuxAmountInPackage: h,
                            onPurchase: function() {
                                C()
                            },
                            onNeutral: e,
                            loading: E,
                            translate: d
                        }), j().createElement(Da, {
                            remainingCreditBalance: n,
                            currencyCode: c,
                            robuxConversionAmount: l,
                            numberOfPurchase: v,
                            onConvert: function() {
                                C()
                            },
                            onNeutral: e,
                            loading: E,
                            translate: d
                        }))
                    }, Ea), function() {
                        b(0), i(), b(1)
                    }]
                };

            function qa(e, t) {
                return function(e) {
                    if (Array.isArray(e)) return e
                }(e) || function(e, t) {
                    if ("undefined" == typeof Symbol || !(Symbol.iterator in Object(e))) return;
                    var n = [],
                        r = !0,
                        a = !1,
                        o = void 0;
                    try {
                        for (var i, c = e[Symbol.iterator](); !(r = (i = c.next()).done) && (n.push(i.value), !t || n.length !== t); r = !0);
                    } catch (e) {
                        a = !0, o = e
                    } finally {
                        try {
                            r || null == c.return || c.return()
                        } finally {
                            if (a) throw o
                        }
                    }
                    return n
                }(e, t) || function(e, t) {
                    if (!e) return;
                    if ("string" == typeof e) return Ba(e, t);
                    var n = Object.prototype.toString.call(e).slice(8, -1);
                    "Object" === n && e.constructor && (n = e.constructor.name);
                    if ("Map" === n || "Set" === n) return Array.from(e);
                    if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return Ba(e, t)
                }(e, t) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function Ba(e, t) {
                (null == t || t > e.length) && (t = e.length);
                for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
                return r
            }
            var Fa = E,
                Ga = (E = qa((0, A.createSystemFeedback)(), 2))[0],
                Va = E[1];

            function Ka(e) {
                function t() {
                    a && (f(!1), ce(o).then(function(e) {
                        e = e.data;
                        p(e.robux)
                    }, function() {
                        C(n(P))
                    }).finally(function() {
                        f(!0)
                    }))
                }
                var n = e.translate,
                    r = e.toggleUniverseSearch,
                    a = k.authenticatedUser.isAuthenticated,
                    o = k.authenticatedUser.id,
                    i = qa((0, L.useState)(0), 2),
                    c = i[0],
                    u = i[1],
                    l = qa((0, L.useState)(!1), 2),
                    s = l[0],
                    f = l[1],
                    d = qa((0, L.useState)(0), 2),
                    m = d[0],
                    p = d[1],
                    v = qa((0, L.useState)(!1), 2),
                    b = v[0],
                    y = v[1],
                    g = qa((0, L.useState)(!0), 2),
                    h = g[0],
                    S = g[1],
                    E = qa((0, L.useState)(""), 2),
                    w = E[0],
                    C = E[1],
                    e = qa((0, L.useState)(U.control), 2),
                    i = e[0],
                    x = e[1],
                    l = qa((0, L.useState)(null), 2),
                    d = l[0],
                    A = l[1],
                    v = qa((0, L.useState)(null), 2),
                    g = v[0],
                    N = v[1],
                    E = qa((0, L.useState)(""), 2),
                    e = E[0],
                    R = E[1],
                    l = qa((0, L.useState)(!1), 2),
                    v = l[0],
                    O = l[1],
                    E = qa((0, L.useState)(0), 2),
                    l = E[0],
                    E = E[1],
                    l = qa(_a({
                        creditBalance: d,
                        setCreditBalance: A,
                        currencyCode: g,
                        setCurrencyCode: N,
                        convertedRobuxAmount: l,
                        setConvertedRobuxAmount: E,
                        systemFeedbackService: Va,
                        translate: n
                    }), 2),
                    E = l[0],
                    I = l[1];
                (0, L.useEffect)(function() {
                    window.addEventListener("navigation-update-user-currency", function(e) {
                        t()
                    })
                }, []), (0, L.useEffect)(function() {
                    if (a) {
                        Fa().then(u), t(), a && ue().then(function(e) {
                            e = e.data;
                            y(e.shouldShowVng), S(e.notificationsCanAccessStream)
                        }, function() {
                            C(n(P))
                        }), me().then(function(e) {
                            var t = e.data;
                            null === t.creditDisplayConfig || null === t.creditBalance || null === t.currencyCode ? x(U.control) : x(null !== (e = t.creditDisplayConfig) && void 0 !== e ? e : U.control), A(t.creditBalance), N(t.currencyCode)
                        }, function() {
                            R(n(P))
                        }).finally(function() {
                            O(!0)
                        });
                        try {
                            be.localStorageService.getLocalStorage(B.accountSwitchedFlag) && (Va.success(n(B.accountSwitchedMessage, {
                                accountName: k.authenticatedUser.name
                            }), 0, 5e3), be.localStorageService.removeLocalStorage(B.accountSwitchedFlag))
                        } catch (e) {}
                    }
                }, [a, o]);
                var T = j().createElement("li", {
                    id: "navbar-stream",
                    className: "navbar-icon-item navbar-stream"
                }, j().createElement("span", {
                    className: "nav-robux-icon rbx-menu-item"
                }, j().createElement("span", {
                    id: "notification-stream-icon-container",
                    "notification-stream-indicator": "true"
                })));
                try {
                    gn().module("notificationStreamIcon"), gn().module("notificationStream"), T = j().createElement(Un, null)
                } catch (e) {
                    console.log(e)
                }
                return j().createElement("ul", {
                    className: "nav navbar-right rbx-navbar-icon-group"
                }, j().createElement(Ga, null), j().createElement(Kr, {
                    translate: n
                }), j().createElement(Dr, {
                    translate: n,
                    toggleUniverseSearch: r
                }), h && T, j().createElement(Lr, {
                    translate: n,
                    robuxAmount: m,
                    robuxError: w,
                    creditAmount: d,
                    currencyCode: g,
                    creditError: e,
                    creditDisplayConfig: i,
                    isEligibleForVng: b,
                    isExperimentCallDone: v,
                    isGetCurrencyCallDone: s,
                    openConvertCreditModal: function() {
                        I()
                    }
                }), j().createElement(mr, {
                    translate: n,
                    accountNotificationCount: c
                }), j().createElement(E, null))
            }
            Ka.defaultProps = {
                accountNotificationCount: 0
            }, Ka.propTypes = {
                translate: d().func.isRequired,
                accountNotificationCount: d().number,
                toggleUniverseSearch: d().func.isRequired
            };
            var Wa = (0, _.withTranslations)(Ka, {
                common: ["CommonUI.Features", "Common.AlertsAndOptions"],
                feature: "Purchasing.RedeemGameCard"
            });

            function Ha(e, t, n, r, a, o, i) {
                try {
                    var c = e[o](i),
                        u = c.value
                } catch (e) {
                    return void n(e)
                }
                c.done ? t(u) : Promise.resolve(u).then(r, a)
            }

            function Qa(e, t) {
                return function(e) {
                    if (Array.isArray(e)) return e
                }(e) || function(e, t) {
                    if ("undefined" == typeof Symbol || !(Symbol.iterator in Object(e))) return;
                    var n = [],
                        r = !0,
                        a = !1,
                        o = void 0;
                    try {
                        for (var i, c = e[Symbol.iterator](); !(r = (i = c.next()).done) && (n.push(i.value), !t || n.length !== t); r = !0);
                    } catch (e) {
                        a = !0, o = e
                    } finally {
                        try {
                            r || null == c.return || c.return()
                        } finally {
                            if (a) throw o
                        }
                    }
                    return n
                }(e, t) || function(e, t) {
                    if (!e) return;
                    if ("string" == typeof e) return za(e, t);
                    var n = Object.prototype.toString.call(e).slice(8, -1);
                    "Object" === n && e.constructor && (n = e.constructor.name);
                    if ("Map" === n || "Set" === n) return Array.from(e);
                    if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return za(e, t)
                }(e, t) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function za(e, t) {
                (null == t || t > e.length) && (t = e.length);
                for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
                return r
            }
            var $a = r.getSignupUrl,
                Xa = r.getIsVNGLandingRedirectEnabled;

            function Ya(e) {
                var t = e.translate,
                    n = Qa((0, L.useState)(!1), 2),
                    e = n[0],
                    r = n[1],
                    a = Qa(null !== (n = null === M.AccountSwitcherService || void 0 === M.AccountSwitcherService ? void 0 : M.AccountSwitcherService.useIsAccountSwitcherAvailableForBrowser()) && void 0 !== n ? n : [!1], 1)[0];
                return (0, L.useEffect)(function() {
                    try {
                        (0, be.dataStores.authIntentDataStore.saveGameIntentFromCurrentUrl)()
                    } catch (e) {
                        console.error("Failed to save game intent from current url", e)
                    }
                }, []), (0, L.useEffect)(function() {
                    (function() {
                        var c, e = (c = regeneratorRuntime.mark(function e() {
                            var t;
                            return regeneratorRuntime.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        return e.prev = 0, e.next = 3, Xa();
                                    case 3:
                                        t = e.sent, r(!t), e.next = 10;
                                        break;
                                    case 7:
                                        e.prev = 7, e.t0 = e.catch(0), r(!0);
                                    case 10:
                                    case "end":
                                        return e.stop()
                                }
                            }, e, null, [
                                [0, 7]
                            ])
                        }), function() {
                            var e = this,
                                i = arguments;
                            return new Promise(function(t, n) {
                                var r = c.apply(e, i);

                                function a(e) {
                                    Ha(r, t, n, a, o, "next", e)
                                }

                                function o(e) {
                                    Ha(r, t, n, a, o, "throw", e)
                                }
                                a(void 0)
                            })
                        });
                        return function() {
                            return e.apply(this, arguments)
                        }
                    })()()
                }, []), e && j().createElement("li", {
                    className: "signup-button-container"
                }, j().createElement(A.Link, {
                    onClick: function() {
                        window.location.href = $a(a)
                    },
                    url: $a(a),
                    id: "sign-up-button",
                    className: "rbx-navbar-signup btn-growth-sm nav-menu-title signup-button"
                }, t("Label.sSignUp")))
            }

            function Ja() {
                window.location.href = to()
            }
            Ya.propTypes = {
                translate: d().func.isRequired
            };
            var Za = Ya,
                eo = r.isLoginLinkAvailable,
                to = r.getLoginLinkUrl;

            function no(e) {
                e = e.translate;
                return j().createElement("li", {
                    className: "login-action"
                }, eo() && j().createElement(A.Link, {
                    onClick: Ja,
                    url: to(),
                    className: "rbx-navbar-login btn-secondary-sm nav-menu-title rbx-menu-item"
                }, e("Label.sLogin")))
            }
            no.propTypes = {
                translate: d().func.isRequired
            };
            var ro = no;

            function ao() {
                return (ao = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n, r = arguments[t];
                        for (n in r) Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n])
                    }
                    return e
                }).apply(this, arguments)
            }

            function oo(e, t) {
                if (null == e) return {};
                var n, r = function(e, t) {
                    if (null == e) return {};
                    var n, r, a = {},
                        o = Object.keys(e);
                    for (r = 0; r < o.length; r++) n = o[r], 0 <= t.indexOf(n) || (a[n] = e[n]);
                    return a
                }(e, t);
                if (Object.getOwnPropertySymbols)
                    for (var a = Object.getOwnPropertySymbols(e), o = 0; o < a.length; o++) n = a[o], 0 <= t.indexOf(n) || Object.prototype.propertyIsEnumerable.call(e, n) && (r[n] = e[n]);
                return r
            }

            function io(e) {
                var t = e.translate,
                    n = e.toggleUniverseSearch,
                    e = oo(e, ["translate", "toggleUniverseSearch"]);
                return k.authenticatedUser.isAuthenticated ? j().createElement("div", {
                    className: "navbar-right rbx-navbar-right"
                }, j().createElement(Wa, ao({
                    translate: t,
                    toggleUniverseSearch: n
                }, e))) : j().createElement("div", {
                    className: "navbar-right rbx-navbar-right"
                }, j().createElement("ul", {
                    className: "nav navbar-right rbx-navbar-right-nav"
                }, j().createElement(Za, {
                    translate: t
                }), j().createElement(ro, {
                    translate: t
                }), j().createElement(Dr, {
                    translate: t,
                    toggleUniverseSearch: n
                })))
            }
            io.propTypes = {
                translate: d().func.isRequired,
                toggleUniverseSearch: d().func.isRequired
            };
            var co = io;

            function uo() {
                return (uo = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n, r = arguments[t];
                        for (n in r) Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n])
                    }
                    return e
                }).apply(this, arguments)
            }

            function lo(e, t) {
                return function(e) {
                    if (Array.isArray(e)) return e
                }(e) || function(e, t) {
                    if ("undefined" == typeof Symbol || !(Symbol.iterator in Object(e))) return;
                    var n = [],
                        r = !0,
                        a = !1,
                        o = void 0;
                    try {
                        for (var i, c = e[Symbol.iterator](); !(r = (i = c.next()).done) && (n.push(i.value), !t || n.length !== t); r = !0);
                    } catch (e) {
                        a = !0, o = e
                    } finally {
                        try {
                            r || null == c.return || c.return()
                        } finally {
                            if (a) throw o
                        }
                    }
                    return n
                }(e, t) || function(e, t) {
                    if (!e) return;
                    if ("string" == typeof e) return so(e, t);
                    var n = Object.prototype.toString.call(e).slice(8, -1);
                    "Object" === n && e.constructor && (n = e.constructor.name);
                    if ("Map" === n || "Set" === n) return Array.from(e);
                    if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return so(e, t)
                }(e, t) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function so(e, t) {
                (null == t || t > e.length) && (t = e.length);
                for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
                return r
            }
            var fo = (0, _.withTranslations)(function(e) {
                var t = je(),
                    n = lo((0, L.useState)(t), 2),
                    r = n[0],
                    a = n[1],
                    t = (n = lo((0, L.useState)(!t), 2))[0],
                    o = n[1],
                    i = (0, L.useCallback)(function() {
                        var e = je();
                        r !== e && (a(e), o(!e))
                    }, [r]);
                return (0, L.useEffect)(function() {
                    return window.addEventListener("resize", i),
                        function() {
                            window.removeEventListener("resize", i)
                        }
                }, [i]), j().createElement(j().Fragment, null, j().createElement(yn, uo({
                    isUniverseSearchShown: t
                }, e)), j().createElement(co, uo({
                    toggleUniverseSearch: function() {
                        o(function(e) {
                            return !e
                        })
                    }
                }, e)))
            }, s);

            function mo(e, t) {
                return function(e) {
                    if (Array.isArray(e)) return e
                }(e) || function(e, t) {
                    if ("undefined" == typeof Symbol || !(Symbol.iterator in Object(e))) return;
                    var n = [],
                        r = !0,
                        a = !1,
                        o = void 0;
                    try {
                        for (var i, c = e[Symbol.iterator](); !(r = (i = c.next()).done) && (n.push(i.value), !t || n.length !== t); r = !0);
                    } catch (e) {
                        a = !0, o = e
                    } finally {
                        try {
                            r || null == c.return || c.return()
                        } finally {
                            if (a) throw o
                        }
                    }
                    return n
                }(e, t) || function(e, t) {
                    if (!e) return;
                    if ("string" == typeof e) return po(e, t);
                    var n = Object.prototype.toString.call(e).slice(8, -1);
                    "Object" === n && e.constructor && (n = e.constructor.name);
                    if ("Map" === n || "Set" === n) return Array.from(e);
                    if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return po(e, t)
                }(e, t) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function po(e, t) {
                (null == t || t > e.length) && (t = e.length);
                for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
                return r
            }

            function vo(e) {
                function t(e) {
                    be.paymentFlowAnalyticsService.sendUserPurchaseFlowEvent(c.WEB_ROBUX_PURCHASE, !1, u.NAVIGATION_ROBUX_TEXT, s.USER_INPUT, e)
                }
                var n = e.translate,
                    r = F.buyRobuxUrl,
                    a = r.buyRobux,
                    o = r.buyRobuxOnVng,
                    i = k.authenticatedUser.isAuthenticated,
                    c = be.paymentFlowAnalyticsService.ENUM_TRIGGERING_CONTEXT,
                    u = be.paymentFlowAnalyticsService.ENUM_VIEW_NAME,
                    l = be.paymentFlowAnalyticsService.ENUM_VIEW_MESSAGE,
                    s = be.paymentFlowAnalyticsService.ENUM_PURCHASE_EVENT_TYPE,
                    f = mo((0, L.useState)(!1), 2),
                    e = f[0],
                    d = f[1],
                    r = mo((0, L.useState)(!1), 2),
                    f = r[0],
                    m = r[1],
                    p = (0, L.useRef)(new Map);
                (0, L.useEffect)(function() {
                    var t = p.current,
                        n = o.cacheKey;
                    t.has(n) ? d(t.get(n)) : i && ue().then(function(e) {
                        e = e.data.shouldShowVng;
                        d(e), t.set(n, e)
                    })
                }, [o, o.cacheKey, i]);
                return j().createElement("div", null, e ? j().createElement(j().Fragment, null, j().createElement(Tr, {
                    isOpen: f,
                    onClose: function() {
                        m(!1)
                    },
                    onContinue: function() {
                        t(l.CONTINUE_TO_VNG);
                        var e = decodeURIComponent(o.url);
                        window.open(e, "_blank").focus(), m(!1)
                    }
                }), j().createElement(A.Link, {
                    cssClasses: "font-header-2 nav-menu-title text-header robux-menu-btn",
                    onClick: function() {
                        t(l.EXTERNAL_LINK_MODAL), m(!0)
                    }
                }, n(a.name))) : j().createElement(A.Link, {
                    cssClasses: "font-header-2 nav-menu-title text-header robux-menu-btn",
                    url: a.url,
                    onClick: function() {
                        return t(l.BUY_ROBUX)
                    }
                }, n(a.name)))
            }
            vo.propTypes = {
                translate: d().func.isRequired
            };
            var bo = (0, _.withTranslations)(vo, s),
                E = function() {
                    var e = document.getElementById("header-develop-md-link"),
                        t = document.getElementById("header-develop-sm-link");
                    null !== e && (e.href = "https://create.".concat(M.EnvironmentUrls.domain, "/")), null !== t && (t.href = "https://create.".concat(M.EnvironmentUrls.domain, "/"))
                },
                yo = n;

            function go(e) {
                var e = e.translate,
                    t = document.getElementById(yo);
                return j().createElement(A.Button, {
                    id: "skip-to-main-content",
                    size: A.Button.sizes.extraSmall,
                    variant: A.Button.variants.primary,
                    onClick: function() {
                        return t.focus()
                    }
                }, e("Action.SkipToMainContent") || "Skip to main content")
            }
            go.propTypes = {
                translate: d().func.isRequired
            };
            var ho = go,
                So = u,
                Eo = k.authenticatedUser.isAuthenticated;

            function wo(e) {
                var t = A.IconButton.iconTypes;
                return j().createElement(L.Fragment, null, j().createElement(ho, e), Eo && j().createElement(A.IconButton, {
                    className: "menu-button",
                    iconType: t.navigation,
                    iconName: "nav-menu",
                    onClick: function() {
                        document.dispatchEvent(new CustomEvent(So.name))
                    }
                }))
            }
            wo.propTypes = {};
            var Co = (0, _.withTranslations)(wo, s);

            function xo(t, e) {
                var n, r = Object.keys(t);
                return Object.getOwnPropertySymbols && (n = Object.getOwnPropertySymbols(t), e && (n = n.filter(function(e) {
                    return Object.getOwnPropertyDescriptor(t, e).enumerable
                })), r.push.apply(r, n)), r
            }

            function Ao(r) {
                for (var e = 1; e < arguments.length; e++) {
                    var a = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? xo(Object(a), !0).forEach(function(e) {
                        var t, n;
                        t = r, e = a[n = e], n in t ? Object.defineProperty(t, n, {
                            value: e,
                            enumerable: !0,
                            configurable: !0,
                            writable: !0
                        }) : t[n] = e
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(r, Object.getOwnPropertyDescriptors(a)) : xo(Object(a)).forEach(function(e) {
                        Object.defineProperty(r, e, Object.getOwnPropertyDescriptor(a, e))
                    })
                }
                return r
            }
            ko(226);
            var u = r.logoutAndRedirect,
                s = r.getIsVNGLandingRedirectEnabled,
                r = r.navigateToLoginWithRedirect,
                No = "right-navigation-header",
                Ro = "left-navigation-container",
                Oo = "header-menu-icon",
                Io = "navigation-robux-container",
                To = "navigation-robux-mobile-container";
            t().NavigationService = Ao(Ao({}, t().NavigationService), {}, {
                logoutAndRedirect: u,
                getIsVNGLandingRedirectEnabled: s,
                navigateToLoginWithRedirect: r
            }), E(), (0, D.ready)(function() {
                document.getElementById(Oo) && (0, e.render)(j().createElement(Co, null), document.getElementById(Oo)), document.getElementById(Io) && (0, e.render)(j().createElement(bo, null), document.getElementById(Io)), document.getElementById(To) && (0, e.render)(j().createElement(bo, null), document.getElementById(To)), document.getElementById(No) && (0, e.render)(j().createElement(fo, null), document.getElementById(No)), document.getElementById(Ro) && (0, e.render)(j().createElement(Et, null), document.getElementById(Ro))
            })
        }()
}();
//# sourceMappingURL=https://js.rbxcdn.com/5b0e5d36695c6af0f4bb964a515af88a-navigation.bundle.min.js.map

/* Bundle detector */
window.Roblox && window.Roblox.BundleDetector && window.Roblox.BundleDetector.bundleDetected("Navigation");