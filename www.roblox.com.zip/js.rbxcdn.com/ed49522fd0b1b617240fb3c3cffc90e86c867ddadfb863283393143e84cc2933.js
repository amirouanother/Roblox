var Roblox = Roblox || {};
Roblox.LangDynamicDefault = Roblox.LangDynamicDefault || {};
Roblox.LangDynamicDefault["Feature.RostileChallenge"] = {
    "Description.VerificationSuccess": "Verification Complete",
    "Description.VerificationError": "Verification failed because of an issue. Please try again.",
    "Description.VerificationPrompt": "To proceed, first verify you are human.",
    "Description.VerificationHeader": "Complete Verification",
    "Description.VerificationErrorHeader": "Verification Failed",
    "Description.Ok": "OK",
    "Description.ImAHuman": "Start Verification"
};
window.Roblox && window.Roblox.BundleDetector && window.Roblox.BundleDetector.bundleDetected("DynamicLocalizationResourceScript_Feature.RostileChallenge");