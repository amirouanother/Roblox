! function() {
    "use strict";
    var n = {
            n: function(e) {
                var t = e && e.__esModule ? function() {
                    return e.default
                } : function() {
                    return e
                };
                return n.d(t, {
                    a: t
                }), t
            },
            d: function(e, t) {
                for (var r in t) n.o(t, r) && !n.o(e, r) && Object.defineProperty(e, r, {
                    enumerable: !0,
                    get: t[r]
                })
            },
            o: function(e, t) {
                return Object.prototype.hasOwnProperty.call(e, t)
            }
        },
        de = React,
        me = n.n(de),
        t = ReactDOM,
        pe = CoreUtilities,
        e = PropTypes,
        o = n.n(e),
        s = ReactUtilities,
        P = ReactStyleGuide,
        c = {
            purchasingResources: {
                common: [],
                feature: "Purchasing.PurchaseDialog"
            },
            itemResources: {
                common: [],
                feature: "Feature.Item"
            },
            itemModelResources: {
                common: [],
                feature: "Feature.ItemModel"
            }
        },
        a = {
            errorTypeIds: {
                transactionFailure: "TransactionFailureView",
                insufficientFunds: "InsufficientFundsView",
                priceChanged: "PriceChangedView"
            },
            errorStatusText: {
                badRequest: "Bad Request"
            },
            events: {
                startItemPurchase: "ItemPurchaseStart",
                NEW_UPSELL_FAILED_DUE_TO_ERROR: "ReactBuyButtonNewUpsellProcessFailedDueToError",
                NEW_UPSELL_FAILED_DUE_TO_LOADING: "ReactBuyButtonNewUpsellProcessFailedDueToNotLoaded",
                NEW_UPSELL_FROM_REACT_BUY_BUTTON: "ReactBuyButtonNewUpsellProcessNewUpsellFromReactBuyButton"
            },
            resources: {
                freeLabel: "Label.Free",
                okAction: "Action.Ok",
                insufficientFundsHeading: "Heading.InsufficientFunds",
                insufficientFundsMessage: "Message.InsufficientFunds",
                doneAction: "Action.Done",
                cancelAction: "Action.Cancel",
                buyRobuxAction: "Action.BuyRobux",
                buyAccessAction: "Action.BuyAccess",
                buyItemHeading: "Heading.BuyItem",
                buyNowAction: "Action.BuyNow",
                getItemHeading: "Heading.GetItem",
                getNowAction: "Action.GetNow",
                priceChangedHeading: "Heading.PriceChanged",
                priceChangedMessage: "Message.PriceChanged",
                balanceAfterMessage: "Message.BalanceAfter",
                agreeAndPayLabel: "Label.AgreeAndPay",
                promptGetFreeAccessMessage: "Message.PromptGetFreeAccess",
                promptGetFreeMessage: "Message.PromptGetFree",
                promptBuyAccessMessage: "Message.PromptBuyAccess",
                promptBuyMessage: "Message.PromptBuy",
                configureAction: "Action.Customize",
                notNowAction: "Action.NotNow",
                customizeAction: "Action.Customize",
                continueAction: "Action.Continue",
                purchaseCompleteHeading: "Heading.PurchaseComplete",
                successfullyBoughtAccessMessage: "Message.SuccessfullyBoughtAccess",
                successfullyBoughtMessage: "Message.SuccessfullyBought",
                successfullyRenewedAccessMessage: "Message.SuccessfullyRenewedAccess",
                successfullyRenewedMessage: "Message.SuccessfullyRenewed",
                successfullyAcquiredAccessMessage: "Message.SuccessfullyAcquiredAccess",
                successfullyAcquiredMessage: "Message.SuccessfullyAcquired",
                itemGrantDelayMessage: "Message.ItemGrantDelay",
                errorOccuredHeading: "Heading.ErrorOccured",
                purchasingUnavailableMessage: "Message.PurchasingUnavailable",
                buyAction: "Action.Buy",
                installAction: "Action.Install",
                getAction: "Action.Get",
                bestPriceLabel: "Label.BestPrice",
                priceLabel: "Label.Price",
                premiumDiscountOpportunityPromptLabel: "Label.PremiumDiscountOpportunityPrompt",
                premiumDiscountSavingsLabel: "Label.PremiumDiscountSavings",
                premiumExclusiveEligiblePromptLabel: "Label.PremiumExclusiveEligiblePrompt",
                premiumExclusiveIneligiblePromptLabel: "Label.PremiumExclusiveIneligiblePrompt",
                getPremiumAction: "Action.GetPremium",
                itemNotCurrentlyForSaleLabel: "Label.ItemNotCurrentlyForSale",
                itemNoLongerForSaleLabel: "Label.ItemNoLongerForSale",
                purchasingTemporarilyUnavailableLabel: "Label.PurchasingTemporarilyUnavailable",
                itemAvailableInventoryLabel: "Label.ItemAvailableInventory",
                noOneCurrentlySellingLabel: "Label.NoOneCurrentlySelling",
                inventoryAction: "Action.Inventory",
                OffsaleCountdownHourMinuteSecondLabel: "Label.OffsaleCountdownHourMinuteSecond",
                CountdownTimerDayHourMinute: "Label.CountdownTimerDayHourMinute",
                batchBuyItemHeading: "Heading.BuyItems",
                batchBuyPromptMessage: "Message.PromptBatchBuy",
                batchBuyBalanceAfterMessage: "Message.BalanceAfter",
                purchaseCompletedMessage: "Heading.PurchaseCompleted",
                generalPurchaseErrorMessage: "Heading.GeneralError",
                batchBuyPartialSuccessGeneralFailureMessage: "Heading.PartialSuccessGeneralFailure",
                batchBuyPartialSuccessItemsOwnedFailureMessage: "Heading.PartialSuccessItemsOwnedFailure",
                batchBuyPartialSuccessInsufficientFundsFailureMessage: "Heading.PartialSuccessInsufficientFundsFailure",
                batchBuyPartialSuccessNetworkErrorFailureMessage: "Heading.PartialSuccessNetworkErrorFailure",
                batchBuyPartialSuccessFloodcheckFailureMessage: "Heading.PartialSuccessFloodcheckFailure",
                purchaseErrorFailureMessage: "Heading.PurchaseFailure",
                batchBuyItemsOwnedFailureMessage: "Heading.ItemsOwnedFailure",
                insufficientFundsFailureMessage: "Heading.InsufficientFundsFailure",
                networkErrroFailureMessage: "Heading.NetworkErrorFailure",
                floodcheckFailureMessage: "Heading.FloodcheckFailure",
                batchBuyPartialSuccessPremiumNeededFailureMessage: "Heading.PartialSuccessPremiumNeededFailure",
                batchBuyPartialSuccessNoSellersFailureMessage: "Heading.PartialSuccessNoSellersFailure",
                premiumNeededFailureMessage: "Heading.PremiumNeededFailure",
                noSellersFailureMessage: "Heading.NoSellersFailure",
                batchBuyPartialSuccessInExperienceOnlyFailureMessage: "Heading.PartialSuccessInExperienceOnlyFailure",
                inExperienceOnlyFailureMessage: "Heading.InExperienceOnlyFailure",
                redirectToPartnerWebsiteMessage: "Description.RedirectToPartnerWebsite",
                continueToPaymentAction: "Action.ContinueToPayment",
                leavingRobloxHeading: "Heading.LeavingRoblox"
            },
            assetTypes: {
                Plugin: 38,
                Decal: 13,
                Model: 10,
                Video: 62,
                MeshPart: 40,
                Place: 9,
                Badge: 21,
                GamePass: 34,
                Animation: 24
            },
            assetCategory: {
                Catalog: 0,
                Library: 1
            },
            errorMessages: {
                insufficientFunds: "InsufficientFunds",
                retryErrorMessage: "Failed to determine purchasability status. Please try again by refreshing.",
                notForSale: "NotForSale",
                unauthorizedMessage: "Unauthorized",
                twoStepVerificationRequired: "TwoStepVerificationRequired"
            },
            batchBuyMaxThumbnails: 3,
            maxBatchLoadRetries: 5,
            floodcheckTime: 5
        };

    function r(e, t) {
        return function(e) {
            if (Array.isArray(e)) return e
        }(e) || function(e, t) {
            if ("undefined" == typeof Symbol || !(Symbol.iterator in Object(e))) return;
            var r = [],
                n = !0,
                a = !1,
                i = void 0;
            try {
                for (var o, s = e[Symbol.iterator](); !(n = (o = s.next()).done) && (r.push(o.value), !t || r.length !== t); n = !0);
            } catch (e) {
                a = !0, i = e
            } finally {
                try {
                    n || null == s.return || s.return()
                } finally {
                    if (a) throw i
                }
            }
            return r
        }(e, t) || function(e, t) {
            if (!e) return;
            if ("string" == typeof e) return i(e, t);
            var r = Object.prototype.toString.call(e).slice(8, -1);
            "Object" === r && e.constructor && (r = e.constructor.name);
            if ("Map" === r || "Set" === r) return Array.from(e);
            if ("Arguments" === r || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return i(e, t)
        }(e, t) || function() {
            throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }

    function i(e, t) {
        (null == t || t > e.length) && (t = e.length);
        for (var r = 0, n = new Array(t); r < t; r++) n[r] = e[r];
        return n
    }
    var l = a.resources;

    function u() {
        var e = r((0, P.createModal)(), 2),
            a = e[0],
            e = e[1];

        function t(e) {
            var t = e.translate,
                r = e.title,
                n = e.message,
                e = e.onDecline,
                n = me().createElement("div", {
                    className: "modal-message"
                }, n);
            return me().createElement(a, {
                title: r,
                body: n,
                thumbnail: me().createElement("span", {
                    className: "icon-warning-orange-150x150"
                }),
                neutralButtonText: t(l.okAction),
                onNeutral: e
            })
        }
        return t.defaultProps = {
            onDecline: null
        }, t.propTypes = {
            translate: o().func.isRequired,
            title: o().string.isRequired,
            message: o().string.isRequired,
            onDecline: o().func
        }, [(0, s.withTranslations)(t, c.purchasingResources), e]
    }
    var I = ReactDOMServer,
        E = CoreRobloxUtilities,
        fe = Roblox,
        d = fe.EnvironmentUrls.economyApi,
        m = fe.EnvironmentUrls.catalogApi,
        p = fe.EnvironmentUrls.apiGatewayUrl,
        f = fe.EnvironmentUrls.twoStepVerificationApi,
        b = fe.EnvironmentUrls.universalAppConfigurationApi,
        y = fe.EnvironmentUrls.vngGamesShopUrl,
        S = {
            getRobuxUpgradesUrl: function(e) {
                return pe.urlService.getUrlWithQueries("/Upgrades/Robux.aspx", {
                    ctx: e
                })
            },
            getAvatarPageUrl: function() {
                return pe.urlService.getAbsoluteUrl("/my/avatar")
            },
            getPurchaseItemUrl: function(e) {
                return d + "/v1/purchases/products/" + e
            },
            getItemDetailsUrl: function(e, t) {
                return m + "/v1/catalog/items/" + e + "/details?itemType=" + t
            },
            postItemDetailsUrl: function() {
                return m + "/v1/catalog/items/details"
            },
            getPurchaseableDetailUrl: function(e) {
                return d + "/v1/products/" + e + "?showPurchasable=true"
            },
            getPremiumConversionUrl: function(e, t) {
                return "/premium/membership?ctx=WebItemDetail&upsellTargetType=" + t + "&upsellTargetId=" + e
            },
            getResellerDataUrl: function(e) {
                return d + "/v1/assets/" + e + "/resellers?limit=10"
            },
            getInventoryUrl: function(e) {
                return "/users/" + e + "/inventory"
            },
            getMetaDataUrl: function() {
                return d + "/v2/metadata"
            },
            getCurrentUserBalance: function(e) {
                return d + "/v1/users/" + e + "/currency"
            },
            getPurchaseCollectibleItemUrl: function(e) {
                return p + "/marketplace-sales/v1/item/" + e + "/purchase-item"
            },
            getPurchaseCollectibleItemInstanceUrl: function(e) {
                return p + "/marketplace-sales/v1/item/" + e + "/purchase-resale"
            },
            getCollectibleItemDetailsUrl: function() {
                return p + "/marketplace-items/v1/items/details"
            },
            getTwoStepVerificationConfig: function(e) {
                return f + "/v1/users/" + e + "/configuration"
            },
            postGenerateTwoStepVerificationToken: function(e) {
                return d + "/v2/" + e + "/two-step-verification/generate"
            },
            postRedeemTwoStepVerificationChallenge: function(e) {
                return d + "/v2/" + e + "/two-step-verification/redeem"
            },
            postBulkPurchaseUrl: function() {
                return p + "/cloud/v2/avatar-marketplace-orders"
            },
            getVngShopUrl: function() {
                return y
            },
            getVngBuyRobuxBehaviorUrl: function() {
                return b + "/v1/behaviors/vng-buy-robux/content"
            }
        },
        g = a.resources;

    function h(e) {
        var t = e.translate,
            r = e.price,
            n = e.color,
            e = e.useFreeText;
        return 0 === r && e ? me().createElement("span", {
            className: "text-robux text-free"
        }, t(g.freeLabel)) : me().createElement(me().Fragment, null, me().createElement("span", {
            className: "icon-robux".concat(n ? "-".concat(n) : "", "-16x16")
        }), me().createElement("span", {
            className: "text-robux"
        }, pe.numberFormat.getNumberFormat(r)))
    }
    h.defaultProps = {
        color: "",
        useFreeText: !0
    }, h.propTypes = {
        price: o().number.isRequired,
        translate: o().func.isRequired,
        color: o().string,
        useFreeText: o().bool
    };
    var w = (0, s.withTranslations)(h, c.purchasingResources);

    function v() {
        return (v = Object.assign || function(e) {
            for (var t = 1; t < arguments.length; t++) {
                var r, n = arguments[t];
                for (r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
            }
            return e
        }).apply(this, arguments)
    }

    function A(e, t) {
        return function(e) {
            if (Array.isArray(e)) return e
        }(e) || function(e, t) {
            if ("undefined" == typeof Symbol || !(Symbol.iterator in Object(e))) return;
            var r = [],
                n = !0,
                a = !1,
                i = void 0;
            try {
                for (var o, s = e[Symbol.iterator](); !(n = (o = s.next()).done) && (r.push(o.value), !t || r.length !== t); n = !0);
            } catch (e) {
                a = !0, i = e
            } finally {
                try {
                    n || null == s.return || s.return()
                } finally {
                    if (a) throw i
                }
            }
            return r
        }(e, t) || function(e, t) {
            if (!e) return;
            if ("string" == typeof e) return T(e, t);
            var r = Object.prototype.toString.call(e).slice(8, -1);
            "Object" === r && e.constructor && (r = e.constructor.name);
            if ("Map" === r || "Set" === r) return Array.from(e);
            if ("Arguments" === r || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return T(e, t)
        }(e, t) || function() {
            throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }

    function T(e, t) {
        (null == t || t > e.length) && (t = e.length);
        for (var r = 0, n = new Array(t); r < t; r++) n[r] = e[r];
        return n
    }
    var R = a.resources;

    function x() {
        var e = A((0, P.createModal)(), 2),
            i = e[0],
            e = e[1];

        function t(e) {
            var t = e.translate,
                r = e.robuxNeeded,
                n = e.source,
                a = e.onAccept,
                r = me().createElement("div", {
                    className: "modal-message",
                    dangerouslySetInnerHTML: {
                        __html: t(R.insufficientFundsMessage, {
                            robux: (0, I.renderToString)(me().createElement(w, {
                                price: r
                            }))
                        })
                    }
                });
            return me().createElement(i, v({
                title: t(R.insufficientFundsHeading),
                body: r,
                thumbnail: me().createElement("span", {
                    className: "money-stack-icon"
                }),
                neutralButtonText: t(R.cancelAction),
                actionButtonText: t(R.buyRobuxAction),
                onAction: function() {
                    return E.paymentFlowAnalyticsService.sendUserPurchaseFlowEvent(E.paymentFlowAnalyticsService.ENUM_TRIGGERING_CONTEXT.WEB_CATALOG_ROBUX_UPSELL, !0, E.paymentFlowAnalyticsService.ENUM_VIEW_NAME.ROBUX_UPSELL, E.paymentFlowAnalyticsService.ENUM_PURCHASE_EVENT_TYPE.USER_INPUT, E.paymentFlowAnalyticsService.ENUM_VIEW_MESSAGE.BUY_ROBUX), a ? a() : window.location = S.getRobuxUpgradesUrl(n), !1
                },
                onClose: function() {
                    E.paymentFlowAnalyticsService.sendUserPurchaseFlowEvent(E.paymentFlowAnalyticsService.ENUM_TRIGGERING_CONTEXT.WEB_CATALOG_ROBUX_UPSELL, !0, E.paymentFlowAnalyticsService.ENUM_VIEW_NAME.ROBUX_UPSELL, E.paymentFlowAnalyticsService.ENUM_PURCHASE_EVENT_TYPE.USER_INPUT, E.paymentFlowAnalyticsService.ENUM_VIEW_MESSAGE.CANCEL)
                }
            }, {
                actionButtonShow: !0
            }))
        }
        return t.defaultProps = {
            onAccept: null,
            source: ""
        }, t.propTypes = {
            translate: o().func.isRequired,
            source: o().string,
            onAccept: o().func,
            robuxNeeded: o().number.isRequired
        }, [(0, s.withTranslations)(t, c.purchasingResources), e]
    }

    function be() {
        var e = document.getElementById("ItemPurchaseAjaxData");
        return e ? {
            userRobuxBalance: parseInt(e.getAttribute("data-user-balance-robux"), 10),
            userBc: parseInt(e.getAttribute("data-user-bc"), 10),
            hasCurrencyServiceError: "True" === e.getAttribute("data-has-currency-service-error"),
            currencyServiceErrorMessage: e.getAttribute("data-currency-service-error-message")
        } : {}
    }
    var C = a.resources;

    function N(e) {
        var t = e.translate,
            r = e.expectedPrice,
            e = e.currentRobuxBalance,
            r = (null != e ? e : be().userRobuxBalance) - r;
        return me().createElement("span", {
            dangerouslySetInnerHTML: {
                __html: t(C.balanceAfterMessage, {
                    robuxBalance: (0, I.renderToString)(me().createElement(w, {
                        price: r,
                        color: "gray",
                        useFreeText: !1
                    }))
                })
            }
        })
    }
    N.propTypes = {
        expectedPrice: o().number.isRequired,
        currentRobuxBalance: o().number,
        translate: o().func.isRequired
    }, N.defaultProps = {
        currentRobuxBalance: void 0
    };
    var M = (0, s.withTranslations)(N, c.purchasingResources);

    function F() {
        return (F = Object.assign || function(e) {
            for (var t = 1; t < arguments.length; t++) {
                var r, n = arguments[t];
                for (r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
            }
            return e
        }).apply(this, arguments)
    }

    function U(e, t) {
        return function(e) {
            if (Array.isArray(e)) return e
        }(e) || function(e, t) {
            if ("undefined" == typeof Symbol || !(Symbol.iterator in Object(e))) return;
            var r = [],
                n = !0,
                a = !1,
                i = void 0;
            try {
                for (var o, s = e[Symbol.iterator](); !(n = (o = s.next()).done) && (r.push(o.value), !t || r.length !== t); n = !0);
            } catch (e) {
                a = !0, i = e
            } finally {
                try {
                    n || null == s.return || s.return()
                } finally {
                    if (a) throw i
                }
            }
            return r
        }(e, t) || function(e, t) {
            if (!e) return;
            if ("string" == typeof e) return D(e, t);
            var r = Object.prototype.toString.call(e).slice(8, -1);
            "Object" === r && e.constructor && (r = e.constructor.name);
            if ("Map" === r || "Set" === r) return Array.from(e);
            if ("Arguments" === r || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return D(e, t)
        }(e, t) || function() {
            throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }

    function D(e, t) {
        (null == t || t > e.length) && (t = e.length);
        for (var r = 0, n = new Array(t); r < t; r++) n[r] = e[r];
        return n
    }
    var O = a.resources;

    function B() {
        var e = U((0, P.createModal)(), 2),
            l = e[0],
            e = e[1];

        function t(e) {
            var t = e.translate,
                r = e.expectedPrice,
                n = e.currentPrice,
                a = e.onAction,
                i = e.loading,
                e = U((0, de.useState)(!1), 2),
                o = e[0],
                s = e[1],
                r = me().createElement(me().Fragment, null, me().createElement("div", {
                    className: "modal-message",
                    dangerouslySetInnerHTML: {
                        __html: t(O.priceChangedMessage, {
                            robuxBefore: (0, I.renderToString)(me().createElement(w, {
                                price: r,
                                color: "gray"
                            })),
                            robuxAfter: (0, I.renderToString)(me().createElement(w, {
                                price: n,
                                color: "gray"
                            }))
                        })
                    }
                }), me().createElement("div", {
                    className: "modal-checkbox checkbox"
                }, me().createElement("input", {
                    id: "modal-checkbox-input",
                    name: "agreementCheckBox",
                    type: "checkbox",
                    checked: o
                }), me().createElement("label", {
                    onClick: function() {
                        return s(!o)
                    },
                    htmlFor: "modal-checkbox-input"
                }, t(O.agreeAndPayLabel))));
            return me().createElement(l, F({
                title: t(O.priceChangedHeading),
                body: r,
                neutralButtonText: t(O.cancelAction),
                actionButtonText: t(O.buyRobuxAction),
                onAction: a,
                loading: i,
                disableActionButton: !o,
                footerText: me().createElement(M, {
                    expectedPrice: n
                })
            }, {
                actionButtonShow: !0
            }))
        }
        return t.defaultProps = {
            loading: !1
        }, t.propTypes = {
            translate: o().func.isRequired,
            expectedPrice: o().number.isRequired,
            currentPrice: o().number.isRequired,
            onAction: o().func.isRequired,
            loading: o().bool
        }, [(0, s.withTranslations)(t, c.purchasingResources), e]
    }

    function q(e) {
        e = e.name;
        return me().createElement("span", {
            className: "font-bold"
        }, e)
    }
    q.propTypes = {
        name: o().string.isRequired
    };
    var L = q;

    function _() {
        return (_ = Object.assign || function(e) {
            for (var t = 1; t < arguments.length; t++) {
                var r, n = arguments[t];
                for (r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
            }
            return e
        }).apply(this, arguments)
    }

    function k(e, t) {
        return function(e) {
            if (Array.isArray(e)) return e
        }(e) || function(e, t) {
            if ("undefined" == typeof Symbol || !(Symbol.iterator in Object(e))) return;
            var r = [],
                n = !0,
                a = !1,
                i = void 0;
            try {
                for (var o, s = e[Symbol.iterator](); !(n = (o = s.next()).done) && (r.push(o.value), !t || r.length !== t); n = !0);
            } catch (e) {
                a = !0, i = e
            } finally {
                try {
                    n || null == s.return || s.return()
                } finally {
                    if (a) throw i
                }
            }
            return r
        }(e, t) || function(e, t) {
            if (!e) return;
            if ("string" == typeof e) return j(e, t);
            var r = Object.prototype.toString.call(e).slice(8, -1);
            "Object" === r && e.constructor && (r = e.constructor.name);
            if ("Map" === r || "Set" === r) return Array.from(e);
            if ("Arguments" === r || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return j(e, t)
        }(e, t) || function() {
            throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }

    function j(e, t) {
        (null == t || t > e.length) && (t = e.length);
        for (var r = 0, n = new Array(t); r < t; r++) n[r] = e[r];
        return n
    }
    var H = a.resources;

    function V() {
        var e = k((0, P.createModal)(), 2),
            p = e[0],
            e = e[1];

        function t(e) {
            var t, r = e.translate,
                n = e.title,
                a = e.expectedPrice,
                i = e.thumbnail,
                o = e.assetName,
                s = e.assetType,
                l = e.assetTypeDisplayName,
                c = e.sellerName,
                u = e.isPlace,
                d = e.onAction,
                m = e.loading,
                e = e.currentRobuxBalance,
                l = {
                    assetName: (0, I.renderToString)(me().createElement(L, {
                        name: o
                    })),
                    assetType: l || s,
                    seller: (0, pe.escapeHtml)()(c),
                    robux: (0, I.renderToString)(me().createElement(w, {
                        price: a
                    }))
                },
                s = u ? H.promptBuyAccessMessage : H.promptBuyMessage,
                c = 0 === a ? (t = r(H.getItemHeading), r(H.getNowAction)) : (t = r(H.buyItemHeading), r(H.buyNowAction));
            u && (c = r(H.buyAccessAction));
            l = me().createElement("div", {
                className: "modal-message",
                dangerouslySetInnerHTML: {
                    __html: r(s, l)
                }
            });
            return me().createElement(p, _({
                title: n || t,
                body: l,
                thumbnail: i,
                neutralButtonText: r(H.cancelAction),
                actionButtonText: c,
                onAction: d,
                footerText: me().createElement(M, {
                    expectedPrice: a,
                    currentRobuxBalance: e
                }),
                loading: m
            }, {
                actionButtonShow: !0
            }))
        }
        return t.defaultProps = {
            isPlace: !1,
            assetTypeDisplayName: "",
            title: "",
            loading: !1,
            currentRobuxBalance: void 0
        }, t.propTypes = {
            translate: o().func.isRequired,
            title: o().string,
            expectedPrice: o().number.isRequired,
            thumbnail: o().node.isRequired,
            assetName: o().string.isRequired,
            assetType: o().string.isRequired,
            assetTypeDisplayName: o().string,
            sellerName: o().string.isRequired,
            isPlace: o().bool,
            onAction: o().func.isRequired,
            loading: o().bool,
            currentRobuxBalance: o().number
        }, [(0, s.withTranslations)(t, c.purchasingResources), e]
    }(xt = Ct = Ct || {}).Bought = "bought", xt.Renewed = "renewed";
    var G = Ct;

    function W(e, t) {
        return function(e) {
            if (Array.isArray(e)) return e
        }(e) || function(e, t) {
            if ("undefined" == typeof Symbol || !(Symbol.iterator in Object(e))) return;
            var r = [],
                n = !0,
                a = !1,
                i = void 0;
            try {
                for (var o, s = e[Symbol.iterator](); !(n = (o = s.next()).done) && (r.push(o.value), !t || r.length !== t); n = !0);
            } catch (e) {
                a = !0, i = e
            } finally {
                try {
                    n || null == s.return || s.return()
                } finally {
                    if (a) throw i
                }
            }
            return r
        }(e, t) || function(e, t) {
            if (!e) return;
            if ("string" == typeof e) return z(e, t);
            var r = Object.prototype.toString.call(e).slice(8, -1);
            "Object" === r && e.constructor && (r = e.constructor.name);
            if ("Map" === r || "Set" === r) return Array.from(e);
            if ("Arguments" === r || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return z(e, t)
        }(e, t) || function() {
            throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }

    function z(e, t) {
        (null == t || t > e.length) && (t = e.length);
        for (var r = 0, n = new Array(t); r < t; r++) n[r] = e[r];
        return n
    }
    var X = S.getAvatarPageUrl,
        $ = a.resources;

    function ye() {
        var e = W((0, P.createModal)(), 2),
            h = e[0],
            e = e[1];

        function t(e) {
            var t, r, n = e.translate,
                a = e.expectedPrice,
                i = e.thumbnail,
                o = e.assetName,
                s = e.assetType,
                l = e.assetIsWearable,
                c = e.assetTypeDisplayName,
                u = e.sellerName,
                d = e.isPlace,
                m = e.isPrivateServer,
                p = e.onAccept,
                f = e.onDecline,
                b = e.transactionVerb,
                y = e.itemDelayed,
                g = e.currentRobuxBalance,
                e = n($.continueAction);
            m ? (t = n($.configureAction), e = n($.notNowAction)) : y ? (t = n($.customizeAction), e = n($.doneAction)) : l && (t = n($.customizeAction), e = n($.notNowAction), r = function() {
                return window.location.href = X(), !1
            });
            u = {
                assetName: (0, I.renderToString)(me().createElement(L, {
                    name: o
                })),
                assetType: c || s,
                seller: (0, pe.escapeHtml)()(u),
                robux: (0, I.renderToString)(me().createElement(w, {
                    price: a
                }))
            }, d = b === G.Bought ? d ? $.successfullyAcquiredAccessMessage : $.successfullyBoughtMessage : b === G.Renewed ? d ? $.successfullyRenewedAccessMessage : $.successfullyRenewedMessage : d ? $.successfullyAcquiredAccessMessage : $.successfullyAcquiredMessage, u = me().createElement("div", {
                className: "modal-message",
                dangerouslySetInnerHTML: {
                    __html: "".concat(n(d, u), " ").concat(y ? n($.itemGrantDelayMessage) : "")
                }
            });
            return me().createElement(h, {
                title: n($.purchaseCompleteHeading),
                body: u,
                thumbnail: i,
                neutralButtonText: e,
                actionButtonText: t,
                onAction: p || r,
                onNeutral: f,
                footerText: !m && me().createElement(M, {
                    expectedPrice: a,
                    currentRobuxBalance: g
                }),
                actionButtonShow: !!t,
                disableActionButton: y,
                onClose: function() {
                    return window.location.reload()
                }
            })
        }
        return t.defaultProps = {
            isPlace: !1,
            assetTypeDisplayName: "",
            transactionVerb: "",
            assetIsWearable: !1,
            isPrivateServer: !1,
            onAccept: null,
            onDecline: null,
            itemDelayed: !1,
            currentRobuxBalance: void 0
        }, t.propTypes = {
            translate: o().func.isRequired,
            transactionVerb: o().string,
            expectedPrice: o().number.isRequired,
            thumbnail: o().node.isRequired,
            assetName: o().string.isRequired,
            assetType: o().string.isRequired,
            assetTypeDisplayName: o().string,
            assetIsWearable: o().bool,
            sellerName: o().string.isRequired,
            isPlace: o().bool,
            isPrivateServer: o().bool,
            onAccept: o().func,
            onDecline: o().func,
            itemDelayed: o().bool,
            currentRobuxBalance: o().number
        }, [(0, s.withTranslations)(t, c.purchasingResources), e]
    }
    var Q = S.getPurchaseItemUrl,
        Y = S.getPurchaseCollectibleItemUrl,
        J = S.getPurchaseCollectibleItemInstanceUrl,
        K = S.postBulkPurchaseUrl,
        ge = {
            purchaseCollectibleItem: function(e, t) {
                e = {
                    url: Y(e),
                    retryable: !0,
                    withCredentials: !0
                };
                return pe.httpService.post(e, t)
            },
            purchaseCollectibleItemInstance: function(e, t) {
                e = {
                    url: J(e),
                    retryable: !0,
                    withCredentials: !0
                };
                return pe.httpService.post(e, t)
            },
            purchaseItem: function(e, t) {
                e = {
                    url: Q(e),
                    retryable: !0,
                    withCredentials: !0
                };
                return pe.httpService.post(e, t)
            },
            bulkPurchaseItem: function(e, t, r, n) {
                n = {
                    url: "".concat(K(), "?idempotencyKey.key=").concat(n),
                    retryable: !0,
                    withCredentials: !0
                }, r = {
                    purchasingUser: "users/".concat(e),
                    context: {
                        productSurface: t
                    },
                    fulfillmentGroups: [r]
                };
                return pe.httpService.post(n, r)
            }
        },
        Z = S.getItemDetailsUrl,
        ee = (S.postItemDetailsUrl, S.getPurchaseableDetailUrl),
        te = S.getResellerDataUrl,
        re = S.getMetaDataUrl,
        ne = (S.getCollectibleItemDetailsUrl, S.getCurrentUserBalance),
        ae = function(e, t) {
            t = {
                url: Z(e, t),
                retryable: !0,
                withCredentials: !0
            };
            return pe.httpService.get(t)
        },
        ie = function(e) {
            e = {
                url: ee(e),
                retryable: !0,
                withCredentials: !0
            };
            return pe.httpService.get(e)
        },
        oe = function(e) {
            e = {
                url: te(e),
                retryable: !0,
                withCredentials: !0
            };
            return pe.httpService.get(e)
        },
        se = function() {
            var e = {
                url: re(),
                retryable: !0,
                withCredentials: !0
            };
            return pe.httpService.get(e)
        },
        he = function(e) {
            e = {
                url: ne(e),
                retryable: !0,
                withCredentials: !0
            };
            return pe.httpService.get(e)
        },
        le = function(e, o, s, l) {
            return new(s = s || Promise)(function(r, t) {
                function n(e) {
                    try {
                        i(l.next(e))
                    } catch (e) {
                        t(e)
                    }
                }

                function a(e) {
                    try {
                        i(l.throw(e))
                    } catch (e) {
                        t(e)
                    }
                }

                function i(e) {
                    var t;
                    e.done ? r(e.value) : ((t = e.value) instanceof s ? t : new s(function(e) {
                        e(t)
                    })).then(n, a)
                }
                i((l = l.apply(e, o || [])).next())
            })
        },
        ce = function(r, n) {
            var a, i, o, s = {
                    label: 0,
                    sent: function() {
                        if (1 & o[0]) throw o[1];
                        return o[1]
                    },
                    trys: [],
                    ops: []
                },
                e = {
                    next: t(0),
                    throw: t(1),
                    return: t(2)
                };
            return "function" == typeof Symbol && (e[Symbol.iterator] = function() {
                return this
            }), e;

            function t(t) {
                return function(e) {
                    return function(t) {
                        if (a) throw new TypeError("Generator is already executing.");
                        for (; s;) try {
                            if (a = 1, i && (o = 2 & t[0] ? i.return : t[0] ? i.throw || ((o = i.return) && o.call(i), 0) : i.next) && !(o = o.call(i, t[1])).done) return o;
                            switch (i = 0, o && (t = [2 & t[0], o.value]), t[0]) {
                                case 0:
                                case 1:
                                    o = t;
                                    break;
                                case 4:
                                    return s.label++, {
                                        value: t[1],
                                        done: !1
                                    };
                                case 5:
                                    s.label++, i = t[1], t = [0];
                                    continue;
                                case 7:
                                    t = s.ops.pop(), s.trys.pop();
                                    continue;
                                default:
                                    if (!(o = 0 < (o = s.trys).length && o[o.length - 1]) && (6 === t[0] || 2 === t[0])) {
                                        s = 0;
                                        continue
                                    }
                                    if (3 === t[0] && (!o || t[1] > o[0] && t[1] < o[3])) {
                                        s.label = t[1];
                                        break
                                    }
                                    if (6 === t[0] && s.label < o[1]) {
                                        s.label = o[1], o = t;
                                        break
                                    }
                                    if (o && s.label < o[2]) {
                                        s.label = o[2], s.ops.push(t);
                                        break
                                    }
                                    o[2] && s.ops.pop(), s.trys.pop();
                                    continue
                            }
                            t = n.call(r, s)
                        } catch (e) {
                            t = [6, e], i = 0
                        } finally {
                            a = o = 0
                        }
                        if (5 & t[0]) throw t[1];
                        return {
                            value: t[0] ? t[1] : void 0,
                            done: !0
                        }
                    }([t, e])
                }
            }
        },
        ue = S.getTwoStepVerificationConfig,
        ve = S.postGenerateTwoStepVerificationToken,
        Se = S.postRedeemTwoStepVerificationChallenge,
        Pe = function() {
            return le(void 0, void 0, Promise, function() {
                var t;
                return ce(this, function(e) {
                    switch (e.label) {
                        case 0:
                            t = {
                                url: ve("spend-friction"),
                                retryable: !0,
                                withCredentials: !0
                            }, e.label = 1;
                        case 1:
                            return e.trys.push([1, 3, , 4]), [4, pe.httpService.post(t)];
                        case 2:
                            return [2, e.sent().data || null];
                        case 3:
                            return e.sent(), [2, null];
                        case 4:
                            return [2]
                    }
                })
            })
        },
        Ee = function(n, a) {
            return le(void 0, void 0, Promise, function() {
                var t, r;
                return ce(this, function(e) {
                    switch (e.label) {
                        case 0:
                            t = {
                                url: Se("spend-friction"),
                                retryable: !0,
                                withCredentials: !0
                            }, r = {
                                challengeToken: n,
                                verificationToken: a
                            }, e.label = 1;
                        case 1:
                            return e.trys.push([1, 3, , 4]), [4, pe.httpService.post(t, r)];
                        case 2:
                            return r = e.sent(), [2, null !== (r = r.data) && void 0 !== r && r];
                        case 3:
                            return e.sent(), [2, !1];
                        case 4:
                            return [2]
                    }
                })
            })
        },
        Ie = function(e, o, s, l) {
            return new(s = s || Promise)(function(r, t) {
                function n(e) {
                    try {
                        i(l.next(e))
                    } catch (e) {
                        t(e)
                    }
                }

                function a(e) {
                    try {
                        i(l.throw(e))
                    } catch (e) {
                        t(e)
                    }
                }

                function i(e) {
                    var t;
                    e.done ? r(e.value) : ((t = e.value) instanceof s ? t : new s(function(e) {
                        e(t)
                    })).then(n, a)
                }
                i((l = l.apply(e, o || [])).next())
            })
        },
        we = function(r, n) {
            var a, i, o, s = {
                    label: 0,
                    sent: function() {
                        if (1 & o[0]) throw o[1];
                        return o[1]
                    },
                    trys: [],
                    ops: []
                },
                e = {
                    next: t(0),
                    throw: t(1),
                    return: t(2)
                };
            return "function" == typeof Symbol && (e[Symbol.iterator] = function() {
                return this
            }), e;

            function t(t) {
                return function(e) {
                    return function(t) {
                        if (a) throw new TypeError("Generator is already executing.");
                        for (; s;) try {
                            if (a = 1, i && (o = 2 & t[0] ? i.return : t[0] ? i.throw || ((o = i.return) && o.call(i), 0) : i.next) && !(o = o.call(i, t[1])).done) return o;
                            switch (i = 0, o && (t = [2 & t[0], o.value]), t[0]) {
                                case 0:
                                case 1:
                                    o = t;
                                    break;
                                case 4:
                                    return s.label++, {
                                        value: t[1],
                                        done: !1
                                    };
                                case 5:
                                    s.label++, i = t[1], t = [0];
                                    continue;
                                case 7:
                                    t = s.ops.pop(), s.trys.pop();
                                    continue;
                                default:
                                    if (!(o = 0 < (o = s.trys).length && o[o.length - 1]) && (6 === t[0] || 2 === t[0])) {
                                        s = 0;
                                        continue
                                    }
                                    if (3 === t[0] && (!o || t[1] > o[0] && t[1] < o[3])) {
                                        s.label = t[1];
                                        break
                                    }
                                    if (6 === t[0] && s.label < o[1]) {
                                        s.label = o[1], o = t;
                                        break
                                    }
                                    if (o && s.label < o[2]) {
                                        s.label = o[2], s.ops.push(t);
                                        break
                                    }
                                    o[2] && s.ops.pop(), s.trys.pop();
                                    continue
                            }
                            t = n.call(r, s)
                        } catch (e) {
                            t = [6, e], i = 0
                        } finally {
                            a = o = 0
                        }
                        if (5 & t[0]) throw t[1];
                        return {
                            value: t[0] ? t[1] : void 0,
                            done: !0
                        }
                    }([t, e])
                }
            }
        },
        Ae = fe.AccountIntegrityChallengeService.TwoStepVerification;

    function Te(e) {
        var t = e.systemFeedbackService,
            e = e.translate;
        t.warning(e("Response.VerificationError"))
    }

    function Re(e) {
        var o = e.stopTwoStepVerification,
            s = e.systemFeedbackService,
            r = e.totalAttempts,
            l = e.translate;
        return Ie(this, void 0, void 0, function() {
            var i, t = this;
            return we(this, function(e) {
                switch (e.label) {
                    case 0:
                        return [4, Pe()];
                    case 1:
                        return (i = e.sent()) ? fe.AccountIntegrityChallengeService.TwoStepVerification.renderChallenge({
                            containerId: "two-sv-popup-entry",
                            userId: fe.CurrentUser.userId,
                            challengeId: i,
                            actionType: Ae.ActionType.RobuxSpend,
                            renderInline: !1,
                            shouldShowRememberDeviceCheckbox: !1,
                            onChallengeCompleted: function(a) {
                                return Ie(t, void 0, void 0, function() {
                                    var n;
                                    return we(this, function(e) {
                                        switch (e.label) {
                                            case 0:
                                                return [4, Ee(i, a.verificationToken)];
                                            case 1:
                                                return n = e.sent(), o(), n ? (r = (t = {
                                                    systemFeedbackService: s,
                                                    translate: l
                                                }).systemFeedbackService, t = t.translate, r.success(t("Response.SuccessfulVerificationV2"))) : Te({
                                                    systemFeedbackService: s,
                                                    translate: l
                                                }), [2]
                                        }
                                        var t, r
                                    })
                                })
                            },
                            onChallengeInvalidated: function() {
                                var e = r || 0;
                                e < 3 ? Re({
                                    stopTwoStepVerification: o,
                                    systemFeedbackService: s,
                                    translate: l,
                                    totalAttempts: e + 1
                                }) : (Te({
                                    systemFeedbackService: s,
                                    translate: l
                                }), o())
                            },
                            onModalChallengeAbandoned: function() {}
                        }) : Te({
                            systemFeedbackService: s,
                            translate: l
                        }), [2]
                }
            })
        })
    }
    var xe = (0, s.withTranslations)(function(e) {
        var t = this,
            r = e.translate,
            n = e.isTwoStepVerificationActive,
            a = e.stopTwoStepVerification,
            i = e.systemFeedbackService;
        return (0, de.useEffect)(function() {
            n && Ie(t, void 0, void 0, function() {
                return we(this, function(e) {
                    switch (e.label) {
                        case 0:
                            return [4, le(void 0, void 0, Promise, function() {
                                var t;
                                return ce(this, function(e) {
                                    switch (e.label) {
                                        case 0:
                                            t = {
                                                url: ue(fe.CurrentUser.userId),
                                                retryable: !0,
                                                withCredentials: !0
                                            }, e.label = 1;
                                        case 1:
                                            return e.trys.push([1, 3, , 4]), [4, pe.httpService.get(t)];
                                        case 2:
                                            return t = e.sent(), [2, ((null === (t = null == t ? void 0 : t.data) || void 0 === t ? void 0 : t.methods) || []).some(function(e) {
                                                return !!e.enabled
                                            })];
                                        case 3:
                                            return e.sent(), [2, !1];
                                        case 4:
                                            return [2]
                                    }
                                })
                            })];
                        case 1:
                            return e.sent() ? Re({
                                stopTwoStepVerification: a,
                                systemFeedbackService: i,
                                translate: r
                            }) : (t = {
                                titleText: (t = (t = {
                                    translate: r
                                }).translate)("Heading.TwoStepVerificationRequiredV3"),
                                bodyContent: t("Message.TwoStepVerificationRequiredV4"),
                                imageUrl: void 0,
                                acceptText: t("Action.GoToSecurity"),
                                acceptColor: "btn-primary-md",
                                onAccept: function() {
                                    window.location.href = fe.Endpoints.getAbsoluteUrl("/my/account#!/security")
                                },
                                declineText: t("Action.Cancel"),
                                dismissable: !0,
                                allowHtmlContentInBody: !0,
                                onOpenCallback: function() {}
                            }, fe.Dialog.open(t)), [2]
                    }
                    var t
                })
            })
        }, [n]), me().createElement("div", {
            id: "two-sv-popup-entry"
        })
    }, c.purchasingResources);

    function Ce(t, e) {
        var r, n = Object.keys(t);
        return Object.getOwnPropertySymbols && (r = Object.getOwnPropertySymbols(t), e && (r = r.filter(function(e) {
            return Object.getOwnPropertyDescriptor(t, e).enumerable
        })), n.push.apply(n, r)), n
    }

    function Ne(n) {
        for (var e = 1; e < arguments.length; e++) {
            var a = null != arguments[e] ? arguments[e] : {};
            e % 2 ? Ce(Object(a), !0).forEach(function(e) {
                var t, r;
                t = n, e = a[r = e], r in t ? Object.defineProperty(t, r, {
                    value: e,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[r] = e
            }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(n, Object.getOwnPropertyDescriptors(a)) : Ce(Object(a)).forEach(function(e) {
                Object.defineProperty(n, e, Object.getOwnPropertyDescriptor(a, e))
            })
        }
        return n
    }

    function Me(e, t, r, n, a, i, o) {
        try {
            var s = e[i](o),
                l = s.value
        } catch (e) {
            return void r(e)
        }
        s.done ? t(l) : Promise.resolve(l).then(n, a)
    }

    function Fe(e, t) {
        return function(e) {
            if (Array.isArray(e)) return e
        }(e) || function(e, t) {
            if ("undefined" == typeof Symbol || !(Symbol.iterator in Object(e))) return;
            var r = [],
                n = !0,
                a = !1,
                i = void 0;
            try {
                for (var o, s = e[Symbol.iterator](); !(n = (o = s.next()).done) && (r.push(o.value), !t || r.length !== t); n = !0);
            } catch (e) {
                a = !0, i = e
            } finally {
                try {
                    n || null == s.return || s.return()
                } finally {
                    if (a) throw i
                }
            }
            return r
        }(e, t) || function(e, t) {
            if (!e) return;
            if ("string" == typeof e) return Ue(e, t);
            var r = Object.prototype.toString.call(e).slice(8, -1);
            "Object" === r && e.constructor && (r = e.constructor.name);
            if ("Map" === r || "Set" === r) return Array.from(e);
            if ("Arguments" === r || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return Ue(e, t)
        }(e, t) || function() {
            throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }

    function Ue(e, t) {
        (null == t || t > e.length) && (t = e.length);
        for (var r = 0, n = new Array(t); r < t; r++) n[r] = e[r];
        return n
    }
    var De = a.resources,
        Oe = a.errorTypeIds,
        Be = a.errorStatusText,
        qe = a.events;

    function Le() {
        function z() {
            ue.itemDetail.buyButtonElementDataset && (E.paymentFlowAnalyticsService.startRobuxUpsellFlow(ue.itemDetail.buyButtonElementDataset.assetType, !!ue.itemDetail.buyButtonElementDataset.userassetId, ue.itemDetail.buyButtonElementDataset.isPrivateServer, ue.itemDetail.buyButtonElementDataset.isPlace), t.open())
        }

        function X() {
            var e, t, r;
            if (fe.ItemPurchaseUpsellService && null !== (e = ue) && void 0 !== e && null !== (t = e.itemDetail) && void 0 !== t && t.expectedItemPrice)
                if (0 <= Y - (null === ue || void 0 === ue || null === (r = ue.itemDetail) || void 0 === r ? void 0 : r.expectedItemPrice)) z();
                else try {
                    fe.ItemPurchaseUpsellService.startItemUpsellProcess(ue.errorObject, ue.itemDetail, ue.startOriginalFlowCallback), window.EventTracker.fireEvent(qe.NEW_UPSELL_FROM_REACT_BUY_BUTTON)
                } catch (e) {
                    window.EventTracker.fireEvent(qe.NEW_UPSELL_FAILED_DUE_TO_ERROR), z()
                } else window.EventTracker.fireEvent(qe.NEW_UPSELL_FAILED_DUE_TO_LOADING), z()
        }
        var e = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : {},
            $ = e.customPurchaseVerificationModal,
            Q = e.customPurchaseVerificationModalService,
            Y = be().userRobuxBalance,
            e = Fe((0, P.createSystemFeedback)(), 2),
            J = e[0],
            K = e[1],
            e = Fe((0, P.createSystemFeedback)(), 2),
            Z = e[0],
            ee = e[1],
            e = Fe(V(), 2),
            te = e[0],
            re = e[1],
            e = Fe(x(), 2),
            ne = e[0],
            t = e[1],
            e = Fe(ye(), 2),
            ae = e[0],
            ie = e[1],
            e = Fe(B(), 2),
            oe = e[0],
            se = e[1],
            e = Fe(u(), 2),
            le = e[0],
            ce = e[1],
            ue = {
                errorObject: {},
                itemDetail: {},
                startOriginalFlowCallback: function() {
                    return null
                }
            };

        function r(e) {
            function l() {
                return L(!0)
            }
            var c = e.translate,
                i = e.assetName,
                o = e.assetType,
                s = e.assetTypeDisplayName,
                u = e.productId,
                d = e.expectedCurrency,
                t = e.expectedPrice,
                m = e.expectedSellerId,
                p = e.expectedPromoId,
                f = e.userAssetId,
                r = e.thumbnail,
                n = e.sellerName,
                b = e.sellerType,
                y = e.showSuccessBanner,
                g = e.isPlace,
                h = e.isPrivateServer,
                v = e.handlePurchase,
                S = e.onPurchaseSuccess,
                P = e.collectibleItemId,
                E = e.collectibleItemInstanceId,
                I = e.collectibleProductId,
                a = e.customProps,
                w = Fe((0, de.useState)(!1), 2),
                A = w[0],
                T = w[1],
                R = Fe((0, de.useState)(null), 2),
                x = R[0],
                C = R[1],
                N = Fe((0, de.useState)(null), 2),
                M = N[0],
                F = N[1],
                U = Fe((0, de.useState)(t - Y), 2),
                e = U[0],
                D = U[1],
                w = Fe((0, de.useState)(null), 2),
                R = w[0],
                O = w[1],
                N = Fe((0, de.useState)(void 0), 2),
                U = N[0],
                B = N[1],
                w = Fe((0, de.useState)(!1), 2),
                q = w[0],
                L = w[1],
                N = Fe((0, de.useState)(!1), 2),
                w = N[0],
                _ = N[1];
            (0, de.useEffect)(function() {
                fe.CurrentUser.isAuthenticated && void 0 === be().userRobuxBalance && he(fe.CurrentUser.userId).then(function(e) {
                    B(e.data.robux)
                }).catch(function() {
                    B(void 0)
                })
            }, [u, t, m]), (0, de.useEffect)(function() {
                q && _(!0)
            }, [q]);

            function k() {
                (Q || re).close(), se.close()
            }

            function j(e, t) {
                var r, n, a = {
                    assetType: o,
                    assetTypeDisplayName: s,
                    expectedCurrency: d,
                    expectedPrice: t,
                    expectedSellerId: m,
                    itemName: i,
                    itemType: o,
                    productId: u,
                    userassetId: f,
                    placeproductpromotionId: p,
                    isPrivateServer: h,
                    isPlace: g
                };
                ue = {
                    errorObject: {
                        shortfallPrice: e,
                        currentCurrency: d,
                        isPlace: g
                    },
                    itemDetail: {
                        expectedItemPrice: t,
                        assetName: i,
                        buyButtonElementDataset: a
                    },
                    startOriginalFlowCallback: (r = e, n = a, function() {
                        fe.ItemPurchaseUpsellService && fe.ItemPurchaseUpsellService.showExceedLargestInsufficientRobuxModal ? fe.ItemPurchaseUpsellService.showExceedLargestInsufficientRobuxModal(r, n, z) : z()
                    })
                }
            }

            function H(e) {
                var t = e.showDivId,
                    r = e.title,
                    n = e.errorMsg,
                    a = e.price,
                    i = e.shortfallPrice,
                    e = e.onDecline;
                t === Oe.transactionFailure ? (C({
                    title: r,
                    message: n,
                    onDecline: e
                }), ce.open()) : t === Oe.insufficientFunds ? (D(i), j(i, a), X()) : t === Oe.priceChanged && (F(a), se.open())
            }

            function V(e) {
                O(e), ie.open()
            }

            function G(e) {
                P ? W(e) : (e = {
                    expectedCurrency: d,
                    expectedPrice: e = e,
                    expectedSellerId: m
                }, 0 < p && (e.expectedPromoId = p), 0 < f && (e.userAssetId = f), v ? v({
                    params: e,
                    handleError: H,
                    setLoading: T,
                    openConfirmation: V,
                    closeAll: k
                }) : (T(!0), ge.purchaseItem(u, e).then(function(e) {
                    var t = e.data;
                    console.debug(t);
                    var r = t.statusCode,
                        n = t.assetIsWearable,
                        e = t.transactionVerb;
                    T(!1), k(), t.purchased || "TwoStepVerificationRequired" !== t.reason ? 500 === r ? H(t) : (S(), y ? K.success(c(De.purchaseCompleteHeading)) : V({
                        assetIsWearable: n,
                        transactionVerb: e,
                        onDecline: function() {
                            window.location.reload()
                        }
                    })) : l()
                }).catch(function(t) {
                    if (console.debug(t), T(!1), k(), t && (null == t ? void 0 : t.statusText) !== Be.badRequest) {
                        429 === t.status && H({
                            title: c(De.errorOccuredHeading),
                            errorMsg: c(De.floodcheckFailureMessage, {
                                throttleTime: 1
                            }),
                            showDivId: Oe.transactionFailure
                        });
                        try {
                            H(JSON.parse(null == t ? void 0 : t.statusText))
                        } catch (e) {
                            H({
                                errorMsg: null == t ? void 0 : t.statusText
                            })
                        }
                    } else H({
                        title: c(De.errorOccuredHeading),
                        errorMsg: c(De.purchasingUnavailableMessage),
                        showDivId: Oe.transactionFailure
                    })
                })))
            }
            var W = function() {
                    var s, e = (s = regeneratorRuntime.mark(function e(r) {
                        var n, a, i, o;
                        return regeneratorRuntime.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    if (n = {
                                            collectibleItemId: P,
                                            expectedCurrency: d,
                                            expectedPrice: r,
                                            expectedPurchaserId: fe.CurrentUser.userId,
                                            expectedPurchaserType: "User",
                                            expectedSellerId: m,
                                            expectedSellerType: b,
                                            idempotencyKey: pe.uuidService.generateRandomUuid()
                                        }, E && (n.collectibleItemInstanceId = E), I && (n.collectibleProductId = I), v) return v({
                                        params: n,
                                        handleError: H,
                                        setLoading: T,
                                        openConfirmation: V,
                                        closeAll: k
                                    }), t.abrupt("return");
                                    t.next = 6;
                                    break;
                                case 6:
                                    return T(!0), o = E ? ge.purchaseCollectibleItemInstance : ge.purchaseCollectibleItem, t.prev = 8, t.next = 11, o(P, n);
                                case 11:
                                    if (o = t.sent, a = o.data, i = a.transactionVerb, T(!1), k(), !("number" == typeof(o = null !== (o = a.statusCode) && void 0 !== o ? o : a.status) && 400 <= o || !1 === (null == a ? void 0 : a.purchased))) {
                                        t.next = 21;
                                        break
                                    }!1 === (null == a ? void 0 : a.purchased) && "TwoStepVerificationRequired" === (null == a ? void 0 : a.reason) ? l() : !1 === (null == a ? void 0 : a.purchased) && "Flooded" === (null == a ? void 0 : a.purchaseResult) ? H({
                                        title: c(De.errorOccuredHeading),
                                        errorMsg: c(De.floodcheckFailureMessage, {
                                            throttleTime: 1
                                        }),
                                        showDivId: Oe.transactionFailure
                                    }) : H({
                                        title: c(De.errorOccuredHeading),
                                        errorMsg: c(De.purchasingUnavailableMessage),
                                        showDivId: Oe.transactionFailure,
                                        onDecline: function() {
                                            window.location.reload()
                                        }
                                    }), t.next = 26;
                                    break;
                                case 21:
                                    if (S(), y) return K.success(c(De.purchaseCompleteHeading)), t.abrupt("return");
                                    t.next = 25;
                                    break;
                                case 25:
                                    V({
                                        assetIsWearable: !0,
                                        transactionVerb: i,
                                        itemDelayed: null == a ? void 0 : a.pending,
                                        onDecline: function() {
                                            window.location.reload()
                                        }
                                    });
                                case 26:
                                    t.next = 37;
                                    break;
                                case 28:
                                    if (t.prev = 28, t.t0 = t.catch(8), console.debug(t.t0), fe.AccountIntegrityChallengeService.Generic.ChallengeError.matchAbandoned(x)) return T(!1), t.abrupt("return");
                                    t.next = 34;
                                    break;
                                case 34:
                                    if (T(!1), k(), t.t0 && (null === t.t0 || void 0 === t.t0 ? void 0 : t.t0.statusText) !== Be.badRequest) {
                                        429 === t.t0.status && H({
                                            title: c(De.errorOccuredHeading),
                                            errorMsg: c(De.floodcheckFailureMessage, {
                                                throttleTime: 1
                                            }),
                                            showDivId: Oe.transactionFailure
                                        });
                                        try {
                                            H(JSON.parse(null === t.t0 || void 0 === t.t0 ? void 0 : t.t0.statusText))
                                        } catch (e) {
                                            H({
                                                errorMsg: null === t.t0 || void 0 === t.t0 ? void 0 : t.t0.statusText
                                            })
                                        }
                                    } else H({
                                        title: c(De.errorOccuredHeading),
                                        errorMsg: c(De.purchasingUnavailableMessage),
                                        showDivId: Oe.transactionFailure
                                    });
                                case 37:
                                case "end":
                                    return t.stop()
                            }
                        }, e, null, [
                            [8, 28]
                        ])
                    }), function() {
                        var e = this,
                            o = arguments;
                        return new Promise(function(t, r) {
                            var n = s.apply(e, o);

                            function a(e) {
                                Me(n, t, r, a, i, "next", e)
                            }

                            function i(e) {
                                Me(n, t, r, a, i, "throw", e)
                            }
                            a(void 0)
                        })
                    });
                    return function() {
                        return e.apply(this, arguments)
                    }
                }(),
                a = $ ? me().createElement($, Ne({}, Ne({
                    assetName: i,
                    assetType: o,
                    expectedPrice: t,
                    thumbnail: r,
                    sellerName: n,
                    loading: A,
                    onAction: function() {
                        return G(t)
                    }
                }, a))) : me().createElement(te, {
                    expectedPrice: t,
                    thumbnail: r,
                    assetName: i,
                    assetType: o,
                    assetTypeDisplayName: s,
                    sellerName: n,
                    isPlace: g,
                    loading: A,
                    collectibleItemId: P,
                    collectibleItemInstanceId: E,
                    currentRobuxBalance: U,
                    onAction: function() {
                        return G(t), !1
                    }
                });
            return 0 < e && fe.ItemPurchaseUpsellService && j(e, null != M ? M : t), me().createElement(me().Fragment, null, me().createElement(xe, {
                isTwoStepVerificationActive: q,
                stopTwoStepVerification: function() {
                    return L(!1)
                },
                systemFeedbackService: ee
            }), 0 < e ? me().createElement(ne, {
                robuxNeeded: e
            }) : a, x && me().createElement(le, {
                title: x.title,
                message: x.message,
                onDecline: x.onDecline
            }), null != M && me().createElement(oe, {
                expectedPrice: t,
                currentPrice: M,
                loading: A,
                onAction: function() {
                    return G(M), !1
                }
            }), R && me().createElement(ae, Ne({
                thumbnail: r,
                assetName: i,
                assetType: o,
                assetTypeDisplayName: s,
                sellerName: n,
                isPlace: g,
                isPrivateServer: h,
                expectedPrice: M || t,
                currentRobuxBalance: U
            }, R)), y && me().createElement(J, null), w && me().createElement(Z, null))
        }
        return r.defaultProps = {
            isPlace: !1,
            isPrivateServer: !1,
            productId: null,
            assetTypeDisplayName: "",
            expectedPromoId: 0,
            userAssetId: 0,
            showSuccessBanner: !1,
            handlePurchase: null,
            onPurchaseSuccess: function() {
                return null
            },
            customProps: {},
            collectibleItemId: null,
            collectibleItemInstanceId: null,
            collectibleProductId: null,
            sellerType: null
        }, r.propTypes = {
            translate: o().func.isRequired,
            productId: function(e, t, r) {
                var n = e.collectibleItemId,
                    a = e.productId;
                return n || "number" == typeof a ? null : new Error("Invalid prop ".concat(t, " supplied to ").concat(r, ". Validation failed."))
            },
            expectedCurrency: o().number.isRequired,
            expectedPrice: o().number.isRequired,
            thumbnail: o().node.isRequired,
            assetName: o().string.isRequired,
            assetType: o().string.isRequired,
            assetTypeDisplayName: o().string,
            expectedSellerId: o().number.isRequired,
            sellerName: o().string.isRequired,
            sellerType: o().string,
            isPlace: o().bool,
            isPrivateServer: o().bool,
            expectedPromoId: o().number,
            userAssetId: o().number,
            showSuccessBanner: o().bool,
            handlePurchase: o().func,
            onPurchaseSuccess: o().func,
            customProps: o().func,
            collectibleItemId: o().string,
            collectibleItemInstanceId: o().string,
            collectibleProductId: o().string
        }, [(0, s.withTranslations)(r, c.purchasingResources), {
            start: function() {
                (Q || re).open(), X()
            }
        }]
    }
    var _e = HeaderScripts;

    function ke(e, t) {
        return function(e) {
            if (Array.isArray(e)) return e
        }(e) || function(e, t) {
            if ("undefined" == typeof Symbol || !(Symbol.iterator in Object(e))) return;
            var r = [],
                n = !0,
                a = !1,
                i = void 0;
            try {
                for (var o, s = e[Symbol.iterator](); !(n = (o = s.next()).done) && (r.push(o.value), !t || r.length !== t); n = !0);
            } catch (e) {
                a = !0, i = e
            } finally {
                try {
                    n || null == s.return || s.return()
                } finally {
                    if (a) throw i
                }
            }
            return r
        }(e, t) || function(e, t) {
            if (!e) return;
            if ("string" == typeof e) return je(e, t);
            var r = Object.prototype.toString.call(e).slice(8, -1);
            "Object" === r && e.constructor && (r = e.constructor.name);
            if ("Map" === r || "Set" === r) return Array.from(e);
            if ("Arguments" === r || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return je(e, t)
        }(e, t) || function() {
            throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }

    function je(e, t) {
        (null == t || t > e.length) && (t = e.length);
        for (var r = 0, n = new Array(t); r < t; r++) n[r] = e[r];
        return n
    }
    var He = a.errorMessages,
        Ve = function(e, t, r) {
            function n() {
                o({
                    loading: !1,
                    loadFailure: !0
                })
            }
            var a = ke((0, de.useState)({
                    expectedSellerId: 0,
                    owned: !1,
                    isPurchasable: !1,
                    id: 0,
                    itemType: "",
                    assetType: "",
                    name: "",
                    description: "",
                    productId: 0,
                    creatorTargetId: 0,
                    creatorName: "",
                    price: null,
                    loading: !0,
                    loadFailure: !1,
                    premiumPricing: null,
                    premiumDiscountPercentage: null,
                    hasLimitedPrivateSales: !1,
                    isPublicDomain: !1,
                    premiumPriceInRobux: null,
                    assetTypeDisplayName: "",
                    offSaleDeadline: null,
                    unitsAvailableForConsumption: 0,
                    isLimited: !1,
                    resellerAvailable: !1,
                    firstReseller: {},
                    priceStatus: "",
                    isMarketPlaceEnabled: !0
                }), 2),
                i = a[0],
                o = a[1],
                s = (0, de.useCallback)(function() {
                    e(t, r).then(function(e) {
                        var e = e.data,
                            t = {
                                expectedSellerId: e.expectedSellerId,
                                owned: e.owned,
                                id: e.id,
                                itemType: e.itemType,
                                assetType: e.assetType,
                                name: e.name,
                                description: e.description,
                                productId: e.productId,
                                price: e.price,
                                lowestPrice: e.lowestPrice,
                                creatorTargetId: e.creatorTargetId,
                                creatorName: e.creatorName,
                                hasLimitedPrivateSales: void 0 !== e.lowestPrice,
                                isPublicDomain: 0 === e.price,
                                offSaleDeadline: e.offSaleDeadline,
                                isLimited: e.itemRestrictions.includes("Limited") || e.itemRestrictions.includes("LimitedUnique"),
                                unitsAvailableForConsumption: void 0 !== e.unitsAvailableForConsumption ? e.unitsAvailableForConsumption : 0,
                                priceStatus: void 0 !== e.priceStatus ? e.priceStatus : "",
                                itemRestrictions: e.itemRestrictions
                            };
                        void 0 !== e.premiumPricing && (t.premiumPriceInRobux = e.premiumPricing.premiumPriceInRobux, t.premiumDiscountPercentage = e.premiumPricing.premiumDiscountPercentage), t.isLimited && (t.price = void 0 !== t.lowestPrice ? t.lowestPrice : t.price, oe(t.id).then(function(e) {
                            t.resellerAvailable = 0 < e.data.data.length, t.resellerAvailable && (e = ke(e.data.data, 1)[0], t.price = e.price, t.firstReseller = e)
                        })), ie(e.productId).then(function(e) {
                            !e.data.purchasable && e.data.reason && e.data.reason !== He.insufficientFunds ? t.isPurchasable = e.data.purchasable : t.isPurchasable = !0, t.assetTypeDisplayName = e.data.assetTypeDisplayName, t.loading = !1, t.loadFailure = !1, se().then(function(e) {
                                t.isMarketPlaceEnabled = e.data.isMarketPlaceEnabled && e.data.isItemsXchangeEnabled, o(t)
                            }).catch(function() {
                                n()
                            })
                        }).catch(function(e) {
                            e.statusText === He.unauthorizedMessage ? (t.loading = !1, t.loadFailure = !1, o(t)) : n()
                        })
                    }).catch(function() {
                        n()
                    })
                }, [t, r, e]);
            return (0, de.useEffect)(function() {
                s()
            }, []), {
                itemDetail: i,
                loadItemDetail: s
            }
        },
        Ge = function() {
            var e = document.getElementById("item-container");
            return e ? {
                itemDetailItemId: parseInt(e.getAttribute("data-item-id"), 10),
                itemDetailItemType: e.getAttribute("data-item-type")
            } : null
        },
        We = RobloxThumbnails;

    function ze(e, t) {
        (null == t || t > e.length) && (t = e.length);
        for (var r = 0, n = new Array(t); r < t; r++) n[r] = e[r];
        return n
    }
    var Xe = Le(),
        $e = (Nt = (Nt = 2, function(e) {
            if (Array.isArray(e)) return e
        }(Xe = Xe) || function(e, t) {
            if ("undefined" == typeof Symbol || !(Symbol.iterator in Object(e))) return;
            var r = [],
                n = !0,
                a = !1,
                i = void 0;
            try {
                for (var o, s = e[Symbol.iterator](); !(n = (o = s.next()).done) && (r.push(o.value), !t || r.length !== t); n = !0);
            } catch (e) {
                a = !0, i = e
            } finally {
                try {
                    n || null == s.return || s.return()
                } finally {
                    if (a) throw i
                }
            }
            return r
        }(Xe, Nt) || function(e, t) {
            if (!e) return;
            if ("string" == typeof e) return ze(e, t);
            var r = Object.prototype.toString.call(e).slice(8, -1);
            "Object" === r && e.constructor && (r = e.constructor.name);
            if ("Map" === r || "Set" === r) return Array.from(e);
            if ("Arguments" === r || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return ze(e, t)
        }(Xe, Nt) || function() {
            throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()))[0],
        Qe = Nt[1],
        Ye = a.resources,
        Je = S.getPremiumConversionUrl;

    function Ke(e) {
        var t = e.translate,
            r = e.productId,
            n = e.price,
            a = e.itemName,
            i = e.itemType,
            o = e.assetTypeDisplayName,
            s = e.sellerName,
            l = e.expectedSellerId,
            c = e.isPurchasable,
            u = e.isOwned,
            d = e.isPlugin,
            m = e.itemDetailItemId,
            p = e.loading,
            f = e.userQualifiesForPremiumPrices,
            b = e.premiumPriceInRobux,
            y = e.isAuthenticated,
            g = e.resellerAvailable,
            h = e.firstReseller,
            g = e.isMarketPlaceEnabled && (g || c),
            c = function() {
                return t(0 === n ? Ye.getAction : Ye.buyAction)
            };
        if (p) return me().createElement(P.Loading, null);
        if (!y) return null != b ? me().createElement(P.Button, {
            id: "upgrade-button",
            className: "btn-fixed-width-lg btn-primary-lg",
            onClick: function() {
                E.paymentFlowAnalyticsService.sendUserPurchaseFlowEvent(E.paymentFlowAnalyticsService.ENUM_TRIGGERING_CONTEXT.WEB_PREMIUM_PURCHASE, !1, E.paymentFlowAnalyticsService.ENUM_VIEW_NAME.PREMIUM_UPSELL, E.paymentFlowAnalyticsService.ENUM_PURCHASE_EVENT_TYPE.USER_INPUT, E.paymentFlowAnalyticsService.ENUM_VIEW_MESSAGE.GET_PREMIUM), window.open(Je(m, i))
            }
        }, t(Ye.getPremiumAction)) : me().createElement(P.Button, {
            className: "btn-fixed-width-lg btn-growth-lg PurchaseButton",
            onClick: function() {
                window.location = "/login"
            }
        }, c());
        y = me().createElement(We.Thumbnail2d, {
            type: "bundle" === i ? We.ThumbnailTypes.bundleThumbnail : We.ThumbnailTypes.assetThumbnail,
            size: We.DefaultThumbnailSize,
            targetId: m,
            format: We.ThumbnailFormat.webp,
            altName: a
        });
        return d && (u || 0 === n) ? me().createElement(me().Fragment, null, me().createElement(P.Button, {
            className: "btn-fixed-width-lg btn-primary-lg InstallButton",
            onClick: function() {
                var e;
                e = m, fe.GameLauncher.openPluginInStudio(e)
            }
        }, me().createElement("span", null, t(Ye.installAction)))) : me().createElement(me().Fragment, null, me().createElement(P.Button, {
            className: "btn-fixed-width-lg btn-growth-lg PurchaseButton",
            onClick: Qe.start,
            isDisabled: !g
        }, c()), me().createElement($e, {
            productId: r,
            expectedPrice: f && null != b ? b : n,
            thumbnail: y,
            assetTypeDisplayName: o,
            assetName: a,
            sellerName: h ? h.seller.name : s,
            expectedSellerId: h ? h.seller.id : l,
            userAssetId: h ? h.userAssetId : 0,
            showSuccessBanner: !0
        }))
    }
    Ke.propTypes = {
        translate: o().func.isRequired,
        productId: o().number.isRequired,
        price: o().number.isRequired,
        itemName: o().string.isRequired,
        itemType: o().string.isRequired,
        assetTypeDisplayName: o().string.isRequired,
        sellerName: o().string.isRequired,
        expectedSellerId: o().number.isRequired,
        isPurchasable: o().bool.isRequired,
        isOwned: o().bool.isRequired,
        isPlugin: o().bool.isRequired,
        itemDetailItemId: o().number.isRequired,
        loading: o().bool.isRequired,
        userQualifiesForPremiumPrices: o().bool.isRequired,
        premiumPriceInRobux: o().number.isRequired,
        isAuthenticated: o().bool.isRequired,
        resellerAvailable: o().bool.isRequired,
        firstReseller: o().shape({
            seller: {
                name: o().string.isRequired,
                id: o().number.isRequired
            },
            userAssetId: o().number.isRequired
        }).isRequired,
        isMarketPlaceEnabled: o().bool.isRequired
    };
    var Ze = (0, s.withTranslations)(Ke, c.itemResources),
        et = a.resources;

    function tt(e) {
        var t = e.translate,
            r = e.isLimited,
            e = e.resellerAvailable,
            e = r && e;
        return me().createElement("div", {
            className: "text-label field-label price-label"
        }, me().createElement("span", null, t(e ? et.bestPriceLabel : et.priceLabel)))
    }
    tt.propTypes = {
        translate: o().func.isRequired,
        isLimited: o().bool.isRequired,
        resellerAvailable: o().bool.isRequired
    };
    var rt = (0, s.withTranslations)(tt, c.itemResources),
        nt = a.resources,
        at = a.errorMessages,
        it = S.getPremiumConversionUrl;

    function ot(e) {
        function t(e) {
            E.paymentFlowAnalyticsService.sendUserPurchaseFlowEvent(E.paymentFlowAnalyticsService.ENUM_TRIGGERING_CONTEXT.WEB_PREMIUM_PURCHASE, !1, E.paymentFlowAnalyticsService.ENUM_VIEW_NAME.PREMIUM_UPSELL, E.paymentFlowAnalyticsService.ENUM_PURCHASE_EVENT_TYPE.USER_INPUT, e.target.innerText)
        }
        var r = e.translate,
            n = e.price,
            a = e.itemType,
            i = e.itemDetailItemId,
            o = e.premiumPriceInRobux,
            s = e.premiumDiscountPercentage,
            l = e.userQualifiesForPremiumPrices,
            c = e.isOwned,
            u = e.loading,
            d = e.loadFailure,
            m = e.unitsAvailableForConsumption,
            p = e.isLimited,
            f = e.isPlugin,
            b = e.resellerAvailable,
            y = e.priceStatus,
            g = e.offSaleDeadline,
            h = e.isMarketPlaceEnabled,
            v = null == o && null == n,
            S = !0,
            e = "";
        return u ? me().createElement(P.Loading, null) : (!u && d ? e = at.retryErrorMessage : y === nt.offSale && null === g ? e = r(nt.itemNoLongerForSaleLabel) : h || c ? f || !c || p ? p && 0 === m && !b ? e = r(nt.noOneCurrentlySellingLabel) : S = !1 : e = r(nt.itemAvailableInventoryLabel) : e = r(nt.purchasingTemporarilyUnavailableLabel), 0 === n ? null : S && !c ? me().createElement("div", {
            className: "price-container-text"
        }, me().createElement("div", {
            className: "item-first-line"
        }, " ", e, " ")) : me().createElement(me().Fragment, null, me().createElement("div", {
            className: "price-container-text"
        }, S ? me().createElement("div", {
            className: "item-first-line"
        }, " ", e, " ") : null, me().createElement(rt, {
            translate: r,
            isLimited: p,
            resellerAvailable: b
        }), me().createElement("div", {
            className: "price-info"
        }, me().createElement("div", {
            className: "icon-text-wrapper clearfix icon-robux-price-container"
        }, v ? me().createElement("span", {
            className: "icon-robux-16x16 icon-robux-gray-16x16 wait-for-i18n-format-render"
        }) : me().createElement("span", {
            className: "icon-robux-16x16 wait-for-i18n-format-render"
        }), me().createElement("span", {
            className: "text-robux-lg wait-for-i18n-format-render"
        }, l && null != o ? pe.numberFormat.getNumberFormat(o) : pe.numberFormat.getNumberFormat(n)))), function() {
            if (null == o || c) return null;
            if (null == n) return l ? me().createElement("span", {
                className: "small text field-content empty-label wait-for-i18n-format-render"
            }, r(nt.premiumExclusiveEligiblePromptLabel)) : me().createElement("span", {
                className: "small text field-content empty-label wait-for-i18n-format-render"
            }, r(nt.premiumExclusiveIneligiblePromptLabel));
            var e = {
                originalPrice: (0, I.renderToString)(me().createElement(w, {
                    price: n
                })),
                discountPercentage: s,
                premiumDiscountedPrice: (0, I.renderToString)(me().createElement(w, {
                    price: o
                }))
            };
            return me().createElement(me().Fragment, null, me().createElement("div", {
                className: "text-label field-label empty-label"
            }, " "), me().createElement("span", {
                className: "premium-prompt small text field-content empty-label wait-for-i18n-format-render"
            }, l ? me().createElement("a", {
                "aria-label": " ",
                href: it(i, a),
                dangerouslySetInnerHTML: {
                    __html: r(nt.premiumDiscountSavingsLabel, e)
                },
                onClick: function(e) {
                    t(e), window.open(it(i, a))
                }
            }) : me().createElement("a", {
                "aria-label": " ",
                href: it(i, a),
                dangerouslySetInnerHTML: {
                    __html: r(nt.premiumDiscountOpportunityPromptLabel, e)
                },
                onClick: function(e) {
                    t(e), window.open(it(i, a))
                }
            })))
        }())))
    }
    ot.propTypes = {
        translate: o().func.isRequired,
        price: o().number.isRequired,
        itemType: o().string.isRequired,
        itemDetailItemId: o().number.isRequired,
        premiumPriceInRobux: o().number.isRequired,
        premiumDiscountPercentage: o().number.isRequired,
        userQualifiesForPremiumPrices: o().bool.isRequired,
        loading: o().bool.isRequired,
        isOwned: o().bool.isRequired,
        loadFailure: o().bool.isRequired,
        unitsAvailableForConsumption: o().number.isRequired,
        isLimited: o().bool.isRequired,
        isPlugin: o().bool.isRequired,
        resellerAvailable: o().bool.isRequired,
        priceStatus: o().string.isRequired,
        offSaleDeadline: o().string.isRequired,
        isMarketPlaceEnabled: o().bool.isRequired
    };
    var st = (0, s.withTranslations)(ot, c.itemModelResources);

    function lt(e, t) {
        return function(e) {
            if (Array.isArray(e)) return e
        }(e) || function(e, t) {
            if ("undefined" == typeof Symbol || !(Symbol.iterator in Object(e))) return;
            var r = [],
                n = !0,
                a = !1,
                i = void 0;
            try {
                for (var o, s = e[Symbol.iterator](); !(n = (o = s.next()).done) && (r.push(o.value), !t || r.length !== t); n = !0);
            } catch (e) {
                a = !0, i = e
            } finally {
                try {
                    n || null == s.return || s.return()
                } finally {
                    if (a) throw i
                }
            }
            return r
        }(e, t) || function(e, t) {
            if (!e) return;
            if ("string" == typeof e) return ct(e, t);
            var r = Object.prototype.toString.call(e).slice(8, -1);
            "Object" === r && e.constructor && (r = e.constructor.name);
            if ("Map" === r || "Set" === r) return Array.from(e);
            if ("Arguments" === r || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return ct(e, t)
        }(e, t) || function() {
            throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }

    function ct(e, t) {
        (null == t || t > e.length) && (t = e.length);
        for (var r = 0, n = new Array(t); r < t; r++) n[r] = e[r];
        return n
    }
    var ut = a.resources;

    function dt(e) {
        var t = e.translate,
            r = e.offSaleDeadline,
            e = lt((0, de.useState)(0), 2),
            n = e[0],
            a = e[1],
            e = lt((0, de.useState)(0), 2),
            i = e[0],
            o = e[1],
            e = lt((0, de.useState)(0), 2),
            s = e[0],
            l = e[1],
            e = lt((0, de.useState)(0), 2),
            c = e[0],
            u = e[1];
        (0, de.useEffect)(function() {
            function e() {
                var e;
                new Date < new Date(r) && (e = +new Date, e = (new Date(r).getTime() - e) / 1e3, a(Math.floor(e / 86400)), o(Math.floor(e / 3600 % 24)), l(Math.floor(e / 60 % 60)), u(Math.floor(e % 60)))
            }
            var t;
            return e(), t = setInterval(e, 1e3),
                function() {
                    return clearInterval(t)
                }
        }, [a, o, l, u]);
        return me().createElement("div", {
            id: "sale-clock",
            className: "text-error sale-clock desktop-sale-clock"
        }, function() {
            if (n < 1) {
                var e = {
                    numberOfHours: i,
                    numberOfMinutes: s,
                    numberOfSeconds: c
                };
                return me().createElement("div", {
                    className: "text",
                    dangerouslySetInnerHTML: {
                        __html: t(ut.OffsaleCountdownHourMinuteSecondLabel, e)
                    }
                })
            }
            if (c < 1) return window.location.reload(), null;
            e = {
                numberOfDays: n,
                numberOfHours: i,
                numberOfMinutes: s
            };
            return me().createElement("div", {
                className: "text",
                dangerouslySetInnerHTML: {
                    __html: t(ut.CountdownTimerDayHourMinute, e)
                }
            })
        }())
    }
    dt.propTypes = {
        translate: o().func.isRequired,
        offSaleDeadline: o().string.isRequired
    };
    var mt = (0, s.withTranslations)(dt, c.itemResources),
        pt = a.resources,
        ft = a.assetTypes,
        bt = a.assetCategory,
        yt = S.getInventoryUrl;

    function gt(e) {
        var t = e.translate,
            r = e.assetType,
            n = _e.deviceMeta.getDeviceMeta(),
            a = "phone" === n.deviceType,
            e = yt(_e.authenticatedUser.id),
            i = r === ft.Plugin || r === ft.Decal || r === ft.Model || r === ft.Video || r === ft.Animation ? bt.Library : r === ft.Place || r === ft.Badge || r === ft.GamePass || r === ft.Animation ? null : bt.Catalog;
        return i !== bt.Catalog || n.isInApp || !_e.deviceMeta.isAndroidApp && !_e.deviceMeta.isIosApp || !_e.deviceMeta.isPhone && !_e.deviceMeta.isTablet ? i !== bt.Catalog || a ? me().createElement("a", {
            id: "inventory-button",
            href: e,
            className: "btn-fixed-width-lg btn-control-md"
        }, t(pt.inventoryAction)) : me().createElement("a", {
            id: "edit-avatar-button",
            href: "/my/avatar",
            className: "btn-control-md"
        }, me().createElement("span", {
            className: "icon-nav-charactercustomizer"
        })) : me().createElement("a", {
            id: "open-in-avatar-editor-button",
            href: "/#",
            className: "btn-fixed-width-lg btn-control-md"
        }, me().createElement("span", {
            className: "icon-nav-charactercustomizer"
        }))
    }
    gt.propTypes = {
        translate: o().func.isRequired,
        assetType: o().number.isRequired
    };
    var ht = (0, s.withTranslations)(gt, c.itemResources),
        vt = Ge,
        St = a.assetTypes;

    function Pt(e) {
        var t = e.translate,
            e = vt(),
            r = e.itemDetailItemId,
            e = e.itemDetailItemType,
            n = Ve(ae, r, e).itemDetail;
        return me().createElement(me().Fragment, null, me().createElement(st, {
            translate: t,
            price: n.price,
            itemType: n.itemType,
            itemDetailItemId: r,
            premiumPriceInRobux: n.premiumPriceInRobux,
            premiumDiscountPercentage: n.premiumDiscountPercentage,
            userQualifiesForPremiumPrices: _e.authenticatedUser.isPremiumUser,
            isOwned: n.owned,
            loading: n.loading,
            loadFailure: n.loadFailure,
            unitsAvailableForConsumption: n.unitsAvailableForConsumption,
            isLimited: n.isLimited,
            isPlugin: n.assetType === St.Plugin,
            resellerAvailable: n.resellerAvailable,
            priceStatus: n.priceStatus,
            offSaleDeadline: n.offSaleDeadline,
            isMarketPlaceEnabled: n.isMarketPlaceEnabled
        }), !n.loadFailure && (n.owned && (!n.isLimited || 0 < n.unitsAvailableForConsumption) ? me().createElement("div", {
            className: "action-button"
        }, me().createElement(ht, {
            translate: t,
            assetType: n.assetType
        })) : me().createElement("div", {
            className: "action-button"
        }, me().createElement(Ze, {
            translate: t,
            productId: n.productId,
            price: n.price,
            itemType: n.itemType,
            assetTypeDisplayName: n.assetTypeDisplayName,
            itemName: n.name,
            sellerName: n.creatorName,
            expectedSellerId: n.expectedSellerId,
            isPurchasable: n.isPurchasable,
            isOwned: n.owned,
            isInstallable: n.assetType === St.Plugin,
            itemDetailItemId: r,
            loading: n.loading,
            hasLimitedPrivateSales: n.hasLimitedPrivateSales,
            userQualifiesForPremiumPrices: _e.authenticatedUser.isPremiumUser,
            premiumPriceInRobux: n.premiumPriceInRobux,
            isAuthenticated: _e.authenticatedUser.isAuthenticated,
            unitsAvailableForConsumption: n.unitsAvailableForConsumption,
            isLimited: n.isLimited,
            resellerAvailable: n.resellerAvailable,
            firstReseller: n.firstReseller,
            isMarketPlaceEnabled: n.isMarketPlaceEnabled
        }), null !== n.offSaleDeadline && me().createElement(mt, {
            translate: t,
            offSaleDeadline: n.offSaleDeadline
        }))))
    }
    Pt.propTypes = {
        translate: o().func.isRequired
    };
    var Et = Pt;

    function It(e, t) {
        return function(e) {
            if (Array.isArray(e)) return e
        }(e) || function(e, t) {
            if ("undefined" == typeof Symbol || !(Symbol.iterator in Object(e))) return;
            var r = [],
                n = !0,
                a = !1,
                i = void 0;
            try {
                for (var o, s = e[Symbol.iterator](); !(n = (o = s.next()).done) && (r.push(o.value), !t || r.length !== t); n = !0);
            } catch (e) {
                a = !0, i = e
            } finally {
                try {
                    n || null == s.return || s.return()
                } finally {
                    if (a) throw i
                }
            }
            return r
        }(e, t) || function(e, t) {
            if (!e) return;
            if ("string" == typeof e) return wt(e, t);
            var r = Object.prototype.toString.call(e).slice(8, -1);
            "Object" === r && e.constructor && (r = e.constructor.name);
            if ("Map" === r || "Set" === r) return Array.from(e);
            if ("Arguments" === r || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return wt(e, t)
        }(e, t) || function() {
            throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }

    function wt(e, t) {
        (null == t || t > e.length) && (t = e.length);
        for (var r = 0, n = new Array(t); r < t; r++) n[r] = e[r];
        return n
    }

    function At(t, e) {
        var r, n = Object.keys(t);
        return Object.getOwnPropertySymbols && (r = Object.getOwnPropertySymbols(t), e && (r = r.filter(function(e) {
            return Object.getOwnPropertyDescriptor(t, e).enumerable
        })), n.push.apply(n, r)), n
    }

    function Tt(n) {
        for (var e = 1; e < arguments.length; e++) {
            var a = null != arguments[e] ? arguments[e] : {};
            e % 2 ? At(Object(a), !0).forEach(function(e) {
                var t, r;
                t = n, e = a[r = e], r in t ? Object.defineProperty(t, r, {
                    value: e,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[r] = e
            }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(n, Object.getOwnPropertyDescriptors(a)) : At(Object(a)).forEach(function(e) {
                Object.defineProperty(n, e, Object.getOwnPropertyDescriptor(a, e))
            })
        }
        return n
    }
    var Rt, e = function(e, t) {
            e = Tt(Tt({}, e), {}, {
                expectedSellerId: t.expectedSellerId,
                owned: t.owned,
                id: t.id,
                itemType: t.itemType,
                assetType: t.assetType,
                name: t.name,
                description: t.description,
                productId: t.productId,
                price: t.price,
                lowestPrice: t.lowestPrice,
                creatorTargetId: t.creatorTargetId,
                creatorName: t.creatorName,
                hasLimitedPrivateSales: void 0 !== t.lowestPrice,
                isPublicDomain: 0 === t.price,
                offSaleDeadline: t.offSaleDeadline,
                isLimited: t.itemRestrictions.includes("Limited") || t.itemRestrictions.includes("LimitedUnique"),
                collectibleItemId: t.collectibleItemId,
                collectibleItemDetails: t.collectibleItemDetails,
                unitsAvailableForConsumption: void 0 !== t.unitsAvailableForConsumption ? t.unitsAvailableForConsumption : 0,
                priceStatus: null !== (e = t.priceStatus) && void 0 !== e ? e : t.priceStatus,
                itemRestrictions: t.itemRestrictions
            });
            return void 0 !== t.premiumPricing && (e.premiumPriceInRobux = t.premiumPricing.premiumPriceInRobux, e.premiumDiscountPercentage = t.premiumPricing.premiumDiscountPercentage), e.isLimited && (e.price = void 0 !== e.lowestPrice ? e.lowestPrice : e.price), void 0 !== e.collectibleItemId && (e.resellerAvailable = t.hasResellers, e.isPurchasable = void 0 !== t.lowestPrice, e.isMarketPlaceEnabled = "ShopAndAllExperiences" === t.saleLocationType), e
        },
        xt = function(e, t) {
            e = Tt({}, e);
            return e.resellerAvailable = 0 < t.data.data.length, e.resellerAvailable && (t = It(t.data.data, 1)[0], e.price = t.price, e.firstReseller = t), e
        },
        Ct = function(e, t, r) {
            var n = a.errorMessages,
                e = Tt({}, e);
            return !t.purchasable && t.reason && t.reason !== n.insufficientFunds && t.reason !== n.twoStepVerificationRequired ? e.isPurchasable = t.purchasable : (!t.purchasable && t.reason && t.reason === n.twoStepVerificationRequired && (e.twoStepVerificationRequired = !0), e.isPurchasable = !0), e.assetTypeDisplayName = t.assetTypeDisplayName, e.loading = !1, e.loadFailure = !1, e.isMarketPlaceEnabled = r.data.isMarketPlaceEnabled && r.data.isItemsXchangeEnabled, e
        },
        Nt = function(e) {
            e = Tt({}, e);
            return e.isPurchasable = !1, e
        };
    (Ge = Rt = Rt || {}).Asset = "asset", Ge.Bundle = "bundle";
    var Mt = Rt;

    function Ft(e, t, r, n, a, i, o) {
        try {
            var s = e[i](o),
                l = s.value
        } catch (e) {
            return void r(e)
        }
        s.done ? t(l) : Promise.resolve(l).then(n, a)
    }

    function Ut(s) {
        return function() {
            var e = this,
                o = arguments;
            return new Promise(function(t, r) {
                var n = s.apply(e, o);

                function a(e) {
                    Ft(n, t, r, a, i, "next", e)
                }

                function i(e) {
                    Ft(n, t, r, a, i, "throw", e)
                }
                a(void 0)
            })
        }
    }

    function Dt(e, t) {
        return function(e) {
            if (Array.isArray(e)) return e
        }(e) || function(e, t) {
            if ("undefined" == typeof Symbol || !(Symbol.iterator in Object(e))) return;
            var r = [],
                n = !0,
                a = !1,
                i = void 0;
            try {
                for (var o, s = e[Symbol.iterator](); !(n = (o = s.next()).done) && (r.push(o.value), !t || r.length !== t); n = !0);
            } catch (e) {
                a = !0, i = e
            } finally {
                try {
                    n || null == s.return || s.return()
                } finally {
                    if (a) throw i
                }
            }
            return r
        }(e, t) || function(e, t) {
            if (!e) return;
            if ("string" == typeof e) return Ot(e, t);
            var r = Object.prototype.toString.call(e).slice(8, -1);
            "Object" === r && e.constructor && (r = e.constructor.name);
            if ("Map" === r || "Set" === r) return Array.from(e);
            if ("Arguments" === r || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return Ot(e, t)
        }(e, t) || function() {
            throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }

    function Ot(e, t) {
        (null == t || t > e.length) && (t = e.length);
        for (var r = 0, n = new Array(t); r < t; r++) n[r] = e[r];
        return n
    }
    var Bt = a.maxBatchLoadRetries,
        qt = e,
        Lt = xt,
        _t = Ct,
        kt = Nt,
        jt = function(i) {
            var a = (r = Dt((0, de.useState)(), 2))[0],
                t = r[1],
                e = Dt((0, de.useState)([]), 2),
                r = e[0],
                o = e[1],
                s = (e = Dt((0, de.useState)({}), 2))[0],
                l = e[1],
                n = 0,
                c = function() {
                    n < Bt ? (b(), n += 1) : o([{
                        loading: !1,
                        loadFailure: !0
                    }])
                },
                u = (0, de.useCallback)(function() {
                    _e.authenticatedUser.isAuthenticated ? se().then(function(e) {
                        t(e)
                    }).catch(function() {
                        c()
                    }) : t({
                        data: {
                            isMarketplaceEnabled: !1,
                            isItemsXchangeEnabled: !1
                        }
                    })
                }, []);

            function d(e) {
                return m.apply(this, arguments)
            }

            function m() {
                return (m = Ut(regeneratorRuntime.mark(function e(t) {
                    var r, n;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                if (t.inCache) return e.abrupt("return", s[t.itemType.toLowerCase()][t.id]);
                                e.next = 2;
                                break;
                            case 2:
                                if ((r = qt({}, t)).isLimited) return e.prev = 4, e.next = 7, oe(r.id);
                                e.next = 14;
                                break;
                            case 7:
                                n = e.sent, r = Lt(r, n), e.next = 14;
                                break;
                            case 11:
                                e.prev = 11, e.t0 = e.catch(4), r.resellerAvailable = !1;
                            case 14:
                                if (void 0 === t.productId) {
                                    e.next = 24;
                                    break
                                }
                                if (!_e.authenticatedUser.isAuthenticated) {
                                    e.next = 23;
                                    break
                                }
                                if (void 0 === r.collectibleItemId) return e.next = 19, ie(t.productId);
                                e.next = 21;
                                break;
                            case 19:
                                n = e.sent, r = _t(r, n.data, a);
                            case 21:
                                e.next = 24;
                                break;
                            case 23:
                                r = kt(r);
                            case 24:
                                return e.abrupt("return", r);
                            case 25:
                            case "end":
                                return e.stop()
                        }
                    }, e, null, [
                        [4, 11]
                    ])
                }))).apply(this, arguments)
            }

            function p() {
                return (p = Ut(regeneratorRuntime.mark(function e(t) {
                    var r, n;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return e.prev = 0, e.next = 3, Promise.all(t.map(function(e) {
                                    return d(e)
                                }));
                            case 3:
                                r = e.sent, o(r), n = s, r.forEach(function(e) {
                                    e.isLimited || s[e.itemType.toLowerCase()][e.id] || (n[e.itemType.toLowerCase()][e.id] = e)
                                }), l(n), e.next = 13;
                                break;
                            case 10:
                                e.prev = 10, e.t0 = e.catch(0), c();
                            case 13:
                            case "end":
                                return e.stop()
                        }
                    }, e, null, [
                        [0, 10]
                    ])
                }))).apply(this, arguments)
            }

            function f() {
                return (f = Ut(regeneratorRuntime.mark(function e() {
                    var t, r, n, a;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                if (t = [], i.forEach(function(e) {
                                        void 0 === s[e.itemType.toLowerCase()][e.id] && t.push(e)
                                    }), 0 < t.length) return n = [], t.map(function(e) {
                                    return n.push({
                                        itemType: e.itemType,
                                        id: e.id
                                    })
                                }), e.next = 7, fe.ItemDetailsHydrationService.getItemDetails(n);
                                e.next = 8;
                                break;
                            case 7:
                                r = e.sent;
                            case 8:
                                return a = [], i.forEach(function(t) {
                                    var e;
                                    void 0 === s[t.itemType.toLowerCase()][t.id] ? (e = r.find(function(e) {
                                        return e.id === t.id && e.itemType.toLowerCase() === t.itemType.toLowerCase()
                                    })) && a.push(e) : a.push({
                                        id: t.id,
                                        itemType: t.itemType,
                                        inCache: !0
                                    })
                                }), e.abrupt("return", a);
                            case 11:
                            case "end":
                                return e.stop()
                        }
                    }, e)
                }))).apply(this, arguments)
            }
            var b = (0, de.useCallback)(function() {
                (function() {
                    return f.apply(this, arguments)
                })().then(function(e) {
                    try {
                        ! function() {
                            p.apply(this, arguments)
                        }(e)
                    } catch (e) {
                        c()
                    }
                }).catch(function() {
                    c()
                })
            }, [a, i, d]);
            return (0, de.useEffect)(function() {
                var e = {};
                e[Mt.Asset] = {}, e[Mt.Bundle] = {}, l(e), u()
            }, []), (0, de.useEffect)(function() {
                void 0 !== a && b()
            }, [a, i]), {
                itemDetails: r,
                batchLoadItemDetails: b
            }
        };
    (Nt = lr = lr || {}).Success = "Success", Nt.AlreadyOwned = "ALREADY_OWNED", Nt.InsufficientFunds = "INSUFFICIENT_ROBUX", Nt.ExceptionOccured = "INTERNAL", Nt.TooManyPurchases = "QUOTA_EXCEEDED", Nt.CaughtError = "CaughtError", Nt.PremiumNeeded = "INSUFFICIENT_MEMBERSHIP", Nt.NoSellers = "NOT_FOR_SALE", Nt.TwoStepVerificationRequired = "TwoStepVerificationRequired", Nt.InExperienceOnly = "PURCHASE_PLACE_INVALID";
    var Ht = lr;

    function Vt(e, t, r, n, a, i, o) {
        try {
            var s = e[i](o),
                l = s.value
        } catch (e) {
            return void r(e)
        }
        s.done ? t(l) : Promise.resolve(l).then(n, a)
    }

    function Gt(s) {
        return function() {
            var e = this,
                o = arguments;
            return new Promise(function(t, r) {
                var n = s.apply(e, o);

                function a(e) {
                    Vt(n, t, r, a, i, "next", e)
                }

                function i(e) {
                    Vt(n, t, r, a, i, "throw", e)
                }
                a(void 0)
            })
        }
    }

    function Wt(e, t) {
        return function(e) {
            if (Array.isArray(e)) return e
        }(e) || function(e, t) {
            if ("undefined" == typeof Symbol || !(Symbol.iterator in Object(e))) return;
            var r = [],
                n = !0,
                a = !1,
                i = void 0;
            try {
                for (var o, s = e[Symbol.iterator](); !(n = (o = s.next()).done) && (r.push(o.value), !t || r.length !== t); n = !0);
            } catch (e) {
                a = !0, i = e
            } finally {
                try {
                    n || null == s.return || s.return()
                } finally {
                    if (a) throw i
                }
            }
            return r
        }(e, t) || function(e, t) {
            if (!e) return;
            if ("string" == typeof e) return zt(e, t);
            var r = Object.prototype.toString.call(e).slice(8, -1);
            "Object" === r && e.constructor && (r = e.constructor.name);
            if ("Map" === r || "Set" === r) return Array.from(e);
            if ("Arguments" === r || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return zt(e, t)
        }(e, t) || function() {
            throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }

    function zt(e, t) {
        (null == t || t > e.length) && (t = e.length);
        for (var r = 0, n = new Array(t); r < t; r++) n[r] = e[r];
        return n
    }
    var Xt = a.resources,
        $t = a.batchBuyMaxThumbnails,
        Qt = a.floodcheckTime;

    function Yt(e) {
        var t = e.itemsCount,
            r = e.item,
            n = e.index,
            a = r.name,
            e = t - $t,
            n = $t < t && n === $t - 1;
        return me().createElement("div", {
            className: "modal-multi-item-image-container"
        }, me().createElement(We.Thumbnail2d, {
            type: r.itemType.toLowerCase() === Mt.Bundle ? We.ThumbnailTypes.bundleThumbnail : We.ThumbnailTypes.assetThumbnail,
            size: We.DefaultThumbnailSize,
            targetId: r.id,
            containerClass: "batch-buy-thumbnail",
            format: We.ThumbnailFormat.webp,
            altName: a
        }), n && me().createElement("div", {
            className: "thumb-overlay"
        }, me().createElement("div", {
            className: "font-header-1"
        }, "＋", e)))
    }

    function Jt() {
        return (Jt = Object.assign || function(e) {
            for (var t = 1; t < arguments.length; t++) {
                var r, n = arguments[t];
                for (r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
            }
            return e
        }).apply(this, arguments)
    }

    function Kt(e, t) {
        return function(e) {
            if (Array.isArray(e)) return e
        }(e) || function(e, t) {
            if ("undefined" == typeof Symbol || !(Symbol.iterator in Object(e))) return;
            var r = [],
                n = !0,
                a = !1,
                i = void 0;
            try {
                for (var o, s = e[Symbol.iterator](); !(n = (o = s.next()).done) && (r.push(o.value), !t || r.length !== t); n = !0);
            } catch (e) {
                a = !0, i = e
            } finally {
                try {
                    n || null == s.return || s.return()
                } finally {
                    if (a) throw i
                }
            }
            return r
        }(e, t) || function(e, t) {
            if (!e) return;
            if ("string" == typeof e) return Zt(e, t);
            var r = Object.prototype.toString.call(e).slice(8, -1);
            "Object" === r && e.constructor && (r = e.constructor.name);
            if ("Map" === r || "Set" === r) return Array.from(e);
            if ("Arguments" === r || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return Zt(e, t)
        }(e, t) || function() {
            throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }

    function Zt(e, t) {
        (null == t || t > e.length) && (t = e.length);
        for (var r = 0, n = new Array(t); r < t; r++) n[r] = e[r];
        return n
    }
    var er = a.resources,
        tr = S.getVngBuyRobuxBehaviorUrl,
        rr = function() {
            var e = {
                url: tr(),
                retryable: !0,
                withCredentials: !0
            };
            return pe.httpService.get(e)
        };

    function nr(e, t) {
        return function(e) {
            if (Array.isArray(e)) return e
        }(e) || function(e, t) {
            if ("undefined" == typeof Symbol || !(Symbol.iterator in Object(e))) return;
            var r = [],
                n = !0,
                a = !1,
                i = void 0;
            try {
                for (var o, s = e[Symbol.iterator](); !(n = (o = s.next()).done) && (r.push(o.value), !t || r.length !== t); n = !0);
            } catch (e) {
                a = !0, i = e
            } finally {
                try {
                    n || null == s.return || s.return()
                } finally {
                    if (a) throw i
                }
            }
            return r
        }(e, t) || function(e, t) {
            if (!e) return;
            if ("string" == typeof e) return ar(e, t);
            var r = Object.prototype.toString.call(e).slice(8, -1);
            "Object" === r && e.constructor && (r = e.constructor.name);
            if ("Map" === r || "Set" === r) return Array.from(e);
            if ("Arguments" === r || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return ar(e, t)
        }(e, t) || function() {
            throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }

    function ar(e, t) {
        (null == t || t > e.length) && (t = e.length);
        for (var r = 0, n = new Array(t); r < t; r++) n[r] = e[r];
        return n
    }
    var ir, or = (Nt = nr(x(), 2))[0],
        sr = Nt[1],
        lr = nr((ir = (Ct = Wt((0, P.createModal)(), 2))[0], Ct = Ct[1], dr.defaultProps = {
            title: "",
            loading: !1
        }, dr.propTypes = {
            translate: o().func.isRequired,
            title: o().string,
            expectedTotalPrice: o().number.isRequired,
            currentRobuxBalance: o().number.isRequired,
            itemDetails: o().arrayOf(o().shape({
                productId: o().number.isRequired,
                price: o().number.isRequired,
                itemName: o().string.isRequired,
                itemType: o().string.isRequired,
                assetTypeDisplayName: o().string.isRequired,
                sellerName: o().string.isRequired,
                expectedSellerId: o().number.isRequired,
                isPurchasable: o().bool.isRequired,
                isOwned: o().bool.isRequired,
                isPlugin: o().bool.isRequired,
                itemDetailItemId: o().number.isRequired,
                loading: o().bool.isRequired,
                userQualifiesForPremiumPrices: o().bool.isRequired,
                premiumPriceInRobux: o().number.isRequired,
                isAuthenticated: o().bool.isRequired,
                resellerAvailable: o().bool.isRequired,
                firstReseller: o().shape({
                    seller: {
                        name: o().string.isRequired,
                        id: o().number.isRequired
                    },
                    userAssetId: o().number.isRequired
                }).isRequired,
                isMarketPlaceEnabled: o().bool.isRequired
            })).isRequired,
            onCancel: o().func.isRequired,
            onTransactionComplete: o().func.isRequired,
            onAction: o().func.isRequired,
            loading: o().bool,
            productSurface: o().string.isRequired,
            systemFeedbackService: o().func.isRequired
        }, [(0, s.withTranslations)(dr, c.purchasingResources), Ct]), 2),
        cr = lr[0],
        ur = lr[1];

    function dr(e) {
        var t, r = e.translate,
            n = e.title,
            a = e.expectedTotalPrice,
            s = e.itemDetails,
            i = e.currentRobuxBalance,
            o = e.onCancel,
            l = e.onTransactionComplete,
            c = e.onAction,
            u = e.loading,
            d = e.productSurface,
            m = e.systemFeedbackService,
            p = Wt((0, de.useState)(!1), 2),
            f = p[0],
            b = p[1],
            y = function() {
                m.loading(r("Message.TwoStepVerificationBatchPurchase")), b(!0)
            },
            g = Wt((0, de.useState)(!1), 2),
            h = g[0],
            v = g[1],
            S = {
                itemCount: s.length,
                robux: (0, I.renderToString)(me().createElement("span", {
                    className: "robux-price"
                }, me().createElement(w, {
                    price: a
                })))
            },
            e = Xt.batchBuyPromptMessage,
            p = 0 === a ? (t = r(Xt.getItemHeading), r(Xt.getNowAction)) : (t = r(Xt.buyItemHeading), r(Xt.buyNowAction)),
            g = null == s ? void 0 : s.slice(0, $t);

        function P(e) {
            var t = function(e, t) {
                    var r = 0,
                        n = [];
                    if (200 === e.status) {
                        if (e.data.fulfillmentGroups[0].lineItems.forEach(function(t) {
                                var e;
                                "SUCCEEDED" === t.status ? r += 1 : (e = n.find(function(e) {
                                    return e.error === t.errorReason
                                })) ? e.count += 1 : n.push({
                                    error: t.errorReason,
                                    count: 1
                                })
                            }), r === e.data.fulfillmentGroups[0].lineItems.length) return {
                            success: !0,
                            message: Xt.purchaseCompleteHeading
                        };
                        var a = {
                            error: "",
                            count: 0
                        };
                        if (n.forEach(function(e) {
                                e.count > a.count && (a = e)
                            }), 0 < r) switch (a.error) {
                            case Ht.AlreadyOwned:
                                return {
                                    success: !1,
                                    message: Xt.batchBuyPartialSuccessItemsOwnedFailureMessage,
                                    params: {
                                        itemCountSuccess: r,
                                        itemCountFailure: a.count
                                    }
                                };
                            case Ht.InsufficientFunds:
                                return {
                                    success: !1,
                                    message: Xt.batchBuyPartialSuccessInsufficientFundsFailureMessage,
                                    params: {
                                        itemCountSuccess: r,
                                        itemCountFailure: a.count
                                    }
                                };
                            case Ht.ExceptionOccured:
                                return {
                                    success: !1,
                                    message: Xt.batchBuyPartialSuccessNetworkErrorFailureMessage,
                                    params: {
                                        itemCountSuccess: r,
                                        itemCountFailure: a.count
                                    }
                                };
                            case Ht.TooManyPurchases:
                                return {
                                    success: !1,
                                    message: Xt.batchBuyPartialSuccessFloodcheckFailureMessage,
                                    params: {
                                        itemCountSuccess: r,
                                        itemCountFailure: a.count
                                    }
                                };
                            case Ht.PremiumNeeded:
                                return {
                                    success: !1,
                                    message: Xt.batchBuyPartialSuccessPremiumNeededFailureMessage,
                                    params: {
                                        itemCountSuccess: r,
                                        itemCountFailure: a.count
                                    }
                                };
                            case Ht.NoSellers:
                                return {
                                    success: !1,
                                    message: Xt.batchBuyPartialSuccessNoSellersFailureMessage,
                                    params: {
                                        itemCountSuccess: r,
                                        itemCountFailure: a.count
                                    }
                                };
                            case Ht.InExperienceOnly:
                                return {
                                    success: !1,
                                    message: Xt.batchBuyPartialSuccessInExperienceOnlyFailureMessage,
                                    params: {
                                        itemCountSuccess: r,
                                        itemCountFailure: a.count
                                    }
                                };
                            default:
                                return {
                                    success: !1,
                                    message: Xt.batchBuyPartialSuccessGeneralFailureMessage,
                                    params: {
                                        itemCountSuccess: r,
                                        itemCountFailure: a.count
                                    }
                                }
                        } else switch (a.error) {
                            case Ht.AlreadyOwned:
                                return {
                                    success: !1,
                                    message: Xt.batchBuyItemsOwnedFailureMessage
                                };
                            case Ht.InsufficientFunds:
                                return {
                                    success: !1,
                                    message: Xt.insufficientFundsFailureMessage
                                };
                            case Ht.ExceptionOccured:
                                return {
                                    success: !1,
                                    message: Xt.networkErrroFailureMessage
                                };
                            case Ht.TooManyPurchases:
                                return {
                                    success: !1,
                                    message: Xt.floodcheckFailureMessage,
                                    params: {
                                        throttleTime: Qt
                                    }
                                };
                            case Ht.PremiumNeeded:
                                return {
                                    success: !1,
                                    message: Xt.premiumNeededFailureMessage
                                };
                            case Ht.NoSellers:
                                return {
                                    success: !1,
                                    message: Xt.noSellersFailureMessage
                                };
                            case Ht.InExperienceOnly:
                                return {
                                    success: !1,
                                    message: Xt.inExperienceOnlyFailureMessage
                                };
                            default:
                                return {
                                    success: !1,
                                    message: Xt.purchaseErrorFailureMessage
                                }
                        }
                    } else if (403 === e.status && e.data.message.includes("2sv")) t();
                    else if (400 === e.status && e.data.message.includes("InsufficientTotalBalance")) return {
                        success: !1,
                        message: Xt.insufficientFundsFailureMessage
                    };
                    return {
                        success: !1,
                        message: Xt.purchaseErrorFailureMessage
                    }
                }(e, y),
                e = t.params ? r(t.message, t.params) : r(t.message);
            t.success ? m.success(e) : m.warning(e)
        }

        function E() {
            return (E = Gt(regeneratorRuntime.mark(function e() {
                var t, r, n, a, i, o;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                        case 0:
                            return t = {
                                strategy: "BEST_EFFORT",
                                lineItems: []
                            }, r = [], n = [], s.forEach(function(e) {
                                var t = {};
                                void 0 !== e.collectibleItemId ? (!("ExperiencesDevApiOnly" !== e.collectibleItemDetails.saleLocationType && (!e.itemRestrictions.includes("Collectible") || 0 < e.collectibleItemDetails.unitsAvailableForConsumption && (!e.collectibleItemDetails.hasResellers || e.collectibleItemDetails.price < e.collectibleItemDetails.lowestResalePrice))) && e.collectibleItemDetails.lowestAvailableResaleProductId ? t.collectibleProductId = e.collectibleItemDetails.lowestAvailableResaleProductId : t.collectibleProductId = e.collectibleItemDetails.collectibleProductId, t.agreedPriceRobux = e.collectibleItemDetails.lowestPrice) : void 0 !== e.firstReseller ? (t.limitedV1InstanceId = "".concat(e.firstReseller.userAssetId), t.agreedPriceRobux = e.firstReseller.price) : (t.virtualEconomyProductId = "".concat(e.productId), t.agreedPriceRobux = e.premiumPriceInRobux && _e.authenticatedUser.isPremiumUser ? e.premiumPriceInRobux : e.price), r.push(t);
                                t = {
                                    data: {
                                        itemData: {},
                                        reason: ""
                                    }
                                };
                                "Asset" === e.itemType ? t.data.itemData.assetId = e.id : t.data.itemData.bundleId = e.id, n.push(t)
                            }), t.lineItems = r, e.prev = 5, e.next = 8, ge.bulkPurchaseItem(fe.CurrentUser.userId, d, t, pe.uuidService.generateRandomUuid());
                        case 8:
                            a = e.sent, i = 0, a.data.fulfillmentGroups[0].lineItems.forEach(function(e) {
                                n[i].data.reason = "SUCCEEDED" === e.status ? "Success" : e.errorReason, i += 1
                            }), e.next = 18;
                            break;
                        case 13:
                            e.prev = 13, e.t0 = e.catch(5), a = e.t0, o = 0, n.forEach(function(e) {
                                n[o].data.reason = a.data.message, o += 1
                            });
                        case 18:
                            P(a), l(n);
                        case 20:
                        case "end":
                            return e.stop()
                    }
                }, e, null, [
                    [5, 13]
                ])
            }))).apply(this, arguments)
        }
        g = me().createElement(de.Fragment, null, me().createElement("div", {
            className: "modal-message multi-item",
            dangerouslySetInnerHTML: {
                __html: r(e, S)
            }
        }), void 0 !== s && 0 < s.length && me().createElement("div", {
            className: "modal-multi-item-images-container"
        }, g.map(function(e, t) {
            return me().createElement(Yt, {
                key: e.itemId,
                itemsCount: s.length,
                item: e,
                index: t
            })
        })));
        return me().createElement(me().Fragment, null, me().createElement(xe, {
            isTwoStepVerificationActive: f,
            stopTwoStepVerification: function() {
                v(!0), b(!1)
            },
            systemFeedbackService: m
        }), me().createElement(ir, {
            title: n || t,
            body: g,
            neutralButtonText: r(Xt.cancelAction),
            actionButtonText: p,
            onAction: function() {
                var t = !1;
                s.forEach(function(e) {
                    t = t || e.twoStepVerificationRequired
                }), t && !h ? y() : (function() {
                    E.apply(this, arguments)
                }(), c())
            },
            onNeutral: function() {
                o()
            },
            footerText: me().createElement(M, {
                expectedPrice: a,
                currentRobuxBalance: i
            }),
            loading: u,
            actionButtonShow: s
        }))
    }
    var mr, pr = (Nt = nr((mr = (Ct = Kt((0, P.createModal)(), 2))[0], Ct = Ct[1], br.defaultProps = {
            onContinueToPayment: null
        }, br.propTypes = {
            translate: o().func.isRequired,
            onContinueToPayment: o().func
        }, [(0, s.withTranslations)(br, c.purchasingResources), Ct]), 2))[0],
        fr = Nt[1];

    function br(e) {
        var t = e.translate,
            r = e.onContinueToPayment,
            e = t(er.redirectToPartnerWebsiteMessage, {
                linebreak: "\n\n"
            }) || "This purchase must be completed on our partner’s website. You will be returned to Roblox after the purchase is completed.\n\n Proceed to partner website for payment?",
            e = me().createElement("p", {
                className: "modal-body"
            }, e);
        return me().createElement(mr, Jt({
            title: t(er.leavingRobloxHeading) || "Leaving Roblox",
            body: e,
            neutralButtonText: t(er.cancelAction),
            actionButtonText: t(er.continueToPaymentAction) || "Continue To Payment",
            onAction: function() {
                E.paymentFlowAnalyticsService.sendUserPurchaseFlowEvent(E.paymentFlowAnalyticsService.ENUM_TRIGGERING_CONTEXT.WEB_CATALOG_ROBUX_UPSELL, !0, E.paymentFlowAnalyticsService.ENUM_VIEW_NAME.LEAVE_ROBLOX_WARNING, E.paymentFlowAnalyticsService.ENUM_PURCHASE_EVENT_TYPE.USER_INPUT, E.paymentFlowAnalyticsService.ENUM_VIEW_MESSAGE.CONTINUE_TO_VNG), r()
            },
            onClose: function() {
                E.paymentFlowAnalyticsService.sendUserPurchaseFlowEvent(E.paymentFlowAnalyticsService.ENUM_TRIGGERING_CONTEXT.WEB_CATALOG_ROBUX_UPSELL, !0, E.paymentFlowAnalyticsService.ENUM_VIEW_NAME.LEAVE_ROBLOX_WARNING, E.paymentFlowAnalyticsService.ENUM_PURCHASE_EVENT_TYPE.USER_INPUT, E.paymentFlowAnalyticsService.ENUM_VIEW_MESSAGE.CANCEL)
            }
        }, {
            actionButtonShow: !0
        }))
    }
    var yr = a.resources;

    function gr(e) {
        var t = e.currentUserBalance,
            r = e.items,
            n = e.itemDetails,
            a = e.onBuyButtonClick,
            i = e.onConfirm,
            o = e.onCancel,
            s = e.onTransactionComplete,
            l = e.productSurface,
            c = e.systemFeedbackService,
            u = e.translate,
            d = !1,
            m = 0,
            p = 0,
            f = [],
            b = nr((0, de.useState)(!1), 2),
            e = b[0],
            y = b[1],
            b = nr((0, de.useState)(!1), 2),
            g = b[0],
            h = b[1];
        (0, de.useEffect)(function() {
            rr().then(function(e) {
                e = e.data.shouldShowVng;
                h(e)
            }).catch(function(e) {
                console.debug(e), h(!1)
            })
        }, []);
        if (!_e.authenticatedUser.isAuthenticated) return me().createElement("div", {
            className: "sign-in"
        }, me().createElement(P.Button, {
            className: "action-button batch-buy-purchase-button sign-in-button",
            variant: P.Button.variants.growth,
            size: P.Button.sizes.large,
            onClick: function() {
                var e;
                window.location = (e = {
                    ReturnUrl: window.location.pathname
                }, pe.urlService.getUrlWithQueries("/login", e))
            }
        }, u(yr.buyAction)));
        if (void 0 === n || 0 < n.length && n[0] && n[0].loading || void 0 === t) return me().createElement("div", {
            className: "loading"
        }, me().createElement(P.Button, {
            className: "action-button batch-buy-purchase-button",
            variant: P.Button.variants.growth,
            size: P.Button.sizes.large,
            isDisabled: !0
        }, me().createElement(P.Loading, null)));
        if (0 === n.length || n[0] && n[0].loadFailure) return me().createElement(P.Button, {
            className: "action-button batch-buy-purchase-button",
            variant: P.Button.variants.growth,
            size: P.Button.sizes.large,
            isDisabled: !0
        }, u(yr.buyAction));
        n.forEach(function(e) {
            var t;
            (void 0 !== (t = e).collectibleItemId ? t.isMarketPlaceEnabled && t.isPurchasable || t.resellerAvailable : t.isMarketPlaceEnabled && (t.resellerAvailable || t.isPurchasable)) && (d = !0), e.premiumPriceInRobux && _e.authenticatedUser.isPremiumUser ? p += e.premiumPriceInRobux : e.lowestPrice ? m += e.lowestPrice : e.price && (m += e.price), e.resellerAvailable && f.push(e)
        });
        var v = m + p - t;
        return me().createElement(me().Fragment, null, me().createElement("div", null, me().createElement(P.Button, {
            className: "action-button batch-buy-purchase-button",
            variant: P.Button.variants.growth,
            size: P.Button.sizes.large,
            onClick: function() {
                (0 < v ? sr : ur).open(), a()
            },
            isDisabled: !d
        }, e ? me().createElement(P.Loading, null) : u(yr.buyAction))), 0 < v && me().createElement("div", {
            id: "insufficient-funds-modal"
        }, me().createElement(or, {
            robuxNeeded: v,
            onAccept: function() {
                g ? fr.open() : window.location = S.getRobuxUpgradesUrl("")
            }
        })), g && me().createElement("div", {
            id: "leave-roblox-warning-modal"
        }, me().createElement(pr, {
            onContinueToPayment: function() {
                window.open(S.getVngShopUrl(), "_blank"), fr.close()
            }
        })), me().createElement("div", {
            id: "multi-item-purchase-modal"
        }, me().createElement(cr, {
            title: u(yr.buyNowAction),
            expectedTotalPrice: m + p,
            items: r,
            itemDetails: n,
            resaleItems: f,
            currentRobuxBalance: t,
            onCancel: function() {
                var e;
                null == ur || null !== (e = ur.close) && void 0 !== e && e.call(ur), o()
            },
            onTransactionComplete: function(e) {
                y(!1), s(e)
            },
            onAction: function() {
                var e;
                null == ur || null !== (e = ur.close) && void 0 !== e && e.call(ur), y(!0), i()
            },
            loading: !1,
            productSurface: l,
            systemFeedbackService: c
        })))
    }
    gr.propTypes = {
        currentUserBalance: o().number.isRequired,
        items: o().arrayOf(o().shape({
            id: o().number.isRequired,
            itemType: o().string.isRequired
        })).isRequired,
        itemDetails: o().arrayOf(o().shape({
            productId: o().number.isRequired,
            price: o().number.isRequired,
            itemName: o().string.isRequired,
            itemType: o().string.isRequired,
            assetTypeDisplayName: o().string.isRequired,
            sellerName: o().string.isRequired,
            expectedSellerId: o().number.isRequired,
            isPurchasable: o().bool.isRequired,
            isOwned: o().bool.isRequired,
            isPlugin: o().bool.isRequired,
            itemDetailItemId: o().number.isRequired,
            loading: o().bool.isRequired,
            loadFailure: o().bool,
            userQualifiesForPremiumPrices: o().bool.isRequired,
            premiumPriceInRobux: o().number,
            isAuthenticated: o().bool.isRequired,
            resellerAvailable: o().bool.isRequired,
            firstReseller: o().shape({
                seller: {
                    name: o().string.isRequired,
                    id: o().number.isRequired
                },
                userAssetId: o().number.isRequired
            }),
            isMarketPlaceEnabled: o().bool.isRequired
        })).isRequired,
        onBuyButtonClick: o().func.isRequired,
        onConfirm: o().func.isRequired,
        onCancel: o().func.isRequired,
        onTransactionComplete: o().func.isRequired,
        productSurface: o().string.isRequired,
        systemFeedbackService: o().func.isRequired,
        translate: o().func.isRequired
    };
    var hr = (0, s.withTranslations)(gr, c.purchasingResources);

    function vr(e, t) {
        return function(e) {
            if (Array.isArray(e)) return e
        }(e) || function(e, t) {
            if ("undefined" == typeof Symbol || !(Symbol.iterator in Object(e))) return;
            var r = [],
                n = !0,
                a = !1,
                i = void 0;
            try {
                for (var o, s = e[Symbol.iterator](); !(n = (o = s.next()).done) && (r.push(o.value), !t || r.length !== t); n = !0);
            } catch (e) {
                a = !0, i = e
            } finally {
                try {
                    n || null == s.return || s.return()
                } finally {
                    if (a) throw i
                }
            }
            return r
        }(e, t) || function(e, t) {
            if (!e) return;
            if ("string" == typeof e) return Sr(e, t);
            var r = Object.prototype.toString.call(e).slice(8, -1);
            "Object" === r && e.constructor && (r = e.constructor.name);
            if ("Map" === r || "Set" === r) return Array.from(e);
            if ("Arguments" === r || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return Sr(e, t)
        }(e, t) || function() {
            throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }

    function Sr(e, t) {
        (null == t || t > e.length) && (t = e.length);
        for (var r = 0, n = new Array(t); r < t; r++) n[r] = e[r];
        return n
    }

    function Pr(e) {
        var t = e.items,
            r = e.onBuyButtonClick,
            n = e.systemFeedbackService,
            a = e.onConfirm,
            i = e.onCancel,
            o = e.onTransactionComplete,
            s = e.productSurface,
            l = e.translate,
            c = vr((0, de.useState)(void 0), 2),
            e = c[0],
            u = c[1];
        (0, de.useEffect)(function() {
            _e.authenticatedUser.isAuthenticated && he(_e.authenticatedUser.id).then(function(e) {
                u(e.data.robux)
            }).catch(function() {
                u(void 0)
            })
        }, []);
        c = jt(t).itemDetails;
        return me().createElement(hr, {
            currentUserBalance: e,
            items: t,
            itemDetails: c,
            systemFeedbackService: n,
            onBuyButtonClick: r,
            onConfirm: a,
            onCancel: i,
            onTransactionComplete: o,
            productSurface: s,
            translate: l
        })
    }
    Pr.propTypes = {
        items: o().arrayOf(o().object).isRequired,
        onBuyButtonClick: o().func,
        onConfirm: o().func,
        onCancel: o().func,
        onTransactionComplete: o().func,
        systemFeedbackService: o().func.isRequired,
        productSurface: o().string,
        translate: o().func.isRequired
    }, Pr.defaultProps = {
        onBuyButtonClick: function() {},
        onConfirm: function() {},
        onCancel: function() {},
        onTransactionComplete: function() {},
        productSurface: "SHOPPING_CART_WEB"
    }, lr = (0, s.withTranslations)(Pr, c.purchasingResources), Nt = a.errorTypeIds, window.RobloxItemPurchase = {
        createTransactionFailureModal: u,
        createInsufficientFundsModal: x,
        createPriceChangedModal: B,
        createPurchaseVerificationModal: V,
        createPurchaseConfirmationModal: ye,
        createItemPurchase: Le,
        errorTypeIds: Nt,
        getMetaData: be,
        BalanceAfterSaleText: M,
        PriceLabel: w,
        AssetName: L,
        TransactionVerb: G,
        BatchBuyPriceContainer: lr
    }, (0, pe.ready)(function() {
        var e = document.getElementById("display-price-container");
        e && (0, t.render)(me().createElement(Et, null), e)
    })
}();
//# sourceMappingURL=https://js.rbxcdn.com/4b337a0e2e9b6f3e138f644d5fe913da-itemPurchase.bundle.min.js.map

/* Bundle detector */
window.Roblox && window.Roblox.BundleDetector && window.Roblox.BundleDetector.bundleDetected("ItemPurchase");