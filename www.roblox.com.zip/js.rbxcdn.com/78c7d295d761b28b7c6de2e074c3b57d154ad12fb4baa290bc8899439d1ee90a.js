! function() {
    "use strict";

    function e(e) {
        var n = e.children,
            t = (0, s.useState)(null),
            e = t[0],
            r = t[1];
        return (0, s.useEffect)(function() {
            u().then(function(e) {
                null != (null == e ? void 0 : e.data) && r(e.data)
            }, function(e) {
                console.error(e)
            })
        }, []), m().createElement(E.Provider, {
            value: e
        }, n)
    }
    var d, n, r = {
            n: function(e) {
                var n = e && e.__esModule ? function() {
                    return e.default
                } : function() {
                    return e
                };
                return r.d(n, {
                    a: n
                }), n
            },
            d: function(e, n) {
                for (var t in n) r.o(n, t) && !r.o(e, t) && Object.defineProperty(e, t, {
                    enumerable: !0,
                    get: n[t]
                })
            },
            o: function(e, n) {
                return Object.prototype.hasOwnProperty.call(e, n)
            }
        },
        t = CoreUtilities,
        s = React,
        m = r.n(s),
        o = ReactDOM,
        f = ReactUtilities,
        p = Roblox,
        i = function(e, a, l, u) {
            return new(l = l || Promise)(function(t, n) {
                function r(e) {
                    try {
                        i(u.next(e))
                    } catch (e) {
                        n(e)
                    }
                }

                function o(e) {
                    try {
                        i(u.throw(e))
                    } catch (e) {
                        n(e)
                    }
                }

                function i(e) {
                    var n;
                    e.done ? t(e.value) : ((n = e.value) instanceof l ? n : new l(function(e) {
                        e(n)
                    })).then(r, o)
                }
                i((u = u.apply(e, a || [])).next())
            })
        },
        a = function(t, r) {
            var o, i, a, l = {
                    label: 0,
                    sent: function() {
                        if (1 & a[0]) throw a[1];
                        return a[1]
                    },
                    trys: [],
                    ops: []
                },
                e = {
                    next: n(0),
                    throw: n(1),
                    return: n(2)
                };
            return "function" == typeof Symbol && (e[Symbol.iterator] = function() {
                return this
            }), e;

            function n(n) {
                return function(e) {
                    return function(n) {
                        if (o) throw new TypeError("Generator is already executing.");
                        for (; l;) try {
                            if (o = 1, i && (a = 2 & n[0] ? i.return : n[0] ? i.throw || ((a = i.return) && a.call(i), 0) : i.next) && !(a = a.call(i, n[1])).done) return a;
                            switch (i = 0, a && (n = [2 & n[0], a.value]), n[0]) {
                                case 0:
                                case 1:
                                    a = n;
                                    break;
                                case 4:
                                    return l.label++, {
                                        value: n[1],
                                        done: !1
                                    };
                                case 5:
                                    l.label++, i = n[1], n = [0];
                                    continue;
                                case 7:
                                    n = l.ops.pop(), l.trys.pop();
                                    continue;
                                default:
                                    if (!(a = 0 < (a = l.trys).length && a[a.length - 1]) && (6 === n[0] || 2 === n[0])) {
                                        l = 0;
                                        continue
                                    }
                                    if (3 === n[0] && (!a || n[1] > a[0] && n[1] < a[3])) {
                                        l.label = n[1];
                                        break
                                    }
                                    if (6 === n[0] && l.label < a[1]) {
                                        l.label = a[1], a = n;
                                        break
                                    }
                                    if (a && l.label < a[2]) {
                                        l.label = a[2], l.ops.push(n);
                                        break
                                    }
                                    a[2] && l.ops.pop(), l.trys.pop();
                                    continue
                            }
                            n = r.call(t, l)
                        } catch (e) {
                            n = [6, e], i = 0
                        } finally {
                            o = a = 0
                        }
                        if (5 & n[0]) throw n[1];
                        return {
                            value: n[0] ? n[1] : void 0,
                            done: !0
                        }
                    }([n, e])
                }
            }
        },
        l = p.EnvironmentUrls.userModerationApi + "/v1/reminder",
        u = function() {
            return i(void 0, void 0, Promise, function() {
                var n;
                return a(this, function(e) {
                    return n = {
                        url: l,
                        withCredentials: !0
                    }, [2, t.httpService.get(n)]
                })
            })
        },
        E = (0, s.createContext)(null),
        c = {
            common: [],
            feature: "Feature.Home"
        },
        v = ReactStyleGuide,
        y = function(e, n) {
            var t = e.contentVariant,
                e = e.policyViolation,
                r = "";
            switch (t) {
                case "positive":
                    r = n("Experiment.Reminders.BodyPositiveVariant");
                    break;
                case "warning":
                    r = n("Experiment.Reminders.BodyWarningVariant")
            }
            return {
                dialogTitle: n("Experiment.Reminders.Title"),
                dialogBodyAbuseType: n("Experiment.Reminders.BodyShared", {
                    policy_violation: n(e)
                }),
                dialogBodyGuidelineReminder: r,
                confirmationButtonLabel: n("Experiment.Reminders.Button")
            }
        };

    function b() {
        var e = (u = (0, s.useState)(!1))[0],
            n = u[1],
            t = (0, s.useContext)(E),
            r = (0, s.useRef)(0),
            o = p.CurrentUser.userId;
        (0, s.useEffect)(function() {
            r.current = Date.now()
        }, []);
        var i = (0, f.useTranslation)().translate;
        if (null == t || null == t || !t.shouldSurfaceReminder || null == t || !t.policyViolation) return null;
        var a = t.interventionId,
            l = !e && (null == t ? void 0 : t.shouldSurfaceReminder),
            u = (c = y(t, i)).dialogTitle,
            e = c.dialogBodyAbuseType,
            i = c.dialogBodyGuidelineReminder,
            c = c.confirmationButtonLabel;
        return m().createElement(v.Modal, {
            className: "reminder-of-norms-dialog-modal",
            show: l,
            onHide: function() {
                var e = Date.now();
                h(a, d.DISMISSED, t.reminderNumber, o, e, (e - r.current) / 1e3, t.experimentVariant), n(!0)
            }
        }, m().createElement(v.Modal.Header, {
            className: "reminder-of-norms-dialog-title",
            title: u,
            showCloseButton: !1
        }), m().createElement(v.Modal.Body, {
            className: "reminder-of-norms-dialog-body"
        }, m().createElement("p", {
            className: "dialog-body-abuse-type"
        }, e), m().createElement("p", {
            className: "dialog-body-guideline-reminder"
        }, i)), m().createElement(v.Modal.Footer, null, m().createElement(v.Button, {
            className: "reminder-of-norms-confirm-button",
            onClick: function() {
                var e = Date.now();
                h(a, d.CTA_CLICKED, t.reminderNumber, o, e, (e - r.current) / 1e3, t.experimentVariant), n(!0)
            }
        }, c)))
    }(n = d = d || {}).CTA_CLICKED = "REMINDER_INTERACTION_CTA_CLICKED", n.DISMISSED = "REMINDER_INTERACTION_REMINDER_DISMISSED";
    var h = function(e, n, t, r, o, i, a) {
        p.EventStream.SendEventWithTarget("HomePageRemindersEvent", "WebApp", {
            user_id: r,
            source_intervention_id: e,
            reminder_number: t,
            timestamp_milliseconds: o,
            time_to_interact_seconds: i,
            interaction: n,
            platform: "PLATFORM_WEB",
            experiment_variant: a
        }, p.EventStream.TargetTypes.WWW)
    };

    function R() {
        return m().createElement(f.TranslationProvider, {
            config: c
        }, m().createElement(e, null, m().createElement(b, null)))
    }

    function g() {
        return m().createElement(R, null)
    }(0, t.ready)(function() {
        (0, o.render)(m().createElement(g, null), document.getElementById("reminder-of-norms-web-app-root"))
    })
}();
//# sourceMappingURL=https://js.rbxcdn.com/d5785dd7fa6d935949323dba0b8c114e-reminderOfNormsApp.bundle.min.js.map

/* Bundle detector */
window.Roblox && window.Roblox.BundleDetector && window.Roblox.BundleDetector.bundleDetected("ReminderOfNormsApp");