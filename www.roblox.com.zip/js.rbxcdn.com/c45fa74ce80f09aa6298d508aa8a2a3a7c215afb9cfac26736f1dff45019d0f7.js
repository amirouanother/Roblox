! function() {
    var t = {
            4940: function(e, a, t) {
                var i = {
                    "./apiParamsInitialization.js": 49,
                    "./channelsNotificationType.js": 4010,
                    "./diagActionList.js": 9846,
                    "./eventNames.js": 178,
                    "./gameParameters.js": 7682,
                    "./httpResponse.js": 1202,
                    "./messageHelper.js": 831,
                    "./notificationType.js": 2958,
                    "./notificationsName.js": 4224,
                    "./resources.js": 4636
                };

                function r(e) {
                    e = n(e);
                    return t(e)
                }

                function n(e) {
                    if (t.o(i, e)) return i[e];
                    e = new Error("Cannot find module '" + e + "'");
                    throw e.code = "MODULE_NOT_FOUND", e
                }
                r.keys = function() {
                    return Object.keys(i)
                }, r.resolve = n, (e.exports = r).id = 4940
            },
            9084: function(e, a, t) {
                var i = {
                    "./chatBarController.js": 5394,
                    "./chatController.js": 8240,
                    "./detailsController.js": 4978,
                    "./dialogController.js": 9443,
                    "./dialogHeaderController.js": 6822,
                    "./dialogMessagesController.js": 9226,
                    "./dialogsController.js": 8984,
                    "./friendsController.js": 7146,
                    "./linkCardController.js": 3771,
                    "./linkCardMessagesController.js": 7910,
                    "./playTogetherController.js": 2696,
                    "./userConversationInfoController.js": 2041
                };

                function r(e) {
                    e = n(e);
                    return t(e)
                }

                function n(e) {
                    if (t.o(i, e)) return i[e];
                    e = new Error("Cannot find module '" + e + "'");
                    throw e.code = "MODULE_NOT_FOUND", e
                }
                r.keys = function() {
                    return Object.keys(i)
                }, r.resolve = n, (e.exports = r).id = 9084
            },
            9083: function(e, a, t) {
                var i = {
                    "./abuseReportDirective.js": 5774,
                    "./addFriendsDirective.js": 6620,
                    "./backBtnDirective.js": 96,
                    "./chatAvatarHeadshotDirective.js": 1083,
                    "./chatBarDirective.js": 5764,
                    "./chatBaseDirective.js": 889,
                    "./chatGameIconDirective.js": 8272,
                    "./chatPlaceholderDirective.js": 5121,
                    "./confirmNegativeActionDirective.js": 8042,
                    "./confirmRemoveMemberDirective.js": 57,
                    "./conversationTitleDirective.js": 9264,
                    "./conversationTitleEditorDirective.js": 8759,
                    "./detailsDirective.js": 6842,
                    "./detailsScrollbarDirective.js": 1763,
                    "./dialogDirective.js": 3669,
                    "./dialogHeaderDirective.js": 8945,
                    "./dialogLazyLoadDirective.js": 3111,
                    "./dialogMinimizeDirective.js": 6059,
                    "./displayMessageDirective.js": 4861,
                    "./groupSelectDirective.js": 4433,
                    "./lazyLoadDirective.js": 8406,
                    "./linkCardDirective.js": 8079,
                    "./minimizeItemDirective.js": 7806,
                    "./pendingStateDirective.js": 9688,
                    "./removeFocusDirective.js": 9032,
                    "./repeatDoneDirective.js": 2638,
                    "./selectFriendsDirective.js": 9630,
                    "./selectFriendsResizeDirective.js": 5809,
                    "./systemMessageDirective.js": 4449,
                    "./togglePopoverDirective.js": 9080,
                    "./userConversationInfoDirective.js": 8341
                };

                function r(e) {
                    e = n(e);
                    return t(e)
                }

                function n(e) {
                    if (t.o(i, e)) return i[e];
                    e = new Error("Cannot find module '" + e + "'");
                    throw e.code = "MODULE_NOT_FOUND", e
                }
                r.keys = function() {
                    return Object.keys(i)
                }, r.resolve = n, (e.exports = r).id = 9083
            },
            2883: function(e, a, t) {
                var i = {
                    "./analyticsService.js": 1495,
                    "./chatClientStorageUtilityService.js": 5869,
                    "./chatService.js": 6061,
                    "./chatUtilityService.js": 2109,
                    "./conversationUtilityService.js": 7044,
                    "./cookieService.js": 1171,
                    "./dialogAttributesService.js": 7333,
                    "./gameLayoutService.js": 5585,
                    "./gameService.js": 5710,
                    "./gameUtility.js": 3333,
                    "./libraryInitializationService.js": 6331,
                    "./messageService.js": 2370,
                    "./messageUtility.js": 1553,
                    "./pinGameLayoutService.js": 8549,
                    "./pinGameService.js": 2986,
                    "./playTogetherLayoutService.js": 7241,
                    "./playTogetherService.js": 9123,
                    "./presenceLayoutService.js": 4216,
                    "./storageService.js": 6162,
                    "./systemMessagesService.js": 7563,
                    "./userSettingsService.js": 1106,
                    "./usersService.js": 3693
                };

                function r(e) {
                    e = n(e);
                    return t(e)
                }

                function n(e) {
                    if (t.o(i, e)) return i[e];
                    e = new Error("Cannot find module '" + e + "'");
                    throw e.code = "MODULE_NOT_FOUND", e
                }
                r.keys = function() {
                    return Object.keys(i)
                }, r.resolve = n, (e.exports = r).id = 2883
            },
            4850: function(e, a, t) {
                var i = {
                    "./directives/templates/addFriends.html": 6115,
                    "./directives/templates/chatAbuseReport.html": 3474,
                    "./directives/templates/chatAvatarHeadshot.html": 4947,
                    "./directives/templates/chatBar.html": 3540,
                    "./directives/templates/chatBase.html": 4497,
                    "./directives/templates/chatDialog.html": 3355,
                    "./directives/templates/chatGameIcon.html": 7709,
                    "./directives/templates/chatGroupDialog.html": 9816,
                    "./directives/templates/chatPlaceholder.html": 4120,
                    "./directives/templates/confirmNegativeAction.html": 8895,
                    "./directives/templates/conversationTitle.html": 2791,
                    "./directives/templates/conversationTitleEditor.html": 6465,
                    "./directives/templates/createChatGroup.html": 4748,
                    "./directives/templates/details.html": 9837,
                    "./directives/templates/dialogHeader.html": 7905,
                    "./directives/templates/dialogMinimize.html": 3528,
                    "./directives/templates/displayMessage.html": 2449,
                    "./directives/templates/gamesList.html": 954,
                    "./directives/templates/linkCard.html": 1651,
                    "./directives/templates/pendingState.html": 162,
                    "./directives/templates/selectFriends.html": 4310,
                    "./directives/templates/systemMessage.html": 3812,
                    "./directives/templates/userConversationInfo.html": 293
                };

                function r(e) {
                    e = n(e);
                    return t(e)
                }

                function n(e) {
                    if (t.o(i, e)) return i[e];
                    e = new Error("Cannot find module '" + e + "'");
                    throw e.code = "MODULE_NOT_FOUND", e
                }
                r.keys = function() {
                    return Object.keys(i)
                }, r.resolve = n, (e.exports = r).id = 4850
            },
            3544: function(e) {
                function n(e) {
                    return e.replace(/([a-z])([A-Z])/g, "$1-$2").toLowerCase()
                }

                function s(e) {
                    return e.split("/").pop().replace(".html", "")
                }
                var a = {
                    importFilesUnderPath: function(e) {
                        e.keys().forEach(e)
                    },
                    templateCacheGenerator: function(e, a, i, r) {
                        return e.module(a, []).run(["$templateCache", function(t) {
                            i && i.keys().forEach(function(e) {
                                var a = n(s(e));
                                t.put(a, i(e))
                            }), r && r.keys().forEach(function(e) {
                                var a = n(s(e));
                                t.put(a, r(e).replace(/<\/?script[^>]*>/gi, ""))
                            })
                        }])
                    }
                };
                e.exports = a
            },
            9472: function(e, a, t) {
                "use strict";
                var i = t(792),
                    r = t(5734),
                    n = t.n(r),
                    s = ["robloxApp", "monospaced.elastic", "modal", "ui.bootstrap.popover", "toast", "thumbnails", "userProfiles", "ngSanitize"],
                    o = "contacts";
                try {
                    n().module(o), s.push(o)
                } catch (e) {}
                r = n().module("chat", s).config(["msdElasticConfig", "languageResourceProvider", function(e, a) {
                    e.append = "\n";
                    e = (new i.TranslationResourceProvider).getTranslationResource("Feature.Chat");
                    a.setTranslationResources([e])
                }]);
                a.Z = r
            },
            49: function(e, a, t) {
                "use strict";
                t.r(a);
                var i = t(792),
                    t = t(9472),
                    i = {
                        chatApiParams: {
                            pageNumberOfUnreadConversations: 1,
                            pageSizeOfUnreadConversations: 30,
                            getUserConversationsNextCursor: null,
                            pageSizeOfConversations: 20,
                            pageSizeOfDisplayMessages: 1,
                            pageSizeOfUnreadMessages: 30,
                            pageSizeOfGetMessages: 30,
                            startIndexOfFriendList: 0,
                            pageSizeOfFriendList: 50,
                            loadMoreUnreadConversations: !1,
                            loadMoreConversations: !1
                        },
                        dialogParams: {
                            loadMoreMessages: !0,
                            sendingMessage: !1,
                            sendMessageHasError: !1,
                            startIndexOfFriendList: 0,
                            pageSizeOfFriendList: 50,
                            pageSizeOfGetMessages: 30,
                            smallestPageSizeOfGetMessages: 3,
                            getMessagesNextCursor: null
                        },
                        gameUrls: {
                            multiGetPlaceDetails: "/v1/games/multiget-place-details",
                            getGamesByUniverseIds: i.EnvironmentUrls ? "".concat(i.EnvironmentUrls.gamesApi, "/v1/games") : "/v1/games",
                            multiGetPlayabilityStatus: i.EnvironmentUrls ? "".concat(i.EnvironmentUrls.gamesApi, "/v1/games/multiget-playability-status") : "/v1/games/multiget-playability-status"
                        },
                        chatUrls: {
                            setConversationUniverse: "/v2/set-conversation-universe",
                            resetConversationUniverse: "/v2/reset-conversation-universe"
                        },
                        apiSets: {
                            multiGetAvatarHeadshots: {
                                url: i.EnvironmentUrls ? "".concat(i.EnvironmentUrls.thumbnailsApi, "/v1/users/avatar-headshot?size=48x48&format=png") : "/v1/users/avatar-headshot?size=48x48&format=png",
                                retryable: !0,
                                withCredentials: !0
                            },
                            multiGetContacts: {
                                url: i.EnvironmentUrls ? "".concat(i.EnvironmentUrls.contactsApi, "/v1/user/get-tags") : "/v1/user/get-tags",
                                retryable: !0,
                                withCredentials: !0
                            },
                            multiGetPresence: {
                                url: i.EnvironmentUrls ? "".concat(i.EnvironmentUrls.presenceApi, "/v1/presence/users") : "/v1/presence/users",
                                retryable: !0,
                                withCredentials: !0
                            },
                            getMetaData: {
                                url: i.EnvironmentUrls ? "".concat(Roblox.EnvironmentUrls.apiGatewayUrl, "/platform-chat-api/v1/metadata") : "/v1/metadata",
                                retryable: !1,
                                withCredentials: !0
                            },
                            getUserSettings: {
                                url: "".concat(i.EnvironmentUrls.userSettingsApi, "/v1/user-settings/settings-and-options"),
                                retryable: !0,
                                withCredentials: !0
                            },
                            getContactsMetadata: {
                                url: i.EnvironmentUrls ? "".concat(i.EnvironmentUrls.contactsApi, "/v1/contacts/metadata") : "/v1/contacts/metadata",
                                retryable: !0,
                                withCredentials: !0
                            }
                        }
                    };
                t.Z.constant("apiParamsInitialization", i), a.default = i
            },
            4010: function(e, a, t) {
                "use strict";
                t.r(a);
                var i = {
                    addedToChannel: "AddedToChannel",
                    channelArchived: "ChannelArchived",
                    channelCreated: "ChannelCreated",
                    channelDeleted: "ChannelDeleted",
                    channelMarkedRead: "ChannelMarkedRead",
                    channelUnarchived: "ChannelUnarchived",
                    channelUpdated: "ChannelUpdated",
                    messageCreated: "MessageCreated",
                    participantTyping: "ParticipantTyping",
                    participantsAdded: "ParticipantsAdded",
                    participantsRemoved: "ParticipantsRemoved",
                    removedFromChannel: "RemovedFromChannel",
                    systemMessageCreated: "SystemMessageCreated"
                };
                t(9472).Z.constant("channelsNotificationType", i), a.default = i
            },
            9846: function(e, a, t) {
                "use strict";
                t.r(a);
                var i = {
                    ChatLandingConversationClickedWeb: "ChatLandingConversationClickedWeb",
                    ConversationMessageSentWeb: "ConversationMessageSentWeb",
                    WebChatConversationsLoadedWeb: "WebChatConversationsLoadedWeb",
                    WebChatConversationRenderedWeb: "WebChatConversationRenderedWeb",
                    WebChatRenderedWeb: "WebChatRenderedWeb"
                };
                t(9472).Z.constant("diagActionList", i), a.default = i
            },
            178: function(e, a, t) {
                "use strict";
                t.r(a);
                var i = {
                    chatLandingConversationClicked: "chatLandingConversationClicked",
                    conversationMessageSent: "conversationMessageSent",
                    webChatConversationsLoaded: "webChatConversationsLoaded",
                    webChatConversationRendered: "webChatConversationRendered",
                    webChatRendered: "webChatRendered"
                };
                t(9472).Z.constant("eventNames", i), a.default = i
            },
            7682: function(e, a, t) {
                "use strict";
                t.r(a);
                var i = {
                    reasonProhibitedMessage: {
                        None: "None",
                        Playable: "Playable",
                        AnonymousAccessProhibited: "AnonymousAccessProhibited",
                        AssetUnapproved: "AssetUnapproved",
                        IncorrectAssetType: "IncorrectAssetType",
                        IncorrectAssetConfiguration: "IncorrectAssetConfiguration",
                        PlaceHasNoUniverse: "PlaceHasNoUniverse",
                        UniverseDoesNotHaveARootPlace: "This game has no root place.",
                        UniverseRootPlaceIsNotAPlace: "UniverseRootPlaceIsNotAPlace",
                        UniverseRootPlaceIsNotActive: "UniverseRootPlaceIsNotActive",
                        InsufficientPermissionCopylocked: "InsufficientPermissionCopylocked",
                        InsufficientPermissionFriendsOnly: "This game is friends only.",
                        InsufficientPermissionGroupOnly: "Group members only.",
                        InsufficientPermissionOwnerOnly: "InsufficientPermissionOwnerOnly",
                        InsufficientPermissionMembershipLevel: "InsufficientPermissionMembershipLevel",
                        InsufficientPermissionRoleSet: "InsufficientPermissionRoleSet",
                        PermissionDenied: "PermissionDenied",
                        RequiredValueNotSet: "RequiredValueNotSet",
                        AssetUnavailable: "AssetUnavailable",
                        DeviceRestricted: "DeviceRestricted",
                        UnderReview: "This game is under moderation review.",
                        PurchaseRequired: "PurchaseRequired",
                        AccountRestricted: "AccountRestricted",
                        PlaceHasNoPublishedVersion: "This place has no published version."
                    },
                    sortNames: {
                        myRecent: "MyRecent"
                    },
                    maxRowsOfMyRecentGames: 1,
                    gameIconMultiGetLimit: 30,
                    gameUrl: "/games/{placeId}/robloxgame"
                };
                t(9472).Z.constant("gameParameters", i), a.default = i
            },
            1202: function(e, a, t) {
                "use strict";
                t.r(a);
                var i = {
                    sendMessageErrorCode: {
                        textTooLong: "TextTooLong"
                    }
                };
                t(9472).Z.constant("httpResponse", i), a.default = i
            },
            831: function(e, a, t) {
                "use strict";
                t.r(a);
                var i = t(9472),
                    t = {
                        linkCardTypes: {
                            gameCard: "gameCard",
                            catalogItemCard: "catalogItemCard",
                            libraryItemCard: "libraryItemCard"
                        },
                        messageRegexs: {
                            gameCard: new RegExp(/\/games\/(\d+)/)
                        },
                        gameCardRegexs: {
                            privateServerLinkCode: new RegExp(/privateServerLinkCode=(\S+)/)
                        },
                        urlRegex: new RegExp(/(https?:\/\/(?:www\.|(?!www)|(?:web\.))[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|www\.[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|web\.[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|https?:\/\/(?:www\.|(?!www)|(?:web\.))[a-zA-Z0-9]\.[^\s]{2,}|www\.[a-zA-Z0-9]\.[^\s]{2,})/),
                        onlyNewLineRegex: new RegExp(/^[\r|\n|\s]+$/),
                        removeNewLineRegex: new RegExp(/^\n+|\n+$/g),
                        emojiRegex: new RegExp(/\u200D|\uFE0F|(?:[\xA9\xAE\u2122\u23E9-\u23EF\u23F3\u23F8-\u23FA\u24C2\u25B6\u2600-\u27BF\u2934\u2935\u2B05-\u2B07\u2B1B\u2B1C\u2B50\u2B55\u3030\u303D\u3297\u3299]|\uD83C[\uDC04\uDCCF\uDD70\uDD71\uDD7E\uDD7F\uDD8E\uDD91-\uDE51\uDF00-\uDFFF]|\uD83D[\uDC00-\uDE4F\uDE80-\uDEFF]|\uD83E[\uDD00-\uDDFF])/g),
                        zwjRegex: new RegExp(/\u200D/),
                        emojiRepRegex: new RegExp(/\uFE0F/),
                        messageTypes: {
                            user: "user",
                            system: "system"
                        }
                    };
                i.Z.constant("messageHelper", t), a.default = t
            },
            2958: function(e, a, t) {
                "use strict";
                t.r(a);
                var i = {
                    newMessage: "NewMessage",
                    newMessageBySelf: "NewMessageBySelf",
                    newConversation: "NewConversation",
                    addedToConversation: "AddedToConversation",
                    removedFromConversation: "RemovedFromConversation",
                    participantAdded: "ParticipantAdded",
                    participantLeft: "ParticipantLeft",
                    friendshipDestroyed: "FriendshipDestroyed",
                    friendshipCreated: "FriendshipCreated",
                    presenceOffline: "UserOffline",
                    presenceOnline: "UserOnline",
                    conversationTitleModerated: "ConversationTitleModerated",
                    chatEnabled: "ChatEnabled",
                    chatDisabled: "ChatDisabled",
                    conversationTitleChanged: "ConversationTitleChanged",
                    participantTyping: "ParticipantTyping",
                    conversationUniverseChanged: "ConversationUniverseChanged",
                    userTagUpdate: "UserTagUpdate",
                    conversationBackfilled: "ConversationBackfilled",
                    conversationReset: "ConversationReset"
                };
                t(9472).Z.constant("notificationType", i), a.default = i
            },
            4224: function(e, a, t) {
                "use strict";
                t.r(a);
                var i = {
                    CommunicationChannelsNotifications: "CommunicationChannels",
                    ChatMigrationNotifications: "ChatMigration",
                    ChatModerationTypeEligibilityNotifications: "ChatModerationTypeEligibility",
                    ChatNotifications: "ChatNotifications",
                    FriendshipNotifications: "FriendshipNotifications",
                    PresenceNotifications: "PresenceNotifications",
                    ChatPrivacySettingNotifications: "ChatPrivacySettingNotifications",
                    UserTagNotifications: "UserTagChangeNotification",
                    VoiceNotifications: "VoiceNotifications"
                };
                t(9472).Z.constant("notificationsName", i), a.default = i
            },
            4636: function(e, a, t) {
                "use strict";
                t.r(a);
                var i = t(792),
                    t = t(9472),
                    i = {
                        templates: {
                            chatBaseTemplate: "chat-base",
                            chatBarTemplate: "chat-bar",
                            abuseReportTemplate: "chat-abuse-report",
                            dialogTemplate: "chat-dialog",
                            groupDialogTemplate: "chat-group-dialog",
                            dialogMinimizeTemplate: "dialog-minimize",
                            chatPlaceholderTemplate: "chat-placeholder",
                            confirmNegativeActionTemplate: "confirm-negative-action",
                            userConversationInfoTemplate: "user-conversation-info",
                            selectFriendsTemplate: "select-friends",
                            createChatGroupTemplate: "create-chat-group",
                            conversationTitleTemplate: "conversation-title",
                            conversationTitleEditorTemplate: "conversation-title-editor",
                            detailsTemplate: "details",
                            addFriendsTemplate: "add-friends",
                            aliasTemplate: "alias",
                            toastTemplate: "toast",
                            linkCard: "link-card",
                            gamesList: "games-list",
                            dialogHeader: "dialog-header",
                            systemMessage: "system-message",
                            displayMessage: "display-message",
                            chatAvatarHeadshot: "chat-avatar-headshot",
                            chatGameIcon: "chat-game-icon",
                            pendingStateTemplate: "pending-state"
                        },
                        eventStreamParams: {
                            actions: {
                                click: "click",
                                hover: "hover",
                                render: "render"
                            },
                            properties: {},
                            clickPlayFromLinkCardInChat: "clickBtnFromLinkCardInChat",
                            clickLinkCardInChat: "clickLinkCardInChat",
                            clickPlayButtonInPlayTogether: "clickPlayButtonInPlayTogether",
                            clickJoinButtonInPlayTogether: "clickJoinButtonInPlayTogether",
                            clickBuyButtonInPlayTogether: "clickBuyButtonInPlayTogether",
                            clickViewDetailsButtonInPlayTogether: "clickViewDetailsButtonInPlayTogether",
                            openGameListInPlayTogether: "openGameListInPlayTogether",
                            pinGameInPlayTogether: "pinGameInPlayTogether",
                            unpinGameInPlayTogether: "unpinGameInPlayTogether",
                            pinGameInLinkCard: "pinGameInLinkCard",
                            unpinGameInLinkCard: "unpinGameInLinkCard",
                            loadGameLinkCardInChat: "loadGameLinkCardInChat",
                            gameImpressions: "gameImpressions",
                            context: {
                                gamePlayFromLinkCard: "PlayGameFromLinkCard",
                                gamePlayFromPlayTogether: "PlayGameFromPlayTogether"
                            },
                            pageContext: {
                                linkCardInChat: "linkCardInChat"
                            }
                        },
                        urlParamNames: {
                            startConversationWithUserId: "startConversationWithUserId",
                            conversationId: "conversationId"
                        },
                        events: {
                            openGameList: "openGameList"
                        },
                        hoverPopoverParams: {
                            isOpen: !1,
                            triggerSelector: "",
                            hoverPopoverSelector: ""
                        },
                        performanceMeasurements: {
                            messageSend: "MessageSend",
                            messageReceive: "MessageReceive"
                        },
                        chatDataLSNamePrefix: i.CurrentUser ? "Roblox.Chat.".concat(i.CurrentUser.userId) : "Roblox.Chat"
                    };
                t.Z.constant("resources", i), a.default = i
            },
            5394: function(e, a, t) {
                "use strict";
                t.r(a);
                t = t(9472);

                function i(s, e, a, t) {
                    s.cancelSearch = function() {
                        s.chatViewModel.searchTerm = "", s.chatLibrary.chatLayout.searchFocus = !1
                    }, s.saveChatBarLayoutInCookie = function() {
                        var e = {
                            collapsed: s.chatLibrary.chatLayout.collapsed
                        };
                        a.updateStorage(a.storageDictionary.chatBarLayout, e, s.chatLibrary.cookieOption)
                    }, s.toggleChatContainer = function() {
                        s.chatLibrary.chatLayout.collapsed = !s.chatLibrary.chatLayout.collapsed, s.updateUnreadConversationCount(), s.chatLibrary.chatLayout.chatBarInitialized = !0, s.saveChatBarLayoutInCookie()
                    }, s.isChatDisconnected = function() {
                        var e = s.chatLibrary.chatLayout,
                            a = e.errorMaskEnable,
                            e = e.pageDataLoading;
                        return s.getIsChatEnabled() && (a || e)
                    }, s.isChatEmpty = function() {
                        return s.chatLibrary.chatLayout.chatLandingEnabled || !s.getIsChatEnabled()
                    }, s.getIsChatEnabled = function() {
                        return t.getIsChatEnabled(s.chatLibrary)
                    }, s.search = function(e) {
                        var a = s.chatViewModel.searchTerm;
                        if (!a) return !0;
                        var t = e.name,
                            i = e.contact,
                            r = e.participants,
                            e = e.title,
                            n = a.toLowerCase(),
                            a = !1;
                        return r && r.length && (a = r.some(function(e) {
                            var a = e.display_name,
                                e = e.name;
                            return a && -1 < a.toLowerCase().indexOf(n) || -1 < e.toLowerCase().indexOf(n)
                        })), a || -1 !== t.toLowerCase().indexOf(n) || -1 !== e.toLowerCase().indexOf(n) || i && -1 !== i.toLowerCase().indexOf(n)
                    }
                }
                i.$inject = ["$scope", "$log", "chatClientStorageUtilityService", "chatUtility"], t.Z.controller("chatBarController", i), a.default = i
            },
            8240: function(e, a, t) {
                "use strict";
                t.r(a);
                var _ = t(792),
                    W = t(2222),
                    i = t(5734),
                    Z = t.n(i),
                    t = t(9472);

                function V(e, a) {
                    var t;
                    if ("undefined" == typeof Symbol || null == e[Symbol.iterator]) {
                        if (Array.isArray(e) || (t = function(e, a) {
                                if (!e) return;
                                if ("string" == typeof e) return o(e, a);
                                var t = Object.prototype.toString.call(e).slice(8, -1);
                                "Object" === t && e.constructor && (t = e.constructor.name);
                                if ("Map" === t || "Set" === t) return Array.from(e);
                                if ("Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t)) return o(e, a)
                            }(e)) || a && e && "number" == typeof e.length) {
                            t && (e = t);
                            var i = 0,
                                a = function() {};
                            return {
                                s: a,
                                n: function() {
                                    return i >= e.length ? {
                                        done: !0
                                    } : {
                                        done: !1,
                                        value: e[i++]
                                    }
                                },
                                e: function(e) {
                                    throw e
                                },
                                f: a
                            }
                        }
                        throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                    }
                    var r, n = !0,
                        s = !1;
                    return {
                        s: function() {
                            t = e[Symbol.iterator]()
                        },
                        n: function() {
                            var e = t.next();
                            return n = e.done, e
                        },
                        e: function(e) {
                            s = !0, r = e
                        },
                        f: function() {
                            try {
                                n || null == t.return || t.return()
                            } finally {
                                if (s) throw r
                            }
                        }
                    }
                }

                function o(e, a) {
                    (null == a || a > e.length) && (a = e.length);
                    for (var t = 0, i = new Array(a); t < a; t++) i[t] = e[t];
                    return i
                }

                function q(e, a, t, i, r, n, s) {
                    try {
                        var o = e[n](s),
                            l = o.value
                    } catch (e) {
                        return void t(e)
                    }
                    o.done ? a(l) : Promise.resolve(l).then(i, r)
                }

                function n(a, e) {
                    var t, i = Object.keys(a);
                    return Object.getOwnPropertySymbols && (t = Object.getOwnPropertySymbols(a), e && (t = t.filter(function(e) {
                        return Object.getOwnPropertyDescriptor(a, e).enumerable
                    })), i.push.apply(i, t)), i
                }

                function J(i) {
                    for (var e = 1; e < arguments.length; e++) {
                        var r = null != arguments[e] ? arguments[e] : {};
                        e % 2 ? n(Object(r), !0).forEach(function(e) {
                            var a, t;
                            a = i, e = r[t = e], t in a ? Object.defineProperty(a, t, {
                                value: e,
                                enumerable: !0,
                                configurable: !0,
                                writable: !0
                            }) : a[t] = e
                        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(i, Object.getOwnPropertyDescriptors(r)) : n(Object(r)).forEach(function(e) {
                            Object.defineProperty(i, e, Object.getOwnPropertyDescriptor(r, e))
                        })
                    }
                    return i
                }

                function r(d, i, r, t, s, u, o, c, g, n, e, l, p, h, a, y, m, v, f, b, L, C, I, D, T, S, P, M, U, E, O, k, w) {
                    function A() {
                        var e = r.innerWidth() - g.chatLayout.widthOfChat - g.chatLayout.widthOfDialogMinimize,
                            a = g.chatLayout.widthOfDialog + g.chatLayout.spaceOfDialog;
                        d.chatLibrary.chatLayout.availableNumberOfDialogs = Math.floor(e / a), d.chatLibrary.chatLayout.numberOfDialogs = d.chatLibrary.dialogIdList.length, d.chatLibrary.chatLayout.numberOfMinimizedDialogs = d.chatLibrary.minimizedDialogIdList.length, u.debug(" -------------numberOfDialogs = -------------- ".concat(d.chatLibrary.chatLayout.numberOfDialogs)), u.debug(" -------------availableNumberOfDialogs = -------------- ".concat(d.chatLibrary.chatLayout.availableNumberOfDialogs))
                    }

                    function x(e) {
                        var a;
                        d.chatLibrary.dialogDict[e.layoutId] && (a = e.layoutId, d.chatLibrary.dialogDict[a] && (d.chatLibrary.dialogDict[a].isUpdated = !0, d.chatLibrary.dialogDict[a].updateStatus = g.dialogStatus.REFRESH)), !d.chatLibrary.dialogDict[e.layoutId] && e.displayMessage && e.displayMessage.content && d.launchDialog(e.layoutId, !0)
                    }
                    d.dialogsOverflowWindow = function() {
                        var e = r.innerWidth();
                        return d.chatLibrary.chatLayout.numberOfDialogs >= d.chatLibrary.chatLayout.availableNumberOfDialogs && e > g.chatLayout.thresholdMobile
                    }, d.processLatestMessageForConversations = function(e) {
                        Z().forEach(e, function(e) {
                            var a, t = e.messages,
                                i = 0 < t.length ? t[0] : {};
                            d.chatLibrary.conversationsDict[e.conversationId] && (a = d.chatLibrary.conversationsDict[e.conversationId].layoutId, (e = d.chatUserDict[a]).hasUnreadMessages = e.hasUnreadMessages || p.hasUnreadMessages(e, t), g.sanitizeMessage(i), e.displayMessage = c.buildDisplayMessage(i), c.resetConversationUnreadStatus(d.chatUserDict[a], t), c.formatTimestampInConversation(d.chatUserDict[a]))
                        })
                    }, d.updateUnreadConversationCount = function() {
                        o.getUnreadConversationCount().then(function(e) {
                            e && (0 < e.count ? (d.chatViewModel.unreadConversationCount = " ✦ ", i.document.title = "( ✦ ) ".concat(d.chatLibrary.currentTabTitle)) : (d.chatViewModel.unreadConversationCount = 0, i.document.title = d.chatLibrary.currentTabTitle))
                        }, function() {
                            u.debug("----- getUnreadConversationCount request is failed ! ------"), i.document.title = d.chatLibrary.currentTabTitle
                        })
                    }, d.replaceConversation = function(e, a) {
                        var t = a.dialogType,
                            i = d.getLayoutId(a.id, t),
                            r = d.chatUserDict[e];
                        r && (n = r.id, d.chatLibrary.conversationsDict[n].remove = !0);
                        var n = d.chatLibrary.dialogDict[e];
                        d.closeDialog(e), n && d.updateDialogList(i, !0), t !== g.dialogType.CHAT && t !== g.dialogType.FRIEND || a.participants.forEach(function(e) {
                            e = e.id;
                            e !== d.chatLibrary.userId && (d.chatLibrary.userConversationsDict[e] = a.layoutId)
                        })
                    };

                    function F(e, t) {
                        return o.getConversations(e).then(function(e) {
                            if (e) {
                                var a = d.buildChatUserListByUnreadConversations(e, t);
                                return d.getPlaceDetailsForNewPlaceIds(e), a
                            }
                        })
                    }

                    function N(e) {
                        var a = [];
                        return a.push(e), F(a, !0)
                    }

                    function G(e, a, t) {
                        c.appendMessages(d.chatLibrary, a, e), v.fetchDataForLinkCard(e, d.chatLibrary), p.hasUnreadMessages(a, e), e = {
                            status: !1,
                            userId: e[0].sender_user_id
                        }, d.updateConverationTypingStatus(a.id, e), d.updateChatViewModel(a, !0), a.hasUnreadMessages && x(a), t || (t = a.layoutId, a = g.activeType.NEWMESSAGE, d.chatLibrary.dialogDict[t] && (d.chatLibrary.dialogDict[t].markAsActive = !0, d.chatLibrary.dialogDict[t].activeType = a))
                    }

                    function R(e, a) {
                        var t, i, r, n = d.getLayoutId(e, g.dialogType.CHAT);
                        Z().isUndefined(d.chatUserDict[n]) ? N(e) : (e = n, n = null, t = a, i = [], r = d.chatUserDict[e], e = null, t || (e = (new Date).getTime()), o.getMessagesByPageSize(r, n, g.dialogParams.smallestPageSizeOfGetMessages, i, function(e) {
                            G(i, r, t), e && (e = (new Date).getTime() - e, o.sendPerformanceData(C.performanceMeasurements.messageReceive, e))
                        }, e))
                    }
                    d.resetDialogLayout = function(t) {
                        var e, a;
                        t && (e = J({}, g.dialogLayout), a = J({}, g.dialogLayoutResetConstant), Z().forEach(e, function(e, a) {
                            Z().isUndefined(t[a]) && (t[a] = J({}, e))
                        }), Z().forEach(a, function(e, a) {
                            t[a] = J({}, e)
                        }))
                    }, d.retrieveDialogStatus = function() {
                        if (Z().isDefined(d.preSetChatLibrary) && Z().isDefined(d.preSetChatLibrary.dialogIdList)) {
                            var e = J({}, d.preSetChatLibrary.dialogIdList);
                            if (0 === e.length) return d.preSetChatLibrary.dialogDict = {}, d.preSetChatLibrary.dialogsLayout = {}, n.removeFromStorage(n.storageDictionary.dialogDict, d.chatLibrary.cookieOption), n.removeFromStorage(n.storageDictionary.dialogsLayout, d.chatLibrary.cookieOption), !1;
                            var t = d.preSetChatLibrary.dialogDict,
                                i = d.preSetChatLibrary.dialogsLayout;
                            Z().forEach(e, function(e, a) {
                                e === g.newGroup.layoutId || d.chatUserDict[e] || (d.preSetChatLibrary.dialogIdList.splice(a, 1), delete t[e], delete i[e]), d.resetDialogLayout(i[e])
                            }), d.chatLibrary.dialogIdList = d.preSetChatLibrary.dialogIdList, Z().forEach(t, function(e, a) {
                                e.isUpdated || (e.isUpdated = !0), a === g.newGroup.layoutId && (d.chatUserDict[g.newGroup.layoutId] = d.newGroup), d.chatLibrary.dialogDict[a] = e, i[a] && (d.chatLibrary.dialogsLayout[a] = i[a])
                            })
                        }
                    };

                    function j() {
                        return i.innerWidth >= g.chatLayout.thresholdChatBarOpen && !d.chatLibrary.isTakeOverOn && !Z().element("#GamesPageLeftColumn").length
                    }
                    var B;
                    d.setup = function() {
                        d.chatUserDict = {}, d.dialogType = J({}, g.dialogType), d.userPresenceTypes = J({}, g.userPresenceTypes), d.newGroup = J({}, y.newGroup), d.selectedFriendIds = [], d.chatLibrary = J({}, m.chatLibrary), Z().isDefined(_.RealTime) && (B = _.RealTime.Factory.GetClient())
                    }, d.initializePresetData = function() {
                        d.preSetChatLibrary = {}, n.isStorageDefined(n.storageDictionary.dialogIdList) && n.isStorageDefined(n.storageDictionary.dialogDict) ? d.preSetChatLibrary = {
                            dialogIdList: n.getFromStorage(n.storageDictionary.dialogIdList),
                            dialogDict: n.getFromStorage(n.storageDictionary.dialogDict),
                            dialogsLayout: n.isStorageDefined(n.storageDictionary.dialogsLayout) ? n.getFromStorage(n.storageDictionary.dialogsLayout) : {}
                        } : d.preSetChatLibrary = {
                            dialogIdList: [],
                            dialogDict: {},
                            dialogsLayout: {}
                        }, n.isStorageDefined(n.storageDictionary.chatBarLayout) && (d.preSetChatLibrary.chatBarLayout = n.getFromStorage(n.storageDictionary.chatBarLayout)), d.chatApiParams = J({}, g.chatApiParams)
                    }, d.initializeChatBar = function() {
                        d.chatLibrary.chatLayout.chatBarInitialized || (j() && !d.preSetChatLibrary.chatBarLayout ? d.chatLibrary.chatLayout.collapsed = !1 : d.preSetChatLibrary.chatBarLayout ? d.chatLibrary.chatLayout.collapsed = d.preSetChatLibrary.chatBarLayout.collapsed : j() || (d.chatLibrary.chatLayout.collapsed = !0), d.chatLibrary.chatLayout.chatBarInitialized = !0), l.logSinglePerformanceMark(g.performanceMarkLabels.chatPageDataLoaded)
                    };

                    function z(e, a) {
                        var t = d.chatLibrary.layoutIdList.indexOf(e);
                        a && -1 < t ? d.chatLibrary.layoutIdList.splice(t, 1) : !a && t < 0 && d.chatLibrary.layoutIdList.push(e)
                    }

                    function $(e) {
                        return d.chatLibrary.userConversationsDict[e] || null
                    }
                    d.removeFriend = function(e) {
                        var a = (a = $(e)) || d.getLayoutId(e, g.dialogType.FRIEND);
                        d.chatUserDict[a] && (e = d.chatUserDict[a].id, d.chatLibrary.conversationsDict[e].remove = !0), -1 < d.chatLibrary.chatLayoutIds.indexOf(a) && d.closeDialog(a), 0 === d.chatLibrary.chatLayoutIds.length && (d.chatLibrary.chatLayout.chatLandingEnabled = !0)
                    };

                    function H() {
                        var e;
                        window && window.location && (u.debug("--- -initialzeUrlParser- ---"), (e = window.location.search) && -1 < e.indexOf("?") && (e = e.substr(1)).split("&").forEach(function(e) {
                            var a = e.split("="),
                                e = a[0],
                                t = decodeURIComponent(a[1]);
                            switch (e) {
                                case g.urlParamNames.startConversationWithUserId:
                                    d.startSpecificConversationFromUserId(t);
                                    break;
                                case g.urlParamNames.conversationId:
                                    d.chatLibrary.chatLayout.urlParseInitialized = !0, d.startSpecificConversationFromConvId(t)
                            }
                        }))
                    }
                    d.getAllFriends = function() {
                        M.getFriendsPresence().then(function(e) {
                            d.getFriendsInfo(e)
                        }, function(e) {
                            console.debug(e)
                        })
                    }, d.updateDialogList = function(e, a) {
                        for (A(); d.chatLibrary.chatLayout.numberOfDialogs + d.chatLibrary.chatLayout.numberOfMinimizedDialogs >= d.chatLibrary.chatLayout.maxOpenDialogs;) {
                            var t = d.chatLibrary.dialogIdList[0];
                            d.closeDialog(t), A()
                        }
                        if (d.dialogsOverflowWindow())
                            for (; d.chatLibrary.dialogIdList.length >= d.chatLibrary.chatLayout.availableNumberOfDialogs;) {
                                var i = d.chatLibrary.dialogIdList.pop();
                                if (Z().isUndefined(i)) break;
                                d.chatLibrary.dialogDict[i].isUpdated = !0, d.chatLibrary.dialogDict[i].updateStatus = g.dialogStatus.MINIMIZE;
                                i = d.chatLibrary.minimizedDialogIdList.indexOf(e); - 1 < i && (d.chatLibrary.dialogsLayout[e].collapsed && (d.chatLibrary.dialogsLayout[e].collapsed = !1), d.chatLibrary.minimizedDialogIdList.splice(i, 1), delete d.chatLibrary.minimizedDialogData[e])
                            }
                        d.chatLibrary.dialogIdList.indexOf(e) < 0 && d.chatLibrary.dialogIdList.push(e);
                        var r = J({}, g.dialogInitValue);
                        Z().isDefined(a) && a && (r.autoOpen = !0), d.chatLibrary.dialogDict[e] = r
                    }, d.getUserConversations = function() {
                        var r = d.chatApiParams.getUserConversationsNextCursor;
                        o.getUserConversations(r, d.chatApiParams.pageSizeOfConversations, d.chatLibrary.friendsDict).then(function(e) {
                            var a = e.conversations;
                            r || d.sendWebChatConversationsLoadedEvent(a), l.logSinglePerformanceMark(g.performanceMarkLabels.chatConversationsLoaded);
                            var t = [],
                                i = d.chatLibrary.friendsDict;
                            a && 0 < a.length && (t = T.getUserIdsNotInFriendsDict(a, i), d.buildChatUserListByConversations(a, !1), d.chatApiParams.getUserConversationsNextCursor = e.next_cursor, d.retrieveDialogStatus());
                            e = !e.next_cursor;
                            return !a || e ? (d.chatApiParams.loadMoreConversations = !1, d.chatApiParams.getUserConversationsNextCursor = null, a && 0 === a.length && (d.chatLibrary.chatLayout.chatLandingEnabled = !0)) : d.chatApiParams.loadMoreConversations = !0, d.chatLibrary.chatLayout.pageDataLoading && (d.chatLibrary.chatLayout.pageDataLoading = !1), d.chatLibrary.chatLayout.urlParseInitialized || H(), S.getUserContacts(t, i), D.getUserInfo(t, i)
                        }, function(e) {
                            console.debug(e)
                        })
                    }, d.getUserConversationsFromCursor = function(e) {
                        o.getUserConversations(e, d.chatApiParams.pageSizeOfConversations, d.chatLibrary.friendsDict).then(function(e) {
                            var a = e.conversations;
                            l.logSinglePerformanceMark(g.performanceMarkLabels.chatConversationsLoaded);
                            var t = [],
                                e = d.chatLibrary.friendsDict;
                            return a && 0 < a.length && (t = T.getUserIdsNotInFriendsDict(a, e), d.buildChatUserListByConversations(a, !1), d.retrieveDialogStatus()), d.chatLibrary.chatLayout.pageDataLoading && (d.chatLibrary.chatLayout.pageDataLoading = !1), d.chatLibrary.chatLayout.urlParseInitialized || H(), S.getUserContacts(t, e), D.getUserInfo(t, e)
                        }, function(e) {
                            console.debug(e)
                        })
                    }, d.updateConversationTitle = function(t) {
                        var e = [t];
                        o.getConversations(e).then(function(e) {
                            e && (d.buildChatUserListByUnreadConversations(e, !0), Z().forEach(e, function(e) {
                                var a;
                                e.id == t && (a = d.chatLibrary.conversationsDict[t] ? d.chatLibrary.conversationsDict[t].layoutId : d.getLayoutId(t, g.dialogType.CHAT), a = d.chatUserDict[a], g.updateConversationTitle(a, e.title))
                            }))
                        }, function() {
                            u.debug(" -------- getConversations request failed ------ ")
                        })
                    }, d.resetTypingStatusAsReceiver = function(e, a) {
                        u.debug("--------- resetTypingStatusAsReceiver has been called-----------");
                        var t = e.typing,
                            i = e.typing.userTypingDict[a],
                            r = e.typing.userIds.indexOf(a);
                        e.typing.userIds.splice(r), e.typing.isTypingFromSender = !1, i.status = !1, i.lastTimeReceiveTypingEvent = null, s.cancel(i.lastTimeReceiveTimer), delete e.typing.userTypingDict[a], s.cancel(t.lastTimeReceiveTimer)
                    }, d.typingStatusForReceiverExpirationInterval = function(e, a, t) {
                        e.typing.userIds.indexOf(t) < 0 && e.typing.userIds.push(t);
                        var i = a || (new Date).getTime(),
                            a = e.typing.userTypingDict[t];
                        a.lastTimeReceiveTypingEvent || (a.lastTimeReceiveTypingEvent = i), (i - a.lastTimeReceiveTypingEvent > d.chatLibrary.typingInChatForReceiverExpirationMs || !a.status) && d.resetTypingStatusAsReceiver(e, t)
                    }, d.updateConverationTypingStatus = function(e, a) {
                        var t = d.chatLibrary.conversationsDict[e] ? d.chatLibrary.conversationsDict[e].layoutId : d.getLayoutId(e),
                            i = d.chatUserDict[t],
                            e = a.status,
                            r = a.userId,
                            n = d.chatLibrary.dialogsLayout[t];
                        n && (n.typing.userTypingDict[r] || (n.typing.userTypingDict[r] = {}), n.typing.isTypingFromSender = e, (t = n.typing.userTypingDict[r]).status = e, c.refreshTypingStatus(i, r, e, n), e && !t.lastTimeReceiveTimer ? (u.debug("--------- start a new timer-----------".concat(r)), d.typingStatusForReceiverExpirationInterval(n, null, r), t.lastTimeReceiveTimer = s(function() {
                            return d.typingStatusForReceiverExpirationInterval(n, null, r)
                        }, d.chatLibrary.typingInChatForReceiverExpirationMs)) : !e && t.lastTimeReceiveTimer && (u.debug("--------- cancel timer-----------".concat(r)), d.resetTypingStatusAsReceiver(n, r)))
                    }, d.fetchPlaceDetailsIntoPlacesLibrary = function(e, t) {
                        e && 0 < e.length && v.multiGetPlaceDetails(e).then(function(e) {
                            v.buildPlacesLibrary(d.chatLibrary, e);
                            var a = d.chatLibrary.placesLibrary;
                            Z().forEach(t, function(e) {
                                v.buildButtonLayoutPerConversation(e, a)
                            })
                        })
                    }, d.handleChannelsNotifications = function(a) {
                        u.debug("--------- this is ".concat(g.notificationsName.CommunicationChannelsNotifications, " subscription -----------").concat(a.Type));
                        try {
                            var e = a.Type,
                                t = a.ChannelId;
                            switch (e) {
                                case g.channelsNotificationType.messageCreated:
                                case g.channelsNotificationType.systemMessageCreated:
                                    R(t);
                                    break;
                                case g.channelsNotificationType.addedToChannel:
                                case g.channelsNotificationType.channelCreated:
                                case g.channelsNotificationType.channelUnarchived:
                                case g.channelsNotificationType.participantsAdded:
                                case g.channelsNotificationType.participantsRemoved:
                                    N(t);
                                    break;
                                case g.channelsNotificationType.channelArchived:
                                case g.channelsNotificationType.channelDeleted:
                                case g.channelsNotificationType.removedFromChannel:
                                    d.chatLibrary.conversationsDict[t].remove || (i = d.chatLibrary.conversationsDict[t].layoutId, d.chatLibrary.conversationsDict[t].remove = !0, d.closeDialog(i), N(t));
                                    break;
                                case g.channelsNotificationType.channelUpdated:
                                    d.updateConversationTitle(t);
                                    break;
                                case g.channelsNotificationType.participantTyping:
                                    var i = {
                                        status: !0,
                                        userId: parseInt(a.Actor.Id)
                                    };
                                    d.updateConverationTypingStatus(t, i)
                            }
                        } catch (e) {
                            var r = "".concat(g.notificationsName.CommunicationChannelsNotifications, ":").concat(a.Type, ": ");
                            e && e.message && (r += e.message), h.fireEvent(d.chatLibrary.googleAnalyticsEvent.category, d.chatLibrary.googleAnalyticsEvent.action, r)
                        }
                    }, d.handleChatMigrationNotifications = function(a) {
                        var e, t, i;
                        u.debug("--------- this is ".concat(g.notificationsName.ChatMigrationNotifications, " subscription -----------").concat(a.Type));
                        try {
                            var r = a.Type;
                            if (r === g.notificationType.conversationBackfilled) e = a.ConversationId, t = a.ChannelId;
                            else {
                                if (r !== g.notificationType.conversationReset) return;
                                e = a.ChannelId, t = a.ConversationId
                            }
                            i = e, N(t).then(function(e) {
                                var a;
                                !e || (a = e[0]) && (e = a.dialogType, e = d.getLayoutId(i, e), d.chatUserDict[e] && (d.replaceConversation(e, a), d.processLatestMessageForConversations([{
                                    conversationId: a.id,
                                    messages: a.messages
                                }])))
                            })
                        } catch (e) {
                            var n = "".concat(g.notificationsName.ChatMigrationNotifications, ":").concat(a.Type, ": ");
                            e && e.message && (n += e.message), h.fireEvent(d.chatLibrary.googleAnalyticsEvent.category, d.chatLibrary.googleAnalyticsEvent.action, n)
                        }
                    }, d.handleChatModerationTypeEligibilityNotifications = function(e) {
                        if (u.debug("--------- this is ".concat(g.notificationsName.ChatModerationTypeEligibilityNotifications, " subscription -----------")), d.chatLibrary.isTrustedCommsWebEnabled) try {
                            var a = e.channels_inspected;
                            if (!a || 0 === a.length) return;
                            a = a.filter(function(e) {
                                return d.chatLibrary.conversationsDict[e]
                            });
                            if (0 === a.length) return;
                            ! function(e) {
                                for (var a = 0; a < e.length; a += g.chatApiParams.pageSizeOfConversations) {
                                    var t = e.slice(a, a + g.chatApiParams.pageSizeOfConversations);
                                    F(t, !1)
                                }
                            }(a)
                        } catch (e) {
                            var t = "".concat(g.notificationsName.ChatModerationTypeEligibilityNotifications, " ");
                            e && e.message && (t += e.message), h.fireEvent(d.chatLibrary.googleAnalyticsEvent.category, d.chatLibrary.googleAnalyticsEvent.action, t)
                        }
                    }, d.handleChatNotifications = function(a) {
                        u.debug("--------- this is ChatNotifications subscription -----------".concat(a.Type));
                        try {
                            var e, t, i, r, n = a.Type,
                                s = a.ConversationId;
                            switch (n) {
                                case g.notificationType.newMessage:
                                    R(s);
                                    break;
                                case g.notificationType.newMessageBySelf:
                                    R(s, !0);
                                    break;
                                case g.notificationType.newConversation:
                                case g.notificationType.addedToConversation:
                                case g.notificationType.participantAdded:
                                case g.notificationType.participantLeft:
                                    N(s);
                                    break;
                                case g.notificationType.removedFromConversation:
                                    d.chatLibrary.conversationsDict[s].remove || (i = d.chatLibrary.conversationsDict[s].layoutId, d.chatLibrary.conversationsDict[s].remove = !0, d.closeDialog(i));
                                    break;
                                case g.notificationType.conversationTitleChanged:
                                    var o = a.ActorTargetId;
                                    d.updateConversationTitle(s);
                                    break;
                                case g.notificationType.participantTyping:
                                    var l = {
                                        status: a.IsTyping,
                                        userId: a.UserId
                                    };
                                    d.updateConverationTypingStatus(s, l);
                                    break;
                                case g.notificationType.conversationUniverseChanged:
                                    d.chatLibrary.conversationsDict[s] && (r = a.RootPlaceId, e = a.UniverseId, o = a.ActorTargetId, i = d.chatLibrary.conversationsDict[s].layoutId, t = d.chatUserDict[i], l = d.chatLibrary.placesLibrary && d.chatLibrary.placesLibrary[r] ? d.chatLibrary.placesLibrary[r].placeName : "", i = d.chatLibrary.placesLibrary && d.chatLibrary.placesLibrary[r] ? d.chatLibrary.placesLibrary[r].encodedPlaceName : "", l = {
                                        rootPlaceId: r,
                                        universeId: e,
                                        actorUsername: d.chatLibrary.friendsDict[o].name,
                                        userId: a.ActorTargetId,
                                        placeName: l,
                                        encodedPlaceName: i
                                    }, i = [r], r = [t], d.fetchPlaceDetailsIntoPlacesLibrary(i, r), b.setPinGameData(t, l))
                            }
                        } catch (e) {
                            var c = "ChatNotifications:".concat(a.Type, ": ");
                            e && e.message && (c += e.message), h.fireEvent(d.chatLibrary.googleAnalyticsEvent.category, d.chatLibrary.googleAnalyticsEvent.action, c)
                        }
                    }, d.handleFriendshipNotifications = function(a) {
                        u.debug("--------- this is FriendshipNotifications subscription -----------".concat(a.Type));
                        try {
                            switch (a.Type) {
                                case g.notificationType.friendshipDestroyed:
                                    var e = a.EventArgs;
                                    Z().forEach(e, function(e) {
                                        e !== d.chatLibrary.userId && d.$digest(d.removeFriend(e))
                                    }), M.getFriendsPresence(!0).then(function(e) {
                                        d.getFriendsInfo(e)
                                    }, function(e) {
                                        console.debug(e)
                                    }), r.triggerHandler("Roblox.Friends.CountChanged");
                                    break;
                                case g.notificationType.friendshipCreated:
                                    M.getFriendsPresence(!0).then(function(e) {
                                        d.getFriendsInfo(e)
                                    }, function(e) {
                                        console.debug(e)
                                    }), d.getUserConversationsFromCursor(""), r.triggerHandler("Roblox.Friends.CountChanged")
                            }
                        } catch (e) {
                            var t = "FriendshipNotifications:".concat(a.Type, ": ");
                            e && e.message && (t += e.message), h.fireEvent(d.chatLibrary.googleAnalyticsEvent.category, d.chatLibrary.googleAnalyticsEvent.action, t)
                        }
                    }, d.handleUserTagNotifications = function(e) {
                        e.Type === g.notificationType.userTagUpdate && S.getUserContacts(Object.keys(d.chatLibrary.friendsDict), d.chatLibrary.friendsDict, S.options.skipCache)
                    }, d.buildPlayTogetherInConversationFromPresence = function(e, i, r) {
                        Z().forEach(e, function(e) {
                            var a = d.chatUserDict[e],
                                t = [i];
                            f.sortPlayTogetherIds(a, r), d.fetchPlaceDetailsIntoPlacesLibrary(t, [a]), d.chatLibrary.dialogDict[e] && (a.pinGame && i === a.pinGame.rootPlaceId && r.userId !== d.chatLibrary.userId && (a.recentUserIdFromPresence = r.userId, a.recentPlaceIdFromPresence = i, c.buildSystemMessage(g.notificationType.presenceOnline, a)), !(e = d.chatLibrary.dialogsLayout[e]).togglePopoverParams.isOpen && !a.placeForShown && a.playTogetherIds && 0 < a.playTogetherIds.length && (e.togglePopoverParams.isOpen = !0)), f.setPlaceForShown(a)
                        })
                    }, d.releasePlayerFromActivePlaceLists = function(e, r) {
                        Z().forEach(e, function(e) {
                            var t = d.chatUserDict[e],
                                i = [];
                            Z().forEach(t.playTogetherDict, function(e, a) {
                                var t;
                                a = parseInt(a), -1 < e.playerIds.indexOf(r) && (t = e.playerIds.indexOf(r), e.playerIds.splice(t, 1), 0 === e.playerIds.length && i.push(a))
                            }), i && 0 < i.length && Z().forEach(i, function(e) {
                                var a = t.playTogetherIds.indexOf(e);
                                t.playTogetherIds.splice(a, 1), delete t.playTogetherDict[e]
                            }), f.setPlaceForShown(t), t.pinGame && t.pinGame.rootPlaceId && (e = t.pinGame.rootPlaceId, v.updateButtonLayoutPerConversation(t, e))
                        })
                    }, d.vanishRootPlaceIdFromPlayTogether = function(r, n, e) {
                        Z().forEach(e, function(e) {
                            var t = d.chatUserDict[e],
                                i = [];
                            Z().forEach(t.playTogetherDict, function(e, a) {
                                a = parseInt(a), n === a && 1 === e.playerIds.length && -1 < e.playerIds.indexOf(r) && i.push(a)
                            }), i && 0 < i.length && Z().forEach(i, function(e) {
                                var a = t.playTogetherIds.indexOf(e);
                                t.playTogetherIds.splice(a, 1), delete t.playTogetherDict[e]
                            })
                        })
                    }, d.updatePresenceInFriendDict = function(e) {
                        d.chatLibrary.friendsDict[e.userId].userPresenceType = e.userPresenceType, d.chatLibrary.friendsDict[e.userId].presenceData = e, d.chatLibrary.friendsDict[e.userId].presence = e
                    }, d.updatePresenceStatus = function(e) {
                        for (var a = 0; a < e.length; a++) {
                            var t = e[a],
                                i = t.userId;
                            d.chatLibrary.friendsDict[i] || (d.chatLibrary.friendsDict[i] = {});
                            var r, n = t.userPresenceType,
                                s = d.chatLibrary.friendsDict[i].presence,
                                o = null;
                            n === L.status.inGame ? (r = t.rootPlaceId, s && n === s.userPresenceType && r === s.rootPlaceId || (o = d.chatLibrary.layoutIdsDictPerUserId[i], s && s.rootPlaceId && d.vanishRootPlaceIdFromPlayTogether(i, s.rootPlaceId, o), d.updatePresenceInFriendDict(t), r && d.buildPlayTogetherInConversationFromPresence(o, r, t))) : s && n === s.userPresenceType || (d.updatePresenceInFriendDict(t), s && s.userPresenceType === L.status.inGame && (o = d.chatLibrary.layoutIdsDictPerUserId[i], d.releasePlayerFromActivePlaceLists(o, i)))
                        }
                    }, d.listenToPresenceServiceInWeb = function() {
                        document.addEventListener("Roblox.Presence.Update", function(e) {
                            null != e && e.detail && t(function() {
                                d.updatePresenceStatus(e.detail)
                            }, 0)
                        })
                    }, d.unsubscribeRealTimeForChat = function() {
                        B.Unsubscribe(g.notificationsName.CommunicationChannelsNotifications, d.handleChannelsNotifications), B.Unsubscribe(g.notificationsName.ChatMigrationNotifications, d.handleChatMigrationNotifications), B.Unsubscribe(g.notificationsName.ChatModerationTypeEligibilityNotifications, d.handleChatModerationTypeEligibilityNotifications), B.Unsubscribe(g.notificationsName.ChatNotifications, d.handleChatNotifications), B.Unsubscribe(g.notificationsName.FriendshipNotifications, d.handleFriendshipNotifications), B.Unsubscribe(g.notificationsName.UserTagNotifications, d.handleUserTagNotifications)
                    }, d.handleChatPrivacySetting = function(a) {
                        u.debug("--------- this is ChatPrivacySettingNotifications subscription -----------".concat(a.Type));
                        try {
                            switch (a.Type) {
                                case g.notificationType.chatEnabled:
                                    d.chatLibrary.chatLayout.isChatEnabledByPrivacySetting = d.chatLibrary.chatLayout.chatEnabledByPrivacySettingTypes.enabled, d.handleSignalRSuccess(!0), d.initializeRealTimeSubscriptionsForChat();
                                    break;
                                case g.notificationType.chatDisabled:
                                    d.chatLibrary.chatLayout.isChatEnabledByPrivacySetting = d.chatLibrary.chatLayout.chatEnabledByPrivacySettingTypes.disabled, d.unsubscribeRealTimeForChat()
                            }
                        } catch (e) {
                            var t = "ChatPrivacySettingNotifications:".concat(a.Type, ": ");
                            e && e.message && (t += e.message), h.fireEvent(d.chatLibrary.googleAnalyticsEvent.category, d.chatLibrary.googleAnalyticsEvent.action, t)
                        }
                    }, d.initializeRealTimeSubscriptionsForChatPrivacySetting = function() {
                        Z().isDefined(B) && B.Subscribe(g.notificationsName.ChatPrivacySettingNotifications, d.handleChatPrivacySetting)
                    }, d.initializeRealTimeSubscriptionsForChat = function() {
                        Z().isDefined(B) && (l.logSinglePerformanceMark(g.performanceMarkLabels.chatSignalRInitializing), B.SubscribeToConnectionEvents(d.handleSignalRSuccess, d.handleSignalRSuccess, d.handleSignalRError, g.notificationsName.ChatNotifications), B.Subscribe(g.notificationsName.CommunicationChannelsNotifications, d.handleChannelsNotifications), B.Subscribe(g.notificationsName.ChatMigrationNotifications, d.handleChatMigrationNotifications), B.Subscribe(g.notificationsName.ChatModerationTypeEligibilityNotifications, d.handleChatModerationTypeEligibilityNotifications), B.Subscribe(g.notificationsName.ChatNotifications, d.handleChatNotifications), B.Subscribe(g.notificationsName.FriendshipNotifications, d.handleFriendshipNotifications), B.Subscribe(g.notificationsName.UserTagNotifications, d.handleUserTagNotifications), d.listenToPresenceServiceInWeb())
                    }, d.handleSignalRSuccess = function(e) {
                        if (u.debug(" -------- Signal R is connected ------ "), d.chatLibrary.chatLayout.errorMaskEnable && d.$apply(function() {
                                d.chatLibrary.chatLayout.errorMaskEnable = !1
                            }), d.chatLibrary.timer && t.cancel(d.chatLibrary.timer), e || l.logSinglePerformanceMark(g.performanceMarkLabels.chatSignalRSucceeded), d.chatLibrary.chatLayout.pageInitializing) d.chatLibrary.chatLayout.pageInitializing = !1;
                        else try {
                            e && (d.initializePresetData(), d.initializeChat())
                        } catch (e) {
                            var a = "handleSignalRSuccess: ";
                            e && e.message && (a += e.message), h.fireEvent(d.chatLibrary.googleAnalyticsEvent.category, d.chatLibrary.googleAnalyticsEvent.action, a)
                        }
                    }, d.handleSignalRError = function() {
                        u.debug(" -------- Signal R is disconnected ------ "), d.chatLibrary.timer = t(function() {
                            d.chatLibrary.chatLayout.errorMaskEnable = !0
                        }, parseInt(d.chatLibrary.signalRDisconnectionResponseInMilliseconds))
                    }, d.onResize = function() {
                        if (d.chatLibrary.chatLayout.numberOfDialogs > d.chatLibrary.chatLayout.availableNumberOfDialogs)
                            for (; d.chatLibrary.dialogIdList.length > d.chatLibrary.chatLayout.availableNumberOfDialogs;) {
                                u.debug(" -------------overflow ------ $scope.chatLibrary.dialogIdList.length ------------- ".concat(d.chatLibrary.dialogIdList.length));
                                var e = d.chatLibrary.dialogIdList.pop();
                                if (Z().isUndefined(e)) break;
                                e && d.chatLibrary.dialogDict[e] && (d.chatLibrary.dialogDict[e].isUpdated = !0, d.chatLibrary.dialogDict[e].updateStatus = g.dialogStatus.MINIMIZE)
                            } else if (d.chatLibrary.chatLayout.numberOfDialogs < d.chatLibrary.chatLayout.availableNumberOfDialogs)
                                for (; d.chatLibrary.dialogIdList.length < d.chatLibrary.chatLayout.availableNumberOfDialogs;) {
                                    u.debug(" -------------fit ------ $scope.chatLibrary.dialogIdList.length ------------- ".concat(d.chatLibrary.dialogIdList.length));
                                    var a, e = d.chatLibrary.minimizedDialogIdList.pop();
                                    if (Z().isUndefined(e)) break;
                                    e && d.chatLibrary.minimizedDialogData[e] && (delete d.chatLibrary.minimizedDialogData[e], d.chatLibrary.dialogIdList.push(e), a = J({}, g.dialogInitValue), d.chatLibrary.dialogDict[e] = a)
                                }
                        d.chatLibrary.chatLayout.resizing = !1
                    }, d.getLayoutId = function(e, a) {
                        switch (a) {
                            case g.dialogType.FRIEND:
                                return "friend_".concat(e);
                            case g.dialogType.NEWGROUPCHAT:
                                return g.newGroup.dialogType;
                            case g.dialogType.CHAT:
                            case g.dialogType.GROUPCHAT:
                            case g.dialogType.ADDFRIENDS:
                            default:
                                return "conv_".concat(e)
                        }
                    }, d.getUserInfoForConversation = function(r) {
                        var n;
                        r.participants && (r.userIds = [], r.candidatePlayerIds = [], n = [], r.participants.forEach(function(e) {
                            var a, t = e.id,
                                i = e.name;
                            switch (r.dialogType) {
                                case d.dialogType.GROUPCHAT:
                                    r.userIds.push(t), t !== d.chatLibrary.userId && (r.playerIds && r.playerIds.indexOf(t) < 0 || !r.playerIds) && r.candidatePlayerIds.push(t);
                                    break;
                                case d.dialogType.FRIEND:
                                case d.dialogType.CHAT:
                                    t !== d.chatLibrary.userId && (r.userIds.push(t), r.displayUserId = t, r.username = i, (r.playerIds && r.playerIds.indexOf(t) < 0 || !r.playerIds) && r.candidatePlayerIds.push(t));
                                    break;
                                default:
                                    r.userIds.push(t)
                            }
                            t !== d.chatLibrary.userId && d.buildPlayTogetherListForEachConveration(e, r), d.chatLibrary.friendsDict[t] || (n.push(t), a = e.name, e = e.display_name, d.chatLibrary.friendsDict[t] = {
                                id: t,
                                name: a,
                                display_name: e,
                                nameForDisplay: null !== _.DisplayNames && void 0 !== _.DisplayNames && _.DisplayNames.Enabled() ? e : a
                            }), d.chatLibrary.layoutIdsDictPerUserId[t] || (d.chatLibrary.layoutIdsDictPerUserId[t] = []), d.chatLibrary.layoutIdsDictPerUserId[t].indexOf(r.layoutId) < 0 && d.chatLibrary.layoutIdsDictPerUserId[t].push(r.layoutId)
                        }), 0 < n.length && D.getUserInfo(n, d.chatLibrary.friendsDict).then(function(e) {
                            e && (n.forEach(function(e) {
                                e = d.chatLibrary.friendsDict[e];
                                d.buildPlayTogetherListForEachConveration(e, r), d.getPlaceDetailsForNewPlaceIds([r])
                            }), S.getUserContacts(n, d.chatLibrary.friendsDict, S.options.noCache))
                        }), f.setPlaceForShown(r))
                    }, d.buildPlayTogetherListForEachConveration = function(e, a) {
                        if (!d.chatLibrary.friendsDict) return !1;
                        e = d.chatLibrary.friendsDict[e.id];
                        e && e.presence && e.presence.userPresenceType === L.status.inGame && f.sortPlayTogetherIds(a, e.presence)
                    }, d.updateChatViewModel = function(i, e) {
                        switch (i.isGroupChat || i.dialogType !== g.dialogType.CHAT || i.participants.forEach(function(e) {
                            e = e.id;
                            e !== d.chatLibrary.userId && (e = d.getLayoutId(e, g.dialogType.FRIEND), d.replaceConversation(e, i))
                        }), i.dialogType) {
                            case d.dialogType.GROUPCHAT:
                            case d.dialogType.CHAT:
                                i.name = i.title, d.chatLibrary.allConversationLayoutIdsDict[i.id] = i.layoutId;
                                break;
                            default:
                                Z().isDefined(i.Username) && (i.name = i.Username)
                        }
                        var a = [W.UserProfileField.Names.CombinedName],
                            t = i.userIds,
                            r = i.isGroupChat;
                        U.watchUserProfiles(t, a).subscribe(function(e) {
                            e.loading, e.error;
                            var a = e.data,
                                t = [];
                            Z().forEach(a, function(e) {
                                t.push(e.names.combinedName)
                            }), t.sort();
                            e = t.join(", ");
                            r ? (a = i.conversationTitle.titleForViewer, g.updateConversationTitle(i, i.hasDefaultName ? e : a)) : g.updateConversationTitle(i, e), d.$applyAsync()
                        }), d.chatUserDict[i.layoutId] = i;
                        a = d.chatLibrary.chatLayoutIds.indexOf(i.layoutId); - 1 < a && d.chatLibrary.chatLayoutIds.splice(a, 1), e ? (e = d.chatLibrary.chatLayoutIds[0], d.chatUserDict[e], d.chatLibrary.chatLayoutIds.unshift(i.layoutId)) : d.chatLibrary.chatLayoutIds.push(i.layoutId), z(i.layoutId), d.chatLibrary.conversationsDict[i.id] || (d.chatLibrary.conversationsDict[i.id] = J({}, g.conversationInitStatus), d.chatLibrary.conversationsDict[i.id].layoutId = i.layoutId)
                    }, d.updateConversationInLocalStorage = function(e) {
                        var a = {
                                pageNumber: 1,
                                pageSize: d.chatApiParams.pageSizeOfConversations
                            },
                            t = I.getStorageName(I.chatDataName.getUserConversations, a),
                            a = I.getChatDataFromLocalStorage(t);
                        a && ((a = a.data).unshift(e), I.saveChatDataToLocalStorage(t, a))
                    }, d.buildChatUserListByUnreadConversations = function() {
                        var o, t = (o = regeneratorRuntime.mark(function e(o, l) {
                            var a, t;
                            return regeneratorRuntime.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        a = regeneratorRuntime.mark(function e(a) {
                                            var t, i, r, n, s;
                                            return regeneratorRuntime.wrap(function(e) {
                                                for (;;) switch (e.prev = e.next) {
                                                    case 0:
                                                        return (t = o[a]).isGroupChat = g.conversationType.multiUserConversation === t.type, t.dialogType = t.isGroupChat ? g.dialogType.GROUPCHAT : g.dialogType.CHAT, d.getUserInfoForConversation(t), s = [W.UserProfileField.Names.CombinedName], i = t.userIds, r = [], e.next = 9, U.queryUserProfiles(i, s);
                                                    case 9:
                                                        s = e.sent, Z().forEach(s, function(e) {
                                                            r.push(e.names.combinedName)
                                                        }), r.sort(), s = r.join(", "), t.isGroupChat ? (n = t.conversationTitle.titleForViewer, g.updateConversationTitle(t, t.hasDefaultName ? s : n)) : g.updateConversationTitle(t, s), t.isUserPending = d.getIsUserPending(t), c.formatTimestampInConversation(t), n = d.getLayoutId(t.id, g.dialogType.CHAT), d.chatUserDict[n] ? (s = d.chatUserDict[n], t.hasUnreadMessages && t.chatMessages && 0 < t.chatMessages.length && (s.hasUnreadMessages = !0, d.chatLibrary.dialogDict[n] && -1 < d.chatLibrary.dialogIdList.indexOf(n) && (c.processMessages(d.chatLibrary, s, t.chatMessages, d.chatLibrary.friendsDict), v.fetchDataForLinkCard(t.chatMessages, d.chatLibrary)), g.sanitizeMessage(t.chatMessages[0]), s.displayMessage = c.buildDisplayMessage(t.chatMessages[0]), d.updateChatViewModel(s, !0)), t.title !== s.title && g.updateConversationTitle(s, t.title), s.participants = t.participants, s.isUserPending = t.isUserPending, s.moderationType = t.moderationType, s.userPendingStatus = t.userPendingStatus, d.getUserInfoForConversation(s), l && x(s)) : (d.updateConversationInLocalStorage(t), t.layoutId = n, d.updateChatViewModel(t, !0), l && x(t)), d.$apply();
                                                    case 19:
                                                    case "end":
                                                        return e.stop()
                                                }
                                            }, e)
                                        }), t = 0;
                                    case 2:
                                        if (t < o.length) return e.delegateYield(a(t), "t0", 4);
                                        e.next = 7;
                                        break;
                                    case 4:
                                        t++, e.next = 2;
                                        break;
                                    case 7:
                                        return e.abrupt("return", o);
                                    case 8:
                                    case "end":
                                        return e.stop()
                                }
                            }, e)
                        }), function() {
                            var e = this,
                                s = arguments;
                            return new Promise(function(a, t) {
                                var i = o.apply(e, s);

                                function r(e) {
                                    q(i, a, t, r, n, "next", e)
                                }

                                function n(e) {
                                    q(i, a, t, r, n, "throw", e)
                                }
                                r(void 0)
                            })
                        });
                        return function(e, a) {
                            return t.apply(this, arguments)
                        }
                    }(), d.getPlaceDetailsForNewPlaceIds = function(e) {
                        var a, r = [],
                            n = [];
                        e.forEach(function(t) {
                            var e, i = d.chatLibrary.placesLibrary;
                            t.pinGame && (e = t.pinGame.rootPlaceId, !g.isPlaceDetailQualifiedInLibrary(i, e) && r.indexOf(e) < 0 && r.push(e)), t.playTogetherIds && 0 < t.playTogetherIds.length && t.playTogetherIds.forEach(function(e) {
                                !g.isPlaceDetailQualifiedInLibrary(i, e) && r.indexOf(e) < 0 && r.push(e);
                                var a = t.id;
                                t.placeButtonLayout && t.placeButtonLayout[e] || !(n.indexOf(a) < 0) || n.push(a)
                            })
                        }), 0 < r.length ? d.fetchPlaceDetailsIntoPlacesLibrary(r, e) : 0 < n.length && (a = d.chatLibrary.placesLibrary, Z().forEach(e, function(e) {
                            -1 < n.indexOf(e.id) && v.buildButtonLayoutPerConversation(e, a)
                        }))
                    }, d.isConversationExistedInViewModel = function(e) {
                        if (e && e.layoutId) {
                            e = e.layoutId;
                            return d.chatUserDict && d.chatUserDict[e]
                        }
                        return !1
                    }, d.getIsUserPending = function(e) {
                        return !(!d.chatLibrary.isTrustedCommsWebEnabled || e.userPendingStatus !== g.pendingStatus.PENDING)
                    }, d.buildChatUserListByConversations = function(e, i) {
                        var r = [];
                        e.forEach(function(e) {
                            if ("friends" === e.source) {
                                if (!e || !e.participants) return;
                                var a = null;
                                if (e.participants.forEach(function(e) {
                                        e = e.id;
                                        e === d.chatLibrary.userId || a || (a = e)
                                    }), !a) return;
                                e.id = a, e.dialogType = g.dialogType.FRIEND
                            }
                            var t = d.getLayoutId(e.id, e.dialogType);
                            r.push(e.id), e.layoutId = t, d.getUserInfoForConversation(e), e.isUserPending = d.getIsUserPending(e), d.isConversationExistedInViewModel(e) || d.updateChatViewModel(e, i)
                        }), d.processLatestMessageForConversations(e.map(function(e) {
                            return {
                                conversationId: e.id,
                                messages: e.messages
                            }
                        })), d.getPlaceDetailsForNewPlaceIds(e)
                    }, d.openConversation = function() {
                        var e = d.chatLibrary.dialogRequestedToOpenParams.layoutId,
                            a = d.chatLibrary.dialogRequestedToOpenParams.autoPop;
                        d.chatUserDict[e] && (d.updateDialogList(e, a), d.$evalAsync())
                    }, d.openConversationFromFriendId = function(e, i) {
                        return i = void 0 === i || "boolean" != typeof i || i, o.startOneToOneConversation(e).then(function(e) {
                            var a, t = d.getLayoutId(e.id, g.dialogType.CHAT);
                            return e.layoutId = t, e.dialogType = g.dialogType.CHAT, e.chatMessages = [], e.isGroupChat = e.type === g.conversationType.multiUserConversation, d.getUserInfoForConversation(e), v.buildButtonLayoutPerConversation(e, d.chatLibrary.placesLibrary), d.updateChatViewModel(e, i), e.pinGame && (a = e.pinGame.rootPlaceId, d.fetchPlaceDetailsIntoPlacesLibrary([a], [e])), g.updateFocusedDialog(d.chatLibrary, t), c.formatTimestampInConversation(e), e
                        }, function() {
                            u.debug(" ---- startOneToOneConversation ---- failed!")
                        })
                    }, d.destroyDialogLayout = function(e) {
                        e = "#".concat(e);
                        Z().element(e).empty()
                    }, d.deleteLayoutIdFromDialogList = function(e) {
                        for (var a = d.chatLibrary.dialogIdList, t = [], i = 0; i < a.length; i++) a[i] === e && t.push(i);
                        if (0 < t.length) {
                            for (var r = t.length - 1; 0 <= r; r--) d.chatLibrary.dialogIdList.splice(t[r], 1);
                            delete d.chatLibrary.dialogDict[e]
                        }
                    }, d.expandGameListInConversation = function(e) {
                        e = d.chatUserDict[e];
                        d.chatLibrary.playTogetherLibrary && d.chatLibrary.playTogetherLibrary[e.id] && (d.chatLibrary.playTogetherLibrary[e.id].layout.activeGamesList.isCollapsed = !0)
                    }, d.launchFromConversationList = function(e) {
                        d.sendChatLandingEvent(O.chatLandingConversationClicked, k.ChatLandingConversationClickedWeb, e), d.launchDialog(e, !1)
                    }, d.launchDialog = function(e, a) {
                        d.chatLibrary.dialogRequestedToOpenParams.layoutId = e, d.chatLibrary.dialogRequestedToOpenParams.autoPop = a;
                        var t, i = d.chatUserDict[e];
                        d.chatLibrary.dialogIdList.indexOf(e) < 0 && e === g.newGroup.layoutId ? (d.updateDialogList(e, a), d.chatUserDict[g.newGroup.layoutId] = d.newGroup) : d.chatLibrary.dialogIdList.indexOf(e) < 0 && i ? (d.openConversation(), d.expandGameListInConversation(e), a || g.updateFocusedDialog(d.chatLibrary, e)) : -1 < d.chatLibrary.dialogIdList.indexOf(e) && d.chatLibrary.dialogsLayout[e] && ((t = d.chatLibrary.dialogsLayout[e]).focusMeEnabled = !0, g.updateFocusedDialog(d.chatLibrary, e), t.collapsed && (t.collapsed = !1, g.updateDialogsPosition(d.chatLibrary))), i && !a && c.markMessagesAsRead(i, d.chatLibrary.shouldRespectConversationHasUnreadMessageToMarkAsRead)
                    }, d.closeDialog = function(e) {
                        var a = d.chatUserDict[e];
                        a && (t = g.getScrollBarSelector(a), t = Z().element(t));
                        var t;
                        Z().element("#chat-main");
                        d.chatLibrary.chatLayout.focusedLayoutId === e && g.updateFocusedDialog(d.chatLibrary, null), d.deleteLayoutIdFromDialogList(e), a && a.dialogType === g.dialogType.NEWGROUPCHAT && (a.selectedUserIds = [], a.selectedUsersDict = {}, a.numberOfSelected = 0), t && 0 < t.length && t.mCustomScrollbar("destroy"), d.$broadcast("Roblox.Chat.MarkDialogInactive", {
                            layoutId: e
                        }), a && (t = a.id, d.chatLibrary.conversationsDict[t] && d.chatLibrary.conversationsDict[t].remove ? (-1 < (t = d.chatLibrary.chatLayoutIds.indexOf(e)) && a && (d.chatLibrary.chatLayoutIds.splice(t, 1), delete d.chatUserDict[e], Z().equals(d.chatUserDict, {}) && (d.chatLibrary.chatLayout.chatLandingEnabled = !0)), z(e, !0)) : c.processMessages(d.chatLibrary, a, null)), d.destroyDialogLayout(e), 0 < d.chatLibrary.minimizedDialogIdList.length && (a = d.chatLibrary.minimizedDialogIdList.shift(), delete d.chatLibrary.minimizedDialogData[a], d.chatLibrary.dialogIdList.push(a), d.chatLibrary.dialogDict[a].isUpdated = !0, d.chatLibrary.dialogDict[a].updateStatus = g.dialogStatus.REPLACE), n.updateStorage(n.storageDictionary.dialogIdList, d.chatLibrary.dialogIdList, d.chatLibrary.cookieOption), n.updateStorage(n.storageDictionary.dialogDict, d.chatLibrary.dialogDict, d.chatLibrary.cookieOption), d.chatLibrary.dialogsLayout && d.chatLibrary.dialogsLayout[e] && (d.chatLibrary.dialogsLayout[e].collapsed = !1), delete d.chatLibrary.dialogsLayout[e], n.updateStorage(n.storageDictionary.dialogsLayout, d.chatLibrary.dialogsLayout, d.chatLibrary.cookieOption)
                    }, d.validLayoutId = function(e, a) {
                        return !!d.chatUserDict[e] || (d.chatApiParams.loadMoreConversations ? d.getUserConversations() : d.chatLibrary.chatLayout.urlParseInitialized = !0, !1)
                    }, d.startSpecificConversationFromUserId = function(e) {
                        var a = $(e);
                        a && d.validLayoutId(a, g.dialogType.CHAT) ? (d.chatLibrary.chatLayout.urlParseInitialized = !0, d.launchDialog(a, !0)) : d.openConversationFromFriendId(e)
                    }, d.startSpecificConversationFromConvId = function(e) {
                        var a = d.getLayoutId(e, g.dialogType.CHAT);
                        u.debug("--attempting to open specific conversation on load: ".concat(e, "--")), d.validLayoutId(a, g.dialogType.CHAT) && (d.chatLibrary.chatLayout.urlParseInitialized = !0, d.launchDialog(a))
                    }, d.openSettingsPage = function() {
                        window.location.href = a.getAbsoluteUrl(g.linksLibrary.settingLink)
                    }, d.getAvatars = function(e) {
                        e && 0 < e.length && D.getAvatarHeadshots(e, d.chatLibrary.friendsDict)
                    }, d.getFriendsInfo = function(e) {
                        var r;
                        d.chatLibrary.chatLayout.pageDataLoading && (d.chatLibrary.chatLayout.pageDataLoading = !1), null != e && e.length && (r = [], Z().forEach(e, function(e) {
                            var a = e,
                                t = a.id;
                            r.push(t), a.id = parseInt(t, 10), a.userId = parseInt(t, 10);
                            var i = a.name,
                                e = a.display_name;
                            a.nameForDisplay = null !== _.DisplayNames && void 0 !== _.DisplayNames && _.DisplayNames.Enabled() ? e : i, d.chatLibrary.friendsDict[t] || (d.chatLibrary.friendsDict[t] = a)
                        }), d.getAvatars(r))
                    }, d.initializeChat = function() {
                        d.chatUserDict && d.chatLibrary || d.setup(), l.logSinglePerformanceMark(g.performanceMarkLabels.chatConversationsLoading), d.updateUnreadConversationCount(), d.getUserConversations()
                    }, d.sendChatLandingEvent = function(a, e, t) {
                        try {
                            if (!d.chatLibrary.shouldSendEvents) return;
                            E.incrementCounter(e);
                            var i = null !== (n = null === (r = d.chatUserDict) || void 0 === r ? void 0 : r[t]) && void 0 !== n ? n : {},
                                r = i.hasUnreadMessages,
                                n = (null !== (n = d.chatViewModel) && void 0 !== n ? n : {}).searchTerm,
                                r = {
                                    localTimestamp: Date.now(),
                                    isChatEnabled: d.getIsChatEnabled(),
                                    isFiltered: !!n,
                                    selectedConversationId: E.getConversationIdForAnalytics(i),
                                    hasUnreadMessages: !!r
                                };
                            E.sendEvent(a, r)
                        } catch (e) {
                            u.debug("sendChatLandingEvent for Event ".concat(a, " failed: ").concat(e))
                        }
                    }, d.sendWebChatRenderedEvent = function() {
                        try {
                            var e;
                            if (!d.chatLibrary.shouldSendEvents) return;
                            E.incrementCounter(k.WebChatRenderedWeb);
                            var a = {
                                localTimestamp: Date.now(),
                                isChatEnabled: d.getIsChatEnabled(),
                                isChatOpen: !(null !== (e = d.chatLibrary) && void 0 !== e && null !== (a = e.chatLayout) && void 0 !== a && a.collapsed)
                            };
                            E.sendEvent(O.webChatRendered, a)
                        } catch (e) {
                            u.debug("sendWebChatRenderedEvent failed: ".concat(e))
                        }
                    }, d.sendWebChatConversationsLoadedEvent = function(e) {
                        try {
                            var a, t;
                            if (!d.chatLibrary.shouldSendEvents) return;
                            E.incrementCounter(k.WebChatConversationsLoadedWeb);
                            var n = [],
                                s = [];
                            Z().forEach(e, function(e) {
                                var a = e.id,
                                    t = e.source,
                                    e = e.participant_user_ids;
                                if ("friends" === t) {
                                    if (e) {
                                        var i = V(e);
                                        try {
                                            for (i.s(); !(r = i.n()).done;) {
                                                var r = r.value;
                                                if (r !== d.chatLibrary.userId) {
                                                    s.push(r);
                                                    break
                                                }
                                            }
                                        } catch (e) {
                                            i.e(e)
                                        } finally {
                                            i.f()
                                        }
                                    }
                                } else a && n.push(a)
                            });
                            var i = JSON.stringify(n).replace(/"/g, ""),
                                i = {
                                    localTimestamp: Date.now(),
                                    isChatOpen: !(null !== (a = d.chatLibrary) && void 0 !== a && null !== (t = a.chatLayout) && void 0 !== t && t.collapsed),
                                    conversationIds: i,
                                    friendsConversationIds: JSON.stringify(s)
                                };
                            E.sendEvent(O.webChatConversationsLoaded, i)
                        } catch (e) {
                            u.debug("sendWebChatConversationsLoaded failed: ".concat(e))
                        }
                    }, d.initializeEvents = function() {
                        Z().element(i).bind("resize", function() {
                            var e;
                            !d.chatLibrary.chatLayout.resizing && (0 < d.chatLibrary.dialogIdList.length || 0 < d.chatLibrary.minimizedDialogIdList.length) && (d.chatLibrary.chatLayout.resizing = !0, A(), d.dialogsOverflowWindow() || (e = r.innerWidth(), d.chatLibrary.chatLayout.numberOfDialogs < d.chatLibrary.chatLayout.availableNumberOfDialogs && e > g.chatLayout.thresholdMobile) ? (u.debug(" ------- need to resize -------------- "), d.onResize()) : d.chatLibrary.chatLayout.resizing = !1)
                        }), d.$on("Roblox.Chat.destroyChatCookie", function() {
                            n.removeFromStorage(n.storageDictionary.dialogIdList, d.chatLibrary.cookieOption), n.removeFromStorage(n.storageDictionary.dialogDict, d.chatLibrary.cookieOption), n.removeFromStorage(n.storageDictionary.dialogsLayout, d.chatLibrary.cookieOption), n.removeFromStorage(n.storageDictionary.chatBarLayout, d.chatLibrary.cookieOption), n.removeFromStorage(n.storageDictionary.chatFriendsListReloadTime), e.removeLocalStorage(d.chatLibrary.dialogLocalStorageName), I.clearLocalStorage()
                        }), d.$on("Roblox.Chat.LoadUnreadConversationCount", function() {
                            d.updateUnreadConversationCount()
                        }), r.bind("Roblox.Chat.StartChat", function(e, a) {
                            d.startSpecificConversationFromUserId(a.userId)
                        })
                    }, d.initializeServices = function(e) {
                        o.setParams(), c.setParams(e), v.setParams(_.EnvironmentUrls.gamesApi), I.setStorageParams(e)
                    }, d.initializeLayoutLibrary = function() {
                        var e = P.thumbnailTypes,
                            a = P.avatarHeadshotSize;
                        d.chatLibrary.layoutLibrary = {
                            thumbnailTypes: e,
                            avatarHeadshotSize: a
                        }
                    }, d.initializeChatLibrary = function(e, a) {
                        var t = _.EnvironmentUrls.domain;
                        d.chatLibrary.isWebChatSettingsMigrationEnabled = e.isWebChatSettingsMigrationEnabled, d.chatLibrary.chatLayout.chatEnabledByPrivacySettingTypes = g.chatEnabledByPrivacySettingTypes, d.chatLibrary.chatLayout.whoCanChatWithMeInAppTypes = g.whoCanChatWithMeInAppTypes, d.chatLibrary.isWebChatSettingsMigrationEnabled ? d.chatLibrary.chatLayout.whoCanChatWithMeInApp = null === (a = a.whoCanChatWithMeInApp) || void 0 === a ? void 0 : a.currentValue : d.chatLibrary.chatLayout.isChatEnabledByPrivacySetting = e.isChatEnabledByPrivacySetting, d.chatLibrary.chatLayout.isChatEnabled = e.isChatEnabled, d.chatLibrary.chatLayout.languageForPrivacySettingUnavailable = e.languageForPrivacySettingUnavailable, d.chatLibrary.chatLayout.playTogetherGameCardsEnabled = e.isPlayTogetherForGameCardsEnabled, d.chatLibrary.cookieOption = {
                            domain: t,
                            path: "/",
                            expires: null
                        }, d.chatLibrary.currentTabTitle = i.document.title, d.chatLibrary.dialogLocalStorageName = m.dialogLocalStorageNamePrefix + t, d.chatLibrary.domain = t, d.chatLibrary.isUserUnder13 = _.CurrentUser.isUnder13, d.chatLibrary.maxConversationTitleLengthInput = e.maxConversationTitleLength, d.chatLibrary.partyChromeDisplayTimeStampInterval = e.partyChromeDisplayTimeStampInterval, d.chatLibrary.quotaOfGroupChatMembers = e.numberOfMembersForPartyChrome - 1, d.chatLibrary.screenHeight = window.screen ? window.screen.height : 0, d.chatLibrary.signalRDisconnectionResponseInMilliseconds = e.signalRDisconnectionResponseInMilliseconds, d.chatLibrary.typingInChatAsSenderThrottleMs = e.typingInChatFromSenderThrottleMs, d.chatLibrary.typingInChatForReceiverExpirationMs = e.typingInChatForReceiverExpirationMs, d.chatLibrary.userId = parseInt(_.CurrentUser.userId), d.chatLibrary.username = _.CurrentUser.name;
                        var t = h.eventActions.Chat;
                        t += ": ".concat(h.getUserAgent()), d.chatLibrary.googleAnalyticsEvent = {
                            category: h.eventCategories.JSErrors,
                            action: t
                        }, d.chatLibrary.eventStreamParams = J({}, g.eventStreamParams);
                        t = null !== (t = e.webChatEventSampleRate) && void 0 !== t ? t : 0;
                        d.chatLibrary.shouldSendEvents = 100 * Math.random() <= t, d.chatLibrary.relativeValueToRecordUiPerformance = e.relativeValueToRecordUiPerformance, d.chatLibrary.isUsingCacheToLoadFriendsInfoEnabled = e.isUsingCacheToLoadFriendsInfoEnabled, d.chatLibrary.cachedDataFromLocalStorageExpirationMS = e.cachedDataFromLocalStorageExpirationMS, d.chatLibrary.shouldRespectConversationHasUnreadMessageToMarkAsRead = e.shouldRespectConversationHasUnreadMessageToMarkAsRead, d.chatLibrary.isTrustedCommsWebEnabled = e.isTrustedCommsWebEnabled, d.initializeLayoutLibrary()
                    }, d.getIsChatEnabled = function() {
                        return g.getIsChatEnabled(d.chatLibrary)
                    }, d.initializeChatViewModel = function() {
                        d.chatViewModel = J({}, m.chatViewModel)
                    }, d.bootstrapAllInitialization = function(e, a) {
                        d.initializeChatViewModel(), d.initializeChatLibrary(e, a), d.initializeServices(e), d.initializeRealTimeSubscriptionsForChatPrivacySetting(), d.initializePresetData(), d.initializeChatBar(), d.getIsChatEnabled() && (d.chatLibrary.chatLayout.pageDataLoading = !0, d.initializeChat(), d.initializeRealTimeSubscriptionsForChat()), d.chatLibrary.chatLayout.pageInitializing && (d.chatLibrary.chatLayout.pageInitializing = !1), d.sendWebChatRenderedEvent()
                    }, d.initialize = function() {
                        d.setup(), d.initializeEvents(), d.chatLibrary.chatLayout.pageInitializing = !0, o.getMetaData().then(function(a) {
                            return a.isWebChatSettingsMigrationEnabled ? w.getChatUserSettings().then(function(e) {
                                return {
                                    metadataResponse: a,
                                    userSettingsResponse: e,
                                    isWebChatSettingsMigrationEnabled: a.isWebChatSettingsMigrationEnabled
                                }
                            }).catch(function(e) {
                                u.debug(e)
                            }) : a
                        }).then(function(e) {
                            e.isWebChatSettingsMigrationEnabled ? d.bootstrapAllInitialization(e.metadataResponse, e.userSettingsResponse) : d.bootstrapAllInitialization(e, {})
                        }).catch(function(e) {
                            u.debug(e)
                        }), S.getContactsMetaData().then(function() {}).catch(function(e) {
                            u.debug(e)
                        })
                    }, d.initialize()
                }
                r.$inject = ["$scope", "$window", "$document", "$timeout", "$interval", "$log", "chatService", "messageService", "chatUtility", "chatClientStorageUtilityService", "localStorageService", "performanceService", "messageUtility", "googleAnalyticsEventsService", "urlService", "dialogAttributes", "libraryInitialization", "gameService", "playTogetherService", "pinGameService", "presenceLayout", "resources", "storageService", "usersService", "conversationsUtility", "contactsService", "thumbnailConstants", "usersPresenceService", "userProfilesService", "analyticsService", "eventNames", "diagActionList", "userSettingsService"], t.Z.controller("chatController", r), a.default = r
            },
            4978: function(e, a, t) {
                "use strict";
                t.r(a);
                t = t(9472);

                function i(e, a) {
                    var t = e.dialogData.initiator,
                        i = e.chatLibrary.userId;
                    e.canConversationRemoveMember = function() {
                        return e.dialogData.dialogType !== e.dialogType.CHAT && (t && t.id === i && !e.dialogData.isUserPending)
                    }
                }
                i.$inject = ["$scope", "$log"], t.Z.controller("detailsController", i), a.default = i
            },
            9443: function(e, a, t) {
                "use strict";
                t.r(a);
                var v = t(792),
                    i = t(5734),
                    f = t.n(i),
                    t = t(9472);

                function n(a, e) {
                    var t, i = Object.keys(a);
                    return Object.getOwnPropertySymbols && (t = Object.getOwnPropertySymbols(a), e && (t = t.filter(function(e) {
                        return Object.getOwnPropertyDescriptor(a, e).enumerable
                    })), i.push.apply(i, t)), i
                }

                function b(i) {
                    for (var e = 1; e < arguments.length; e++) {
                        var r = null != arguments[e] ? arguments[e] : {};
                        e % 2 ? n(Object(r), !0).forEach(function(e) {
                            var a, t;
                            a = i, e = r[t = e], t in a ? Object.defineProperty(a, t, {
                                value: e,
                                enumerable: !0,
                                configurable: !0,
                                writable: !0
                            }) : a[t] = e
                        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(i, Object.getOwnPropertyDescriptors(r)) : n(Object(r)).forEach(function(e) {
                            Object.defineProperty(i, e, Object.getOwnPropertyDescriptor(r, e))
                        })
                    }
                    return i
                }

                function r(l, c, i, d, t, r, n, u, a, s, g, p, o, h, y) {
                    l.removeFromConversation = function(a, t) {
                        i.removeFromConversation(l.chatLibrary.userId, a).then(function(e) {
                            e && e.status === d.resultType.SUCCESS && l.chatLibrary.chatLayoutIds && -1 < l.chatLibrary.chatLayoutIds.indexOf(t) && (l.chatLibrary.conversationsDict[a].remove = !0, l.closeDialog({
                                layoutId: t
                            }))
                        })
                    }, l.sendPerformanceData = function(e) {
                        Math.random() < l.chatLibrary.relativeValueToRecordUiPerformance && (e = e.startSendingTime, e = (new Date).getTime() - e, i.sendPerformanceData(a.performanceMeasurements.messageSend, e))
                    };

                    function m(s, o) {
                        i.sendMessage(l.dialogData.id, s.rawContent).then(function(e) {
                            var a;
                            l.sendConversationMessageSentEvent(e, o), !e || (a = e.data) && (s.sendingMessage = !1, s.canResend = !1, l.sendPerformanceData(s), a.status !== d.resultType.SUCCESS ? (s.sendMessageHasError = !0, s.error = d.errorMessages.default, a.status === d.resultType.MODERATED ? (s.error = d.errorMessages.messageContentModerated, s.content = d.hashOutContent(s.content), d.sanitizeMessage(s), s.hasLinkCard && s.linkCardMessages.forEach(function(e) {
                                e.isCard || (e.content = d.hashOutContent(e.content))
                            })) : s.canResend = !0) : (e = a.content, s.sendMessageHasError = !1, f().isUndefined(l.dialogData.messagesDict) && (l.dialogData.messagesDict = {}), s.id = a.id, s.created_at = a.created_at, t.buildTimeStamp(s, l.dialogData), t.buildDisplayMessage(s), s.resetClusterMessage = !0, d.sanitizeMessage(a), s.content = a.content, s.pieces = a.pieces, s.type = g.messageTypes.user, s.moderation_type = a.moderation_type, t.setClusterMaster(l.dialogData, s), s.hasLinkCard && s.rawContent !== e && (a.hasLinkCard ? (u.fetchDataForLinkCard([a], l.chatLibrary), s.linkCardMessages = a.linkCardMessages) : s.hasLinkCard = !1), l.dialogData.messagesDict[a.id] = s))
                        }, function(e) {
                            c.debug(" ------ sendMessage error -------"), s.sendingMessage = !1, s.sendMessageHasError = !0, s.canResend = !0;
                            var a, t, i, r, n = e.errors;
                            n && (a = d.sendMessageErrorCode.textTooLong, t = (r = d.errorMessages).textTooLong, i = r.sendingMessagesTooQuickly, e = r.sendMessageConflict, n.length && (n = (r = n[0] || {}).code, r.message === a ? s.error = t : n === p.tooManyAttempts ? s.error = i : n === p.conflict && (s.canResend = !1, s.error = e, l.sendConversationMessageSentEvent({
                                data: {
                                    status: "Conflict"
                                }
                            }, o))))
                        })
                    }
                    l.toggleDetails = function() {
                        l.dialogLayout.details.isEnabled = !l.dialogLayout.details.isEnabled, l.saveIntoDialogsLayout()
                    }, l.toggleConversationEditor = function() {
                        l.dialogLayout.details.isConversationTitleEditorEnabled = !l.dialogLayout.details.isConversationTitleEditorEnabled, l.dialogLayout.focusMeEnabled = l.dialogLayout.details.isConversationTitleEditorEnabled, l.saveIntoDialogsLayout()
                    }, l.toggleAddFriends = function() {
                        l.dialogLayout.details.isAddFriendsEnabled = !l.dialogLayout.details.isAddFriendsEnabled, l.dialogLayout.details.isAddFriendsEnabled ? l.addFriends() : l.dialogData.addMoreFriends = !1, l.getLimitLinkNameForMemberList(), l.saveIntoDialogsLayout()
                    }, l.getLimitLinkNameForMemberList = function(e) {
                        var a = l.dialogData.userIds.length;
                        l.dialogData.selectedUserIds && (a += l.dialogData.selectedUserIds.length), e && (a -= e), l.dialogLayout.memberDisplay.linkName = l.dialogLayout.memberDisplay.isAll ? l.dialogLayout.memberDisplay.seeLessLink : "".concat(l.dialogLayout.memberDisplay.seeMoreLink, " (").concat(a - l.dialogLayout.memberDisplay.defaultLimit, ")")
                    }, l.toggleMemberList = function() {
                        l.dialogLayout.memberDisplay.isAll = !l.dialogLayout.memberDisplay.isAll, l.dialogLayout.memberDisplay.limitNumber = l.dialogLayout.memberDisplay.isAll ? l.dialogData.userIds.length : l.dialogLayout.memberDisplay.defaultLimit, l.getLimitLinkNameForMemberList()
                    }, l.toggleFriendsMenu = function(e, a) {
                        a && l.dialogLayout.details.friendIdForMenuOn === e ? (l.dialogLayout.details.friendMenuAction = {}, l.dialogLayout.details.friendIdForMenuOn = null) : e && !a && (l.dialogLayout.details.friendMenuAction[e] = !l.dialogLayout.details.friendMenuAction[e], l.dialogLayout.details.friendIdForMenuOn = e)
                    }, l.updatePopoverParams = function() {
                        var e = l.dialogData,
                            a = e.id,
                            t = e.playTogetherIds,
                            i = l.dialogLayout.togglePopoverParams,
                            r = i.dialogSelectorPrefix,
                            n = i.popoverTriggerSelectorPrefix,
                            e = i.dialogTriggerClassPrefix,
                            i = l.dialogLayout.togglePopoverParams,
                            t = {
                                dialogSelect: r + a,
                                triggerSelector: n + a,
                                dialogTriggerClassSelector: e + a,
                                isOpen: !!t && 0 < t.length,
                                isFirstTimeOpen: !0
                            };
                        Object.assign(i, t)
                    }, l.dialogParams = b({}, d.dialogParams), l.userPresenceTypes = d.userPresenceTypes, l.dialogData.messageForSend = "", l.dialogLayout.scrollbarElm = d.getScrollBarSelector(l.dialogData, d.scrollBarType.MESSAGE), l.dialogLayout.listenToScrollInitialized = !1, l.friendsScrollbarElm = d.getScrollBarSelector(l.dialogData, d.scrollBarType.FRIENDSELECTION), l.updatePopoverParams(), l.updateDialog = function() {
                        return c.debug("---- updateDialog callback ---- Scrollbars updated"), l.dialogLayout.IsdialogContainerVisible || (f().element(l.dialogLayout.scrollbarElm).find(".mCustomScrollBox").addClass("dialog-visible"), l.dialogLayout.IsdialogContainerVisible = !0), !1
                    }, l.buildNewMessage = function(e) {
                        return {
                            read: !0,
                            content: e,
                            rawContent: e,
                            sender_user_id: l.chatLibrary.userId,
                            sendingMessage: !0,
                            sendMessageHasError: !1,
                            startSendingTime: (new Date).getTime(),
                            type: "user"
                        }
                    }, l.sendMessage = function() {
                        var e, a;
                        0 < l.dialogData.messageForSend.length && (e = l.buildNewMessage(l.dialogData.messageForSend), d.sanitizeMessage(e), u.fetchDataForLinkCard([e], l.chatLibrary), l.dialogData.messageForSend = "", f().isUndefined(l.dialogData.chatMessages) && (l.dialogData.chatMessages = []), t.setClusterMaster(l.dialogData, e), l.dialogData.displayMessage = e, l.dialogData.dialogType === d.dialogType.FRIEND ? (a = e, l.openConversationFromFriendId().then(function(e) {
                            e = e && e.id;
                            if (!e) return a.canResend = !1, a.sendMessageHasError = !0, void(a.error = d.errorMessages.default);
                            i.sendMessage(e, a.rawContent).then(function(e) {
                                l.sendConversationMessageSentEvent(e, !1)
                            })
                        }).catch(function() {
                            a.canResend = !1, a.sendMessageHasError = !0, a.error = d.errorMessages.default
                        })) : m(e))
                    }, l.resendMessage = function(e) {
                        m(e, !0)
                    }, l.keyPressEnter = function() {
                        l.sendMessage(), l.dialogLayout.typing.isTypingAsSender && (l.dialogLayout.typing.lastTimeTypingAsSender = null, l.dialogLayout.typing.isTypingAsSender = !1)
                    }, l.typing = function(e, a, t) {
                        l.dialogData.dialogType !== d.dialogType.FRIEND && a && (e.which !== n.enter && (e = t || (new Date).getTime(), (!(t = l.dialogLayout.typing).lastTimeTypingAsSender || e - t.lastTimeTypingAsSender > l.chatLibrary.typingInChatAsSenderThrottleMs) && (t.lastTimeTypingAsSender = e, t.isTypingAsSender = !0, i.updateUserTypingStatus(l.dialogData.id, !0))), l.toggleDialogFocusStatus(!0))
                    }, l.abuseReport = function(e, a) {
                        l.dialogLayout.isConfirmationOn = !0, e && (l.dialogLayout.userIdForAbuseReport = e), a && l.dialogLayout.userIdForAbuseReport && (a = s("formatString")(d.chatLayout.abuseReportUrl, {
                            userId: l.dialogLayout.userIdForAbuseReport,
                            location: escape(window.location),
                            conversationId: l.dialogData.id
                        }), a = v.Endpoints ? v.Endpoints.getAbsoluteUrl(a) : a, v.AbuseReportDispatcher ? v.AbuseReportDispatcher.triggerUrlAction(a) : window.location.href = a, l.dialogLayout.userIdForAbuseReport = null, l.dialogLayout.isConfirmationOn = !1), l.saveIntoDialogsLayout()
                    }, l.leaveGroupChat = function(e) {
                        e ? (l.chatLibrary.conversationsDict[l.dialogData.id].remove = !0, l.removeFromConversation(l.dialogData.id, l.dialogData.layoutId), l.resetConfirmDialog()) : (l.dialogLayout.confirmDialog.isOpen = !0, e = r.negativeAction.leaveChatGroup, l.dialogLayout.confirmDialog.title = e.title, l.dialogLayout.confirmDialog.headerTitle = e.headerTitle, l.dialogLayout.confirmDialog.btnName = e.btnName, l.dialogLayout.confirmDialog.cancelBtnName = e.cancelBtnName, l.dialogLayout.confirmDialog.type = e.type)
                    }, l.openLearnMorePage = function() {
                        window.open(d.linksLibrary.trustedCommsLearnMoreLink, "_blank")
                    }, l.addFriends = function() {
                        l.dialogData.addMoreFriends = !0, 0 < l.chatLibrary.friendIds.length && l.updateFriends(), l.dialogData.scrollBarType = d.scrollBarType.FRIENDSELECTION
                    }, l.viewParticipants = function() {
                        l.dialogLayout.lookUpMembers = !l.dialogLayout.lookUpMembers
                    }, l.toggleGroupNameEditor = function() {
                        l.dialogLayout.renameEditor.isEnabled = !l.dialogLayout.renameEditor.isEnabled, l.dialogLayout.renameEditor.hasFocus = !l.dialogLayout.renameEditor.hasFocus, l.updateDialogStyle(), l.dialogLayout.focusMeEnabled = !l.dialogLayout.renameEditor.isEnabled
                    }, l.renameTitle = function() {
                        var a = l.dialogData.title;
                        i.renameGroupConversation(l.dialogData.id, l.dialogData.name).then(function(e) {
                            if (e) {
                                switch (e.status) {
                                    case d.resultType.MODERATED:
                                        t.buildSystemMessage(d.notificationType.conversationTitleModerated, l.dialogData, !0), d.updateConversationTitle(l.dialogData, a);
                                        break;
                                    case d.resultType.SUCCESS:
                                        d.updateConversationTitle(l.dialogData, e.name)
                                }
                                l.toggleConversationEditor()
                            }
                        })
                    }, l.removeMember = function(e, a) {
                        a ? (l.resetConfirmDialog(), l.getLimitLinkNameForMemberList(1), i.removeFromConversation(e, l.dialogData.id).then(function() {
                            data && data.status === d.resultType.SUCCESS && l.isOverLoaded()
                        })) : (l.dialogLayout.confirmDialog.isOpen = !0, a = r.negativeAction.removeUser, l.dialogLayout.confirmDialog.title = a.title, l.dialogLayout.confirmDialog.headerTitle = a.headerTitle, l.dialogLayout.confirmDialog.btnName = a.btnName, l.dialogLayout.confirmDialog.cancelBtnName = a.cancelBtnName, l.dialogLayout.confirmDialog.type = a.type, l.dialogLayout.confirmDialog.params = {
                            userId: e
                        })
                    }, l.resetConfirmDialog = function() {
                        Object.assign(l.dialogLayout.confirmDialog, {
                            isOpen: !1,
                            title: "",
                            btnName: "",
                            type: "",
                            params: {}
                        })
                    }, l.confirmCallBack = function() {
                        var e = l.dialogLayout.confirmDialog;
                        switch (e.type) {
                            case r.negativeAction.removeUser.type:
                                l.removeMember(e.params.userId, !0);
                                break;
                            case r.negativeAction.leaveChatGroup.type:
                                l.leaveGroupChat(!0)
                        }
                    }, l.updateDialogHeader = function(e) {
                        l.dialogLayout.collapsed && (l.dialogLayout.hoverOnCollapsed = e)
                    }, l.sendConversationMessageSentEvent = function(e, a) {
                        try {
                            var t;
                            if (!l.chatLibrary.shouldSendEvents) return;
                            i = e ? e.data ? e.data.status || "NoMessageStatus" : "NoResponseBody" : "NoResponse";
                            var i = {
                                messageId: null == e || null === (t = e.data) || void 0 === t ? void 0 : t.id,
                                messageSentResult: i,
                                recipientIds: JSON.stringify((null === (i = l.dialogData) || void 0 === i ? void 0 : i.candidatePlayerIds) || []),
                                isRetry: a || !1
                            };
                            l.sendConversationEvent(h.conversationMessageSent, y.ConversationMessageSentWeb, i)
                        } catch (e) {
                            c.debug("sendConversationMessageSentEvent failed: ".concat(e))
                        }
                    }, l.sendConversationEvent = function(a, e, t) {
                        var i = o.getConversationIdForAnalytics(l.dialogData);
                        try {
                            if (!l.chatLibrary.shouldSendEvents) return;
                            o.incrementCounter(e);
                            var r = b({
                                localTimestamp: Date.now(),
                                conversationId: i
                            }, t);
                            o.sendEvent(a, r)
                        } catch (e) {
                            c.debug("sendConversationEvent for Event ".concat(a, " and Conversation ").concat(i, " failed: ").concat(e))
                        }
                    }, l.sendWebChatConversationRenderedEvent = function() {
                        var a = o.getConversationIdForAnalytics(l.dialogData);
                        try {
                            if (!l.chatLibrary.shouldSendEvents) return;
                            o.incrementCounter(y.WebChatConversationRenderedWeb);
                            var e = {
                                localTimestamp: Date.now(),
                                conversationId: a,
                                isDialogOpen: !(null !== (e = l.dialogLayout) && void 0 !== e && e.collapsed),
                                conversationSource: null === (e = l.dialogData) || void 0 === e ? void 0 : e.source,
                                moderationType: null === (e = l.dialogData) || void 0 === e ? void 0 : e.moderationType,
                                userPendingStatus: null === (e = l.dialogData) || void 0 === e ? void 0 : e.userPendingStatus
                            };
                            o.sendEvent(h.webChatConversationRendered, e)
                        } catch (e) {
                            c.debug("sendWebChatConversationRenderedEvent for Conversation ".concat(a, " failed: ").concat(e))
                        }
                    }, l.isDialogMainContainerHidden = function() {
                        return l.dialogData.addMoreFriends || l.dialogLayout.details.isEnabled
                    }, l.shouldShowPendingState = function() {
                        return l.chatLibrary.isTrustedCommsWebEnabled && l.dialogData.isUserPending && !(l.isDialogMainContainerHidden() || l.dialogLayout.isConfirmationOn)
                    }, l.dialogData.dialogType === d.dialogType.FRIEND || l.dialogData.isUserPending || i.getMessages(l.dialogData.id, null, l.dialogParams.pageSizeOfGetMessages).then(function(e) {
                        var a = e.messages;
                        a && 0 < a.length ? (l.dialogParams.getMessagesNextCursor = e.next_cursor, l.dialogData.chatMessages = [], l.dialogData.messagesDict = {}, t.processMessages(l.chatLibrary, l.dialogData, a, l.chatLibrary.friendsDict), u.fetchDataForLinkCard(a, l.chatLibrary), l.dialogData.scrollBarType = d.scrollBarType.MESSAGE, e.next_cursor || (l.dialogParams.loadMoreMessages = !1)) : (l.dialogData.scrollBarType = d.scrollBarType.MESSAGE, l.updateDialog())
                    }), l.$on("elastic:resize", function(e, a, t, i) {
                        c.debug("---- oldHeight -----".concat(t, "---- newHeight -----").concat(i)), t !== i && (e.preventDefault(), e.stopPropagation(), d.setResizeInputLayout(l.chatLibrary, i, l.dialogData, l.dialogLayout))
                    }), l.init = function() {
                        l.getLimitLinkNameForMemberList(), l.sendWebChatConversationRenderedEvent()
                    }, l.init()
                }
                r.$inject = ["$scope", "$log", "chatService", "chatUtility", "messageService", "dialogAttributes", "keyCode", "gameService", "resources", "$filter", "messageHelper", "httpStatusCodes", "analyticsService", "eventNames", "diagActionList"], t.Z.controller("dialogController", r), a.default = r
            },
            6822: function(e, a, t) {
                "use strict";
                t.r(a);
                t = t(9472);

                function i(t, e, i, r) {
                    t.isGameIconAvailable = function() {
                        return t.isPinOrActiveGameAvailable()
                    }, t.isPinOrActiveGameAvailable = function() {
                        return t.dialogData.placeForShown && t.dialogData.placeForShown.universeId && t.dialogData.placeForShown.rootPlaceId
                    }, t.openGameList = function() {
                        var e = i.eventStreamParams.openGameListInPlayTogether,
                            a = {
                                conversationId: t.dialogData.id
                            };
                        r.sendEventWithTarget(e, i.eventStreamParams.actions.click, a)
                    }, t.init = function() {
                        t.gamesListTemplateUrl = i.templates.gamesList
                    }, t.init()
                }
                i.$inject = ["$scope", "$log", "resources", "eventStreamService"], t.Z.controller("dialogHeaderController", i), a.default = i
            },
            9226: function(e, a, t) {
                "use strict";
                t.r(a);
                t = t(9472);

                function i(a, e, t, i) {
                    a.canRenderMessage = function(e) {
                        return !!e.sendingMessage || (e.isSystemMessage || t.isMessageTypeLegal(e))
                    }, a.isMessageOutgoingTrustedComms = function(e) {
                        return a.chatLibrary.isTrustedCommsWebEnabled && e && e.sender_user_id === a.chatLibrary.userId && e.moderation_type === i.moderationType.TRUSTED_COMMS
                    }
                }
                i.$inject = ["$scope", "$log", "messageUtility", "chatUtility"], t.Z.controller("dialogMessagesController", i), a.default = i
            },
            8984: function(e, a, t) {
                "use strict";
                t.r(a);
                var i = t(5734),
                    l = t.n(i),
                    t = t(9472);

                function n(a, e) {
                    var t, i = Object.keys(a);
                    return Object.getOwnPropertySymbols && (t = Object.getOwnPropertySymbols(a), e && (t = t.filter(function(e) {
                        return Object.getOwnPropertyDescriptor(a, e).enumerable
                    })), i.push.apply(i, t)), i
                }

                function c(i) {
                    for (var e = 1; e < arguments.length; e++) {
                        var r = null != arguments[e] ? arguments[e] : {};
                        e % 2 ? n(Object(r), !0).forEach(function(e) {
                            var a, t;
                            a = i, e = r[t = e], t in a ? Object.defineProperty(a, t, {
                                value: e,
                                enumerable: !0,
                                configurable: !0,
                                writable: !0
                            }) : a[t] = e
                        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(i, Object.getOwnPropertyDescriptors(r)) : n(Object(r)).forEach(function(e) {
                            Object.defineProperty(i, e, Object.getOwnPropertyDescriptor(r, e))
                        })
                    }
                    return i
                }

                function r(n, r, s, o, i) {
                    n.isNewGroupChat = function(e) {
                        return e.dialogType === s.dialogType.NEWGROUPCHAT || e.addMoreFriends && !e.isGroupChat
                    }, n.canAddFriendInExistedConversation = function(e) {
                        return e.addMoreFriends && e.isGroupChat
                    }, n.resetPreviousDialog = function(e, a, t) {
                        n.chatUserDict[e].selectedUserIds = [], n.chatUserDict[e].selectedUsersDict = {}, t.preserved ? n.chatUserDict[e].addMoreFriends = !1 : delete n.chatUserDict[e];
                        var i = n.chatLibrary.dialogIdList.indexOf(e); - 1 < i && !t.preserved ? (n.destroyDialogLayout(e), delete n.chatLibrary.dialogDict[e], t.isDuplicatedConversation ? n.chatLibrary.dialogIdList.splice(i) : (n.chatLibrary.dialogIdList[i] = a, n.chatLibrary.dialogDict[a] = c({}, s.dialogInitValue))) : n.updateDialogList(a, !0)
                    }, n.generateDialog = function(e, a, t) {
                        var i = t.layoutId,
                            r = n.getLayoutId(e.id, a);
                        e.dialogType = a, i !== r ? (n.getUserInfoForConversation(e), e.layoutId = r, n.updateChatViewModel(e, !0), n.resetPreviousDialog(i, r, t)) : (n.getUserInfoForConversation(e), n.updateChatViewModel(e, !0), n.chatLibrary.dialogDict[i].isUpdated = !0, n.chatLibrary.dialogDict[i].updateStatus = s.dialogStatus.REFRESH)
                    }, n.createNewGroupChat = function(e, t) {
                        var i, a;
                        n.newGroupChatLocked || (n.newGroupChatLocked = !0, i = {
                            layoutId: e
                        }, a = t.name, t.addMoreFriends && !t.isGroupChat && (e = t.participants, l().forEach(e, function(e) {
                            e = e.id;
                            e !== n.chatLibrary.userId && (t.selectedUserIds && t.selectedUserIds.indexOf(e) < 0 && t.selectedUserIds.push(e), t.selectedUsersDict[e] = l().copy(n.chatLibrary.friendsDict[e]), t.selectedUsersDict[e].hiddenFromSelection = !0)
                        }), i.preserved = !0, a = ""), r.startGroupConversation(t.selectedUserIds, a).then(function(e) {
                            var a;
                            e.status === s.resultType.SUCCESS && ((a = n.chatLibrary.allConversationLayoutIdsDict[e.id]) ? (i.isDuplicatedConversation = !0, n.resetPreviousDialog(t.layoutId, a, i), n.chatLibrary.dialogIdList.indexOf(a) < 0 && n.launchDialog(a, !0)) : (e.isGroupChat = e.type === s.conversationType.multiUserConversation, o.formatTimestampInConversation(e), n.generateDialog(e, s.dialogType.GROUPCHAT, i))), n.newGroupChatLocked = !1
                        }).catch(function(e) {
                            n.newGroupChatLocked = !1
                        }))
                    }, n.sendInvite = function(e) {
                        i.debug("------------- sendInvite ------------");
                        var a, t = n.chatUserDict[e];
                        t.dialogType !== s.dialogType.CHAT && t.dialogType !== s.dialogType.GROUPCHAT || t.addMoreFriends ? n.canAddFriendInExistedConversation(t) ? r.addToConversation(t.selectedUserIds, t.id).then(function(e) {
                            e && e.status === s.resultType.SUCCESS && (t.addMoreFriends = !1, t.selectedUserIds.forEach(function(e) {
                                t.userIds.indexOf(e) < 0 && t.userIds.push(e)
                            }))
                        }).finally(function() {
                            t.selectedUserIds = [], t.selectedUsersDict = {}
                        }) : n.isNewGroupChat(t) && n.createNewGroupChat(e, t) : (-1 < (e = (a = t.userIds).indexOf(n.chatLibrary.userId)) && a.splice(e, 1), t.selectedUserIds = a)
                    }
                }
                r.$inject = ["$scope", "chatService", "chatUtility", "messageService", "$log"], t.Z.controller("dialogsController", r), a.default = r
            },
            7146: function(e, a, t) {
                "use strict";
                t.r(a);
                var o = t(792),
                    l = t(2222),
                    i = t(5734),
                    c = t.n(i),
                    t = t(9472);

                function n(a, e) {
                    var t, i = Object.keys(a);
                    return Object.getOwnPropertySymbols && (t = Object.getOwnPropertySymbols(a), e && (t = t.filter(function(e) {
                        return Object.getOwnPropertyDescriptor(a, e).enumerable
                    })), i.push.apply(i, t)), i
                }

                function d(i) {
                    for (var e = 1; e < arguments.length; e++) {
                        var r = null != arguments[e] ? arguments[e] : {};
                        e % 2 ? n(Object(r), !0).forEach(function(e) {
                            var a, t;
                            a = i, e = r[t = e], t in a ? Object.defineProperty(a, t, {
                                value: e,
                                enumerable: !0,
                                configurable: !0,
                                writable: !0
                            }) : a[t] = e
                        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(i, Object.getOwnPropertyDescriptors(r)) : n(Object(r)).forEach(function(e) {
                            Object.defineProperty(i, e, Object.getOwnPropertyDescriptor(r, e))
                        })
                    }
                    return i
                }

                function r(s, e, t, a, i, r) {
                    s.dialogLayout.scrollToBottom = !1, s.dialogLayout.IsdialogContainerVisible = !1, s.dialogParams = d({}, e.dialogParams), s.dialogType = d({}, e.dialogType), s.userPresenceTypes = d({}, e.userPresenceTypes), s.friendsScrollbarElm = e.getScrollBarSelector(s.dialogData, e.scrollBarType.FRIENDSELECTION), s.dialogData.scrollBarType = e.scrollBarType.FRIENDSELECTION, s.dialogData.isCreated = !0, s.updateFriendsDictData = function(e) {
                        var r, n, a;
                        null != e && e.length && (r = [], n = [], c().forEach(e, function(e) {
                            var a = e,
                                t = a.id;
                            a.id = parseInt(t, 10);
                            var i = a.name,
                                e = a.display_name;
                            a.nameForDisplay = null !== o.DisplayNames && void 0 !== o.DisplayNames && o.DisplayNames.Enabled() ? e : i, s.chatLibrary.friendsDict[t] || (s.chatLibrary.friendsDict[t] = a, r.push(t)), n.push(t)
                        }), a = [l.UserProfileField.Names.CombinedName], i.watchUserProfiles(n, a).subscribe(function(e) {
                            e.loading, e.error;
                            var a = e.data;
                            Object.keys(a).forEach(function(e) {
                                s.chatLibrary.friendsDict[e] && (s.chatLibrary.friendsDict[e].nameForDisplay = a[e].names.combinedName)
                            })
                        }), s.updateFriends(e), r && 0 < r.length && t.getAvatarHeadshots(r, s.chatLibrary.friendsDict))
                    };
                    0 < s.chatLibrary.friendIds.length && s.updateFriends(), a.getFriendsPresence().then(function(e) {
                        null != e && e.length && s.updateFriendsDictData(e)
                    }, function(e) {
                        console.debug(e)
                    }), s.isOverLoaded()
                }
                r.$inject = ["$scope", "chatUtility", "usersService", "usersPresenceService", "userProfilesService", "$timeout"], t.Z.controller("friendsController", r), a.default = r
            },
            3771: function(e, a, t) {
                "use strict";
                t.r(a), t.d(a, {
                    default: function() {
                        return r
                    }
                });
                var g = t(792),
                    p = t(4720),
                    h = CoreRobloxUtilities,
                    t = t(9472);

                function i(n, t, i, r, s, o, l, c, d, u) {
                    n.isLinkCardAvailableAndParsedByClientSide = function(e) {
                        return !e.isLinkCard && e.isCard
                    }, n.sendEventStream = function(e, a, t) {
                        a = {
                            placeId: a,
                            conversationId: n.dialogData.id
                        };
                        t && (a.joinAttemptId = t), r.sendEventWithTarget(e, n.chatLibrary.eventStreamParams.actions.click, a)
                    }, n.sendLoadLinkCardEvent = function(e) {
                        e = {
                            placeId: e,
                            conversationId: n.dialogData.id
                        };
                        r.sendEventWithTarget(n.chatLibrary.eventStreamParams.loadGameLinkCardInChat, n.chatLibrary.eventStreamParams.actions.render, e)
                    }, n.sendGamePlayEvent = function(e, a) {
                        var t = n.chatLibrary.eventStreamParams.context;
                        r.sendGamePlayEvent(t.gamePlayFromLinkCard, e, void 0, a)
                    }, n.playGame = function(e, a, t) {
                        var i = g.GameLauncher.isJoinAttemptIdEnabled() ? p.uuidService.generateRandomUuid() : void 0,
                            r = n.chatLibrary.eventStreamParams.context;
                        n.sendEventStream(a, e, i), n.sendGamePlayEvent(e, i), t && t.privateServerLinkCode ? s.playPrivateServerGame(e, t.privateServerLinkCode, i, r.gamePlayFromLinkCard) : n.chatLibrary.chatLayout.playTogetherGameCardsEnabled ? s.playTogetherGame(e, n.dialogData.id, i, r.gamePlayFromLinkCard) : s.playRegularGame(e, !1, i, r.gamePlayFromLinkCard)
                    }, n.buyAccess = function(e, a) {
                        var t = n.chatLibrary.placesLibrary[e],
                            e = t.gameIconUrl,
                            t = c("formatString")(a.buyAccess.bodyText(), {
                                placeName: t.placeName,
                                creatorName: t.creatorName,
                                price: t.price
                            }),
                            a = {
                                titleText: a.buyAccess.title,
                                bodyText: t,
                                imageUrl: e,
                                actionButtonShow: !0,
                                actionButtonText: a.buyAccess.yesButtonText,
                                actionButtonClass: a.buyAccess.yesButtonClass,
                                neutralButtonText: a.buyAccess.noButtonText,
                                closeButtonShow: !0
                            };
                        n.dialogLayout.playTogetherButton.isPlayButtonDisabled = !0, o.open(a).result.then(function() {
                            i.debug("--- purchase ---"), n.dialogLayout.playTogetherButton.isPlayButtonDisabled = !1
                        }, function() {
                            i.debug("--- cancel ---"), n.dialogLayout.playTogetherButton.isPlayButtonDisabled = !1
                        })
                    }, n.goToPlaceDetails = function(e, a) {
                        var t = n.chatLibrary.placesLibrary[e],
                            i = {
                                universeId: t.universeId,
                                placeId: e,
                                position: 0,
                                page: n.chatLibrary.eventStreamParams.pageContext.linkCardInChat
                            };
                        n.sendEventStream(a, e);
                        i = "".concat(t.placeUrl, "?").concat(p.urlService.composeQueryString(i));
                        l.location.href = p.urlService.getAbsoluteUrl(i)
                    }, n.play = function(e, a, t) {
                        switch (n.chatLibrary.placesLibrary[e].buttonLayoutForLinkCard.type) {
                            case u.playButtonTypes.play:
                                n.playGame(e, a, t);
                                break;
                            case u.playButtonTypes.buy:
                                n.buyAccess(e, u);
                                break;
                            case u.playButtonTypes.details:
                                n.goToPlaceDetails(e, a)
                        }
                    }, n.pinGame = function(e, a) {
                        e = parseInt(e), a = parseInt(a);
                        var t;
                        n.dialogData.pinGame && n.dialogData.pinGame.rootPlaceId === parseInt(a) || (t = n.chatLibrary.eventStreamParams.pinGameInLinkCard, d.sendPinGameEvent(t, a, n.dialogData), a = {
                            rootPlaceId: a,
                            universeId: e,
                            actorUsername: n.chatLibrary.username,
                            userId: n.chatLibrary.userId,
                            placeName: n.chatLibrary.placesLibrary && n.chatLibrary.placesLibrary[a] ? n.chatLibrary.placesLibrary[a].placeName : "",
                            encodedPlaceName: n.chatLibrary.placesLibrary && n.chatLibrary.placesLibrary[a] ? n.chatLibrary.placesLibrary[a].encodedPlaceName : ""
                        }, d.setPinGameData(n.dialogData, a), d.pinGame(n.dialogData, e), s.buildButtonLayoutPerConversation(n.dialogData, n.chatLibrary.placesLibrary))
                    }, n.sendGameImpressionEvent = function(e) {
                        var a;
                        n.gameImpressionSent || (a = n.chatLibrary.eventStreamParams, n.gameImpressionSent = !0, e = {
                            page: a.pageContext.linkCardInChat,
                            rootPlaceIds: JSON.stringify([e.rootPlaceId]),
                            universeIds: JSON.stringify([e.universeId]),
                            absPositions: JSON.stringify([0]),
                            sortPos: 0
                        }, r.sendEventWithTarget(a.gameImpressions, a.actions.render, e))
                    }, n.enqueueGameImpressionEvent = function(e) {
                        clearTimeout(n.gameImpressionTimeout), n.gameImpressionTimeout = setTimeout(function() {
                            n.sendGameImpressionEvent(e)
                        }, 500)
                    }, n.observeGameImpressions = function(a) {
                        null !== (e = n.visibilityObserver) && void 0 !== e && e.disconnect();
                        var e = h.elementVisibilityService.observeVisibility({
                            element: t[0],
                            threshold: .5
                        }, function(e) {
                            e ? n.enqueueGameImpressionEvent(a) : clearTimeout(n.gameImpressionTimeout)
                        });
                        n.visibilityObserver = {
                            disconnect: e
                        }
                    }, n.$on("$destroy", function() {
                        var e;
                        null !== (e = n.visibilityObserver) && void 0 !== e && e.disconnect(), clearTimeout(n.gameImpressionTimeout)
                    })
                }
                i.$inject = ["$scope", "$element", "$log", "eventStreamService", "gameService", "modalService", "$window", "$filter", "pinGameService", "gameLayout"], t.Z.controller("linkCardController", i);
                var r = i
            },
            7910: function(e, a, t) {
                "use strict";
                t.r(a);
                var i = t(5734),
                    r = t.n(i),
                    t = t(9472);

                function n(e, a) {
                    e.pinGameLayout = r().copy(a), e.linkCardMessages = e.message.linkCardMessages
                }
                n.$inject = ["$scope", "pinGameLayout"], t.Z.controller("linkCardMessagesController", n), a.default = n
            },
            2696: function(e, a, t) {
                "use strict";
                t.r(a);
                var y = t(792),
                    m = t(4720),
                    t = t(9472);

                function i(o, i, t, r, n, l, s, c, d, u, g, p, h) {
                    o.sendEventStream = function(e, a, t, i) {
                        a = {
                            placeId: a,
                            conversationId: o.playTogether.id
                        };
                        t && (a.gameInstanceId = t), i && (a.joinAttemptId = i), s.sendEventWithTarget(e, o.chatLibrary.eventStreamParams.actions.click, a)
                    }, o.sendGamePlayEvent = function(e, a) {
                        var t = o.chatLibrary.eventStreamParams.context;
                        s.sendGamePlayEvent(t.gamePlayFromPlayTogether, e, void 0, a)
                    }, o.buyAccess = function(e, a) {
                        var t = o.chatLibrary.eventStreamParams.clickBuyButtonInPlayTogether;
                        o.sendEventStream(t, e), o.dialogLayout.playTogetherButton.isPlayButtonDisabled = !0;
                        t = o.chatLibrary.placesLibrary[e], e = t.gameIconUrl, t = a.buyAccess.bodyText(t.encodedPlaceName, t.encodedCreatorName, t.price), a = {
                            titleText: a.buyAccess.title,
                            bodyText: t,
                            imageUrl: e,
                            actionButtonShow: !0,
                            actionButtonText: a.buyAccess.yesButtonText,
                            actionButtonClass: a.buyAccess.yesButtonClass,
                            neutralButtonText: a.buyAccess.noButtonText,
                            closeButtonShow: !0
                        };
                        r.open(a).result.then(function() {
                            i.debug("--- purchase ---"), o.dialogLayout.playTogetherButton.isPlayButtonDisabled = !1
                        }, function() {
                            i.debug("--- cancel ---"), o.dialogLayout.playTogetherButton.isPlayButtonDisabled = !1
                        })
                    }, o.goToPlaceDetails = function(e) {
                        var a = o.chatLibrary.eventStreamParams.clickViewDetailsButtonInPlayTogether;
                        o.sendEventStream(a, e), t.location.href = m.urlService.getAbsoluteUrl(o.chatLibrary.placesLibrary[e].placeUrl)
                    }, o.joinGame = function(e) {
                        o.chatLibrary.eventStreamParams.clickJoinButtonInPlayTogether;
                        var a = o.playTogether.playTogetherDict[e].placeId,
                            t = o.playTogether.playTogetherDict[e].gameInstanceId,
                            i = o.playTogether.playTogetherDict[e].playerIds ? o.playTogether.playTogetherDict[e].playerIds[0] : null,
                            i = h.buildPlayGameProperties(e, a, t, i),
                            e = {
                                placeId: e,
                                conversationId: o.playTogether.id
                            };
                        t && (e.gameInstanceId = t);
                        e = {
                            eventName: o.chatLibrary.eventStreamParams.clickJoinButtonInPlayTogether,
                            ctx: o.chatLibrary.eventStreamParams.actions.click,
                            properties: e,
                            gamePlayIntentEventCtx: o.chatLibrary.eventStreamParams.context.gamePlayFromPlayTogether
                        };
                        h.launchGame(i, e)
                    }, o.playGame = function(e, a) {
                        var t = y.GameLauncher.isJoinAttemptIdEnabled() ? m.uuidService.generateRandomUuid() : void 0,
                            i = o.chatLibrary.eventStreamParams.context.gamePlayFromPlayTogether,
                            r = o.chatLibrary.eventStreamParams.clickPlayButtonInPlayTogether;
                        o.sendEventStream(r, e, void 0, t), o.sendGamePlayEvent(e, t), n.playTogetherGame(e, a, t, i)
                    }, o.joinGameFromPlayTogether = function(e) {
                        e = parseInt(e);
                        var a = o.playTogether.placeButtonLayout[e].type,
                            t = o.playTogether.id;
                        switch (a) {
                            case g.playButtonTypes.join:
                                o.joinGame(e);
                                break;
                            case g.playButtonTypes.play:
                                o.playGame(e, t);
                                break;
                            case g.playButtonTypes.buy:
                                o.buyAccess(e, g);
                                break;
                            case g.playButtonTypes.details:
                                o.goToPlaceDetails(e)
                        }
                    }, o.toggleActiveGameList = function() {
                        o.playTogetherLayout.activeGamesList.isCollapsed = !o.playTogetherLayout.activeGamesList.isCollapsed, o.playTogetherLayout.activeGamesList.isCollapsed ? (o.playTogetherLayout.activeGamesList.toggleMenuText = o.playTogetherLayout.activeGamesList.showMoreText, o.playTogetherLayout.activeGamesList.limitNumber = o.playTogetherLayout.activeGamesList.minNumberForFit) : (o.playTogetherLayout.activeGamesList.toggleMenuText = o.playTogetherLayout.activeGamesList.showLess, o.playTogetherLayout.activeGamesList.limitNumber = o.playTogetherLayout.numberOfActiveGames)
                    }, o.hasPinGameAndActiveGames = function() {
                        return !(!o.hasActiveGames() || !o.playTogether.pinGame) && (1 !== o.playTogether.playTogetherIds.length || o.playTogether.playTogetherIds[0] !== o.playTogether.pinGame.rootPlaceId)
                    }, o.hasActiveGames = function() {
                        var e = !1;
                        return o.playTogether.playTogetherIds ? (o.playTogether.pinGame && (e = -1 < o.playTogether.playTogetherIds.indexOf(o.playTogether.pinGame.rootPlaceId), o.playTogetherLayout.activeGamesList.pinGameIsInActiveGames = e), e ? o.playTogether.playTogetherIds.length - 1 : o.playTogether.playTogetherIds.length) : 0
                    }, o.unPinGame = function() {
                        var e, a;
                        o.playTogether && o.playTogether.pinGame && (e = o.chatLibrary.eventStreamParams.unpinGameInPlayTogether, a = o.playTogether.pinGame.rootPlaceId, c.sendPinGameEvent(e, a, o.playTogether), c.setPinGameData(o.playTogether), c.unpinGame(o.playTogether), n.updateButtonLayoutPerConversation(o.playTogether, a), u.updateScrollbar(l.gameListScrollListSelector))
                    }, o.pinGame = function(e, a) {
                        e = parseInt(e), a = parseInt(a);
                        var t = o.chatLibrary.eventStreamParams.pinGameInPlayTogether;
                        c.sendPinGameEvent(t, a, o.playTogether);
                        t = {
                            rootPlaceId: a,
                            universeId: e,
                            actorUsername: o.chatLibrary.name,
                            userId: o.chatLibrary.userId,
                            placeName: o.chatLibrary.placesLibrary && o.chatLibrary.placesLibrary[a] ? o.chatLibrary.placesLibrary[a].placeName : "",
                            encodedPlaceName: o.chatLibrary.placesLibrary && o.chatLibrary.placesLibrary[a] ? o.chatLibrary.placesLibrary[a].encodedPlaceName : ""
                        };
                        c.setPinGameData(o.playTogether, t), c.pinGame(o.playTogether, e), n.updateButtonLayoutPerConversation(o.playTogether, a)
                    }, o.initData = function() {
                        var e, a, t, i, r, n, s;
                        o.playTogetherLayout = Object.assign({}, l), o.gameParameters = Object.assign({}, d), o.gameLayout = Object.assign({}, g), o.pinGameLayout = Object.assign({}, p), o.dialogData ? (o.playTogether = o.dialogData, o.playTogether.inDialog = !0, o.playTogetherLayout.numberOfActiveGames = o.hasActiveGames(), e = o.playTogetherLayout.numberOfActiveGames, a = (i = o.playTogetherLayout.activeGamesList).isCollapsed, t = i.pinGameIsInActiveGames, r = i.limitNumber, s = i.minNumberForFit, n = i.maxNumberForFit, i = i.showLess, t && (r = {
                            limitNumber: r + 1,
                            minNumberForFit: s + 1,
                            maxNumberForFit: n + 1
                        }, n = o.playTogetherLayout.activeGamesList, Object.assign(n, r)), s = 0 < (s = e - s) ? s : 0, s = o.playTogetherLayout.activeGamesList.showMore(s), o.playTogetherLayout.activeGamesList.showMoreText = s, 1 < o.playTogetherLayout.numberOfActiveGames && (o.playTogetherLayout.activeGamesList.toggleMenuText = a ? s : i)) : (o.playTogether = o.chatUser, o.playTogether.inDialog = !1, o.playTogetherLayout.numberOfActiveGames = o.hasActiveGames(), o.playTogetherLayout.activeGamesList.limitNumber = o.playTogetherLayout.numberOfActiveGames), o.chatLibrary.playTogetherLibrary[o.playTogether.id] = {
                            layout: o.playTogetherLayout
                        }
                    }, o.initData()
                }
                i.$inject = ["$scope", "$log", "$window", "modalService", "gameService", "playTogetherLayout", "eventStreamService", "pinGameService", "gameParameters", "chatUtility", "gameLayout", "pinGameLayout", "playGameService"], t.Z.controller("playTogetherController", i), a.default = i
            },
            2041: function(e, a, t) {
                "use strict";
                t.r(a);
                t = t(9472);

                function n(a, e) {
                    var t, i = Object.keys(a);
                    return Object.getOwnPropertySymbols && (t = Object.getOwnPropertySymbols(a), e && (t = t.filter(function(e) {
                        return Object.getOwnPropertyDescriptor(a, e).enumerable
                    })), i.push.apply(i, t)), i
                }

                function s(i) {
                    for (var e = 1; e < arguments.length; e++) {
                        var r = null != arguments[e] ? arguments[e] : {};
                        e % 2 ? n(Object(r), !0).forEach(function(e) {
                            var a, t;
                            a = i, e = r[t = e], t in a ? Object.defineProperty(a, t, {
                                value: e,
                                enumerable: !0,
                                configurable: !0,
                                writable: !0
                            }) : a[t] = e
                        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(i, Object.getOwnPropertyDescriptors(r)) : n(Object(r)).forEach(function(e) {
                            Object.defineProperty(i, e, Object.getOwnPropertyDescriptor(r, e))
                        })
                    }
                    return i
                }

                function i(t, e, i, r) {
                    t.hasGameAlbum = function() {
                        var e = 0,
                            a = null;
                        return t.chatUser.pinGame && (e++, a = t.chatUser.pinGame.rootPlaceId), t.chatUser.playTogetherIds && (a && -1 < t.chatUser.playTogetherIds.indexOf(a) ? e = e + t.chatUser.playTogetherIds.length - 1 : e += t.chatUser.playTogetherIds.length), 1 < e
                    }, t.isGameAvailableInChat = function() {
                        return t.chatUser.placeForShown && t.chatUser.placeForShown.universeId && t.chatUser.placeForShown.rootPlaceId
                    }, t.openGameList = function() {
                        var e, a;
                        t.hoverPopoverParams && !t.hoverPopoverParams.isOpen && (e = i.eventStreamParams.openGameListInPlayTogether, a = {
                            conversationId: t.chatUser.id
                        }, r.sendEventWithTarget(e, i.eventStreamParams.actions.hover, a))
                    }, t.setupHoverPopover = function() {
                        t.hoverPopoverParams = s({}, i.hoverPopoverParams), t.hoverPopoverParams.triggerSelector = ".chat-friend-".concat(t.chatUser.id), t.hoverPopoverParams.hoverPopoverSelector = ".game-list-".concat(t.chatUser.id)
                    }, t.shouldShowUnread = function() {
                        return t.chatUser && t.chatUser.hasUnreadMessages && !t.chatUser.isUserPending
                    }, t.init = function() {
                        t.gamesListTemplateUrl = i.templates.gamesList, t.setupHoverPopover()
                    }, t.init()
                }
                i.$inject = ["$scope", "$log", "resources", "eventStreamService"], t.Z.controller("userConversationInfoController", i), a.default = i
            },
            5774: function(e, a, t) {
                "use strict";
                t.r(a);
                t = t(9472);

                function i(e) {
                    return {
                        restrict: "A",
                        templateUrl: e.templates.abuseReportTemplate
                    }
                }
                i.$inject = ["resources"], t.Z.directive("abuseReport", i), a.default = i
            },
            6620: function(e, a, t) {
                "use strict";
                t.r(a);
                t = t(9472);

                function i(e) {
                    return {
                        restrict: "A",
                        replace: !0,
                        templateUrl: e.templates.addFriendsTemplate
                    }
                }
                i.$inject = ["resources"], t.Z.directive("addFriends", i), a.default = i
            },
            96: function(e, a, t) {
                "use strict";
                t.r(a);
                t = t(9472);

                function i(e) {
                    return {
                        restrict: "A",
                        scope: !0,
                        link: function(a, e) {
                            e.bind("click touchstart", function(e) {
                                e.preventDefault(), a.closeDialog(a.dialogData.layoutId)
                            })
                        }
                    }
                }
                i.$inject = ["$log"], t.Z.directive("backBtn", i), a.default = i
            },
            1083: function(e, a, t) {
                "use strict";
                t.r(a);
                t = t(9472);

                function i(e) {
                    return {
                        restrict: "A",
                        scope: {
                            userId: "@",
                            className: "@",
                            layoutLibrary: "="
                        },
                        templateUrl: e.templates.chatAvatarHeadshot
                    }
                }
                i.$inject = ["resources"], t.Z.directive("chatAvatarHeadshot", i), a.default = i
            },
            5764: function(e, a, t) {
                "use strict";
                t.r(a);
                t = t(9472);

                function i(e) {
                    return {
                        restrict: "A",
                        scope: !0,
                        replace: !0,
                        templateUrl: e.templates.chatBarTemplate
                    }
                }
                i.$inject = ["resources"], t.Z.directive("chatBar", i), a.default = i
            },
            889: function(e, a, t) {
                "use strict";
                t.r(a);
                t = t(9472);

                function i(e) {
                    return {
                        restrict: "A",
                        scope: !0,
                        replace: !0,
                        templateUrl: e.templates.chatBaseTemplate
                    }
                }
                i.$inject = ["resources"], t.Z.directive("chatBase", i), a.default = i
            },
            8272: function(e, a, t) {
                "use strict";
                t.r(a);
                t = t(9472);

                function i(e) {
                    return {
                        restrict: "A",
                        scope: {
                            universeId: "@",
                            className: "@",
                            layoutLibrary: "="
                        },
                        templateUrl: e.templates.chatGameIcon
                    }
                }
                i.$inject = ["resources"], t.Z.directive("chatGameIcon", i), a.default = i
            },
            5121: function(e, a, t) {
                "use strict";
                t.r(a);
                t = t(9472);

                function i(e) {
                    return {
                        restrict: "A",
                        scope: !0,
                        templateUrl: e.templates.chatPlaceholderTemplate
                    }
                }
                i.$inject = ["resources"], t.Z.directive("chatPlaceholder", i), a.default = i
            },
            8042: function(e, a, t) {
                "use strict";
                t.r(a);
                t = t(9472);

                function i(e) {
                    return {
                        restrict: "A",
                        scope: {
                            chatLibrary: "=",
                            dialogLayout: "=",
                            confirmCallback: "&"
                        },
                        templateUrl: e.templates.confirmNegativeActionTemplate
                    }
                }
                i.$inject = ["resources"], t.Z.directive("confirmNegativeAction", i), a.default = i
            },
            57: function(e, a, t) {
                "use strict";
                t.r(a);
                t = t(9472);

                function i(e) {
                    return {
                        restrict: "A",
                        scope: {
                            dialogLayout: "=",
                            confirmCallback: "&"
                        },
                        templateUrl: e.templates.confirmNegativeActionTemplate
                    }
                }
                i.$inject = ["resources"], t.Z.directive("confirmRemoveMember", i), a.default = i
            },
            9264: function(e, a, t) {
                "use strict";
                t.r(a);
                t = t(9472);

                function i(e) {
                    return {
                        restrict: "A",
                        replace: !0,
                        templateUrl: e.templates.conversationTitleTemplate
                    }
                }
                i.$inject = ["resources"], t.Z.directive("conversationTitle", i), a.default = i
            },
            8759: function(e, a, t) {
                "use strict";
                t.r(a);
                t = t(9472);

                function i(e) {
                    return {
                        restrict: "A",
                        replace: !0,
                        templateUrl: e.templates.conversationTitleEditorTemplate
                    }
                }
                i.$inject = ["resources"], t.Z.directive("conversationTitleEditor", i), a.default = i
            },
            6842: function(e, a, t) {
                "use strict";
                t.r(a);
                t = t(9472);

                function i(e) {
                    return {
                        restrict: "A",
                        replace: !0,
                        scope: !0,
                        templateUrl: e.templates.detailsTemplate
                    }
                }
                i.$inject = ["resources"], t.Z.directive("details", i), a.default = i
            },
            1763: function(e, a, t) {
                "use strict";
                t.r(a);
                t = t(9472);

                function i(e) {
                    return {
                        restrict: "A",
                        scope: !0,
                        link: function(e, a) {
                            a.mCustomScrollbar({
                                autoExpandScrollbar: !1,
                                scrollInertia: 5,
                                contentTouchScroll: 1,
                                mouseWheel: {
                                    preventDefault: !0
                                },
                                advanced: {
                                    autoScrollOnFocus: !1
                                }
                            })
                        }
                    }
                }
                i.$inject = ["$log"], t.Z.directive("detailsScrollbar", i), a.default = i
            },
            3669: function(e, a, t) {
                "use strict";
                t.r(a);
                var i = t(5734),
                    f = t.n(i),
                    t = t(9472);

                function n(a, e) {
                    var t, i = Object.keys(a);
                    return Object.getOwnPropertySymbols && (t = Object.getOwnPropertySymbols(a), e && (t = t.filter(function(e) {
                        return Object.getOwnPropertyDescriptor(a, e).enumerable
                    })), i.push.apply(i, t)), i
                }

                function b(i) {
                    for (var e = 1; e < arguments.length; e++) {
                        var r = null != arguments[e] ? arguments[e] : {};
                        e % 2 ? n(Object(r), !0).forEach(function(e) {
                            var a, t;
                            a = i, e = r[t = e], t in a ? Object.defineProperty(a, t, {
                                value: e,
                                enumerable: !0,
                                configurable: !0,
                                writable: !0
                            }) : a[t] = e
                        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(i, Object.getOwnPropertyDescriptors(r)) : n(Object(r)).forEach(function(e) {
                            Object.defineProperty(i, e, Object.getOwnPropertyDescriptor(r, e))
                        })
                    }
                    return i
                }

                function r(h, n, s, o, y, m, t, l, c, e, a, v) {
                    return {
                        restrict: "A",
                        scope: {
                            dialogData: "=",
                            chatLibrary: "=",
                            chatUser: "=",
                            closeDialog: "&",
                            sendInvite: "&",
                            openConversationFromFriendId: "&"
                        },
                        link: function(d, u) {
                            function g() {
                                d.isOverLoaded(), d.dialogData.currentUserId = d.currentUserId;
                                var a, e = c.templates.dialogTemplate,
                                    t = c.templates.groupDialogTemplate,
                                    i = c.templates.createChatGroupTemplate;
                                switch (d.dialogData.dialogType) {
                                    case y.dialogType.CHAT:
                                        f().forEach(d.dialogData.userIds, function(e) {
                                            e !== d.chatLibrary.userId && (a = e)
                                        }), d.dialogLayout.title = d.dialogData.title, d.dialogLayout.templateUrl = e, d.dialogLayout.scrollbarElm = y.getScrollBarSelector(d.dialogData, y.scrollBarType.MESSAGE), d.dialogData.name = d.dialogData.title, d.dialogData.nameLink = d.chatLibrary.friendsDict[a] ? d.chatLibrary.friendsDict[a].profileUrl : "";
                                        break;
                                    case y.dialogType.GROUPCHAT:
                                        d.dialogLayout.templateUrl = t, d.dialogLayout.limitMemberDisplay = r, d.dialogLayout.scrollbarElm = y.getScrollBarSelector(d.dialogData, y.scrollBarType.MESSAGE), d.dialogData.name = d.dialogData.title;
                                        break;
                                    case y.dialogType.NEWGROUPCHAT:
                                        d.dialogLayout.title = d.dialogData.title, d.dialogLayout.templateUrl = i
                                }
                                d.updateDialogStyle()
                            }

                            function p() {
                                (d.dialogLayout.IsdialogContainerVisible || u.find(".dialog-container")) && (d.dialogLayout.IsdialogContainerVisible = !1, u.empty());
                                var e = f().element(s.get(d.dialogLayout.templateUrl));
                                d.chatLibrary && d.chatLibrary.dialogScopeLib[d.dialogData.id] && (t = d.chatLibrary.dialogScopeLib[d.dialogData.id]), d.$$childHead && null != d.$$childHead && d.$$childHead.timeStamp === t && d.$$childHead.$destroy();
                                var a = d.$new(),
                                    t = Date.now();
                                d.chatLibrary && (d.chatLibrary.dialogScopeLib[d.dialogData.id] = t), a.timeStamp = t, t = n(e), u.append(e), t(a)
                            }
                            var r = y.dialogLayout.limitMemberDisplay,
                                e = 0;
                            d.saveIntoDialogsLayout = function() {
                                var e = d.dialogData.layoutId;
                                d.dialogLayout && d.dialogLayout.layoutId === e && (d.chatLibrary.dialogsLayout[e] = d.dialogLayout, m.updateStorage(m.storageDictionary.dialogsLayout, d.chatLibrary.dialogsLayout, d.chatLibrary.cookieOption))
                            };

                            function i(e) {
                                var a = f().isDefined(d.dialogData.userIds) ? d.dialogData.userIds.indexOf(e) : -1,
                                    e = f().isDefined(d.dialogData.selectedUserIds) ? d.dialogData.selectedUserIds.indexOf(e) : -1;
                                return a < 0 && e < 0
                            }

                            function a() {
                                d.dialogLibrary = t.getLocalStorage(d.chatLibrary.dialogLocalStorageName) ? t.getLocalStorage(d.chatLibrary.dialogLocalStorageName) : {}
                            }
                            d.updateDialogStyle = function() {
                                y.updateDialogStyle(d.dialogData, d.dialogLayout, d.chatLibrary)
                            }, d.updateFriends = function(e) {
                                var a, t = [];
                                e ? (a = y.sortFriendList(d.chatLibrary, e)) && (a.forEach(function(e) {
                                    i(e.id) && t.push(e.id), d.chatLibrary.friendsDict[e.id] || (d.chatLibrary.friendsDict[e.id] = e)
                                }), d.dialogData.friendIds = t) : (a = d.chatLibrary.friendIds.slice(), f().forEach(a, function(e) {
                                    i(e) && t.push(e)
                                }), d.dialogData.friendIds = t)
                            }, d.isOverLoaded = function() {
                                f().isUndefined(d.dialogData.selectedUserIds) && (d.dialogData.selectedUserIds = [], d.dialogData.selectedUsersDict = {}), d.dialogData.dialogType !== y.dialogType.FRIEND && (d.dialogData.dialogType === y.dialogType.NEWGROUPCHAT ? d.dialogData.numberOfSelected = d.dialogData.selectedUserIds.length : d.dialogData.dialogType === y.dialogType.CHAT ? d.dialogData.numberOfSelected = d.dialogData.userIds.length + d.dialogData.selectedUserIds.length : d.dialogData.numberOfSelected = d.dialogData.userIds.length + d.dialogData.selectedUserIds.length - 1, d.dialogLayout.isMembersOverloaded = d.dialogData.numberOfSelected >= d.chatLibrary.quotaOfGroupChatMembers)
                            }, d.dialogData.selectedUserIds = [], d.dialogData.selectedUsersDict = {}, d.selectFriends = function(e) {
                                var a = d.dialogData.selectedUserIds.indexOf(e);
                                a < 0 && !d.dialogLayout.isMembersOverloaded ? (d.dialogData.selectedUserIds.push(e), d.dialogData.selectedUsersDict[e] = f().copy(d.chatLibrary.friendsDict[e])) : -1 < a && (d.dialogData.selectedUserIds.splice(a, 1), delete d.dialogData.selectedUsersDict[e]), d.dialogData.searchTerm = "", d.isOverLoaded()
                            }, d.isNumberOfMemberOverloaded = function() {
                                var e = d.dialogData.selectedUserIds ? d.dialogData.selectedUserIds.length : 0,
                                    a = 0;
                                return d.dialogData.userIds && (a = d.dialogData.dialogType === y.dialogType.CHAT ? d.dialogData.userIds.length : d.dialogData.userIds.length - 1), e + a >= d.chatLibrary.quotaOfGroupChatMembers && (d.dialogLayout.isMembersOverloaded = !0, !d.dialogLayout.details.isEnabled && d.dialogData.dialogType !== y.dialogType.NEWGROUPCHAT || (d.toastLayout.isNeeded = !0, d.toastLayout.text || (d.toastLayout.text = d.dialogLayout.memberDisplay.toastText(d.chatLibrary.quotaOfGroupChatMembers))), !0)
                            }, d.toggleFriendSelection = function(e, a) {
                                a && a.preventDefault();
                                a = d.dialogData.selectedUserIds.indexOf(e);
                                a < 0 && !d.isNumberOfMemberOverloaded() ? (d.dialogData.selectedUserIds.push(e), d.dialogData.selectedUsersDict[e] = f().copy(d.chatLibrary.friendsDict[e]), d.dialogData.selectedUsersDict[e].isSelected = !0) : -1 < a && (d.dialogData.selectedUserIds.splice(a, 1), delete d.dialogData.selectedUsersDict[e]), d.dialogData.searchTerm = "", d.isOverLoaded()
                            }, d.toggleDialogContainer = function() {
                                d.dialogLayout.collapsed = !d.dialogLayout.collapsed, d.toggleDialogFocusStatus(!d.dialogLayout.collapsed), d.saveIntoDialogsLayout(), y.updateDialogsPosition(d.chatLibrary)
                            }, d.toggleDialogFocusStatus = function(e) {
                                e && (y.updateFocusedDialog(d.chatLibrary, d.dialogData.layoutId), l.markMessagesAsRead(d.dialogData, d.chatLibrary.shouldRespectConversationHasUnreadMessageToMarkAsRead)), (d.dialogLayout.hasFocus = e) && d.dialogLayout.active && d.markInactive();
                                var a, a = e && (a = "", f().isDefined(window.getSelection) ? a = window.getSelection().toString() : f().isDefined(window.document.selection) && "Text" === window.document.selection.type && (a = window.document.selection.createRange().text), !(0 < a.length)) && !d.dialogLayout.collapsed && !d.dialogLayout.renameEditor.isEnabled;
                                return d.dialogLayout.focusMeEnabled = a, d.saveIntoDialogsLayout(), !1
                            }, d.getTitle = function(e) {
                                var a = d.dialogData.chatMessages;
                                if (a && 0 < a.length) {
                                    var t = a[0].sender_user_id;
                                    if (!t) return !1;
                                    t = d.chatLibrary.friendsDict[t].name
                                } else t = d.dialogData.initiator.name;
                                t = o("formatString")(y.chatLayout.defaultTitleForMessage, {
                                    userName: t
                                }), d.title = t
                            }, d.changeTitle = function() {
                                h.document.title = e % 2 == 0 ? d.title : d.chatLibrary.currentTabTitle, e++
                            }, d.markInactive = function() {
                                d.dialogLayout.active && (d.dialogLayout.active = !1, a(), d.dialogLibrary && d.dialogLibrary[d.dialogData.layoutId] && d.dialogLibrary[d.dialogData.layoutId].active && (v.debug(" --------------- markInactive -------------- set into local storage"), f().isUndefined(d.dialogLibrary[d.dialogData.layoutId]) && (d.dialogLibrary[d.dialogData.layoutId] = {}), d.dialogLibrary[d.dialogData.layoutId].active = !1, d.dialogLibrary[d.dialogData.layoutId].played = !1, t.setLocalStorage(d.chatLibrary.dialogLocalStorageName, d.dialogLibrary)))
                            }, d.markActive = function(e) {
                                a(), f().isUndefined(d.dialogLibrary[d.dialogData.layoutId]) && (d.dialogLibrary[d.dialogData.layoutId] = {}), d.dialogLibrary[d.dialogData.layoutId].active = !0, d.dialogLibrary[d.dialogData.layoutId].played = !1, t.setLocalStorage(d.chatLibrary.dialogLocalStorageName, d.dialogLibrary), !d.dialogLayout.collapsed && d.chatLibrary.chatLayout.focusedLayoutId === d.dialogData.layoutId || (d.dialogLayout.active = !0, d.dialogLayout.focusMeEnabled && (d.dialogLayout.focusMeEnabled = !1))
                            }, d.handleLocalStorage = function(e) {
                                e.key === d.chatLibrary.dialogLocalStorageName && (a(), d.dialogLayout.active && d.dialogLibrary && d.dialogLibrary[d.dialogData.layoutId] && !d.dialogLibrary[d.dialogData.layoutId].active && d.markInactive())
                            }, d.checkNewGenerationDialogStatus = function() {
                                d.dialogData.isRenameEditorNeeded && (d.dialogLayout.focusMeEnabled && (d.dialogLayout.focusMeEnabled = !1), d.dialogData.isRenameEditorNeeded = !1, d.dialogLayout.renameEditor.isEnabled = !0, d.dialogLayout.renameEditor.hasFocus = !0)
                            }, d.search = function(e) {
                                var a = d.dialogData.searchTerm;
                                if (!a) return !0;
                                var t = e.name,
                                    i = e.contact,
                                    r = e.display_name,
                                    e = e.nameForDisplay,
                                    a = a.toLowerCase();
                                return -1 !== t.toLowerCase().indexOf(a) || r && -1 !== r.toLowerCase().indexOf(a) || i && -1 !== i.toLowerCase().indexOf(a) || e && -1 !== e.toLowerCase().indexOf(a)
                            }, d.dialogData.friendIds = d.chatLibrary.friendIds ? d.chatLibrary.friendIds.slice() : [], d.dialogMessages = [], d.dialogType = b({}, y.dialogType), d.dialogBannerTypes = b({}, y.dialogBannerTypes), d.dialogLayout = f().isDefined(d.chatLibrary.dialogsLayout[d.dialogData.layoutId]) ? d.chatLibrary.dialogsLayout[d.dialogData.layoutId] : f().copy(y.dialogLayout), d.dialogLayout.layoutId = d.dialogData.layoutId, d.toastLayout = {
                                isEnabled: d.dialogLayout.isMembersOverloaded,
                                timeout: d.dialogLayout.memberDisplay.timeoutToast
                            }, d.dialogLayout.defaultStyle = {}, d.isOverLoaded(), d.$watch(function() {
                                return d.chatLibrary.dialogDict
                            }, function(e, a) {
                                if (f().isDefined(e) && f().isDefined(e[d.dialogData.layoutId])) {
                                    var t = d.dialogData.layoutId,
                                        i = d.chatLibrary,
                                        r = i.dialogIdList.indexOf(t),
                                        n = e[t];
                                    if (!a[t] || n.isUpdated) switch (f().isDefined(d.chatLibrary.dialogsLayout[d.dialogData.layoutId]) ? d.dialogLayout = d.chatLibrary.dialogsLayout[d.dialogData.layoutId] : f().isUndefined(d.dialogLayout) ? d.dialogLayout = f().copy(y.dialogLayout) : n.updateStatus === y.dialogStatus.INIT && d.dialogLayout && (d.dialogLayout.renameEditor = b({}, y.dialogLayout.renameEditor)), n.isUpdated = !1, n.updateStatus) {
                                        case y.dialogStatus.REPLACE:
                                            -1 < r && (d.dialogLayout.collapsed && (d.dialogLayout.collapsed = !1), n.updateStatus = y.dialogStatus.INIT, d.toggleDialogFocusStatus(!0));
                                        case y.dialogStatus.INIT:
                                            -1 < r && (d.dialogLayout.focusMeEnabled === n.autoOpen && (d.dialogLayout.focusMeEnabled = !n.autoOpen), d.checkNewGenerationDialogStatus(), g(), p());
                                            break;
                                        case y.dialogStatus.MINIMIZE:
                                            g(), d.chatLibrary.minimizedDialogIdList.indexOf(t) < 0 && (d.chatLibrary.minimizedDialogIdList.push(t), d.chatLibrary.minimizedDialogData[t] = d.dialogData), u.empty();
                                            break;
                                        case y.dialogStatus.REFRESH:
                                            g(), n.updateStatus = y.dialogStatus.INIT
                                    }
                                    m.updateStorage(m.storageDictionary.dialogIdList, d.chatLibrary.dialogIdList, d.chatLibrary.cookieOption), m.updateStorage(m.storageDictionary.dialogDict, d.chatLibrary.dialogDict, d.chatLibrary.cookieOption), d.saveIntoDialogsLayout(), -1 < r && (s = i.dialogIdList, l = d.dialogData.layoutId, c = "#".concat(l), e = d.chatLibrary.chatLayout, a = f().element(document.querySelector(c)).find(".dialog-container"), i = e.widthOfChat, c = e.widthOfDialog + e.spaceOfDialog, s = s.indexOf(l), l = d.chatLibrary, i = +i + y.calculateRightPosition(l, s) + e.spaceOfDialog, h.innerWidth < i + c ? o = +e.defaultChatZIndex + 1 : (o = +e.defaultChatZIndex + s, y.updateDialogsPosition(l)), a.css("z-index", o), a.addClass("dialog-visible"), n.markAsActive && (d.markActive(n.activeType), n.markAsActive = !1))
                                }
                                var s, o, l, c
                            }, !0), d.$on("Roblox.Chat.MarkDialogInactive", function(e, a) {
                                a.layoutId === d.dialogData.layoutId && d.markInactive()
                            }), t.listenLocalStorage(d.handleLocalStorage)
                        }
                    }
                }
                r.$inject = ["$window", "$compile", "$templateCache", "$filter", "chatUtility", "chatClientStorageUtilityService", "localStorageService", "messageService", "resources", "gameService", "gameLayout", "$log"], t.Z.directive("dialog", r), a.default = r
            },
            8945: function(e, a, t) {
                "use strict";
                t.r(a);
                t = t(9472);

                function i(e) {
                    return {
                        restrict: "A",
                        replace: !0,
                        scope: !0,
                        templateUrl: e.templates.dialogHeader
                    }
                }
                i.$inject = ["resources"], t.Z.directive("dialogHeader", i), a.default = i
            },
            3111: function(e, a, t) {
                "use strict";
                t.r(a);
                var i = t(5734),
                    l = t.n(i),
                    t = t(9472);

                function r(a, n, s, o, t) {
                    return {
                        restrict: "A",
                        scope: !0,
                        link: function(r, e) {
                            r.callbackScrollToBottom = function() {
                                r.updateDialog()
                            }, r.callbackLazyLoad = function() {
                                if (!r.dialogParams.loadMoreMessages || !r.dialogLayout.IsdialogContainerVisible || r.dialogData.dialogType === n.dialogType.FRIEND) return !1;
                                r.dialogLayout.isChatLoading = !0;
                                r.dialogData.chatMessages.length;
                                var e = r.dialogParams.getMessagesNextCursor;
                                a.getMessages(r.dialogData.id, e, r.dialogParams.pageSizeOfGetMessages).then(function(e) {
                                    var a = e.messages;
                                    if (r.dialogLayout.isChatLoading = !1, a) {
                                        if (l().isUndefined(r.dialogData.messagesDict) && (r.dialogData.messagesDict = {}), r.dialogParams.getMessagesNextCursor = e.next_cursor, 0 < a.length) {
                                            r.dialogLayout.scrollToBottom = !1, s.preProcessMessages(r.chatLibrary, r.dialogData, a);
                                            for (var t = 0; t < a.length; t++) {
                                                var i = a[t];
                                                i.type === n.messageSenderType.SYSTEM && (i.isSystemMessage = !0), s.buildFallbackTimeStamp(i, r.dialogData), l().isDefined(i.id) && l().isDefined(r.dialogData.messagesDict[i.id]) || (s.setFallbackClusterMaster(r.dialogData, i), l().isDefined(i.id) && (r.dialogData.messagesDict[i.id] = i))
                                            }
                                            o.fetchDataForLinkCard(a, r.chatLibrary)
                                        }!e.next_cursor && (r.dialogParams.loadMoreMessages = !1)
                                    } else r.dialogParams.loadMoreMessages = !1, s.processMessages(r.chatLibrary, r.dialogData, a, r.chatLibrary.friendsDict), o.fetchDataForLinkCard(a, r.chatLibrary)
                                }, function() {
                                    r.dialogLayout.isChatLoading = !1, t.debug("---error from get getMessages in dialogLazyLoadDirective.js---")
                                })
                            };
                            e.mCustomScrollbar({
                                autoExpandScrollbar: !1,
                                scrollInertia: 5,
                                contentTouchScroll: 1,
                                mouseWheel: {
                                    preventDefault: !0
                                },
                                callbacks: {
                                    onInit: function() {
                                        t.debug("---- onInit callback ---- Scrollbars updated"), r.dialogLayout.scrollToBottom = !0
                                    },
                                    onUpdate: function() {
                                        t.debug("---- onUpdate callback ---- Scrollbars updated" + r.dialogLayout.scrollToBottom), r.dialogLayout.scrollToBottom ? e.mCustomScrollbar("scrollTo", "bottom", {
                                            scrollInertia: 0
                                        }) : r.dialogLayout.scrollToBottom = !0, e.hasClass("mCS_no_scrollbar") && r.updateDialog()
                                    },
                                    onTotalScroll: r.callbackScrollToBottom,
                                    onTotalScrollOffset: 60,
                                    onTotalScrollBack: r.callbackLazyLoad
                                }
                            })
                        }
                    }
                }
                r.$inject = ["chatService", "chatUtility", "messageService", "gameService", "$log"], t.Z.directive("dialogLazyLoad", r), a.default = r
            },
            6059: function(e, a, t) {
                "use strict";
                t.r(a);
                var i = t(792),
                    i = t(5734),
                    o = t.n(i),
                    t = t(9472);

                function r(n, e, s) {
                    return {
                        restrict: "A",
                        scope: {
                            chatLibrary: "="
                        },
                        templateUrl: e.templates.dialogMinimizeTemplate,
                        link: function(t, i) {
                            function r() {
                                var e = t.chatLibrary.chatLayout,
                                    a = t.chatLibrary.dialogIdList.length,
                                    e = +e.widthOfChat + n.calculateRightPosition(t.chatLibrary, a) + e.spaceOfDialog;
                                i.css("right", e)
                            }
                            t.dialogType = n.dialogType, t.chatLibrary.hasMinimizedDialogs = !1, t.layoutIdHasClicked = !1, t.openDialog = function(e) {
                                s.debug(" -------------------openDialog------------------ " + e);
                                var a = t.chatLibrary.dialogIdList.pop();
                                t.chatLibrary.dialogDict[a].isUpdated = !0, t.chatLibrary.dialogDict[a].updateStatus = n.dialogStatus.MINIMIZE, t.chatLibrary.dialogIdList.push(e), t.chatLibrary.dialogDict[e].isUpdated = !0, t.chatLibrary.dialogDict[e].updateStatus = n.dialogStatus.REPLACE;
                                a = t.chatLibrary.minimizedDialogIdList.indexOf(e); - 1 < a && (t.chatLibrary.minimizedDialogIdList.splice(a, 1), delete t.chatLibrary.minimizedDialogData[e])
                            }, t.remove = function(e) {
                                var a = t.chatLibrary.minimizedDialogIdList.indexOf(e); - 1 < a && (t.chatLibrary.minimizedDialogIdList.splice(a, 1), delete t.chatLibrary.minimizedDialogData[e], delete t.chatLibrary.dialogDict[e])
                            }, Roblox.BootstrapWidgets.SetupPopover("top", {
                                selector: "#dialogs-minimize"
                            }, "#dialogs-minimize-container"), t.$watch(function() {
                                return t.chatLibrary.minimizedDialogIdList
                            }, function(e, a) {
                                o().isUndefined(e) || e == a || (s.debug("------ watch minimizedDialogIdList ----- "), 0 < e.length ? (t.chatLibrary.hasMinimizedDialogs || (t.chatLibrary.hasMinimizedDialogs = !0), r()) : 0 === e.length && (t.chatLibrary.hasMinimizedDialogs = !1))
                            }, !0), t.$watch(function() {
                                return t.chatLibrary.chatLayout.areDialogsUpdated
                            }, function(e, a) {
                                e && e !== a && (t.$evalAsync(function() {
                                    t.chatLibrary.chatLayout.areDialogsUpdated = !1
                                }), r())
                            }, !0)
                        }
                    }
                }
                r.$inject = ["chatUtility", "resources", "$log"], t.Z.directive("dialogMinimize", r), a.default = r
            },
            4861: function(e, a, t) {
                "use strict";
                t.r(a);
                t = t(9472);

                function i(e, a) {
                    return {
                        restrict: "A",
                        replace: !0,
                        scope: !0,
                        templateUrl: e.templates.displayMessage,
                        link: function(e) {
                            e.initializeDisplayMessage = function() {
                                e.messageHelper = a, e.displayMessage = e.chatUser.displayMessage
                            }, e.initializeDisplayMessage()
                        }
                    }
                }
                i.$inject = ["resources", "messageHelper"], t.Z.directive("displayMessage", i), a.default = i
            },
            4433: function(e, a, t) {
                "use strict";
                t.r(a);
                var i = t(5734),
                    n = t.n(i),
                    t = t(9472);

                function r(e) {
                    return {
                        restrict: "A",
                        link: function(i, e) {
                            var r = i.chatLibrary.layout.topBarHeight;
                            i.$watch(function() {
                                return e.innerHeight()
                            }, function(e, a) {
                                var t;
                                e && e !== a && (t = "#".concat(i.dialogData.layoutId, " .dialog-container"), a = "#".concat(i.dialogData.layoutId, " ").concat(i.friendsScrollbarElm), t = n().element(t), a = n().element(a), e = r + e, e = t.height() - e, a.css("height", e), a.mCustomScrollbar("update"))
                            }, !0)
                        }
                    }
                }
                r.$inject = ["$log"], t.Z.directive("groupSelect", r), a.default = r
            },
            8406: function(e, a, t) {
                "use strict";
                t.r(a);
                t = t(9472);

                function i(a, n, t, i, s, o, l) {
                    return {
                        restrict: "A",
                        scope: !0,
                        link: function(r, e) {
                            r.callbackLazyLoad = function() {
                                if (!r.chatApiParams || r.chatLibrary.chatLayout.errorMaskEnable || !r.chatApiParams.loadMoreConversations) return !1;
                                var e;
                                r.chatLibrary.chatLayout.isChatLoading = !0, r.chatApiParams.loadMoreConversations && (e = r.chatApiParams.getUserConversationsNextCursor, a.getUserConversations(e, r.chatApiParams.pageSizeOfConversations, r.chatLibrary.friendsDict).then(function(e) {
                                    var a = e.conversations,
                                        t = r.chatLibrary.friendsDict,
                                        i = s.getUserIdsNotInFriendsDict(a, t);
                                    return r.chatLibrary.chatLayout.isChatLoading = !1, a && 0 < a.length ? (r.buildChatUserListByConversations(a), r.chatApiParams.getUserConversationsNextCursor = e.next_cursor, n.updateScrollbar(n.chatLayout.scrollbarClassName), e.next_cursor || (r.chatApiParams.loadMoreConversations = !1, r.chatApiParams.getUserConversationsNextCursor = null)) : (r.chatApiParams.loadMoreConversations = !1, r.chatApiParams.getUserConversationsNextCursor = null), l.getUserContacts(i, t), o.getUserInfo(i, t)
                                }, function() {
                                    r.chatLibrary.chatLayout.isChatLoading = !1, t.debug("---error from get Conversations in lazyLoadDirective.js---")
                                }))
                            }, r.callbackScrollStart = function() {
                                r.$broadcast("Roblox.Chat.ConversationListScroll"), i.triggerHandler("HoverPopover.EnableClose")
                            }, e.mCustomScrollbar({
                                autoExpandScrollbar: !1,
                                scrollInertia: 5,
                                contentTouchScroll: 1,
                                mouseWheel: {
                                    preventDefault: !0
                                },
                                callbacks: {
                                    onTotalScrollOffset: 100,
                                    onTotalScroll: r.callbackLazyLoad,
                                    onOverflowYNone: r.callbackLazyLoad,
                                    onScrollStart: r.callbackScrollStart
                                }
                            })
                        }
                    }
                }
                i.$inject = ["chatService", "chatUtility", "$log", "$document", "conversationsUtility", "usersService", "contactsService"], t.Z.directive("lazyLoad", i), a.default = i
            },
            8079: function(e, a, t) {
                "use strict";
                t.r(a);
                t = t(9472);

                function i(e) {
                    return {
                        restrict: "A",
                        scope: !0,
                        replace: !0,
                        templateUrl: e.templates.linkCard
                    }
                }
                i.$inject = ["resources"], t.Z.directive("linkCard", i), a.default = i
            },
            7806: function(e, a, t) {
                "use strict";
                t.r(a);
                var i = t(5734),
                    r = t.n(i),
                    t = t(9472);

                function n(e) {
                    return {
                        restrict: "A",
                        scope: !0,
                        link: function(e) {
                            r().element("#dialogs-minimize").on("click touchstart", ".popover-content #" + e.dialogLayoutId + " .minimize-title", function() {
                                e.$apply(e.openDialog(e.dialogLayoutId))
                            });
                            r().element("#dialogs-minimize").on("click touchstart", ".popover-content #" + e.dialogLayoutId + " .minimize-close", function() {
                                e.$apply(e.remove(e.dialogLayoutId))
                            })
                        }
                    }
                }
                n.$inject = ["$log"], t.Z.directive("minimizeItem", n), a.default = n
            },
            9688: function(e, a, t) {
                "use strict";
                t.r(a);
                t = t(9472);

                function i(e) {
                    return {
                        restrict: "A",
                        templateUrl: e.templates.pendingStateTemplate
                    }
                }
                i.$inject = ["resources"], t.Z.directive("pendingState", i), a.default = i
            },
            9032: function(e, a, t) {
                "use strict";
                t.r(a);
                t = t(9472);

                function i(e) {
                    return {
                        restrict: "A",
                        scope: !0,
                        link: function(a, e) {
                            e.bind("click touchstart", function(e) {
                                e.preventDefault(), a.sendMessage()
                            })
                        }
                    }
                }
                i.$inject = ["$log"], t.Z.directive("removeFocus", i), a.default = i
            },
            2638: function(e, a, t) {
                "use strict";
                t.r(a);
                t = t(9472);

                function i(e, a) {
                    return {
                        link: function() {
                            e.buildScrollbar(a.gameListScrollListSelector)
                        }
                    }
                }
                i.$inject = ["chatUtility", "playTogetherLayout"], t.Z.directive("repeatDone", i), a.default = i
            },
            9630: function(e, a, t) {
                "use strict";
                t.r(a);
                var i = t(5734),
                    r = t.n(i),
                    t = t(9472);

                function n(t, e) {
                    return {
                        restrict: "A",
                        replace: !0,
                        templateUrl: e.templates.selectFriendsTemplate,
                        link: function(e) {
                            function a() {
                                r().isUndefined(e.dialogData) || r().isUndefined(e.dialogData.selectedUserIds) || (e.dialogData.dialogType === t.dialogType.NEWGROUPCHAT ? e.dialogLayout.inviteBtnDisabled = e.dialogData.selectedUserIds.length < 2 : e.dialogLayout.inviteBtnDisabled = 0 === e.dialogData.selectedUserIds.length)
                            }
                            a(), e.$watch(function() {
                                return e.dialogData && e.dialogData.selectedUserIds
                            }, function() {
                                a()
                            }, !0)
                        }
                    }
                }
                n.$inject = ["chatUtility", "resources"], t.Z.directive("selectFriends", n), a.default = n
            },
            5809: function(e, a, t) {
                "use strict";
                t.r(a);
                var i = t(5734),
                    s = t.n(i),
                    t = t(9472);

                function r(n, e) {
                    return {
                        restrict: "A",
                        link: function(i, e) {
                            var r = i.chatLibrary.layout.topBarHeight;
                            i.$watch(function() {
                                return e.innerHeight()
                            }, function(e, a) {
                                var t;
                                e && e !== a && (t = "#" + i.dialogData.layoutId + " .dialog-container", a = "#" + i.dialogData.layoutId + " " + i.friendsScrollbarElm, t = s().element(t), a = s().element(a), e = r + i.chatLibrary.layout.detailsActionHeight + e, i.dialogData.dialogType === n.dialogType.NEWGROUPCHAT && (e += i.chatLibrary.layout.detailsInputHeight), e = t.height() - e, a.css("height", e), a.mCustomScrollbar("update"))
                            }, !0)
                        }
                    }
                }
                r.$inject = ["chatUtility", "$log"], t.Z.directive("selectFriendsResize", r), a.default = r
            },
            4449: function(e, a, t) {
                "use strict";
                t.r(a);
                t = t(9472);

                function i(e, a) {
                    return {
                        restrict: "A",
                        replace: !0,
                        scope: !0,
                        templateUrl: e.templates.systemMessage,
                        link: function(e) {
                            e.messageHelper = a
                        }
                    }
                }
                i.$inject = ["resources", "messageHelper"], t.Z.directive("systemMessage", i), a.default = i
            },
            9080: function(e, a, t) {
                "use strict";
                t.r(a);
                var i = t(5734),
                    p = t.n(i),
                    t = t(9472);

                function r(e, g) {
                    return {
                        restrict: "A",
                        replace: !0,
                        scope: !0,
                        link: function(i, e) {
                            var a = i.dialogLayout.togglePopoverParams,
                                r = a.dialogSelector,
                                t = a.triggerSelector,
                                n = a.pinIconClassName,
                                s = a.dialogTriggerClassSelector,
                                o = a.isExclusiveClickSelector || "is-exclusive-click";

                            function l() {
                                g.on("click", function(e) {
                                    e.stopPropagation();
                                    var a, t = p().element(e.target);
                                    c(t) || (a = t, (e = p().element(r)).find(a) && 0 < e.find(a).length) || function(e) {
                                        var a = !1;
                                        ! function(e) {
                                            return e.hasClass(n)
                                        }(e) || (a = i.dialogData.playTogetherIds && 0 < i.dialogData.playTogetherIds.length || i.dialogData.pinGame);
                                        ! function(e) {
                                            var a = p().element(s);
                                            return a.is(e) || a.find(e) && 0 < a.find(e).length
                                        }(e) || (a = !0);
                                        e.hasClass(o) && (a = !0);
                                        return a
                                    }(t) || (i.dialogLayout.togglePopoverParams.isOpen = !1)
                                })
                            }

                            function c(e) {
                                var a = p().element(t);
                                return a.is(e) || a.find(e) && 0 < a.find(e).length
                            }
                            e.on("click", function(e) {
                                c(p().element(e.target)) && (i.dialogLayout.togglePopoverParams.isOpen = !i.dialogLayout.togglePopoverParams.isOpen)
                            });
                            var d = i.$watch(function() {
                                    return i.dialogData.playTogetherIds
                                }, function(e, a) {
                                    e !== a && e && 0 < e.length && (i.dialogLayout.togglePopoverParams.isOpen || (i.dialogLayout.togglePopoverParams.isOpen = !0))
                                }, !0),
                                u = i.$watch(function() {
                                    return i.dialogLayout.togglePopoverParams.isFirstTimeOpen
                                }, function(e, a) {
                                    e && l()
                                }, !0);
                            i.$on("$destroy", function() {
                                d(), u()
                            })
                        }
                    }
                }
                r.$inject = ["$log", "$document"], t.Z.directive("togglePopover", r), a.default = r
            },
            8341: function(e, a, t) {
                "use strict";
                t.r(a);
                t = t(9472);

                function i(e) {
                    return {
                        restrict: "A",
                        replace: !0,
                        scope: !0,
                        templateUrl: e.templates.userConversationInfoTemplate
                    }
                }
                i.$inject = ["resources"], t.Z.directive("userConversationInfo", i), a.default = i
            },
            1495: function(e, a, t) {
                "use strict";
                t.r(a);
                var i = t(9472),
                    r = t(792);

                function n(e, a) {
                    var t = window.EventTracker;
                    return {
                        sendEvent: function(e, a) {
                            r.EventStream && r.EventStream.SendEventWithTarget(e, "WebChatEventContext", a, r.EventStream.TargetTypes.WWW)
                        },
                        incrementCounter: function(e) {
                            t && t.fireEvent(e)
                        },
                        getConversationIdForAnalytics: function(e) {
                            if ((null == e ? void 0 : e.dialogType) !== a.dialogType.FRIEND) return null == e ? void 0 : e.id;
                            e = e.id || "unknown-id";
                            return "friends:".concat(e)
                        }
                    }
                }
                n.$inject = ["$log", "chatUtility"], i.Z.factory("analyticsService", n), a.default = n
            },
            5869: function(e, a, t) {
                "use strict";
                t.r(a);
                t = t(9472);

                function i(e, i, r) {
                    return {
                        storageDictionary: {
                            dialogIdList: "dialogIdList",
                            dialogDict: "dialogDict",
                            dialogsLayout: "dialogsLayout",
                            chatBarLayout: "chatBarLayout",
                            chatFriendsListReloadTime: "chatFriendsListReloadTime"
                        },
                        isStorageDefined: function(e) {
                            return void 0 !== window.Storage ? this.getFromStorage(e) : r.isCookieDefined(e)
                        },
                        getFromStorage: function(e) {
                            return void 0 !== window.Storage ? i.getLocalStorage(e) : r.retrieveCookie(e)
                        },
                        updateStorage: function(e, a, t) {
                            void 0 !== window.Storage ? i.setLocalStorage(e, a) : r.updateCookie(e, a, t)
                        },
                        removeFromStorage: function(e, a) {
                            void 0 !== window.Storage ? i.removeLocalStorage(e) : r.destroyCookie(e, a)
                        },
                        updateChatFriendsListReloadTime: function(e) {
                            this.updateStorage(this.storageDictionary.chatFriendsListReloadTime, e)
                        }
                    }
                }
                i.$inject = ["chatUtility", "localStorageService", "cookieService"], t.Z.factory("chatClientStorageUtilityService", i), a.default = i
            },
            6061: function(e, a, t) {
                "use strict";
                t.r(a);
                var n = t(792),
                    t = t(9472);

                function i(e, c, i, a, t) {
                    var r = function(e) {
                        for (var a in e) {
                            var t, i = e[a],
                                r = i.participants = [];
                            for (t in i.participant_user_ids) {
                                var n = Object.assign({}, i.user_data[i.participant_user_ids[t]]);
                                r.push(n)
                            }
                            i.initiator = Object.assign({}, i.user_data[i.created_by]), i.hasUnreadMessages = 0 < i.unread_message_count, i.hasDefaultName = !i.name, i.conversationTitle = {
                                titleForViewer: i.name
                            }, i.userPendingStatus = i.user_pending_status, i.moderationType = i.moderation_type
                        }
                    };
                    return {
                        apiSets: {},
                        setParams: function() {
                            var e = n.EnvironmentUrls.chatApi;
                            this.apiSets.markAsReadApi = {
                                url: "".concat(e, "/v1/mark-conversations"),
                                retryable: !1,
                                withCredentials: !0
                            }, this.apiSets.sendMessageApi = {
                                url: "".concat(e, "/v1/send-messages"),
                                retryable: !1,
                                withCredentials: !0
                            }, this.apiSets.getConversationsApi = {
                                url: "".concat(e, "/v1/get-conversations"),
                                retryable: !0,
                                withCredentials: !0
                            }, this.apiSets.userConversationsApi = {
                                url: "".concat(e, "/v1/get-user-conversations"),
                                retryable: !0,
                                withCredentials: !0
                            }, this.apiSets.getMessagesApi = {
                                url: "".concat(e, "/v1/get-conversation-messages"),
                                retryable: !0,
                                withCredentials: !0
                            }, this.apiSets.getUnreadConversationCountApi = {
                                url: "".concat(e, "/v1/get-conversation-metadata"),
                                retryable: !0,
                                withCredentials: !0
                            }, this.apiSets.startOneToOneConversationApi = {
                                url: "".concat(e, "/v1/create-conversations"),
                                retryable: !0,
                                withCredentials: !0
                            }, this.apiSets.startGroupConversationApi = {
                                url: "".concat(e, "/v1/create-conversations"),
                                retryable: !1,
                                withCredentials: !0
                            }, this.apiSets.addToConversationApi = {
                                url: "".concat(e, "/v1/add-users"),
                                retryable: !0,
                                withCredentials: !0
                            }, this.apiSets.removeFromConversationApi = {
                                url: "".concat(e, "/v1/remove-users"),
                                retryable: !0,
                                withCredentials: !0
                            }, this.apiSets.renameGroupConversationApi = {
                                url: "".concat(e, "/v1/update-conversations"),
                                retryable: !1,
                                withCredentials: !0
                            }, this.apiSets.updateUserTypingStatusApi = {
                                url: "".concat(e, "/v1/update-typing-status"),
                                retryable: !1,
                                withCredentials: !0
                            }, this.apiSets.uiPerformanceTrackingApi = {
                                url: "".concat(n.EnvironmentUrls.metricsApi, "/v1/performance/send-measurement"),
                                retryable: !1,
                                withCredentials: !0
                            }
                        },
                        getMetaData: function() {
                            return i.httpGet(t.apiSets.getMetaData, {})
                        },
                        getUnreadConversationCount: function() {
                            return i.httpGet(this.apiSets.getUnreadConversationCountApi, null).then(function(e) {
                                return {
                                    count: 0 < e.global_unread_message_count ? 1 : 0
                                }
                            })
                        },
                        getUserConversations: function(e, a) {
                            a = {
                                include_user_data: !0,
                                cursor: e,
                                pageSize: a
                            };
                            return i.httpGet(this.apiSets.userConversationsApi, a).then(function(e) {
                                return r(e.conversations), e
                            })
                        },
                        getConversations: function(e) {
                            e = {
                                ids: e,
                                include_messages: !0,
                                include_participants: !0,
                                include_user_data: !0
                            };
                            return i.httpPost(this.apiSets.getConversationsApi, e).then(function(e) {
                                return r(e.conversations), e.conversations
                            })
                        },
                        addToConversation: function(e, a) {
                            e = {
                                conversation_id: a,
                                user_ids: e
                            };
                            return i.httpPost(this.apiSets.addToConversationApi, e)
                        },
                        removeFromConversation: function(e, a) {
                            e = {
                                conversation_id: a,
                                user_ids: [e]
                            };
                            return i.httpPost(this.apiSets.removeFromConversationApi, e)
                        },
                        startOneToOneConversation: function(e) {
                            e = {
                                conversations: [{
                                    type: "one_to_one",
                                    participant_user_ids: [e]
                                }],
                                include_user_data: !0
                            };
                            return i.httpPost(this.apiSets.startOneToOneConversationApi, e).then(function(e) {
                                return r(e.conversations), e.conversations[0]
                            })
                        },
                        startGroupConversation: function(e, a) {
                            e = {
                                conversations: [{
                                    type: "group",
                                    name: a,
                                    participant_user_ids: e
                                }],
                                include_user_data: !0
                            };
                            return i.httpPost(this.apiSets.startGroupConversationApi, e).then(function(e) {
                                return r(e.conversations), e.conversations[0]
                            })
                        },
                        getMessages: function(e, a, t) {
                            if (!e) return new Promise(function(e) {
                                return {
                                    messages: []
                                }
                            });
                            t = {
                                conversation_id: e,
                                cursor: a,
                                pageSize: t
                            };
                            return i.httpGet(this.apiSets.getMessagesApi, t)
                        },
                        getMessagesByPageSize: function(i, e, r, n, s, o) {
                            var l = this;
                            this.getMessages(i.id, e, r).then(function(e) {
                                var a, t = e.messages;
                                t && 0 < t.length ? (a = 2 * r, t.forEach(function(e) {
                                    n.push(e)
                                }), function(e, a) {
                                    if (!e || !e.chatMessages || e.chatMessages.length <= 0) return !1;
                                    for (var t = 0; t < a.length; t++)
                                        if (a[t].id === e.chatMessages[0].id) return !1;
                                    return !0
                                }(i, t) && a <= c.dialogParams.pageSizeOfGetMessages && t.length === r ? l.getMessagesByPageSize(i, e.next_cursor, a, n, s, o) : s(o)) : t && 0 === t.length && s(o)
                            })
                        },
                        markAsRead: function(e) {
                            e = {
                                conversation_ids: [e]
                            };
                            return i.httpPost(this.apiSets.markAsReadApi, e)
                        },
                        sendMessage: function(e, a) {
                            a = {
                                conversation_id: e,
                                messages: [{
                                    content: a
                                }]
                            };
                            return i.httpPost(this.apiSets.sendMessageApi, a).then(function(e) {
                                return {
                                    data: e.messages[0]
                                }
                            })
                        },
                        renameGroupConversation: function(e, a) {
                            a = {
                                conversations: [{
                                    id: e,
                                    name: a
                                }]
                            };
                            return i.httpPost(this.apiSets.renameGroupConversationApi, a).then(function(e) {
                                var a;
                                return null !== (a = null == e || null === (a = e.conversations) || void 0 === a ? void 0 : a[0]) && void 0 !== a ? a : {}
                            })
                        },
                        updateUserTypingStatus: function(e) {
                            e = {
                                conversation_id: e
                            };
                            return i.httpPost(this.apiSets.updateUserTypingStatusApi, e)
                        },
                        sendPerformanceData: function(e, a) {
                            a = {
                                featureName: "Chat",
                                measureName: e,
                                value: a
                            };
                            return i.httpPost(this.apiSets.uiPerformanceTrackingApi, a)
                        }
                    }
                }
                i.$inject = ["$q", "chatUtility", "httpService", "$log", "apiParamsInitialization"], t.Z.factory("chatService", i), a.default = i
            },
            2109: function(e, a, t) {
                "use strict";
                t.r(a);
                var v = t(792),
                    i = t(5734),
                    f = t.n(i),
                    t = t(9472);

                function r(s, e, l, a, t, i, r, n, o, c, d, u, g, p) {
                    function h(e) {
                        return f().isDefined(v.Linkify) && "function" == typeof v.Linkify.String ? v.Linkify.String(e.escapeHTML()) : e
                    }

                    function y(e) {
                        e = e.match(g.gameCardRegexs.privateServerLinkCode);
                        if (e && 2 == e.length) return {
                            privateServerLinkCode: e[1]
                        }
                    }

                    function m(e, a) {
                        return {
                            content: e,
                            isEmoji: a
                        }
                    }
                    return {
                        linksLibrary: f().copy(d.linksLibrary),
                        chatLayout: f().copy(d.chatLayout),
                        chatApiParams: f().copy(u.chatApiParams),
                        dialogParams: f().copy(u.dialogParams),
                        dialogLayoutResetConstant: f().copy(l.dialogLayoutResetConstant),
                        dialogLayout: f().copy(l.dialogLayout),
                        dialogBannerTypes: f().copy(l.dialogBannerTypes),
                        userPresenceTypes: f().copy(r.userPresenceTypes),
                        dialogType: f().copy(l.dialogTypes),
                        newGroup: f().copy(l.newGroup),
                        scrollBarType: f().copy(l.scrollBarTypes),
                        errorMessages: f().copy(d.errors),
                        pendingStatus: f().copy(l.pendingStatus),
                        moderationType: f().copy(l.moderationType),
                        dialogInitValue: f().copy(l.dialogInitValue),
                        dialogStatus: f().copy(l.dialogStatus),
                        conversationInitStatus: f().copy(l.conversationInitStatus),
                        conversationType: f().copy(l.conversationType),
                        messageSenderType: f().copy(l.messageSenderType),
                        notificationsName: a,
                        channelsNotificationType: t,
                        notificationType: i,
                        activeType: f().copy(l.activeType),
                        performanceMarkLabels: o.chat,
                        resultType: {
                            SUCCESS: "success",
                            MODERATED: "moderated"
                        },
                        sendMessageErrorCode: n.sendMessageErrorCode,
                        linkCardTypes: f().copy(g.linkCardTypes),
                        eventStreamParams: f().copy(c.eventStreamParams),
                        urlParamNames: f().copy(c.urlParamNames),
                        chatEnabledByPrivacySettingTypes: {
                            disabled: "disabled",
                            enabled: "enabled",
                            unavailable: "unavailable"
                        },
                        whoCanChatWithMeInAppTypes: {
                            noOne: "NoOne",
                            friends: "Friends",
                            friendsAndFriendsOfFriends: "FriendsAndFriendsOfFriends"
                        },
                        getIsChatEnabled: function(e) {
                            var a, t;
                            return e.isWebChatSettingsMigrationEnabled ? (null === (a = e.chatLayout) || void 0 === a ? void 0 : a.isChatEnabled) && (null === (t = e.chatLayout) || void 0 === t ? void 0 : t.whoCanChatWithMeInAppTypes) && (e.chatLayout.whoCanChatWithMeInApp === e.chatLayout.whoCanChatWithMeInAppTypes.friends || e.chatLayout.whoCanChatWithMeInApp === e.chatLayout.whoCanChatWithMeInAppTypes.friendsAndFriendsOfFriends) : (null === (t = e.chatLayout) || void 0 === t ? void 0 : t.isChatEnabled) && (null === (t = e.chatLayout) || void 0 === t ? void 0 : t.chatEnabledByPrivacySettingTypes) && e.chatLayout.isChatEnabledByPrivacySetting === e.chatLayout.chatEnabledByPrivacySettingTypes.enabled
                        },
                        hashOutContent: function(e) {
                            return e && e.replace(/\S/g, "#")
                        },
                        buildScrollbar: function(e) {
                            f().element(document.querySelector(e)).mCustomScrollbar({
                                autoExpandScrollbar: !1,
                                scrollInertia: 1,
                                contentTouchScroll: 1,
                                mouseWheel: {
                                    preventDefault: !0
                                }
                            })
                        },
                        updateScrollbar: function(e) {
                            f().element(document.querySelector(e)).mCustomScrollbar("update")
                        },
                        htmlEntities: function(e) {
                            return String(e).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;")
                        },
                        getAssetDetails: y,
                        buildLinkCard: function(e) {
                            var a, t, i = h(e),
                                r = {
                                    content: i,
                                    isCard: !1
                                },
                                n = g.messageRegexs;
                            for (a in n) n.hasOwnProperty(a) && (t = n[a], (t = e.match(t)) && 2 === t.length && (r = {
                                id: t[1],
                                type: a,
                                isCard: !0,
                                content: i,
                                assetDetails: y(e)
                            }));
                            return this.buildEmojiPieces(r), r
                        },
                        buildEmojiPieces: function(e) {
                            e.pieces = [];
                            for (var a = e.content, t = g.emojiRegex, i = g.zwjRegex, r = g.emojiRepRegex, n = "", s = !1, o = 0; null !== (c = t.exec(a));) {
                                var l = c.index,
                                    c = c[0];
                                o !== l ? (n && e.pieces.push(m(n, !0)), e.pieces.push(m(a.slice(o, l), !1)), n = c) : null != c.match(i) ? (n += "&zwj;", s = !0) : s || null != c.match(r) ? (n += c, s = !1) : (n && e.pieces.push(m(n, !0)), n = c), o = t.lastIndex
                            }
                            n && e.pieces.push(m(n, !0)), o < a.length && e.pieces.push(m(a.slice(o), !1))
                        },
                        buildLinkCardMessages: function(e) {
                            var a = e.parsedContent;
                            if (a && 0 < a.length) {
                                var t = a.split(g.urlRegex);
                                if (!t) return e.hasLinkCard = !1;
                                e.linkCardMessages = [];
                                for (var i = 0; i < t.length; i++) {
                                    var r = t[i],
                                        n = null;
                                    r.match(g.urlRegex) ? n = this.buildLinkCard(r) : r && 0 < r.length && !r.match(g.onlyNewLineRegex) && (n = {
                                        content: r = h(r = r.replace(g.removeNewLineRegex, "")),
                                        isCard: !1
                                    }, this.buildEmojiPieces(n)), n && e.linkCardMessages.push(n)
                                }
                            }
                            return !0
                        },
                        sortFriendList: function(t, e) {
                            var a = s("orderBy"),
                                i = [],
                                r = [],
                                n = [];
                            return t.friendIds.forEach(function(e) {
                                var a = t.friendsDict[e];
                                (0 < (a && a.presence ? a.presence : a).userPresenceType ? i : r).push(a), n.push(e)
                            }), f().forEach(e, function(e) {
                                n.indexOf(e.id) < 0 && (0 < (e && e.presence ? e.presence : e).userPresenceType ? i : r).push(e), t.friendIds.indexOf(e.id) < 0 && t.friendIds.push(e.id)
                            }), i = a(i, "+name"), r = a(r, "+name"), e = i.concat(r)
                        },
                        getScrollBarSelector: function(e, a) {
                            var t = e.layoutId;
                            switch (f().isUndefined(a) && (a = e.scrollBarType), a) {
                                case l.scrollBarTypes.FRIENDSELECTION:
                                    return "#scrollbar_friend_" + e.dialogType + "_" + t;
                                case l.scrollBarTypes.MESSAGE:
                                default:
                                    return "#scrollbar_" + e.dialogType + "_" + t
                            }
                        },
                        hasLinkifyContent: function(e) {
                            return f().isString(e) && 0 <= e.search("<a") && 0 <= e.search("href=") && 0 <= e.search("text-link")
                        },
                        sanitizeMessage: function(e) {
                            var a, t;
                            e && e.content && (a = e.content, t = e.content, e.content = h(e.content), t !== e.content ? (e.parsedContent = a, e.hasLinkCard = !0, e.hasLinkifyMessage = this.hasLinkifyContent(e.content), this.buildLinkCardMessages(e)) : this.buildEmojiPieces(e))
                        },
                        sanitizeMessages: function(e) {
                            if (e && 0 < e.length)
                                for (var a = 0; a < e.length; a++) {
                                    var t = e[a];
                                    this.sanitizeMessage(t)
                                }
                        },
                        updateConversationTitle: function(e, a) {
                            e.title = a, e.name = a
                        },
                        updateDialogStyle: function(e, a, t) {
                            var i = a.defaultStyle;
                            i && i.inputStyle && this.setResizeInputLayout(t, i.inputStyle.height, e, a)
                        },
                        setResizeInputLayout: function(e, a, t, i) {
                            var r = e.layout,
                                n = r.topBarHeight,
                                e = (e = a, (a = i).maxHeightOfTextInput < e ? a.maxHeightOfInput : e),
                                n = (r.bannerHeight, i.renameEditor.isEnabled ? (r.renameEditorHeight, n + e + r.renameEditorHeight) : n + e),
                                r = r.dialogHeight - n + "px",
                                n = l.dialogLayoutResetConstant.paddingOfInput / 2;
                            i.defaultStyle.dialogStyle = {
                                height: r
                            }, i.defaultStyle.inputStyle = {
                                height: e
                            }, i.defaultStyle.inputTextStyle = {
                                "padding-top": n
                            }
                        },
                        calculateRightPosition: function(e, a) {
                            for (var t = this.chatLayout.widthOfDialog + this.chatLayout.spaceOfDialog, i = this.chatLayout.widthOfCollapsedDialog + this.chatLayout.spaceOfDialog, r = 0, n = 0; n < a; n++) {
                                var s, o = e.dialogIdList[n];
                                r += ((null === (s = e.dialogsLayout) || void 0 === s ? void 0 : s[o]) || f().copy(l.dialogLayout)).collapsed ? i : t
                            }
                            return r
                        },
                        updateDialogsPosition: function(e) {
                            for (var a = e.chatLayout, t = a.widthOfChat, i = 0; i < e.dialogIdList.length; i++) {
                                var r = "#" + e.dialogIdList[i],
                                    n = f().element(document.querySelector(r)).find(this.dialogLayout.dialogContainerClass),
                                    r = +t + this.calculateRightPosition(e, i) + a.spaceOfDialog;
                                n.css("right", r)
                            }
                            0 < e.minimizedDialogIdList.length && (e.chatLayout.areDialogsUpdated = !0)
                        },
                        updateFocusedDialog: function(e, a) {
                            p.debug(" ------ focused layoutId ------ " + a), e.chatLayout.focusedLayoutId = a
                        },
                        invalidateLinkCardsInMessageDict: function(e, t) {
                            e.forEach(function(e) {
                                var a;
                                t[a = e].linkCardMessages.forEach(function(e) {
                                    a === e.id && (e.isCard = !1)
                                })
                            })
                        },
                        invalidatePlaceDetails: function(a, e) {
                            e.forEach(function(e) {
                                a.placesLibrary[e] || (a.placesLibrary[e] = {}), a.placesLibrary[e] = {
                                    isInvalid: !0
                                }
                            })
                        },
                        isPlaceDetailQualifiedInLibrary: function(e, a) {
                            return e[a] && e[a].reasonProhibited
                        }
                    }
                }
                r.$inject = ["$filter", "$window", "dialogAttributes", "notificationsName", "channelsNotificationType", "notificationType", "presenceLayout", "httpResponse", "performanceMarkLabels", "resources", "libraryInitialization", "apiParamsInitialization", "messageHelper", "$log"], t.Z.factory("chatUtility", r), a.default = r
            },
            7044: function(e, a, t) {
                "use strict";
                t.r(a);
                var l = t(792),
                    i = t(5734),
                    c = t.n(i),
                    t = t(9472);

                function r(e, t, n) {
                    function s(e, a) {
                        return (i = a)[t = e] && c().isDefined(i[t].avatarHeadshot) && ((a = a)[e = e] && c().isDefined(a[e].userPresenceType));
                        var t, i
                    }

                    function o(e) {
                        var a;
                        return e.conversationUniverse && (a = {
                            rootPlaceId: e.conversationUniverse.rootPlaceId,
                            universeId: e.conversationUniverse.universeId,
                            actorUsername: l.CurrentUser.name,
                            userId: parseInt(l.CurrentUser.userId)
                        }, t.setPinGameData(e, a)), e
                    }
                    return {
                        buildPinGameInConversation: o,
                        getUserIdsNotInFriendsDict: function(e, i) {
                            var a, t, r = [];
                            return e && 0 < e.length && (a = n.conversationType, t = n.dialogTypes, e.forEach(function(e) {
                                e.isGroupChat = e.type === a.multiUserConversation, c().forEach(e.participants, function(e) {
                                    var a, t = e.id;
                                    r.indexOf(t) < 0 && !s(t, i) && r.push(t), i[t] || (a = e.name, e = e.display_name, i[t] = {
                                        id: t,
                                        name: a,
                                        display_name: e,
                                        nameForDisplay: null !== l.DisplayNames && void 0 !== l.DisplayNames && l.DisplayNames.Enabled() ? e : a
                                    })
                                }), e.dialogType || (e.dialogType = e.isGroupChat ? t.GROUPCHAT : t.CHAT), o(e)
                            })), r
                        }
                    }
                }
                r.$inject = ["$log", "pinGameService", "dialogAttributes"], t.Z.factory("conversationsUtility", r), a.default = r
            },
            1171: function(e, a, t) {
                "use strict";
                t.r(a), t.d(a, {
                    default: function() {
                        return s
                    }
                });
                var a = jQuery,
                    i = t.n(a),
                    a = t(5734),
                    r = t.n(a),
                    t = t(9472);

                function n(e) {
                    return {
                        isCookieDefined: function(e) {
                            return r().isDefined(i().cookie(e)) && i().cookie(e)
                        },
                        updateCookie: function(e, a, t) {
                            i().cookie(e, JSON.stringify(a), t)
                        },
                        retrieveCookie: function(e) {
                            return this.isCookieDefined(e) ? JSON.parse(i().cookie(e)) : []
                        },
                        destroyCookie: function(e, a) {
                            i().cookie(e, null, a)
                        }
                    }
                }
                n.$inject = ["$log"], t.Z.factory("cookieService", n);
                var s = n
            },
            7333: function(e, a, t) {
                "use strict";
                t.r(a);
                t = t(9472);

                function i(e) {
                    var a = e,
                        t = {
                            default: -1,
                            member: 0,
                            game: 1
                        },
                        i = {
                            INIT: 0,
                            OPEN: 1,
                            REPLACE: 2,
                            MINIMIZE: 3,
                            COLLAPSE: 4,
                            REMOVE: 5,
                            REFRESH: 6
                        },
                        r = {
                            maxHeightOfTextInput: 64,
                            maxHeightOfInput: 80,
                            paddingOfInput: 16,
                            typing: {
                                isTypingAsSender: !1,
                                lastTimeTypingAsSender: null,
                                isTypingFromSender: !1,
                                lastTimeReceiveTypingEvent: null,
                                lastTimeReceiveTimer: null,
                                userIds: [],
                                userTypingDict: {}
                            },
                            hoverOnCollapsed: !1,
                            memberDisplay: {
                                limitNumber: 3,
                                defaultLimit: 3,
                                isAll: !1,
                                linkName: a.get("Label.SeeMore"),
                                seeMoreLink: a.get("Label.SeeMore"),
                                seeLessLink: a.get("Label.SeeLess"),
                                toastText: function(e) {
                                    return a.get("Message.ToastText", {
                                        friendNum: e
                                    })
                                },
                                timeoutToast: 5e3
                            },
                            playTogetherButton: {
                                buttonType: null,
                                isPlayButtonDisabled: !1
                            },
                            togglePopoverParams: {
                                isOpen: !1,
                                dialogSelector: "",
                                triggerSelector: "",
                                dialogSelectorPrefix: "#dialog-container-",
                                popoverTriggerSelectorPrefix: "#play-together-",
                                pinIconClassName: "pin-icon",
                                dialogTriggerClassSelector: "",
                                dialogTriggerClassPrefix: ".chat-friend-",
                                isFirstTimeOpen: !1
                            },
                            layoutId: null
                        },
                        e = {
                            FRIEND: -1,
                            CHAT: 0,
                            GROUPCHAT: 1,
                            NEWGROUPCHAT: 2,
                            ADDFRIENDS: 6
                        };
                    return {
                        activeType: {
                            NEWMESSAGE: "New message"
                        },
                        conversationInitStatus: {
                            remove: !1
                        },
                        conversationType: {
                            oneToOneConversation: "one_to_one",
                            multiUserConversation: "group"
                        },
                        dialogBannerTypes: t,
                        dialogInitValue: {
                            isUpdated: !0,
                            updateStatus: i.INIT,
                            markAsActive: !1,
                            activeType: null,
                            autoOpen: !1
                        },
                        dialogLayout: {
                            lookUpMembers: !1,
                            focusMeEnabled: !0,
                            hasFocus: !1,
                            isFocused: !1,
                            active: !1,
                            isChatLoading: !1,
                            collapsed: !1,
                            isConfirmationOn: !1,
                            isMembersOverloaded: !1,
                            scrollToBottom: !1,
                            IsdialogContainerVisible: !1,
                            inviteBtnDisabled: !0,
                            limitMemberDisplay: 6,
                            heightOfInput: 32,
                            maxHeightOfTextInput: r.maxHeightOfTextInput,
                            maxHeightOfInput: r.maxHeightOfInput,
                            paddingOfInput: r.paddingOfInput,
                            limitCharacterCount: 160,
                            heightOfBanner: 40,
                            templateUrl: "chat-dialog",
                            scrollbarElm: null,
                            listenToScrollInitialized: !1,
                            isBannerEnabled: !1,
                            renameEditor: {
                                isEnabled: !1,
                                hasFocus: !1
                            },
                            bannerType: t.default,
                            confirmDialog: {
                                isOpen: !1,
                                title: "",
                                btnName: "",
                                type: ""
                            },
                            typing: r.typing,
                            dialogContainerClass: ".dialog-container",
                            hoverOnCollapsed: !1,
                            details: {
                                isEnabled: !1,
                                isConversationTitleEditorEnabled: !1,
                                isAddFriendsEnabled: !1,
                                isNegativeConfirmationEnabled: !1,
                                friendMenuAction: {},
                                friendIdForMenuOn: null
                            },
                            memberDisplay: r.memberDisplay,
                            playTogetherButton: r.playTogetherButton,
                            togglePopoverParams: r.togglePopoverParams
                        },
                        dialogLayoutResetConstant: r,
                        dialogStatus: i,
                        dialogTypes: e,
                        pendingStatus: {
                            INVALID: "invalid",
                            PENDING: "pending",
                            NOT_PENDING: "not_pending"
                        },
                        moderationType: {
                            TRUSTED_COMMS: "trusted_comms",
                            MODERATED: "moderated",
                            INVALID: "invalid",
                            UNKNOWN_TYPE: "unknown_type"
                        },
                        messageSenderType: {
                            SYSTEM: "system",
                            USER: "user"
                        },
                        negativeAction: {
                            removeUser: {
                                title: a.get("Heading.RemoveUser"),
                                headerTitle: a.get("Heading.RemoveUser"),
                                btnName: a.get("Action.Remove"),
                                cancelBtnName: a.get("Action.Cancel"),
                                type: "removeUser"
                            },
                            leaveChatGroup: {
                                title: a.get("Heading.ConfirmLeaving"),
                                headerTitle: a.get("Heading.LeaveChatGroup"),
                                btnName: a.get("Action.Leave"),
                                cancelBtnName: a.get("Action.Stay"),
                                type: "leaveChatGroup"
                            }
                        },
                        newGroup: {
                            dialogType: e.NEWGROUPCHAT,
                            layoutId: "newGroup",
                            title: a.get("Heading.NewChatGroup")
                        },
                        scrollBarTypes: {
                            MESSAGE: 0,
                            FRIENDSELECTION: 1
                        },
                        systemMessage: {
                            isSystemMessage: !0,
                            isErrorMsg: !1
                        }
                    }
                }
                i.$inject = ["languageResource"], t.Z.factory("dialogAttributes", i), a.default = i
            },
            5585: function(e, a, t) {
                "use strict";
                t.r(a);
                t = t(9472);

                function i(e) {
                    var i = e;
                    return {
                        playButtonTypes: {
                            play: "play",
                            join: "join",
                            buy: "buy",
                            details: "details",
                            notAvailable: "notAvailable"
                        },
                        playButtons: {
                            play: {
                                type: "play",
                                text: i.get("Label.PlayButton"),
                                className: "btn-primary-xs btn-growth-xs",
                                isPlayable: !0
                            },
                            join: {
                                type: "join",
                                text: i.get("Label.JoinButton"),
                                className: "btn-primary-xs btn-growth-xs",
                                isPlayable: !0
                            },
                            buy: {
                                type: "buy",
                                text: i.get("Label.BuyButton"),
                                className: "btn-control-xs",
                                isPlayable: !1
                            },
                            details: {
                                type: "details",
                                text: i.get("Label.ViewDetailsButton"),
                                className: "btn-control-xs",
                                isPlayable: !1
                            },
                            notAvailable: {
                                type: "notAvailable",
                                text: i.get("Label.GameNotAvailableButton"),
                                isPlayable: !1
                            }
                        },
                        buyAccess: {
                            title: i.get("Heading.BuyItem"),
                            yesButtonText: i.get("Action.BuyAccess"),
                            yesButtonClass: "btn-primary-xs btn-growth-xs",
                            noButtonText: i.get("Action.Cancel"),
                            bodyText: function(e, a, t) {
                                e = "<span class='font-bold'>".concat(e, "</span>"), t = "<span class='icon-robux-16x16'></span><span class='text-robux'>".concat(t, "</span>");
                                return i.get("Label.BuyAccessToGameForModal", {
                                    placeName: e,
                                    creatorName: a,
                                    robux: t
                                })
                            }
                        }
                    }
                }
                i.$inject = ["languageResource"], t.Z.factory("gameLayout", i), a.default = i
            },
            5710: function(e, a, t) {
                "use strict";
                t.r(a);
                var r = t(792),
                    i = t(5734),
                    h = t.n(i),
                    t = t(9472);

                function n(o, t, e, i, a, l, s, c, d) {
                    var n = {};

                    function u(i, r) {
                        var e = {
                            placeIds: i
                        };
                        return t.httpGet(n.multiGetPlaceDetails, e).then(function(e) {
                            if (e && 0 < e.length) {
                                var a = {};
                                e.forEach(function(e) {
                                    a[e.placeId] = e
                                });
                                var t = [];
                                return i.forEach(function(e) {
                                    a[e] || (a[e] = null, t.push(e))
                                }), r.forEach(function(e) {
                                    e && e.linkCardMessages && e.linkCardMessages.forEach(function(e) {
                                        e.isCard && -1 < t.indexOf(e.id) && (e.isCard = !1)
                                    })
                                }), a
                            }
                        })
                    }

                    function g(r, e, n) {
                        h().forEach(e, function(e, t) {
                            if (e) {
                                var a;
                                r.placesLibrary[t] && (a = r.placesLibrary[t]);
                                var i = e.creatorName || e.builder;
                                if (r.placesLibrary[t] = {
                                        universeId: e.universeId,
                                        placeId: t,
                                        rootPlaceId: e.universeRootPlaceId || e.placeId || e.rootPlaceId,
                                        placeName: e.name,
                                        encodedPlaceName: o.htmlEntities(e.name),
                                        creatorName: i,
                                        encodedCreatorName: o.htmlEntities(i),
                                        creatorId: e.creatorId || e.builderId,
                                        gameIconUrl: e.gameIconUrl,
                                        placeUrl: e.url || e.placeUrl,
                                        reasonProhibited: e.reasonProhibited,
                                        description: e.description,
                                        price: e.price,
                                        isPlayable: e.isPlayable,
                                        gameReferralUrl: e.gameReferralUrl
                                    }, a && h().forEach(a, function(e, a) {
                                        r.placesLibrary[t][a] || (r.placesLibrary[t][a] = e)
                                    }), e.reasonProhibited) switch (e.reasonProhibited) {
                                    case l.reasonProhibitedMessage.None:
                                    case l.reasonProhibitedMessage.Playable:
                                        r.placesLibrary[t].buttonLayoutForLinkCard = h().copy(s.playButtons.play);
                                        break;
                                    case l.reasonProhibitedMessage.PurchaseRequired:
                                    default:
                                        r.placesLibrary[t].buttonLayoutForLinkCard = h().copy(s.playButtons.details)
                                }
                                r.universeLibrary[e.universeId] = r.placesLibrary[t]
                            } else !e && r.placesLibrary[t] && (r.placesLibrary[t] = {
                                isInvalid: !0
                            }, n && o.invalidateLinkCardInPieceOfMessage(t, n))
                        })
                    }

                    function p(a, e) {
                        e.forEach(function(e) {
                            a.placesLibrary[e] || (a.placesLibrary[e] = {}), a.placesLibrary[e] = {
                                isInvalid: !0
                            }
                        })
                    }
                    return {
                        apiSets: n,
                        setParams: function(e) {
                            n.multiGetPlaceDetails = {
                                url: e + a.gameUrls.multiGetPlaceDetails,
                                retryable: !0,
                                withCredentials: !0
                            }, n.getGamesByUniverseIds = {
                                url: a.gameUrls.getGamesByUniverseIds,
                                retryable: !0,
                                withCredentials: !0
                            }, n.multiGetPlayabilityStatus = {
                                url: a.gameUrls.multiGetPlayabilityStatus,
                                retryable: !0,
                                withCredentials: !0
                            }
                        },
                        setConversationUniverse: function(e, a) {
                            a = {
                                conversationId: e,
                                universeId: a
                            };
                            return t.httpPost(n.setConversationUniverse, a)
                        },
                        resetConversationUniverse: function(e) {
                            e = {
                                conversationId: e
                            };
                            return t.httpPost(n.resetConversationUniverse, e)
                        },
                        multiGetPlaceDetailsForLinkCard: u,
                        multiGetPlaceDetails: function(e) {
                            return e = {
                                placeIds: e
                            }, t.httpGet(n.multiGetPlaceDetails, e).then(function(e) {
                                var a = {};
                                return h().forEach(e, function(e) {
                                    a[e.placeId] = e
                                }), a
                            })
                        },
                        playRegularGame: function(e, a, t, i) {
                            a = !0 === a, r.GameLauncher.joinMultiplayerGame(e, !0, a, t, i)
                        },
                        playTogetherGame: function(e, a, t, i) {
                            r.GameLauncher.playTogetherGame(e, a, t, i)
                        },
                        joinGame: function(e, a, t, i) {
                            r.GameLauncher.joinGameInstance(e, a, !0, !0, t, i)
                        },
                        playPrivateServerGame: function(e, a, t, i) {
                            r.GameLauncher.joinPrivateGame(e, null, a, t, i)
                        },
                        fetchDataForLinkCard: function(e, i) {
                            if (!e) return !1;
                            var r = [],
                                n = {},
                                s = [];
                            e.forEach(function(t) {
                                t.hasLinkCard && t.linkCardMessages.forEach(function(e) {
                                    var a;
                                    e.isCard && e.type === o.linkCardTypes.gameCard && (a = e.id, o.isPlaceDetailQualifiedInLibrary(i.placesLibrary, a) ? i.placesLibrary[a] && i.placesLibrary[a].isInvalid && (e.isCard = !1) : (s.push(t), r.indexOf(a) < 0 && (r.push(a), n[a] = t)))
                                })
                            }), 0 < r.length && u(r, s).then(function(e) {
                                return e ? void g(i, e, n) : (p(i, r), o.invalidateLinkCardsInMessageDict(r, n), !1)
                            }, function() {
                                p(i, r), o.invalidateLinkCardsInMessageDict(r, n)
                            })
                        },
                        updateButtonLayoutPerConversation: function(e, a) {
                            if (!e.placeButtonLayout || e.placeButtonLayout && !e.placeButtonLayout[a].isPlayable) return !1;
                            e.pinGame && e.playTogetherIds && -1 < e.playTogetherIds.indexOf(a) ? e.placeButtonLayout[a] = h().copy(s.playButtons.join) : e.placeButtonLayout[a] = h().copy(s.playButtons.play)
                        },
                        buildButtonLayoutPerConversation: function(t, i) {
                            var e = [],
                                r = null,
                                n = !0;
                            t.playTogetherIds && 0 < t.playTogetherIds.length && (e = h().copy(t.playTogetherIds)), t.pinGame && (r = t.pinGame.rootPlaceId, e.indexOf(r) < 0 && (n = !1, e.push(r))), t.placeButtonLayout || (t.placeButtonLayout = {}), h().forEach(e, function(e) {
                                var a = i[e];
                                if (a) switch (a.reasonProhibited) {
                                    case l.reasonProhibitedMessage.None:
                                    case l.reasonProhibitedMessage.Playable:
                                        t.placeButtonLayout[e] = n || e !== r ? h().copy(s.playButtons.join) : h().copy(s.playButtons.play);
                                        break;
                                    case l.reasonProhibitedMessage.PurchaseRequired:
                                        t.placeButtonLayout[e] = h().copy(s.playButtons.details);
                                        break;
                                    default:
                                        t.placeButtonLayout[e] = h().copy(s.playButtons.notAvailable)
                                }
                            })
                        },
                        buildPlacesLibrary: g,
                        getGames: function(e) {
                            var a = {
                                    universeIds: e
                                },
                                e = {};
                            return e.getGamesInfo = t.httpGet(n.getGamesByUniverseIds, a), e.getPlayabilityStatus = t.httpGet(n.multiGetPlayabilityStatus, a), i.all(e).then(function(e) {
                                if (e && e.getGamesInfo && e.getPlayabilityStatus) {
                                    var a = e.getGamesInfo.data,
                                        r = e.getPlayabilityStatus,
                                        n = {},
                                        s = {};
                                    return h().forEach(a, function(e, a) {
                                        var t = e.rootPlaceId,
                                            i = r[a].universeId;
                                        n[t] = e, n[t].universeId = i, n[t].placeId = t, n[t].isPlayable = r[a].isPlayable, n[t].reasonProhibited = r[a].playabilityStatus, n[t].placeUrl = (e = n[t], a = c.getAbsoluteUrl(l.gameUrl), d("formatString")(a, {
                                            placeId: e.placeId
                                        })), s[i] = n[t]
                                    }), n
                                }
                            })
                        }
                    }
                }
                n.$inject = ["chatUtility", "httpService", "$log", "$q", "apiParamsInitialization", "gameParameters", "gameLayout", "urlService", "$filter"], t.Z.factory("gameService", n), a.default = n
            },
            3333: function(e, a, t) {
                "use strict";
                t.r(a);
                var i = t(5734),
                    r = t.n(i),
                    t = t(9472);

                function n(e) {
                    return {
                        isGameExistedInPlacesLibrary: function(e, a) {
                            var t = null;
                            return r().forEach(e, function(e) {
                                if (e.universeId === a) return t = e.placeId, !1
                            }), t
                        }
                    }
                }
                n.$inject = ["$log"], t.Z.factory("gameUtility", n), a.default = n
            },
            6331: function(e, a, t) {
                "use strict";
                t.r(a);
                var i = t(792),
                    t = t(9472);

                function r(e) {
                    var a = e,
                        e = {
                            scrollbarClassName: "#chat-friend-list",
                            chatContentSelector: "#chat-main",
                            collapsed: !0,
                            pageInitializing: !1,
                            pageDataLoading: !1,
                            chatBarInitialized: !1,
                            isChatLoading: !1,
                            widthOfChatCollapsed: 112,
                            widthOfChat: 286,
                            widthOfDialog: 260,
                            widthOfCollapsedDialog: 160,
                            spaceOfDialog: 6,
                            widthOfDialogMinimize: 200,
                            numberOfDialogOpen: 0,
                            defaultChatZIndex: 1060,
                            errorMaskEnable: !1,
                            isFriendListEmpty: !1,
                            isUserConversationEmpty: !1,
                            chatLandingEnabled: !1,
                            thresholdMobile: 543,
                            thresholdChatBarOpen: 1748,
                            resizing: !1,
                            defaultTitleForMessage: a.get("Message.DefaultTitleForMsg"),
                            urlParseInitialized: !1,
                            noConnectionMsg: a.get("Message.NoConnectionMsg"),
                            isChatEnabledByPrivacySetting: 1,
                            focusedDialogId: null,
                            areDialogsUpdated: !1,
                            maxOpenDialogs: 12,
                            conversationTitleChangedText: a.get("Message.conversationTitleChangedText"),
                            abuseReportUrl: "/abusereport/chat?id={userId}&redirectUrl={location}&conversationId={conversationId}"
                        },
                        a = {
                            default: a.get("Message.DefaultErrorMsg"),
                            conversationTitleModerated: a.get("Message.ConversationTitleModerated"),
                            messageContentModerated: a.get("Message.MessageContentModerated"),
                            messageFilterForReceivers: a.get("Message.MessageFilterForReceivers"),
                            textTooLong: a.get("Message.TextTooLong"),
                            sendingMessagesTooQuickly: a.get("Message.SendingMessagesTooQuickly"),
                            sendMessageConflict: a.get("Message.RefreshChat")
                        };
                    return {
                        chatLayout: e,
                        chatLibrary: {
                            chatLayout: e,
                            chatLayoutIds: [],
                            conversationsDict: {},
                            currentTabTitle: null,
                            dialogIdList: [],
                            dialogDict: {},
                            dialogScopeLib: {},
                            dialogsLayout: {},
                            dialogRequestedToOpenParams: {
                                layoutId: null,
                                autoPop: !1
                            },
                            errors: a,
                            friendIds: [],
                            friendLayoutIds: [],
                            friendsDict: {},
                            isTakeOverOn: angular.element(document.querySelector("#wrap")).data("gutter-ads-enabled"),
                            layout: {
                                bannerHeight: 40,
                                playTogetherBannerHeight: 102,
                                dialogHeight: 360,
                                inputHeight: 32,
                                renameEditorHeight: 32,
                                searchHeight: 32,
                                topBarHeight: 32,
                                detailsActionHeight: 48,
                                detailsInputHeight: 32
                            },
                            layoutIdList: [],
                            minimizedDialogIdList: [],
                            minimizedDialogData: {},
                            userConversationsDict: {},
                            allConversationLayoutIdsDict: {},
                            placesLibrary: {},
                            playTogetherLibrary: {},
                            layoutIdsDictPerUserId: {},
                            gamesPageLink: "".concat(i.EnvironmentUrls.websiteUrl, "/discover"),
                            isMetaDataLoaded: !1,
                            universeLibrary: {},
                            voiceChannelMapToConversation: {}
                        },
                        chatViewModel: {
                            friendsDict: {},
                            chatUserDict: {}
                        },
                        dialogLocalStorageNamePrefix: "dialogLibrary_",
                        errors: a,
                        linksLibrary: {
                            settingTabName: "Settings",
                            settingLink: "/my/account#!/privacy",
                            trustedCommsLearnMoreLink: "https://help.roblox.com/"
                        }
                    }
                }
                r.$inject = ["languageResource"], t.Z.factory("libraryInitialization", r), a.default = r
            },
            2370: function(e, a, t) {
                "use strict";
                t.r(a);
                var i = t(5734),
                    L = t.n(i),
                    t = t(9472);

                function r(t, d, u, g, p, n, a, h, e, i, s, o, y) {
                    var r = 3e4;

                    function m(e) {
                        e.created_at && !e.parsedTimestamp && (e.parsedTimestamp = new Date(e.created_at).getTime())
                    }

                    function l(e, a, t) {
                        var i = e.parsedTimestamp,
                            r = L().isDefined(t) ? t : new Date,
                            n = new Date(r - 864e5),
                            s = new Date(i),
                            o = s.toDateString(),
                            l = Math.round(Math.abs(r.getTime() - s.getTime()) / 864e5),
                            c = s.getDay(),
                            d = r.getFullYear(),
                            t = s.getFullYear(),
                            s = "h:mm a";
                        r.toDateString() === o ? (r = g("date")(i, s), a ? e.briefTimeStamp = r : e.displayTimeStamp = r) : n.toDateString() === o ? a ? e.briefTimeStamp = "Yesterday" : e.displayTimeStamp = "Yesterday | ".concat(g("date")(i, s)) : l <= c ? a ? (s = "EEE", e.briefTimeStamp = g("date")(i, s)) : (s = "EEE | ".concat(s), e.displayTimeStamp = g("date")(i, s)) : d === t ? a ? (s = "MMM d", e.briefTimeStamp = g("date")(i, s)) : (s = "MMM d | ".concat(s), e.displayTimeStamp = g("date")(i, s)) : a ? (s = "MMM d, yyyy", e.briefTimeStamp = g("date")(i, s)) : (s = "MMM d, yyyy | " + s, e.displayTimeStamp = g("date")(i, s))
                    }
                    var c, v, f = (v = !(c = {}), {
                        queueMessageToMarkRead: function(e) {
                            !(c[e.id] = {
                                conversation: e
                            }) === v && (v = !0, a(b, 1e3))
                        }
                    });

                    function b() {
                        for (var e in c) {
                            var a = c[e];
                            t.markAsRead(e).then(function(e) {
                                a.conversation.hasUnreadMessages = !1, u.$broadcast("Roblox.Chat.LoadUnreadConversationCount")
                            }, function() {
                                p.debug("----- markAsRead request is failed ! ------")
                            })
                        }
                        v = !(c = {})
                    }
                    return {
                        setParams: function(e) {
                            r = parseInt(e.partyChromeDisplayTimeStampInterval)
                        },
                        setFallbackClusterMaster: function(e, a) {
                            L().isUndefined(e.chatMessages) && (e.chatMessages = []);
                            var t = e.chatMessages.length - 1;
                            a.displayTimeStamp && (a.isClusterMaster = !0), 0 < e.chatMessages.length && e.chatMessages[t].sender_user_id !== a.sender_user_id && (e.chatMessages[t].isClusterMaster = !0), e.chatMessages.push(a)
                        },
                        setClusterMaster: function(e, a) {
                            L().isUndefined(e.chatMessages) && (e.chatMessages = []), (0 < e.chatMessages.length && e.chatMessages[0].sender_user_id !== a.sender_user_id || a.displayTimeStamp) && (a.isClusterMaster = !0), a.resetClusterMessage || e.chatMessages.unshift(a)
                        },
                        buildFallbackTimeStamp: function(e, a, t) {
                            if (!e.created_at) return !1;
                            m(e);
                            var i = e.parsedTimestamp;
                            (!a.startTimeStamp || i + r < a.startTimeStamp) && (l(e, !1, t), a.startTimeStamp = i)
                        },
                        buildTimeStamp: function(e, a, t) {
                            if (!e.created_at) return !1;
                            m(e);
                            var i = e.parsedTimestamp;
                            return a.previousTimeStamp || (a.startTimeStamp = i), (!a.previousTimeStamp || i - r > a.previousTimeStamp) && (l(e, !1, t), a.previousTimeStamp = i), !0
                        },
                        preProcessMessages: function(e, a, t) {
                            d.sanitizeMessages(t)
                        },
                        processMessages: function(e, a, t, i) {
                            this.preProcessMessages(e, a, t), this.manipulateMessages(a, t, i)
                        },
                        manipulateMessages: function(e, a, t) {
                            if (a || (e.messagesDict = {}), L().isUndefined(e.messagesDict) && (e.messagesDict = {}), a && 0 < a.length) {
                                var i = a.length,
                                    r = [];
                                e.previousTimeStamp = null;
                                for (var n = i - 1; 0 <= n; n--) {
                                    var s = a[n];
                                    this.buildTimeStamp(s, e), s.type === d.messageSenderType.SYSTEM && (s.isSystemMessage = !0), e.messagesDict[s.id] || (e.messagesDict[s.id] = s, this.setClusterMaster(e, s)), l = t, c = r, (o = s).type === h.messageTypes.user && (l && !l[o.sender_user_id] && c.indexOf(o.sender_user_id) < 0) && (o = s.sender_user_id, p.debug(" ----- new friend information for this message, trying to get now -----" + o), s = [o], r.push(o), y.getUserInfo(s, t))
                                }
                                e.hasUnreadMessages && u.$broadcast("Roblox.Chat.LoadUnreadConversationCount")
                            }
                            var o, l, c
                        },
                        formatTimestampInConversation: function(e) {
                            e.briefTimeStamp || (e.parsedTimestamp = new Date(e.updated_at).getTime(), l(e, !0))
                        },
                        appendMessages: function(e, a, t) {
                            if (!t) return !1;
                            if (L().isUndefined(a.messagesDict) && (a.messagesDict = {}), d.sanitizeMessages(t), a.chatMessages && 0 !== a.chatMessages.length) {
                                if (a.chatMessages) {
                                    for (var i = {}, r = 0; r < a.chatMessages.length; r++) {
                                        var n = a.chatMessages[r];
                                        if (n.id && !n.sendMessageHasError && !n.resetClusterMessage) {
                                            m(i = a.chatMessages[r]);
                                            break
                                        }
                                    }
                                    for (r = t.length - 1; 0 <= r; r--) {
                                        (l = t[r]).type === d.messageSenderType.SYSTEM && (l.isSystemMessage = !0), m(l);
                                        var s = l.id === i.id || i.id && "string" != typeof i.id && i.id.toString() === l.id,
                                            o = !L().isUndefined(l.id) && !L().isUndefined(a.messagesDict[l.id]);
                                        !(L().equals({}, i) || l.parsedTimestamp > i.parsedTimestamp) || s || o || (this.buildTimeStamp(l, a), this.setClusterMaster(a, l), (a.messagesDict[l.id] = l).sender_user_id !== e.userId && l.is_badgeable && (a.hasUnreadMessages = !0))
                                    }
                                }
                            } else {
                                for (var l, r = t.length - 1; 0 <= r; r--)(l = t[r]).type === d.messageSenderType.SYSTEM && (l.isSystemMessage = !0), this.buildTimeStamp(l, a), this.setClusterMaster(a, l), L().isDefined(l.id) && (a.messagesDict[l.id] = l), l.sender_user_id !== e.userId && l.is_badgeable && (a.hasUnreadMessages = !0);
                                a.chatMessages = t
                            }
                            var c = 0 < t.length ? t[0] : {};
                            a.displayMessage = this.buildDisplayMessage(c), 0 < a.hasUnreadMessages && u.$broadcast("Roblox.Chat.LoadUnreadConversationCount")
                        },
                        markMessagesAsRead: function(e, a) {
                            e.dialogType !== d.dialogType.FRIEND && (e.chatMessages || a) && e.hasUnreadMessages && f.queueMessageToMarkRead(e)
                        },
                        buildSystemMessage: function(e, a, t) {
                            var i = L().copy(o.systemMessage);
                            switch (s.setSystemMessage(i, t), e) {
                                case d.notificationType.conversationTitleModerated:
                                    i.content = d.errorMessages.conversationTitleModerated;
                                    break;
                                case d.notificationType.conversationTitleChanged:
                                    var r = d.htmlEntities(a.name);
                                    i.content = g("formatString")(d.chatLayout.conversationTitleChangedText, {
                                        userName: a.actorUsername,
                                        groupName: r
                                    });
                                    break;
                                case d.notificationType.conversationUniverseChanged:
                                    i.content = n.playTogether.pinGameUpdate(a.pinGame.actorUsername, a.pinGame.encodedPlaceName);
                                    break;
                                case d.notificationType.presenceOnline:
                                    i.content = n.playTogether.playGameUpdate, i.hasParams = !0
                            }
                            L().isUndefined(a.messages) && (a.chatMessages = []), m(i), this.setClusterMaster(a, i)
                        },
                        resetConversationUnreadStatus: function(e, a) {
                            0 === a.length && e.hasUnreadMessages && f.queueMessageToMarkRead(e)
                        },
                        buildDisplayMessage: function(e, a) {
                            return m(e), l(e, !0, a), e
                        },
                        refreshTypingStatus: function(e, a, t, i) {
                            if (e && t && e.type === d.conversationType.multiUserConversation) {
                                var r = e.chatMessages;
                                if (r && 0 < r.length)
                                    for (var n = i.typing.userTypingDict[a], s = {}, o = 0; o < r.length; o++) {
                                        var l = r[o];
                                        if (l.isClusterMaster && l.sender_user_id === a && (!s[a] || s[a].messageId !== l.id)) {
                                            n.messageId = l.id;
                                            break
                                        }
                                    }
                            }
                        }
                    }
                }
                r.$inject = ["chatService", "chatUtility", "$rootScope", "$filter", "$log", "systemMessages", "$timeout", "messageHelper", "gameUtility", "gameService", "messageUtility", "dialogAttributes", "usersService"], t.Z.factory("messageService", r), a.default = r
            },
            1553: function(e, a, t) {
                "use strict";
                t.r(a);
                var i = t(5734),
                    r = t.n(i),
                    t = t(9472);

                function n(e, i, a) {
                    return {
                        isMessageTypeLegal: function(a) {
                            var t = !1;
                            return r().forEach(i.messageTypes, function(e) {
                                if (e === a.type) return !(t = !0)
                            }), t
                        },
                        setSystemMessage: function(t, e) {
                            t ? r().forEach(a.systemMessage, function(e, a) {
                                t[a] = e
                            }) : t = r().copy(a.systemMessage), e && (t.isErrorMsg = !0);
                            e = new Date;
                            t.created_at = e.toISOString()
                        },
                        hasUnreadMessages: function(e, a) {
                            return e.hasUnreadMessages || a.some(function(e) {
                                return !e.read
                            }), e.hasUnreadMessages
                        }
                    }
                }
                n.$inject = ["$log", "messageHelper", "dialogAttributes"], t.Z.factory("messageUtility", n), a.default = n
            },
            8549: function(e, a, t) {
                "use strict";
                t.r(a);
                t = t(9472);

                function i(e) {
                    return {
                        tooltipForPinGame: e.get("Label.PinGameTooltip"),
                        tooltipForUnPinGame: e.get("Label.UnpinGameTooltip"),
                        titleForPinGame: e.get("Label.PinnedGame")
                    }
                }
                i.$inject = ["languageResource"], t.Z.factory("pinGameLayout", i), a.default = i
            },
            2986: function(e, a, t) {
                "use strict";
                t.r(a);
                t = t(9472);

                function i(e, i, t, r, n) {
                    return {
                        sendPinGameEvent: function(e, a, t) {
                            t = {
                                placeId: a,
                                conversationId: t.id
                            };
                            r.sendEventWithTarget(e, n.eventStreamParams.actions.click, t)
                        },
                        setPinGameData: function(e, a) {
                            var t;
                            a && a.universeId ? (t = a.rootPlaceId, e.pinGame = {
                                universeId: a.universeId,
                                rootPlaceId: t,
                                placeName: a.placeName,
                                encodedPlaceName: a.encodedPlaceName,
                                actorUsername: a.actorUsername,
                                userId: a.userId
                            }) : e.pinGame = null, i.setPlaceForShown(e)
                        },
                        pinGame: function(e, a) {
                            e && a && t.setConversationUniverse(e.id, a)
                        },
                        unpinGame: function(e) {
                            e && t.resetConversationUniverse(e.id)
                        }
                    }
                }
                i.$inject = ["$log", "playTogetherService", "gameService", "eventStreamService", "resources"], t.Z.factory("pinGameService", i), a.default = i
            },
            7241: function(e, a, t) {
                "use strict";
                t.r(a);
                t = t(9472);

                function i(e) {
                    var a = e;
                    return {
                        numberOfMembers: {
                            inPinnedGame: 3,
                            inActiveGame: 4
                        },
                        gameListScrollListSelector: "#active-game-list",
                        activeGamesList: {
                            maxNumberForFit: 4,
                            minNumberForFit: 1,
                            limitNumber: 1,
                            showMore: function(e) {
                                return a.get("Label.ShowMoreGames", {
                                    count: e
                                })
                            },
                            showMoreText: "",
                            showLess: a.get("Label.ShowLessGames"),
                            toggleMenuText: "",
                            isCollapsed: !0,
                            pinGameIsInActiveGames: !1
                        },
                        recommendedLabel: a.get("Label.RecommendedGames")
                    }
                }
                i.$inject = ["languageResource"], t.Z.factory("playTogetherLayout", i), a.default = i
            },
            9123: function(e, a, t) {
                "use strict";
                t.r(a);
                var i = t(792),
                    r = t(5734),
                    c = t.n(r),
                    t = t(9472);

                function n(e) {
                    return {
                        isPlacePlayersOnlyMe: function(e, a) {
                            if (e.playTogetherDict && e.playTogetherDict[a]) {
                                a = e.playTogetherDict[a].playerIds;
                                if (a && 1 === a.length && a[0] === parseInt(i.CurrentUser.userId)) return !0
                            }
                            return !1
                        },
                        setPlaceForShown: function(e) {
                            var a, t;
                            e.playTogetherIds && 0 < e.playTogetherIds.length ? (t = e.playTogetherIds[0], this.isPlacePlayersOnlyMe(e, t) || (a = e.playTogetherDict[t].universeId, e.placeForShown = {
                                rootPlaceId: t,
                                universeId: a
                            })) : e.pinGame ? (a = (t = e.pinGame).rootPlaceId, t = t.universeId, e.placeForShown = {
                                rootPlaceId: a,
                                universeId: t
                            }) : e.placeForShown = null
                        },
                        sortPlayTogetherIds: function(i, e) {
                            if (!i || !e || !e.rootPlaceId) return !1;
                            var r, n = parseInt(e.rootPlaceId),
                                a = parseInt(e.placeId),
                                t = e.gameId,
                                s = parseInt(e.userId),
                                o = parseInt(e.universeId),
                                l = (l = e.lastOnline) && new Date(l).getTime();
                            if (!i.playTogetherIds) {
                                i.playTogetherIds = [n], i.playTogetherDict = {};
                                return !(i.playTogetherDict[n] = {
                                    playerIds: [s],
                                    gameInstanceId: t,
                                    lastSeen: l,
                                    placeId: a,
                                    universeId: o
                                })
                            }
                            i.playTogetherDict[n] ? i.playTogetherDict[n].placeId !== a && (i.playTogetherDict[n].placeId = a) : i.playTogetherDict[n] = {
                                playerIds: [s],
                                gameInstanceId: t,
                                lastSeen: l,
                                placeId: a,
                                universeId: o
                            }, i.playTogetherDict[n].playerIds.indexOf(s) < 0 && i.playTogetherDict[n].playerIds.push(s), i.playTogetherDict[n] && (r = i.playTogetherDict[n].playerIds.length, c().forEach(i.playTogetherIds, function(e, a) {
                                var t = i.playTogetherDict[e].playerIds;
                                if (-1 < t.indexOf(s) && n !== e && (t = t.indexOf(s), i.playTogetherDict[e].playerIds.splice(t, 1)), i.playTogetherDict[e].playerIds.length < r) return i.playTogetherIds.splice(a, 0, n), !1
                            }), i.playTogetherIds.indexOf(n) < 0 && i.playTogetherIds.push(n)), i.playTogetherDict[n].lastSeen < l && (i.playTogetherDict[n].gameInstanceId = t, i.playTogetherDict[n].lastSeen = l), i.recentPlaceIdFromPresence = e.rootPlaceId, i.recentUserIdFromPresence = e.userId
                        }
                    }
                }
                n.$inject = ["$log"], t.Z.factory("playTogetherService", n), a.default = n
            },
            4216: function(e, a, t) {
                "use strict";
                t.r(a);
                t = t(9472);

                function i(e) {
                    return {
                        userPresenceTypes: [{
                            className: "",
                            title: e.get("Label.Offline")
                        }, {
                            className: "online",
                            title: e.get("Label.Online")
                        }, {
                            className: "game",
                            title: e.get("Label.InGame")
                        }, {
                            className: "studio",
                            title: e.get("Label.InStudio")
                        }],
                        status: {
                            offline: 0,
                            online: 1,
                            inGame: 2,
                            inStudio: 3
                        }
                    }
                }
                i.$inject = ["languageResource"], t.Z.factory("presenceLayout", i), a.default = i
            },
            6162: function(e, a, t) {
                "use strict";
                t.r(a);
                var i = t(5734),
                    n = t.n(i),
                    t = t(9472);

                function r(i, e, t) {
                    var r = !1,
                        a = 1e4;
                    return {
                        chatDataName: {
                            getUserConversations: "getUserConversations",
                            getConversations: "getConversations",
                            getMessages: "getMessages"
                        },
                        setStorageParams: function(e) {
                            r = e.IsChatDataFromLocalStorageEnabled, a = 1e3 * e.ChatDataFromLocalStorageExpirationSeconds
                        },
                        getStorageName: function(e, a) {
                            var t = i.chatDataLSNamePrefix + "." + e;
                            return n().forEach(a, function(e) {
                                t = t + "." + e
                            }), t
                        },
                        saveChatDataToLocalStorage: function(e, a) {
                            r && t.saveDataByTimeStamp(e, a)
                        },
                        getChatDataFromLocalStorage: function(e) {
                            return r && t.fetchNonExpiredCachedData(e, a), null
                        },
                        clearLocalStorage: function() {
                            var e = t.storage();
                            if (e)
                                for (var a in e) a && -1 < a.search(i.chatDataLSNamePrefix) && t.removeLocalStorage(a)
                        }
                    }
                }
                r.$inject = ["resources", "$log", "localStorageService"], t.Z.factory("storageService", r), a.default = r
            },
            7563: function(e, a, t) {
                "use strict";
                t.r(a);
                t(5734);
                t = t(9472);

                function i(e) {
                    var t = e;
                    return {
                        playTogether: {
                            pinGameUpdate: function(e, a) {
                                return t.get("Message.PinGameUpdate", {
                                    userName: e,
                                    gameName: a
                                })
                            },
                            playGameUpdate: t.get("Message.PlayGameUpdate")
                        }
                    }
                }
                i.$inject = ["languageResource"], t.Z.factory("systemMessages", i), a.default = i
            },
            1106: function(e, a, t) {
                "use strict";
                t.r(a);
                t = t(9472);

                function i(e, a, t, i) {
                    return {
                        getChatUserSettings: function() {
                            return a.httpGet(i.apiSets.getUserSettings, {
                                requestedUserSettings: "whoCanChatWithMeInApp"
                            })
                        }
                    }
                }
                i.$inject = ["$q", "httpService", "$log", "apiParamsInitialization"], t.Z.factory("userSettingsService", i), a.default = i
            },
            3693: function(e, a, t) {
                "use strict";
                t.r(a);
                var n = t(792),
                    i = t(5734),
                    s = t.n(i),
                    t = t(9472);

                function r(t, i, r) {
                    return {
                        getAvatarHeadshots: function(e, t) {
                            var a = i.apiSets.multiGetAvatarHeadshots;
                            return r.buildBatchPromises(a, e, 50, "userIds").then(function(e) {
                                if (e && 0 < e.length) {
                                    var a = [];
                                    return s().forEach(e, function(e) {
                                        a = a.concat(e.data)
                                    }), s().forEach(a, function(e) {
                                        var a = e.targetId;
                                        t[a] || (t[a] = {}), t[a].avatarHeadshot = e
                                    }), a
                                }
                                return null
                            })
                        },
                        getUserPresence: function(e, t) {
                            var a = i.apiSets.multiGetPresence;
                            return r.buildBatchPromises(a, e, 100, "userIds", "POST").then(function(e) {
                                if (e && 0 < e.length) {
                                    var a = [];
                                    return s().forEach(e, function(e) {
                                        e = e.userPresences;
                                        a = a.concat(e)
                                    }), a.forEach(function(e) {
                                        var a = e.userId;
                                        t[a] || (t[a] = {}), t[a].presence = e, n.Endpoints && (t[a].profileUrl = n.Endpoints.generateAbsoluteUrl("/users/{id}/profile", {
                                            id: a
                                        }, !0))
                                    }), a
                                }
                                return null
                            })
                        },
                        getUserInfo: function(e, a) {
                            a = {
                                avatarHeadshots: this.getAvatarHeadshots(e, a),
                                presences: this.getUserPresence(e, a)
                            };
                            return t.all(a).then(function(e) {
                                return e
                            })
                        }
                    }
                }
                r.$inject = ["$q", "apiParamsInitialization", "httpService"], t.Z.factory("usersService", r), a.default = r
            },
            6115: function(e) {
                e.exports = '<div class="details-container add-friends-container" ng-class="{\'collapsed\': dialogLayout.collapsed}" ng-show="dialogLayout.details.isAddFriendsEnabled" ng-controller="friendsController"> <div class="chat-windows-header" ng-mouseenter="updateDialogHeader(true)" ng-mouseleave="updateDialogHeader(false)" ng-class="{\'hover\': dialogLayout.hoverOnCollapsed}"> <div class="chat-header-back" ng-click="toggleAddFriends()"> <span class="icon-chat-back"></span> </div> <div class="chat-header-label chat-header-create-group" ng-click="toggleDialogContainer()"> <span class="font-bold font-caption-header" ng-bind="\'Label.AddFriends\' | translate"></span> </div> <div class="chat-header-action"> <span class="icon-chat-close-white" ng-click="closeDialog({layoutId: dialogData.layoutId})"></span> </div> </div> <div select-friends></div> <div class="details-btns-fixed select-friends-btns"> <button id="select-friends-cancel" ng-click="toggleAddFriends()" ng-bind="\'Action.Cancel\' | translate" class="btn-fixed-width btn-control-sm details-btn-cancel select-friends-cancel"></button> <button id="select-friends-save" class="btn-fixed-width btn-secondary-sm btn-cta-sm details-btn-save select-friends-save" ng-bind="\'Action.Add\' | translate" ng-disabled="dialogLayout.inviteBtnDisabled" ng-click="sendInvite(); toggleAddFriends()"></button> </div> </div>'
            },
            3474: function(e) {
                e.exports = '<div class="details-confirmation-container" ng-show="dialogLayout.isConfirmationOn"> <div class="dialog-report-content"> <div class="chat-windows-header"> <div class="chat-header-back" ng-click="dialogLayout.isConfirmationOn = false"> <span class="icon-chat-back"></span> </div> <div class="chat-header-label details-dialog-title" ng-click="toggleDialogContainer()"> <span ng-bind="\'Action.Report\'|translate" class="font-caption-header">Report</span> </div> <div class="chat-header-action"> <span class="icon-chat-close-white" ng-click="closeDialog({layoutId: dialogData.layoutId})"></span> </div> </div> <div class="details-negative-confirmation-body"> <span ng-bind="\'Heading.ContinueToReport\'|translate" class="small text details-negative-confirmation-text">Continue to report?</span> <div class="details-btns-fixed select-friends-btns"> <button class="btn-control-sm details-btn-cancel" ng-bind="\'Action.Cancel\'|translate" ng-click="dialogLayout.isConfirmationOn = false"></button> <button id="chat-abuse-report-btn" class="btn-alert-sm details-btn-save" ng-bind="\'Action.Report\'|translate" ng-click="abuseReport(null, true)"></button> </div> </div> </div> </div>'
            },
            4947: function(e) {
                e.exports = '<thumbnail-2d thumbnail-target-id="userId" thumbnail-type="layoutLibrary.thumbnailTypes.avatarHeadshot" thumbnail-options="{size: layoutLibrary.avatarHeadshotSize.size48}" class="{{className}}" alt-name="userId" title="{{userId}}"> </thumbnail-2d>'
            },
            3540: function(e) {
                e.exports = '<div id="chat-main" class="chat-main" ng-controller="chatBarController" ng-class="{\'chat-main-empty\': isChatEmpty() }" ng-cloak> <div id="chat-header" class="chat-windows-header chat-header"> <div class="chat-header-label" ng-click="toggleChatContainer()"> <span class="font-caption-header chat-header-title" ng-bind="\'Heading.Chat\' | translate"></span> </div> <div class="chat-header-action"> <span class="xsmall notification-red notification" ng-show="chatLibrary.chatLayout.collapsed && chatViewModel.unreadConversationCount" ng-cloak>{{chatViewModel.unreadConversationCount}}</span> <span> <span id="chat-group-create" class="icon-chat-group-create" ng-hide="chatLibrary.chatLayout.collapsed || chatLibrary.chatLayout.errorMaskEnable || chatLibrary.chatLayout.chatLandingEnabled || chatLibrary.chatLayout.pageDataLoading || !getIsChatEnabled()" ng-click="launchDialog(newGroup.layoutId)" uib-tooltip="{{\'Label.SpanTitle.CreateGroupNeeds2More\' | translate}}" tooltip-placement="bottom-right" ng-cloak></span> </span> </div> </div> <div id="chat-body" class="chat-body" ng-show="!chatLibrary.chatLayout.errorMaskEnable && !chatLibrary.chatLayout.pageDataLoading && !chatLibrary.chatLayout.pageInitializing" ng-if="!(chatLibrary.chatLayout.chatLandingEnabled || !getIsChatEnabled())"> <div class="border-bottom chat-search" ng-class="{\'chat-search-focus\': chatLibrary.chatLayout.searchFocus}"> <span> <input type="text" placeholder="{{\'Label.InputPlaceHolder.SearchForFriends\' | translate }}" class="input-field chat-search-input font-caption-body" ng-model="chatViewModel.searchTerm" ng-focus="chatLibrary.chatLayout.searchFocus = true"/> </span> <span class="icon-chat-search"></span> <span class="icon-chat-search-cancel" ng-click="cancelSearch()"></span> </div> <div id="chat-friend-list" class="rbx-scrollbar chat-friend-list" lazy-load> <ul id="chat-friends" class="chat-friends"> <li ng-repeat="chatUser in chatUserDict | orderList: chatLibrary.chatLayoutIds | filter : search" class="chat-friend chat-friend-{{chatUser.id}}"> <div ng-if="chatUser.dialogType === dialogType.CHAT || chatUser.dialogType === dialogType.FRIEND" class="chat-friend-container" ng-click="launchFromConversationList(chatUser.layoutId)"> <div class="avatar avatar-headshot-sm card-plain chat-friend-avatar" ng-click="launchFromConversationList(chatUser.layoutId)"> <span class="chat-avatar-headshot" class-name="avatar-card-image chat-avatar" chat-avatar-headshot user-id="{{chatUser.displayUserId}}" layout-library="chatLibrary.layoutLibrary"> </span> <div class="avatar-status chat-friend-status" ng-class="userPresenceTypes[chatLibrary.friendsDict[chatUser.displayUserId].presence.userPresenceType][\'className\']"> </div> </div> <div user-conversation-info></div> </div> <div ng-if="chatUser.dialogType === dialogType.GROUPCHAT" class="chat-friend-container chat-friend-groups" ng-click="launchFromConversationList(chatUser.layoutId)"> <div class="chat-friend-avatar" ng-click="launchFromConversationList(chatUser.layoutId)"> <ul class="avatar-group card-plain chat-avatar-groups" ng-class="{\'avatar-double\': chatUser.userIds.length === 2,\'avatar-triple\' : chatUser.userIds.length === 3,\'avatar-all\' : chatUser.userIds.length>= 4}"> <li ng-repeat="userId in chatUser.userIds | limitTo : 4" class="avatar-item chat-avatar"> <span class="chat-avatar-headshot" class-name="avatar-card-image" chat-avatar-headshot user-id="{{userId}}" layout-library="chatLibrary.layoutLibrary"> </span> </li> </ul> </div> <div user-conversation-info></div> </div> </li> </ul> <div class="chat-loading loading-bottom" ng-show="chatLibrary.chatLayout.isChatLoading"> <span class="spinner spinner-sm" title="{{\'Label.SpanTitle.Loading\' | translate}}"></span> </div> </div> </div> <div id="chat-disconnect" class="chat-disconnect" ng-show="isChatDisconnected()" ng-cloak> <p class="text-info" ng-show="chatLibrary.chatLayout.errorMaskEnable">{{chatLibrary.chatLayout.noConnectionMsg}} </p> <span><span class="spinner spinner-default" title="{{\'Label.SpanTitle.Loading\' | translate}}"></span></span> </div> <div id="chat-empty-list" class="chat-disconnect" ng-hide="chatLibrary.chatLayout.errorMaskEnable" ng-if="isChatEmpty()"> <span class="icon-chat-friends"></span> <p ng-show="getIsChatEnabled()" class="text-info small font-caption-body text-default" ng-bind="\'Message.MakeFriendsToChatNPlay\' | translate"></p> <a id="find-game" ng-bind="\'Label.PlayGames\' | translate" class="btn-primary-sm btn-cta-sm" ng-show="getIsChatEnabled()" ng-href="{{chatLibrary.gamesPageLink}}"></a> <p ng-show="!getIsChatEnabled()" class="text-info small" ng-click="openSettingsPage()"> <span ng-bind-html="\'Message.ChatPrivacySetting\' | translate:{frontLink: \'<span class=text-link>\', endLink: \'</span>\'}"></span> </p> <p ng-show="chatLibrary.chatLayout.isChatEnabledByPrivacySetting === chatLibrary.chatLayout.chatEnabledByPrivacySettingTypes.unavailable" class="text-info small">{{chatLibrary.chatLayout.languageForPrivacySettingUnavailable}}</p> </div> </div>'
            },
            4497: function(e) {
                e.exports = '<div ng-controller="chatController" ng-class="{\'collapsed\': chatLibrary.chatLayout.collapsed}" ng-cloak> <div chat-bar></div> <div id="dialogs" class="dialogs" ng-controller="dialogsController" ng-hide="!getIsChatEnabled()"> <div dialog id="{{chatLayoutId}}" dialog-data="chatUserDict[chatLayoutId]" chat-library="chatLibrary" close-dialog="closeDialog(chatLayoutId)" send-invite="sendInvite(chatLayoutId)" open-conversation-from-friend-id="openConversationFromFriendId(chatUserDict[chatLayoutId].id)" ng-repeat="chatLayoutId in chatLibrary.layoutIdList"></div> <div dialog id="{{newGroup.layoutId}}" dialog-data="newGroup" chat-library="chatLibrary" close-dialog="closeDialog(\'newGroup\')" send-invite="sendInvite(newGroup.layoutId)" open-conversation-from-friend-id="openConversationFromFriendId(chatUserDict[chatLayoutId].id)" ng-if="newGroup"></div> <div id="dialogs-minimize" class="dialogs-minimize" ng-class="{\'dialogs-minimize-non-interactable\': !chatLibrary.hasMinimizedDialogs}" dialog-minimize chat-library="chatLibrary"> </div> <div class="chat-placeholder" chat-placeholder> </div> </div> </div>'
            },
            3355: function(e) {
                e.exports = '<div id="dialog-container-{{dialogData.id}}" class="dialog-container" ng-class="{\'collapsed\': dialogLayout.collapsed,\'active\': dialogLayout.active && dialogData.layoutId !== chatLibrary.chatLayout.focusedLayoutId,\'focused\': !dialogLayout.collapsed && dialogData.layoutId === chatLibrary.chatLayout.focusedLayoutId}" ng-controller="dialogController"> <div class="dialog-main" ng-hide="isDialogMainContainerHidden()"> <div class="chat-windows-header dialog-header" ng-mouseenter="updateDialogHeader(true)" ng-mouseleave="updateDialogHeader(false)" ng-class="{\'hover\': dialogLayout.hoverOnCollapsed}"> <div class="chat-header-label" ng-click="toggleDialogContainer()"> <span class="font-caption-header text-overflow chat-header-title dialog-header-title"> {{dialogData.name}} </span> </div> <div dialog-header></div> </div> <div id="scrollbar_{{dialogData.dialogType}}_{{dialogData.layoutId}}" class="rbx-scrollbar dialog-body" ng-style="dialogLayout.defaultStyle.dialogStyle" focus-model="toggleDialogFocusStatus(true)" dialog-lazy-load> <ul class="dialog-messages" ng-controller="dialogMessagesController"> <li class="dialog-message-container" ng-repeat="message in dialogData.chatMessages | reverse" ng-class="{\'message-inbound\': message.sender_user_id != chatLibrary.userId && !message.isSystemMessage,\'system-message\': message.isSystemMessage,\'message-cluster-master\': message.isClusterMaster}" ng-if="canRenderMessage(message)" on-finish-render="ngRepeatFinished"> <div class="indicated-message" ng-hide="!message.displayTimeStamp"> <span class="font-footer text-muted indicated-message-bubble">{{message.displayTimeStamp}}</span> </div> <a ng-href="{{chatLibrary.friendsDict[message.sender_user_id].profileUrl}}" ng-hide="message.isSystemMessage" class="avatar avatar-headshot-sm dialog-message-avatar-link"> <span ng-if="message.sender_user_id != chatLibrary.userId" class="chat-avatar-headshot" class-name="avatar-card-image dialog-message-avatar" chat-avatar-headshot user-id="{{message.sender_user_id}}" layout-library="chatLibrary.layoutLibrary"></span> </a> <div class="dialog-message-body"> <div class="dialog-message dialog-message-content dialog-triangle" ng-class="{\'message-is-sending\': message.sendingMessage, \'trusted-comms\': isMessageOutgoingTrustedComms(message)}" ng-hide="message.isSystemMessage" ng-if="!message.hasLinkCard && canRenderMessage(message)"> <span class="message-piece font-caption-body text-emphasis" ng-repeat="piece in message.pieces" ng-bind-html="piece.content"></span> <span ng-show="message.canResend" ng-click="resendMessage(message)" class="icon-chat-resend"></span> </div> <div ng-if="message.hasLinkCard" link-card></div> <div class="xsmall text-error dialog-sending" ng-show="message.sendMessageHasError" ng-bind="message.error || (\'Message.Error\' | translate)"></div> </div> <div class="indicated-message" system-message></div> </li> <li class="dialog-message-container message-inbound typing-indicator" ng-show="dialogLayout.typing.isTypingFromSender"> <a ng-href="{{chatLibrary.friendsDict[dialogLayout.typing.userIds[0]].profileUrl}}" class="avatar avatar-headshot-sm dialog-message-avatar-link"> <span class="chat-avatar-headshot" class-name="avatar-card-image dialog-message-avatar" chat-avatar-headshot user-id="{{dialogLayout.typing.userIds[0]}}" layout-library="chatLibrary.layoutLibrary"></span> </a> <div class="small dialog-message dialog-triangle"> <span class="typing"></span> </div> </li> </ul> </div> <div class="chat-loading loading-top" ng-show="dialogLayout.isChatLoading"> <span class="spinner spinner-sm" title="{{\'Label.SpanTitle.Loading\' | translate}} ..."></span> </div> <div class="border-top dialog-input-container" ng-class="{\'disabled\': chatLibrary.chatLayout.errorMaskEnable}" ng-style="dialogLayout.defaultStyle.inputStyle"> <textarea id="dialog-input" msd-elastic dialog-input rows="1" focus-me="{{dialogLayout.focusMeEnabled && dialogData.layoutId === chatLibrary.chatLayout.focusedLayoutId}}" placeholder="{{\'Label.InputPlaceHolder.SendMessage\' | translate}}" ng-model="dialogData.messageForSend" enter-escape-shift="keyPressEnter($event)" ng-keypress="typing($event, true)" ng-blur="typing($event, false)" class="dialog-input" input-max-length="{{dialogLayout.limitCharacterCount}}" ng-disabled="chatLibrary.chatLayout.errorMaskEnable" ng-style="dialogLayout.defaultStyle.inputTextStyle" hinteractive hinteractive-domain="chat"></textarea> </div> </div> <div abuse-report></div> <div details></div> <div places></div> </div>'
            },
            7709: function(e) {
                e.exports = '<thumbnail-2d class="{{className}}" thumbnail-target-id="universeId" thumbnail-type="layoutLibrary.thumbnailTypes.gameIcon"> </thumbnail-2d>'
            },
            9816: function(e) {
                e.exports = '<div id="dialog-container-{{dialogData.id}}" class="dialog-container group-dialog" ng-class="{\'group-has-banner\': dialogLayout.renameEditor.isEnabled,\'collapsed\': dialogLayout.collapsed,\'active\': dialogLayout.active && dialogData.layoutId !== chatLibrary.chatLayout.focusedLayoutId,\'focused\': !dialogLayout.collapsed && dialogData.layoutId === chatLibrary.chatLayout.focusedLayoutId}" ng-controller="dialogController"> <div class="dialog-main" ng-hide="dialogLayout.isConfirmationOn || isDialogMainContainerHidden() || shouldShowPendingState()"> <div class="chat-windows-header dialog-header" ng-mouseenter="updateDialogHeader(true)" ng-mouseleave="updateDialogHeader(false)" ng-class="{\'hover\': dialogLayout.hoverOnCollapsed}"> <div class="chat-header-label" ng-click="toggleDialogContainer()"> <span id="group-chat-title" class="font-caption-header text-overflow dialog-header-title max-width" title="{{dialogData.title}}">{{dialogData.title}}</span> </div> <div dialog-header></div> </div> <div id="scrollbar_{{dialogData.dialogType}}_{{dialogData.layoutId}}" ng-style="dialogLayout.defaultStyle.dialogStyle" class="rbx-scrollbar dialog-body" dialog-lazy-load focus-model="toggleDialogFocusStatus(true)"> <ul class="dialog-messages" ng-controller="dialogMessagesController"> <li class="dialog-message-container" ng-repeat="message in dialogData.chatMessages | reverse" ng-class="{\'message-inbound\': message.sender_user_id != chatLibrary.userId && !message.isSystemMessage,\'system-message\': message.isSystemMessage,\'message-cluster-master\': message.isClusterMaster}" ng-if="canRenderMessage(message)" on-finish-render="ngRepeatFinished"> <div class="indicated-message" ng-hide="!message.displayTimeStamp"> <span class="font-footer text-muted indicated-message-bubble"> {{message.displayTimeStamp}} </span> </div> <a ng-href="{{chatLibrary.friendsDict[message.sender_user_id].profileUrl}}" ng-hide="message.isSystemMessage" class="avatar avatar-headshot-sm dialog-message-avatar-link"> <span ng-if="message.sender_user_id != chatLibrary.userId" class="chat-avatar-headshot" class-name="avatar-card-image dialog-message-avatar" chat-avatar-headshot user-id="{{message.sender_user_id}}" layout-library="chatLibrary.layoutLibrary"> </span> </a> <div class="dialog-message-body" ng-if="canRenderMessage(message)"> <div ng-if="chatLibrary.friendsDict[message.sender_user_id]" ng-show="message.isClusterMaster && message.sender_user_id != chatLibrary.userId" class="xxsmall dialog-message-author"> <span class="font-footer text-muted" ng-bind="chatLibrary.friendsDict[message.sender_user_id].nameForDisplay"></span> <span class="typing" ng-show="message.id == dialogLayout.typing.userTypingDict[message.sender_user_id].messageId"></span> </div> <div class="dialog-message dialog-triangle" ng-class="{\'message-is-sending\': message.sendingMessage, \'trusted-comms\': isMessageOutgoingTrustedComms(message)}" ng-hide="message.isSystemMessage" ng-if="!message.hasLinkCard"> <span class="dialog-message-content"> <span class="message-piece" ng-repeat="piece in message.pieces" ng-bind-html="piece.content"></span> </span> <span ng-show="message.canResend" ng-click="resendMessage(message)" class="icon-chat-resend"></span> </div> <div ng-if="message.hasLinkCard" link-card></div> <div class="text-error dialog-sending" ng-show="message.sendMessageHasError" ng-bind="message.error || (\'Message.Error\'|translate)"></div> </div> <div class="indicated-message" system-message></div> </li> </ul> </div> <div class="chat-loading loading-top" ng-show="dialogLayout.isChatLoading"> <span class="spinner spinner-sm" title="{{\'Label.SpanTitle.Loading\'|translate}}"></span> </div> <div class="border-top dialog-input-container" ng-class="{\'disabled\': chatLibrary.chatLayout.errorMaskEnable}" ng-style="dialogLayout.defaultStyle.inputStyle"> <textarea msd-elastic focus-me="{{dialogLayout.focusMeEnabled && dialogData.layoutId === chatLibrary.chatLayout.focusedLayoutId}}" placeholder="{{\'Label.InputPlaceHolder.SendMessage\'|translate}}" ng-model="dialogData.messageForSend" enter-escape-shift="keyPressEnter($event)" ng-keypress="typing($event, true)" ng-blur="typing($event, false)" class="dialog-input" rows="1" input-max-length="{{dialogLayout.limitCharacterCount}}" ng-disabled="chatLibrary.chatLayout.errorMaskEnable" ng-style="dialogLayout.defaultStyle.inputTextStyle" hinteractive hinteractive-domain="chat"></textarea> </div> </div> <div abuse-report></div> <div confirm-negative-action chat-library="chatLibrary" dialog-layout="dialogLayout" confirm-callback="confirmCallBack()"></div> <div details></div> <div pending-state></div> </div> '
            },
            4120: function(e) {
                e.exports = '<div class="chat-placeholder-container" ng-show="chatLibrary.chatPlaceholderEnabled"> <div class="chat-placeholder-header"></div> <span class="icon-chat-placeholder"></span> </div>'
            },
            8895: function(e) {
                e.exports = '<div class="confirm-negative-action details-confirmation-container" ng-show="dialogLayout.confirmDialog.isOpen"> <div class="confirm-negative-action-container"> <div class="chat-windows-header"> <div class="chat-header-back" ng-click="dialogLayout.confirmDialog.isOpen = false"> <span class="icon-chat-back"></span> </div> <div class="chat-header-label details-dialog-title" ng-click="toggleDialogContainer()"> <span class="font-caption-header">{{dialogLayout.confirmDialog.headerTitle}}</span> </div> <div class="chat-header-action"> <span class="icon-chat-close-white" ng-click="closeDialog({layoutId: dialogData.layoutId})" data-toggle="tooltip" title="{{\'Label.Close\'|translate}}"></span> </div> </div> <div class="details-negative-confirmation-body"> <span class="small text details-negative-confirmation-text">{{dialogLayout.confirmDialog.title}}</span> <div class="details-btns-fixed select-friends-btns"> <button class="btn-control-sm details-btn-cancel" ng-click="dialogLayout.confirmDialog.isOpen = false"> {{dialogLayout.confirmDialog.cancelBtnName}} </button> <button id="negative-action-confirm-btn" class="btn-alert-sm details-btn-save" ng-click="confirmCallback()"> {{dialogLayout.confirmDialog.btnName}} </button> </div> </div> </div> </div>'
            },
            2791: function(e) {
                e.exports = '<div class="details-header-container conversation-title-container"> <div class="details-label conversation-title-icon"> <span class="icon-chat-group-name" ng-show="dialogData.dialogType === dialogType.NEWGROUPCHAT"></span> <ul class="avatar-group card-plain chat-avatar-groups" ng-show="dialogData.dialogType != dialogType.NEWGROUPCHAT" ng-class="{\'avatar-double\': dialogData.userIds.length === 2,\'avatar-triple\' : dialogData.userIds.length === 3,\'avatar-all\' : dialogData.userIds.length >= 4}"> <li ng-repeat="userId in dialogData.userIds | limitTo : 4" class="avatar-item chat-avatar"> <span class="chat-avatar-headshot" class-name="avatar-card-image" chat-avatar-headshot user-id="{{userId}}" layout-library="chatLibrary.layoutLibrary"> </span> </li> </ul> </div> <div class="border-bottom small details-input-container" ng-show="dialogData.dialogType == dialogType.NEWGROUPCHAT"> <input type="text" focus-me="{{dialogLayout.focusMeEnabled}}" class="small details-input conversation-title-input" placeholder="{{\'Label.NameYourChatGroup\'|translate}}" ng-model="dialogData.name" maxlength="{{chatLibrary.maxConversationTitleLengthInput}}"> </div> <div class="details-title conversation-title-content" ng-click="toggleConversationEditor()" ng-class="{\'not-clickable\': dialogData.isUserPending}" ng-show="dialogData.dialogType != dialogType.NEWGROUPCHAT"> <span class="small text conversation-title-label text-overflow" ng-bind="dialogData.title"></span> <span class="icon-chat-arrow-right"></span> </div> </div>'
            },
            6465: function(e) {
                e.exports = '<div class="details-container conversation-title-editor-container" ng-show="dialogLayout.details.isConversationTitleEditorEnabled"> <div class="chat-windows-header" ng-mouseenter="updateDialogHeader(true)" ng-mouseleave="updateDialogHeader(false)" ng-class="{\'hover\': dialogLayout.hoverOnCollapsed}"> <div class="chat-header-back" ng-click="toggleConversationEditor()"> <span class="icon-chat-back"></span> </div> <div class="chat-header-label details-dialog-title" ng-click="toggleDialogContainer()"> <span class="font-caption-header" ng-bind="\'Label.ChatGroupName\' | translate"></span> </div> <div class="chat-header-action"> <span class="icon-chat-close-white" ng-click="closeDialog({layoutId: dialogData.layoutId})"></span> </div> </div> <div class="details-container conversation-title-editor-body"> <div ng-bind="\'Label.ChangeChatGroupName\' | translate" class="font-caption-body text conversation-title-editor-title"> </div> <div class="conversation-title-editor-content"> <textarea auto-resize rows="1" maxlength="{{chatLibrary.maxConversationTitleLengthInput}}" focus-me="{{dialogLayout.focusMeEnabled}}" class="font-caption-body input-field details-input conversation-title-editor-textarea" key-press-enter="renameTitle()" ng-model="dialogData.name">\r\n            </textarea> <span class="font-footer text-subheader conversation-title-editor-count">{{dialogData.name.length}}/{{chatLibrary.maxConversationTitleLengthInput}}</span> </div> <div class="details-btns-fixed select-friends-btns"> <button id="select-friends-cancel" ng-bind="\'Action.Cancel\'|translate" ng-click="toggleConversationEditor()" class="btn-fixed-width btn-control-sm details-btn-cancel"></button> <button id="select-friends-save" ng-bind="\'Action.Save\'|translate" class="btn-fixed-width btn-secondary-sm details-btn-save" ng-click="renameTitle()"></button> </div> </div> </div>'
            },
            4748: function(e) {
                e.exports = '<div class="dialog-container create-chat-container" ng-class="{\'collapsed\': dialogLayout.collapsed}" ng-controller="friendsController"> <div class="chat-windows-header"> <div class="chat-header-label chat-header-create-group" ng-click="toggleDialogContainer()"> <span class="font-caption-header">{{dialogLayout.title}}</span> </div> <div class="chat-header-action"> <span class="icon-chat-close-white" ng-click="closeDialog({layoutId: dialogData.layoutId})"></span> </div> </div> <div conversation-title></div> <div select-friends></div> <div class="details-btns-fixed select-friends-btns"> <button id="select-friends-cancel" ng-bind="\'Action.Cancel\'|translate" ng-click="closeDialog({layoutId: dialogData.layoutId})" class="btn-fixed-width btn-control-sm details-btn-cancel select-friends-cancel"> </button> <button id="select-friends-save" ng-bind="\'Action.Create\'|translate" class="btn-fixed-width btn-secondary-sm btn-cta-sm details-btn-save select-friends-save" ng-disabled="dialogLayout.inviteBtnDisabled" ng-click="sendInvite()"> </button> </div> </div>'
            },
            9837: function(e) {
                e.exports = '<div class="details-dialog-container" ng-show="dialogLayout.details.isEnabled" ng-controller="detailsController"> <div class="details-dialog" ng-class="{\'collapsed\': dialogLayout.collapsed}" ng-hide="dialogLayout.details.isAddFriendsEnabled || dialogLayout.details.isConversationTitleEditorEnabled"> <div class="chat-windows-header" ng-mouseenter="updateDialogHeader(true)" ng-mouseleave="updateDialogHeader(false)" ng-class="{\'hover\': dialogLayout.hoverOnCollapsed}"> <div class="chat-header-back" ng-click="toggleDetails()"> <span class="icon-chat-back"></span> </div> <div class="chat-header-label details-dialog-title" ng-click="toggleDialogContainer()"> <span ng-bind="\'Label.ChatDetails\'| translate" class="font-caption-header"></span> </div> <div class="chat-header-action"> <span class="icon-chat-close-white" ng-click="closeDialog({layoutId: dialogData.layoutId})"></span> </div> </div> <div id="scrollbar_details_{{dialogData.layoutId}}" class="rbx-scrollbar details-container details-scrollbar" details-scrollbar> <div class="xsmall border-bottom text-secondary details-general-label" ng-if="dialogData.isGroupChat" ng-bind="\'Label.General\'|translate"> </div> <div conversation-title ng-if="dialogData.isGroupChat"></div> <div class="xsmall border-top border-bottom text-secondary details-members-label font-footer text-muted" ng-bind="\'Label.Members\' | translate"></div> <div class="details-members-container"> <div class="add-friends-option" ng-hide="dialogData.isUserPending"> <div class="add-friends-icon" ng-click="toggleAddFriends()"> <div class="add-friends-cirle-container"> <span class="icon-chat-add-friends"></span> </div> </div> <div class="small border-bottom text-sec add-friends-label" ng-bind="\'Label.AddFriends\' | translate" ng-click="toggleAddFriends()"> </div> </div> <div id="group-members" class="participant-list"> <ul class="friends-list-container participant-list-container"> <li ng-repeat="userId in dialogData.userIds | limitTo: dialogLayout.memberDisplay.limitNumber" id="member-list-{{userId}}"> <div class="friend-container"> <a ng-href="{{chatLibrary.friendsDict[userId].profileUrl}}" class="avatar avatar-headshot-sm friend-avatar"> <span class="chat-avatar-headshot" class-name="avatar-card-image avatar" chat-avatar-headshot user-id="{{userId}}" layout-library="chatLibrary.layoutLibrary"> </span> <div class="avatar-status avatar-status" ng-class="userPresenceTypes[chatLibrary.friendsDict[userId].presence.userPresenceType][\'className\']"> </div> </a> <div class="border-bottom friend-info-action"> <div class="friend-info"> <div class="friend-username dynamic-overflow-container no-wrap"> <div class="small text-overflow text-sec friend-name dynamic-ellipsis-item"> {{chatLibrary.friendsDict[userId].nameForDisplay}}</div> </div> <div class="xsmall text-overflow friend-status"> {{userPresenceTypes[chatLibrary.friendsDict[userId].presence.userPresenceType].title}} </div> </div> <div class="friend-action" ng-show="userId !== chatLibrary.userId"> <div class="friend-action-more-option more-options-{{dialogData.layoutId}}" click-outside="toggleFriendsMenu(userId, true)" ng-click="toggleFriendsMenu(userId)"> <span class="icon-chat-more-options"></span> </div> <div class="friend-menu" ng-class="{\'three-items\': canConversationRemoveMember() }" ng-show="dialogLayout.details.friendIdForMenuOn == userId && dialogLayout.details.friendMenuAction[userId]"> <ul class="dropdown-menu" role="menu" ng-show="dialogLayout.details.friendIdForMenuOn == userId && dialogLayout.details.friendMenuAction[userId]"> <li> <a id="add-friends-{{userId}}" ng-href="{{chatLibrary.friendsDict[userId].profileUrl}}" ng-click="toggleFriendsMenu(userId)" ng-bind="\'Label.ViewProfile\' | translate" class="font-caption-header"></a> </li> <li> <a id="abuse-report-{{userId}}" ng-click="abuseReport(userId, false); toggleFriendsMenu(userId)" class="font-caption-header" ng-bind="\'Action.Report\' | translate"></a> </li> <li ng-if="canConversationRemoveMember()"> <a id="remove-member-{{userId}}" ng-click="removeMember(userId, false); toggleFriendsMenu(userId)" class="font-caption-header" ng-bind="\'Action.Remove\' | translate"></a> </li> </ul> </div> </div> </div> </div> </li> <li class="participant-list-action" ng-show="dialogData.userIds.length > dialogLayout.memberDisplay.defaultLimit"> <a class="small text-link" ng-click="toggleMemberList()">{{dialogLayout.memberDisplay.linkName}}</a> </li> </ul> </div> </div> <div class="details-btns"> <button id="leave-group" ng-click="leaveGroupChat(false)" class="btn-full-width btn-alert-sm select-friends-cancel" ng-if="dialogData.dialogType !== dialogType.CHAT && dialogData.isGroupChat" ng-bind="\'Label.LeaveChatGroup\' | translate"></button> </div> </div> </div> <div add-friends></div> <div conversation-title-editor></div> </div> '
            },
            7905: function(e) {
                e.exports = '<div class="chat-header-action" ng-controller="dialogHeaderController"> <span class="icon-chat-close-white" ng-click="closeDialog({layoutId: dialogData.layoutId})"></span> <span class="icon-chat-info-white" id="dialog-info" uib-tooltip="{{\'Label.ChatDetails\'| translate}}" tooltip-placement="bottom" ng-click="toggleDetails()" ng-hide="dialogLayout.collapsed || chatLibrary.chatLayout.errorMaskEnable"></span> <span id="play-together-{{dialogData.id}}" class="cursor-pointer dialog-header-active-game" ng-if="isPinOrActiveGameAvailable()" ng-hide="dialogLayout.collapsed || chatLibrary.chatLayout.errorMaskEnable" ng-click="openGameList()" popover-trigger=" \'none\' " popover-class="game-list-in-dialog" popover-placement="bottom-right" popover-append-to-body="false" popover-is-open="dialogLayout.togglePopoverParams.isOpen" uib-popover-template="\'{{gamesListTemplateUrl}}\'" toggle-popover> <span chat-game-icon class-name="dialog-header-active-game-image" ng-if="dialogData.placeForShown.universeId" universe-id="{{dialogData.placeForShown.universeId}}" layout-library="chatLibrary.layoutLibrary"></span> </span> </div>'
            },
            3528: function(e) {
                e.exports = '<div id="dialogs-minimize-container" class="dialogs-minimize-container" ng-show="chatLibrary.hasMinimizedDialogs" data-toggle="popover" data-bind="dialogs"> <span class="icon-chat-more-dialogs"></span> <span class="font-header-2 minimize-count">{{chatLibrary.minimizedDialogIdList.length}}</span> <div class="rbx-popover-content" data-toggle="dialogs"> <ul class="dropdown-menu minimize-list" role="menu"> <li ng-repeat="dialogLayoutId in chatLibrary.minimizedDialogIdList" class="minimize-item" id="{{dialogLayoutId}}" minimize-item> <a class="text-overflow minimize-title"> <span> {{chatLibrary.minimizedDialogData[dialogLayoutId].name}} </span> </a> <span class="icon-chat-close-black minimize-close"></span> </li> </ul> </div> </div>'
            },
            2449: function(e) {
                e.exports = '<div> <span ng-show="!chatUser.displayMessage.hasLinkifyMessage" ng-bind-html="chatUser.displayMessage.content"></span> <span ng-show="chatUser.displayMessage.hasLinkifyMessage" ng-bind="chatUser.displayMessage.parsedContent"></span> </div>'
            },
            954: function(e) {
                e.exports = '<div ng-controller="playTogetherController"> <div class="game-item-container pinned-game-container" ng-class="{\'has-active-game\': hasPinGameAndActiveGames()}" ng-show="playTogether.pinGame && playTogether.pinGame.rootPlaceId"> <a ng-href="{{chatLibrary.placesLibrary[playTogether.pinGame.rootPlaceId].placeUrl}}" class="text-title game-link"> <span chat-game-icon class-name="game-icon" layout-library="chatLibrary.layoutLibrary" ng-if="chatLibrary.placesLibrary[playTogether.pinGame.rootPlaceId].universeId" universe-id="{{chatLibrary.placesLibrary[playTogether.pinGame.rootPlaceId].universeId}}" title="{{chatLibrary.placesLibrary[playTogether.pinGame.rootPlaceId].placeName}}"></span> </a> <div class="game-details pinned-game-details"> <div class="pinned-game-header"></div> <div class="text-overflow small text-title game-name"> <a ng-href="{{chatLibrary.placesLibrary[playTogether.pinGame.rootPlaceId].placeUrl}}" class="text-title game-link"> {{chatLibrary.placesLibrary[playTogether.pinGame.rootPlaceId].placeName}} </a> </div> <div class="game-info pinned-game-info"> <ul class="game-players"> <li ng-repeat="userId in playTogether.playTogetherDict[playTogether.pinGame.rootPlaceId].playerIds | limitTo: playTogetherLayout.numberOfMembers.inPinnedGame" class="avatar avatar-headshot-sm card-plain game-player" title="{{chatLibrary.friendsDict[userId].nameForDisplay}}"> <span uib-tooltip="{{chatLibrary.friendsDict[userId].nameForDisplay}}" tooltip-placement="bottom" tooltip-append-to-body="true" class="avatar-card-image game-player-avatar" class="chat-avatar-headshot" chat-avatar-headshot user-id="{{userId}}" layout-library="chatLibrary.layoutLibrary"> </span> <div class="avatar-status game-player-presence" ng-class="userPresenceTypes[chatLibrary.friendsDict[userId].presence.userPresenceType][\'className\']"> </div> </li> <li ng-show="playTogether.playTogetherDict[playTogether.pinGame.rootPlaceId].playerIds.length > playTogetherLayout.numberOfMembers.inPinnedGame" class="font-caption-body text-secondary game-player-plus" ng-cloak> +{{playTogether.playTogetherDict[playTogether.pinGame.rootPlaceId].playerIds.length - playTogetherLayout.numberOfMembers.inPinnedGame}} </li> </ul> <button type="button" class="{{playTogether.placeButtonLayout[playTogether.pinGame.rootPlaceId].className}} game-btn" ng-class="{\'invisible\' : !playTogether.placeButtonLayout[playTogether.pinGame.rootPlaceId]}" ng-click="joinGameFromPlayTogether(playTogether.pinGame.rootPlaceId)" ng-if="playTogether.placeButtonLayout[playTogether.pinGame.rootPlaceId].type != gameLayout.playButtonTypes.notAvailable"> {{playTogether.placeButtonLayout[playTogether.pinGame.rootPlaceId].text}} </button> <span class="xsmall text-label game-non-available" ng-if="playTogether.placeButtonLayout[playTogether.pinGame.rootPlaceId].type == gameLayout.playButtonTypes.notAvailable"> {{playTogether.placeButtonLayout[playTogether.pinGame.rootPlaceId].text}} </span> </div> </div> </div> <div class="game-list-container" ng-class="{\'has-pin-game-above\': hasPinGameAndActiveGames(),\'overflow\': (playTogetherLayout.activeGamesList.limitNumber >= playTogetherLayout.activeGamesList.maxNumberForFit)}" ng-show="hasActiveGames()"> <ul id="active-game-list" ng-class="{\'rbx-scrollbar\': playTogether.inDialog}" class="active-game-list"> <li ng-repeat="placeId in playTogether.playTogetherIds | limitTo: playTogetherLayout.activeGamesList.limitNumber" ng-if="placeId != playTogether.pinGame.rootPlaceId" repeat-done class="game-item-container active-game-container"> <a ng-href="{{chatLibrary.placesLibrary[placeId].placeUrl}}" class="text-title game-link"> <div chat-game-icon class="chat-game-icon" class-name="game-icon" layout-library="chatLibrary.layoutLibrary" ng-if="chatLibrary.placesLibrary[placeId].universeId" universe-id="{{chatLibrary.placesLibrary[placeId].universeId}}" title="{{chatLibrary.placesLibrary[placeId].placeName}}"></div> </a> <div class="border-bottom game-details active-game-details"> <div class="game-title-container"> <div class="text-overflow small text-title game-name"> <a ng-href="{{chatLibrary.placesLibrary[placeId].placeUrl}}"> {{chatLibrary.placesLibrary[placeId].placeName}} </a> </div> </div> <div class="game-info active-game-info"> <ul class="game-players"> <li ng-repeat="userId in playTogether.playTogetherDict[placeId].playerIds | limitTo: playTogetherLayout.numberOfMembers.inActiveGame" class="avatar avatar-headshot-sm card-plain game-player" title="{{chatLibrary.friendsDict[userId].nameForDisplay}}"> <div uib-tooltip="{{chatLibrary.friendsDict[userId].nameForDisplay}}" tooltip-placement="bottom" tooltip-append-to-body="true" class="chat-avatar-headshot" class-name="avatar-card-image game-player-avatar" chat-avatar-headshot user-id="{{userId}}" layout-library="chatLibrary.layoutLibrary"> </div> <div class="avatar-status game-player-presence" ng-class="userPresenceTypes[chatLibrary.friendsDict[userId].presence.userPresenceType][\'className\']"> </div> </li> <li ng-show="playTogether.playTogetherDict[placeId].playerIds.length > playTogetherLayout.numberOfMembers.inActiveGame" class="font-caption-body text-secondary game-player-plus" ng-cloak> +{{playTogether.playTogetherDict[placeId].playerIds.length - playTogetherLayout.numberOfMembers.inActiveGame}} </li> </ul> <button type="button" class="{{playTogether.placeButtonLayout[placeId].className}} game-btn" ng-class="{\'invisible\' : !playTogether.placeButtonLayout[placeId]}" ng-if="playTogether.placeButtonLayout[placeId].type != gameLayout.playButtonTypes.notAvailable" ng-click="joinGameFromPlayTogether(placeId)"> {{playTogether.placeButtonLayout[placeId].text}} </button> <span class="xsmall text-label game-non-available" ng-if="playTogether.placeButtonLayout[placeId].type == gameLayout.playButtonTypes.notAvailable"> {{playTogether.placeButtonLayout[placeId].text}} </span> </div> </div> </li> </ul> <div class="cursor-pointer border-top is-exclusive-click active-game-toggle-menu" ng-click="toggleActiveGameList()" ng-if="playTogetherLayout.numberOfActiveGames > 1" ng-class="{\'collapsed\': playTogetherLayout.activeGamesList.isCollapsed}"> <span class="xsmall text is-exclusive-click toggle-menu-text">{{playTogetherLayout.activeGamesList.toggleMenuText}}</span> </div> </div> </div> '
            },
            1651: function(e) {
                e.exports = '<div id="link-card" ng-controller="linkCardMessagesController"> <div class="link-card-msg-wrap" ng-repeat="pieceOfMessage in linkCardMessages" ng-controller="linkCardController" ng-init="sendLoadLinkCardEvent(pieceOfMessage.id)"> <div class="dialog-message dialog-message-content dialog-triangle" ng-class="{\'message-is-sending\': message.sendingMessage, \'trusted-comms\': isMessageOutgoingTrustedComms(message)}" ng-hide="pieceOfMessage.isLinkCard" ng-if="!pieceOfMessage.isCard || (pieceOfMessage.isCard && chatLibrary.placesLibrary[pieceOfMessage.id].isInvalid)"> <span class="message-piece font-caption-body text-emphasis" ng-repeat="piece in pieceOfMessage.pieces" ng-bind-html="piece.content"></span> </div> <div class="cursor-pointer border dialog-triangle link-card-container" ng-if="isLinkCardAvailableAndParsedByClientSide(pieceOfMessage) && (chatLibrary.placesLibrary[pieceOfMessage.id] || !chatLibrary.placesLibrary[pieceOfMessage.id].isInvalid)"> <div ng-if="chatLibrary.placesLibrary[pieceOfMessage.id]" ng-init="observeGameImpressions(chatLibrary.placesLibrary[pieceOfMessage.id])" ng-hide="true"></div> <div class="link-card-top-container"> <div class="small font-caption-header text-title text-overflow link-card-title" title="{{chatLibrary.placesLibrary[pieceOfMessage.id].placeName}}" ng-bind="chatLibrary.placesLibrary[pieceOfMessage.id].placeName" ng-click="goToPlaceDetails(pieceOfMessage.id, chatLibrary.eventStreamParams.clickLinkCardInChat)"> </div> </div> <div class="link-card-details" ng-click="goToPlaceDetails(pieceOfMessage.id, chatLibrary.eventStreamParams.clickLinkCardInChat)"> <span chat-game-icon class="chat-game-icon link-card-thumb" layout-library="chatLibrary.layoutLibrary" universe-id="{{chatLibrary.placesLibrary[pieceOfMessage.id].universeId}}" ng-if="chatLibrary.placesLibrary[pieceOfMessage.id].universeId"></span> <p class="xsmall text-secondary link-card-description" ng-bind="chatLibrary.placesLibrary[pieceOfMessage.id].description"></p> </div> <button class="{{chatLibrary.placesLibrary[pieceOfMessage.id].buttonLayoutForLinkCard.className}} btn-full-width link-card-btn" ng-class="{\'invisible\' : !chatLibrary.placesLibrary[pieceOfMessage.id].buttonLayoutForLinkCard}" ng-click="play(pieceOfMessage.id, chatLibrary.eventStreamParams.clickPlayFromLinkCardInChat, pieceOfMessage.assetDetails)" ng-disabled="dialogLayout.playTogetherButton.isPlayButtonDisabled"> {{chatLibrary.placesLibrary[pieceOfMessage.id].buttonLayoutForLinkCard.text}} </button> </div> <div class="cursor-pointer border dialog-triangle link-card-container" ng-if="pieceOfMessage.isLinkCard && chatLibrary.universeLibrary[pieceOfMessage.universeId]"> <div ng-init="observeGameImpressions(chatLibrary.universeLibrary[pieceOfMessage.universeId])" ng-hide="true"></div> <div class="link-card-top-container"> <div class="small font-caption-header text-title text-overflow link-card-title" title="{{chatLibrary.universeLibrary[pieceOfMessage.universeId].placeName}}" ng-bind="chatLibrary.universeLibrary[pieceOfMessage.universeId].placeName" ng-click="goToPlaceDetails(chatLibrary.universeLibrary[pieceOfMessage.universeId].placeId, chatLibrary.eventStreamParams.clickLinkCardInChat)"> </div> </div> <div class="link-card-details" ng-click="goToPlaceDetails(chatLibrary.universeLibrary[pieceOfMessage.universeId].placeId, chatLibrary.eventStreamParams.clickLinkCardInChat)"> <span chat-game-icon class="chat-game-icon link-card-thumb" ng-if="pieceOfMessage.universeId" layout-library="chatLibrary.layoutLibrary" universe-id="{{pieceOfMessage.universeId}}"></span> <p class="xsmall text-secondary link-card-description" ng-bind="chatLibrary.universeLibrary[pieceOfMessage.universeId].description"></p> </div> <button class="{{chatLibrary.universeLibrary[pieceOfMessage.universeId].buttonLayoutForLinkCard.className}} btn-full-width link-card-btn" ng-class="{\'invisible\' : !chatLibrary.universeLibrary[pieceOfMessage.universeId].buttonLayoutForLinkCard}" ng-click="play(chatLibrary.universeLibrary[pieceOfMessage.universeId].placeId, chatLibrary.eventStreamParams.clickPlayFromLinkCardInChat)" ng-disabled="dialogLayout.playTogetherButton.isPlayButtonDisabled"> {{chatLibrary.universeLibrary[pieceOfMessage.universeId].buttonLayoutForLinkCard.text}} </button> </div> </div> </div>'
            },
            162: function(e) {
                e.exports = '<div class="pending-state" ng-show="shouldShowPendingState()"> <div class="pending-state-container details-confirmation-container"> <div class="chat-windows-header dialog-header" ng-mouseenter="updateDialogHeader(true)" ng-mouseleave="updateDialogHeader(false)" ng-class="{\'hover\': dialogLayout.hoverOnCollapsed}"> <div class="chat-header-label" ng-click="toggleDialogContainer()"> <span id="group-chat-title" class="font-caption-header text-overflow dialog-header-title max-width" title="{{dialogData.title}}">{{dialogData.title}}</span> </div> <div dialog-header></div> </div> <div class="details-negative-confirmation-body"> <span class="small text details-negative-confirmation-text" ng-bind="\'Message.IneligibleToJoinChat\'|translate"></span> <div class="details-btns-fixed select-friends-btns"> <button id="negative-action-confirm-btn" class="btn-alert-sm details-btn-save details-btn-left" ng-bind="\'Action.LeaveGroup\'|translate" ng-click="leaveGroupChat(true)"> </button> <button class="btn-control-sm details-btn-cancel details-btn-right" ng-bind="\'Action.LearnMore\'|translate" ng-click="openLearnMorePage()"> </button> </div> </div> </div> </div>'
            },
            4310: function(e) {
                e.exports = '<div class="select-friends-container"> <div class="border-bottom details-header-container select-friends-header"> <div class="details-label select-friends-label"> <span class="icon-chat-group-label"></span> </div> <div class="small details-input-container select-friends-search" ng-class="{\'group-select-container\' : dialogData.selectedUserIds.length > 0}" select-friends-resize> <ul class="friends-selected-list" ng-show="dialogData.selectedUserIds.length > 0"> <li class="friends-selected-item friends-selected-placeholder invisible"> </li> <li class="avatar avatar-headshot-sm card-plain friends-selected-item" ng-repeat="userId in dialogData.selectedUserIds" ng-click="selectFriends(userId)" ng-hide="dialogData.selectedUsersDict[userId].hiddenFromSelection" title="{{dialogData.selectedUsersDict[userId].nameForDisplay}}"> <span class="chat-avatar-headshot" class-name="avatar-card-image avatar" chat-avatar-headshot user-id="{{userId}}" layout-library="chatLibrary.layoutLibrary"> </span> <div class="friends-selected-mask"> <span class="icon-chat-close-white"></span> </div> </li> </ul> <input type="text" placeholder="{{\'Label.InputPlaceHolder.SearchForFriends\'|translate}}" class="small details-input select-friends-input" ng-model="dialogData.searchTerm"/> <span class="xsmall text-secondary select-friends-count" ng-if="dialogData.dialogType === dialogType.GROUPCHAT"> ({{(dialogData.selectedUserIds.length)}}/{{chatLibrary.quotaOfGroupChatMembers - dialogData.userIds.length + 1}}) </span> <span class="xsmall text-secondary select-friends-count" ng-if="dialogData.dialogType === dialogType.NEWGROUPCHAT || dialogData.dialogType === dialogType.CHAT"> ({{(dialogData.selectedUserIds.length)}}/{{chatLibrary.quotaOfGroupChatMembers - dialogData.userIds.length}}) </span> </div> </div> <div> <div id="scrollbar_friend_{{dialogData.dialogType}}_{{dialogData.layoutId}}" class="rbx-scrollbar select-friends-list" friends-lazy-load> <ul class="friends-list-container"> <li ng-repeat="friend in chatLibrary.friendsDict | orderList: dialogData.friendIds  | filter: search" id="friend-{{friend.id}}"> <div class="friend-container chat-friend-select"> <div class="avatar avatar-headshot-sm card-plain friend-avatar" ng-click="toggleFriendSelection(friend.id)"> <span class="chat-avatar-headshot" class-name="avatar-card-image avatar" chat-avatar-headshot user-id="{{friend.id}}" layout-library="chatLibrary.layoutLibrary"> </span> <div class="avatar-status avatar-status" ng-class="userPresenceTypes[friend.presence.userPresenceType][\'className\']"></div> </div> <div class="border-bottom friend-info-action" ng-click="toggleFriendSelection(friend.id)"> <div class="text-overflow friend-info"> <div class="dynamic-overflow-container no-wrap"> <div class="small text-overflow text-sec friend-name dynamic-ellipsis-item"> {{friend.nameForDisplay}}</div> </div> <div class="xsmall text-overflow text-secondary friend-status"> {{userPresenceTypes[friend.presence.userPresenceType].title}}</div> </div> <div class="checkbox friend-action"> <input id="checkbox-select-{{dialogData.layoutId}}-{{friend.id}}" type="checkbox" ng-click="toggleFriendSelection(friend.id, $event)" ng-checked="dialogData.selectedUsersDict[friend.id]"> <label for="checkbox-select-{{dialogData.layoutId}}-{{friend.id}}"> </label> </div> </div> </div> </li> </ul> </div> <div toast toast-layout="toastLayout"></div> </div> </div> '
            },
            3812: function(e) {
                e.exports = '<div> <div ng-hide="message.isSystemMessageFromApi"> <span class="font-footer text-muted indicated-message-bubble system-message-content" ng-show="message.isSystemMessage && !message.hasParams" ng-bind-html="message.content"></span> <span class="font-footer text-muted indicated-message-bubble system-message-content" ng-show="message.isSystemMessage && message.hasParams">{{chatLibrary.friendsDict[dialogData.recentUserIdFromPresence].name}}{{message.content}}{{chatLibrary.placesLibrary[dialogData.recentPlaceIdFromPresence].placeName}}</span> </div> </div>'
            },
            293: function(e) {
                e.exports = '<div ng-controller="userConversationInfoController"> <div class="border-bottom chat-friend-info" ng-class="{\'has-universe\': isGameAvailableInChat()}"> <div class="chat-friend-info-top dynamic-overflow-container"> <span class="small text-title text-overflow font-caption-header chat-friend-name dynamic-ellipsis-item" ng-class="{\'unread\': shouldShowUnread(), \'read\': !shouldShowUnread()}" ng-bind="chatUser.title  || chatUser.name "></span> </div> <span class="xsmall text-info chat-brief-timestamp" ng-class="{\'font-bold secondary unread\': shouldShowUnread(), \'read\': !shouldShowUnread()}" ng-if="!isGameAvailableInChat()" ng-bind="chatUser.displayMessage.briefTimeStamp || chatUser.briefTimeStamp"></span> <span class="xsmall text-overflow text-info font-caption-body chat-friend-message" ng-class="{\'unread\': shouldShowUnread(), \'read\': !shouldShowUnread()}" display-message ng-if="chatUser.displayMessage && !chatUser.isUserPending"></span> </div> <div class="border-bottom chat-conversation-universe" ng-if="isGameAvailableInChat()" title="{{chatLibrary.placesLibrary[chatUser.placeForShown.rootPlaceId].placeName}}" ng-class="{\'album\': hasGameAlbum()}" ng-mouseover="openGameList()" popover-trigger=" \'none\' " popover-class="game-list-per-conversation game-list-{{chatUser.id}}" popover-placement="left-bottom" popover-append-to-body="true" popover-is-open="hoverPopoverParams.isOpen" hover-popover-params="hoverPopoverParams" hover-popover uib-popover-template="\'{{gamesListTemplateUrl}}\'"> <span chat-game-icon class-name="universe-image" layout-library="chatLibrary.layoutLibrary" ng-if="chatUser.placeForShown.universeId" universe-id="{{chatUser.placeForShown.universeId}}"></span> </div> </div> '
            },
            4720: function(e) {
                "use strict";
                e.exports = CoreUtilities
            },
            792: function(e) {
                "use strict";
                e.exports = Roblox
            },
            2222: function(e) {
                "use strict";
                e.exports = RobloxUserProfiles
            },
            5734: function(e) {
                "use strict";
                e.exports = angular
            }
        },
        i = {};

    function n(e) {
        if (i[e]) return i[e].exports;
        var a = i[e] = {
            exports: {}
        };
        return t[e](a, a.exports, n), a.exports
    }
    n.n = function(e) {
            var a = e && e.__esModule ? function() {
                return e.default
            } : function() {
                return e
            };
            return n.d(a, {
                a: a
            }), a
        }, n.d = function(e, a) {
            for (var t in a) n.o(a, t) && !n.o(e, t) && Object.defineProperty(e, t, {
                enumerable: !0,
                get: a[t]
            })
        }, n.o = function(e, a) {
            return Object.prototype.hasOwnProperty.call(e, a)
        }, n.r = function(e) {
            "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
                value: "Module"
            }), Object.defineProperty(e, "__esModule", {
                value: !0
            })
        },
        function() {
            "use strict";
            var e = n(5734),
                a = n.n(e),
                t = n(3544),
                i = n(9472);
            (0, t.importFilesUnderPath)(n(4940)), (0, t.importFilesUnderPath)(n(9083)), (0, t.importFilesUnderPath)(n(9084)), (0, t.importFilesUnderPath)(n(2883));
            var e = n(4850),
                r = (0, t.templateCacheGenerator)(a(), "chatAppTemplates", e);
            a().element(function() {
                a().bootstrap("#chat-container", [i.Z.name, r.name])
            })
        }()
}();
//# sourceMappingURL=https://js.rbxcdn.com/846902084ccbe7dff54209b9febe68fd-chat.bundle.min.js.map

/* Bundle detector */
window.Roblox && window.Roblox.BundleDetector && window.Roblox.BundleDetector.bundleDetected("Chat");