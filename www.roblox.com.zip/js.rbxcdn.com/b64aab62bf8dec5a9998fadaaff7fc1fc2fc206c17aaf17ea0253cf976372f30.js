! function() {
    var n = {
            1191: function(e, t, n) {
                var r = {
                    "./resources.js": 5738
                };

                function a(e) {
                    e = o(e);
                    return n(e)
                }

                function o(e) {
                    if (n.o(r, e)) return r[e];
                    e = new Error("Cannot find module '" + e + "'");
                    throw e.code = "MODULE_NOT_FOUND", e
                }
                a.keys = function() {
                    return Object.keys(r)
                }, a.resolve = o, (e.exports = a).id = 1191
            },
            8475: function(e, t, n) {
                var r = {
                    "./friendsListController.js": 6491,
                    "./peopleController.js": 5412,
                    "./peopleInfoCardController.js": 3037,
                    "./peopleListContainerController.js": 7047
                };

                function a(e) {
                    e = o(e);
                    return n(e)
                }

                function o(e) {
                    if (n.o(r, e)) return r[e];
                    e = new Error("Cannot find module '" + e + "'");
                    throw e.code = "MODULE_NOT_FOUND", e
                }
                a.keys = function() {
                    return Object.keys(r)
                }, a.resolve = o, (e.exports = a).id = 8475
            },
            7389: function(e, t, n) {
                var r = {
                    "./peopleDirective.js": 5733,
                    "./peopleListContainerDirective.js": 2034,
                    "./peopleListDirective.js": 2617
                };

                function a(e) {
                    e = o(e);
                    return n(e)
                }

                function o(e) {
                    if (n.o(r, e)) return r[e];
                    e = new Error("Cannot find module '" + e + "'");
                    throw e.code = "MODULE_NOT_FOUND", e
                }
                a.keys = function() {
                    return Object.keys(r)
                }, a.resolve = o, (e.exports = a).id = 7389
            },
            8051: function(e, t, n) {
                var r = {
                    "./friendsService.js": 5029,
                    "./gamesService.js": 4213,
                    "./layoutService.js": 1886,
                    "./utilityService.js": 7498
                };

                function a(e) {
                    e = o(e);
                    return n(e)
                }

                function o(e) {
                    if (n.o(r, e)) return r[e];
                    e = new Error("Cannot find module '" + e + "'");
                    throw e.code = "MODULE_NOT_FOUND", e
                }
                a.keys = function() {
                    return Object.keys(r)
                }, a.resolve = o, (e.exports = a).id = 8051
            },
            6506: function(e, t, n) {
                var r = {
                    "./directives/templates/people.html": 2222,
                    "./directives/templates/peopleInfoCard.html": 2662,
                    "./directives/templates/peopleList.html": 2844,
                    "./directives/templates/peopleListContainer.html": 186
                };

                function a(e) {
                    e = o(e);
                    return n(e)
                }

                function o(e) {
                    if (n.o(r, e)) return r[e];
                    e = new Error("Cannot find module '" + e + "'");
                    throw e.code = "MODULE_NOT_FOUND", e
                }
                a.keys = function() {
                    return Object.keys(r)
                }, a.resolve = o, (e.exports = a).id = 6506
            },
            3544: function(e) {
                function o(e) {
                    return e.replace(/([a-z])([A-Z])/g, "$1-$2").toLowerCase()
                }

                function i(e) {
                    return e.split("/").pop().replace(".html", "")
                }
                var t = {
                    importFilesUnderPath: function(e) {
                        e.keys().forEach(e)
                    },
                    templateCacheGenerator: function(e, t, r, a) {
                        return e.module(t, []).run(["$templateCache", function(n) {
                            r && r.keys().forEach(function(e) {
                                var t = o(i(e));
                                n.put(t, r(e))
                            }), a && a.keys().forEach(function(e) {
                                var t = o(i(e));
                                n.put(t, a(e).replace(/<\/?script[^>]*>/gi, ""))
                            })
                        }])
                    }
                };
                e.exports = t
            },
            5738: function(e, t, n) {
                "use strict";
                n.r(t);
                var r = n(792),
                    n = n(895),
                    r = {
                        templateUrls: {
                            peopleListContainer: "people-list-container",
                            peopleList: "people-list",
                            peopleInfoCard: "people-info-card",
                            people: "people"
                        },
                        apiSets: {
                            getFriendsListUrl: {
                                url: r.EnvironmentUrls ? "".concat(r.EnvironmentUrls.friendsApi, "/v1/users/{userId}/friends") : "/v1/users/{userId}/friends",
                                retryable: !0,
                                withCredentials: !0
                            },
                            getMetadataUrl: {
                                url: r.EnvironmentUrls ? "".concat(r.EnvironmentUrls.friendsApi, "/v1/metadata") : "/v1/metadata",
                                retryable: !0,
                                withCredentials: !0
                            },
                            getPresences: {
                                url: r.EnvironmentUrls ? "".concat(r.EnvironmentUrls.presenceApi, "/v1/presence/users") : "/v1/presence/users",
                                retryable: !0,
                                withCredentials: !0
                            },
                            multiGetPlaceDetails: {
                                url: r.EnvironmentUrls ? "".concat(r.EnvironmentUrls.gamesApi, "/v1/games/multiget-place-details") : "/v1/games/multiget-place-details",
                                retryable: !0,
                                withCredentials: !0
                            },
                            multiGetGameIcons: {
                                url: r.EnvironmentUrls ? "".concat(r.EnvironmentUrls.gamesApi, "/v1/games/game-thumbnails") : "/v1/games/game-thumbnails",
                                retryable: !0,
                                withCredentials: !0
                            }
                        },
                        apiParams: {
                            avatarMultiGetLimit: 100,
                            presenceMultiGetLimit: 100
                        },
                        gameIconSize: {
                            lg: {
                                width: 150,
                                height: 150
                            }
                        },
                        eventStreamParams: {
                            goToProfileFromAvatar: {
                                name: "goToProfileFromAvatar",
                                ctx: "click"
                            },
                            goToProfileInPeopleList: {
                                name: "goToProfileFromPeopleList",
                                ctx: "click"
                            },
                            openPeopleList: {
                                name: "openPeopleList",
                                ctx: "hover"
                            },
                            goToChatInPeopleList: {
                                name: "goToChatFromPeopleList",
                                ctx: "click"
                            },
                            joinGameInPeopleList: {
                                name: "joinGameInPeopleList",
                                ctx: "click"
                            },
                            goToGameDetailFromAvatar: {
                                name: "goToGameDetailFromAvatar",
                                ctx: "click"
                            },
                            goToGameDetailInPeopleList: {
                                name: "goToGameDetailInPeopleList",
                                ctx: "click"
                            },
                            gamePlayIntentInPeopleList: {
                                ctx: "peopleListInHomePage"
                            },
                            gameImpressions: {
                                name: "gameImpressions",
                                ctx: "hover"
                            },
                            sessionInfoTypes: {
                                homePageSessionInfo: "homePageSessionInfo"
                            },
                            pageContexts: {
                                peopleListInHomePage: "peopleListInHomePage"
                            }
                        },
                        hoverPopoverParams: {
                            isOpen: !1,
                            triggerSelector: "",
                            hoverPopoverSelector: "",
                            isDisabled: !!r.DeviceMeta && (!(0, r.DeviceMeta)().isDesktop || (0, r.DeviceMeta)().isUWPApp)
                        },
                        reasonProhibitedMessage: {
                            None: "None",
                            PurchaseRequired: "PurchaseRequired"
                        },
                        peopleInfoCardContainerClass: "card-with-game"
                    };
                n.Z.constant("resources", r), t.default = r
            },
            6491: function(e, t, n) {
                "use strict";
                n.r(t);
                var r = n(5734),
                    i = n.n(r),
                    n = n(895);

                function a(a, e, t, r, o, n) {
                    a.clickAvatar = function(e, t) {
                        var n = o.eventStreamParams.goToProfileFromAvatar,
                            t = {
                                friendId: e.id,
                                presentStatus: e.presence.userPresenceType,
                                position: t
                            };
                        e.presence.rootPlaceId && (t.rootPlaceId = e.presence.rootPlaceId), r.sendEventWithTarget(n.name, n.ctx, t)
                    }, a.clickPlaceLink = function(e, t) {
                        var n = o.eventStreamParams.goToGameDetailFromAvatar,
                            e = {
                                friendId: e.id,
                                position: t,
                                rootPlaceId: e.presence.rootPlaceId
                            };
                        r.sendEventWithTarget(n.name, n.ctx, e)
                    }, a.updatePresenceStatus = function(e) {
                        for (var t = [], n = 0; n < e.length; n++) {
                            var r = e[n];
                            r.rootPlaceId && !a.library.placesDict[r.rootPlaceId] && t.push(r.rootPlaceId), a.updatePresenceData(r)
                        }
                        0 < t.length && i().isFunction(a.setPlaceDetails) && a.setPlaceDetails(t)
                    }, a.listenToPresenceUpdate = function() {
                        document.addEventListener("Roblox.Presence.Update", function(e) {
                            null != e && e.detail && n(function() {
                                a.updatePresenceStatus(e.detail)
                            })
                        })
                    }, a.init = function() {
                        a.listenToPresenceUpdate()
                    }, a.init()
                }
                a.$inject = ["$scope", "$log", "$document", "eventStreamService", "resources", "$timeout"], n.Z.controller("friendsListController", a), t.default = a
            },
            5412: function(e, t, n) {
                "use strict";
                n.r(t);
                var r = n(5734),
                    a = n.n(r),
                    n = n(895);

                function o(e, t, n) {
                    e.setupHoverPopover = function() {
                        e.peopleInfoCardPlacement = "bottom", e.peopleInfoCardTemplateUrl = n.templateUrls.peopleInfoCard, e.peopleInfoCardContainerClass = e.friend.presence && e.friend.presence.placeUrl ? n.peopleInfoCardContainerClass : "", e.hoverPopoverParams = a().copy(n.hoverPopoverParams), e.hoverPopoverParams.triggerSelector = "#people-".concat(e.friend.id), e.hoverPopoverParams.hoverPopoverSelector = ".people-info-".concat(e.friend.id), e.hoverPopoverParams.isDisabled = e.hoverPopoverParams.isDisabled || !e.library.isForCurrentUsersFriends
                    }, e.init = function() {
                        e.setupHoverPopover()
                    }, e.init()
                }
                o.$inject = ["$scope", "$log", "resources"], n.Z.controller("peopleController", o), t.default = o
            },
            3037: function(e, t, n) {
                "use strict";
                n.r(t);
                var r = n(895),
                    l = n(4720),
                    f = n(292);

                function a(s, e, u, c, n, i, t, r, d) {
                    s.sendEventStream = function(e, t) {
                        (t = t || {}).friendId = s.friend.id, t.position = s.$index, r.sendEventWithTarget(e.name, e.ctx, t)
                    }, s.sendGamePlayEvent = function(e) {
                        r.sendGamePlayEvent(u.eventStreamParams.gamePlayIntentInPeopleList.ctx, e)
                    }, s.sendGameImpressionEvent = function(e, t, n) {
                        var r = u.eventStreamParams.pageContexts,
                            a = f.sessionStorageService.getEventTracker().homePageSessionInfo,
                            a = {
                                universeIds: JSON.stringify([e]),
                                rootPlaceIds: JSON.stringify([t]),
                                absPositions: JSON.stringify([0]),
                                sortPos: 0,
                                page: r.peopleListInHomePage,
                                homePageSessionInfo: a
                            };
                        s.sendEventStream(u.eventStreamParams.gameImpressions, a)
                    }, s.clickBtn = function(e) {
                        var t = s.friend.presence.rootPlaceId,
                            n = s.library.placesDict[t],
                            r = c.playButtons,
                            a = {
                                rootPlaceId: t
                            },
                            o = u.eventStreamParams;
                        switch (n.buttonLayout.type) {
                            case r.join.type:
                                var i = s.friend.presence.gameId,
                                    l = s.friend.id,
                                    l = d.buildPlayGameProperties(t, s.friend.presence.placeId, i, l);
                                a.gameInstanceId = i, a.friendId = s.friend.id, a.position = s.$index;
                                i = {
                                    eventName: o.joinGameInPeopleList.name,
                                    ctx: o.joinGameInPeopleList.ctx,
                                    properties: a,
                                    gamePlayIntentEventCtx: u.eventStreamParams.gamePlayIntentInPeopleList.ctx
                                };
                                d.launchGame(l, i);
                                break;
                            case r.details.type:
                                s.goToGameDetails(e)
                        }
                    }, s.goToGameDetails = function(e) {
                        var t = u.eventStreamParams,
                            n = s.friend.presence,
                            r = n.rootPlaceId,
                            a = n.universeId,
                            o = n.userId,
                            n = t.pageContexts.peopleListInHomePage,
                            e = {
                                rootPlaceId: r,
                                fromWhere: e,
                                page: n
                            };
                        s.sendEventStream(t.goToGameDetailInPeopleList, e);
                        r = {
                            page: n,
                            friendId: o,
                            universeId: a,
                            placeId: r,
                            position: 0,
                            homePageSessionInfo: f.sessionStorageService.getEventTracker().homePageSessionInfo
                        }, r = "".concat(s.friend.presence.placeUrl, "?").concat(l.urlService.composeQueryString(r));
                        i.location.href = l.urlService.getAbsoluteUrl(r)
                    }, s.goToChat = function() {
                        var e = s.friend.id;
                        s.sendEventStream(u.eventStreamParams.goToChatInPeopleList);
                        var t = n.buildPermissionVerifier({});
                        n.startChat(e, t)
                    }, s.goToProfilePage = function() {
                        s.sendEventStream(u.eventStreamParams.goToProfileInPeopleList), i.location.href = l.urlService.getAbsoluteUrl(s.friend.profileUrl)
                    }, s.init = function() {
                        s.sendEventStream(u.eventStreamParams.openPeopleList);
                        var e = s.friend.presence;
                        null != e && e.universeId && null != e && e.rootPlaceId && s.sendGameImpressionEvent(e.universeId, e.rootPlaceId, s.$index)
                    }, s.init()
                }
                a.$inject = ["$scope", "$log", "resources", "layoutService", "chatDispatchService", "$window", "gamesService", "eventStreamService", "playGameService"], r.Z.controller("peopleInfoCardController", a), t.default = a
            },
            7047: function(e, t, n) {
                "use strict";
                n.r(t), n.d(t, {
                    default: function() {
                        return a
                    }
                });
                var t = n(5734),
                    d = n.n(t),
                    f = n(792),
                    p = n(9589),
                    m = RobloxUserProfiles,
                    t = n(895),
                    v = n(3747);

                function r(i, e, t, n, r, a, o, l, s) {
                    function u() {
                        var e = (0, v.j)();
                        return !(null !== e || !f.CurrentUser) || e === f.CurrentUser.userId
                    }

                    function c() {
                        try {
                            (0, p.initRobloxBadgesFrameworkAgnostic)({
                                overrideIconClass: "verified-badge-icon-friends-carousel"
                            })
                        } catch (e) {}
                    }
                    i.setPlaceDetails = function(e) {
                        a.multiGetPlaceDetails(e).then(function(e) {
                            d().forEach(e, function(e, t) {
                                if (e) switch ((i.library.placesDict[t] = e).reasonProhibited) {
                                    case o.reasonProhibitedMessage.None:
                                        i.library.placesDict[t].buttonLayout = d().copy(r.playButtons.join);
                                        break;
                                    case o.reasonProhibitedMessage.PurchaseRequired:
                                        i.library.placesDict[t].requiredPurchase = !0;
                                    default:
                                        i.library.placesDict[t].buttonLayout = d().copy(r.playButtons.details)
                                }
                            })
                        })
                    }, i.safelyUpdatePresenceData = function(e, t) {
                        e ? (t && !t.userId && (t = {
                            lastLocation: "Website",
                            userId: e,
                            userPresenceType: 0
                        }, i.layout.invalidPresenceData = !0), t && i.updatePresenceData(t)) : i.layout.invalidPresenceData = !0
                    }, i.updatePresenceData = function(e) {
                        var t = r.presenceTypes;
                        switch (e.userPresenceType) {
                            case t.online.status:
                                e.className = r.presenceTypes.online.className;
                                break;
                            case t.ingame.status:
                                e.className = r.presenceTypes.ingame.className, e.rootPlaceId && (e.placeUrl = r.getGameDetailsPageUrl(e.rootPlaceId));
                                break;
                            case t.instudio.status:
                                e.className = r.presenceTypes.instudio.className, e.rootPlaceId && (e.placeUrl = r.getGameDetailsPageUrl(e.rootPlaceId))
                        }
                        i.library.friendsDict[e.userId] || (i.library.friendsDict[e.userId] = {}), i.library.friendsDict[e.userId].presence = e
                    }, i.buildFriendsInfo = function(a, e) {
                        e.shouldGetPresenceData ? t.getPresences(a).then(function(e) {
                            var r = [];
                            d().forEach(e, function(e, t) {
                                var n = e.rootPlaceId;
                                n && !i.library.placesDict[n] && r.push(n), i.safelyUpdatePresenceData(a[t], e)
                            }), 0 < r.length && i.setPlaceDetails(r), i.layout.isAllFriendsDataLoaded = !0, c()
                        }) : (i.library.isForCurrentUsersFriends || a.sort(function(e, t) {
                            e = i.library.friendsDict[e], t = i.library.friendsDict[t];
                            return e.name.toLowerCase() > t.name.toLowerCase() ? 1 : -1
                        }), i.library.friendIds = a, i.layout.isAllFriendsDataLoaded = !0, c())
                    }, i.buildFriendsList = function(e) {
                        i.layout.namesLoading = !0, t.getFriendsList(e).then(function(e) {
                            var a = e.data || e,
                                n = [];
                            d().forEach(a, function(e) {
                                var t = e.id;
                                n.indexOf(t) < 0 && n.push(t), e.profileUrl = r.getProfilePageUrl(t), e.hasVerifiedBadge = e.hasVerifiedBadge, i.library.friendsDict[t] = e
                            });
                            e = [m.UserProfileField.Names.CombinedName];
                            s.watchUserProfiles(n, e).subscribe(function(e) {
                                var t = e.loading,
                                    n = e.error,
                                    r = e.data;
                                i.layout.namesLoading = t, i.error = n, d().forEach(a, function(e) {
                                    e.nameToDisplay = r[e.id].names.combinedName
                                })
                            }), i.buildFriendsInfo(n, {
                                shouldGetPresenceData: i.library.isForCurrentUsersFriends
                            }), i.library.numOfFriends = a.length
                        }, function(e) {
                            i.layout.friendsError = !0, i.layout.isAllFriendsDataLoaded = !0
                        })
                    }, i.setup = function() {
                        i.library = {
                            friendsDict: {},
                            friendIds: [],
                            isForCurrentUsersFriends: u(),
                            placesDict: {},
                            numOfFriends: null
                        }, i.layout = r
                    }, i.buildFriendsListFromSharedService = function(o) {
                        i.layout.invalidPresenceData = !1, i.layout.namesLoading = !0, i.$evalAsync(function() {
                            var n, r, a, e;
                            null != o && o.length && (n = [], r = [], a = 0, d().forEach(o, function(e) {
                                var t = e.id;
                                i.library.friendsDict[t] = e, n.push(t);
                                t = e.presence.rootPlaceId;
                                t && !i.library.placesDict[t] && r.push(t), i.safelyUpdatePresenceData(e.id, e.presence), a += 1
                            }), i.library.numOfFriends = a, i.library.friendIds = n, e = [m.UserProfileField.Names.CombinedName], s.watchUserProfiles(n, e).subscribe(function(e) {
                                var t = e.loading,
                                    n = e.error,
                                    r = e.data;
                                i.layout.namesLoading = t, i.error = n, d().forEach(o, function(e) {
                                    e.nameToDisplay = r[e.id].names.combinedName
                                })
                            }), 0 < r.length && i.setPlaceDetails(r)), i.layout.isAllFriendsDataLoaded = !0, c()
                        })
                    }, i.init = function() {
                        i.setup();
                        var e = null !== (e = (0, v.j)()) && void 0 !== e ? e : f.CurrentUser.userId;
                        u() ? l.getFriendsPresence().then(function(e) {
                            i.buildFriendsListFromSharedService(e)
                        }, function(e) {
                            console.debug(e), i.layout.friendsError = !0, i.layout.isAllFriendsDataLoaded = !0
                        }) : i.buildFriendsList(e)
                    }, i.init()
                }
                r.$inject = ["$scope", "$log", "friendsService", "utilityService", "layoutService", "gamesService", "resources", "usersPresenceService", "userProfilesService"], t.Z.controller("peopleListContainerController", r);
                var a = r
            },
            5733: function(e, t, n) {
                "use strict";
                n.r(t);
                n = n(895);

                function r(e) {
                    return {
                        restrict: "A",
                        scope: !0,
                        replace: !0,
                        templateUrl: e.templateUrls.people
                    }
                }
                r.$inject = ["resources"], n.Z.directive("people", r), t.default = r
            },
            2034: function(e, t, n) {
                "use strict";
                n.r(t);
                n = n(895);

                function r(e, t) {
                    return {
                        restrict: "A",
                        scope: !0,
                        replace: !0,
                        templateUrl: e.templateUrls.peopleListContainer,
                        link: function() {
                            t.isFriendsListLoaded = !0
                        }
                    }
                }
                r.$inject = ["resources", "$rootScope"], n.Z.directive("peopleListContainer", r), t.default = r
            },
            2617: function(e, t, n) {
                "use strict";
                n.r(t);
                n = n(895);

                function r(e) {
                    return {
                        restrict: "A",
                        scope: !0,
                        replace: !0,
                        templateUrl: e.templateUrls.peopleList
                    }
                }
                r.$inject = ["resources"], n.Z.directive("peopleList", r), t.default = r
            },
            895: function(e, t, n) {
                "use strict";
                var r = n(792),
                    a = n(5734),
                    a = n.n(a)().module("peopleList", ["peopleListHtmlTemplateApp", "robloxApp", "ui.bootstrap", "thumbnails", "userProfiles"]).config(["languageResourceProvider", function(e) {
                        var t = (new r.TranslationResourceProvider).getTranslationResource("Feature.PeopleList");
                        e.setTranslationResources([t])
                    }]);
                t.Z = a
            },
            5029: function(e, t, n) {
                "use strict";
                n.r(t);
                n = n(895);

                function r(s, n, u, r) {
                    var a = n.apiSets;
                    return {
                        getFriendsList: function(e) {
                            var t = a.getFriendsListUrl.url;
                            return a.getFriendsListUrl.url = r("formatString")(t, {
                                userId: e
                            }), u.httpGet(a.getFriendsListUrl)
                        },
                        buildBatchPromises: function(e, t, n, r) {
                            for (var a = [], o = 0, i = e.slice(o, t); 0 < i.length;) {
                                var l = {
                                    userIds: i
                                };
                                r ? a.push(u.httpPost(n, l)) : a.push(u.httpGet(n, l)), o++, i = e.slice(o * t, o * t + t)
                            }
                            return s.all(a)
                        },
                        getPresences: function(e) {
                            var t = n.apiParams.presenceMultiGetLimit;
                            return this.buildBatchPromises(e, t, a.getPresences, !0).then(function(e) {
                                if (e && 0 < e.length) {
                                    var t = [];
                                    return angular.forEach(e, function(e) {
                                        e = e.userPresences;
                                        t = t.concat(e)
                                    }), t
                                }
                                return null
                            })
                        },
                        getMetadata: function(e) {
                            e = {
                                targetUserId: e
                            };
                            return u.httpGet(a.getMetadataUrl, e)
                        }
                    }
                }
                r.$inject = ["$q", "resources", "httpService", "$filter"], n.Z.factory("friendsService", r), t.default = r
            },
            4213: function(e, t, n) {
                "use strict";
                n.r(t);
                var a = n(792),
                    n = n(895);

                function r(e, t, n) {
                    var r = t.apiSets;
                    return {
                        joinGame: function(e, t) {
                            a.GameLauncher.joinGameInstance(e, t, !0, !0)
                        },
                        multiGetPlaceDetails: function(e) {
                            e = {
                                placeIds: e
                            };
                            return n.httpGet(r.multiGetPlaceDetails, e).then(function(e) {
                                var t = [],
                                    n = {};
                                return angular.forEach(e, function(e) {
                                    e && e.imageToken && t.push(e.imageToken), n[e.placeId] = e
                                }), n
                            })
                        }
                    }
                }
                r.$inject = ["$q", "resources", "httpService"], n.Z.factory("gamesService", r), t.default = r
            },
            1886: function(e, t, n) {
                "use strict";
                n.r(t);
                var r = n(895),
                    o = n(3747);

                function a(e, t, n, r) {
                    var a = e;
                    return {
                        sectionTitle: a.get("Heading.Friends"),
                        seeAllBtnText: a.get("Heading.SeeAll"),
                        maxNumberOfFriendsDisplayed: 24,
                        isAllFriendsDataLoaded: !1,
                        isAvatarDataLoaded: !1,
                        presenceTypes: {
                            offline: {
                                status: 0,
                                className: ""
                            },
                            online: {
                                status: 1,
                                className: "icon-online"
                            },
                            ingame: {
                                status: 2,
                                className: "icon-game"
                            },
                            instudio: {
                                status: 3,
                                className: "icon-studio"
                            }
                        },
                        getFriendsPageUrl: function() {
                            var e = (0, o.j)();
                            return null !== e ? t.getAbsoluteUrl("/users/".concat(e, "/friends")) : t.getAbsoluteUrl("/users/friends")
                        },
                        getGameDetailsPageUrl: function(e) {
                            e = n("formatString")("/games/{placeId}/gamename", {
                                placeId: e
                            });
                            return t.getAbsoluteUrl(e)
                        },
                        getProfilePageUrl: function(e) {
                            e = n("formatString")("/users/{userId}/profile", {
                                userId: e
                            });
                            return t.getAbsoluteUrl(e)
                        },
                        playButtons: {
                            join: {
                                type: "join",
                                text: a.get("Action.Join"),
                                className: "btn-growth-sm",
                                isPlayable: !0
                            },
                            buy: {
                                type: "buy",
                                text: a.get("Action.Buy"),
                                className: "btn-primary-sm",
                                isPlayable: !1
                            },
                            details: {
                                type: "details",
                                text: a.get("Action.ViewDetails"),
                                className: "btn-control-sm",
                                isPlayable: !1
                            }
                        },
                        interactionLabels: {
                            chat: function(e) {
                                return a.get("Label.Chat", {
                                    username: e
                                })
                            },
                            viewProfile: a.get("Label.ViewProfile")
                        },
                        thumbnailTypes: r.thumbnailTypes
                    }
                }
                a.$inject = ["languageResource", "urlService", "$filter", "thumbnailConstants"], r.Z.factory("layoutService", a), t.default = a
            },
            7498: function(e, t, n) {
                "use strict";
                n.r(t);
                n = n(895);

                function r(l, s, e) {
                    return {
                        sortFriendsByOnlineOffline: function(t) {
                            var e = l("orderBy"),
                                n = [],
                                r = [];
                            angular.forEach(t.friendsDict, function(e) {
                                (e.presence && 0 < e.presence.userPresenceType ? n : r).push(e)
                            }), n = e(n, "+name"), r = e(r, "+name"), (n = n.concat(r)).forEach(function(e) {
                                t.friendIds.push(e.id)
                            })
                        },
                        sortFriendsByPresenceType: function(t) {
                            var e = l("orderBy"),
                                n = [],
                                r = [],
                                a = [],
                                o = [],
                                i = s.presenceTypes;
                            angular.forEach(t.friendsDict, function(e) {
                                if (!e.presence) return !1;
                                switch (e.presence.userPresenceType) {
                                    case i.online.status:
                                        n.push(e);
                                        break;
                                    case i.offline.status:
                                        r.push(e);
                                        break;
                                    case i.ingame.status:
                                        a.push(e);
                                        break;
                                    case i.instudio.status:
                                        o.push(e)
                                }
                            }), n = e(n, "+name"), r = e(r, "+name"), a = e(a, "+name"), o = e(o, "+name"), (a = (a = (a = a.concat(n)).concat(o)).concat(r)).forEach(function(e) {
                                t.friendIds.indexOf(e.id) < 0 && t.friendIds.push(e.id)
                            })
                        }
                    }
                }
                r.$inject = ["$filter", "layoutService", "$log"], n.Z.factory("utilityService", r), t.default = r
            },
            3747: function(e, t, n) {
                "use strict";

                function r() {
                    var e = /\/users\/(\d+)\//g.exec(window.location.pathname);
                    return e ? e[1] : null
                }
                n.d(t, {
                    j: function() {
                        return r
                    }
                })
            },
            2779: function(e, t) {
                var n;
                /*!
                	Copyright (c) 2018 Jed Watson.
                	Licensed under the MIT License (MIT), see
                	http://jedwatson.github.io/classnames
                */
                ! function() {
                    "use strict";
                    var i = {}.hasOwnProperty;

                    function l() {
                        for (var e = [], t = 0; t < arguments.length; t++) {
                            var n = arguments[t];
                            if (n) {
                                var r, a = typeof n;
                                if ("string" == a || "number" == a) e.push(n);
                                else if (Array.isArray(n)) !n.length || (r = l.apply(null, n)) && e.push(r);
                                else if ("object" == a)
                                    if (n.toString === Object.prototype.toString || n.toString.toString().includes("[native code]"))
                                        for (var o in n) i.call(n, o) && n[o] && e.push(o);
                                    else e.push(n.toString())
                            }
                        }
                        return e.join(" ")
                    }
                    e.exports ? (l.default = l, e.exports = l) : void 0 === (n = function() {
                        return l
                    }.apply(t, [])) || (e.exports = n)
                }()
            },
            2222: function(e) {
                e.exports = '<div ng-controller="peopleController"> <div class="avatar-container"> <a href="{{friend.profileUrl}}" class="text-link friend-link" ng-click="clickAvatar(friend, $index)" popover-trigger=" \'none\' " popover-class="people-info-card-container {{peopleInfoCardContainerClass}} people-info-{{friend.id}}" popover-placement="{{peopleInfoCardPlacement}}" popover-append-to-body="true" popover-is-open="hoverPopoverParams.isOpen" hover-popover-params="hoverPopoverParams" hover-popover uib-popover-template="\'{{peopleInfoCardTemplateUrl}}\'"> <div class="avatar avatar-card-fullbody"> <span class="avatar-card-link friend-avatar" ng-class="{\'icon-placeholder-avatar-headshot\': !friend.avatar.imageUrl}"> <thumbnail-2d class="avatar-card-image" thumbnail-type="layout.thumbnailTypes.avatarHeadshot" thumbnail-target-id="friend.id"></thumbnail-2d> </span> </div> <div ng-class="{\'shimmer\': layout.namesLoading}" class="friend-parent-container"> <div class="friend-name-container"> <span class="text-overflow friend-name font-caption-header" ng-bind="friend.nameToDisplay" title="{{friend.nameToDisplay}}"></span> <span ng-class="{\'hide\': !friend.hasVerifiedBadge || layout.namesLoading}"> <span class="verified-badge-icon-friends-carousel" data-size="CaptionHeader" data-overrideimgclass="verified-badge-icon-friends-carousel-rendered"> </span> </span> </div> </div> <div class="text-overflow xsmall text-label place-name" ng-if="friend.presence.placeUrl" ng-bind="library.placesDict[friend.presence.rootPlaceId].name"></div> </a> <a class="friend-status place-link" ng-href="{{friend.presence.placeUrl}}" ng-if="friend.presence.placeUrl" ng-click="clickPlaceLink(friend, $index)"> <span class="avatar-status friend-status {{friend.presence.className}}" title="{{friend.presence.lastLocation}}"></span> </a> <span ng-if="!friend.presence.placeUrl" class="avatar-status friend-status {{friend.presence.className}}" title="{{friend.presence.lastLocation}}"></span> </div> </div>'
            },
            2662: function(e) {
                e.exports = '<div ng-controller="peopleInfoCardController" ng-class="{\'card-with-game\': friend.presence.placeUrl}"> <div class="border-bottom place-container" ng-show="friend.presence.placeUrl"> <span ng-click="goToGameDetails(\'icon\')"> <thumbnail-2d class="cursor-pointer place-icon" thumbnail-type="layout.thumbnailTypes.gameIcon" thumbnail-target-id="library.placesDict[friend.presence.rootPlaceId].universeId"></thumbnail-2d> </span> <div class="place-info-container"> <div class="place-info"> <span class="text-subject cursor-pointer place-title" ng-bind="library.placesDict[friend.presence.rootPlaceId].name" ng-click="goToGameDetails(\'link\')"></span> <div class="icon-text-wrapper" ng-show="library.placesDict[friend.presence.rootPlaceId].requiredPurchase"> <span class="icon-robux"></span> <span class="text-robux" ng-bind="library.placesDict[friend.presence.rootPlaceId].price"></span> </div> </div> <div class="place-btn-container"> <button class="btn-full-width place-btn {{library.placesDict[friend.presence.rootPlaceId].buttonLayout.className}}" ng-click="clickBtn(\'btn\')"> {{library.placesDict[friend.presence.rootPlaceId].buttonLayout.text}} </button> </div> </div> </div> <ul class="dropdown-menu interaction-container"> <li class="interaction-item" ng-click="goToChat()"> <span class="icon icon-chat-gray"></span> <span class="text-overflow border-bottom label" ng-bind="layout.interactionLabels.chat(friend.nameToDisplay)" title="{{layout.interactionLabels.chat(friend.nameToDisplay)}}"></span> </li> <li class="interaction-item" ng-click="goToProfilePage()"> <span class="icon icon-viewdetails"></span> <span class="label" ng-bind="layout.interactionLabels.viewProfile"></span> </li> </ul> </div>'
            },
            2844: function(e) {
                e.exports = '<ul class="hlist" ng-controller="friendsListController"> <li id="people-{{friend.id}}" rbx-user-id="{{friend.id}}" class="list-item friend" ng-repeat="friend in library.friendsDict | orderList: library.friendIds | limitTo: layout.maxNumberOfFriendsDisplayed"> <div people></div> </li> </ul> '
            },
            186: function(e) {
                e.exports = '<div ng-controller="peopleListContainerController"> <div class="col-xs-12 people-list-container" ng-show="layout.isAllFriendsDataLoaded && library.numOfFriends > 0 || layout.friendsError"> <div class="section home-friends"> <div class="container-header people-list-header"> <h2> {{layout.sectionTitle}}<span ng-show="library.numOfFriends !== null" class="friends-count">({{library.numOfFriends}})</span> </h2> <span ng-show="layout.invalidPresenceData" class="presence-error"> <span class="icon-warning"></span> <span class="text-error" ng-bind="\'Label.PresenceError\' | translate"></span> </span> <a href="{{layout.getFriendsPageUrl()}}" class="btn-secondary-xs btn-more see-all-link-icon">{{layout.seeAllBtnText}}</a> </div> <div class="section-content remove-panel people-list"> <p ng-show="layout.friendsError" class="section-content-off" ng-bind="\'Label.FriendsError\' | translate"></p> <div people-list ng-class="{\'invisible\': !layout.isAllFriendsDataLoaded}"></div> <span class="spinner spinner-default" ng-show="!layout.isAllFriendsDataLoaded"></span> </div> </div> </div> <div class="col-xs-12 people-list-container" ng-hide="layout.isAllFriendsDataLoaded"> <div class="section home-friends"> <div class="container-header people-list-header"> <h2>{{layout.sectionTitle}}</h2> </div> <div class="section-content remove-panel people-list"> <span class="spinner spinner-default"></span> </div> </div> </div> </div> '
            },
            6635: function(N, D, A) {
                var k;
                /**
                 * @license
                 * Lodash <https://lodash.com/>
                 * Copyright OpenJS Foundation and other contributors <https://openjsf.org/>
                 * Released under MIT license <https://lodash.com/license>
                 * Based on Underscore.js 1.8.3 <http://underscorejs.org/LICENSE>
                 * Copyright Jeremy Ashkenas, DocumentCloud and Investigative Reporters & Editors
                 */
                N = A.nmd(N),
                    function() {
                        var Ho, zo = "Expected a function",
                            Vo = "__lodash_hash_undefined__",
                            Wo = "__lodash_placeholder__",
                            $o = 128,
                            qo = 9007199254740991,
                            Zo = NaN,
                            Ko = 4294967295,
                            Jo = [
                                ["ary", $o],
                                ["bind", 1],
                                ["bindKey", 2],
                                ["curry", 8],
                                ["curryRight", 16],
                                ["flip", 512],
                                ["partial", 32],
                                ["partialRight", 64],
                                ["rearg", 256]
                            ],
                            Yo = "[object Arguments]",
                            Qo = "[object Array]",
                            Xo = "[object Boolean]",
                            ei = "[object Date]",
                            ti = "[object Error]",
                            ni = "[object Function]",
                            ri = "[object GeneratorFunction]",
                            ai = "[object Map]",
                            oi = "[object Number]",
                            ii = "[object Object]",
                            li = "[object Promise]",
                            si = "[object RegExp]",
                            ui = "[object Set]",
                            ci = "[object String]",
                            di = "[object Symbol]",
                            fi = "[object WeakMap]",
                            pi = "[object ArrayBuffer]",
                            mi = "[object DataView]",
                            vi = "[object Float32Array]",
                            hi = "[object Float64Array]",
                            gi = "[object Int8Array]",
                            yi = "[object Int16Array]",
                            bi = "[object Int32Array]",
                            Ii = "[object Uint8Array]",
                            Pi = "[object Uint8ClampedArray]",
                            Ei = "[object Uint16Array]",
                            Si = "[object Uint32Array]",
                            wi = /\b__p \+= '';/g,
                            Ci = /\b(__p \+=) '' \+/g,
                            Ti = /(__e\(.*?\)|\b__t\)) \+\n'';/g,
                            _i = /&(?:amp|lt|gt|quot|#39);/g,
                            xi = /[&<>"']/g,
                            Li = RegExp(_i.source),
                            Ni = RegExp(xi.source),
                            Di = /<%-([\s\S]+?)%>/g,
                            Ai = /<%([\s\S]+?)%>/g,
                            ki = /<%=([\s\S]+?)%>/g,
                            Oi = /\.|\[(?:[^[\]]*|(["'])(?:(?!\1)[^\\]|\\.)*?\1)\]/,
                            Ri = /^\w*$/,
                            Ui = /[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g,
                            Mi = /[\\^$.*+?()[\]{}|]/g,
                            Gi = RegExp(Mi.source),
                            ji = /^\s+/,
                            n = /\s/,
                            Fi = /\{(?:\n\/\* \[wrapped with .+\] \*\/)?\n?/,
                            Bi = /\{\n\/\* \[wrapped with (.+)\] \*/,
                            Hi = /,? & /,
                            zi = /[^\x00-\x2f\x3a-\x40\x5b-\x60\x7b-\x7f]+/g,
                            Vi = /[()=,{}\[\]\/\s]/,
                            Wi = /\\(\\)?/g,
                            $i = /\$\{([^\\}]*(?:\\.[^\\}]*)*)\}/g,
                            qi = /\w*$/,
                            Zi = /^[-+]0x[0-9a-f]+$/i,
                            Ki = /^0b[01]+$/i,
                            Ji = /^\[object .+?Constructor\]$/,
                            Yi = /^0o[0-7]+$/i,
                            Qi = /^(?:0|[1-9]\d*)$/,
                            Xi = /[\xc0-\xd6\xd8-\xf6\xf8-\xff\u0100-\u017f]/g,
                            el = /($^)/,
                            tl = /['\n\r\u2028\u2029\\]/g,
                            e = "\\ud800-\\udfff",
                            t = "\\u0300-\\u036f\\ufe20-\\ufe2f\\u20d0-\\u20ff",
                            r = "\\u2700-\\u27bf",
                            a = "a-z\\xdf-\\xf6\\xf8-\\xff",
                            o = "A-Z\\xc0-\\xd6\\xd8-\\xde",
                            i = "\\ufe0e\\ufe0f",
                            l = "\\xac\\xb1\\xd7\\xf7\\x00-\\x2f\\x3a-\\x40\\x5b-\\x60\\x7b-\\xbf\\u2000-\\u206f \\t\\x0b\\f\\xa0\\ufeff\\n\\r\\u2028\\u2029\\u1680\\u180e\\u2000\\u2001\\u2002\\u2003\\u2004\\u2005\\u2006\\u2007\\u2008\\u2009\\u200a\\u202f\\u205f\\u3000",
                            s = "['’]",
                            u = "[" + e + "]",
                            c = "[" + l + "]",
                            d = "[" + t + "]",
                            f = "\\d+",
                            p = "[" + r + "]",
                            m = "[" + a + "]",
                            v = "[^" + e + l + f + r + a + o + "]",
                            h = "\\ud83c[\\udffb-\\udfff]",
                            g = "[^" + e + "]",
                            y = "(?:\\ud83c[\\udde6-\\uddff]){2}",
                            b = "[\\ud800-\\udbff][\\udc00-\\udfff]",
                            I = "[" + o + "]",
                            P = "\\u200d",
                            E = "(?:" + m + "|" + v + ")",
                            l = "(?:" + I + "|" + v + ")",
                            r = "(?:['’](?:d|ll|m|re|s|t|ve))?",
                            a = "(?:['’](?:D|LL|M|RE|S|T|VE))?",
                            o = "(?:" + d + "|" + h + ")" + "?",
                            v = "[" + i + "]?",
                            o = v + o + ("(?:" + P + "(?:" + [g, y, b].join("|") + ")" + v + o + ")*"),
                            p = "(?:" + [p, y, b].join("|") + ")" + o,
                            u = "(?:" + [g + d + "?", d, y, b, u].join("|") + ")",
                            nl = RegExp(s, "g"),
                            rl = RegExp(d, "g"),
                            S = RegExp(h + "(?=" + h + ")|" + u + o, "g"),
                            al = RegExp([I + "?" + m + "+" + r + "(?=" + [c, I, "$"].join("|") + ")", l + "+" + a + "(?=" + [c, I + E, "$"].join("|") + ")", I + "?" + E + "+" + r, I + "+" + a, "\\d*(?:1ST|2ND|3RD|(?![123])\\dTH)(?=\\b|[a-z_])", "\\d*(?:1st|2nd|3rd|(?![123])\\dth)(?=\\b|[A-Z_])", f, p].join("|"), "g"),
                            w = RegExp("[" + P + e + t + i + "]"),
                            ol = /[a-z][A-Z]|[A-Z]{2}[a-z]|[0-9][a-zA-Z]|[a-zA-Z][0-9]|[^a-zA-Z0-9 ]/,
                            il = ["Array", "Buffer", "DataView", "Date", "Error", "Float32Array", "Float64Array", "Function", "Int8Array", "Int16Array", "Int32Array", "Map", "Math", "Object", "Promise", "RegExp", "Set", "String", "Symbol", "TypeError", "Uint8Array", "Uint8ClampedArray", "Uint16Array", "Uint32Array", "WeakMap", "_", "clearTimeout", "isFinite", "parseInt", "setTimeout"],
                            ll = -1,
                            sl = {};
                        sl[vi] = sl[hi] = sl[gi] = sl[yi] = sl[bi] = sl[Ii] = sl[Pi] = sl[Ei] = sl[Si] = !0, sl[Yo] = sl[Qo] = sl[pi] = sl[Xo] = sl[mi] = sl[ei] = sl[ti] = sl[ni] = sl[ai] = sl[oi] = sl[ii] = sl[si] = sl[ui] = sl[ci] = sl[fi] = !1;
                        var ul = {};
                        ul[Yo] = ul[Qo] = ul[pi] = ul[mi] = ul[Xo] = ul[ei] = ul[vi] = ul[hi] = ul[gi] = ul[yi] = ul[bi] = ul[ai] = ul[oi] = ul[ii] = ul[si] = ul[ui] = ul[ci] = ul[di] = ul[Ii] = ul[Pi] = ul[Ei] = ul[Si] = !0, ul[ti] = ul[ni] = ul[fi] = !1;
                        var C = {
                                "\\": "\\",
                                "'": "'",
                                "\n": "n",
                                "\r": "r",
                                "\u2028": "u2028",
                                "\u2029": "u2029"
                            },
                            cl = parseFloat,
                            dl = parseInt,
                            t = "object" == typeof A.g && A.g && A.g.Object === Object && A.g,
                            i = "object" == typeof self && self && self.Object === Object && self,
                            fl = t || i || Function("return this")(),
                            i = D && !D.nodeType && D,
                            T = i && N && !N.nodeType && N,
                            pl = T && T.exports === i,
                            _ = pl && t.process,
                            t = function() {
                                try {
                                    var e = T && T.require && T.require("util").types;
                                    return e ? e : _ && _.binding && _.binding("util")
                                } catch (e) {}
                            }(),
                            ml = t && t.isArrayBuffer,
                            vl = t && t.isDate,
                            hl = t && t.isMap,
                            gl = t && t.isRegExp,
                            yl = t && t.isSet,
                            bl = t && t.isTypedArray;

                        function Il(e, t, n) {
                            switch (n.length) {
                                case 0:
                                    return e.call(t);
                                case 1:
                                    return e.call(t, n[0]);
                                case 2:
                                    return e.call(t, n[0], n[1]);
                                case 3:
                                    return e.call(t, n[0], n[1], n[2])
                            }
                            return e.apply(t, n)
                        }

                        function Pl(e, t, n, r) {
                            for (var a = -1, o = null == e ? 0 : e.length; ++a < o;) {
                                var i = e[a];
                                t(r, i, n(i), e)
                            }
                            return r
                        }

                        function El(e, t) {
                            for (var n = -1, r = null == e ? 0 : e.length; ++n < r && !1 !== t(e[n], n, e););
                            return e
                        }

                        function Sl(e, t) {
                            for (var n = null == e ? 0 : e.length; n-- && !1 !== t(e[n], n, e););
                            return e
                        }

                        function wl(e, t) {
                            for (var n = -1, r = null == e ? 0 : e.length; ++n < r;)
                                if (!t(e[n], n, e)) return !1;
                            return !0
                        }

                        function Cl(e, t) {
                            for (var n = -1, r = null == e ? 0 : e.length, a = 0, o = []; ++n < r;) {
                                var i = e[n];
                                t(i, n, e) && (o[a++] = i)
                            }
                            return o
                        }

                        function Tl(e, t) {
                            return !!(null == e ? 0 : e.length) && -1 < Rl(e, t, 0)
                        }

                        function _l(e, t, n) {
                            for (var r = -1, a = null == e ? 0 : e.length; ++r < a;)
                                if (n(t, e[r])) return !0;
                            return !1
                        }

                        function xl(e, t) {
                            for (var n = -1, r = null == e ? 0 : e.length, a = Array(r); ++n < r;) a[n] = t(e[n], n, e);
                            return a
                        }

                        function Ll(e, t) {
                            for (var n = -1, r = t.length, a = e.length; ++n < r;) e[a + n] = t[n];
                            return e
                        }

                        function Nl(e, t, n, r) {
                            var a = -1,
                                o = null == e ? 0 : e.length;
                            for (r && o && (n = e[++a]); ++a < o;) n = t(n, e[a], a, e);
                            return n
                        }

                        function Dl(e, t, n, r) {
                            var a = null == e ? 0 : e.length;
                            for (r && a && (n = e[--a]); a--;) n = t(n, e[a], a, e);
                            return n
                        }

                        function Al(e, t) {
                            for (var n = -1, r = null == e ? 0 : e.length; ++n < r;)
                                if (t(e[n], n, e)) return !0;
                            return !1
                        }
                        var x = jl("length");

                        function kl(e, r, t) {
                            var a;
                            return t(e, function(e, t, n) {
                                if (r(e, t, n)) return a = t, !1
                            }), a
                        }

                        function Ol(e, t, n, r) {
                            for (var a = e.length, o = n + (r ? 1 : -1); r ? o-- : ++o < a;)
                                if (t(e[o], o, e)) return o;
                            return -1
                        }

                        function Rl(e, t, n) {
                            return t == t ? function(e, t, n) {
                                var r = n - 1,
                                    a = e.length;
                                for (; ++r < a;)
                                    if (e[r] === t) return r;
                                return -1
                            }(e, t, n) : Ol(e, Ml, n)
                        }

                        function Ul(e, t, n, r) {
                            for (var a = n - 1, o = e.length; ++a < o;)
                                if (r(e[a], t)) return a;
                            return -1
                        }

                        function Ml(e) {
                            return e != e
                        }

                        function Gl(e, t) {
                            var n = null == e ? 0 : e.length;
                            return n ? Bl(e, t) / n : Zo
                        }

                        function jl(t) {
                            return function(e) {
                                return null == e ? Ho : e[t]
                            }
                        }

                        function L(t) {
                            return function(e) {
                                return null == t ? Ho : t[e]
                            }
                        }

                        function Fl(e, r, a, o, t) {
                            return t(e, function(e, t, n) {
                                a = o ? (o = !1, e) : r(a, e, t, n)
                            }), a
                        }

                        function Bl(e, t) {
                            for (var n, r = -1, a = e.length; ++r < a;) {
                                var o = t(e[r]);
                                o !== Ho && (n = n === Ho ? o : n + o)
                            }
                            return n
                        }

                        function Hl(e, t) {
                            for (var n = -1, r = Array(e); ++n < e;) r[n] = t(n);
                            return r
                        }

                        function zl(e) {
                            return e && e.slice(0, os(e) + 1).replace(ji, "")
                        }

                        function Vl(t) {
                            return function(e) {
                                return t(e)
                            }
                        }

                        function Wl(t, e) {
                            return xl(e, function(e) {
                                return t[e]
                            })
                        }

                        function $l(e, t) {
                            return e.has(t)
                        }

                        function ql(e, t) {
                            for (var n = -1, r = e.length; ++n < r && -1 < Rl(t, e[n], 0););
                            return n
                        }

                        function Zl(e, t) {
                            for (var n = e.length; n-- && -1 < Rl(t, e[n], 0););
                            return n
                        }
                        var Kl = L({
                                "À": "A",
                                "Á": "A",
                                "Â": "A",
                                "Ã": "A",
                                "Ä": "A",
                                "Å": "A",
                                "à": "a",
                                "á": "a",
                                "â": "a",
                                "ã": "a",
                                "ä": "a",
                                "å": "a",
                                "Ç": "C",
                                "ç": "c",
                                "Ð": "D",
                                "ð": "d",
                                "È": "E",
                                "É": "E",
                                "Ê": "E",
                                "Ë": "E",
                                "è": "e",
                                "é": "e",
                                "ê": "e",
                                "ë": "e",
                                "Ì": "I",
                                "Í": "I",
                                "Î": "I",
                                "Ï": "I",
                                "ì": "i",
                                "í": "i",
                                "î": "i",
                                "ï": "i",
                                "Ñ": "N",
                                "ñ": "n",
                                "Ò": "O",
                                "Ó": "O",
                                "Ô": "O",
                                "Õ": "O",
                                "Ö": "O",
                                "Ø": "O",
                                "ò": "o",
                                "ó": "o",
                                "ô": "o",
                                "õ": "o",
                                "ö": "o",
                                "ø": "o",
                                "Ù": "U",
                                "Ú": "U",
                                "Û": "U",
                                "Ü": "U",
                                "ù": "u",
                                "ú": "u",
                                "û": "u",
                                "ü": "u",
                                "Ý": "Y",
                                "ý": "y",
                                "ÿ": "y",
                                "Æ": "Ae",
                                "æ": "ae",
                                "Þ": "Th",
                                "þ": "th",
                                "ß": "ss",
                                "Ā": "A",
                                "Ă": "A",
                                "Ą": "A",
                                "ā": "a",
                                "ă": "a",
                                "ą": "a",
                                "Ć": "C",
                                "Ĉ": "C",
                                "Ċ": "C",
                                "Č": "C",
                                "ć": "c",
                                "ĉ": "c",
                                "ċ": "c",
                                "č": "c",
                                "Ď": "D",
                                "Đ": "D",
                                "ď": "d",
                                "đ": "d",
                                "Ē": "E",
                                "Ĕ": "E",
                                "Ė": "E",
                                "Ę": "E",
                                "Ě": "E",
                                "ē": "e",
                                "ĕ": "e",
                                "ė": "e",
                                "ę": "e",
                                "ě": "e",
                                "Ĝ": "G",
                                "Ğ": "G",
                                "Ġ": "G",
                                "Ģ": "G",
                                "ĝ": "g",
                                "ğ": "g",
                                "ġ": "g",
                                "ģ": "g",
                                "Ĥ": "H",
                                "Ħ": "H",
                                "ĥ": "h",
                                "ħ": "h",
                                "Ĩ": "I",
                                "Ī": "I",
                                "Ĭ": "I",
                                "Į": "I",
                                "İ": "I",
                                "ĩ": "i",
                                "ī": "i",
                                "ĭ": "i",
                                "į": "i",
                                "ı": "i",
                                "Ĵ": "J",
                                "ĵ": "j",
                                "Ķ": "K",
                                "ķ": "k",
                                "ĸ": "k",
                                "Ĺ": "L",
                                "Ļ": "L",
                                "Ľ": "L",
                                "Ŀ": "L",
                                "Ł": "L",
                                "ĺ": "l",
                                "ļ": "l",
                                "ľ": "l",
                                "ŀ": "l",
                                "ł": "l",
                                "Ń": "N",
                                "Ņ": "N",
                                "Ň": "N",
                                "Ŋ": "N",
                                "ń": "n",
                                "ņ": "n",
                                "ň": "n",
                                "ŋ": "n",
                                "Ō": "O",
                                "Ŏ": "O",
                                "Ő": "O",
                                "ō": "o",
                                "ŏ": "o",
                                "ő": "o",
                                "Ŕ": "R",
                                "Ŗ": "R",
                                "Ř": "R",
                                "ŕ": "r",
                                "ŗ": "r",
                                "ř": "r",
                                "Ś": "S",
                                "Ŝ": "S",
                                "Ş": "S",
                                "Š": "S",
                                "ś": "s",
                                "ŝ": "s",
                                "ş": "s",
                                "š": "s",
                                "Ţ": "T",
                                "Ť": "T",
                                "Ŧ": "T",
                                "ţ": "t",
                                "ť": "t",
                                "ŧ": "t",
                                "Ũ": "U",
                                "Ū": "U",
                                "Ŭ": "U",
                                "Ů": "U",
                                "Ű": "U",
                                "Ų": "U",
                                "ũ": "u",
                                "ū": "u",
                                "ŭ": "u",
                                "ů": "u",
                                "ű": "u",
                                "ų": "u",
                                "Ŵ": "W",
                                "ŵ": "w",
                                "Ŷ": "Y",
                                "ŷ": "y",
                                "Ÿ": "Y",
                                "Ź": "Z",
                                "Ż": "Z",
                                "Ž": "Z",
                                "ź": "z",
                                "ż": "z",
                                "ž": "z",
                                "Ĳ": "IJ",
                                "ĳ": "ij",
                                "Œ": "Oe",
                                "œ": "oe",
                                "ŉ": "'n",
                                "ſ": "s"
                            }),
                            Jl = L({
                                "&": "&amp;",
                                "<": "&lt;",
                                ">": "&gt;",
                                '"': "&quot;",
                                "'": "&#39;"
                            });

                        function Yl(e) {
                            return "\\" + C[e]
                        }

                        function Ql(e) {
                            return w.test(e)
                        }

                        function Xl(e) {
                            var n = -1,
                                r = Array(e.size);
                            return e.forEach(function(e, t) {
                                r[++n] = [t, e]
                            }), r
                        }

                        function es(t, n) {
                            return function(e) {
                                return t(n(e))
                            }
                        }

                        function ts(e, t) {
                            for (var n = -1, r = e.length, a = 0, o = []; ++n < r;) {
                                var i = e[n];
                                i !== t && i !== Wo || (e[n] = Wo, o[a++] = n)
                            }
                            return o
                        }

                        function ns(e) {
                            var t = -1,
                                n = Array(e.size);
                            return e.forEach(function(e) {
                                n[++t] = e
                            }), n
                        }

                        function rs(e) {
                            return (Ql(e) ? function(e) {
                                var t = S.lastIndex = 0;
                                for (; S.test(e);) ++t;
                                return t
                            } : x)(e)
                        }

                        function as(e) {
                            return Ql(e) ? e.match(S) || [] : e.split("")
                        }

                        function os(e) {
                            for (var t = e.length; t-- && n.test(e.charAt(t)););
                            return t
                        }
                        var is = L({
                            "&amp;": "&",
                            "&lt;": "<",
                            "&gt;": ">",
                            "&quot;": '"',
                            "&#39;": "'"
                        });
                        var ls = function e(t) {
                            var S = (t = null == t ? fl : ls.defaults(fl.Object(), t, ls.pick(fl, il))).Array,
                                n = t.Date,
                                d = t.Error,
                                f = t.Function,
                                a = t.Math,
                                v = t.Object,
                                p = t.RegExp,
                                c = t.String,
                                E = t.TypeError,
                                o = S.prototype,
                                r = f.prototype,
                                m = v.prototype,
                                i = t["__core-js_shared__"],
                                l = r.toString,
                                y = m.hasOwnProperty,
                                s = 0,
                                u = (ko = /[^.]+$/.exec(i && i.keys && i.keys.IE_PROTO || "")) ? "Symbol(src)_1." + ko : "",
                                h = m.toString,
                                g = l.call(v),
                                b = fl._,
                                I = p("^" + l.call(y).replace(Mi, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$"),
                                P = pl ? t.Buffer : Ho,
                                w = t.Symbol,
                                C = t.Uint8Array,
                                T = P ? P.allocUnsafe : Ho,
                                _ = es(v.getPrototypeOf, v),
                                x = v.create,
                                L = m.propertyIsEnumerable,
                                N = o.splice,
                                D = w ? w.isConcatSpreadable : Ho,
                                A = w ? w.iterator : Ho,
                                k = w ? w.toStringTag : Ho,
                                O = function() {
                                    try {
                                        var e = Hn(v, "defineProperty");
                                        return e({}, "", {}), e
                                    } catch (e) {}
                                }(),
                                R = t.clearTimeout !== fl.clearTimeout && t.clearTimeout,
                                U = n && n.now !== fl.Date.now && n.now,
                                M = t.setTimeout !== fl.setTimeout && t.setTimeout,
                                G = a.ceil,
                                j = a.floor,
                                F = v.getOwnPropertySymbols,
                                B = P ? P.isBuffer : Ho,
                                H = t.isFinite,
                                z = o.join,
                                V = es(v.keys, v),
                                W = a.max,
                                $ = a.min,
                                q = n.now,
                                Z = t.parseInt,
                                K = a.random,
                                J = o.reverse,
                                Y = Hn(t, "DataView"),
                                Q = Hn(t, "Map"),
                                X = Hn(t, "Promise"),
                                ee = Hn(t, "Set"),
                                te = Hn(t, "WeakMap"),
                                ne = Hn(v, "create"),
                                re = te && new te,
                                ae = {},
                                oe = hr(Y),
                                ie = hr(Q),
                                le = hr(X),
                                se = hr(ee),
                                ue = hr(te),
                                ce = w ? w.prototype : Ho,
                                de = ce ? ce.valueOf : Ho,
                                fe = ce ? ce.toString : Ho;

                            function pe(e) {
                                if (ka(e) && !Ea(e) && !(e instanceof ye)) {
                                    if (e instanceof ge) return e;
                                    if (y.call(e, "__wrapped__")) return gr(e)
                                }
                                return new ge(e)
                            }
                            var me = function(e) {
                                if (!Aa(e)) return {};
                                if (x) return x(e);
                                ve.prototype = e;
                                e = new ve;
                                return ve.prototype = Ho, e
                            };

                            function ve() {}

                            function he() {}

                            function ge(e, t) {
                                this.__wrapped__ = e, this.__actions__ = [], this.__chain__ = !!t, this.__index__ = 0, this.__values__ = Ho
                            }

                            function ye(e) {
                                this.__wrapped__ = e, this.__actions__ = [], this.__dir__ = 1, this.__filtered__ = !1, this.__iteratees__ = [], this.__takeCount__ = Ko, this.__views__ = []
                            }

                            function be(e) {
                                var t = -1,
                                    n = null == e ? 0 : e.length;
                                for (this.clear(); ++t < n;) {
                                    var r = e[t];
                                    this.set(r[0], r[1])
                                }
                            }

                            function Ie(e) {
                                var t = -1,
                                    n = null == e ? 0 : e.length;
                                for (this.clear(); ++t < n;) {
                                    var r = e[t];
                                    this.set(r[0], r[1])
                                }
                            }

                            function Pe(e) {
                                var t = -1,
                                    n = null == e ? 0 : e.length;
                                for (this.clear(); ++t < n;) {
                                    var r = e[t];
                                    this.set(r[0], r[1])
                                }
                            }

                            function Ee(e) {
                                var t = -1,
                                    n = null == e ? 0 : e.length;
                                for (this.__data__ = new Pe; ++t < n;) this.add(e[t])
                            }

                            function Se(e) {
                                e = this.__data__ = new Ie(e);
                                this.size = e.size
                            }

                            function we(e, t) {
                                var n, r = Ea(e),
                                    a = !r && Pa(e),
                                    o = !r && !a && Ta(e),
                                    i = !r && !a && !o && Ba(e),
                                    l = r || a || o || i,
                                    s = l ? Hl(e.length, c) : [],
                                    u = s.length;
                                for (n in e) !t && !y.call(e, n) || l && ("length" == n || o && ("offset" == n || "parent" == n) || i && ("buffer" == n || "byteLength" == n || "byteOffset" == n) || Kn(n, u)) || s.push(n);
                                return s
                            }

                            function Ce(e) {
                                var t = e.length;
                                return t ? e[Et(0, t - 1)] : Ho
                            }

                            function Te(e, t) {
                                return dr(rn(e), Re(t, 0, e.length))
                            }

                            function _e(e) {
                                return dr(rn(e))
                            }

                            function xe(e, t, n) {
                                (n === Ho || ya(e[t], n)) && (n !== Ho || t in e) || ke(e, t, n)
                            }

                            function Le(e, t, n) {
                                var r = e[t];
                                y.call(e, t) && ya(r, n) && (n !== Ho || t in e) || ke(e, t, n)
                            }

                            function Ne(e, t) {
                                for (var n = e.length; n--;)
                                    if (ya(e[n][0], t)) return n;
                                return -1
                            }

                            function De(e, r, a, o) {
                                return Fe(e, function(e, t, n) {
                                    r(o, e, a(e), n)
                                }), o
                            }

                            function Ae(e, t) {
                                return e && an(t, uo(t), e)
                            }

                            function ke(e, t, n) {
                                "__proto__" == t && O ? O(e, t, {
                                    configurable: !0,
                                    enumerable: !0,
                                    value: n,
                                    writable: !0
                                }) : e[t] = n
                            }

                            function Oe(e, t) {
                                for (var n = -1, r = t.length, a = S(r), o = null == e; ++n < r;) a[n] = o ? Ho : ao(e, t[n]);
                                return a
                            }

                            function Re(e, t, n) {
                                return e == e && (n !== Ho && (e = e <= n ? e : n), t !== Ho && (e = t <= e ? e : t)), e
                            }

                            function Ue(n, r, a, e, t, o) {
                                var i, l = 1 & r,
                                    s = 2 & r,
                                    u = 4 & r;
                                if (a && (i = t ? a(n, e, t, o) : a(n)), i !== Ho) return i;
                                if (!Aa(n)) return n;
                                var c, d, f = Ea(n);
                                if (f) {
                                    if (i = function(e) {
                                            var t = e.length,
                                                n = new e.constructor(t);
                                            t && "string" == typeof e[0] && y.call(e, "index") && (n.index = e.index, n.input = e.input);
                                            return n
                                        }(n), !l) return rn(n, i)
                                } else {
                                    var p = Wn(n),
                                        e = p == ni || p == ri;
                                    if (Ta(n)) return Yt(n, l);
                                    if (p == ii || p == Yo || e && !t) {
                                        if (i = s || e ? {} : qn(n), !l) return s ? (e = c = n, d = (d = i) && an(e, co(e), d), an(c, Vn(c), d)) : (d = Ae(i, c = n), an(c, zn(c), d))
                                    } else {
                                        if (!ul[p]) return t ? n : {};
                                        i = function(e, t, n) {
                                            var r = e.constructor;
                                            switch (t) {
                                                case pi:
                                                    return Qt(e);
                                                case Xo:
                                                case ei:
                                                    return new r(+e);
                                                case mi:
                                                    return function(e, t) {
                                                        t = t ? Qt(e.buffer) : e.buffer;
                                                        return new e.constructor(t, e.byteOffset, e.byteLength)
                                                    }(e, n);
                                                case vi:
                                                case hi:
                                                case gi:
                                                case yi:
                                                case bi:
                                                case Ii:
                                                case Pi:
                                                case Ei:
                                                case Si:
                                                    return Xt(e, n);
                                                case ai:
                                                    return new r;
                                                case oi:
                                                case ci:
                                                    return new r(e);
                                                case si:
                                                    return function(e) {
                                                        var t = new e.constructor(e.source, qi.exec(e));
                                                        return t.lastIndex = e.lastIndex, t
                                                    }(e);
                                                case ui:
                                                    return new r;
                                                case di:
                                                    return function(e) {
                                                        return de ? v(de.call(e)) : {}
                                                    }(e)
                                            }
                                        }(n, p, l)
                                    }
                                }
                                l = (o = o || new Se).get(n);
                                if (l) return l;
                                o.set(n, i), Ga(n) ? n.forEach(function(e) {
                                    i.add(Ue(e, r, a, e, n, o))
                                }) : Oa(n) && n.forEach(function(e, t) {
                                    i.set(t, Ue(e, r, a, t, n, o))
                                });
                                var m = f ? Ho : (u ? s ? Rn : On : s ? co : uo)(n);
                                return El(m || n, function(e, t) {
                                    m && (e = n[t = e]), Le(i, t, Ue(e, r, a, t, n, o))
                                }), i
                            }

                            function Me(e, t, n) {
                                var r = n.length;
                                if (null == e) return !r;
                                for (e = v(e); r--;) {
                                    var a = n[r],
                                        o = t[a],
                                        i = e[a];
                                    if (i === Ho && !(a in e) || !o(i)) return !1
                                }
                                return !0
                            }

                            function Ge(e, t, n) {
                                if ("function" != typeof e) throw new E(zo);
                                return lr(function() {
                                    e.apply(Ho, n)
                                }, t)
                            }

                            function je(e, t, n, r) {
                                var a = -1,
                                    o = Tl,
                                    i = !0,
                                    l = e.length,
                                    s = [],
                                    u = t.length;
                                if (!l) return s;
                                n && (t = xl(t, Vl(n))), r ? (o = _l, i = !1) : 200 <= t.length && (o = $l, i = !1, t = new Ee(t));
                                e: for (; ++a < l;) {
                                    var c = e[a],
                                        d = null == n ? c : n(c),
                                        c = r || 0 !== c ? c : 0;
                                    if (i && d == d) {
                                        for (var f = u; f--;)
                                            if (t[f] === d) continue e;
                                        s.push(c)
                                    } else o(t, d, r) || s.push(c)
                                }
                                return s
                            }
                            pe.templateSettings = {
                                escape: Di,
                                evaluate: Ai,
                                interpolate: ki,
                                variable: "",
                                imports: {
                                    _: pe
                                }
                            }, (pe.prototype = he.prototype).constructor = pe, (ge.prototype = me(he.prototype)).constructor = ge, (ye.prototype = me(he.prototype)).constructor = ye, be.prototype.clear = function() {
                                this.__data__ = ne ? ne(null) : {}, this.size = 0
                            }, be.prototype.delete = function(e) {
                                return e = this.has(e) && delete this.__data__[e], this.size -= e ? 1 : 0, e
                            }, be.prototype.get = function(e) {
                                var t = this.__data__;
                                if (ne) {
                                    var n = t[e];
                                    return n === Vo ? Ho : n
                                }
                                return y.call(t, e) ? t[e] : Ho
                            }, be.prototype.has = function(e) {
                                var t = this.__data__;
                                return ne ? t[e] !== Ho : y.call(t, e)
                            }, be.prototype.set = function(e, t) {
                                var n = this.__data__;
                                return this.size += this.has(e) ? 0 : 1, n[e] = ne && t === Ho ? Vo : t, this
                            }, Ie.prototype.clear = function() {
                                this.__data__ = [], this.size = 0
                            }, Ie.prototype.delete = function(e) {
                                var t = this.__data__;
                                return !((e = Ne(t, e)) < 0) && (e == t.length - 1 ? t.pop() : N.call(t, e, 1), --this.size, !0)
                            }, Ie.prototype.get = function(e) {
                                var t = this.__data__;
                                return (e = Ne(t, e)) < 0 ? Ho : t[e][1]
                            }, Ie.prototype.has = function(e) {
                                return -1 < Ne(this.__data__, e)
                            }, Ie.prototype.set = function(e, t) {
                                var n = this.__data__,
                                    r = Ne(n, e);
                                return r < 0 ? (++this.size, n.push([e, t])) : n[r][1] = t, this
                            }, Pe.prototype.clear = function() {
                                this.size = 0, this.__data__ = {
                                    hash: new be,
                                    map: new(Q || Ie),
                                    string: new be
                                }
                            }, Pe.prototype.delete = function(e) {
                                return e = Fn(this, e).delete(e), this.size -= e ? 1 : 0, e
                            }, Pe.prototype.get = function(e) {
                                return Fn(this, e).get(e)
                            }, Pe.prototype.has = function(e) {
                                return Fn(this, e).has(e)
                            }, Pe.prototype.set = function(e, t) {
                                var n = Fn(this, e),
                                    r = n.size;
                                return n.set(e, t), this.size += n.size == r ? 0 : 1, this
                            }, Ee.prototype.add = Ee.prototype.push = function(e) {
                                return this.__data__.set(e, Vo), this
                            }, Ee.prototype.has = function(e) {
                                return this.__data__.has(e)
                            }, Se.prototype.clear = function() {
                                this.__data__ = new Ie, this.size = 0
                            }, Se.prototype.delete = function(e) {
                                var t = this.__data__,
                                    e = t.delete(e);
                                return this.size = t.size, e
                            }, Se.prototype.get = function(e) {
                                return this.__data__.get(e)
                            }, Se.prototype.has = function(e) {
                                return this.__data__.has(e)
                            }, Se.prototype.set = function(e, t) {
                                var n = this.__data__;
                                if (n instanceof Ie) {
                                    var r = n.__data__;
                                    if (!Q || r.length < 199) return r.push([e, t]), this.size = ++n.size, this;
                                    n = this.__data__ = new Pe(r)
                                }
                                return n.set(e, t), this.size = n.size, this
                            };
                            var Fe = sn(Ze),
                                Be = sn(Ke, !0);

                            function He(e, r) {
                                var a = !0;
                                return Fe(e, function(e, t, n) {
                                    return a = !!r(e, t, n)
                                }), a
                            }

                            function ze(e, t, n) {
                                for (var r = -1, a = e.length; ++r < a;) {
                                    var o, i, l = e[r],
                                        s = t(l);
                                    null != s && (o === Ho ? s == s && !Fa(s) : n(s, o)) && (o = s, i = l)
                                }
                                return i
                            }

                            function Ve(e, r) {
                                var a = [];
                                return Fe(e, function(e, t, n) {
                                    r(e, t, n) && a.push(e)
                                }), a
                            }

                            function We(e, t, n, r, a) {
                                var o = -1,
                                    i = e.length;
                                for (n = n || Zn, a = a || []; ++o < i;) {
                                    var l = e[o];
                                    0 < t && n(l) ? 1 < t ? We(l, t - 1, n, r, a) : Ll(a, l) : r || (a[a.length] = l)
                                }
                                return a
                            }
                            var $e = un(),
                                qe = un(!0);

                            function Ze(e, t) {
                                return e && $e(e, t, uo)
                            }

                            function Ke(e, t) {
                                return e && qe(e, t, uo)
                            }

                            function Je(t, e) {
                                return Cl(e, function(e) {
                                    return La(t[e])
                                })
                            }

                            function Ye(e, t) {
                                for (var n = 0, r = (t = qt(t, e)).length; null != e && n < r;) e = e[vr(t[n++])];
                                return n && n == r ? e : Ho
                            }

                            function Qe(e, t, n) {
                                t = t(e);
                                return Ea(e) ? t : Ll(t, n(e))
                            }

                            function Xe(e) {
                                return null == e ? e === Ho ? "[object Undefined]" : "[object Null]" : k && k in v(e) ? function(e) {
                                    var t = y.call(e, k),
                                        n = e[k];
                                    try {
                                        e[k] = Ho;
                                        var r = !0
                                    } catch (e) {}
                                    var a = h.call(e);
                                    r && (t ? e[k] = n : delete e[k]);
                                    return a
                                }(e) : (e = e, h.call(e))
                            }

                            function et(e, t) {
                                return t < e
                            }

                            function tt(e, t) {
                                return null != e && y.call(e, t)
                            }

                            function nt(e, t) {
                                return null != e && t in v(e)
                            }

                            function rt(e, t, n) {
                                for (var r = n ? _l : Tl, a = e[0].length, o = e.length, i = o, l = S(o), s = 1 / 0, u = []; i--;) {
                                    var c = e[i];
                                    i && t && (c = xl(c, Vl(t))), s = $(c.length, s), l[i] = !n && (t || 120 <= a && 120 <= c.length) ? new Ee(i && c) : Ho
                                }
                                c = e[0];
                                var d = -1,
                                    f = l[0];
                                e: for (; ++d < a && u.length < s;) {
                                    var p = c[d],
                                        m = t ? t(p) : p,
                                        p = n || 0 !== p ? p : 0;
                                    if (!(f ? $l(f, m) : r(u, m, n))) {
                                        for (i = o; --i;) {
                                            var v = l[i];
                                            if (!(v ? $l(v, m) : r(e[i], m, n))) continue e
                                        }
                                        f && f.push(m), u.push(p)
                                    }
                                }
                                return u
                            }

                            function at(e, t, n) {
                                t = null == (e = ar(e, t = qt(t, e))) ? e : e[vr(xr(t))];
                                return null == t ? Ho : Il(t, e, n)
                            }

                            function ot(e) {
                                return ka(e) && Xe(e) == Yo
                            }

                            function it(e, t, n, r, a) {
                                return e === t || (null == e || null == t || !ka(e) && !ka(t) ? e != e && t != t : function(e, t, n, r, a, o) {
                                    var i = Ea(e),
                                        l = Ea(t),
                                        s = i ? Qo : Wn(e),
                                        u = l ? Qo : Wn(t),
                                        c = (s = s == Yo ? ii : s) == ii,
                                        l = (u = u == Yo ? ii : u) == ii,
                                        u = s == u;
                                    if (u && Ta(e)) {
                                        if (!Ta(t)) return !1;
                                        c = !(i = !0)
                                    }
                                    if (u && !c) return o = o || new Se, i || Ba(e) ? An(e, t, n, r, a, o) : function(e, t, n, r, a, o, i) {
                                        switch (n) {
                                            case mi:
                                                if (e.byteLength != t.byteLength || e.byteOffset != t.byteOffset) return !1;
                                                e = e.buffer, t = t.buffer;
                                            case pi:
                                                return e.byteLength == t.byteLength && o(new C(e), new C(t)) ? !0 : !1;
                                            case Xo:
                                            case ei:
                                            case oi:
                                                return ya(+e, +t);
                                            case ti:
                                                return e.name == t.name && e.message == t.message;
                                            case si:
                                            case ci:
                                                return e == t + "";
                                            case ai:
                                                var l = Xl;
                                            case ui:
                                                var s = 1 & r;
                                                if (l = l || ns, e.size != t.size && !s) return !1;
                                                s = i.get(e);
                                                if (s) return s == t;
                                                r |= 2, i.set(e, t);
                                                l = An(l(e), l(t), r, a, o, i);
                                                return i.delete(e), l;
                                            case di:
                                                if (de) return de.call(e) == de.call(t)
                                        }
                                        return !1
                                    }(e, t, s, n, r, a, o);
                                    if (!(1 & n)) {
                                        c = c && y.call(e, "__wrapped__"), l = l && y.call(t, "__wrapped__");
                                        if (c || l) {
                                            c = c ? e.value() : e, l = l ? t.value() : t;
                                            return o = o || new Se, a(c, l, n, r, o)
                                        }
                                    }
                                    return u && (o = o || new Se, function(e, t, n, r, a, o) {
                                        var i = 1 & n,
                                            l = On(e),
                                            s = l.length,
                                            u = On(t).length;
                                        if (s != u && !i) return !1;
                                        var c = s;
                                        for (; c--;) {
                                            var d = l[c];
                                            if (!(i ? d in t : y.call(t, d))) return !1
                                        }
                                        var f = o.get(e),
                                            u = o.get(t);
                                        if (f && u) return f == t && u == e;
                                        var p = !0;
                                        o.set(e, t), o.set(t, e);
                                        var m = i;
                                        for (; ++c < s;) {
                                            d = l[c];
                                            var v, h = e[d],
                                                g = t[d];
                                            if (r && (v = i ? r(g, h, d, t, e, o) : r(h, g, d, e, t, o)), !(v === Ho ? h === g || a(h, g, n, r, o) : v)) {
                                                p = !1;
                                                break
                                            }
                                            m = m || "constructor" == d
                                        }
                                        p && !m && (f = e.constructor, u = t.constructor, f != u && "constructor" in e && "constructor" in t && !("function" == typeof f && f instanceof f && "function" == typeof u && u instanceof u) && (p = !1));
                                        return o.delete(e), o.delete(t), p
                                    }(e, t, n, r, a, o))
                                }(e, t, n, r, it, a))
                            }

                            function lt(e, t, n, r) {
                                var a = n.length,
                                    o = a,
                                    i = !r;
                                if (null == e) return !o;
                                for (e = v(e); a--;) {
                                    var l = n[a];
                                    if (i && l[2] ? l[1] !== e[l[0]] : !(l[0] in e)) return !1
                                }
                                for (; ++a < o;) {
                                    var s = (l = n[a])[0],
                                        u = e[s],
                                        c = l[1];
                                    if (i && l[2]) {
                                        if (u === Ho && !(s in e)) return !1
                                    } else {
                                        var d, f = new Se;
                                        if (r && (d = r(u, c, s, e, t, f)), !(d === Ho ? it(c, u, 3, r, f) : d)) return !1
                                    }
                                }
                                return !0
                            }

                            function st(e) {
                                return !(!Aa(e) || (t = e, u && u in t)) && (La(e) ? I : Ji).test(hr(e));
                                var t
                            }

                            function ut(e) {
                                return "function" == typeof e ? e : null == e ? Oo : "object" == typeof e ? Ea(e) ? vt(e[0], e[1]) : mt(e) : Go(e)
                            }

                            function ct(e) {
                                if (!er(e)) return V(e);
                                var t, n = [];
                                for (t in v(e)) y.call(e, t) && "constructor" != t && n.push(t);
                                return n
                            }

                            function dt(e) {
                                if (!Aa(e)) return function(e) {
                                    var t = [];
                                    if (null != e)
                                        for (var n in v(e)) t.push(n);
                                    return t
                                }(e);
                                var t, n = er(e),
                                    r = [];
                                for (t in e)("constructor" != t || !n && y.call(e, t)) && r.push(t);
                                return r
                            }

                            function ft(e, t) {
                                return e < t
                            }

                            function pt(e, r) {
                                var a = -1,
                                    o = wa(e) ? S(e.length) : [];
                                return Fe(e, function(e, t, n) {
                                    o[++a] = r(e, t, n)
                                }), o
                            }

                            function mt(t) {
                                var n = Bn(t);
                                return 1 == n.length && n[0][2] ? nr(n[0][0], n[0][1]) : function(e) {
                                    return e === t || lt(e, t, n)
                                }
                            }

                            function vt(n, r) {
                                return Yn(n) && tr(r) ? nr(vr(n), r) : function(e) {
                                    var t = ao(e, n);
                                    return t === Ho && t === r ? oo(e, n) : it(r, t, 3)
                                }
                            }

                            function ht(r, a, o, i, l) {
                                r !== a && $e(a, function(e, t) {
                                    var n;
                                    l = l || new Se, Aa(e) ? function(e, t, n, r, a, o, i) {
                                        var l = or(e, n),
                                            s = or(t, n),
                                            u = i.get(s);
                                        if (u) return xe(e, n, u);
                                        var c, d = o ? o(l, s, n + "", e, t, i) : Ho,
                                            f = d === Ho;
                                        f && (c = Ea(s), u = !c && Ta(s), t = !c && !u && Ba(s), d = s, c || u || t ? d = Ea(l) ? l : Ca(l) ? rn(l) : u ? Yt(s, !(f = !1)) : t ? Xt(s, !(f = !1)) : [] : Ua(s) || Pa(s) ? Pa(d = l) ? d = Ka(l) : Aa(l) && !La(l) || (d = qn(s)) : f = !1), f && (i.set(s, d), a(d, s, r, o, i), i.delete(s)), xe(e, n, d)
                                    }(r, a, t, o, ht, i, l) : ((n = i ? i(or(r, t), e, t + "", r, a, l) : Ho) === Ho && (n = e), xe(r, t, n))
                                }, co)
                            }

                            function gt(e, t) {
                                var n = e.length;
                                if (n) return Kn(t += t < 0 ? n : 0, n) ? e[t] : Ho
                            }

                            function yt(e, r, n) {
                                r = r.length ? xl(r, function(t) {
                                    return Ea(t) ? function(e) {
                                        return Ye(e, 1 === t.length ? t[0] : t)
                                    } : t
                                }) : [Oo];
                                var a = -1;
                                return r = xl(r, Vl(jn())),
                                    function(e, t) {
                                        var n = e.length;
                                        for (e.sort(t); n--;) e[n] = e[n].value;
                                        return e
                                    }(pt(e, function(t, e, n) {
                                        return {
                                            criteria: xl(r, function(e) {
                                                return e(t)
                                            }),
                                            index: ++a,
                                            value: t
                                        }
                                    }), function(e, t) {
                                        return function(e, t, n) {
                                            var r = -1,
                                                a = e.criteria,
                                                o = t.criteria,
                                                i = a.length,
                                                l = n.length;
                                            for (; ++r < i;) {
                                                var s = en(a[r], o[r]);
                                                if (s) {
                                                    if (l <= r) return s;
                                                    var u = n[r];
                                                    return s * ("desc" == u ? -1 : 1)
                                                }
                                            }
                                            return e.index - t.index
                                        }(e, t, n)
                                    })
                            }

                            function bt(e, t, n) {
                                for (var r = -1, a = t.length, o = {}; ++r < a;) {
                                    var i = t[r],
                                        l = Ye(e, i);
                                    n(l, i) && _t(o, qt(i, e), l)
                                }
                                return o
                            }

                            function It(e, t, n, r) {
                                var a = r ? Ul : Rl,
                                    o = -1,
                                    i = t.length,
                                    l = e;
                                for (e === t && (t = rn(t)), n && (l = xl(e, Vl(n))); ++o < i;)
                                    for (var s = 0, u = t[o], c = n ? n(u) : u; - 1 < (s = a(l, c, s, r));) l !== e && N.call(l, s, 1), N.call(e, s, 1);
                                return e
                            }

                            function Pt(e, t) {
                                for (var n = e ? t.length : 0, r = n - 1; n--;) {
                                    var a, o = t[n];
                                    n != r && o === a || (Kn(a = o) ? N.call(e, o, 1) : jt(e, o))
                                }
                                return e
                            }

                            function Et(e, t) {
                                return e + j(K() * (t - e + 1))
                            }

                            function St(e, t) {
                                var n = "";
                                if (!e || t < 1 || qo < t) return n;
                                for (; t % 2 && (n += e), (t = j(t / 2)) && (e += e), t;);
                                return n
                            }

                            function wt(e, t) {
                                return sr(rr(e, t, Oo), e + "")
                            }

                            function Ct(e) {
                                return Ce(bo(e))
                            }

                            function Tt(e, t) {
                                e = bo(e);
                                return dr(e, Re(t, 0, e.length))
                            }

                            function _t(e, t, n, r) {
                                if (!Aa(e)) return e;
                                for (var a = -1, o = (t = qt(t, e)).length, i = o - 1, l = e; null != l && ++a < o;) {
                                    var s, u = vr(t[a]),
                                        c = n;
                                    if ("__proto__" === u || "constructor" === u || "prototype" === u) return e;
                                    a != i && (s = l[u], (c = r ? r(s, u, l) : Ho) === Ho && (c = Aa(s) ? s : Kn(t[a + 1]) ? [] : {})), Le(l, u, c), l = l[u]
                                }
                                return e
                            }
                            var xt = re ? function(e, t) {
                                    return re.set(e, t), e
                                } : Oo,
                                Lt = O ? function(e, t) {
                                    return O(e, "toString", {
                                        configurable: !0,
                                        enumerable: !1,
                                        value: Ao(t),
                                        writable: !0
                                    })
                                } : Oo;

                            function Nt(e) {
                                return dr(bo(e))
                            }

                            function Dt(e, t, n) {
                                var r = -1,
                                    a = e.length;
                                t < 0 && (t = a < -t ? 0 : a + t), (n = a < n ? a : n) < 0 && (n += a), a = n < t ? 0 : n - t >>> 0, t >>>= 0;
                                for (var o = S(a); ++r < a;) o[r] = e[r + t];
                                return o
                            }

                            function At(e, r) {
                                var a;
                                return Fe(e, function(e, t, n) {
                                    return !(a = r(e, t, n))
                                }), !!a
                            }

                            function kt(e, t, n) {
                                var r = 0,
                                    a = null == e ? r : e.length;
                                if ("number" == typeof t && t == t && a <= 2147483647) {
                                    for (; r < a;) {
                                        var o = r + a >>> 1,
                                            i = e[o];
                                        null !== i && !Fa(i) && (n ? i <= t : i < t) ? r = 1 + o : a = o
                                    }
                                    return a
                                }
                                return Ot(e, t, Oo, n)
                            }

                            function Ot(e, t, n, r) {
                                var a = 0,
                                    o = null == e ? 0 : e.length;
                                if (0 === o) return 0;
                                for (var i = (t = n(t)) != t, l = null === t, s = Fa(t), u = t === Ho; a < o;) {
                                    var c = j((a + o) / 2),
                                        d = n(e[c]),
                                        f = d !== Ho,
                                        p = null === d,
                                        m = d == d,
                                        v = Fa(d),
                                        d = i ? r || m : u ? m && (r || f) : l ? m && f && (r || !p) : s ? m && f && !p && (r || !v) : !p && !v && (r ? d <= t : d < t);
                                    d ? a = c + 1 : o = c
                                }
                                return $(o, 4294967294)
                            }

                            function Rt(e, t) {
                                for (var n = -1, r = e.length, a = 0, o = []; ++n < r;) {
                                    var i, l = e[n],
                                        s = t ? t(l) : l;
                                    n && ya(s, i) || (i = s, o[a++] = 0 === l ? 0 : l)
                                }
                                return o
                            }

                            function Ut(e) {
                                return "number" == typeof e ? e : Fa(e) ? Zo : +e
                            }

                            function Mt(e) {
                                if ("string" == typeof e) return e;
                                if (Ea(e)) return xl(e, Mt) + "";
                                if (Fa(e)) return fe ? fe.call(e) : "";
                                var t = e + "";
                                return "0" == t && 1 / e == -1 / 0 ? "-0" : t
                            }

                            function Gt(e, t, n) {
                                var r = -1,
                                    a = Tl,
                                    o = e.length,
                                    i = !0,
                                    l = [],
                                    s = l;
                                if (n) i = !1, a = _l;
                                else if (200 <= o) {
                                    var u = t ? null : Tn(e);
                                    if (u) return ns(u);
                                    i = !1, a = $l, s = new Ee
                                } else s = t ? [] : l;
                                e: for (; ++r < o;) {
                                    var c = e[r],
                                        d = t ? t(c) : c,
                                        c = n || 0 !== c ? c : 0;
                                    if (i && d == d) {
                                        for (var f = s.length; f--;)
                                            if (s[f] === d) continue e;
                                        t && s.push(d), l.push(c)
                                    } else a(s, d, n) || (s !== l && s.push(d), l.push(c))
                                }
                                return l
                            }

                            function jt(e, t) {
                                return null == (e = ar(e, t = qt(t, e))) || delete e[vr(xr(t))]
                            }

                            function Ft(e, t, n, r) {
                                return _t(e, t, n(Ye(e, t)), r)
                            }

                            function Bt(e, t, n, r) {
                                for (var a = e.length, o = r ? a : -1;
                                    (r ? o-- : ++o < a) && t(e[o], o, e););
                                return n ? Dt(e, r ? 0 : o, r ? o + 1 : a) : Dt(e, r ? o + 1 : 0, r ? a : o)
                            }

                            function Ht(e, t) {
                                return e instanceof ye && (e = e.value()), Nl(t, function(e, t) {
                                    return t.func.apply(t.thisArg, Ll([e], t.args))
                                }, e)
                            }

                            function zt(e, t, n) {
                                var r = e.length;
                                if (r < 2) return r ? Gt(e[0]) : [];
                                for (var a = -1, o = S(r); ++a < r;)
                                    for (var i = e[a], l = -1; ++l < r;) l != a && (o[a] = je(o[a] || i, e[l], t, n));
                                return Gt(We(o, 1), t, n)
                            }

                            function Vt(e, t, n) {
                                for (var r = -1, a = e.length, o = t.length, i = {}; ++r < a;) {
                                    var l = r < o ? t[r] : Ho;
                                    n(i, e[r], l)
                                }
                                return i
                            }

                            function Wt(e) {
                                return Ca(e) ? e : []
                            }

                            function $t(e) {
                                return "function" == typeof e ? e : Oo
                            }

                            function qt(e, t) {
                                return Ea(e) ? e : Yn(e, t) ? [e] : mr(Ja(e))
                            }
                            var Zt = wt;

                            function Kt(e, t, n) {
                                var r = e.length;
                                return n = n === Ho ? r : n, !t && r <= n ? e : Dt(e, t, n)
                            }
                            var Jt = R || function(e) {
                                return fl.clearTimeout(e)
                            };

                            function Yt(e, t) {
                                if (t) return e.slice();
                                t = e.length, t = T ? T(t) : new e.constructor(t);
                                return e.copy(t), t
                            }

                            function Qt(e) {
                                var t = new e.constructor(e.byteLength);
                                return new C(t).set(new C(e)), t
                            }

                            function Xt(e, t) {
                                t = t ? Qt(e.buffer) : e.buffer;
                                return new e.constructor(t, e.byteOffset, e.length)
                            }

                            function en(e, t) {
                                if (e !== t) {
                                    var n = e !== Ho,
                                        r = null === e,
                                        a = e == e,
                                        o = Fa(e),
                                        i = t !== Ho,
                                        l = null === t,
                                        s = t == t,
                                        u = Fa(t);
                                    if (!l && !u && !o && t < e || o && i && s && !l && !u || r && i && s || !n && s || !a) return 1;
                                    if (!r && !o && !u && e < t || u && n && a && !r && !o || l && n && a || !i && a || !s) return -1
                                }
                                return 0
                            }

                            function tn(e, t, n, r) {
                                for (var a = -1, o = e.length, i = n.length, l = -1, s = t.length, u = W(o - i, 0), c = S(s + u), d = !r; ++l < s;) c[l] = t[l];
                                for (; ++a < i;)(d || a < o) && (c[n[a]] = e[a]);
                                for (; u--;) c[l++] = e[a++];
                                return c
                            }

                            function nn(e, t, n, r) {
                                for (var a = -1, o = e.length, i = -1, l = n.length, s = -1, u = t.length, c = W(o - l, 0), d = S(c + u), f = !r; ++a < c;) d[a] = e[a];
                                for (var p = a; ++s < u;) d[p + s] = t[s];
                                for (; ++i < l;)(f || a < o) && (d[p + n[i]] = e[a++]);
                                return d
                            }

                            function rn(e, t) {
                                var n = -1,
                                    r = e.length;
                                for (t = t || S(r); ++n < r;) t[n] = e[n];
                                return t
                            }

                            function an(e, t, n, r) {
                                var a = !n;
                                n = n || {};
                                for (var o = -1, i = t.length; ++o < i;) {
                                    var l = t[o],
                                        s = r ? r(n[l], e[l], l, n, e) : Ho;
                                    s === Ho && (s = e[l]), (a ? ke : Le)(n, l, s)
                                }
                                return n
                            }

                            function on(a, o) {
                                return function(e, t) {
                                    var n = Ea(e) ? Pl : De,
                                        r = o ? o() : {};
                                    return n(e, a, jn(t, 2), r)
                                }
                            }

                            function ln(l) {
                                return wt(function(e, t) {
                                    var n = -1,
                                        r = t.length,
                                        a = 1 < r ? t[r - 1] : Ho,
                                        o = 2 < r ? t[2] : Ho,
                                        a = 3 < l.length && "function" == typeof a ? (r--, a) : Ho;
                                    for (o && Jn(t[0], t[1], o) && (a = r < 3 ? Ho : a, r = 1), e = v(e); ++n < r;) {
                                        var i = t[n];
                                        i && l(e, i, n, a)
                                    }
                                    return e
                                })
                            }

                            function sn(o, i) {
                                return function(e, t) {
                                    if (null == e) return e;
                                    if (!wa(e)) return o(e, t);
                                    for (var n = e.length, r = i ? n : -1, a = v(e);
                                        (i ? r-- : ++r < n) && !1 !== t(a[r], r, a););
                                    return e
                                }
                            }

                            function un(s) {
                                return function(e, t, n) {
                                    for (var r = -1, a = v(e), o = n(e), i = o.length; i--;) {
                                        var l = o[s ? i : ++r];
                                        if (!1 === t(a[l], l, a)) break
                                    }
                                    return e
                                }
                            }

                            function cn(r) {
                                return function(e) {
                                    var t = Ql(e = Ja(e)) ? as(e) : Ho,
                                        n = t ? t[0] : e.charAt(0),
                                        e = t ? Kt(t, 1).join("") : e.slice(1);
                                    return n[r]() + e
                                }
                            }

                            function dn(t) {
                                return function(e) {
                                    return Nl(No(Eo(e).replace(nl, "")), t, "")
                                }
                            }

                            function fn(r) {
                                return function() {
                                    var e = arguments;
                                    switch (e.length) {
                                        case 0:
                                            return new r;
                                        case 1:
                                            return new r(e[0]);
                                        case 2:
                                            return new r(e[0], e[1]);
                                        case 3:
                                            return new r(e[0], e[1], e[2]);
                                        case 4:
                                            return new r(e[0], e[1], e[2], e[3]);
                                        case 5:
                                            return new r(e[0], e[1], e[2], e[3], e[4]);
                                        case 6:
                                            return new r(e[0], e[1], e[2], e[3], e[4], e[5]);
                                        case 7:
                                            return new r(e[0], e[1], e[2], e[3], e[4], e[5], e[6])
                                    }
                                    var t = me(r.prototype),
                                        n = r.apply(t, e);
                                    return Aa(n) ? n : t
                                }
                            }

                            function pn(o, i, l) {
                                var s = fn(o);
                                return function e() {
                                    for (var t = arguments.length, n = S(t), r = t, a = Gn(e); r--;) n[r] = arguments[r];
                                    a = t < 3 && n[0] !== a && n[t - 1] !== a ? [] : ts(n, a);
                                    return (t -= a.length) < l ? wn(o, i, hn, e.placeholder, Ho, n, a, Ho, Ho, l - t) : Il(this && this !== fl && this instanceof e ? s : o, this, n)
                                }
                            }

                            function mn(o) {
                                return function(e, t, n) {
                                    var r, a = v(e);
                                    wa(e) || (r = jn(t, 3), e = uo(e), t = function(e) {
                                        return r(a[e], e, a)
                                    });
                                    n = o(e, t, n);
                                    return -1 < n ? a[r ? e[n] : n] : Ho
                                }
                            }

                            function vn(s) {
                                return kn(function(a) {
                                    var o = a.length,
                                        e = o,
                                        t = ge.prototype.thru;
                                    for (s && a.reverse(); e--;) {
                                        var n = a[e];
                                        if ("function" != typeof n) throw new E(zo);
                                        t && !l && "wrapper" == Mn(n) && (l = new ge([], !0))
                                    }
                                    for (e = l ? e : o; ++e < o;) var r = Mn(n = a[e]),
                                        i = "wrapper" == r ? Un(n) : Ho,
                                        l = i && Qn(i[0]) && 424 == i[1] && !i[4].length && 1 == i[9] ? l[Mn(i[0])].apply(l, i[3]) : 1 == n.length && Qn(n) ? l[r]() : l.thru(n);
                                    return function() {
                                        var e = arguments,
                                            t = e[0];
                                        if (l && 1 == e.length && Ea(t)) return l.plant(t).value();
                                        for (var n = 0, r = o ? a[n].apply(this, e) : t; ++n < o;) r = a[n].call(this, r);
                                        return r
                                    }
                                })
                            }

                            function hn(l, s, u, c, d, f, p, m, v, h) {
                                var g = s & $o,
                                    y = 1 & s,
                                    b = 2 & s,
                                    I = 24 & s,
                                    P = 512 & s,
                                    E = b ? Ho : fn(l);
                                return function e() {
                                    for (var t, n = S(i = arguments.length), r = i; r--;) n[r] = arguments[r];
                                    if (I && (t = function(e, t) {
                                            for (var n = e.length, r = 0; n--;) e[n] === t && ++r;
                                            return r
                                        }(n, o = Gn(e))), c && (n = tn(n, c, d, I)), f && (n = nn(n, f, p, I)), i -= t, I && i < h) {
                                        var a = ts(n, o);
                                        return wn(l, s, hn, e.placeholder, u, n, a, m, v, h - i)
                                    }
                                    var o = y ? u : this,
                                        a = b ? o[l] : l,
                                        i = n.length;
                                    return m ? n = function(e, t) {
                                        for (var n = e.length, r = $(t.length, n), a = rn(e); r--;) {
                                            var o = t[r];
                                            e[r] = Kn(o, n) ? a[o] : Ho
                                        }
                                        return e
                                    }(n, m) : P && 1 < i && n.reverse(), g && v < i && (n.length = v), this && this !== fl && this instanceof e && (a = E || fn(a)), a.apply(o, n)
                                }
                            }

                            function gn(n, i) {
                                return function(e, t) {
                                    return e = e, r = n, a = i(t), o = {}, Ze(e, function(e, t, n) {
                                        r(o, a(e), t, n)
                                    }), o;
                                    var r, a, o
                                }
                            }

                            function yn(r, a) {
                                return function(e, t) {
                                    var n;
                                    if (e === Ho && t === Ho) return a;
                                    if (e !== Ho && (n = e), t !== Ho) {
                                        if (n === Ho) return t;
                                        t = "string" == typeof e || "string" == typeof t ? (e = Mt(e), Mt(t)) : (e = Ut(e), Ut(t)), n = r(e, t)
                                    }
                                    return n
                                }
                            }

                            function bn(r) {
                                return kn(function(e) {
                                    return e = xl(e, Vl(jn())), wt(function(t) {
                                        var n = this;
                                        return r(e, function(e) {
                                            return Il(e, n, t)
                                        })
                                    })
                                })
                            }

                            function In(e, t) {
                                var n = (t = t === Ho ? " " : Mt(t)).length;
                                if (n < 2) return n ? St(t, e) : t;
                                n = St(t, G(e / rs(t)));
                                return Ql(t) ? Kt(as(n), 0, e).join("") : n.slice(0, e)
                            }

                            function Pn(l, e, s, u) {
                                var c = 1 & e,
                                    d = fn(l);
                                return function e() {
                                    for (var t = -1, n = arguments.length, r = -1, a = u.length, o = S(a + n), i = this && this !== fl && this instanceof e ? d : l; ++r < a;) o[r] = u[r];
                                    for (; n--;) o[r++] = arguments[++t];
                                    return Il(i, c ? s : this, o)
                                }
                            }

                            function En(r) {
                                return function(e, t, n) {
                                    return n && "number" != typeof n && Jn(e, t, n) && (t = n = Ho), e = Wa(e), t === Ho ? (t = e, e = 0) : t = Wa(t),
                                        function(e, t, n, r) {
                                            for (var a = -1, o = W(G((t - e) / (n || 1)), 0), i = S(o); o--;) i[r ? o : ++a] = e, e += n;
                                            return i
                                        }(e, t, n = n === Ho ? e < t ? 1 : -1 : Wa(n), r)
                                }
                            }

                            function Sn(n) {
                                return function(e, t) {
                                    return "string" == typeof e && "string" == typeof t || (e = Za(e), t = Za(t)), n(e, t)
                                }
                            }

                            function wn(e, t, n, r, a, o, i, l, s, u) {
                                var c = 8 & t;
                                t |= c ? 32 : 64, 4 & (t &= ~(c ? 64 : 32)) || (t &= -4);
                                u = [e, t, a, c ? o : Ho, c ? i : Ho, c ? Ho : o, c ? Ho : i, l, s, u], n = n.apply(Ho, u);
                                return Qn(e) && ir(n, u), n.placeholder = r, ur(n, e, t)
                            }

                            function Cn(e) {
                                var r = a[e];
                                return function(e, t) {
                                    if (e = Za(e), (t = null == t ? 0 : $($a(t), 292)) && H(e)) {
                                        var n = (Ja(e) + "e").split("e");
                                        return +((n = (Ja(r(n[0] + "e" + (+n[1] + t))) + "e").split("e"))[0] + "e" + (+n[1] - t))
                                    }
                                    return r(e)
                                }
                            }
                            var Tn = ee && 1 / ns(new ee([, -0]))[1] == 1 / 0 ? function(e) {
                                return new ee(e)
                            } : Mo;

                            function _n(o) {
                                return function(e) {
                                    var t, n, r, a = Wn(e);
                                    return a == ai ? Xl(e) : a == ui ? (a = e, t = -1, n = Array(a.size), a.forEach(function(e) {
                                        n[++t] = [e, e]
                                    }), n) : xl(o(r = e), function(e) {
                                        return [e, r[e]]
                                    })
                                }
                            }

                            function xn(e, t, n, r, a, o, i, l) {
                                var s = 2 & t;
                                if (!s && "function" != typeof e) throw new E(zo);
                                var u = r ? r.length : 0;
                                u || (t &= -97, r = a = Ho), i = i === Ho ? i : W($a(i), 0), l = l === Ho ? l : $a(l), u -= a ? a.length : 0, 64 & t && (m = r, v = a, r = a = Ho);
                                var c, d, f, p, m, v, h, g, y, b, I = s ? Ho : Un(e),
                                    P = [e, t, n, r, a, m, v, o, i, l];
                                return I && (d = I, p = (c = P)[1], m = d[1], o = (v = p | m) < 131, i = m == $o && 8 == p || m == $o && 256 == p && c[7].length <= d[8] || 384 == m && d[7].length <= d[8] && 8 == p, (o || i) && (1 & m && (c[2] = d[2], v |= 1 & p ? 0 : 4), (p = d[3]) && (f = c[3], c[3] = f ? tn(f, p, d[4]) : p, c[4] = f ? ts(c[3], Wo) : d[4]), (p = d[5]) && (f = c[5], c[5] = f ? nn(f, p, d[6]) : p, c[6] = f ? ts(c[5], Wo) : d[6]), (p = d[7]) && (c[7] = p), m & $o && (c[8] = null == c[8] ? d[8] : $(c[8], d[8])), null == c[9] && (c[9] = d[9]), c[0] = d[0], c[1] = v)), e = P[0], t = P[1], n = P[2], r = P[3], a = P[4], !(l = P[9] = P[9] === Ho ? s ? 0 : e.length : W(P[9] - u, 0)) && 24 & t && (t &= -25), n = t && 1 != t ? 8 == t || 16 == t ? pn(e, t, l) : 32 != t && 33 != t || a.length ? hn.apply(Ho, P) : Pn(e, t, n, r) : (g = n, y = 1 & t, b = fn(h = e), function e() {
                                    return (this && this !== fl && this instanceof e ? b : h).apply(y ? g : this, arguments)
                                }), ur((I ? xt : ir)(n, P), e, t)
                            }

                            function Ln(e, t, n, r) {
                                return e === Ho || ya(e, m[n]) && !y.call(r, n) ? t : e
                            }

                            function Nn(e, t, n, r, a, o) {
                                return Aa(e) && Aa(t) && (o.set(t, e), ht(e, t, Ho, Nn, o), o.delete(t)), e
                            }

                            function Dn(e) {
                                return Ua(e) ? Ho : e
                            }

                            function An(e, t, n, r, a, o) {
                                var i = 1 & n,
                                    l = e.length,
                                    s = t.length;
                                if (l != s && !(i && l < s)) return !1;
                                var u = o.get(e),
                                    s = o.get(t);
                                if (u && s) return u == t && s == e;
                                var c = -1,
                                    d = !0,
                                    f = 2 & n ? new Ee : Ho;
                                for (o.set(e, t), o.set(t, e); ++c < l;) {
                                    var p, m = e[c],
                                        v = t[c];
                                    if (r && (p = i ? r(v, m, c, t, e, o) : r(m, v, c, e, t, o)), p !== Ho) {
                                        if (p) continue;
                                        d = !1;
                                        break
                                    }
                                    if (f) {
                                        if (!Al(t, function(e, t) {
                                                return !$l(f, t) && (m === e || a(m, e, n, r, o)) && f.push(t)
                                            })) {
                                            d = !1;
                                            break
                                        }
                                    } else if (m !== v && !a(m, v, n, r, o)) {
                                        d = !1;
                                        break
                                    }
                                }
                                return o.delete(e), o.delete(t), d
                            }

                            function kn(e) {
                                return sr(rr(e, Ho, Sr), e + "")
                            }

                            function On(e) {
                                return Qe(e, uo, zn)
                            }

                            function Rn(e) {
                                return Qe(e, co, Vn)
                            }
                            var Un = re ? function(e) {
                                return re.get(e)
                            } : Mo;

                            function Mn(e) {
                                for (var t = e.name + "", n = ae[t], r = y.call(ae, t) ? n.length : 0; r--;) {
                                    var a = n[r],
                                        o = a.func;
                                    if (null == o || o == e) return a.name
                                }
                                return t
                            }

                            function Gn(e) {
                                return (y.call(pe, "placeholder") ? pe : e).placeholder
                            }

                            function jn() {
                                var e = (e = pe.iteratee || Ro) === Ro ? ut : e;
                                return arguments.length ? e(arguments[0], arguments[1]) : e
                            }

                            function Fn(e, t) {
                                var n, r = e.__data__;
                                return ("string" == (e = typeof(n = t)) || "number" == e || "symbol" == e || "boolean" == e ? "__proto__" !== n : null === n) ? r["string" == typeof t ? "string" : "hash"] : r.map
                            }

                            function Bn(e) {
                                for (var t = uo(e), n = t.length; n--;) {
                                    var r = t[n],
                                        a = e[r];
                                    t[n] = [r, a, tr(a)]
                                }
                                return t
                            }

                            function Hn(e, t) {
                                t = t, t = null == (e = e) ? Ho : e[t];
                                return st(t) ? t : Ho
                            }
                            var zn = F ? function(t) {
                                    return null == t ? [] : (t = v(t), Cl(F(t), function(e) {
                                        return L.call(t, e)
                                    }))
                                } : jo,
                                Vn = F ? function(e) {
                                    for (var t = []; e;) Ll(t, zn(e)), e = _(e);
                                    return t
                                } : jo,
                                Wn = Xe;

                            function $n(e, t, n) {
                                for (var r = -1, a = (t = qt(t, e)).length, o = !1; ++r < a;) {
                                    var i = vr(t[r]);
                                    if (!(o = null != e && n(e, i))) break;
                                    e = e[i]
                                }
                                return o || ++r != a ? o : !!(a = null == e ? 0 : e.length) && Da(a) && Kn(i, a) && (Ea(e) || Pa(e))
                            }

                            function qn(e) {
                                return "function" != typeof e.constructor || er(e) ? {} : me(_(e))
                            }

                            function Zn(e) {
                                return Ea(e) || Pa(e) || !!(D && e && e[D])
                            }

                            function Kn(e, t) {
                                var n = typeof e;
                                return !!(t = null == t ? qo : t) && ("number" == n || "symbol" != n && Qi.test(e)) && -1 < e && e % 1 == 0 && e < t
                            }

                            function Jn(e, t, n) {
                                if (Aa(n)) {
                                    var r = typeof t;
                                    return ("number" == r ? wa(n) && Kn(t, n.length) : "string" == r && t in n) && ya(n[t], e)
                                }
                            }

                            function Yn(e, t) {
                                if (!Ea(e)) {
                                    var n = typeof e;
                                    return "number" == n || "symbol" == n || "boolean" == n || null == e || Fa(e) || (Ri.test(e) || !Oi.test(e) || null != t && e in v(t))
                                }
                            }

                            function Qn(e) {
                                var t = Mn(e),
                                    n = pe[t];
                                if ("function" == typeof n && t in ye.prototype) {
                                    if (e === n) return 1;
                                    n = Un(n);
                                    return n && e === n[0]
                                }
                            }(Y && Wn(new Y(new ArrayBuffer(1))) != mi || Q && Wn(new Q) != ai || X && Wn(X.resolve()) != li || ee && Wn(new ee) != ui || te && Wn(new te) != fi) && (Wn = function(e) {
                                var t = Xe(e),
                                    e = t == ii ? e.constructor : Ho,
                                    e = e ? hr(e) : "";
                                if (e) switch (e) {
                                    case oe:
                                        return mi;
                                    case ie:
                                        return ai;
                                    case le:
                                        return li;
                                    case se:
                                        return ui;
                                    case ue:
                                        return fi
                                }
                                return t
                            });
                            var Xn = i ? La : Fo;

                            function er(e) {
                                var t = e && e.constructor;
                                return e === ("function" == typeof t && t.prototype || m)
                            }

                            function tr(e) {
                                return e == e && !Aa(e)
                            }

                            function nr(t, n) {
                                return function(e) {
                                    return null != e && (e[t] === n && (n !== Ho || t in v(e)))
                                }
                            }

                            function rr(o, i, l) {
                                return i = W(i === Ho ? o.length - 1 : i, 0),
                                    function() {
                                        for (var e = arguments, t = -1, n = W(e.length - i, 0), r = S(n); ++t < n;) r[t] = e[i + t];
                                        t = -1;
                                        for (var a = S(i + 1); ++t < i;) a[t] = e[t];
                                        return a[i] = l(r), Il(o, this, a)
                                    }
                            }

                            function ar(e, t) {
                                return t.length < 2 ? e : Ye(e, Dt(t, 0, -1))
                            }

                            function or(e, t) {
                                if (("constructor" !== t || "function" != typeof e[t]) && "__proto__" != t) return e[t]
                            }
                            var ir = cr(xt),
                                lr = M || function(e, t) {
                                    return fl.setTimeout(e, t)
                                },
                                sr = cr(Lt);

                            function ur(e, t, n) {
                                var r, a, t = t + "";
                                return sr(e, function(e, t) {
                                    var n = t.length;
                                    if (!n) return e;
                                    var r = n - 1;
                                    return t[r] = (1 < n ? "& " : "") + t[r], t = t.join(2 < n ? ", " : " "), e.replace(Fi, "{\n/* [wrapped with " + t + "] */\n")
                                }(t, (r = (t = (t = t).match(Bi)) ? t[1].split(Hi) : [], a = n, El(Jo, function(e) {
                                    var t = "_." + e[0];
                                    a & e[1] && !Tl(r, t) && r.push(t)
                                }), r.sort())))
                            }

                            function cr(n) {
                                var r = 0,
                                    a = 0;
                                return function() {
                                    var e = q(),
                                        t = 16 - (e - a);
                                    if (a = e, 0 < t) {
                                        if (800 <= ++r) return arguments[0]
                                    } else r = 0;
                                    return n.apply(Ho, arguments)
                                }
                            }

                            function dr(e, t) {
                                var n = -1,
                                    r = e.length,
                                    a = r - 1;
                                for (t = t === Ho ? r : t; ++n < t;) {
                                    var o = Et(n, a),
                                        i = e[o];
                                    e[o] = e[n], e[n] = i
                                }
                                return e.length = t, e
                            }
                            var fr, pr, mr = (pr = (fr = fa(fr = function(e) {
                                var a = [];
                                return 46 === e.charCodeAt(0) && a.push(""), e.replace(Ui, function(e, t, n, r) {
                                    a.push(n ? r.replace(Wi, "$1") : t || e)
                                }), a
                            }, function(e) {
                                return 500 === pr.size && pr.clear(), e
                            })).cache, fr);

                            function vr(e) {
                                if ("string" == typeof e || Fa(e)) return e;
                                var t = e + "";
                                return "0" == t && 1 / e == -1 / 0 ? "-0" : t
                            }

                            function hr(e) {
                                if (null != e) {
                                    try {
                                        return l.call(e)
                                    } catch (e) {}
                                    try {
                                        return e + ""
                                    } catch (e) {}
                                }
                                return ""
                            }

                            function gr(e) {
                                if (e instanceof ye) return e.clone();
                                var t = new ge(e.__wrapped__, e.__chain__);
                                return t.__actions__ = rn(e.__actions__), t.__index__ = e.__index__, t.__values__ = e.__values__, t
                            }
                            var yr = wt(function(e, t) {
                                    return Ca(e) ? je(e, We(t, 1, Ca, !0)) : []
                                }),
                                br = wt(function(e, t) {
                                    var n = xr(t);
                                    return Ca(n) && (n = Ho), Ca(e) ? je(e, We(t, 1, Ca, !0), jn(n, 2)) : []
                                }),
                                Ir = wt(function(e, t) {
                                    var n = xr(t);
                                    return Ca(n) && (n = Ho), Ca(e) ? je(e, We(t, 1, Ca, !0), Ho, n) : []
                                });

                            function Pr(e, t, n) {
                                var r = null == e ? 0 : e.length;
                                if (!r) return -1;
                                n = null == n ? 0 : $a(n);
                                return n < 0 && (n = W(r + n, 0)), Ol(e, jn(t, 3), n)
                            }

                            function Er(e, t, n) {
                                var r = null == e ? 0 : e.length;
                                if (!r) return -1;
                                var a = r - 1;
                                return n !== Ho && (a = $a(n), a = n < 0 ? W(r + a, 0) : $(a, r - 1)), Ol(e, jn(t, 3), a, !0)
                            }

                            function Sr(e) {
                                return (null == e ? 0 : e.length) ? We(e, 1) : []
                            }

                            function wr(e) {
                                return e && e.length ? e[0] : Ho
                            }
                            var Cr = wt(function(e) {
                                    var t = xl(e, Wt);
                                    return t.length && t[0] === e[0] ? rt(t) : []
                                }),
                                Tr = wt(function(e) {
                                    var t = xr(e),
                                        n = xl(e, Wt);
                                    return t === xr(n) ? t = Ho : n.pop(), n.length && n[0] === e[0] ? rt(n, jn(t, 2)) : []
                                }),
                                _r = wt(function(e) {
                                    var t = xr(e),
                                        n = xl(e, Wt);
                                    return (t = "function" == typeof t ? t : Ho) && n.pop(), n.length && n[0] === e[0] ? rt(n, Ho, t) : []
                                });

                            function xr(e) {
                                var t = null == e ? 0 : e.length;
                                return t ? e[t - 1] : Ho
                            }
                            var Lr = wt(Nr);

                            function Nr(e, t) {
                                return e && e.length && t && t.length ? It(e, t) : e
                            }
                            var Dr = kn(function(e, t) {
                                var n = null == e ? 0 : e.length,
                                    r = Oe(e, t);
                                return Pt(e, xl(t, function(e) {
                                    return Kn(e, n) ? +e : e
                                }).sort(en)), r
                            });

                            function Ar(e) {
                                return null == e ? e : J.call(e)
                            }
                            var kr = wt(function(e) {
                                    return Gt(We(e, 1, Ca, !0))
                                }),
                                Or = wt(function(e) {
                                    var t = xr(e);
                                    return Ca(t) && (t = Ho), Gt(We(e, 1, Ca, !0), jn(t, 2))
                                }),
                                Rr = wt(function(e) {
                                    var t = "function" == typeof(t = xr(e)) ? t : Ho;
                                    return Gt(We(e, 1, Ca, !0), Ho, t)
                                });

                            function Ur(t) {
                                if (!t || !t.length) return [];
                                var n = 0;
                                return t = Cl(t, function(e) {
                                    return Ca(e) && (n = W(e.length, n), 1)
                                }), Hl(n, function(e) {
                                    return xl(t, jl(e))
                                })
                            }

                            function Mr(e, t) {
                                if (!e || !e.length) return [];
                                e = Ur(e);
                                return null == t ? e : xl(e, function(e) {
                                    return Il(t, Ho, e)
                                })
                            }
                            var Gr = wt(function(e, t) {
                                    return Ca(e) ? je(e, t) : []
                                }),
                                jr = wt(function(e) {
                                    return zt(Cl(e, Ca))
                                }),
                                Fr = wt(function(e) {
                                    var t = xr(e);
                                    return Ca(t) && (t = Ho), zt(Cl(e, Ca), jn(t, 2))
                                }),
                                Br = wt(function(e) {
                                    var t = "function" == typeof(t = xr(e)) ? t : Ho;
                                    return zt(Cl(e, Ca), Ho, t)
                                }),
                                Hr = wt(Ur);
                            var zr = wt(function(e) {
                                var t = e.length,
                                    t = "function" == typeof(t = 1 < t ? e[t - 1] : Ho) ? (e.pop(), t) : Ho;
                                return Mr(e, t)
                            });

                            function Vr(e) {
                                e = pe(e);
                                return e.__chain__ = !0, e
                            }

                            function Wr(e, t) {
                                return t(e)
                            }
                            var $r = kn(function(t) {
                                function e(e) {
                                    return Oe(e, t)
                                }
                                var n = t.length,
                                    r = n ? t[0] : 0,
                                    a = this.__wrapped__;
                                return !(1 < n || this.__actions__.length) && a instanceof ye && Kn(r) ? ((a = a.slice(r, +r + (n ? 1 : 0))).__actions__.push({
                                    func: Wr,
                                    args: [e],
                                    thisArg: Ho
                                }), new ge(a, this.__chain__).thru(function(e) {
                                    return n && !e.length && e.push(Ho), e
                                })) : this.thru(e)
                            });
                            var qr = on(function(e, t, n) {
                                y.call(e, n) ? ++e[n] : ke(e, n, 1)
                            });
                            var Zr = mn(Pr),
                                Kr = mn(Er);

                            function Jr(e, t) {
                                return (Ea(e) ? El : Fe)(e, jn(t, 3))
                            }

                            function Yr(e, t) {
                                return (Ea(e) ? Sl : Be)(e, jn(t, 3))
                            }
                            var Qr = on(function(e, t, n) {
                                y.call(e, n) ? e[n].push(t) : ke(e, n, [t])
                            });
                            var Xr = wt(function(e, t, n) {
                                    var r = -1,
                                        a = "function" == typeof t,
                                        o = wa(e) ? S(e.length) : [];
                                    return Fe(e, function(e) {
                                        o[++r] = a ? Il(t, e, n) : at(e, t, n)
                                    }), o
                                }),
                                ea = on(function(e, t, n) {
                                    ke(e, n, t)
                                });

                            function ta(e, t) {
                                return (Ea(e) ? xl : pt)(e, jn(t, 3))
                            }
                            var na = on(function(e, t, n) {
                                e[n ? 0 : 1].push(t)
                            }, function() {
                                return [
                                    [],
                                    []
                                ]
                            });
                            var ra = wt(function(e, t) {
                                    if (null == e) return [];
                                    var n = t.length;
                                    return 1 < n && Jn(e, t[0], t[1]) ? t = [] : 2 < n && Jn(t[0], t[1], t[2]) && (t = [t[0]]), yt(e, We(t, 1), [])
                                }),
                                aa = U || function() {
                                    return fl.Date.now()
                                };

                            function oa(e, t, n) {
                                return t = n ? Ho : t, t = e && null == t ? e.length : t, xn(e, $o, Ho, Ho, Ho, Ho, t)
                            }

                            function ia(e, t) {
                                var n;
                                if ("function" != typeof t) throw new E(zo);
                                return e = $a(e),
                                    function() {
                                        return 0 < --e && (n = t.apply(this, arguments)), e <= 1 && (t = Ho), n
                                    }
                            }
                            var la = wt(function(e, t, n) {
                                    var r, a = 1;
                                    return n.length && (r = ts(n, Gn(la)), a |= 32), xn(e, a, t, n, r)
                                }),
                                sa = wt(function(e, t, n) {
                                    var r, a = 3;
                                    return n.length && (r = ts(n, Gn(sa)), a |= 32), xn(t, a, e, n, r)
                                });

                            function ua(r, n, e) {
                                var a, o, i, l, s, u, c = 0,
                                    d = !1,
                                    f = !1,
                                    t = !0;
                                if ("function" != typeof r) throw new E(zo);

                                function p(e) {
                                    var t = a,
                                        n = o;
                                    return a = o = Ho, c = e, l = r.apply(n, t)
                                }

                                function m(e) {
                                    var t = e - u;
                                    return u === Ho || n <= t || t < 0 || f && i <= e - c
                                }

                                function v() {
                                    var e, t = aa();
                                    if (m(t)) return h(t);
                                    s = lr(v, (t = n - ((e = t) - u), f ? $(t, i - (e - c)) : t))
                                }

                                function h(e) {
                                    return s = Ho, t && a ? p(e) : (a = o = Ho, l)
                                }

                                function g() {
                                    var e = aa(),
                                        t = m(e);
                                    if (a = arguments, o = this, u = e, t) {
                                        if (s === Ho) return c = t = u, s = lr(v, n), d ? p(t) : l;
                                        if (f) return Jt(s), s = lr(v, n), p(u)
                                    }
                                    return s === Ho && (s = lr(v, n)), l
                                }
                                return n = Za(n) || 0, Aa(e) && (d = !!e.leading, f = "maxWait" in e, i = f ? W(Za(e.maxWait) || 0, n) : i, t = "trailing" in e ? !!e.trailing : t), g.cancel = function() {
                                    s !== Ho && Jt(s), c = 0, a = u = o = s = Ho
                                }, g.flush = function() {
                                    return s === Ho ? l : h(aa())
                                }, g
                            }
                            var ca = wt(function(e, t) {
                                    return Ge(e, 1, t)
                                }),
                                da = wt(function(e, t, n) {
                                    return Ge(e, Za(t) || 0, n)
                                });

                            function fa(r, a) {
                                if ("function" != typeof r || null != a && "function" != typeof a) throw new E(zo);
                                var o = function() {
                                    var e = arguments,
                                        t = a ? a.apply(this, e) : e[0],
                                        n = o.cache;
                                    if (n.has(t)) return n.get(t);
                                    e = r.apply(this, e);
                                    return o.cache = n.set(t, e) || n, e
                                };
                                return o.cache = new(fa.Cache || Pe), o
                            }

                            function pa(t) {
                                if ("function" != typeof t) throw new E(zo);
                                return function() {
                                    var e = arguments;
                                    switch (e.length) {
                                        case 0:
                                            return !t.call(this);
                                        case 1:
                                            return !t.call(this, e[0]);
                                        case 2:
                                            return !t.call(this, e[0], e[1]);
                                        case 3:
                                            return !t.call(this, e[0], e[1], e[2])
                                    }
                                    return !t.apply(this, e)
                                }
                            }
                            fa.Cache = Pe;
                            var ma = Zt(function(r, a) {
                                    var o = (a = 1 == a.length && Ea(a[0]) ? xl(a[0], Vl(jn())) : xl(We(a, 1), Vl(jn()))).length;
                                    return wt(function(e) {
                                        for (var t = -1, n = $(e.length, o); ++t < n;) e[t] = a[t].call(this, e[t]);
                                        return Il(r, this, e)
                                    })
                                }),
                                va = wt(function(e, t) {
                                    var n = ts(t, Gn(va));
                                    return xn(e, 32, Ho, t, n)
                                }),
                                ha = wt(function(e, t) {
                                    var n = ts(t, Gn(ha));
                                    return xn(e, 64, Ho, t, n)
                                }),
                                ga = kn(function(e, t) {
                                    return xn(e, 256, Ho, Ho, Ho, t)
                                });

                            function ya(e, t) {
                                return e === t || e != e && t != t
                            }
                            var ba = Sn(et),
                                Ia = Sn(function(e, t) {
                                    return t <= e
                                }),
                                Pa = ot(function() {
                                    return arguments
                                }()) ? ot : function(e) {
                                    return ka(e) && y.call(e, "callee") && !L.call(e, "callee")
                                },
                                Ea = S.isArray,
                                Sa = ml ? Vl(ml) : function(e) {
                                    return ka(e) && Xe(e) == pi
                                };

                            function wa(e) {
                                return null != e && Da(e.length) && !La(e)
                            }

                            function Ca(e) {
                                return ka(e) && wa(e)
                            }
                            var Ta = B || Fo,
                                _a = vl ? Vl(vl) : function(e) {
                                    return ka(e) && Xe(e) == ei
                                };

                            function xa(e) {
                                if (!ka(e)) return !1;
                                var t = Xe(e);
                                return t == ti || "[object DOMException]" == t || "string" == typeof e.message && "string" == typeof e.name && !Ua(e)
                            }

                            function La(e) {
                                if (!Aa(e)) return !1;
                                e = Xe(e);
                                return e == ni || e == ri || "[object AsyncFunction]" == e || "[object Proxy]" == e
                            }

                            function Na(e) {
                                return "number" == typeof e && e == $a(e)
                            }

                            function Da(e) {
                                return "number" == typeof e && -1 < e && e % 1 == 0 && e <= qo
                            }

                            function Aa(e) {
                                var t = typeof e;
                                return null != e && ("object" == t || "function" == t)
                            }

                            function ka(e) {
                                return null != e && "object" == typeof e
                            }
                            var Oa = hl ? Vl(hl) : function(e) {
                                return ka(e) && Wn(e) == ai
                            };

                            function Ra(e) {
                                return "number" == typeof e || ka(e) && Xe(e) == oi
                            }

                            function Ua(e) {
                                if (!ka(e) || Xe(e) != ii) return !1;
                                e = _(e);
                                if (null === e) return !0;
                                e = y.call(e, "constructor") && e.constructor;
                                return "function" == typeof e && e instanceof e && l.call(e) == g
                            }
                            var Ma = gl ? Vl(gl) : function(e) {
                                return ka(e) && Xe(e) == si
                            };
                            var Ga = yl ? Vl(yl) : function(e) {
                                return ka(e) && Wn(e) == ui
                            };

                            function ja(e) {
                                return "string" == typeof e || !Ea(e) && ka(e) && Xe(e) == ci
                            }

                            function Fa(e) {
                                return "symbol" == typeof e || ka(e) && Xe(e) == di
                            }
                            var Ba = bl ? Vl(bl) : function(e) {
                                return ka(e) && Da(e.length) && !!sl[Xe(e)]
                            };
                            var Ha = Sn(ft),
                                za = Sn(function(e, t) {
                                    return e <= t
                                });

                            function Va(e) {
                                if (!e) return [];
                                if (wa(e)) return (ja(e) ? as : rn)(e);
                                if (A && e[A]) return function(e) {
                                    for (var t, n = []; !(t = e.next()).done;) n.push(t.value);
                                    return n
                                }(e[A]());
                                var t = Wn(e);
                                return (t == ai ? Xl : t == ui ? ns : bo)(e)
                            }

                            function Wa(e) {
                                return e ? (e = Za(e)) !== 1 / 0 && e !== -1 / 0 ? e == e ? e : 0 : 17976931348623157e292 * (e < 0 ? -1 : 1) : 0 === e ? e : 0
                            }

                            function $a(e) {
                                var t = Wa(e),
                                    e = t % 1;
                                return t == t ? e ? t - e : t : 0
                            }

                            function qa(e) {
                                return e ? Re($a(e), 0, Ko) : 0
                            }

                            function Za(e) {
                                if ("number" == typeof e) return e;
                                if (Fa(e)) return Zo;
                                if (Aa(e) && (e = Aa(t = "function" == typeof e.valueOf ? e.valueOf() : e) ? t + "" : t), "string" != typeof e) return 0 === e ? e : +e;
                                e = zl(e);
                                var t = Ki.test(e);
                                return t || Yi.test(e) ? dl(e.slice(2), t ? 2 : 8) : Zi.test(e) ? Zo : +e
                            }

                            function Ka(e) {
                                return an(e, co(e))
                            }

                            function Ja(e) {
                                return null == e ? "" : Mt(e)
                            }
                            var Ya = ln(function(e, t) {
                                    if (er(t) || wa(t)) an(t, uo(t), e);
                                    else
                                        for (var n in t) y.call(t, n) && Le(e, n, t[n])
                                }),
                                Qa = ln(function(e, t) {
                                    an(t, co(t), e)
                                }),
                                Xa = ln(function(e, t, n, r) {
                                    an(t, co(t), e, r)
                                }),
                                eo = ln(function(e, t, n, r) {
                                    an(t, uo(t), e, r)
                                }),
                                to = kn(Oe);
                            var no = wt(function(e, t) {
                                    e = v(e);
                                    var n = -1,
                                        r = t.length,
                                        a = 2 < r ? t[2] : Ho;
                                    for (a && Jn(t[0], t[1], a) && (r = 1); ++n < r;)
                                        for (var o = t[n], i = co(o), l = -1, s = i.length; ++l < s;) {
                                            var u = i[l],
                                                c = e[u];
                                            (c === Ho || ya(c, m[u]) && !y.call(e, u)) && (e[u] = o[u])
                                        }
                                    return e
                                }),
                                ro = wt(function(e) {
                                    return e.push(Ho, Nn), Il(po, Ho, e)
                                });

                            function ao(e, t, n) {
                                t = null == e ? Ho : Ye(e, t);
                                return t === Ho ? n : t
                            }

                            function oo(e, t) {
                                return null != e && $n(e, t, nt)
                            }
                            var io = gn(function(e, t, n) {
                                    null != t && "function" != typeof t.toString && (t = h.call(t)), e[t] = n
                                }, Ao(Oo)),
                                lo = gn(function(e, t, n) {
                                    null != t && "function" != typeof t.toString && (t = h.call(t)), y.call(e, t) ? e[t].push(n) : e[t] = [n]
                                }, jn),
                                so = wt(at);

                            function uo(e) {
                                return (wa(e) ? we : ct)(e)
                            }

                            function co(e) {
                                return wa(e) ? we(e, !0) : dt(e)
                            }
                            var fo = ln(function(e, t, n) {
                                    ht(e, t, n)
                                }),
                                po = ln(function(e, t, n, r) {
                                    ht(e, t, n, r)
                                }),
                                mo = kn(function(t, e) {
                                    var n = {};
                                    if (null == t) return n;
                                    var r = !1;
                                    e = xl(e, function(e) {
                                        return e = qt(e, t), r = r || 1 < e.length, e
                                    }), an(t, Rn(t), n), r && (n = Ue(n, 7, Dn));
                                    for (var a = e.length; a--;) jt(n, e[a]);
                                    return n
                                });
                            var vo = kn(function(e, t) {
                                return null == e ? {} : bt(n = e, t, function(e, t) {
                                    return oo(n, t)
                                });
                                var n
                            });

                            function ho(e, n) {
                                if (null == e) return {};
                                var t = xl(Rn(e), function(e) {
                                    return [e]
                                });
                                return n = jn(n), bt(e, t, function(e, t) {
                                    return n(e, t[0])
                                })
                            }
                            var go = _n(uo),
                                yo = _n(co);

                            function bo(e) {
                                return null == e ? [] : Wl(e, uo(e))
                            }
                            var Io = dn(function(e, t, n) {
                                return t = t.toLowerCase(), e + (n ? Po(t) : t)
                            });

                            function Po(e) {
                                return Lo(Ja(e).toLowerCase())
                            }

                            function Eo(e) {
                                return (e = Ja(e)) && e.replace(Xi, Kl).replace(rl, "")
                            }
                            var So = dn(function(e, t, n) {
                                    return e + (n ? "-" : "") + t.toLowerCase()
                                }),
                                wo = dn(function(e, t, n) {
                                    return e + (n ? " " : "") + t.toLowerCase()
                                }),
                                Co = cn("toLowerCase");
                            var To = dn(function(e, t, n) {
                                return e + (n ? "_" : "") + t.toLowerCase()
                            });
                            var _o = dn(function(e, t, n) {
                                return e + (n ? " " : "") + Lo(t)
                            });
                            var xo = dn(function(e, t, n) {
                                    return e + (n ? " " : "") + t.toUpperCase()
                                }),
                                Lo = cn("toUpperCase");

                            function No(e, t, n) {
                                return e = Ja(e), (t = n ? Ho : t) === Ho ? (n = e, ol.test(n) ? e.match(al) || [] : e.match(zi) || []) : e.match(t) || []
                            }
                            var Do = wt(function(e, t) {
                                    try {
                                        return Il(e, Ho, t)
                                    } catch (e) {
                                        return xa(e) ? e : new d(e)
                                    }
                                }),
                                r = kn(function(t, e) {
                                    return El(e, function(e) {
                                        e = vr(e), ke(t, e, la(t[e], t))
                                    }), t
                                });

                            function Ao(e) {
                                return function() {
                                    return e
                                }
                            }
                            var ko = vn(),
                                P = vn(!0);

                            function Oo(e) {
                                return e
                            }

                            function Ro(e) {
                                return ut("function" == typeof e ? e : Ue(e, 1))
                            }
                            n = wt(function(t, n) {
                                return function(e) {
                                    return at(e, t, n)
                                }
                            }), t = wt(function(t, n) {
                                return function(e) {
                                    return at(t, e, n)
                                }
                            });

                            function Uo(r, t, e) {
                                var n = uo(t),
                                    a = Je(t, n);
                                null != e || Aa(t) && (a.length || !n.length) || (e = t, t = r, r = this, a = Je(t, uo(t)));
                                var o = !(Aa(e) && "chain" in e && !e.chain),
                                    i = La(r);
                                return El(a, function(e) {
                                    var n = t[e];
                                    r[e] = n, i && (r.prototype[e] = function() {
                                        var e = this.__chain__;
                                        if (o || e) {
                                            var t = r(this.__wrapped__);
                                            return (t.__actions__ = rn(this.__actions__)).push({
                                                func: n,
                                                args: arguments,
                                                thisArg: r
                                            }), t.__chain__ = e, t
                                        }
                                        return n.apply(r, Ll([this.value()], arguments))
                                    })
                                }), r
                            }

                            function Mo() {}
                            w = bn(xl), ce = bn(wl), R = bn(Al);

                            function Go(e) {
                                return Yn(e) ? jl(vr(e)) : (t = e, function(e) {
                                    return Ye(e, t)
                                });
                                var t
                            }
                            Y = En(), X = En(!0);

                            function jo() {
                                return []
                            }

                            function Fo() {
                                return !1
                            }
                            te = yn(function(e, t) {
                                return e + t
                            }, 0), i = Cn("ceil"), M = yn(function(e, t) {
                                return e / t
                            }, 1), Lt = Cn("floor");
                            var Bo, U = yn(function(e, t) {
                                    return e * t
                                }, 1),
                                Zt = Cn("round"),
                                B = yn(function(e, t) {
                                    return e - t
                                }, 0);
                            return pe.after = function(e, t) {
                                if ("function" != typeof t) throw new E(zo);
                                return e = $a(e),
                                    function() {
                                        if (--e < 1) return t.apply(this, arguments)
                                    }
                            }, pe.ary = oa, pe.assign = Ya, pe.assignIn = Qa, pe.assignInWith = Xa, pe.assignWith = eo, pe.at = to, pe.before = ia, pe.bind = la, pe.bindAll = r, pe.bindKey = sa, pe.castArray = function() {
                                if (!arguments.length) return [];
                                var e = arguments[0];
                                return Ea(e) ? e : [e]
                            }, pe.chain = Vr, pe.chunk = function(e, t, n) {
                                t = (n ? Jn(e, t, n) : t === Ho) ? 1 : W($a(t), 0);
                                var r = null == e ? 0 : e.length;
                                if (!r || t < 1) return [];
                                for (var a = 0, o = 0, i = S(G(r / t)); a < r;) i[o++] = Dt(e, a, a += t);
                                return i
                            }, pe.compact = function(e) {
                                for (var t = -1, n = null == e ? 0 : e.length, r = 0, a = []; ++t < n;) {
                                    var o = e[t];
                                    o && (a[r++] = o)
                                }
                                return a
                            }, pe.concat = function() {
                                var e = arguments.length;
                                if (!e) return [];
                                for (var t = S(e - 1), n = arguments[0], r = e; r--;) t[r - 1] = arguments[r];
                                return Ll(Ea(n) ? rn(n) : [n], We(t, 1))
                            }, pe.cond = function(r) {
                                var a = null == r ? 0 : r.length,
                                    t = jn();
                                return r = a ? xl(r, function(e) {
                                    if ("function" != typeof e[1]) throw new E(zo);
                                    return [t(e[0]), e[1]]
                                }) : [], wt(function(e) {
                                    for (var t = -1; ++t < a;) {
                                        var n = r[t];
                                        if (Il(n[0], this, e)) return Il(n[1], this, e)
                                    }
                                })
                            }, pe.conforms = function(e) {
                                return t = Ue(e, 1), n = uo(t),
                                    function(e) {
                                        return Me(e, t, n)
                                    };
                                var t, n
                            }, pe.constant = Ao, pe.countBy = qr, pe.create = function(e, t) {
                                return e = me(e), null == t ? e : Ae(e, t)
                            }, pe.curry = function e(t, n, r) {
                                n = xn(t, 8, Ho, Ho, Ho, Ho, Ho, n = r ? Ho : n);
                                return n.placeholder = e.placeholder, n
                            }, pe.curryRight = function e(t, n, r) {
                                n = xn(t, 16, Ho, Ho, Ho, Ho, Ho, n = r ? Ho : n);
                                return n.placeholder = e.placeholder, n
                            }, pe.debounce = ua, pe.defaults = no, pe.defaultsDeep = ro, pe.defer = ca, pe.delay = da, pe.difference = yr, pe.differenceBy = br, pe.differenceWith = Ir, pe.drop = function(e, t, n) {
                                var r = null == e ? 0 : e.length;
                                return r ? Dt(e, (t = n || t === Ho ? 1 : $a(t)) < 0 ? 0 : t, r) : []
                            }, pe.dropRight = function(e, t, n) {
                                var r = null == e ? 0 : e.length;
                                return r ? Dt(e, 0, (t = r - (t = n || t === Ho ? 1 : $a(t))) < 0 ? 0 : t) : []
                            }, pe.dropRightWhile = function(e, t) {
                                return e && e.length ? Bt(e, jn(t, 3), !0, !0) : []
                            }, pe.dropWhile = function(e, t) {
                                return e && e.length ? Bt(e, jn(t, 3), !0) : []
                            }, pe.fill = function(e, t, n, r) {
                                var a = null == e ? 0 : e.length;
                                return a ? (n && "number" != typeof n && Jn(e, t, n) && (n = 0, r = a), function(e, t, n, r) {
                                    var a = e.length;
                                    for ((n = $a(n)) < 0 && (n = a < -n ? 0 : a + n), (r = r === Ho || a < r ? a : $a(r)) < 0 && (r += a), r = r < n ? 0 : qa(r); n < r;) e[n++] = t;
                                    return e
                                }(e, t, n, r)) : []
                            }, pe.filter = function(e, t) {
                                return (Ea(e) ? Cl : Ve)(e, jn(t, 3))
                            }, pe.flatMap = function(e, t) {
                                return We(ta(e, t), 1)
                            }, pe.flatMapDeep = function(e, t) {
                                return We(ta(e, t), 1 / 0)
                            }, pe.flatMapDepth = function(e, t, n) {
                                return n = n === Ho ? 1 : $a(n), We(ta(e, t), n)
                            }, pe.flatten = Sr, pe.flattenDeep = function(e) {
                                return (null == e ? 0 : e.length) ? We(e, 1 / 0) : []
                            }, pe.flattenDepth = function(e, t) {
                                return (null == e ? 0 : e.length) ? We(e, t = t === Ho ? 1 : $a(t)) : []
                            }, pe.flip = function(e) {
                                return xn(e, 512)
                            }, pe.flow = ko, pe.flowRight = P, pe.fromPairs = function(e) {
                                for (var t = -1, n = null == e ? 0 : e.length, r = {}; ++t < n;) {
                                    var a = e[t];
                                    r[a[0]] = a[1]
                                }
                                return r
                            }, pe.functions = function(e) {
                                return null == e ? [] : Je(e, uo(e))
                            }, pe.functionsIn = function(e) {
                                return null == e ? [] : Je(e, co(e))
                            }, pe.groupBy = Qr, pe.initial = function(e) {
                                return (null == e ? 0 : e.length) ? Dt(e, 0, -1) : []
                            }, pe.intersection = Cr, pe.intersectionBy = Tr, pe.intersectionWith = _r, pe.invert = io, pe.invertBy = lo, pe.invokeMap = Xr, pe.iteratee = Ro, pe.keyBy = ea, pe.keys = uo, pe.keysIn = co, pe.map = ta, pe.mapKeys = function(e, r) {
                                var a = {};
                                return r = jn(r, 3), Ze(e, function(e, t, n) {
                                    ke(a, r(e, t, n), e)
                                }), a
                            }, pe.mapValues = function(e, r) {
                                var a = {};
                                return r = jn(r, 3), Ze(e, function(e, t, n) {
                                    ke(a, t, r(e, t, n))
                                }), a
                            }, pe.matches = function(e) {
                                return mt(Ue(e, 1))
                            }, pe.matchesProperty = function(e, t) {
                                return vt(e, Ue(t, 1))
                            }, pe.memoize = fa, pe.merge = fo, pe.mergeWith = po, pe.method = n, pe.methodOf = t, pe.mixin = Uo, pe.negate = pa, pe.nthArg = function(t) {
                                return t = $a(t), wt(function(e) {
                                    return gt(e, t)
                                })
                            }, pe.omit = mo, pe.omitBy = function(e, t) {
                                return ho(e, pa(jn(t)))
                            }, pe.once = function(e) {
                                return ia(2, e)
                            }, pe.orderBy = function(e, t, n, r) {
                                return null == e ? [] : (Ea(t) || (t = null == t ? [] : [t]), Ea(n = r ? Ho : n) || (n = null == n ? [] : [n]), yt(e, t, n))
                            }, pe.over = w, pe.overArgs = ma, pe.overEvery = ce, pe.overSome = R, pe.partial = va, pe.partialRight = ha, pe.partition = na, pe.pick = vo, pe.pickBy = ho, pe.property = Go, pe.propertyOf = function(t) {
                                return function(e) {
                                    return null == t ? Ho : Ye(t, e)
                                }
                            }, pe.pull = Lr, pe.pullAll = Nr, pe.pullAllBy = function(e, t, n) {
                                return e && e.length && t && t.length ? It(e, t, jn(n, 2)) : e
                            }, pe.pullAllWith = function(e, t, n) {
                                return e && e.length && t && t.length ? It(e, t, Ho, n) : e
                            }, pe.pullAt = Dr, pe.range = Y, pe.rangeRight = X, pe.rearg = ga, pe.reject = function(e, t) {
                                return (Ea(e) ? Cl : Ve)(e, pa(jn(t, 3)))
                            }, pe.remove = function(e, t) {
                                var n = [];
                                if (!e || !e.length) return n;
                                var r = -1,
                                    a = [],
                                    o = e.length;
                                for (t = jn(t, 3); ++r < o;) {
                                    var i = e[r];
                                    t(i, r, e) && (n.push(i), a.push(r))
                                }
                                return Pt(e, a), n
                            }, pe.rest = function(e, t) {
                                if ("function" != typeof e) throw new E(zo);
                                return wt(e, t = t === Ho ? t : $a(t))
                            }, pe.reverse = Ar, pe.sampleSize = function(e, t, n) {
                                return t = (n ? Jn(e, t, n) : t === Ho) ? 1 : $a(t), (Ea(e) ? Te : Tt)(e, t)
                            }, pe.set = function(e, t, n) {
                                return null == e ? e : _t(e, t, n)
                            }, pe.setWith = function(e, t, n, r) {
                                return r = "function" == typeof r ? r : Ho, null == e ? e : _t(e, t, n, r)
                            }, pe.shuffle = function(e) {
                                return (Ea(e) ? _e : Nt)(e)
                            }, pe.slice = function(e, t, n) {
                                var r = null == e ? 0 : e.length;
                                return r ? (n = n && "number" != typeof n && Jn(e, t, n) ? (t = 0, r) : (t = null == t ? 0 : $a(t), n === Ho ? r : $a(n)), Dt(e, t, n)) : []
                            }, pe.sortBy = ra, pe.sortedUniq = function(e) {
                                return e && e.length ? Rt(e) : []
                            }, pe.sortedUniqBy = function(e, t) {
                                return e && e.length ? Rt(e, jn(t, 2)) : []
                            }, pe.split = function(e, t, n) {
                                return n && "number" != typeof n && Jn(e, t, n) && (t = n = Ho), (n = n === Ho ? Ko : n >>> 0) ? (e = Ja(e)) && ("string" == typeof t || null != t && !Ma(t)) && !(t = Mt(t)) && Ql(e) ? Kt(as(e), 0, n) : e.split(t, n) : []
                            }, pe.spread = function(n, r) {
                                if ("function" != typeof n) throw new E(zo);
                                return r = null == r ? 0 : W($a(r), 0), wt(function(e) {
                                    var t = e[r],
                                        e = Kt(e, 0, r);
                                    return t && Ll(e, t), Il(n, this, e)
                                })
                            }, pe.tail = function(e) {
                                var t = null == e ? 0 : e.length;
                                return t ? Dt(e, 1, t) : []
                            }, pe.take = function(e, t, n) {
                                return e && e.length ? Dt(e, 0, (t = n || t === Ho ? 1 : $a(t)) < 0 ? 0 : t) : []
                            }, pe.takeRight = function(e, t, n) {
                                var r = null == e ? 0 : e.length;
                                return r ? Dt(e, (t = r - (t = n || t === Ho ? 1 : $a(t))) < 0 ? 0 : t, r) : []
                            }, pe.takeRightWhile = function(e, t) {
                                return e && e.length ? Bt(e, jn(t, 3), !1, !0) : []
                            }, pe.takeWhile = function(e, t) {
                                return e && e.length ? Bt(e, jn(t, 3)) : []
                            }, pe.tap = function(e, t) {
                                return t(e), e
                            }, pe.throttle = function(e, t, n) {
                                var r = !0,
                                    a = !0;
                                if ("function" != typeof e) throw new E(zo);
                                return Aa(n) && (r = "leading" in n ? !!n.leading : r, a = "trailing" in n ? !!n.trailing : a), ua(e, t, {
                                    leading: r,
                                    maxWait: t,
                                    trailing: a
                                })
                            }, pe.thru = Wr, pe.toArray = Va, pe.toPairs = go, pe.toPairsIn = yo, pe.toPath = function(e) {
                                return Ea(e) ? xl(e, vr) : Fa(e) ? [e] : rn(mr(Ja(e)))
                            }, pe.toPlainObject = Ka, pe.transform = function(e, r, a) {
                                var t, n = Ea(e),
                                    o = n || Ta(e) || Ba(e);
                                return r = jn(r, 4), null == a && (t = e && e.constructor, a = o ? n ? new t : [] : Aa(e) && La(t) ? me(_(e)) : {}), (o ? El : Ze)(e, function(e, t, n) {
                                    return r(a, e, t, n)
                                }), a
                            }, pe.unary = function(e) {
                                return oa(e, 1)
                            }, pe.union = kr, pe.unionBy = Or, pe.unionWith = Rr, pe.uniq = function(e) {
                                return e && e.length ? Gt(e) : []
                            }, pe.uniqBy = function(e, t) {
                                return e && e.length ? Gt(e, jn(t, 2)) : []
                            }, pe.uniqWith = function(e, t) {
                                return t = "function" == typeof t ? t : Ho, e && e.length ? Gt(e, Ho, t) : []
                            }, pe.unset = function(e, t) {
                                return null == e || jt(e, t)
                            }, pe.unzip = Ur, pe.unzipWith = Mr, pe.update = function(e, t, n) {
                                return null == e ? e : Ft(e, t, $t(n))
                            }, pe.updateWith = function(e, t, n, r) {
                                return r = "function" == typeof r ? r : Ho, null == e ? e : Ft(e, t, $t(n), r)
                            }, pe.values = bo, pe.valuesIn = function(e) {
                                return null == e ? [] : Wl(e, co(e))
                            }, pe.without = Gr, pe.words = No, pe.wrap = function(e, t) {
                                return va($t(t), e)
                            }, pe.xor = jr, pe.xorBy = Fr, pe.xorWith = Br, pe.zip = Hr, pe.zipObject = function(e, t) {
                                return Vt(e || [], t || [], Le)
                            }, pe.zipObjectDeep = function(e, t) {
                                return Vt(e || [], t || [], _t)
                            }, pe.zipWith = zr, pe.entries = go, pe.entriesIn = yo, pe.extend = Qa, pe.extendWith = Xa, Uo(pe, pe), pe.add = te, pe.attempt = Do, pe.camelCase = Io, pe.capitalize = Po, pe.ceil = i, pe.clamp = function(e, t, n) {
                                return n === Ho && (n = t, t = Ho), n !== Ho && (n = (n = Za(n)) == n ? n : 0), t !== Ho && (t = (t = Za(t)) == t ? t : 0), Re(Za(e), t, n)
                            }, pe.clone = function(e) {
                                return Ue(e, 4)
                            }, pe.cloneDeep = function(e) {
                                return Ue(e, 5)
                            }, pe.cloneDeepWith = function(e, t) {
                                return Ue(e, 5, t = "function" == typeof t ? t : Ho)
                            }, pe.cloneWith = function(e, t) {
                                return Ue(e, 4, t = "function" == typeof t ? t : Ho)
                            }, pe.conformsTo = function(e, t) {
                                return null == t || Me(e, t, uo(t))
                            }, pe.deburr = Eo, pe.defaultTo = function(e, t) {
                                return null == e || e != e ? t : e
                            }, pe.divide = M, pe.endsWith = function(e, t, n) {
                                e = Ja(e), t = Mt(t);
                                var r = e.length,
                                    r = n = n === Ho ? r : Re($a(n), 0, r);
                                return 0 <= (n -= t.length) && e.slice(n, r) == t
                            }, pe.eq = ya, pe.escape = function(e) {
                                return (e = Ja(e)) && Ni.test(e) ? e.replace(xi, Jl) : e
                            }, pe.escapeRegExp = function(e) {
                                return (e = Ja(e)) && Gi.test(e) ? e.replace(Mi, "\\$&") : e
                            }, pe.every = function(e, t, n) {
                                var r = Ea(e) ? wl : He;
                                return n && Jn(e, t, n) && (t = Ho), r(e, jn(t, 3))
                            }, pe.find = Zr, pe.findIndex = Pr, pe.findKey = function(e, t) {
                                return kl(e, jn(t, 3), Ze)
                            }, pe.findLast = Kr, pe.findLastIndex = Er, pe.findLastKey = function(e, t) {
                                return kl(e, jn(t, 3), Ke)
                            }, pe.floor = Lt, pe.forEach = Jr, pe.forEachRight = Yr, pe.forIn = function(e, t) {
                                return null == e ? e : $e(e, jn(t, 3), co)
                            }, pe.forInRight = function(e, t) {
                                return null == e ? e : qe(e, jn(t, 3), co)
                            }, pe.forOwn = function(e, t) {
                                return e && Ze(e, jn(t, 3))
                            }, pe.forOwnRight = function(e, t) {
                                return e && Ke(e, jn(t, 3))
                            }, pe.get = ao, pe.gt = ba, pe.gte = Ia, pe.has = function(e, t) {
                                return null != e && $n(e, t, tt)
                            }, pe.hasIn = oo, pe.head = wr, pe.identity = Oo, pe.includes = function(e, t, n, r) {
                                return e = wa(e) ? e : bo(e), n = n && !r ? $a(n) : 0, r = e.length, n < 0 && (n = W(r + n, 0)), ja(e) ? n <= r && -1 < e.indexOf(t, n) : !!r && -1 < Rl(e, t, n)
                            }, pe.indexOf = function(e, t, n) {
                                var r = null == e ? 0 : e.length;
                                return r ? ((n = null == n ? 0 : $a(n)) < 0 && (n = W(r + n, 0)), Rl(e, t, n)) : -1
                            }, pe.inRange = function(e, t, n) {
                                return t = Wa(t), n === Ho ? (n = t, t = 0) : n = Wa(n), (e = e = Za(e)) >= $(t = t, n = n) && e < W(t, n)
                            }, pe.invoke = so, pe.isArguments = Pa, pe.isArray = Ea, pe.isArrayBuffer = Sa, pe.isArrayLike = wa, pe.isArrayLikeObject = Ca, pe.isBoolean = function(e) {
                                return !0 === e || !1 === e || ka(e) && Xe(e) == Xo
                            }, pe.isBuffer = Ta, pe.isDate = _a, pe.isElement = function(e) {
                                return ka(e) && 1 === e.nodeType && !Ua(e)
                            }, pe.isEmpty = function(e) {
                                if (null == e) return !0;
                                if (wa(e) && (Ea(e) || "string" == typeof e || "function" == typeof e.splice || Ta(e) || Ba(e) || Pa(e))) return !e.length;
                                var t, n = Wn(e);
                                if (n == ai || n == ui) return !e.size;
                                if (er(e)) return !ct(e).length;
                                for (t in e)
                                    if (y.call(e, t)) return !1;
                                return !0
                            }, pe.isEqual = function(e, t) {
                                return it(e, t)
                            }, pe.isEqualWith = function(e, t, n) {
                                var r = (n = "function" == typeof n ? n : Ho) ? n(e, t) : Ho;
                                return r === Ho ? it(e, t, Ho, n) : !!r
                            }, pe.isError = xa, pe.isFinite = function(e) {
                                return "number" == typeof e && H(e)
                            }, pe.isFunction = La, pe.isInteger = Na, pe.isLength = Da, pe.isMap = Oa, pe.isMatch = function(e, t) {
                                return e === t || lt(e, t, Bn(t))
                            }, pe.isMatchWith = function(e, t, n) {
                                return n = "function" == typeof n ? n : Ho, lt(e, t, Bn(t), n)
                            }, pe.isNaN = function(e) {
                                return Ra(e) && e != +e
                            }, pe.isNative = function(e) {
                                if (Xn(e)) throw new d("Unsupported core-js use. Try https://npms.io/search?q=ponyfill.");
                                return st(e)
                            }, pe.isNil = function(e) {
                                return null == e
                            }, pe.isNull = function(e) {
                                return null === e
                            }, pe.isNumber = Ra, pe.isObject = Aa, pe.isObjectLike = ka, pe.isPlainObject = Ua, pe.isRegExp = Ma, pe.isSafeInteger = function(e) {
                                return Na(e) && -qo <= e && e <= qo
                            }, pe.isSet = Ga, pe.isString = ja, pe.isSymbol = Fa, pe.isTypedArray = Ba, pe.isUndefined = function(e) {
                                return e === Ho
                            }, pe.isWeakMap = function(e) {
                                return ka(e) && Wn(e) == fi
                            }, pe.isWeakSet = function(e) {
                                return ka(e) && "[object WeakSet]" == Xe(e)
                            }, pe.join = function(e, t) {
                                return null == e ? "" : z.call(e, t)
                            }, pe.kebabCase = So, pe.last = xr, pe.lastIndexOf = function(e, t, n) {
                                var r = null == e ? 0 : e.length;
                                if (!r) return -1;
                                var a = r;
                                return n !== Ho && (a = (a = $a(n)) < 0 ? W(r + a, 0) : $(a, r - 1)), t == t ? function(e, t, n) {
                                    for (var r = n + 1; r--;)
                                        if (e[r] === t) return r;
                                    return r
                                }(e, t, a) : Ol(e, Ml, a, !0)
                            }, pe.lowerCase = wo, pe.lowerFirst = Co, pe.lt = Ha, pe.lte = za, pe.max = function(e) {
                                return e && e.length ? ze(e, Oo, et) : Ho
                            }, pe.maxBy = function(e, t) {
                                return e && e.length ? ze(e, jn(t, 2), et) : Ho
                            }, pe.mean = function(e) {
                                return Gl(e, Oo)
                            }, pe.meanBy = function(e, t) {
                                return Gl(e, jn(t, 2))
                            }, pe.min = function(e) {
                                return e && e.length ? ze(e, Oo, ft) : Ho
                            }, pe.minBy = function(e, t) {
                                return e && e.length ? ze(e, jn(t, 2), ft) : Ho
                            }, pe.stubArray = jo, pe.stubFalse = Fo, pe.stubObject = function() {
                                return {}
                            }, pe.stubString = function() {
                                return ""
                            }, pe.stubTrue = function() {
                                return !0
                            }, pe.multiply = U, pe.nth = function(e, t) {
                                return e && e.length ? gt(e, $a(t)) : Ho
                            }, pe.noConflict = function() {
                                return fl._ === this && (fl._ = b), this
                            }, pe.noop = Mo, pe.now = aa, pe.pad = function(e, t, n) {
                                e = Ja(e);
                                var r = (t = $a(t)) ? rs(e) : 0;
                                return !t || t <= r ? e : In(j(r = (t - r) / 2), n) + e + In(G(r), n)
                            }, pe.padEnd = function(e, t, n) {
                                e = Ja(e);
                                var r = (t = $a(t)) ? rs(e) : 0;
                                return t && r < t ? e + In(t - r, n) : e
                            }, pe.padStart = function(e, t, n) {
                                e = Ja(e);
                                var r = (t = $a(t)) ? rs(e) : 0;
                                return t && r < t ? In(t - r, n) + e : e
                            }, pe.parseInt = function(e, t, n) {
                                return t = n || null == t ? 0 : t && +t, Z(Ja(e).replace(ji, ""), t || 0)
                            }, pe.random = function(e, t, n) {
                                var r;
                                if (n && "boolean" != typeof n && Jn(e, t, n) && (t = n = Ho), n === Ho && ("boolean" == typeof t ? (n = t, t = Ho) : "boolean" == typeof e && (n = e, e = Ho)), e === Ho && t === Ho ? (e = 0, t = 1) : (e = Wa(e), t === Ho ? (t = e, e = 0) : t = Wa(t)), t < e && (r = e, e = t, t = r), n || e % 1 || t % 1) {
                                    n = K();
                                    return $(e + n * (t - e + cl("1e-" + ((n + "").length - 1))), t)
                                }
                                return Et(e, t)
                            }, pe.reduce = function(e, t, n) {
                                var r = Ea(e) ? Nl : Fl,
                                    a = arguments.length < 3;
                                return r(e, jn(t, 4), n, a, Fe)
                            }, pe.reduceRight = function(e, t, n) {
                                var r = Ea(e) ? Dl : Fl,
                                    a = arguments.length < 3;
                                return r(e, jn(t, 4), n, a, Be)
                            }, pe.repeat = function(e, t, n) {
                                return t = (n ? Jn(e, t, n) : t === Ho) ? 1 : $a(t), St(Ja(e), t)
                            }, pe.replace = function() {
                                var e = arguments,
                                    t = Ja(e[0]);
                                return e.length < 3 ? t : t.replace(e[1], e[2])
                            }, pe.result = function(e, t, n) {
                                var r = -1,
                                    a = (t = qt(t, e)).length;
                                for (a || (a = 1, e = Ho); ++r < a;) {
                                    var o = null == e ? Ho : e[vr(t[r])];
                                    o === Ho && (r = a, o = n), e = La(o) ? o.call(e) : o
                                }
                                return e
                            }, pe.round = Zt, pe.runInContext = e, pe.sample = function(e) {
                                return (Ea(e) ? Ce : Ct)(e)
                            }, pe.size = function(e) {
                                if (null == e) return 0;
                                if (wa(e)) return ja(e) ? rs(e) : e.length;
                                var t = Wn(e);
                                return t == ai || t == ui ? e.size : ct(e).length
                            }, pe.snakeCase = To, pe.some = function(e, t, n) {
                                var r = Ea(e) ? Al : At;
                                return n && Jn(e, t, n) && (t = Ho), r(e, jn(t, 3))
                            }, pe.sortedIndex = function(e, t) {
                                return kt(e, t)
                            }, pe.sortedIndexBy = function(e, t, n) {
                                return Ot(e, t, jn(n, 2))
                            }, pe.sortedIndexOf = function(e, t) {
                                var n = null == e ? 0 : e.length;
                                if (n) {
                                    var r = kt(e, t);
                                    if (r < n && ya(e[r], t)) return r
                                }
                                return -1
                            }, pe.sortedLastIndex = function(e, t) {
                                return kt(e, t, !0)
                            }, pe.sortedLastIndexBy = function(e, t, n) {
                                return Ot(e, t, jn(n, 2), !0)
                            }, pe.sortedLastIndexOf = function(e, t) {
                                if (null == e ? 0 : e.length) {
                                    var n = kt(e, t, !0) - 1;
                                    if (ya(e[n], t)) return n
                                }
                                return -1
                            }, pe.startCase = _o, pe.startsWith = function(e, t, n) {
                                return e = Ja(e), n = null == n ? 0 : Re($a(n), 0, e.length), t = Mt(t), e.slice(n, n + t.length) == t
                            }, pe.subtract = B, pe.sum = function(e) {
                                return e && e.length ? Bl(e, Oo) : 0
                            }, pe.sumBy = function(e, t) {
                                return e && e.length ? Bl(e, jn(t, 2)) : 0
                            }, pe.template = function(i, e, t) {
                                var n = pe.templateSettings;
                                t && Jn(i, e, t) && (e = Ho), i = Ja(i), e = Xa({}, e, n, Ln);
                                var l, s, r = uo(n = Xa({}, e.imports, n.imports, Ln)),
                                    a = Wl(n, r),
                                    u = 0,
                                    n = e.interpolate || el,
                                    c = "__p += '",
                                    n = p((e.escape || el).source + "|" + n.source + "|" + (n === ki ? $i : el).source + "|" + (e.evaluate || el).source + "|$", "g"),
                                    o = "//# sourceURL=" + (y.call(e, "sourceURL") ? (e.sourceURL + "").replace(/\s/g, " ") : "lodash.templateSources[" + ++ll + "]") + "\n";
                                if (i.replace(n, function(e, t, n, r, a, o) {
                                        return n = n || r, c += i.slice(u, o).replace(tl, Yl), t && (l = !0, c += "' +\n__e(" + t + ") +\n'"), a && (s = !0, c += "';\n" + a + ";\n__p += '"), n && (c += "' +\n((__t = (" + n + ")) == null ? '' : __t) +\n'"), u = o + e.length, e
                                    }), c += "';\n", e = y.call(e, "variable") && e.variable) {
                                    if (Vi.test(e)) throw new d("Invalid `variable` option passed into `_.template`")
                                } else c = "with (obj) {\n" + c + "\n}\n";
                                if (c = (s ? c.replace(wi, "") : c).replace(Ci, "$1").replace(Ti, "$1;"), c = "function(" + (e || "obj") + ") {\n" + (e ? "" : "obj || (obj = {});\n") + "var __t, __p = ''" + (l ? ", __e = _.escape" : "") + (s ? ", __j = Array.prototype.join;\nfunction print() { __p += __j.call(arguments, '') }\n" : ";\n") + c + "return __p\n}", (e = Do(function() {
                                        return f(r, o + "return " + c).apply(Ho, a)
                                    })).source = c, xa(e)) throw e;
                                return e
                            }, pe.times = function(e, t) {
                                if ((e = $a(e)) < 1 || qo < e) return [];
                                var n = Ko,
                                    r = $(e, Ko);
                                for (t = jn(t), e -= Ko, r = Hl(r, t); ++n < e;) t(n);
                                return r
                            }, pe.toFinite = Wa, pe.toInteger = $a, pe.toLength = qa, pe.toLower = function(e) {
                                return Ja(e).toLowerCase()
                            }, pe.toNumber = Za, pe.toSafeInteger = function(e) {
                                return e ? Re($a(e), -qo, qo) : 0 === e ? e : 0
                            }, pe.toString = Ja, pe.toUpper = function(e) {
                                return Ja(e).toUpperCase()
                            }, pe.trim = function(e, t, n) {
                                return (e = Ja(e)) && (n || t === Ho) ? zl(e) : e && (t = Mt(t)) ? (e = as(e), t = as(t), Kt(e, ql(e, t), Zl(e, t) + 1).join("")) : e
                            }, pe.trimEnd = function(e, t, n) {
                                return (e = Ja(e)) && (n || t === Ho) ? e.slice(0, os(e) + 1) : e && (t = Mt(t)) ? Kt(e = as(e), 0, Zl(e, as(t)) + 1).join("") : e
                            }, pe.trimStart = function(e, t, n) {
                                return (e = Ja(e)) && (n || t === Ho) ? e.replace(ji, "") : e && (t = Mt(t)) ? Kt(e = as(e), ql(e, as(t))).join("") : e
                            }, pe.truncate = function(e, t) {
                                var n, r = 30,
                                    a = "...";
                                Aa(t) && (n = "separator" in t ? t.separator : n, r = "length" in t ? $a(t.length) : r, a = "omission" in t ? Mt(t.omission) : a);
                                var o, t = (e = Ja(e)).length;
                                if (Ql(e) && (t = (o = as(e)).length), t <= r) return e;
                                if ((t = r - rs(a)) < 1) return a;
                                if (r = o ? Kt(o, 0, t).join("") : e.slice(0, t), n === Ho) return r + a;
                                if (o && (t += r.length - t), Ma(n)) {
                                    if (e.slice(t).search(n)) {
                                        var i, l = r;
                                        for (n.global || (n = p(n.source, Ja(qi.exec(n)) + "g")), n.lastIndex = 0; i = n.exec(l);) var s = i.index;
                                        r = r.slice(0, s === Ho ? t : s)
                                    }
                                } else e.indexOf(Mt(n), t) == t || -1 < (t = r.lastIndexOf(n)) && (r = r.slice(0, t));
                                return r + a
                            }, pe.unescape = function(e) {
                                return (e = Ja(e)) && Li.test(e) ? e.replace(_i, is) : e
                            }, pe.uniqueId = function(e) {
                                var t = ++s;
                                return Ja(e) + t
                            }, pe.upperCase = xo, pe.upperFirst = Lo, pe.each = Jr, pe.eachRight = Yr, pe.first = wr, Uo(pe, (Bo = {}, Ze(pe, function(e, t) {
                                y.call(pe.prototype, t) || (Bo[t] = e)
                            }), Bo), {
                                chain: !1
                            }), pe.VERSION = "4.17.21", El(["bind", "bindKey", "curry", "curryRight", "partial", "partialRight"], function(e) {
                                pe[e].placeholder = pe
                            }), El(["drop", "take"], function(n, r) {
                                ye.prototype[n] = function(e) {
                                    e = e === Ho ? 1 : W($a(e), 0);
                                    var t = this.__filtered__ && !r ? new ye(this) : this.clone();
                                    return t.__filtered__ ? t.__takeCount__ = $(e, t.__takeCount__) : t.__views__.push({
                                        size: $(e, Ko),
                                        type: n + (t.__dir__ < 0 ? "Right" : "")
                                    }), t
                                }, ye.prototype[n + "Right"] = function(e) {
                                    return this.reverse()[n](e).reverse()
                                }
                            }), El(["filter", "map", "takeWhile"], function(e, t) {
                                var n = t + 1,
                                    r = 1 == n || 3 == n;
                                ye.prototype[e] = function(e) {
                                    var t = this.clone();
                                    return t.__iteratees__.push({
                                        iteratee: jn(e, 3),
                                        type: n
                                    }), t.__filtered__ = t.__filtered__ || r, t
                                }
                            }), El(["head", "last"], function(e, t) {
                                var n = "take" + (t ? "Right" : "");
                                ye.prototype[e] = function() {
                                    return this[n](1).value()[0]
                                }
                            }), El(["initial", "tail"], function(e, t) {
                                var n = "drop" + (t ? "" : "Right");
                                ye.prototype[e] = function() {
                                    return this.__filtered__ ? new ye(this) : this[n](1)
                                }
                            }), ye.prototype.compact = function() {
                                return this.filter(Oo)
                            }, ye.prototype.find = function(e) {
                                return this.filter(e).head()
                            }, ye.prototype.findLast = function(e) {
                                return this.reverse().find(e)
                            }, ye.prototype.invokeMap = wt(function(t, n) {
                                return "function" == typeof t ? new ye(this) : this.map(function(e) {
                                    return at(e, t, n)
                                })
                            }), ye.prototype.reject = function(e) {
                                return this.filter(pa(jn(e)))
                            }, ye.prototype.slice = function(e, t) {
                                e = $a(e);
                                var n = this;
                                return n.__filtered__ && (0 < e || t < 0) ? new ye(n) : (e < 0 ? n = n.takeRight(-e) : e && (n = n.drop(e)), t !== Ho && (n = (t = $a(t)) < 0 ? n.dropRight(-t) : n.take(t - e)), n)
                            }, ye.prototype.takeRightWhile = function(e) {
                                return this.reverse().takeWhile(e).reverse()
                            }, ye.prototype.toArray = function() {
                                return this.take(Ko)
                            }, Ze(ye.prototype, function(u, e) {
                                var c = /^(?:filter|find|map|reject)|While$/.test(e),
                                    d = /^(?:head|last)$/.test(e),
                                    f = pe[d ? "take" + ("last" == e ? "Right" : "") : e],
                                    p = d || /^find/.test(e);
                                f && (pe.prototype[e] = function() {
                                    function e(e) {
                                        return e = f.apply(pe, Ll([e], n)), d && i ? e[0] : e
                                    }
                                    var t = this.__wrapped__,
                                        n = d ? [1] : arguments,
                                        r = t instanceof ye,
                                        a = n[0],
                                        o = r || Ea(t);
                                    o && c && "function" == typeof a && 1 != a.length && (r = o = !1);
                                    var i = this.__chain__,
                                        l = !!this.__actions__.length,
                                        a = p && !i,
                                        l = r && !l;
                                    if (p || !o) return a && l ? u.apply(this, n) : (s = this.thru(e), a ? d ? s.value()[0] : s.value() : s);
                                    t = l ? t : new ye(this);
                                    var s = u.apply(t, n);
                                    return s.__actions__.push({
                                        func: Wr,
                                        args: [e],
                                        thisArg: Ho
                                    }), new ge(s, i)
                                })
                            }), El(["pop", "push", "shift", "sort", "splice", "unshift"], function(e) {
                                var n = o[e],
                                    r = /^(?:push|sort|unshift)$/.test(e) ? "tap" : "thru",
                                    a = /^(?:pop|shift)$/.test(e);
                                pe.prototype[e] = function() {
                                    var t = arguments;
                                    if (!a || this.__chain__) return this[r](function(e) {
                                        return n.apply(Ea(e) ? e : [], t)
                                    });
                                    var e = this.value();
                                    return n.apply(Ea(e) ? e : [], t)
                                }
                            }), Ze(ye.prototype, function(e, t) {
                                var n, r = pe[t];
                                r && (n = r.name + "", y.call(ae, n) || (ae[n] = []), ae[n].push({
                                    name: t,
                                    func: r
                                }))
                            }), ae[hn(Ho, 2).name] = [{
                                name: "wrapper",
                                func: Ho
                            }], ye.prototype.clone = function() {
                                var e = new ye(this.__wrapped__);
                                return e.__actions__ = rn(this.__actions__), e.__dir__ = this.__dir__, e.__filtered__ = this.__filtered__, e.__iteratees__ = rn(this.__iteratees__), e.__takeCount__ = this.__takeCount__, e.__views__ = rn(this.__views__), e
                            }, ye.prototype.reverse = function() {
                                var e;
                                return this.__filtered__ ? ((e = new ye(this)).__dir__ = -1, e.__filtered__ = !0) : (e = this.clone()).__dir__ *= -1, e
                            }, ye.prototype.value = function() {
                                var e = this.__wrapped__.value(),
                                    t = this.__dir__,
                                    n = Ea(e),
                                    r = t < 0,
                                    a = n ? e.length : 0,
                                    o = function(e, t, n) {
                                        var r = -1,
                                            a = n.length;
                                        for (; ++r < a;) {
                                            var o = n[r],
                                                i = o.size;
                                            switch (o.type) {
                                                case "drop":
                                                    e += i;
                                                    break;
                                                case "dropRight":
                                                    t -= i;
                                                    break;
                                                case "take":
                                                    t = $(t, e + i);
                                                    break;
                                                case "takeRight":
                                                    e = W(e, t - i)
                                            }
                                        }
                                        return {
                                            start: e,
                                            end: t
                                        }
                                    }(0, a, this.__views__),
                                    i = o.start,
                                    l = (o = o.end) - i,
                                    s = r ? o : i - 1,
                                    u = this.__iteratees__,
                                    c = u.length,
                                    d = 0,
                                    f = $(l, this.__takeCount__);
                                if (!n || !r && a == l && f == l) return Ht(e, this.__actions__);
                                var p = [];
                                e: for (; l-- && d < f;) {
                                    for (var m = -1, v = e[s += t]; ++m < c;) {
                                        var h = u[m],
                                            g = h.iteratee,
                                            h = h.type,
                                            g = g(v);
                                        if (2 == h) v = g;
                                        else if (!g) {
                                            if (1 == h) continue e;
                                            break e
                                        }
                                    }
                                    p[d++] = v
                                }
                                return p
                            }, pe.prototype.at = $r, pe.prototype.chain = function() {
                                return Vr(this)
                            }, pe.prototype.commit = function() {
                                return new ge(this.value(), this.__chain__)
                            }, pe.prototype.next = function() {
                                this.__values__ === Ho && (this.__values__ = Va(this.value()));
                                var e = this.__index__ >= this.__values__.length;
                                return {
                                    done: e,
                                    value: e ? Ho : this.__values__[this.__index__++]
                                }
                            }, pe.prototype.plant = function(e) {
                                for (var t, n = this; n instanceof he;) {
                                    var r = gr(n);
                                    r.__index__ = 0, r.__values__ = Ho, t ? a.__wrapped__ = r : t = r;
                                    var a = r,
                                        n = n.__wrapped__
                                }
                                return a.__wrapped__ = e, t
                            }, pe.prototype.reverse = function() {
                                var e = this.__wrapped__;
                                if (e instanceof ye) {
                                    e = e;
                                    return this.__actions__.length && (e = new ye(this)), (e = e.reverse()).__actions__.push({
                                        func: Wr,
                                        args: [Ar],
                                        thisArg: Ho
                                    }), new ge(e, this.__chain__)
                                }
                                return this.thru(Ar)
                            }, pe.prototype.toJSON = pe.prototype.valueOf = pe.prototype.value = function() {
                                return Ht(this.__wrapped__, this.__actions__)
                            }, pe.prototype.first = pe.prototype.head, A && (pe.prototype[A] = function() {
                                return this
                            }), pe
                        }();
                        fl._ = ls, (k = function() {
                            return ls
                        }.call(D, A, D, N)) === Ho || (N.exports = k)
                    }.call(this)
            },
            292: function(e) {
                "use strict";
                e.exports = CoreRobloxUtilities
            },
            4720: function(e) {
                "use strict";
                e.exports = CoreUtilities
            },
            792: function(e) {
                "use strict";
                e.exports = Roblox
            },
            9589: function(e) {
                "use strict";
                e.exports = RobloxBadges
            },
            5734: function(e) {
                "use strict";
                e.exports = angular
            }
        },
        r = {};

    function Ua(e) {
        if (r[e]) return r[e].exports;
        var t = r[e] = {
            id: e,
            loaded: !1,
            exports: {}
        };
        return n[e].call(t.exports, t, t.exports, Ua), t.loaded = !0, t.exports
    }
    Ua.n = function(e) {
            var t = e && e.__esModule ? function() {
                return e.default
            } : function() {
                return e
            };
            return Ua.d(t, {
                a: t
            }), t
        }, Ua.d = function(e, t) {
            for (var n in t) Ua.o(t, n) && !Ua.o(e, n) && Object.defineProperty(e, n, {
                enumerable: !0,
                get: t[n]
            })
        }, Ua.g = function() {
            if ("object" == typeof globalThis) return globalThis;
            try {
                return this || new Function("return this")()
            } catch (e) {
                if ("object" == typeof window) return window
            }
        }(), Ua.o = function(e, t) {
            return Object.prototype.hasOwnProperty.call(e, t)
        }, Ua.r = function(e) {
            "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
                value: "Module"
            }), Object.defineProperty(e, "__esModule", {
                value: !0
            })
        }, Ua.nmd = function(e) {
            return e.paths = [], e.children || (e.children = []), e
        },
        function() {
            "use strict";
            var P, E, F, B, H, z, V = React,
                W = Ua.n(V),
                e = ReactDOM,
                C = Ua(4720),
                f = ReactUtilities,
                S = Ua(292),
                w = window.EventTracker ? EventTracker : {
                    fireEvent: console.log,
                    start: console.log,
                    endSuccess: console.log,
                    endCancel: console.log,
                    endFailure: console.log
                },
                h = Ua(792),
                r = h.EnvironmentUrls.apiGatewayUrl,
                i = {
                    getExperimentationValues: function(e, t, n) {
                        return {
                            url: r + "/product-experimentation-platform/v1/projects/" + e + "/layers/" + t + "/values?parameters=" + n.join(","),
                            withCredentials: !0
                        }
                    }
                },
                t = {
                    homePage: {},
                    homePageWeb: {
                        IsExpandHomeContentEnabled: !0,
                        IsReactFriendsCarouselEnabled: !1
                    },
                    serverTab: {
                        ShouldDisableJoinButtonForFullServers: !1
                    },
                    gameDetails: {
                        ShouldHidePrivateServersInAboutTab: !1,
                        IsGameStorePreviewEnabled: !1,
                        IsEventsSectionUprankEnabled: !1,
                        IsEventsSectionRedesignEnabled: !1
                    },
                    gameDetailsExposure: {
                        IsShowContainsStrongLanguageWarningEnabled: !1
                    },
                    searchPage: {
                        ShouldUseOmniSearchAPI: !1
                    },
                    discoverPage: {
                        IsChartsPageRenameEnabled: !0
                    },
                    tileLayer: {
                        IsHigherResolutionImageEnabled: !1
                    }
                },
                n = {
                    homePage: "PlayerApp.HomePage.UX",
                    homePageWeb: "Website.Homepage",
                    serverTab: "GameDetails.ServersTab",
                    gameDetails: "Website.GameDetails",
                    gameDetailsExposure: "PlayerApp.GameDetailsPage.Exposure",
                    searchPage: "Website.SearchResultsPage",
                    discoverPage: "Website.GamesPage",
                    tileLayer: "Website.TileLayer"
                },
                a = h.EnvironmentUrls.apiGatewayUrl,
                s = {
                    url: {
                        getOmniRecommendations: {
                            url: a + "/discovery-api/omni-recommendation",
                            withCredentials: !0
                        },
                        getOmniRecommendationsMetadata: {
                            url: a + "/discovery-api/omni-recommendation-metadata",
                            withCredentials: !0
                        },
                        getOmniSearch: {
                            url: a + "/search-api/omni-search",
                            withCredentials: !0
                        },
                        getExploreSorts: {
                            url: a + "/explore-api/v1/get-sorts",
                            withCredentials: !0
                        },
                        getExploreSortContents: {
                            url: a + "/explore-api/v1/get-sort-content",
                            withCredentials: !0
                        },
                        getSurvey: function(e) {
                            return {
                                url: a + "/rocap/v1/locations/" + e + "/prompts",
                                withCredentials: !0
                            }
                        },
                        postSurveyResults: function(e) {
                            return {
                                url: a + "/rocap/v1/locations/" + e + "/annotations",
                                withCredentials: !0
                            }
                        }
                    }
                };
            (ve = P = P || {}).Game = "Game", ve.CatalogAsset = "CatalogAsset", ve.CatalogBundle = "CatalogBundle", (tr = E = E || {}).Carousel = "Carousel", tr.AvatarCarousel = "AvatarCarousel", tr.SortlessGrid = "SortlessGrid", tr.FriendCarousel = "FriendCarousel", tr.InterestGrid = "InterestGrid", tr.Pills = "Pills", (Ge = {}).Sponsored = "Sponsored", Ge.SponsoredGame = "SponsoredGame", (je = F = F || {}).AppGameTileNoMetadata = "AppGameTileNoMetadata", je.GridTile = "GridTile", je.EventTile = "EventTile", je.InterestTile = "InterestTile", je.ExperienceEventsTile = "ExperienceEventsTile", (te = B = B || {}).Always = "Always", te.Hover = "Hover", te.Footer = "Footer", (ae = H = H || {}).Disabled = "Disabled", ae.Enabled = "Enabled", (z = z || {}).imageOverlay = "imageOverlay";
            var o, l = "robloxAttributionIds";

            function u(e) {
                var t = window,
                    n = t[l];
                return n || (n = {}, t[l] = n), (t = n[e]) || (t = C.uuidService.generateRandomUuid(), n[e] = t), t
            }

            function c() {
                return document.getElementById("place-list")
            }(o = o || {}).GameDetailReferral = "gameDetailReferral";
            var T, d = function(e) {
                    return "discover#/sortName/" + e
                },
                p = function(e) {
                    return "discover#/sortName/v2/" + e
                },
                m = function(e) {
                    return "charts#/sortName/" + e
                };

            function v(e, t, n) {
                return void 0 === n && (n = {}), C.urlService.getUrlWithQueries(S.entityUrl.game.getRelativePath(e) + "/" + C.seoName.formatSeoName(t), n)
            }

            function _(e, t, n, r, a) {
                return void 0 === n && (n = {}), void 0 === r && (r = !1), void 0 === a && (a = {}), r = function(e, t, n) {
                    var r = encodeURIComponent(e);
                    switch (t) {
                        case T.HomePage:
                            return p(r);
                        case T.GamesPage:
                            return (n ? m : d)(r);
                        default:
                            return p(r)
                    }
                }(e, t, r), C.urlService.getUrlWithQueries(r, D(D({}, n), a))
            }

            function g() {
                return document.referrer
            }(ve = T = T || {}).SearchPage = "searchPage", ve.SortDetailPageDiscover = "sortDetailPageDiscover", ve.SortDetailPageHome = "sortDetailPageHome", ve.GameDetailPage = "gameDetailPage", ve.GamesPage = "gamesPage", ve.HomePage = "homePage", ve.PeopleListInHomePage = "peopleListInHomePage", ve.InterestCatcher = "interestCatcher";
            var x, y, L, b, I, N, D = function() {
                    return (D = Object.assign || function(e) {
                        for (var t, n = 1, r = arguments.length; n < r; n++)
                            for (var a in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
                        return e
                    }).apply(this, arguments)
                },
                q = v,
                A = function() {
                    return (A = Object.assign || function(e) {
                        for (var t, n = 1, r = arguments.length; n < r; n++)
                            for (var a in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
                        return e
                    }).apply(this, arguments)
                },
                k = function(e, t) {
                    var n = {};
                    for (a in e) Object.prototype.hasOwnProperty.call(e, a) && t.indexOf(a) < 0 && (n[a] = e[a]);
                    if (null != e && "function" == typeof Object.getOwnPropertySymbols)
                        for (var r = 0, a = Object.getOwnPropertySymbols(e); r < a.length; r++) t.indexOf(a[r]) < 0 && Object.prototype.propertyIsEnumerable.call(e, a[r]) && (n[a[r]] = e[a[r]]);
                    return n
                },
                O = (tr = S.eventStreamService.eventTypes).pageLoad,
                R = tr.formInteraction;

            function Z(e, n) {
                return e.filter(function(e) {
                    var t;
                    return (null === (t = e.presence) || void 0 === t ? void 0 : t.universeId) === n && (null === (e = e.presence) || void 0 === e ? void 0 : e.userPresenceType) === h.Presence.PresenceTypes.InGame
                })
            }

            function U(e, t) {
                var n = 0;
                if (!Number.isNaN(e) && !Number.isNaN(t)) {
                    if (0 === e && 0 === t) return;
                    n = 0 === e && 0 !== t ? 0 : 0 !== e && 0 === t || 100 < (n = Math.floor(e / (e + t) * 100)) ? 100 : n
                }
                return n
            }

            function M(t, e) {
                var n;
                return e.some(function(e) {
                    return null === (e = t[e]) || void 0 === e ? void 0 : e.isSponsored
                }) ? ((n = {})[x.AdsPositions] = e.map(function(e) {
                    return t[e].isSponsored ? 1 : 0
                }), n[x.AdFlags] = e.map(function(e) {
                    return t[e].isSponsored ? 1 : 0
                }), n[x.AdIds] = e.map(function(e) {
                    return (null === (e = t[e]) || void 0 === e ? void 0 : e.nativeAdData) || "0"
                }), n) : {}
            }

            function G(e, t) {
                function n(e) {
                    return (e = null === (e = null == e ? void 0 : e.primaryMediaAsset) || void 0 === e ? void 0 : e.wideImageAssetId) && "0" !== e ? parseInt(e, 10) : null
                }
                var r;
                return e.layoutDataBySort && t && e.layoutDataBySort[t] ? r = n(e.layoutDataBySort[t]) : e.defaultLayoutData && (r = n(e.defaultLayoutData)), r || n(e)
            }

            function j(r, a, e, t) {
                return t === F.GridTile || t === F.EventTile || t === F.InterestTile ? ((t = {})[x.ThumbnailAssetIds] = e.map(function(e) {
                    return null !== (e = G(r[e], a.toString())) && void 0 !== e ? e : "0"
                }), t[x.ThumbnailListIds] = e.map(function(e) {
                    var t, n;
                    return null !== (t = r[e], e = a.toString(), t = t.layoutDataBySort && e && t.layoutDataBySort[e] ? null === (n = t.layoutDataBySort[e].primaryMediaAsset) || void 0 === n ? void 0 : n.wideImageListId : t.defaultLayoutData ? null === (n = t.defaultLayoutData.primaryMediaAsset) || void 0 === n ? void 0 : n.wideImageListId : null === (t = t.primaryMediaAsset) || void 0 === t ? void 0 : t.wideImageListId) && void 0 !== t ? t : "0"
                }), t) : {}
            }

            function K(e) {
                var t = e.tileBadgesByPosition,
                    e = [];
                if (t) return !t.ImageTopLeft || (t = t.ImageTopLeft.map(function(e) {
                    return e.analyticsId
                })) && 0 < t.length && e.push("ImageTopLeft=" + t.join("+")), 0 < e.length ? e.join("&") : void 0
            }

            function J(r, a, e, t) {
                return t === F.GridTile || t === F.EventTile || t === F.InterestTile ? ((t = {})[x.TileBadgeContexts] = e.map(function(e) {
                    var t, n;
                    return null !== (t = r[e], e = a.toString(), t.layoutDataBySort && e && t.layoutDataBySort[e] ? n = K(t.layoutDataBySort[e]) : t.defaultLayoutData && (n = K(t.defaultLayoutData)), n) && void 0 !== n ? n : "0"
                }), t) : {}
            }

            function Y(n, r, e, t) {
                if (void 0 === n || void 0 === r || void 0 === e) return {};
                var a = [],
                    o = [];
                return t.forEach(function(e) {
                    var t = n + Math.floor(e / r),
                        e = e % r;
                    a.push(t), o.push(e)
                }), (t = {})[x.RowsOnPage] = a, t[x.PositionsInRow] = o, t
            }

            function Q(e) {
                return void 0 !== e ? {
                    inputUniverseIds: {
                        interestCatcher: e.map(function(e) {
                            return e.toString()
                        })
                    }
                } : {}
            }

            function X(t) {
                return ce(void 0, void 0, Promise, function() {
                    return de(this, function(e) {
                        return [2, C.httpService.get({
                            url: h.EnvironmentUrls.thumbnailsApi + "/v1/assets",
                            timeout: 1e4,
                            withCredentials: !0
                        }, {
                            assetIds: [t],
                            size: "768x432",
                            format: "Png"
                        }).then(function(e) {
                            var t, n;
                            return "Completed" === (null === (t = null === (t = e.data.data) || void 0 === t ? void 0 : t[0]) || void 0 === t ? void 0 : t.state) && null !== (n = null === (n = e.data.data) || void 0 === n ? void 0 : n[0]) && void 0 !== n && n.imageUrl ? e.data.data[0].imageUrl : Promise.reject()
                        })]
                    })
                })
            }(Ge = x = x || {}).AbsPositions = "absPositions", Ge.AdsPositions = "adsPositions", Ge.AdFlags = "adFlags", Ge.Algorithm = "algorithm", Ge.AppliedFilters = "appliedFilters", Ge.AttributionId = "attributionId", Ge.Direction = "direction", Ge.Distance = "distance", Ge.HttpReferrer = "httpReferrer", Ge.EmphasisFlag = "emphasisFlag", Ge.FilterId = "filterId", Ge.FilterIds = "filterIds", Ge.GameSetTargetId = "gameSetTargetId", Ge.GameSetTypeId = "gameSetTypeId", Ge.InteractionType = "interactionType", Ge.IsAd = "isAd", Ge.NativeAdData = "nativeAdData", Ge.AdIds = "adIds", Ge.NumberOfLoadedTiles = "numberOfLoadedTiles", Ge.Page = "page", Ge.PageSession = "pageSession", Ge.PlaceId = "placeId", Ge.PlayContext = "playContext", Ge.Position = "position", Ge.PreviousOptionId = "previousOptionId", Ge.PromptId = "promptId", Ge.PromptText = "promptText", Ge.ResourceId = "resourceId", Ge.ResponseOptionIds = "responseOptionIds", Ge.ResponseOptionTexts = "responseOptionTexts", Ge.RootPlaceIds = "rootPlaceIds", Ge.SelectedIds = "selectedIds", Ge.SelectedTexts = "selectedTexts", Ge.ScreenSizeX = "screenSizeX", Ge.ScreenSizeY = "screenSizeY", Ge.ScrollAreaSize = "scrollAreaSize", Ge.ScrollDepth = "scrollDepth", Ge.SelectedOptionId = "selectedOptionId", Ge.SelectedOptionIds = "selectedOptionIds", Ge.SortId = "sortId", Ge.SortPos = "sortPos", Ge.StartDepth = "startDepth", Ge.StartPos = "startPos", Ge.SuggestionKwd = "suggestionKwd", Ge.SuggestionReplacedKwd = "suggestionReplacedKwd", Ge.SuggestionCorrectedKwd = "suggestionCorrectedKwd", Ge.SuggestionAlgorithm = "suggestionAlgorithm", Ge.TimeToRespond = "timeToRespond", Ge.Token = "token", Ge.Topics = "topics", Ge.TreatmentType = "treatmentType", Ge.UniverseId = "universeId", Ge.UniverseIds = "universeIds", Ge.FriendId = "friendId", Ge.ThumbnailAssetIds = "thumbnailAssetIds", Ge.ThumbnailListIds = "thumbnailListIds", Ge.LinkPath = "linkPath", Ge.LocationName = "locationName", Ge.RowsOnPage = "rowsOnPage", Ge.PositionsInRow = "positionsInRow", Ge.NavigationUids = "navigationUids", Ge.TileBadgeContexts = "tileBadgeContexts", Ge.ButtonName = "buttonName", Ge.IsInterested = "isInterested", Ge.InterestedUniverseIds = "interestedUniverseIds", (je = y = y || {}).GameImpressions = "gameImpressions", je.GameDetailReferral = "gameDetailReferral", je.SortDetailReferral = "sortDetailReferral", je.FeedScroll = "feedScroll", je.NavigateToSortLink = "navigateToSortLink", je.SurveyInteraction = "surveyInteraction", je.SurveyImpression = "surveyImpression", je.InterestCatcherClick = "interestCatcherClick", je.FilterImpressions = "filterImpressions", je.GamesFilterClick = "gamesFilterClick", (te = L = L || {}).HomePageSessionInfo = "homePageSessionInfo", te.GameSearchSessionInfo = "gameSearchSessionInfo", te.DiscoverPageSessionInfo = "discoverPageSessionInfo", (ae = {}).Submission = "submission", ae.Cancellation = "cancellation", (ve = b = b || {}).Horizontal = "horizontal", ve.Vertical = "vertical", (tr = I = I || {}).Skip = "skip", tr.Continue = "continue", tr.Interested = "interested", (Ge = N = N || {}).OpenDropdown = "openDropdown", Ge.CloseDropdown = "closeDropdown", Ge.Apply = "apply";
            var ee = ((je = {})[y.GameImpressions] = function(e) {
                    e = k(e, []);
                    return [{
                        name: y.GameImpressions,
                        type: y.GameImpressions,
                        context: R
                    }, ne(A({}, e))]
                }, je[y.GameDetailReferral] = function(e) {
                    var t;
                    return void 0 === e && (e = {}), [{
                        name: y.GameDetailReferral,
                        type: y.GameDetailReferral,
                        context: O
                    }, ne(A(((t = {})[x.AttributionId] = u(o.GameDetailReferral), t[x.HttpReferrer] = g(), t), e))]
                }, je[y.SortDetailReferral] = function(e) {
                    return void 0 === e && (e = {}), [{
                        name: y.SortDetailReferral,
                        type: y.SortDetailReferral,
                        context: O
                    }, ne(A({}, e))]
                }, je[y.NavigateToSortLink] = function(e) {
                    return void 0 === e && (e = {}), [{
                        name: y.NavigateToSortLink,
                        type: y.NavigateToSortLink,
                        context: R
                    }, ne(A({}, e))]
                }, je[y.SurveyInteraction] = function(e) {
                    return void 0 === e && (e = {}), [{
                        name: y.SurveyInteraction,
                        type: y.SurveyInteraction,
                        context: R
                    }, ne(A({}, e))]
                }, je[y.SurveyImpression] = function(e) {
                    return void 0 === e && (e = {}), [{
                        name: y.SurveyImpression,
                        type: y.SurveyImpression,
                        context: R
                    }, ne(A({}, e))]
                }, je[y.InterestCatcherClick] = function(e) {
                    return void 0 === e && (e = {}), [{
                        name: y.InterestCatcherClick,
                        type: y.InterestCatcherClick,
                        context: R
                    }, ne(A({}, e))]
                }, je[y.FilterImpressions] = function(e) {
                    return void 0 === e && (e = {}), [{
                        name: y.FilterImpressions,
                        type: y.FilterImpressions,
                        context: R
                    }, ne(A({}, e))]
                }, je[y.GamesFilterClick] = function(e) {
                    return void 0 === e && (e = {}), [{
                        name: y.GamesFilterClick,
                        type: y.GamesFilterClick,
                        context: R
                    }, ne(A({}, e))]
                }, je),
                te = (new h.Intl).getDateTimeFormatter(),
                ne = function(n) {
                    return Object.keys(n).reduce(function(e, t) {
                        return "object" == typeof n[t] && n[t] && (e[t] = JSON.stringify(n[t])), "number" == typeof n[t] && (e[t] = n[t]), "string" == typeof n[t] && (e[t] = encodeURIComponent(n[t])), "boolean" == typeof n[t] && (e[t] = n[t] ? 1 : 0), e
                    }, {})
                },
                re = C.urlService.parseQueryString,
                ae = C.numberFormat.getNumberFormat,
                oe = U,
                ie = function(e, t) {
                    t = U(e, t);
                    return void 0 !== t ? t + "%" : void 0
                },
                le = function(e) {
                    return -1 === e ? "--" : C.abbreviateNumber.getAbbreviatedValue(e)
                },
                se = function(n, r) {
                    if (0 === n.length || 0 === r) return [n];
                    var e = Math.ceil(n.length / r);
                    return new Array(e).fill(0).map(function(e, t) {
                        return n.slice(t * r, (t + 1) * r)
                    })
                },
                ue = function() {
                    return (ue = Object.assign || function(e) {
                        for (var t, n = 1, r = arguments.length; n < r; n++)
                            for (var a in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
                        return e
                    }).apply(this, arguments)
                },
                ce = function(e, i, l, s) {
                    return new(l = l || Promise)(function(n, t) {
                        function r(e) {
                            try {
                                o(s.next(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function a(e) {
                            try {
                                o(s.throw(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function o(e) {
                            var t;
                            e.done ? n(e.value) : ((t = e.value) instanceof l ? t : new l(function(e) {
                                e(t)
                            })).then(r, a)
                        }
                        o((s = s.apply(e, i || [])).next())
                    })
                },
                de = function(n, r) {
                    var a, o, i, l = {
                            label: 0,
                            sent: function() {
                                if (1 & i[0]) throw i[1];
                                return i[1]
                            },
                            trys: [],
                            ops: []
                        },
                        e = {
                            next: t(0),
                            throw: t(1),
                            return: t(2)
                        };
                    return "function" == typeof Symbol && (e[Symbol.iterator] = function() {
                        return this
                    }), e;

                    function t(t) {
                        return function(e) {
                            return function(t) {
                                if (a) throw new TypeError("Generator is already executing.");
                                for (; l;) try {
                                    if (a = 1, o && (i = 2 & t[0] ? o.return : t[0] ? o.throw || ((i = o.return) && i.call(o), 0) : o.next) && !(i = i.call(o, t[1])).done) return i;
                                    switch (o = 0, i && (t = [2 & t[0], i.value]), t[0]) {
                                        case 0:
                                        case 1:
                                            i = t;
                                            break;
                                        case 4:
                                            return l.label++, {
                                                value: t[1],
                                                done: !1
                                            };
                                        case 5:
                                            l.label++, o = t[1], t = [0];
                                            continue;
                                        case 7:
                                            t = l.ops.pop(), l.trys.pop();
                                            continue;
                                        default:
                                            if (!(i = 0 < (i = l.trys).length && i[i.length - 1]) && (6 === t[0] || 2 === t[0])) {
                                                l = 0;
                                                continue
                                            }
                                            if (3 === t[0] && (!i || t[1] > i[0] && t[1] < i[3])) {
                                                l.label = t[1];
                                                break
                                            }
                                            if (6 === t[0] && l.label < i[1]) {
                                                l.label = i[1], i = t;
                                                break
                                            }
                                            if (i && l.label < i[2]) {
                                                l.label = i[2], l.ops.push(t);
                                                break
                                            }
                                            i[2] && l.ops.pop(), l.trys.pop();
                                            continue
                                    }
                                    t = r.call(n, l)
                                } catch (e) {
                                    t = [6, e], o = 0
                                } finally {
                                    a = i = 0
                                }
                                if (5 & t[0]) throw t[1];
                                return {
                                    value: t[0] ? t[1] : void 0,
                                    done: !0
                                }
                            }([t, e])
                        }
                    }
                },
                fe = function(r, a, o) {
                    return void 0 === o && (o = 1), ce(void 0, void 0, Promise, function() {
                        var n, t;
                        return de(this, function(e) {
                            switch (e.label) {
                                case 0:
                                    return e.trys.push([0, 2, , 3]), [4, C.httpService.get(i.getExperimentationValues(o, r, Object.keys(a)))];
                                case 1:
                                    return n = e.sent().data, t = Object.keys(n).reduce(function(e, t) {
                                        return null !== n[t] && (e[t] = n[t]), e
                                    }, {}), [2, ue(ue({}, a), t)];
                                case 2:
                                    return e.sent(), [2, a];
                                case 3:
                                    return [2]
                            }
                        })
                    })
                },
                pe = function(r, a, o, i, l) {
                    return ce(void 0, void 0, Promise, function() {
                        var t, n;
                        return de(this, function(e) {
                            switch (e.label) {
                                case 0:
                                    return t = ue(ue({
                                        pageType: r,
                                        sessionId: a,
                                        supportedTreatmentTypes: [E.SortlessGrid],
                                        authIntentData: i
                                    }, o), Q(l)), [4, C.httpService.post(s.url.getOmniRecommendations, t)];
                                case 1:
                                    return n = e.sent().data, Object.keys(n.contentMetadata.Game).forEach(function(e) {
                                        e = n.contentMetadata.Game[e];
                                        e.placeId = e.rootPlaceId
                                    }), [2, n]
                            }
                        })
                    })
                },
                me = function(n, r) {
                    return ce(void 0, void 0, Promise, function() {
                        var t;
                        return de(this, function(e) {
                            switch (e.label) {
                                case 0:
                                    return [4, C.httpService.post(s.url.getOmniRecommendationsMetadata, {
                                        contents: n,
                                        sessionId: r
                                    })];
                                case 1:
                                    return t = e.sent().data, Object.keys(t.contentMetadata.Game).forEach(function(e) {
                                        e = t.contentMetadata.Game[e];
                                        e.placeId = e.rootPlaceId
                                    }), [2, t]
                            }
                        })
                    })
                },
                ve = Ua(2779),
                he = Ua.n(ve),
                ge = ReactStyleGuide,
                ye = ge.Button.variants;
            (tr = function(e) {
                var t = e.errorMessage,
                    n = e.onRefresh,
                    e = e.className;
                return W().createElement("div", {
                    "data-testid": "error-status",
                    className: he()("game-error", e)
                }, W().createElement("span", {
                    className: "icon-spot-error-2xl"
                }), W().createElement("p", {
                    className: "text-label error-text"
                }, t), W().createElement(ge.Button, {
                    className: "refresh-button",
                    variant: ye.control,
                    onClick: n
                }, W().createElement("span", {
                    className: "icon-common-refresh"
                })))
            }).defaultProps = {
                className: ""
            };
            var be = tr,
                Ie = HeaderScripts,
                Pe = h.EnvironmentUrls.gamesApi,
                Ee = {
                    url: {
                        getOmniRecommendations: function(e, t) {
                            return {
                                url: Pe + "/v1/games/omni-recommendations?model.pageType=" + e + (void 0 !== t ? "&model.sessionId=" + t : ""),
                                withCredentials: !0
                            }
                        },
                        getOmniRecommendationsMetadata: {
                            url: Pe + "/v1/games/omni-recommendations-metadata",
                            withCredentials: !0
                        },
                        getGameList: {
                            url: Pe + "/v1/games/list",
                            withCredentials: !0
                        },
                        getGamePasses: function(e, t) {
                            return {
                                url: Pe + "/v1/games/" + e + "/game-passes?limit=" + t,
                                withCredentials: !0
                            }
                        },
                        getGameRecommendations: function(e) {
                            return {
                                url: Pe + "/v1/games/recommendations/game/" + e,
                                withCredentials: !0
                            }
                        },
                        getGameSorts: {
                            url: Pe + "/v1/games/sorts",
                            withCredentials: !0
                        },
                        getUniverseVoiceStatus: function(e) {
                            return {
                                withCredentials: !0,
                                url: h.EnvironmentUrls.voiceApi + "/v1/settings/universe/" + e
                            }
                        },
                        getVoiceOptInStatus: {
                            withCredentials: !0,
                            url: h.EnvironmentUrls.voiceApi + "/v1/settings/user-opt-in"
                        }
                    },
                    defaultCacheCriteria: {
                        refreshCache: !1,
                        expirationWindowMS: 3e4,
                        useCache: !0
                    }
                },
                Se = function(e, i, l, s) {
                    return new(l = l || Promise)(function(n, t) {
                        function r(e) {
                            try {
                                o(s.next(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function a(e) {
                            try {
                                o(s.throw(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function o(e) {
                            var t;
                            e.done ? n(e.value) : ((t = e.value) instanceof l ? t : new l(function(e) {
                                e(t)
                            })).then(r, a)
                        }
                        o((s = s.apply(e, i || [])).next())
                    })
                },
                we = function(n, r) {
                    var a, o, i, l = {
                            label: 0,
                            sent: function() {
                                if (1 & i[0]) throw i[1];
                                return i[1]
                            },
                            trys: [],
                            ops: []
                        },
                        e = {
                            next: t(0),
                            throw: t(1),
                            return: t(2)
                        };
                    return "function" == typeof Symbol && (e[Symbol.iterator] = function() {
                        return this
                    }), e;

                    function t(t) {
                        return function(e) {
                            return function(t) {
                                if (a) throw new TypeError("Generator is already executing.");
                                for (; l;) try {
                                    if (a = 1, o && (i = 2 & t[0] ? o.return : t[0] ? o.throw || ((i = o.return) && i.call(o), 0) : o.next) && !(i = i.call(o, t[1])).done) return i;
                                    switch (o = 0, i && (t = [2 & t[0], i.value]), t[0]) {
                                        case 0:
                                        case 1:
                                            i = t;
                                            break;
                                        case 4:
                                            return l.label++, {
                                                value: t[1],
                                                done: !1
                                            };
                                        case 5:
                                            l.label++, o = t[1], t = [0];
                                            continue;
                                        case 7:
                                            t = l.ops.pop(), l.trys.pop();
                                            continue;
                                        default:
                                            if (!(i = 0 < (i = l.trys).length && i[i.length - 1]) && (6 === t[0] || 2 === t[0])) {
                                                l = 0;
                                                continue
                                            }
                                            if (3 === t[0] && (!i || t[1] > i[0] && t[1] < i[3])) {
                                                l.label = t[1];
                                                break
                                            }
                                            if (6 === t[0] && l.label < i[1]) {
                                                l.label = i[1], i = t;
                                                break
                                            }
                                            if (i && l.label < i[2]) {
                                                l.label = i[2], l.ops.push(t);
                                                break
                                            }
                                            i[2] && l.ops.pop(), l.trys.pop();
                                            continue
                                    }
                                    t = r.call(n, l)
                                } catch (e) {
                                    t = [6, e], o = 0
                                } finally {
                                    a = i = 0
                                }
                                if (5 & t[0]) throw t[1];
                                return {
                                    value: t[0] ? t[1] : void 0,
                                    done: !0
                                }
                            }([t, e])
                        }
                    }
                },
                Ce = Ee.defaultCacheCriteria,
                Te = S.dataStores.gamesDataStore,
                _e = S.dataStores.userDataStoreV2,
                xe = (S.dataStores.localeDataStore, S.dataStores.userDataStore.FriendsUserSortType),
                Le = function() {
                    return _e.getFriends({
                        userId: null === Ie.authenticatedUser || void 0 === Ie.authenticatedUser ? void 0 : Ie.authenticatedUser.id,
                        userSort: xe.StatusFrequents,
                        isGuest: !1
                    }, Ce)
                },
                Ne = function(t) {
                    return Se(void 0, void 0, Promise, function() {
                        return we(this, function(e) {
                            switch (e.label) {
                                case 0:
                                    return [4, Te.getGameDetails([t])];
                                case 1:
                                    return [2, e.sent().data.data[0]]
                            }
                        })
                    })
                },
                De = function(n) {
                    return Se(void 0, void 0, Promise, function() {
                        var t;
                        return we(this, function(e) {
                            switch (e.label) {
                                case 0:
                                    return [4, Te.getPlaceDetails([n])];
                                case 1:
                                    return t = e.sent().data, [2, (void 0 === t ? [] : t)[0]]
                            }
                        })
                    })
                },
                Ae = RobloxThumbnails,
                ke = {
                    maxTilesPerCarouselPage: 6,
                    maxWideGameTilesPerCarouselPage: 4,
                    minWideGameTilesPerCarouselPage: 2,
                    gameTileWidth: 150,
                    homeFeedMaxWidth: 970,
                    wideGameTileTilesPerRowBreakpointWidth: 738,
                    sortlessGridMaxTilesMetadataToFetch: 300,
                    adSortHomePageId: 4e8,
                    topicIdsWithoutSeeAll: [5e8, 500000001],
                    friendsCarouselAngularBootstrapErrorEvent: "HomePageFriendsCarouselBootstrapError",
                    missingNumberOfRowsForLoggingErrorEvent: "HomePageMissingNumberOfRowsForLoggingError",
                    omniRecommendationEndpointErrorEvent: "HomePageOmniRecommendationEndpointError",
                    omniRecommendationEndpointSuccessEvent: "HomePageOmniRecommendationEndpointSuccess",
                    subtitleLinkStart: "{linkStart}",
                    subtitleLinkEnd: "{linkEnd}"
                },
                Oe = {
                    numGameCarouselLookAheadWindows: 3,
                    adSortDiscoverId: 27,
                    carouselContainerBufferWidth: 80,
                    gameTileGutterWidth: 14,
                    wideGameTileGutterWidth: 16
                },
                Re = {
                    maxTilesInGameImpressionsEvent: 25,
                    gameImpressionsIntersectionThreshold: .5,
                    filterImpressionsIntersectionThreshold: .5,
                    numberOfInGameAvatarIcons: 3,
                    numberOfInGameNames: 1,
                    maxFacepileFriendCountValue: 99,
                    numberOfGameTilesPerLoad: 60,
                    numberOfGamePassesPerLoad: 50,
                    keyBoardEventCode: {
                        enter: "Enter",
                        escape: "Escape"
                    },
                    RatingPercentageText: "Label.RatingPercentage"
                },
                Ue = .1,
                Me = ke,
                Ge = Oe,
                je = Re,
                Fe = {
                    ActionApply: "Action.Apply",
                    LabelSponsoredAd: "Label.SponsoredAd",
                    LabelNoSearchResults: "LabelNoSearchResults",
                    LabelPlayingOnePlusUsersWithComma: "LabelPlayingOnePlusUsersWithComma",
                    LabelPlayingOneUser: "LabelPlayingOneUser",
                    LabelBy: "LabelCreatorBy",
                    LabelByPrefix: "Label.By"
                },
                Be = {
                    LabelApiError: "Label.ApiError",
                    LabelGames: "Label.Games",
                    LabelSponsoredAdsDisclosureStatic: "Label.SponsoredAdsDisclosureStatic"
                },
                He = {
                    LabelDiscover: "Label.Discover",
                    LabelCharts: "Label.Charts",
                    ActionClose: "Action.Close",
                    ActionDropdownSelected: "Action.DropdownSelected",
                    ActionDropdownNotSelected: "Action.DropdownNotSelected"
                },
                ze = {
                    ActionSeeAll: "Action.SeeAll",
                    ActionInterestCatcherContinue: "Action.InterestCatcherContinue",
                    ActionInterestCatcherContinueSelected: "Action.InterestCatcherContinueSelected",
                    ActionInterestCatcherSkip: "Action.InterestCatcherSkip",
                    ActionInterestCatcherInterested: "Action.InterestCatcherInterested"
                },
                Ve = {
                    HeadingDescription: "Heading.Description",
                    LabelAgeGuidelines: "Label.AgeGuidelines",
                    LabelLearnMore: "Label.LearnMore",
                    LabelBy: "Label.By",
                    LabelPlaying: "Label.Playing",
                    LabelFavorites: "Label.Favorites",
                    LabelVisits: "Label.Visits",
                    LabelCreated: "Label.Created",
                    LabelUpdated: "Label.Updated",
                    LabelMaxPlayers: "Label.MaxPlayers",
                    LabelGenre: "Label.Genre",
                    LabelAllowedGear: "Label.AllowedGear",
                    LabelReportAbuse: "Label.ReportAbuse",
                    LabelPlaceCopyingAllowed: "Label.PlaceCopyingAllowed",
                    LabelVoiceEnabled: "Label.VoiceEnabled",
                    LabelYes: "Label.Yes",
                    LabelNo: "Label.No",
                    LabelUnavailable: "Label.Unavailable",
                    LabelSuitableForEveryone: "Label.SuitableForEveryone",
                    LabelCommunication: "Label.Communication",
                    LabelMicrophone: "Label.Microphone",
                    LabelCamera: "Label.Camera",
                    LabelNone: "Label.None",
                    LabelThankYou: "Label.ThankYouMessage",
                    LabelGenreUnderConstruction: "Label.GenreUnderConstruction",
                    HeadingRecommendedGames: "Heading.RecommendedGames",
                    ActionSwapToSource: "Action.SwapToSource",
                    ActionSwapToTranslation: "Action.SwapToTranslation",
                    ActionTranslate: "Action.Translate"
                },
                ae = PropTypes,
                We = "Label.ContextMenuTitle",
                $e = "Action.ViewDetails",
                qe = "Action.JoinGame",
                Ze = {
                    goToProfileInPlacesList: {
                        name: "goToProfileInPlacesList",
                        ctx: "click"
                    },
                    openModalFromGameTile: {
                        name: "openModalFromGameTile",
                        ctx: "click"
                    },
                    goToChatInPlacesList: {
                        name: "goToChatInPlacesList",
                        ctx: "click"
                    },
                    joinGameInPlacesList: {
                        name: "joinGameInPlacesList",
                        ctx: "click"
                    },
                    goToGameDetailInPlacesList: {
                        name: "goToGameDetailInPlacesList",
                        ctx: "click"
                    },
                    gamePlayIntentInPlacesList: {
                        ctx: "placesListInHomePage"
                    }
                };

            function Ke(e) {
                var t = e.game,
                    n = e.translate,
                    r = t.universeId,
                    a = t.name,
                    e = t.referralUrl,
                    t = t.isPlayable,
                    r = W().createElement(Ae.Thumbnail2d, {
                        type: Ae.ThumbnailTypes.gameIcon,
                        size: Ae.DefaultThumbnailSize,
                        targetId: r,
                        imgClassName: "game-card-thumb",
                        format: Ae.ThumbnailFormat.jpeg
                    });
                return W().createElement("div", {
                    className: "border-bottom player-interaction-container"
                }, W().createElement("span", {
                    className: "cursor-pointer game-icon"
                }, W().createElement(ge.Link, {
                    url: e,
                    className: "game-card-link"
                }, r)), W().createElement("span", {
                    className: "game-info-container"
                }, W().createElement(ge.Link, {
                    url: e,
                    className: "game-name"
                }, a), !t && W().createElement(ge.Link, {
                    url: e,
                    className: "btn-control-sm game-link"
                }, n($e))))
            }
            Ke.propTypes = {
                game: (te = Ua.n(ae))().shape({
                    universeId: te().number,
                    placeId: te().number,
                    name: te().string,
                    playerCount: te().number,
                    isShowSponsoredLabel: te().bool,
                    nativeAdData: te().string,
                    imageUrl: te().string,
                    referralUrl: te().string,
                    isPlayable: te().bool
                }).isRequired,
                translate: te().func.isRequired
            };
            var Je = Ke;

            function Ye(e) {
                var t = e.playerId,
                    e = e.altName;
                return W().createElement("div", {
                    className: "avatar-card-link"
                }, W().createElement(Ae.Thumbnail2d, {
                    type: Ae.ThumbnailTypes.avatarHeadshot,
                    size: Ae.ThumbnailAvatarHeadshotSize.size48,
                    targetId: t,
                    imgClassName: "avatar-card-image",
                    format: Ae.ThumbnailFormat.webp,
                    altName: e
                }))
            }
            Ye.defaultProps = {
                altName: ""
            }, Ye.propTypes = {
                playerId: te().number.isRequired,
                altName: te().string
            };
            var Qe = Ye;

            function Xe(e) {
                var t = e.playerData,
                    o = e.dismissModal,
                    n = e.isPlayable,
                    r = e.translate,
                    e = t.presence,
                    i = e.rootPlaceId,
                    l = e.placeId,
                    s = e.gameId,
                    u = t.id,
                    t = t.nameForDisplay;
                return W().createElement("div", {
                    className: "border-bottom player-info"
                }, W().createElement("span", {
                    className: "player-name"
                }, t), W().createElement(ge.Button, {
                    className: "cursor-pointer btn-primary-sm player-action",
                    onClick: function(e) {
                        var t = {
                                rootPlaceId: i,
                                placeId: l
                            },
                            n = S.playGameService.buildPlayGameProperties(i, l, s, u),
                            r = Ze.joinGameInPlacesList,
                            a = Ze.gamePlayIntentInPlacesList,
                            a = {
                                eventName: r.name,
                                ctx: r.ctx,
                                properties: t,
                                gamePlayIntentEventCtx: a.ctx
                            };
                        S.playGameService.launchGame(n, a), o(e)
                    },
                    isDisabled: !n
                }, r(qe)))
            }
            Xe.propTypes = {
                playerData: te().shape({
                    presence: te().shape({
                        rootPlaceId: te().number,
                        placeId: te().number,
                        gameId: te().string
                    }),
                    id: te().number,
                    nameForDisplay: te().string
                }).isRequired,
                dismissModal: te().func.isRequired,
                isPlayable: te().bool.isRequired,
                translate: te().func.isRequired
            };
            var et = Xe;

            function tt(e) {
                var t = e.friendsData,
                    n = e.friendsInGame,
                    a = e.dismissModal,
                    o = e.isPlayable,
                    i = e.translate,
                    l = {};
                return t.forEach(function(e) {
                    l[e.id] = e
                }), W().createElement("div", {
                    className: "interaction-container"
                }, W().createElement("ul", {
                    className: "interaction-list"
                }, n.map(function(e, t) {
                    var n = e + t,
                        r = l[e],
                        t = r.id,
                        e = r.nameForDisplay;
                    return W().createElement("li", {
                        key: n,
                        className: "interaction-item",
                        "aria-hidden": "true"
                    }, W().createElement("span", {
                        className: "avatar avatar-headshot avatar-headshot-sm player-avatar"
                    }, W().createElement(Qe, {
                        playerId: t,
                        altName: e
                    })), W().createElement(et, {
                        playerData: r,
                        dismissModal: a,
                        isPlayable: o,
                        translate: i
                    }))
                })))
            }
            tt.propTypes = {
                friendsData: te().arrayOf(te().shape({
                    presense: te().shape({
                        rootPlaceId: te().number,
                        placeId: te().number,
                        gameId: te().string
                    }),
                    id: te().number,
                    nameForDisplay: te().string
                })).isRequired,
                friendsInGame: te().arrayOf(te().number).isRequired,
                dismissModal: te().func.isRequired,
                isPlayable: te().bool.isRequired,
                translate: te().func.isRequired
            };
            var nt = tt;

            function rt(e) {
                var t = e.friendsData,
                    n = e.friendsInGame,
                    r = e.game,
                    a = e.dismissModal,
                    o = e.translate,
                    e = o(We);
                return W().createElement("div", {
                    "data-testid": "game-players-player-interaction-modal"
                }, W().createElement(ge.Modal.Header, {
                    title: e,
                    onClose: a
                }), W().createElement(Je, {
                    game: r,
                    translate: o
                }), W().createElement(nt, {
                    friendsData: t,
                    friendsInGame: n,
                    dismissModal: a,
                    isPlayable: r.isPlayable,
                    translate: o
                }))
            }
            rt.propTypes = {
                friendsData: te().arrayOf(te().shape({
                    presense: te().shape({
                        rootPlaceId: te().number,
                        placeId: te().number,
                        gameId: te().string
                    }),
                    id: te().number,
                    nameForDisplay: te().string
                })).isRequired,
                friendsInGame: te().arrayOf(te().number).isRequired,
                game: te().shape({
                    universeId: te().number,
                    placeId: te().number,
                    name: te().string,
                    playerCount: te().number,
                    isShowSponsoredLabel: te().bool,
                    nativeAdData: te().string,
                    imageUrl: te().string,
                    referralUrl: te().string,
                    isPlayable: te().bool
                }).isRequired,
                dismissModal: te().func.isRequired,
                translate: te().func.isRequired
            };
            var at = rt,
                ve = {
                    common: ["Common.GameSorts", "Feature.GamePage", "Feature.GameDetails", "Feature.ContactUpsell"],
                    feature: "Feature.PlacesList"
                };

            function ot(e) {
                var t = e.id,
                    n = e.children,
                    r = e.gameData,
                    a = e.isOnScreen,
                    o = e.page,
                    i = e.shouldUseHigherResolutionIcon,
                    e = e.buildEventProperties,
                    i = i ? Ae.ThumbnailGameIconSize.size256 : Ae.ThumbnailGameIconSize.size150;
                return W().createElement(ge.Link, {
                    url: q(r.placeId, r.name, e(r, t)),
                    tabIndex: a ? 0 : -1,
                    "aria-hidden": !a,
                    className: "game-card-link",
                    id: r.universeId.toString()
                }, o === T.GamesPage ? W().createElement("div", {
                    className: "game-card-thumb-container"
                }, W().createElement(Ae.Thumbnail2d, {
                    type: Ae.ThumbnailTypes.gameIcon,
                    size: i,
                    targetId: r.universeId,
                    containerClass: "game-card-thumb",
                    format: Ae.ThumbnailFormat.jpeg,
                    altName: r.name
                })) : W().createElement(Ae.Thumbnail2d, {
                    type: Ae.ThumbnailTypes.gameIcon,
                    size: i,
                    targetId: r.universeId,
                    containerClass: "game-card-thumb-container",
                    format: Ae.ThumbnailFormat.jpeg,
                    altName: r.name
                }), W().createElement("div", {
                    className: "game-card-name game-name-title",
                    title: r.name
                }, r.name), n)
            }(tr = function(e) {
                var t = e.tooltipText,
                    e = e.sizeInPx,
                    e = void 0 === e ? 16 : e;
                return W().createElement("span", {
                    className: "info-tooltip-container"
                }, W().createElement(ge.Tooltip, {
                    id: "games-info-tooltip",
                    placement: "right",
                    containerClassName: "games-info-tooltip",
                    content: t
                }, W().createElement("svg", {
                    width: e,
                    height: e,
                    viewBox: "0 0 16 16",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg"
                }, W().createElement("path", {
                    d: "M8.97 5.44H7V4H8.97V5.44Z",
                    fill: "currentColor"
                }), W().createElement("path", {
                    d: "M8.94347 11.9999H7.05347V6.37988H8.94347V11.9999Z",
                    fill: "currentColor"
                }), W().createElement("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M8 16C12.4183 16 16 12.4183 16 8C16 3.58172 12.4183 0 8 0C3.58172 0 0 3.58172 0 8C0 12.4183 3.58172 16 8 16ZM8 14.5C11.5899 14.5 14.5 11.5899 14.5 8C14.5 4.41015 11.5899 1.5 8 1.5C4.41015 1.5 1.5 4.41015 1.5 8C1.5 11.5899 4.41015 14.5 8 14.5Z",
                    fill: "currentColor"
                }))))
            }).defaultProps = {
                sizeInPx: 16
            };
            var it = tr,
                lt = ((ae = {})[F.GridTile] = {
                    minTileWidth: 233,
                    columnGap: 16,
                    minTilesPerRow: 2,
                    maxTilesPerRow: 6
                }, ae[F.EventTile] = {
                    minTileWidth: 233,
                    columnGap: 16,
                    minTilesPerRow: 4,
                    maxTilesPerRow: 4
                }, ae[F.InterestTile] = {
                    minTileWidth: 311,
                    columnGap: 16,
                    minTilesPerRow: 2,
                    maxTilesPerRow: 6
                }, ae[F.AppGameTileNoMetadata] = {
                    minTileWidth: 150,
                    columnGap: 16,
                    minTilesPerRow: 3,
                    maxTilesPerRow: 12
                }, ae[F.ExperienceEventsTile] = {
                    minTileWidth: 233,
                    columnGap: 16,
                    minTilesPerRow: 2,
                    maxTilesPerRow: 3
                }, ae),
                st = {
                    minTileWidth: 150,
                    columnGap: 16,
                    minTilesPerRow: 3,
                    maxTilesPerRow: 12
                },
                ut = function() {
                    return (ut = Object.assign || function(e) {
                        for (var t, n = 1, r = arguments.length; n < r; n++)
                            for (var a in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
                        return e
                    }).apply(this, arguments)
                },
                ct = Re.keyBoardEventCode,
                dt = Re.numberOfInGameAvatarIcons,
                ft = Re.numberOfInGameNames;

            function pt(e) {
                var t = e.totalDownVotes,
                    n = e.totalUpVotes,
                    e = e.playerCount,
                    t = ie(n, t),
                    e = le(e);
                return W().createElement("div", {
                    className: "game-card-info",
                    "data-testid": "game-tile-stats"
                }, W().createElement("span", {
                    className: "info-label icon-votes-gray"
                }), t ? W().createElement("span", {
                    className: "info-label vote-percentage-label"
                }, t) : W().createElement("span", {
                    className: "info-label no-vote"
                }), W().createElement("span", {
                    className: "info-label icon-playing-counts-gray"
                }), W().createElement("span", {
                    className: "info-label playing-counts-label"
                }, e))
            }

            function mt(e) {
                var t = e.totalDownVotes,
                    n = e.totalUpVotes,
                    r = e.translate,
                    e = Re.RatingPercentageText,
                    t = (null == (t = oe(n, t)) ? void 0 : t.toString()) || "--";
                return W().createElement("div", {
                    className: "game-card-info",
                    "data-testid": "game-tile-stats-rating"
                }, W().createElement("span", {
                    className: "info-label icon-votes-gray"
                }), W().createElement("span", {
                    className: "info-label vote-percentage-label"
                }, r(e, {
                    percentRating: t
                }) || t + "% Rating"))
            }

            function vt(e) {
                return e = e.footerData, W().createElement("div", {
                    className: "game-card-info",
                    "data-testid": "game-tile-stats-text-footer"
                }, W().createElement("span", {
                    className: "info-label"
                }, e.text.textLiteral))
            }

            function ht(e) {
                var t = e.iconClassName,
                    e = e.text;
                return W().createElement("div", {
                    className: "game-card-info",
                    "data-testid": "game-tile-stats-icon-text-footer"
                }, W().createElement("span", {
                    className: he()("info-label", t)
                }), W().createElement("span", {
                    className: "info-label text-label-with-icon"
                }, e))
            }

            function gt(e) {
                return e = e.footerText, W().createElement("div", {
                    className: "game-card-info",
                    "data-testid": "game-tile-stats-friend-activity"
                }, W().createElement("span", {
                    className: "info-label"
                }, e))
            }

            function yt(e) {
                return e = e.translate, W().createElement("div", {
                    className: "game-card-native-ad",
                    "data-testid": "game-tile-sponsored-footer"
                }, W().createElement("div", {
                    className: "native-ad-label"
                }, e(Fe.LabelSponsoredAd), W().createElement(it, {
                    tooltipText: e(Be.LabelSponsoredAdsDisclosureStatic) || "Sponsored experiences are paid for by Creators. They may be shown to you based on general information about your device type, location, and demographics.",
                    sizeInPx: 12
                })))
            }

            function bt(e) {
                return e = e.user, W().createElement(Ae.Thumbnail2d, {
                    type: Ae.ThumbnailTypes.avatarHeadshot,
                    size: Ae.ThumbnailAvatarHeadshotSize.size48,
                    targetId: e.id,
                    containerClass: "avatar avatar-headshot avatar-headshot-xs",
                    imgClassName: "avatar-card-image",
                    format: Ae.ThumbnailFormat.webp,
                    altName: e.displayName
                })
            }

            function It(e) {
                return e = e.translate, W().createElement("div", {
                    className: "game-card-info",
                    "data-testid": "wide-game-tile-sponsored-footer"
                }, W().createElement(it, {
                    tooltipText: e(Be.LabelSponsoredAdsDisclosureStatic) || "Sponsored experiences are paid for by Creators. They may be shown to you based on general information about your device type, location, and demographics.",
                    sizeInPx: 12
                }), W().createElement("span", {
                    className: "info-label text-label-with-icon"
                }, e(Fe.LabelSponsoredAd)))
            }

            function Pt(e) {
                var t = e.friendsData,
                    n = e.isOnline,
                    r = Re.maxFacepileFriendCountValue,
                    r = (null == t ? void 0 : t.length) > r ? r.toString() + "+" : (null == t ? void 0 : t.length) > dt ? null == t ? void 0 : t.length.toString() : "",
                    e = r ? dt - 1 : dt,
                    a = he()("avatar-card", {
                        "avatar-card-online": n
                    });
                return W().createElement("div", {
                    className: "info-avatar"
                }, r && W().createElement("div", {
                    className: a
                }, W().createElement("div", {
                    className: "avatar-count-container"
                }, W().createElement("span", {
                    className: "avatar-count info-label"
                }, r))), t.slice(0, e).map(function(e) {
                    return W().createElement("div", {
                        className: a,
                        key: e.displayName
                    }, W().createElement(bt, {
                        user: e
                    }))
                }))
            }

            function Et(e) {
                var t = e.friendsData,
                    e = e.isOnline;
                if (0 === t.length) throw new Error("friendData should not be empty");
                return W().createElement("div", {
                    className: "game-card-info",
                    "data-testid": "game-tile-stats-" + (e ? "online" : "offline") + "-friends-facepile"
                }, W().createElement(Pt, {
                    friendsData: t,
                    isOnline: e
                }), W().createElement("span", {
                    className: "info-label"
                }, t.map(function(e) {
                    return e.displayName
                }).join(", ")))
            }

            function St(e) {
                var t = e.friendData,
                    n = e.gameData,
                    r = e.translate,
                    a = (0, V.useState)(!1),
                    e = a[0],
                    o = a[1];
                if (0 === t.length) throw new Error("friendData should not be empty");
                return W().createElement("div", {
                    className: "game-card-friend-info game-card-info",
                    "data-testid": "game-tile-stats-friends"
                }, W().createElement("div", {
                    className: "info-avatar",
                    style: {
                        width: 22 * (t.slice(0, dt).length - 1) + 32 + "px"
                    }
                }, t.slice(0, dt).map(function(e) {
                    return W().createElement("div", {
                        className: "avatar-card",
                        role: "button",
                        tabIndex: 0,
                        key: e.displayName,
                        onClick: function(e) {
                            e.stopPropagation(), e.preventDefault(), o(!0)
                        },
                        onKeyDown: function(e) {
                            e.code === ct.enter && (e.stopPropagation(), e.preventDefault(), o(!0))
                        }
                    }, W().createElement(bt, {
                        user: e
                    }))
                })), r && W().createElement("span", {
                    className: "info-label text-overflow",
                    "data-testid": "game-tile-stats-info-label"
                }, t.length > ft ? r(Fe.LabelPlayingOnePlusUsersWithComma, {
                    username: t[0].displayName,
                    count: t.length - ft
                }) : r(Fe.LabelPlayingOneUser, {
                    user: t[0].displayName
                })), W().createElement(Ct, {
                    friendsDataInGame: t,
                    game: n,
                    show: e,
                    onHide: function(e) {
                        e.stopPropagation(), e.preventDefault(), o(!1)
                    }
                }))
            }

            function wt(e) {
                var t = e.children,
                    n = (0, V.useState)({
                        shouldUseHigherResolutionIcon: !1
                    }),
                    e = n[0],
                    r = n[1];
                return (0, V.useEffect)(function() {
                    fe(Tt.tileLayer, _t.tileLayer).then(function(e) {
                        null != e && e.IsHigherResolutionImageEnabled && r({
                            shouldUseHigherResolutionIcon: !(null == e || !e.IsHigherResolutionImageEnabled)
                        })
                    }).catch(function() {})
                }, []), W().createElement(xt.Provider, {
                    value: e
                }, t)
            }
            ot.defaultProps = {
                page: T.HomePage,
                isOnScreen: !0,
                shouldUseHigherResolutionIcon: !1
            }, St.defaultProps = {
                translate: void 0
            };
            var Ct = (0, f.withTranslations)(function(e) {
                    var t = e.show,
                        n = e.onHide,
                        r = e.friendsDataInGame,
                        a = e.game,
                        e = e.translate;
                    return W().createElement(ge.Modal, {
                        show: t,
                        onHide: n,
                        size: "lg"
                    }, W().createElement(at, {
                        friendsData: r.map(function(e) {
                            return ut(ut({}, e), {
                                nameForDisplay: e.displayName
                            })
                        }),
                        friendsInGame: r.map(function(e) {
                            return e.id
                        }),
                        game: a,
                        dismissModal: n,
                        translate: e
                    }))
                }, ve),
                Tt = n,
                _t = t,
                xt = (0, V.createContext)({
                    shouldUseHigherResolutionIcon: !1
                }),
                Lt = function(e, i, l, s) {
                    return new(l = l || Promise)(function(n, t) {
                        function r(e) {
                            try {
                                o(s.next(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function a(e) {
                            try {
                                o(s.throw(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function o(e) {
                            var t;
                            e.done ? n(e.value) : ((t = e.value) instanceof l ? t : new l(function(e) {
                                e(t)
                            })).then(r, a)
                        }
                        o((s = s.apply(e, i || [])).next())
                    })
                },
                Nt = function(n, r) {
                    var a, o, i, l = {
                            label: 0,
                            sent: function() {
                                if (1 & i[0]) throw i[1];
                                return i[1]
                            },
                            trys: [],
                            ops: []
                        },
                        e = {
                            next: t(0),
                            throw: t(1),
                            return: t(2)
                        };
                    return "function" == typeof Symbol && (e[Symbol.iterator] = function() {
                        return this
                    }), e;

                    function t(t) {
                        return function(e) {
                            return function(t) {
                                if (a) throw new TypeError("Generator is already executing.");
                                for (; l;) try {
                                    if (a = 1, o && (i = 2 & t[0] ? o.return : t[0] ? o.throw || ((i = o.return) && i.call(o), 0) : o.next) && !(i = i.call(o, t[1])).done) return i;
                                    switch (o = 0, i && (t = [2 & t[0], i.value]), t[0]) {
                                        case 0:
                                        case 1:
                                            i = t;
                                            break;
                                        case 4:
                                            return l.label++, {
                                                value: t[1],
                                                done: !1
                                            };
                                        case 5:
                                            l.label++, o = t[1], t = [0];
                                            continue;
                                        case 7:
                                            t = l.ops.pop(), l.trys.pop();
                                            continue;
                                        default:
                                            if (!(i = 0 < (i = l.trys).length && i[i.length - 1]) && (6 === t[0] || 2 === t[0])) {
                                                l = 0;
                                                continue
                                            }
                                            if (3 === t[0] && (!i || t[1] > i[0] && t[1] < i[3])) {
                                                l.label = t[1];
                                                break
                                            }
                                            if (6 === t[0] && l.label < i[1]) {
                                                l.label = i[1], i = t;
                                                break
                                            }
                                            if (i && l.label < i[2]) {
                                                l.label = i[2], l.ops.push(t);
                                                break
                                            }
                                            i[2] && l.ops.pop(), l.trys.pop();
                                            continue
                                    }
                                    t = r.call(n, l)
                                } catch (e) {
                                    t = [6, e], o = 0
                                } finally {
                                    a = i = 0
                                }
                                if (5 & t[0]) throw t[1];
                                return {
                                    value: t[0] ? t[1] : void 0,
                                    done: !0
                                }
                            }([t, e])
                        }
                    }
                };
            (tr = (0, V.forwardRef)(function(e, t) {
                var n = e.id,
                    r = e.buildEventProperties,
                    a = e.gameData,
                    o = e.page,
                    i = void 0 === o ? T.HomePage : o,
                    l = e.className,
                    s = void 0 === l ? "grid-item-container game-card-container" : l,
                    o = e.friendData,
                    u = void 0 === o ? [] : o,
                    l = e.isOnScreen,
                    o = void 0 === l || l,
                    l = e.shouldShowMetadata,
                    c = void 0 === l || l,
                    l = e.isSponsoredFooterAllowed,
                    d = void 0 !== l && l,
                    f = e.translate,
                    e = (0, V.useState)(),
                    p = e[0],
                    m = e[1],
                    v = (0, V.useMemo)(function() {
                        return Z(u, a.universeId)
                    }, [u, a.universeId]),
                    e = (0, V.useContext)(xt).shouldUseHigherResolutionIcon;
                (0, V.useEffect)(function() {
                    void 0 === p && 0 < v.length && Lt(void 0, void 0, void 0, function() {
                        var t;
                        return Nt(this, function(e) {
                            switch (e.label) {
                                case 0:
                                    return e.trys.push([0, 2, , 3]), [4, De(a.placeId.toString())];
                                case 1:
                                    return t = e.sent(), m(t), [3, 3];
                                case 2:
                                    return t = e.sent(), console.error(t), [3, 3];
                                case 3:
                                    return [2]
                            }
                        })
                    })
                }, [v, p]);
                return W().createElement("div", {
                    ref: t,
                    className: s,
                    "data-testid": "game-tile"
                }, W().createElement(ot, {
                    id: n,
                    isOnScreen: o,
                    buildEventProperties: r,
                    gameData: a,
                    page: i,
                    shouldUseHigherResolutionIcon: e
                }, c ? null != a && a.isShowSponsoredLabel || null != a && a.isSponsored && d ? W().createElement(yt, {
                    translate: f
                }) : 0 < v.length && p ? W().createElement(St, {
                    friendData: v,
                    gameData: p
                }) : null != a && a.friendActivityTitle ? W().createElement(gt, {
                    footerText: a.friendActivityTitle
                }) : W().createElement(pt, {
                    totalUpVotes: a.totalUpVotes,
                    totalDownVotes: a.totalDownVotes,
                    playerCount: a.playerCount
                }) : W().createElement(W().Fragment, null)))
            })).displayName = "GameTile";
            var Dt = tr;
            (ae = function(e) {
                var t = e.placeId,
                    n = e.clientReferralUrl,
                    r = e.buttonClassName,
                    a = e.purchaseIconClassName,
                    o = (0, V.useState)(void 0),
                    i = o[0],
                    l = o[1],
                    e = (0, V.useState)(void 0),
                    o = e[0],
                    s = e[1];
                if ((0, V.useEffect)(function() {
                        De(t).then(function(e) {
                            return l(e)
                        }).catch(function() {
                            s(!0)
                        })
                    }, [t]), void 0 === i && !o) return W().createElement(kt, null);
                r = he()(r, "btn-full-width");
                return W().createElement(W().Fragment, null, W().createElement(ge.Link, {
                    "data-testid": "hover-tile-purchase-button",
                    className: r,
                    url: n || (null == i ? void 0 : i.url)
                }, W().createElement("span", {
                    className: a
                }), W().createElement("span", {
                    className: "btn-text"
                }, (null == i ? void 0 : i.price) || "--"), " "))
            }).defaultProps = {
                clientReferralUrl: ""
            };
            var At = ae,
                kt = function() {
                    return W().createElement("div", {
                        className: "shimmer play-button game-card-thumb-container",
                        "data-testid": "play-button-default"
                    })
                };

            function Ot(e) {
                var t = e.gameData,
                    n = e.topicId,
                    r = e.wideTileType,
                    a = (0, V.useMemo)(function() {
                        return G(t, n)
                    }, [t, n]),
                    e = (0, V.useMemo)(function() {
                        return r === F.EventTile ? Ae.ThumbnailGameThumbnailSize.width576 : Ae.ThumbnailGameThumbnailSize.width384
                    }, [r]);
                return null !== a ? W().createElement(Ae.Thumbnail2d, {
                    type: Ae.ThumbnailTypes.assetThumbnail,
                    size: e,
                    targetId: a,
                    containerClass: "brief-game-icon",
                    format: Ae.ThumbnailFormat.jpeg,
                    altName: t.name
                }) : W().createElement(Ae.Thumbnail2d, {
                    type: Ae.ThumbnailTypes.gameThumbnail,
                    size: e,
                    targetId: t.placeId,
                    containerClass: "brief-game-icon",
                    format: Ae.ThumbnailFormat.jpeg,
                    altName: t.name
                })
            }(tr = function(e) {
                var t = e.universeId,
                    n = e.placeId,
                    r = e.playButtonEventProperties,
                    a = e.buttonClassName,
                    o = e.purchaseIconClassName,
                    i = e.clientReferralUrl,
                    l = e.shouldPurchaseNavigateToDetails,
                    e = h.PlayButton.usePlayabilityStatus,
                    s = h.PlayButton.PlayabilityStatuses,
                    u = h.PlayButton.PlayButton,
                    c = h.PlayButton.PurchaseButton,
                    e = e(t),
                    d = e[0],
                    f = e[1];
                switch (d) {
                    case void 0:
                    case s.GuestProhibited:
                    case s.Playable:
                        return W().createElement(u, {
                            universeId: t,
                            placeId: n,
                            status: null != d ? d : s.Playable,
                            eventProperties: r,
                            buttonClassName: a ? he()(a, "regular-play-button") : void 0,
                            disableLoadingState: !0
                        });
                    case s.PurchaseRequired:
                        return l ? W().createElement(At, {
                            placeId: n,
                            clientReferralUrl: i,
                            purchaseIconClassName: null != o ? o : "icon-common-play",
                            buttonClassName: he()(null != a ? a : "btn-growth-lg play-button", "purchase-button")
                        }) : W().createElement(c, {
                            universeId: t,
                            placeId: n,
                            iconClassName: null != o ? o : "icon-common-play",
                            refetchPlayabilityStatus: f,
                            buttonClassName: a
                        });
                    case s.UniverseRootPlaceIsPrivate:
                        return W().createElement("div", {
                            className: null != a ? a : "btn-growth-lg play-button"
                        }, W().createElement("span", {
                            className: "icon-status-private"
                        }));
                    default:
                        return W().createElement("div", {
                            className: null != a ? a : "btn-growth-lg play-button"
                        }, W().createElement("span", {
                            className: "icon-status-unavailable"
                        }))
                }
            }).defaultProps = {
                playButtonEventProperties: {},
                buttonClassName: void 0,
                purchaseIconClassName: void 0,
                clientReferralUrl: void 0,
                shouldPurchaseNavigateToDetails: !1
            };
            var Rt, Ut, Mt, Gt = tr;

            function jt(e) {
                return e = e.playerCount, e = le(e), W().createElement("div", {
                    className: "game-card-info",
                    "data-testid": "game-tile-stats-player-count"
                }, W().createElement("span", {
                    className: "info-label icon-playing-counts-gray"
                }), W().createElement("span", {
                    className: "info-label playing-counts-label"
                }, e))
            }

            function Ft(e) {
                var t = e.playerCount,
                    e = e.playerCountStyle,
                    e = he()("game-card-image-pill", {
                        "hover-only": e === B.Hover
                    });
                return W().createElement("div", {
                    className: e,
                    "data-testid": "game-tile-player-count-pill"
                }, W().createElement(jt, {
                    playerCount: t
                }))
            }

            function Bt(e) {
                return e = e.featureTypes, W().createElement("div", {
                    className: "game-card-image-feature-pill",
                    "data-testid": "game-tile-social-feature-pill"
                }, W().createElement("div", {
                    className: "game-card-info",
                    "data-testid": "game-tile-social-feature-list"
                }, e.map(function(e) {
                    return zt[e] && W().createElement("span", {
                        key: e,
                        className: zt[e]
                    })
                })))
            }

            function Ht(e) {
                return e = e.text, W().createElement("div", {
                    className: "game-card-text-pill"
                }, W().createElement("div", {
                    className: "game-card-info"
                }, e))
            }(ae = {}).Melee = "Melee", ae.Ranged = "Ranged", ae.Explosive = "Explosive", ae.PowerUps = "PowerUps", ae.Navigation = "Navigation", ae.Music = "Music", ae.Social = "Social", ae.Building = "Building", ae.PersonalTransport = "PersonalTransport", (tr = Rt = Rt || {}).Home = "Home", tr.Games = "Games", (ae = {}).Invalid = "Invalid", ae.HasLootBoxes = "HasLootBoxes", ae.HasInGameTrading = "HasInGameTrading", ae.IsUsingLootBoxApi = "IsUsingLootBoxApi", ae.IsUsingInGameTradingApi = "IsUsingInGameTradingApi", ae.HasAllowedExternalLinkReferences = "HasAllowedExternalLinkReferences", ae.IsUsingAllowedExternalLinkReferencesApi = "IsUsingAllowedExternalLinkReferencesApi", (tr = {}).MorphToR6 = "MorphToR6", tr.PlayerChoice = "PlayerChoice", tr.MorphToR15 = "MorphToR15", (Ut = Ut || {}).TextLabel = "TextLabel", (ae = {}).Voice = "Voice", ae.Camera = "Camera", (tr = Mt = Mt || {}).Text = "Text", tr.Icon = "Icon", Ft.defaultProps = {
                playerCountStyle: void 0
            };
            var zt = {
                Voice: "pill-icon icon-default-voice-16x16-white",
                Camera: "pill-icon icon-default-camera-white"
            };

            function Vt(n, r) {
                var a;
                return void 0 === r && (r = 300), [function() {
                    for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
                    clearTimeout(a), a = setTimeout(function() {
                        n.apply(void 0, e)
                    }, r)
                }, function() {
                    clearTimeout(a)
                }]
            }

            function Wt(e) {
                var t = e.wrapperClassName,
                    n = e.isTileClickEnabled,
                    r = e.isOnScreen,
                    a = e.linkUrl,
                    e = e.children;
                return n ? W().createElement(ge.Link, {
                    url: a,
                    className: t,
                    tabIndex: r ? 0 : -1
                }, e) : W().createElement("span", {
                    className: t
                }, e)
            }(ae = function(e) {
                var t = e.gameLayoutData,
                    n = e.playerCountStyle,
                    r = e.playerCount,
                    e = null === (e = null === (e = null == t ? void 0 : t.tileBadgesByPosition) || void 0 === e ? void 0 : e.ImageTopLeft) || void 0 === e ? void 0 : e[0];
                return e && e.tileBadgeType === Mt.Text && e.text ? W().createElement(Ht, {
                    text: e.text
                }) : null !== (e = null == t ? void 0 : t.pill) && void 0 !== e && e.types && 0 < t.pill.types.length ? W().createElement(Bt, {
                    featureTypes: t.pill.types
                }) : n === B.Always || n === B.Hover ? W().createElement(Ft, {
                    playerCount: r,
                    playerCountStyle: n
                }) : null
            }).defaultProps = {
                playerCountStyle: void 0
            };
            var $t = ae;
            (tr = W().forwardRef(function(e, t) {
                var n = e.gameData,
                    r = e.id,
                    a = e.buildEventProperties,
                    o = e.friendData,
                    i = void 0 === o ? [] : o,
                    l = e.playerCountStyle,
                    s = e.playButtonStyle,
                    u = e.navigationRootPlaceId,
                    c = e.isSponsoredFooterAllowed,
                    d = void 0 !== c && c,
                    f = e.wideTileType,
                    p = e.hoverStyle,
                    m = e.topicId,
                    v = e.isOnScreen,
                    h = void 0 === v || v,
                    g = e.isInterestedUniverse,
                    y = void 0 === g ? void 0 : g,
                    b = e.toggleInterest,
                    I = void 0 === b ? void 0 : b,
                    P = e.translate,
                    E = 0 === r,
                    S = r === Me.maxWideGameTilesPerCarouselPage - 1,
                    w = (0, V.useState)(!1),
                    C = w[0],
                    T = w[1],
                    _ = (0, V.useState)(n.placeId),
                    x = _[0],
                    L = _[1];
                (0, V.useEffect)(function() {
                    u && !Number.isNaN(u) ? L(parseInt(u, 10)) : n.navigationUid && Ne(n.navigationUid).then(function(e) {
                        null != e && e.rootPlaceId && L(e.rootPlaceId)
                    }).catch(function() {})
                }, [u, n.navigationUid]);

                function N() {
                    return n.minimumAge && n.ageRecommendationDisplayName && f !== F.EventTile ? W().createElement("div", {
                        className: "game-card-info",
                        "data-testid": "game-tile-hover-age-rating"
                    }, W().createElement("span", {
                        className: "info-label"
                    }, n.ageRecommendationDisplayName)) : null
                }
                var D, A = (0, V.useMemo)(function() {
                        return q(x, n.name, a(n, r))
                    }, [n, a, r, x]),
                    o = Vt(function() {
                        T(!0)
                    }, 100),
                    k = o[0],
                    O = o[1],
                    c = Vt(function() {
                        T(!1)
                    }, 100),
                    R = c[0],
                    U = c[1],
                    v = function() {
                        U(), k()
                    },
                    g = function() {
                        O(), R()
                    },
                    b = a(n, r),
                    M = (0, V.useMemo)(function() {
                        return Z(i, n.universeId)
                    }, [i, n.universeId]),
                    G = (0, V.useMemo)(function() {
                        return function(e, t) {
                            if (!t) return [];
                            var n = new Map(e.map(function(e) {
                                return [e.id, e]
                            }));
                            return t.map(function(e) {
                                return n.get(e.userId)
                            }).filter(function(e) {
                                return void 0 !== e
                            })
                        }(i, n.friendVisits)
                    }, [i, n.friendVisits]),
                    j = (0, V.useMemo)(function() {
                        return n.layoutDataBySort && m && n.layoutDataBySort[m] ? n.layoutDataBySort[m] : n.defaultLayoutData
                    }, [n.layoutDataBySort, n.defaultLayoutData, m]),
                    e = function() {
                        return (f !== F.GridTile || s !== H.Disabled) && ((f !== F.EventTile || s === H.Enabled) && f !== F.InterestTile)
                    },
                    w = (0, V.useMemo)(function() {
                        return null != j && j.title ? j.title : n.name
                    }, [n.name, null == j ? void 0 : j.title]),
                    _ = f !== F.InterestTile,
                    o = f !== F.InterestTile,
                    c = (0, V.useCallback)(function() {
                        I && I()
                    }, [I]);
                return W().createElement("li", {
                    className: he()("list-item", "hover-game-tile", {
                        "grid-tile": f === F.GridTile
                    }, {
                        "event-tile": f === F.EventTile
                    }, {
                        "interest-tile": f === F.InterestTile
                    }, {
                        "first-tile": E
                    }, {
                        "last-tile": S
                    }, {
                        "image-overlay": p === z.imageOverlay
                    }, {
                        "old-hover": p !== z.imageOverlay
                    }, {
                        focused: C
                    }),
                    "data-testid": "wide-game-tile",
                    onMouseOver: o ? v : void 0,
                    onMouseLeave: o ? g : void 0,
                    onFocus: o ? v : void 0,
                    onBlur: o ? g : void 0,
                    id: n.universeId.toString()
                }, n.universeId && W().createElement("div", {
                    className: "featured-game-container game-card-container",
                    ref: t
                }, W().createElement(Wt, {
                    wrapperClassName: "game-card-link",
                    isTileClickEnabled: _,
                    isOnScreen: h,
                    linkUrl: A
                }, W().createElement("div", {
                    className: "featured-game-icon-container"
                }, W().createElement(Ot, {
                    gameData: n,
                    topicId: m,
                    wideTileType: f
                }), W().createElement($t, {
                    gameLayoutData: j,
                    playerCountStyle: l,
                    playerCount: n.playerCount
                })), W().createElement("div", {
                    className: "info-container"
                }, W().createElement("div", {
                    className: "info-metadata-container"
                }, W().createElement("div", {
                    className: "game-card-name game-name-title",
                    "data-testid": "game-tile-game-title",
                    title: w
                }, w), W().createElement("div", {
                    className: "wide-game-tile-metadata"
                }, W().createElement("div", {
                    className: "base-metadata"
                }, (D = N(), C && p === z.imageOverlay && D ? D : n.isShowSponsoredLabel || n.isSponsored && d ? W().createElement(It, {
                    translate: P
                }) : null != j && j.footer && j.footer.type === Ut.TextLabel ? W().createElement(vt, {
                    footerData: j.footer
                }) : 0 < (null == M ? void 0 : M.length) ? W().createElement(Et, {
                    friendsData: M,
                    isOnline: !0
                }) : 0 < (null == G ? void 0 : G.length) ? W().createElement(Et, {
                    friendsData: G,
                    isOnline: !1
                }) : n.friendVisitedString ? W().createElement(ht, {
                    iconClassName: "icon-pastname",
                    text: n.friendVisitedString
                }) : l === B.Footer ? W().createElement(pt, {
                    totalUpVotes: n.totalUpVotes,
                    totalDownVotes: n.totalDownVotes,
                    playerCount: n.playerCount
                }) : W().createElement(mt, {
                    totalUpVotes: n.totalUpVotes,
                    totalDownVotes: n.totalDownVotes,
                    translate: P
                }))), W().createElement("div", {
                    className: "hover-metadata"
                }, N()))), C && p === z.imageOverlay && e() && W().createElement("div", {
                    "data-testid": "game-tile-hover-game-tile-contents",
                    className: "play-button-container"
                }, W().createElement(Gt, {
                    universeId: n.universeId.toString(),
                    placeId: n.placeId.toString(),
                    playButtonEventProperties: b,
                    buttonClassName: "btn-growth-xs play-button",
                    purchaseIconClassName: "icon-robux-white",
                    clientReferralUrl: A,
                    shouldPurchaseNavigateToDetails: !0
                })))), C && p !== z.imageOverlay && e() && W().createElement("div", {
                    "data-testid": "game-tile-hover-game-tile-contents",
                    className: "game-card-contents"
                }, W().createElement(Gt, {
                    universeId: n.universeId.toString(),
                    placeId: n.placeId.toString(),
                    playButtonEventProperties: b,
                    buttonClassName: "btn-growth-xs play-button",
                    purchaseIconClassName: "icon-robux-white",
                    clientReferralUrl: A,
                    shouldPurchaseNavigateToDetails: !0
                })), f === F.InterestTile && W().createElement(ge.Button, {
                    "data-testid": "tile-interest-button",
                    className: "tile-interest-button",
                    variant: ge.Button.variants.primary,
                    size: ge.Button.sizes.medium,
                    title: P(ze.ActionInterestCatcherInterested),
                    onClick: c
                }, y ? W().createElement("span", {
                    className: "icon-heart-red"
                }) : W().createElement("span", {
                    className: "icon-heart"
                }), W().createElement("span", null, P(ze.ActionInterestCatcherInterested)))))
            })).displayName = "WideGameTile";
            var qt = tr,
                Zt = function() {
                    return (Zt = Object.assign || function(e) {
                        for (var t, n = 1, r = arguments.length; n < r; n++)
                            for (var a in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
                        return e
                    }).apply(this, arguments)
                },
                Kt = function(e, t) {
                    var n = {};
                    for (a in e) Object.prototype.hasOwnProperty.call(e, a) && t.indexOf(a) < 0 && (n[a] = e[a]);
                    if (null != e && "function" == typeof Object.getOwnPropertySymbols)
                        for (var r = 0, a = Object.getOwnPropertySymbols(e); r < a.length; r++) t.indexOf(a[r]) < 0 && Object.prototype.propertyIsEnumerable.call(e, a[r]) && (n[a[r]] = e[a[r]]);
                    return n
                };
            (ae = (0, V.forwardRef)(function(e, t) {
                var n = e.componentType,
                    r = Kt(e, ["componentType"]);
                switch (n) {
                    case F.AppGameTileNoMetadata:
                        return W().createElement(Dt, Zt({
                            ref: t,
                            shouldShowMetadata: !1
                        }, r));
                    case F.GridTile:
                    case F.EventTile:
                    case F.InterestTile:
                        return W().createElement(qt, Zt({
                            ref: t,
                            wideTileType: n
                        }, r));
                    default:
                        return W().createElement(Dt, Zt({
                            ref: t
                        }, r))
                }
            })).displayName = "GameTileTypeMap";
            var Jt = ae,
                Yt = (0, V.forwardRef)(function(e, t) {
                    var n = e.gameData,
                        r = e.buildEventProperties,
                        a = e.translate,
                        o = e.friendData,
                        i = e.componentType,
                        l = e.playerCountStyle,
                        s = e.playButtonStyle,
                        u = e.navigationRootPlaceId,
                        c = e.isSponsoredFooterAllowed,
                        d = e.hoverStyle,
                        f = e.topicId,
                        p = e.isExpandHomeContentEnabled,
                        m = e.tileRef,
                        p = he()("game-carousel", {
                            "wide-game-tile-carousel": i === F.GridTile || i === F.EventTile
                        }, {
                            "expand-home-content": p
                        }, {
                            "expand-home-content-disabled": !p
                        });
                    return W().createElement("div", {
                        "data-testid": "game-carousel",
                        ref: t,
                        className: p
                    }, n.map(function(e, t) {
                        return W().createElement(Jt, {
                            componentType: i,
                            playerCountStyle: l,
                            playButtonStyle: s,
                            navigationRootPlaceId: u,
                            isSponsoredFooterAllowed: c,
                            hoverStyle: d,
                            topicId: f,
                            ref: m,
                            key: t,
                            id: t,
                            gameData: e,
                            translate: a,
                            buildEventProperties: r,
                            friendData: o
                        })
                    }))
                });

            function Qt(e) {
                var t = e.children,
                    e = (e = (e = null === (e = window.location.href) || void 0 === e ? void 0 : e.split("?")[1]) && re(e)) && (e.discoverPageSessionInfo || e.homePageSessionInfo),
                    e = (0, V.useState)(e && "string" == typeof e ? e : C.uuidService.generateRandomUuid())[0];
                return W().createElement(rn.Provider, {
                    value: e
                }, t)
            }

            function Xt() {
                return (0, V.useContext)(rn)
            }

            function en(e) {
                var n = e.defaultSubtitle,
                    t = e.endTimestamp,
                    r = e.countdownString,
                    a = e.isSortLinkOverrideEnabled,
                    o = e.seeAllLink,
                    i = e.handleSeeAllLinkClick,
                    l = e.backgroundImageAssetId,
                    s = (0, V.useMemo)(function() {
                        var e = t && parseInt(t, 10);
                        if (e || 0 === e) return e
                    }, [t]),
                    u = (e = (0, V.useState)(void 0 !== s ? s - Math.floor(Date.now() / 1e3) : void 0))[0],
                    c = e[1];
                (0, V.useEffect)(function() {
                    if (void 0 !== s) {
                        c(s - Math.floor(Date.now() / 1e3));
                        var e = setInterval(function() {
                            c(s - Math.floor(Date.now() / 1e3))
                        }, 15e3);
                        return function() {
                            clearInterval(e)
                        }
                    }
                    c(void 0)
                }, [s]);
                var d = (0, V.useMemo)(function() {
                        if (void 0 !== u && r) {
                            var e = 0,
                                t = 0;
                            if (0 < u && (t = Math.ceil(u / 60), t -= 60 * (e = Math.floor(t / 60))), e < 24) return r.replace("{hours}", e.toString()).replace("{minutes}", t.toString())
                        }
                        return n
                    }, [n, u, r]),
                    e = (0, V.useMemo)(function() {
                        if (a && d) {
                            var e = d.indexOf(an),
                                t = d.indexOf(on);
                            if (-1 !== e && -1 !== t && e < t) {
                                var n = d.slice(0, e),
                                    e = d.slice(e + an.length, t),
                                    t = d.slice(t + on.length);
                                return W().createElement(ge.Link, {
                                    url: o,
                                    onClick: i
                                }, n, W().createElement("span", {
                                    className: "link-text"
                                }, e), t, l ? W().createElement("span", {
                                    className: "icon-chevron-right-dark"
                                }) : W().createElement("span", {
                                    className: "icon-chevron-right"
                                }))
                            }
                        }
                        return d
                    }, [d, a, o, l, i]);
                return d ? W().createElement("div", {
                    className: "sort-subtitle-container"
                }, W().createElement("span", {
                    className: "font-sort-subtitle text-default"
                }, e)) : null
            }
            Yt.displayName = "GameCarousel";
            var tn = function(t, e, n) {
                    var r = (0, V.useState)(new Set),
                        a = r[0],
                        o = r[1],
                        r = (0, V.useState)(new Set),
                        i = r[0],
                        l = r[1],
                        s = (0, V.useRef)(null),
                        u = (0, V.useRef)(n);
                    (0, V.useEffect)(function() {
                        u.current = n
                    }, [n]);
                    var c = (0, V.useCallback)(function() {
                            se(Array.from(i).filter(function(e) {
                                return !a.has(e)
                            }), Re.maxTilesInGameImpressionsEvent).filter(function(e) {
                                return 0 < e.length
                            }).forEach(function(n) {
                                var e, t = u.current(n);
                                void 0 !== t && 0 < (null === (e = t.absPositions) || void 0 === e ? void 0 : e.length) && (t = ee.gameImpressions(t), S.eventStreamService.sendEvent.apply(S.eventStreamService, t), o(function(e) {
                                    var t = e;
                                    return n.forEach(function(e) {
                                        return t.add(e)
                                    }), t
                                }))
                            })
                        }, [a, i]),
                        r = Vt(function() {
                            return c()
                        }),
                        d = r[0],
                        f = r[1];
                    (0, V.useEffect)(function() {
                        var e, o = Array.from(null !== (e = null === (e = null == t ? void 0 : t.current) || void 0 === e ? void 0 : e.children) && void 0 !== e ? e : []);
                        return s.current = S.elementVisibilityService.observeChildrenVisibility({
                                elements: o,
                                threshold: Re.gameImpressionsIntersectionThreshold
                            }, function(e, t) {
                                f();
                                var n, r, a = (n = t, r = [], e.forEach(function(t) {
                                    var e;
                                    null == t || !t.isIntersecting || 0 <= (e = o.findIndex(function(e) {
                                        return e === t.target
                                    })) && (r.push(e), n.unobserve(t.target))
                                }), r.sort(function(e, t) {
                                    return e - t
                                }));
                                l(function(e) {
                                    var t = e;
                                    return a.forEach(function(e) {
                                        return t.add(e)
                                    }), t
                                }), d()
                            }),
                            function() {
                                null != s && s.current && s.current()
                            }
                    }, [t, e, i, d, f])
                },
                nn = function() {
                    return (nn = Object.assign || function(e) {
                        for (var t, n = 1, r = arguments.length; n < r; n++)
                            for (var a in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
                        return e
                    }).apply(this, arguments)
                },
                rn = (0, V.createContext)(""),
                an = ke.subtitleLinkStart,
                on = ke.subtitleLinkEnd;

            function ln(e) {
                var t = e.children,
                    n = e.backgroundImageAssetId,
                    r = (0, V.useState)(""),
                    e = r[0],
                    a = r[1];
                return (0, V.useEffect)(function() {
                    var t = !0;
                    return n ? X(n).then(function(e) {
                            t && a(e)
                        }, function() {
                            t && a("")
                        }) : a(""),
                        function() {
                            t = !1
                        }
                }, [n]), W().createElement("div", {
                    className: he()(["game-sort-carousel-wrapper", {
                        "game-sort-with-mural": !!n,
                        "game-sort-mural-loaded": !!e
                    }])
                }, e && W().createElement("div", {
                    className: "game-sort-mural-wrapper"
                }, W().createElement("img", {
                    className: "game-sort-mural",
                    alt: "",
                    src: e
                }), W().createElement("div", {
                    className: "game-sort-mural-gradient"
                })), t)
            }(tr = function(e) {
                var t = e.sortTitle,
                    n = e.sortSubtitle,
                    r = e.seeAllLink,
                    a = e.isSortLinkOverrideEnabled,
                    o = e.buildNavigateToSortLinkEventProperties,
                    i = e.shouldShowSponsoredTooltip,
                    l = e.tooltipInfoText,
                    s = e.titleContainerClassName,
                    u = e.hideSeeAll,
                    c = e.endTimestamp,
                    d = e.countdownString,
                    f = e.backgroundImageAssetId,
                    p = e.translate,
                    m = (0, V.useMemo)(function() {
                        return l || (i ? p(Be.LabelSponsoredAdsDisclosureStatic) || "Sponsored experiences are paid for by Creators. They may be shown to you based on general information about your device type, location, and demographics." : void 0)
                    }, [i, l, p]),
                    v = (0, V.useMemo)(function() {
                        return p(a ? Ve.LabelLearnMore : ze.ActionSeeAll)
                    }, [a, p]),
                    e = (0, V.useCallback)(function() {
                        var e;
                        a && o && (e = o(), e = ee.navigateToSortLink(e), S.eventStreamService.sendEvent.apply(S.eventStreamService, e))
                    }, [a, o]);
                return W().createElement("div", {
                    className: "game-sort-header-container"
                }, W().createElement("div", {
                    className: s
                }, W().createElement("h2", {
                    className: "sort-header"
                }, u ? W().createElement("span", null, t) : W().createElement(ge.Link, {
                    url: r
                }, t), m && W().createElement(it, {
                    tooltipText: m
                })), !u && W().createElement(ge.Link, {
                    url: r,
                    onClick: e,
                    className: "btn-secondary-xs see-all-link-icon btn-more"
                }, v)), W().createElement(en, {
                    defaultSubtitle: n,
                    endTimestamp: c,
                    countdownString: d,
                    isSortLinkOverrideEnabled: a,
                    seeAllLink: r,
                    handleSeeAllLinkClick: e,
                    backgroundImageAssetId: f
                }))
            }).defaultProps = {
                sortSubtitle: void 0,
                tooltipInfoText: void 0,
                hideSeeAll: void 0,
                endTimestamp: void 0,
                countdownString: void 0,
                buildNavigateToSortLinkEventProperties: void 0,
                backgroundImageAssetId: void 0
            };
            var sn = tr,
                un = function() {
                    return (un = Object.assign || function(e) {
                        for (var t, n = 1, r = arguments.length; n < r; n++)
                            for (var a in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
                        return e
                    }).apply(this, arguments)
                };
            (ae = function(e) {
                var t = e.translate,
                    n = e.friendsPresence,
                    r = e.gameData,
                    a = e.sort,
                    o = e.positionId,
                    i = e.componentType,
                    l = e.playerCountStyle,
                    s = e.playButtonStyle,
                    u = e.hoverStyle,
                    c = e.tooltipInfoText,
                    d = e.hideSeeAll,
                    f = e.navigationRootPlaceId,
                    p = e.isSponsoredFooterAllowed,
                    m = e.seeAllLinkPath,
                    v = e.itemsPerRow,
                    h = e.startingRow,
                    g = e.endTimestamp,
                    y = e.countdownString,
                    b = e.isExpandHomeContentEnabled,
                    I = (0, V.useRef)(null),
                    P = (0, V.useRef)(null),
                    E = Xt(),
                    S = (0, V.useCallback)(function(e) {
                        if (void 0 !== r && void 0 !== h) {
                            var t = e.filter(function(e) {
                                return e < (null == r ? void 0 : r.length)
                            });
                            return un(un(un(un(un(((e = {})[x.RootPlaceIds] = t.map(function(e) {
                                return r[e].placeId
                            }), e[x.UniverseIds] = t.map(function(e) {
                                return r[e].universeId
                            }), e), j(r, a.topicId, t, i)), J(r, a.topicId, t, i)), M(r, t)), Y(h, null == r ? void 0 : r.length, null == r ? void 0 : r.length, t)), ((e = {})[x.NavigationUids] = t.map(function(e) {
                                return null !== (e = r[e].navigationUid) && void 0 !== e ? e : "0"
                            }), e[x.AbsPositions] = t, e[x.SortPos] = o, e[x.GameSetTypeId] = a.topicId, e[x.Page] = T.HomePage, e[L.HomePageSessionInfo] = E, e))
                        }
                    }, [r, E, o, a.topicId, i, h]);
                tn(I, r.length, S), (0, V.useEffect)(function() {
                    b && v && null != I && I.current && I.current.style.setProperty("--items-per-row", v.toString())
                }, [b, v]);
                var w = (0, V.useMemo)(function() {
                        return m ? C.urlService.getAbsoluteUrl(m) : _(a.topic, T.HomePage, {
                            position: o,
                            sortId: a.topicId,
                            page: T.HomePage,
                            treatmentType: a.treatmentType,
                            homePageSessionInfo: E
                        })
                    }, [E, o, a.topic, a.topicId, a.treatmentType, m]),
                    e = (0, V.useCallback)(function() {
                        var e;
                        if (m) return (e = {})[x.LinkPath] = m, e[x.SortPos] = o, e[x.GameSetTypeId] = a.topicId, e[x.Page] = T.HomePage, e[L.HomePageSessionInfo] = E, e
                    }, [E, o, m, a.topicId]);
                return W().createElement(ln, {
                    backgroundImageAssetId: null !== (S = a.topicLayoutData) && void 0 !== S && S.backgroundImageAssetId ? parseInt(null === (S = a.topicLayoutData) || void 0 === S ? void 0 : S.backgroundImageAssetId, 10) : void 0
                }, W().createElement(sn, {
                    sortTitle: a.topic,
                    sortSubtitle: a.subtitle,
                    seeAllLink: w,
                    isSortLinkOverrideEnabled: !!m,
                    buildNavigateToSortLinkEventProperties: e,
                    shouldShowSponsoredTooltip: a.topicId === ke.adSortHomePageId,
                    tooltipInfoText: c,
                    titleContainerClassName: "container-header",
                    hideSeeAll: d,
                    endTimestamp: g,
                    countdownString: y,
                    backgroundImageAssetId: null !== (y = a.topicLayoutData) && void 0 !== y && y.backgroundImageAssetId ? parseInt(null === (y = a.topicLayoutData) || void 0 === y ? void 0 : y.backgroundImageAssetId, 10) : void 0,
                    translate: t
                }), W().createElement(Yt, {
                    ref: I,
                    tileRef: P,
                    gameData: r,
                    friendData: n,
                    buildEventProperties: function(e, t) {
                        var n = {};
                        return n[x.PlaceId] = e.placeId, n[x.UniverseId] = e.universeId, n[x.IsAd] = e.isSponsored, n[x.NativeAdData] = e.nativeAdData, n[x.Position] = t, n[x.SortPos] = o, n[x.NumberOfLoadedTiles] = (r || []).length, n[x.GameSetTypeId] = a.topicId, n[x.Page] = T.HomePage, n[L.HomePageSessionInfo] = E, n[x.PlayContext] = T.HomePage, n
                    },
                    translate: t,
                    componentType: i,
                    playerCountStyle: l,
                    playButtonStyle: s,
                    navigationRootPlaceId: f,
                    isSponsoredFooterAllowed: p,
                    hoverStyle: u,
                    topicId: null === (u = a.topicId) || void 0 === u ? void 0 : u.toString(),
                    isExpandHomeContentEnabled: b
                }))
            }).defaultProps = {
                componentType: void 0,
                playerCountStyle: void 0,
                playButtonStyle: void 0,
                hoverStyle: void 0,
                tooltipInfoText: void 0,
                hideSeeAll: void 0,
                navigationRootPlaceId: void 0,
                isSponsoredFooterAllowed: void 0,
                seeAllLinkPath: void 0,
                itemsPerRow: void 0,
                endTimestamp: void 0,
                countdownString: void 0,
                isExpandHomeContentEnabled: void 0
            };
            var cn = ae,
                dn = function() {
                    return (dn = Object.assign || function(e) {
                        for (var t, n = 1, r = arguments.length; n < r; n++)
                            for (var a in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
                        return e
                    }).apply(this, arguments)
                },
                fn = function(e, i, l, s) {
                    return new(l = l || Promise)(function(n, t) {
                        function r(e) {
                            try {
                                o(s.next(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function a(e) {
                            try {
                                o(s.throw(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function o(e) {
                            var t;
                            e.done ? n(e.value) : ((t = e.value) instanceof l ? t : new l(function(e) {
                                e(t)
                            })).then(r, a)
                        }
                        o((s = s.apply(e, i || [])).next())
                    })
                },
                pn = function(n, r) {
                    var a, o, i, l = {
                            label: 0,
                            sent: function() {
                                if (1 & i[0]) throw i[1];
                                return i[1]
                            },
                            trys: [],
                            ops: []
                        },
                        e = {
                            next: t(0),
                            throw: t(1),
                            return: t(2)
                        };
                    return "function" == typeof Symbol && (e[Symbol.iterator] = function() {
                        return this
                    }), e;

                    function t(t) {
                        return function(e) {
                            return function(t) {
                                if (a) throw new TypeError("Generator is already executing.");
                                for (; l;) try {
                                    if (a = 1, o && (i = 2 & t[0] ? o.return : t[0] ? o.throw || ((i = o.return) && i.call(o), 0) : o.next) && !(i = i.call(o, t[1])).done) return i;
                                    switch (o = 0, i && (t = [2 & t[0], i.value]), t[0]) {
                                        case 0:
                                        case 1:
                                            i = t;
                                            break;
                                        case 4:
                                            return l.label++, {
                                                value: t[1],
                                                done: !1
                                            };
                                        case 5:
                                            l.label++, o = t[1], t = [0];
                                            continue;
                                        case 7:
                                            t = l.ops.pop(), l.trys.pop();
                                            continue;
                                        default:
                                            if (!(i = 0 < (i = l.trys).length && i[i.length - 1]) && (6 === t[0] || 2 === t[0])) {
                                                l = 0;
                                                continue
                                            }
                                            if (3 === t[0] && (!i || t[1] > i[0] && t[1] < i[3])) {
                                                l.label = t[1];
                                                break
                                            }
                                            if (6 === t[0] && l.label < i[1]) {
                                                l.label = i[1], i = t;
                                                break
                                            }
                                            if (i && l.label < i[2]) {
                                                l.label = i[2], l.ops.push(t);
                                                break
                                            }
                                            i[2] && l.ops.pop(), l.trys.pop();
                                            continue
                                    }
                                    t = r.call(n, l)
                                } catch (e) {
                                    t = [6, e], o = 0
                                } finally {
                                    a = i = 0
                                }
                                if (5 & t[0]) throw t[1];
                                return {
                                    value: t[0] ? t[1] : void 0,
                                    done: !0
                                }
                            }([t, e])
                        }
                    }
                };

            function mn() {
                function r(e) {
                    (e.detail || []).forEach(function(e) {
                        o.current[e.userId] && (o.current[e.userId] = dn(dn({}, o.current[e.userId]), {
                            presence: e
                        }))
                    }), a(dn({}, o.current))
                }
                var e = this,
                    t = (0, V.useState)({}),
                    n = t[0],
                    a = t[1],
                    o = (0, V.useRef)(n);
                return (0, V.useEffect)(function() {
                    return fn(e, void 0, void 0, function() {
                            var t, n;
                            return pn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        if ((null == (t = Ie.deviceMeta.getDeviceMeta()) ? void 0 : t.deviceType) !== Ie.deviceMeta.DeviceTypes.computer) return [3, 4];
                                        e.label = 1;
                                    case 1:
                                        return e.trys.push([1, 3, , 4]), [4, Le()];
                                    case 2:
                                        return n = e.sent().userData, n = (n || []).reduce(function(e, t) {
                                            return e[t.id] = t, e
                                        }, {}), o.current = n, a(dn({}, o.current)), document.addEventListener("Roblox.Presence.Update", r), [3, 4];
                                    case 3:
                                        return n = e.sent(), console.error("useFriendsPresence failed to initialized with the error", n), [3, 4];
                                    case 4:
                                        return [2]
                                }
                            })
                        }),
                        function() {
                            document.removeEventListener("Roblox.Presence.Update", r)
                        }
                }, []), Object.values(n)
            }

            function vn() {
                var e = (0, V.useContext)(xn);
                return {
                    contentMetadata: e.contentMetadata,
                    appendContentMetadata: e.appendContentMetadata
                }
            }

            function hn(e, r) {
                return e.map(function(e) {
                    var t = e.contentType,
                        n = e.contentId,
                        e = e.contentMetadata,
                        t = null === (t = null == r ? void 0 : r[t]) || void 0 === t ? void 0 : t[n];
                    if (t) {
                        n = Ln({}, t), e = null == e ? void 0 : e.EncryptedAdTrackingData;
                        return n.isSponsored = 0 < (null == e ? void 0 : e.length), n.nativeAdData = e, n
                    }
                    return t
                }).filter(function(e) {
                    return void 0 !== e
                })
            }

            function gn(e) {
                return "recommendationList" in e
            }

            function yn(e) {
                return "games" in e
            }

            function bn(e) {
                return "filters" in e
            }

            function In(e, t) {
                return "recommendationList" in e ? hn(e.recommendationList, t) : yn(e) ? e.games : []
            }

            function Pn(e) {
                if (e && yn(e)) return e.gameSetTargetId
            }

            function En(e) {
                var t = Pn(e);
                return void 0 !== t ? ((e = {})[x.GameSetTargetId] = t, e) : {}
            }

            function Sn(e) {
                if (e = e.find(bn)) {
                    var t = new Map;
                    return e.filters.forEach(function(e) {
                        t.set(e.filterType, e.selectedOptionId)
                    }), t
                }
            }

            function wn(e) {
                var t;
                return e && yn(e) && e.appliedFilters ? ((t = {})[x.AppliedFilters] = encodeURIComponent(e.appliedFilters), t) : {}
            }

            function Cn(e) {
                var t = e.scrollClassNames,
                    n = e.scrollIconClassName,
                    r = e.scroll,
                    e = e.isDisabled;
                return W().createElement("div", {
                    "data-testid": "game-carousel-scroll-bar",
                    className: t,
                    onClick: r,
                    "aria-disabled": e,
                    onKeyDown: function(e) {
                        e.code === Nn.enter && (e.stopPropagation(), e.preventDefault(), r())
                    },
                    role: "button",
                    tabIndex: 0
                }, W().createElement("div", {
                    className: "arrow"
                }, W().createElement("span", {
                    className: n
                })), W().createElement("div", {
                    className: "spacer"
                }))
            }

            function Tn(e) {
                var t = e.distance,
                    n = e.scrollAreaSize,
                    r = e.direction,
                    a = e.startingPosition,
                    o = e.currentPage,
                    i = e.pageSession,
                    l = e.gameSetTypeId,
                    s = e.gameSetTargetId,
                    u = e.sortPosition,
                    e = ((e = {})[x.StartPos] = a, e[x.Distance] = t, e[x.Direction] = r, e[x.PageSession] = i, e[x.GameSetTypeId] = l, e[x.GameSetTargetId] = s, e[x.SortPos] = u, e[x.ScrollDepth] = t / n, e[x.StartDepth] = a / n, e[x.ScreenSizeX] = window.innerWidth, e[x.ScreenSizeY] = window.innerHeight, e[x.ScrollAreaSize] = n, e);
                h.EventStream.SendEventWithTarget(y.FeedScroll, o, e, h.EventStream.TargetTypes.WWW)
            }

            function _n(e) {
                var t = e.scrollPosition,
                    n = e.page,
                    r = e.gameSetTypeId,
                    a = e.gameSetTargetId,
                    o = e.sortPosition,
                    i = e.wrapperRef,
                    l = (0, V.useRef)(t),
                    s = Xt(),
                    u = (0, V.useMemo)(function() {
                        return Vt(function(e) {
                            var t;
                            e !== l.current && (t = Math.round((null === (t = i.current) || void 0 === t ? void 0 : t.getBoundingClientRect().width) || window.innerWidth), Tn({
                                distance: e - l.current,
                                scrollAreaSize: t,
                                startingPosition: l.current,
                                currentPage: n,
                                direction: b.Horizontal,
                                gameSetTypeId: r,
                                gameSetTargetId: a,
                                sortPosition: o,
                                pageSession: s
                            }), l.current = e)
                        }, 250)[0]
                    }, [n, r, a, o, s]);
                (0, V.useEffect)(function() {
                    u(t)
                }, [u, t])
            }
            var xn = (0, V.createContext)({
                    contentMetadata: null,
                    appendContentMetadata: function() {}
                }),
                Ln = function() {
                    return (Ln = Object.assign || function(e) {
                        for (var t, n = 1, r = arguments.length; n < r; n++)
                            for (var a in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
                        return e
                    }).apply(this, arguments)
                },
                Nn = Re.keyBoardEventCode,
                Dn = Ge.numGameCarouselLookAheadWindows,
                An = Ge.gameTileGutterWidth,
                kn = Ge.wideGameTileGutterWidth;
            (tr = function(e) {
                var t = e.gameData,
                    n = e.sort,
                    r = e.positionId,
                    a = e.page,
                    o = e.gamesContainerRef,
                    i = e.buildEventProperties,
                    l = e.loadMoreGames,
                    s = e.isLoadingMoreGames,
                    u = e.componentType,
                    c = e.playerCountStyle,
                    d = e.playButtonStyle,
                    f = e.itemsPerRow,
                    p = e.translate,
                    m = (0, V.useRef)(null),
                    v = (0, V.useRef)(null),
                    h = (0, V.useState)(0),
                    g = h[0],
                    y = h[1],
                    e = (0, V.useState)(!1),
                    b = e[0],
                    I = e[1],
                    h = (0, V.useState)(!0),
                    P = h[0],
                    E = h[1],
                    e = (0, V.useState)(!0),
                    S = e[0],
                    w = e[1],
                    h = (0, V.useState)(),
                    C = h[0],
                    T = h[1],
                    e = (0, V.useState)(0),
                    _ = e[0],
                    x = e[1],
                    L = (0, V.useMemo)(function() {
                        return u === (F.GridTile || u === F.EventTile) ? kn : An
                    }, [u]),
                    h = (0, V.useCallback)(function(t) {
                        function e() {
                            var e = null === (e = null == t ? void 0 : t.getBoundingClientRect()) || void 0 === e ? void 0 : e.width;
                            e && T(e)
                        }
                        return e(), window.addEventListener("resize", e),
                            function() {
                                window.removeEventListener("resize", e)
                            }
                    }, []),
                    N = (0, V.useMemo)(function() {
                        if ((u === F.GridTile || u === F.EventTile) && f) return f;
                        var e = null === (e = null === (e = null == v ? void 0 : v.current) || void 0 === e ? void 0 : e.getBoundingClientRect()) || void 0 === e ? void 0 : e.width;
                        return void 0 !== C && void 0 !== e ? Math.max(1, Math.floor((C + L) / (e + L))) : 0
                    }, [C, L, f, u]);
                (0, V.useEffect)(function() {
                    var e;
                    E(0 <= _), s ? w(!0) : (e = null === (e = null == m ? void 0 : m.current) || void 0 === e ? void 0 : e.getBoundingClientRect().width, void 0 !== C && void 0 !== e && Math.abs(_) + C >= e ? w(!0) : w(!1))
                }, [_, C, null == t ? void 0 : t.length, s]);
                var D = (0, V.useCallback)(function() {
                        g + Dn * N >= (null == t ? void 0 : t.length) && l && !s && l()
                    }, [g, N, l, s, null == t ? void 0 : t.length]),
                    A = (0, V.useCallback)(function() {
                        var e = null === (e = null === (e = null == v ? void 0 : v.current) || void 0 === e ? void 0 : e.getBoundingClientRect()) || void 0 === e ? void 0 : e.width;
                        return void 0 === e ? 0 : N * (e + L)
                    }, [N, L]),
                    k = (0, V.useCallback)(function() {
                        var t;
                        P || (t = A(), x(function(e) {
                            return Math.min(e + t, 0)
                        }), y(function(e) {
                            return e - N
                        }))
                    }, [A, P, N]),
                    O = (0, V.useCallback)(function() {
                        var n;
                        S || (n = A(), x(function(e) {
                            if (null != m && m.current) {
                                var t = null === (t = m.current.getBoundingClientRect()) || void 0 === t ? void 0 : t.width;
                                return Math.max(e - n, -1 * t)
                            }
                            return e - n
                        }), y(function(e) {
                            return e + N
                        }), D())
                    }, [D, A, S, N]),
                    R = (0, V.useCallback)(function(e) {
                        return g <= e && e < g + N
                    }, [g, N]),
                    U = (0, V.useCallback)(function(e) {
                        b || (I(!0), e(), setTimeout(function() {
                            I(!1)
                        }, 200))
                    }, [b]),
                    e = (0, V.useRef)(null);
                _n({
                    scrollPosition: -_,
                    page: a,
                    gameSetTypeId: n.topicId,
                    gameSetTargetId: Pn(n),
                    wrapperRef: e,
                    sortPosition: r
                });
                r = (0, V.useMemo)(function() {
                    return u === F.GridTile ? "game-carousel games-page-carousel wide-game-tile-carousel" : "hlist games game-cards game-tile-list"
                }, [u]);
                return W().createElement("div", {
                    "data-testid": "game-carousel",
                    ref: e,
                    className: "horizontal-scroller games-list"
                }, W().createElement("div", {
                    ref: h,
                    className: "clearfix horizontal-scroll-window"
                }, W().createElement("div", {
                    ref: m,
                    className: "horizontally-scrollable",
                    style: {
                        left: _ + "px"
                    }
                }, W().createElement("ul", {
                    ref: o,
                    className: r
                }, t.map(function(e, t) {
                    return u === F.GridTile ? W().createElement(Jt, {
                        key: e.universeId,
                        ref: v,
                        id: t,
                        isOnScreen: R(t),
                        page: a,
                        gameData: e,
                        translate: p,
                        buildEventProperties: i,
                        componentType: u,
                        playerCountStyle: c,
                        playButtonStyle: d
                    }) : W().createElement("li", {
                        key: e.universeId,
                        className: "list-item game-card game-tile"
                    }, W().createElement(Jt, {
                        ref: v,
                        id: t,
                        isOnScreen: R(t),
                        page: a,
                        gameData: e,
                        className: "game-card-container",
                        translate: p,
                        buildEventProperties: i
                    }))
                }))), W().createElement(Cn, {
                    scrollClassNames: he()("scroller", "prev", {
                        disabled: P
                    }),
                    scrollIconClassName: "icon-games-carousel-left",
                    isDisabled: P,
                    scroll: function() {
                        return U(k)
                    }
                }), W().createElement(Cn, {
                    scrollClassNames: he()("scroller", "next", {
                        disabled: S
                    }),
                    scrollIconClassName: "icon-games-carousel-right",
                    isDisabled: S,
                    scroll: function() {
                        return U(O)
                    }
                })))
            }).defaultProps = {
                loadMoreGames: void 0,
                componentType: void 0,
                itemsPerRow: void 0,
                playerCountStyle: void 0,
                playButtonStyle: void 0
            };
            var On = tr,
                Rn = function() {
                    return (Rn = Object.assign || function(e) {
                        for (var t, n = 1, r = arguments.length; n < r; n++)
                            for (var a in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
                        return e
                    }).apply(this, arguments)
                };
            (ae = function(e) {
                var t = e.translate,
                    r = e.gameData,
                    a = e.sort,
                    o = e.page,
                    i = e.positionId,
                    n = e.isLoadingMoreGames,
                    l = e.loadMoreGames,
                    s = e.tooltipInfoText,
                    u = e.hideSeeAll,
                    c = e.componentType,
                    d = e.playerCountStyle,
                    f = e.playButtonStyle,
                    p = e.itemsPerRow,
                    m = e.isChartsPageRenameEnabled,
                    v = (0, V.useRef)(null),
                    h = Xt(),
                    e = (0, V.useCallback)(function(e) {
                        if (void 0 !== r) {
                            var t = e.filter(function(e) {
                                return e < (null == r ? void 0 : r.length)
                            });
                            return Rn(Rn(Rn(Rn(Rn(((e = {})[x.RootPlaceIds] = t.map(function(e) {
                                return r[e].placeId
                            }), e[x.UniverseIds] = t.map(function(e) {
                                return r[e].universeId
                            }), e), M(r, t)), ((e = {})[x.AbsPositions] = t, e[x.SortPos] = i, e[x.GameSetTypeId] = a.topicId, e)), En(a)), wn(a)), ((e = {})[x.Page] = o, e[x.NumberOfLoadedTiles] = (r || []).length, e[L.DiscoverPageSessionInfo] = h, e))
                        }
                    }, [r, h, i, a, o]);
                tn(v, r.length, e), (0, V.useEffect)(function() {
                    p && null != v && v.current && v.current.style.setProperty("--items-per-row", p.toString())
                }, [p]);
                e = (0, V.useMemo)(function() {
                    var e = Rn(Rn(((e = {})[x.Position] = i, e[x.GameSetTypeId] = a.topicId, e), En(a)), ((t = {})[x.Page] = o, t[x.TreatmentType] = E.Carousel, t[L.DiscoverPageSessionInfo] = h, t)),
                        t = function(e) {
                            if (yn(e) && e.appliedFilters) {
                                var n = {};
                                return e.appliedFilters.split(",").forEach(function(e) {
                                    var t = e.split("="),
                                        e = t[0],
                                        t = t[1];
                                    e && t && (n[e] = t)
                                }), n
                            }
                            return {}
                        }(a);
                    return _(a.sortId, o, e, m, t)
                }, [h, o, i, a, m]);
                return W().createElement("div", {
                    className: he()("games-list-container", {
                        "wide-game-tile-container": c === F.GridTile || c === F.EventTile
                    })
                }, W().createElement(sn, {
                    sortTitle: a.topic,
                    sortSubtitle: a.subtitle,
                    seeAllLink: e,
                    isSortLinkOverrideEnabled: !1,
                    shouldShowSponsoredTooltip: a.topicId === Oe.adSortDiscoverId,
                    tooltipInfoText: s,
                    titleContainerClassName: "container-header games-filter-changer",
                    hideSeeAll: u,
                    translate: t
                }), W().createElement(On, {
                    gamesContainerRef: v,
                    gameData: r,
                    sort: a,
                    positionId: i,
                    loadMoreGames: l,
                    isLoadingMoreGames: n,
                    buildEventProperties: function(e, t) {
                        var n;
                        return Rn(Rn(Rn(Rn(((n = {})[x.PlaceId] = e.placeId, n[x.UniverseId] = e.universeId, n[x.IsAd] = e.isSponsored, n[x.NativeAdData] = e.nativeAdData, n[x.Position] = t, n[x.SortPos] = i, n[x.GameSetTypeId] = a.topicId, n), En(a)), ((n = {})[x.NumberOfLoadedTiles] = (r || []).length, n[x.Page] = o, n)), wn(a)), ((n = {})[L.DiscoverPageSessionInfo] = h, n[x.PlayContext] = T.GamesPage, n))
                    },
                    translate: t,
                    page: o,
                    componentType: c,
                    playerCountStyle: d,
                    playButtonStyle: f,
                    itemsPerRow: p
                }))
            }).defaultProps = {
                loadMoreGames: void 0,
                tooltipInfoText: void 0,
                hideSeeAll: void 0,
                componentType: void 0,
                itemsPerRow: void 0,
                playerCountStyle: void 0,
                playButtonStyle: void 0,
                isChartsPageRenameEnabled: void 0
            };
            var Un = ae;

            function Mn(e) {
                var t = e.sort,
                    a = vn().contentMetadata;
                return 0 === (null == (e = (0, V.useMemo)(function() {
                    return t.recommendationList.map(function(e) {
                        var t, n = e.contentType,
                            r = e.contentId,
                            e = null === (t = null == a ? void 0 : a[n]) || void 0 === t ? void 0 : t[r];
                        return e && ((t = e).itemId = r, t.itemType = n), e
                    }).filter(function(e) {
                        return e
                    }).slice(0, Fn)
                }, [t.recommendationList, a])) ? void 0 : e.length) ? null : W().createElement(h.AvatarShopHomepageRecommendations, {
                    recommendedItems: e
                })
            }

            function Gn(e) {
                var t = e.loadData,
                    n = (0, V.useRef)(null),
                    r = (0, V.useRef)(null);
                return (0, V.useEffect)(function() {
                    var e = n.current;
                    return e && (r.current = S.elementVisibilityService.observeVisibility({
                            element: e,
                            threshold: Ue
                        }, function(e) {
                            e && t && t()
                        })),
                        function() {
                            null != r && r.current && r.current()
                        }
                }, [t]), t ? W().createElement("div", {
                    ref: n,
                    "data-testid": "sentinel-tile",
                    className: "grid-item-container game-card-container invisible"
                }) : null
            }(Ge = function(e) {
                var t = e.translate,
                    n = e.sort,
                    r = e.positionId,
                    a = e.page,
                    o = e.itemsPerRow,
                    i = e.startingRow,
                    l = e.loadMoreGames,
                    s = e.isLoadingMoreGames,
                    u = e.isExpandHomeContentEnabled,
                    c = e.isChartsPageRenameEnabled,
                    d = mn(),
                    f = vn().contentMetadata,
                    e = (0, V.useMemo)(function() {
                        var e;
                        return u ? In(n, f).slice(0, o) : In(n, f).slice(0, function(e, t) {
                            var n = ke.maxWideGameTilesPerCarouselPage,
                                r = ke.maxTilesPerCarouselPage;
                            if (e !== T.GamesPage) switch (t) {
                                case F.GridTile:
                                case F.EventTile:
                                case F.InterestTile:
                                    return n;
                                case F.AppGameTileNoMetadata:
                                default:
                                    return r
                            }
                        }(a, null === (e = n.topicLayoutData) || void 0 === e ? void 0 : e.componentType))
                    }, [n, f, a, o, u]);
                return 0 === (null == e ? void 0 : e.length) ? null : a === T.GamesPage ? W().createElement(Un, {
                    key: n.topic,
                    sort: n,
                    translate: t,
                    positionId: r,
                    page: a,
                    gameData: e,
                    loadMoreGames: l,
                    isLoadingMoreGames: !0 === s,
                    tooltipInfoText: null === (s = n.topicLayoutData) || void 0 === s ? void 0 : s.infoText,
                    hideSeeAll: "true" === (null === (s = n.topicLayoutData) || void 0 === s ? void 0 : s.hideSeeAll),
                    componentType: null === (s = n.topicLayoutData) || void 0 === s ? void 0 : s.componentType,
                    playerCountStyle: null === (s = n.topicLayoutData) || void 0 === s ? void 0 : s.playerCountStyle,
                    playButtonStyle: null === (s = n.topicLayoutData) || void 0 === s ? void 0 : s.playButtonStyle,
                    itemsPerRow: o,
                    isChartsPageRenameEnabled: c
                }) : W().createElement(cn, {
                    key: n.topic,
                    sort: n,
                    translate: t,
                    positionId: r,
                    gameData: e,
                    friendsPresence: d,
                    itemsPerRow: o,
                    startingRow: i,
                    componentType: null === (i = n.topicLayoutData) || void 0 === i ? void 0 : i.componentType,
                    playerCountStyle: null === (i = n.topicLayoutData) || void 0 === i ? void 0 : i.playerCountStyle,
                    playButtonStyle: null === (i = n.topicLayoutData) || void 0 === i ? void 0 : i.playButtonStyle,
                    hoverStyle: null === (i = n.topicLayoutData) || void 0 === i ? void 0 : i.hoverStyle,
                    tooltipInfoText: null === (i = n.topicLayoutData) || void 0 === i ? void 0 : i.infoText,
                    hideSeeAll: "true" === (null === (i = n.topicLayoutData) || void 0 === i ? void 0 : i.hideSeeAll),
                    navigationRootPlaceId: null === (i = n.topicLayoutData) || void 0 === i ? void 0 : i.navigationRootPlaceId,
                    isSponsoredFooterAllowed: "true" === (null === (i = n.topicLayoutData) || void 0 === i ? void 0 : i.isSponsoredFooterAllowed),
                    seeAllLinkPath: null === (i = n.topicLayoutData) || void 0 === i ? void 0 : i.linkPath,
                    endTimestamp: null === (i = n.topicLayoutData) || void 0 === i ? void 0 : i.endTimestamp,
                    countdownString: null === (i = n.topicLayoutData) || void 0 === i ? void 0 : i.countdownString,
                    isExpandHomeContentEnabled: u
                })
            }).defaultProps = {
                loadMoreGames: void 0,
                isLoadingMoreGames: void 0,
                isExpandHomeContentEnabled: void 0,
                isChartsPageRenameEnabled: void 0
            };
            var jn = Ge,
                Fn = ke.maxTilesPerCarouselPage;

            function Bn(e) {
                var t = e.universeId,
                    n = e.creatorName,
                    r = e.creatorType,
                    a = e.creatorId,
                    o = e.linkUrl,
                    i = e.isCreatorVerified,
                    l = e.translate,
                    e = (0, V.useRef)(null);
                return W().createElement("div", {
                    ref: e,
                    className: "game-card-creator-name",
                    "data-testid": "game-card-creator-name"
                }, W().createElement("span", {
                    className: "text-label creator-name-label"
                }, l(Fe.LabelByPrefix), " "), W().createElement("a", {
                    href: o,
                    onClick: function() {
                        h.EventStream.SendEventWithTarget("buttonClick", "featuredTileCreatorLabel", {
                            creatorId: a,
                            creatorType: r,
                            universeId: t
                        }, h.EventStream.TargetTypes.WWW)
                    },
                    className: "text-overflow text-label creator-name"
                }, n), i && W().createElement(Hn.VerifiedBadgeIconContainer, {
                    size: Hn.BadgeSizes.CAPTIONHEADER
                }))
            }
            Gn.displayName = "SentinelTile", Gn.defaultProps = {
                loadData: null
            };
            var Hn = Ua(9589),
                zn = function(e, i, l, s) {
                    return new(l = l || Promise)(function(n, t) {
                        function r(e) {
                            try {
                                o(s.next(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function a(e) {
                            try {
                                o(s.throw(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function o(e) {
                            var t;
                            e.done ? n(e.value) : ((t = e.value) instanceof l ? t : new l(function(e) {
                                e(t)
                            })).then(r, a)
                        }
                        o((s = s.apply(e, i || [])).next())
                    })
                },
                Vn = function(n, r) {
                    var a, o, i, l = {
                            label: 0,
                            sent: function() {
                                if (1 & i[0]) throw i[1];
                                return i[1]
                            },
                            trys: [],
                            ops: []
                        },
                        e = {
                            next: t(0),
                            throw: t(1),
                            return: t(2)
                        };
                    return "function" == typeof Symbol && (e[Symbol.iterator] = function() {
                        return this
                    }), e;

                    function t(t) {
                        return function(e) {
                            return function(t) {
                                if (a) throw new TypeError("Generator is already executing.");
                                for (; l;) try {
                                    if (a = 1, o && (i = 2 & t[0] ? o.return : t[0] ? o.throw || ((i = o.return) && i.call(o), 0) : o.next) && !(i = i.call(o, t[1])).done) return i;
                                    switch (o = 0, i && (t = [2 & t[0], i.value]), t[0]) {
                                        case 0:
                                        case 1:
                                            i = t;
                                            break;
                                        case 4:
                                            return l.label++, {
                                                value: t[1],
                                                done: !1
                                            };
                                        case 5:
                                            l.label++, o = t[1], t = [0];
                                            continue;
                                        case 7:
                                            t = l.ops.pop(), l.trys.pop();
                                            continue;
                                        default:
                                            if (!(i = 0 < (i = l.trys).length && i[i.length - 1]) && (6 === t[0] || 2 === t[0])) {
                                                l = 0;
                                                continue
                                            }
                                            if (3 === t[0] && (!i || t[1] > i[0] && t[1] < i[3])) {
                                                l.label = t[1];
                                                break
                                            }
                                            if (6 === t[0] && l.label < i[1]) {
                                                l.label = i[1], i = t;
                                                break
                                            }
                                            if (i && l.label < i[2]) {
                                                l.label = i[2], l.ops.push(t);
                                                break
                                            }
                                            i[2] && l.ops.pop(), l.trys.pop();
                                            continue
                                    }
                                    t = r.call(n, l)
                                } catch (e) {
                                    t = [6, e], o = 0
                                } finally {
                                    a = i = 0
                                }
                                if (5 & t[0]) throw t[1];
                                return {
                                    value: t[0] ? t[1] : void 0,
                                    done: !0
                                }
                            }([t, e])
                        }
                    }
                },
                Wn = (0, V.forwardRef)(function(e, t) {
                    var n = e.id,
                        r = e.buildEventProperties,
                        a = e.gameData,
                        o = e.translate,
                        i = (0, V.useState)(),
                        l = i[0],
                        s = i[1],
                        u = mn(),
                        c = (0, V.useMemo)(function() {
                            return Z(u, a.universeId)
                        }, [u, a.universeId]),
                        e = (0, V.useMemo)(function() {
                            return 0 < c.length && l ? W().createElement(St, {
                                gameData: l,
                                friendData: c,
                                translate: o
                            }) : W().createElement("div", {
                                className: "game-card-description-info font-body",
                                "data-testid": "featured-grid-tile-description"
                            }, null == l ? void 0 : l.description)
                        }, [c]);
                    (0, V.useEffect)(function() {
                        zn(void 0, void 0, void 0, function() {
                            var t;
                            return Vn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return e.trys.push([0, 2, , 3]), [4, De(a.placeId.toString())];
                                    case 1:
                                        return t = e.sent(), s(t), [3, 3];
                                    case 2:
                                        return t = e.sent(), console.error(t), [3, 3];
                                    case 3:
                                        return [2]
                                }
                            })
                        })
                    }, []);
                    var i = v(a.placeId, a.name, r(a, n)),
                        n = r(a, n);
                    return W().createElement("div", {
                        ref: t,
                        className: "featured-grid-item-container game-card-container",
                        "data-testid": "game-tile-featured"
                    }, W().createElement(ge.Link, {
                        url: i,
                        className: "game-card-link",
                        id: a.universeId.toString()
                    }, W().createElement(Ae.Thumbnail2d, {
                        type: Ae.ThumbnailTypes.gameIcon,
                        size: Ae.ThumbnailGameIconSize.size512,
                        targetId: a.universeId,
                        containerClass: "game-card-thumb-container",
                        format: Ae.ThumbnailFormat.jpeg,
                        altName: a.name
                    }), W().createElement("div", {
                        className: "game-card-name-info"
                    }, W().createElement("div", null, W().createElement("div", {
                        className: "game-card-name game-name-title",
                        title: a.name
                    }, a.name), W().createElement(pt, {
                        totalUpVotes: a.totalUpVotes,
                        totalDownVotes: a.totalDownVotes,
                        playerCount: a.playerCount
                    })), W().createElement(Gt, {
                        universeId: a.universeId.toString(),
                        placeId: a.placeId.toString(),
                        playButtonEventProperties: n
                    })), null !== a.creatorName && W().createElement(Bn, {
                        universeId: a.universeId.toString(),
                        creatorId: a.creatorId,
                        creatorType: a.creatorType,
                        creatorName: a.creatorName,
                        isCreatorVerified: null !== (n = a.creatorHasVerifiedBadge) && void 0 !== n && n,
                        linkUrl: i,
                        translate: o
                    }), e))
                });
            Wn.displayName = "FeaturedGridTile";
            var $n = function() {
                    return ($n = Object.assign || function(e) {
                        for (var t, n = 1, r = arguments.length; n < r; n++)
                            for (var a in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
                        return e
                    }).apply(this, arguments)
                },
                qn = function(e, t) {
                    var n = {};
                    for (a in e) Object.prototype.hasOwnProperty.call(e, a) && t.indexOf(a) < 0 && (n[a] = e[a]);
                    if (null != e && "function" == typeof Object.getOwnPropertySymbols)
                        for (var r = 0, a = Object.getOwnPropertySymbols(e); r < a.length; r++) t.indexOf(a[r]) < 0 && Object.prototype.propertyIsEnumerable.call(e, a[r]) && (n[a[r]] = e[a[r]]);
                    return n
                };
            (tr = (0, V.forwardRef)(function(e, t) {
                var n = e.emphasis,
                    r = e.friendData,
                    a = e.componentType,
                    o = e.playerCountStyle,
                    i = e.playButtonStyle,
                    l = e.isSponsoredFooterAllowed,
                    s = e.hoverStyle,
                    u = e.topicId,
                    c = e.isInterestedUniverse,
                    d = e.toggleInterest,
                    e = qn(e, ["emphasis", "friendData", "componentType", "playerCountStyle", "playButtonStyle", "isSponsoredFooterAllowed", "hoverStyle", "topicId", "isInterestedUniverse", "toggleInterest"]);
                return n ? W().createElement(Wn, $n({
                    ref: t
                }, e)) : W().createElement(Jt, $n({
                    ref: t,
                    friendData: r,
                    componentType: a,
                    playerCountStyle: o,
                    playButtonStyle: i,
                    isSponsoredFooterAllowed: l,
                    hoverStyle: s,
                    topicId: u,
                    isInterestedUniverse: c,
                    toggleInterest: d
                }, e))
            })).displayName = "GameGridTile", tr.defaultProps = {
                friendData: [],
                componentType: void 0,
                playerCountStyle: void 0,
                playButtonStyle: void 0,
                isSponsoredFooterAllowed: void 0,
                hoverStyle: void 0,
                topicId: void 0,
                isInterestedUniverse: void 0,
                toggleInterest: void 0
            };
            var Zn = tr,
                Kn = (0, V.forwardRef)(function(e, t) {
                    var n = e.gameData,
                        r = e.translate,
                        a = e.emphasis,
                        o = e.buildEventProperties,
                        i = e.tileRef,
                        l = e.loadData,
                        s = e.shouldUseSentinelTile,
                        u = e.friendsPresence,
                        c = e.componentType,
                        d = e.playerCountStyle,
                        f = e.playButtonStyle,
                        p = e.isHomeGameGrid,
                        m = e.isSponsoredFooterAllowed,
                        v = e.hoverStyle,
                        h = e.topicId,
                        g = e.isExpandHomeContentEnabled,
                        y = e.interestedUniverses,
                        b = e.toggleInterest,
                        g = he()("game-grid", {
                            "home-game-grid": p
                        }, {
                            "wide-game-tile-game-grid": c === F.GridTile || c === F.EventTile || c === F.InterestTile
                        }, {
                            "interest-tile-game-grid": c === F.InterestTile
                        }, {
                            "expand-home-content": g
                        }, {
                            "expand-home-content-disabled": !g
                        });
                    return W().createElement("div", {
                        "data-testid": "game-grid",
                        ref: t,
                        className: g
                    }, n.map(function(e, t) {
                        return W().createElement(Zn, {
                            ref: function(e) {
                                (!0 === a && 1 === t || !1 === a && 0 === t) && i && (i.current = e)
                            },
                            key: e.universeId,
                            id: t,
                            gameData: e,
                            translate: r,
                            buildEventProperties: o,
                            emphasis: !0 === a && 0 === t && !p,
                            friendData: u,
                            componentType: c,
                            playerCountStyle: d,
                            playButtonStyle: f,
                            isSponsoredFooterAllowed: m,
                            hoverStyle: v,
                            topicId: h,
                            isInterestedUniverse: null == y ? void 0 : y.has(e.universeId),
                            toggleInterest: b ? function() {
                                return b(e.universeId)
                            } : void 0
                        })
                    }), s && W().createElement(Gn, {
                        loadData: l
                    }))
                });
            Kn.displayName = "GameGrid", Kn.defaultProps = {
                friendsPresence: [],
                componentType: void 0,
                playerCountStyle: void 0,
                playButtonStyle: void 0,
                isHomeGameGrid: !1,
                isSponsoredFooterAllowed: void 0,
                hoverStyle: void 0,
                topicId: void 0,
                isExpandHomeContentEnabled: void 0,
                interestedUniverses: void 0,
                toggleInterest: void 0
            };
            var Jn = Kn,
                Yn = function() {
                    return (Yn = Object.assign || function(e) {
                        for (var t, n = 1, r = arguments.length; n < r; n++)
                            for (var a in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
                        return e
                    }).apply(this, arguments)
                };
            (ae = function(e) {
                var r = e.gameData,
                    a = e.sort,
                    o = e.positionId,
                    t = e.friendsPresence,
                    n = e.componentType,
                    i = e.playerCountStyle,
                    l = e.playButtonStyle,
                    s = e.hoverStyle,
                    u = e.itemsPerRow,
                    c = e.startingRow,
                    d = e.isSponsoredFooterAllowed,
                    f = e.isExpandHomeContentEnabled,
                    p = e.translate,
                    m = (0, V.useRef)(null),
                    v = (0, V.useRef)(null),
                    h = Xt(),
                    e = (0, V.useCallback)(function(e) {
                        if (void 0 !== r && void 0 !== c) {
                            var t = e.filter(function(e) {
                                return e < (null == r ? void 0 : r.length)
                            });
                            return Yn(Yn(Yn(Yn(Yn(Yn(((e = {})[x.RootPlaceIds] = t.map(function(e) {
                                return r[e].placeId
                            }), e[x.UniverseIds] = t.map(function(e) {
                                return r[e].universeId
                            }), e), j(r, a.topicId, t, n)), J(r, a.topicId, t, n)), ((e = {})[x.NavigationUids] = t.map(function(e) {
                                return null !== (e = r[e].navigationUid) && void 0 !== e ? e : "0"
                            }), e[x.AbsPositions] = t, e)), M(r, t)), Y(c, u, null == r ? void 0 : r.length, t)), ((t = {})[x.SortPos] = o, t[x.NumberOfLoadedTiles] = null == r ? void 0 : r.length, t[x.GameSetTypeId] = a.topicId, t[x.Page] = T.HomePage, t[L.HomePageSessionInfo] = h, t))
                        }
                    }, [r, h, o, a.topicId, n, u, c]);
                return tn(m, r.length, e), (0, V.useEffect)(function() {
                    u && null != m && m.current && m.current.style.setProperty("--items-per-row", u.toString())
                }, [u]), W().createElement("div", {
                    "data-testid": "home-page-game-grid"
                }, W().createElement("div", {
                    className: "container-header"
                }, W().createElement("h2", null, a.topic, a.topicId === ke.adSortHomePageId && W().createElement(it, {
                    tooltipText: p(Be.LabelSponsoredAdsDisclosureStatic) || "Sponsored experiences are paid for by Creators. They may be shown to you based on general information about your device type, location, and demographics."
                }))), W().createElement(Kn, {
                    ref: m,
                    tileRef: v,
                    gameData: r,
                    emphasis: !1,
                    translate: p,
                    buildEventProperties: function(e, t) {
                        var n = {};
                        return n[x.PlaceId] = e.placeId, n[x.UniverseId] = e.universeId, n[x.IsAd] = e.isSponsored, n[x.NativeAdData] = e.nativeAdData, n[x.Position] = t, n[x.SortPos] = o, n[x.NumberOfLoadedTiles] = (r || []).length, n[x.GameSetTypeId] = a.topicId, n[x.Page] = T.HomePage, n[L.HomePageSessionInfo] = h, n[x.PlayContext] = T.HomePage, n
                    },
                    isHomeGameGrid: !0,
                    friendsPresence: t,
                    componentType: n,
                    playerCountStyle: i,
                    playButtonStyle: l,
                    isSponsoredFooterAllowed: d,
                    hoverStyle: s,
                    topicId: null === (s = a.topicId) || void 0 === s ? void 0 : s.toString(),
                    isExpandHomeContentEnabled: f
                }))
            }).defaultProps = {
                componentType: void 0,
                playerCountStyle: void 0,
                playButtonStyle: void 0,
                hoverStyle: void 0,
                itemsPerRow: void 0,
                isSponsoredFooterAllowed: void 0,
                isExpandHomeContentEnabled: void 0
            };
            var Qn = ae,
                Xn = ke.sortlessGridMaxTilesMetadataToFetch;
            (Ge = function(e) {
                var t = e.translate,
                    n = e.sort,
                    r = e.positionId,
                    a = e.itemsPerRow,
                    o = e.startingRow,
                    i = e.recommendations,
                    l = e.isExpandHomeContentEnabled,
                    s = mn(),
                    u = Xt(),
                    e = vn(),
                    c = e.contentMetadata,
                    d = e.appendContentMetadata,
                    f = (0, V.useCallback)(function() {
                        var e = i.filter(function(e) {
                            var t = e.contentType,
                                e = e.contentId;
                            return !(null !== (t = null == c ? void 0 : c[t]) && void 0 !== t && t[e])
                        });
                        0 < e.length && me(e.slice(0, Xn), u).then(function(e) {
                            return d(e.contentMetadata)
                        }).catch(function() {})
                    }, [i, u, c, d]);
                (0, V.useEffect)(function() {
                    f()
                }, [f]);
                e = (0, V.useMemo)(function() {
                    return hn(i, c)
                }, [i, c]);
                return 0 === (null == e ? void 0 : e.length) ? null : W().createElement(Qn, {
                    key: n.topic,
                    sort: n,
                    gameData: e,
                    translate: t,
                    positionId: r,
                    itemsPerRow: a,
                    startingRow: o,
                    friendsPresence: s,
                    componentType: null === (s = n.topicLayoutData) || void 0 === s ? void 0 : s.componentType,
                    playerCountStyle: null === (s = n.topicLayoutData) || void 0 === s ? void 0 : s.playerCountStyle,
                    playButtonStyle: null === (s = n.topicLayoutData) || void 0 === s ? void 0 : s.playButtonStyle,
                    hoverStyle: null === (s = n.topicLayoutData) || void 0 === s ? void 0 : s.hoverStyle,
                    isSponsoredFooterAllowed: "true" === (null === (n = n.topicLayoutData) || void 0 === n ? void 0 : n.isSponsoredFooterAllowed),
                    isExpandHomeContentEnabled: l
                })
            }).defaultProps = {
                isExpandHomeContentEnabled: void 0
            };
            var er = Ge,
                tr = Ua(5734),
                nr = Ua.n(tr),
                ae = Ua(3544),
                Ge = Ua(895);
            (0, ae.importFilesUnderPath)(Ua(1191)), (0, ae.importFilesUnderPath)(Ua(7389)), (0, ae.importFilesUnderPath)(Ua(8475)), (0, ae.importFilesUnderPath)(Ua(8051));
            var tr = Ua(6506),
                rr = (0, ae.templateCacheGenerator)(nr(), "peopleListHtmlTemplateApp", tr);

            function ar() {
                var e = (0, V.useRef)(null);
                return (0, V.useEffect)(function() {
                    if (null != e && e.current) try {
                        nr().bootstrap(e.current, [sr.name, rr.name])
                    } catch (e) {
                        (0, w.fireEvent)(ke.friendsCarouselAngularBootstrapErrorEvent)
                    }
                }, []), W().createElement("div", {
                    className: "friend-carousel-container"
                }, W().createElement("div", {
                    ref: e,
                    "people-list-container": ""
                }))
            }

            function or(e) {
                var t = e.friendsCount,
                    n = e.translate,
                    e = "(" + (null != t ? t : 0) + ")";
                return W().createElement("div", {
                    className: "container-header people-list-header"
                }, null == t ? W().createElement("h2", null, n("Heading.Friends")) : W().createElement("h2", null, n("Heading.Friends"), W().createElement("span", {
                    className: "friends-count"
                }, e)), W().createElement("a", {
                    href: h.EnvironmentUrls.websiteUrl + "/users/friends#!/friends",
                    className: "btn-secondary-xs btn-more see-all-link-icon"
                }, n("Heading.SeeAll")))
            }

            function ir(e) {
                var t = e.id,
                    n = e.userProfileUrl,
                    r = e.translate,
                    e = W().createElement(Ae.Thumbnail2d, {
                        type: Ae.ThumbnailTypes.avatarHeadshot,
                        size: Ae.DefaultThumbnailSize,
                        targetId: t,
                        containerClass: "avatar-card-image"
                    });
                return W().createElement(ge.AvatarCardItem.Headshot, {
                    statusIcon: W().createElement(mr().PresenceStatusIcon, {
                        translate: r,
                        userId: t
                    }),
                    thumbnail: e,
                    imageLink: n
                })
            }

            function lr(e) {
                var t = e.id,
                    n = e.displayName,
                    r = e.userProfileUrl,
                    a = e.userPresence,
                    o = e.hasVerifiedBadge,
                    e = e.translate;
                return W().createElement("div", {
                    className: "friend-tile-content"
                }, W().createElement(ir, {
                    id: t,
                    translate: e,
                    userProfileUrl: r
                }), W().createElement("a", {
                    href: r,
                    className: "friends-carousel-tile-labels"
                }, W().createElement("div", {
                    className: "friends-carousel-tile-label"
                }, W().createElement("div", {
                    className: "friends-carousel-tile-name"
                }, W().createElement("span", {
                    className: "friends-carousel-display-name"
                }, n), o && W().createElement("div", {
                    className: "friend-tile-verified-badge"
                }, W().createElement("div", {
                    className: "friend-tile-spacer"
                }), W().createElement(Hn.VerifiedBadgeIconContainer, {
                    size: Hn.BadgeSizes.SUBHEADER,
                    additionalContainerClass: "verified-badge"
                })))), null != a && W().createElement("div", {
                    className: "friends-carousel-tile-sublabel"
                }, W().createElement("div", {
                    className: "friends-carousel-tile-experience"
                }, a))))
            }
            nr().element("#people-list-container").hasClass("no-self-bootstrap") && (window.peopleList = Ge.Z);
            var sr = Ge.Z,
                ur = function(e, i, l, s) {
                    return new(l = l || Promise)(function(n, t) {
                        function r(e) {
                            try {
                                o(s.next(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function a(e) {
                            try {
                                o(s.throw(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function o(e) {
                            var t;
                            e.done ? n(e.value) : ((t = e.value) instanceof l ? t : new l(function(e) {
                                e(t)
                            })).then(r, a)
                        }
                        o((s = s.apply(e, i || [])).next())
                    })
                },
                cr = function(n, r) {
                    var a, o, i, l = {
                            label: 0,
                            sent: function() {
                                if (1 & i[0]) throw i[1];
                                return i[1]
                            },
                            trys: [],
                            ops: []
                        },
                        e = {
                            next: t(0),
                            throw: t(1),
                            return: t(2)
                        };
                    return "function" == typeof Symbol && (e[Symbol.iterator] = function() {
                        return this
                    }), e;

                    function t(t) {
                        return function(e) {
                            return function(t) {
                                if (a) throw new TypeError("Generator is already executing.");
                                for (; l;) try {
                                    if (a = 1, o && (i = 2 & t[0] ? o.return : t[0] ? o.throw || ((i = o.return) && i.call(o), 0) : o.next) && !(i = i.call(o, t[1])).done) return i;
                                    switch (o = 0, i && (t = [2 & t[0], i.value]), t[0]) {
                                        case 0:
                                        case 1:
                                            i = t;
                                            break;
                                        case 4:
                                            return l.label++, {
                                                value: t[1],
                                                done: !1
                                            };
                                        case 5:
                                            l.label++, o = t[1], t = [0];
                                            continue;
                                        case 7:
                                            t = l.ops.pop(), l.trys.pop();
                                            continue;
                                        default:
                                            if (!(i = 0 < (i = l.trys).length && i[i.length - 1]) && (6 === t[0] || 2 === t[0])) {
                                                l = 0;
                                                continue
                                            }
                                            if (3 === t[0] && (!i || t[1] > i[0] && t[1] < i[3])) {
                                                l.label = t[1];
                                                break
                                            }
                                            if (6 === t[0] && l.label < i[1]) {
                                                l.label = i[1], i = t;
                                                break
                                            }
                                            if (i && l.label < i[2]) {
                                                l.label = i[2], l.ops.push(t);
                                                break
                                            }
                                            i[2] && l.ops.pop(), l.trys.pop();
                                            continue
                                    }
                                    t = r.call(n, l)
                                } catch (e) {
                                    t = [6, e], o = 0
                                } finally {
                                    a = i = 0
                                }
                                if (5 & t[0]) throw t[1];
                                return {
                                    value: t[0] ? t[1] : void 0,
                                    done: !0
                                }
                            }([t, e])
                        }
                    }
                },
                dr = function(e, t) {
                    for (var n = 0, r = t.length, a = e.length; n < r; n++, a++) e[a] = t[n];
                    return e
                },
                fr = function(n) {
                    return ur(void 0, void 0, Promise, function() {
                        var t;
                        return cr(this, function(e) {
                            switch (e.label) {
                                case 0:
                                    return t = {
                                        url: h.EnvironmentUrls.friendsApi + "/v1/users/" + n + "/friends/count",
                                        retryable: !0,
                                        withCredentials: !0
                                    }, [4, C.httpService.get(t)];
                                case 1:
                                    return [2, e.sent().data]
                            }
                        })
                    })
                },
                pr = function(m, v) {
                    return ur(void 0, void 0, Promise, function() {
                        var t, i, l, s, u, c, d, f, p;
                        return cr(this, function(e) {
                            switch (e.label) {
                                case 0:
                                    return v ? [4, (o = m, ur(void 0, void 0, Promise, function() {
                                        var t;
                                        return cr(this, function(e) {
                                            switch (e.label) {
                                                case 0:
                                                    return t = {
                                                        url: h.EnvironmentUrls.friendsApi + "/v1/users/" + o + "/friends/online",
                                                        retryable: !0,
                                                        withCredentials: !0
                                                    }, [4, C.httpService.get(t)];
                                                case 1:
                                                    return [2, e.sent().data]
                                            }
                                        })
                                    }))] : [3, 2];
                                case 1:
                                    return i = e.sent().data, [3, 3];
                                case 2:
                                    i = [], e.label = 3;
                                case 3:
                                    return (t = i).sort(function(e, t) {
                                        var n = {
                                                InGame: 0,
                                                Online: 1,
                                                InStudio: 2
                                            },
                                            e = e.userPresence.UserPresenceType,
                                            t = t.userPresence.UserPresenceType;
                                        return !(e in n && t in n) || n[e] < n[t] ? -1 : 1
                                    }), [4, (n = m, a = v, ur(void 0, void 0, Promise, function() {
                                        var t;
                                        return cr(this, function(e) {
                                            switch (e.label) {
                                                case 0:
                                                    return t = h.EnvironmentUrls.friendsApi + "/v1/users/" + n + "/friends/find", t = {
                                                        url: a ? t + "?userSort=1" : t,
                                                        retryable: !0,
                                                        withCredentials: !0
                                                    }, [4, C.httpService.get(t)];
                                                case 1:
                                                    return [2, e.sent().data]
                                            }
                                        })
                                    }))];
                                case 4:
                                    for (f = e.sent().PageItems, l = new Map, s = 0, u = t; s < u.length; s++) c = u[s], l.set(c.id, c.userPresence);
                                    return d = t.map(function(e) {
                                        return e.id
                                    }), f = f.filter(function(e) {
                                        return !d.includes(e.id)
                                    }).map(function(e) {
                                        return e.id
                                    }), f = dr(dr([], d), f), [4, (r = f, ur(void 0, void 0, Promise, function() {
                                        var t, n;
                                        return cr(this, function(e) {
                                            switch (e.label) {
                                                case 0:
                                                    return t = {
                                                        url: h.EnvironmentUrls.apiGatewayUrl + "/user-profile-api/v1/user/profiles/get-profiles",
                                                        retryable: !0,
                                                        withCredentials: !0
                                                    }, n = {
                                                        userIds: r,
                                                        fields: ["names.combinedName", "isVerified"]
                                                    }, [4, C.httpService.post(t, n)];
                                                case 1:
                                                    return [2, e.sent().data]
                                            }
                                        })
                                    }))];
                                case 5:
                                    return f = e.sent().profileDetails, p = [], f.forEach(function(e) {
                                        var t, n, r, a, o = l.has(e.userId),
                                            i = {
                                                isOnline: o,
                                                isInGame: o && "InGame" === (null === (t = l.get(e.userId)) || void 0 === t ? void 0 : t.UserPresenceType),
                                                lastLocation: !o || null === (n = l.get(e.userId)) || void 0 === n ? void 0 : n.lastLocation,
                                                gameId: !o || null === (r = l.get(e.userId)) || void 0 === r ? void 0 : r.gameInstanceId,
                                                universeId: !o || null === (a = l.get(e.userId)) || void 0 === a ? void 0 : a.universeId,
                                                placeId: !o || null === (i = l.get(e.userId)) || void 0 === i ? void 0 : i.placeId
                                            };
                                        p.push({
                                            id: e.userId,
                                            combinedName: e.names.combinedName,
                                            presence: i,
                                            hasVerifiedBadge: e.isVerified
                                        })
                                    }), [2, p]
                            }
                            var r, n, a, o
                        })
                    })
                },
                tr = {
                    common: [],
                    feature: "Feature.PeopleList"
                },
                Ge = RobloxPresence,
                mr = Ua.n(Ge);

            function vr(t, e) {
                var n, r = Object.keys(t);
                return Object.getOwnPropertySymbols && (n = Object.getOwnPropertySymbols(t), e && (n = n.filter(function(e) {
                    return Object.getOwnPropertyDescriptor(t, e).enumerable
                })), r.push.apply(r, n)), r
            }

            function hr(r) {
                for (var e = 1; e < arguments.length; e++) {
                    var a = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? vr(Object(a), !0).forEach(function(e) {
                        var t, n;
                        t = r, e = a[n = e], n in t ? Object.defineProperty(t, n, {
                            value: e,
                            enumerable: !0,
                            configurable: !0,
                            writable: !0
                        }) : t[n] = e
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(r, Object.getOwnPropertyDescriptors(a)) : vr(Object(a)).forEach(function(e) {
                        Object.defineProperty(r, e, Object.getOwnPropertyDescriptor(a, e))
                    })
                }
                return r
            }

            function gr() {
                return void 0 !== h.EventStream
            }

            function yr(e, t, n, r) {
                gr() && h.EventStream.SendEventWithTarget && (r = Object.values(Sr).includes(r) ? r : Sr.WWW, h.EventStream.SendEventWithTarget(e, t, n, r))
            }

            function br(e) {
                var n = e.friend,
                    t = e.displayName,
                    r = e.userProfileUrl,
                    a = e.userPresence,
                    o = e.gameUrl,
                    i = e.translate;
                return W().createElement("div", {
                    className: "friend-tile-dropdown"
                }, n.presence.isInGame && W().createElement("div", {
                    className: "in-game-friend-card"
                }, W().createElement("button", {
                    type: "button",
                    className: "friend-tile-non-styled-button",
                    onClick: function() {
                        window.open(o)
                    }
                }, W().createElement(Ae.Thumbnail2d, {
                    type: Ae.ThumbnailTypes.gameIcon,
                    size: Ae.ThumbnailGameIconSize.size150,
                    targetId: null !== (e = n.presence.universeId) && void 0 !== e ? e : 0,
                    imgClassName: "game-card-thumb",
                    containerClass: "friend-tile-game-card"
                })), W().createElement("div", {
                    className: "friend-presence-info"
                }, W().createElement("button", {
                    type: "button",
                    className: "friend-tile-non-styled-button",
                    onClick: function() {
                        window.open(o)
                    }
                }, a), W().createElement(ge.Button, {
                    variant: ge.Button.variants.growth,
                    size: ge.Button.sizes.small,
                    width: ge.Button.widths.full,
                    onClick: function() {
                        return Tr(void 0, void 0, void 0, function() {
                            var t;
                            return _r(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return (t = n.presence.gameId || "", (0, h.DeviceMeta)().isInApp) ? ((0, h.DeviceMeta)().isDesktop ? h.GameLauncher.followPlayerIntoGame(n.id, t, "JoinUser") : window.location.href = "/games/start?userID=" + n.id + "&joinAttemptId=" + t + "&joinAttemptOrigin=JoinUser", [3, 5]) : [3, 1];
                                    case 1:
                                        return (0, h.DeviceMeta)().isAndroidDevice || (0, h.DeviceMeta)().isChromeOs ? (window.location.href = "intent://userId=" + n.id + "&joinAttemptId=" + t + "&joinAttemptOrigin=JoinUser#Intent;scheme=robloxmobile;package=com.roblox.client;S.browser_fallback_url=https%3A%2F%2Fplay.google.com%2Fstore%2Fapps%2Fdetails%3Fid%3Dcom.roblox.client;end", [3, 5]) : [3, 2];
                                    case 2:
                                        return (0, h.DeviceMeta)().isIosDevice ? (window.location.href = "robloxmobile://userId=" + n.id + "&joinAttemptId=" + t + "&joinAttemptOrigin=JoinUser", [3, 5]) : [3, 3];
                                    case 3:
                                        return [4, h.ProtocolHandlerClientInterface.followPlayerIntoGame({
                                            userId: n.id,
                                            joinAttemptId: t,
                                            joinAttemptOrigin: "JoinUser"
                                        })];
                                    case 4:
                                        e.sent(), e.label = 5;
                                    case 5:
                                        return [2]
                                }
                            })
                        })
                    }
                }, i("Action.Join")))), W().createElement("ul", null, W().createElement("li", null, W().createElement("button", {
                    type: "button",
                    className: "friend-tile-dropdown-button",
                    onClick: function() {
                        Cr({
                            userId: n.id
                        })
                    }
                }, W().createElement("span", {
                    className: "icon icon-chat-gray"
                }), " ", i("Label.Chat", {
                    username: t
                }))), W().createElement("li", null, W().createElement("button", {
                    type: "button",
                    className: "friend-tile-dropdown-button",
                    onClick: function() {
                        window.open(r)
                    }
                }, W().createElement("span", {
                    className: "icon icon-viewdetails"
                }), " ", i("Label.ViewProfile")))))
            }

            function Ir(e) {
                function t() {
                    l(!0)
                }

                function n(e) {
                    var t;
                    null == e || null !== (t = s.current) && void 0 !== t && t.contains(e.relatedTarget) || null !== (t = u.current) && void 0 !== t && t.contains(e.relatedTarget) || l(!1)
                }
                var r = e.trigger,
                    a = e.content,
                    o = e.dropdownWidth,
                    i = (0, V.useState)(!1),
                    e = i[0],
                    l = i[1],
                    s = (0, V.useRef)(null),
                    u = (0, V.useRef)(null);
                return (0, V.useEffect)(function() {
                    return s.current ? (s.current.addEventListener("mouseover", t), s.current.addEventListener("mouseout", n), function() {
                        var e;
                        null !== (e = s.current) && void 0 !== e && e.removeEventListener("mouseover", t), null !== (e = s.current) && void 0 !== e && e.removeEventListener("mouseout", n)
                    }) : function() {}
                }, []), W().createElement("div", null, W().createElement("div", {
                    ref: s
                }, r), e && W().createElement("div", {
                    ref: u,
                    style: {
                        position: "absolute",
                        top: ((null === (e = s.current) || void 0 === e ? void 0 : e.offsetHeight) || 0) + ((null === (e = s.current) || void 0 === e ? void 0 : e.offsetTop) || 0),
                        left: ((null === (e = s.current) || void 0 === e ? void 0 : e.offsetLeft) || 0) + ((null === (e = s.current) || void 0 === e ? void 0 : e.offsetWidth) || 0) / 2 - o / 2,
                        zIndex: 1002,
                        width: o
                    },
                    onMouseOver: t,
                    onMouseOut: n,
                    onFocus: t,
                    onBlur: n
                }, a))
            }

            function Pr(e) {
                var t = e.friend,
                    n = e.isOwnUser,
                    r = e.translate,
                    a = h.EnvironmentUrls.websiteUrl + "/users/" + t.id + "/profile",
                    o = t.combinedName,
                    i = null != t.presence && t.presence.isInGame ? t.presence.lastLocation : null,
                    e = null != i && 15 < i.length ? i.slice(0, 15) + "..." : i,
                    l = null != t.presence && t.presence.isInGame ? h.EnvironmentUrls.websiteUrl + "/games/" + (null !== (l = t.presence.placeId) && void 0 !== l ? l : "") : "";
                return W().createElement("div", {
                    className: "friends-carousel-tile"
                }, W().createElement(Ir, {
                    trigger: W().createElement("button", {
                        type: "button",
                        className: "options-dropdown",
                        id: "friend-tile-button",
                        onClick: function() {}
                    }, W().createElement(lr, {
                        id: t.id,
                        displayName: o,
                        userProfileUrl: a,
                        userPresence: e,
                        translate: r,
                        hasVerifiedBadge: t.hasVerifiedBadge
                    })),
                    content: n ? W().createElement(br, {
                        friend: t,
                        displayName: o,
                        userProfileUrl: a,
                        userPresence: i,
                        translate: r,
                        gameUrl: l
                    }) : W().createElement("div", null),
                    dropdownWidth: null == e ? 240 : 315
                }))
            }

            function Er(e) {
                var t = e.friendsList,
                    n = e.isOwnUser,
                    r = e.translate,
                    a = (0, V.useRef)(null),
                    o = (e = (0, V.useState)(null != t ? t.length : 0))[0],
                    i = e[1];
                return (0, V.useEffect)(function() {
                    if (a.current) {
                        var e = function() {
                            var e, t = null !== (e = null === (e = a.current) || void 0 === e ? void 0 : e.offsetWidth) && void 0 !== e ? e : 0,
                                n = 0,
                                r = 0;
                            Array.from(null !== (e = null === (e = a.current) || void 0 === e ? void 0 : e.children) && void 0 !== e ? e : []).forEach(function(e) {
                                n + e.offsetWidth <= t && (r += 1, n += e.offsetWidth)
                            }), i(r)
                        };
                        e();
                        var t = new ResizeObserver(e);
                        return t.observe(a.current),
                            function() {
                                return t.disconnect()
                            }
                    }
                }, [t]), W().createElement("div", null, null == t ? W().createElement("span", {
                    className: "spinner spinner-default"
                }) : W().createElement("div", {
                    ref: function(e) {
                        return a.current = e, a.current
                    },
                    className: "friends-carousel-container"
                }, t.map(function(e, t) {
                    return W().createElement("div", {
                        key: e.id,
                        style: {
                            opacity: t < o ? 1 : 0
                        }
                    }, W().createElement(Pr, {
                        friend: e,
                        translate: r,
                        isOwnUser: n
                    }))
                })))
            }
            var Sr = hr(hr({}, {
                    DEFAULT: 0,
                    WWW: 1,
                    STUDIO: 2,
                    DIAGNOSTIC: 3
                }), gr() ? h.EventStream.TargetTypes : {}),
                wr = yr,
                Cr = function(e) {
                    var t, n, r, a = e.userId;
                    a ? ((r = h.DeviceMeta && new h.DeviceMeta) && r.isAndroidApp ? ((t = {
                        userIds: []
                    }).userIds.push(a), null !== (e = h.Hybrid.Chat) && void 0 !== e && e.startChatConversation(t)) : r && r.isIosApp ? null !== (t = h.Hybrid.Navigation) && void 0 !== t && t.startWebChatConversation(a) : r && r.isUWPApp ? null !== (n = h.Hybrid.Navigation) && void 0 !== n && n.startWebChatConversation(a) : r && r.isWin32App ? null !== (n = h.Hybrid.Navigation) && void 0 !== n && n.startWebChatConversation(a) : r && r.isUniversalApp ? null !== (r = h.Hybrid.Navigation) && void 0 !== r && r.startWebChatConversation(a) : $(document).triggerHandler("Roblox.Chat.StartChat", {
                        userId: a
                    }), wr("startChatByUser", "click", {
                        userId: a
                    })) : console.log("missing valid params to start web chat")
                },
                Tr = function(e, i, l, s) {
                    return new(l = l || Promise)(function(n, t) {
                        function r(e) {
                            try {
                                o(s.next(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function a(e) {
                            try {
                                o(s.throw(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function o(e) {
                            var t;
                            e.done ? n(e.value) : ((t = e.value) instanceof l ? t : new l(function(e) {
                                e(t)
                            })).then(r, a)
                        }
                        o((s = s.apply(e, i || [])).next())
                    })
                },
                _r = function(n, r) {
                    var a, o, i, l = {
                            label: 0,
                            sent: function() {
                                if (1 & i[0]) throw i[1];
                                return i[1]
                            },
                            trys: [],
                            ops: []
                        },
                        e = {
                            next: t(0),
                            throw: t(1),
                            return: t(2)
                        };
                    return "function" == typeof Symbol && (e[Symbol.iterator] = function() {
                        return this
                    }), e;

                    function t(t) {
                        return function(e) {
                            return function(t) {
                                if (a) throw new TypeError("Generator is already executing.");
                                for (; l;) try {
                                    if (a = 1, o && (i = 2 & t[0] ? o.return : t[0] ? o.throw || ((i = o.return) && i.call(o), 0) : o.next) && !(i = i.call(o, t[1])).done) return i;
                                    switch (o = 0, i && (t = [2 & t[0], i.value]), t[0]) {
                                        case 0:
                                        case 1:
                                            i = t;
                                            break;
                                        case 4:
                                            return l.label++, {
                                                value: t[1],
                                                done: !1
                                            };
                                        case 5:
                                            l.label++, o = t[1], t = [0];
                                            continue;
                                        case 7:
                                            t = l.ops.pop(), l.trys.pop();
                                            continue;
                                        default:
                                            if (!(i = 0 < (i = l.trys).length && i[i.length - 1]) && (6 === t[0] || 2 === t[0])) {
                                                l = 0;
                                                continue
                                            }
                                            if (3 === t[0] && (!i || t[1] > i[0] && t[1] < i[3])) {
                                                l.label = t[1];
                                                break
                                            }
                                            if (6 === t[0] && l.label < i[1]) {
                                                l.label = i[1], i = t;
                                                break
                                            }
                                            if (i && l.label < i[2]) {
                                                l.label = i[2], l.ops.push(t);
                                                break
                                            }
                                            i[2] && l.ops.pop(), l.trys.pop();
                                            continue
                                    }
                                    t = r.call(n, l)
                                } catch (e) {
                                    t = [6, e], o = 0
                                } finally {
                                    a = i = 0
                                }
                                if (5 & t[0]) throw t[1];
                                return {
                                    value: t[0] ? t[1] : void 0,
                                    done: !0
                                }
                            }([t, e])
                        }
                    }
                },
                xr = function(e, i, l, s) {
                    return new(l = l || Promise)(function(n, t) {
                        function r(e) {
                            try {
                                o(s.next(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function a(e) {
                            try {
                                o(s.throw(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function o(e) {
                            var t;
                            e.done ? n(e.value) : ((t = e.value) instanceof l ? t : new l(function(e) {
                                e(t)
                            })).then(r, a)
                        }
                        o((s = s.apply(e, i || [])).next())
                    })
                },
                Lr = function(n, r) {
                    var a, o, i, l = {
                            label: 0,
                            sent: function() {
                                if (1 & i[0]) throw i[1];
                                return i[1]
                            },
                            trys: [],
                            ops: []
                        },
                        e = {
                            next: t(0),
                            throw: t(1),
                            return: t(2)
                        };
                    return "function" == typeof Symbol && (e[Symbol.iterator] = function() {
                        return this
                    }), e;

                    function t(t) {
                        return function(e) {
                            return function(t) {
                                if (a) throw new TypeError("Generator is already executing.");
                                for (; l;) try {
                                    if (a = 1, o && (i = 2 & t[0] ? o.return : t[0] ? o.throw || ((i = o.return) && i.call(o), 0) : o.next) && !(i = i.call(o, t[1])).done) return i;
                                    switch (o = 0, i && (t = [2 & t[0], i.value]), t[0]) {
                                        case 0:
                                        case 1:
                                            i = t;
                                            break;
                                        case 4:
                                            return l.label++, {
                                                value: t[1],
                                                done: !1
                                            };
                                        case 5:
                                            l.label++, o = t[1], t = [0];
                                            continue;
                                        case 7:
                                            t = l.ops.pop(), l.trys.pop();
                                            continue;
                                        default:
                                            if (!(i = 0 < (i = l.trys).length && i[i.length - 1]) && (6 === t[0] || 2 === t[0])) {
                                                l = 0;
                                                continue
                                            }
                                            if (3 === t[0] && (!i || t[1] > i[0] && t[1] < i[3])) {
                                                l.label = t[1];
                                                break
                                            }
                                            if (6 === t[0] && l.label < i[1]) {
                                                l.label = i[1], i = t;
                                                break
                                            }
                                            if (i && l.label < i[2]) {
                                                l.label = i[2], l.ops.push(t);
                                                break
                                            }
                                            i[2] && l.ops.pop(), l.trys.pop();
                                            continue
                                    }
                                    t = r.call(n, l)
                                } catch (e) {
                                    t = [6, e], o = 0
                                } finally {
                                    a = i = 0
                                }
                                if (5 & t[0]) throw t[1];
                                return {
                                    value: t[0] ? t[1] : void 0,
                                    done: !0
                                }
                            }([t, e])
                        }
                    }
                };

            function Nr() {
                var e = document.querySelector('meta[name="user-data"]'),
                    t = e ? e.getAttribute("data-userid") : Number(null !== (t = h.CurrentUser.userId) && void 0 !== t ? t : "0");
                return W().createElement("div", {
                    className: "friend-carousel-container"
                }, W().createElement(Rr, {
                    profileUserId: t,
                    isOwnUser: !0
                }))
            }

            function Dr(e) {
                return e.isReactFriendsCarouselEnabled ? W().createElement(Nr, null) : W().createElement(ar, null)
            }

            function Ar(e) {
                var t = e.option,
                    n = e.isSelected,
                    r = e.setSelectedOptionId,
                    e = e.translate;
                return W().createElement("button", {
                    type: "button",
                    onClick: function() {
                        return r(t.optionId)
                    },
                    className: he()("filter-option", {
                        "selected-option": n
                    }),
                    "aria-label": e(n ? He.ActionDropdownSelected : He.ActionDropdownNotSelected, {
                        optionName: t.optionDisplayName
                    })
                }, W().createElement("span", null, t.optionDisplayName), n ? W().createElement("span", {
                    className: "icon-radio-check-circle-filled"
                }) : W().createElement("span", {
                    className: "icon-radio-check-circle"
                }))
            }

            function kr(e) {
                var t = e.filter,
                    n = e.dropdownContainerRef,
                    r = e.selectedOptionId,
                    a = e.setSelectedOptionId,
                    o = e.setIsDropdownOpen,
                    i = e.updateFilterValue,
                    l = e.sendFilterClickEvent,
                    s = e.translate,
                    e = (0, V.useCallback)(function() {
                        i(r), o(!1), l(t.filterId, N.Apply, r, t.selectedOptionId)
                    }, [r, i, o, t.filterId, t.selectedOptionId, l]),
                    u = (0, V.useCallback)(function() {
                        var e = r;
                        o(!1), a(t.selectedOptionId), l(t.filterId, N.CloseDropdown, t.selectedOptionId, e)
                    }, [t.selectedOptionId, o, l, t.filterId, a, r]),
                    c = (0, V.useCallback)(function(e) {
                        n.current && e.target instanceof Node && !n.current.contains(e.target) && u()
                    }, [u, n]),
                    d = (0, V.useCallback)(function(e) {
                        e.key === Ur.keyBoardEventCode.escape && u()
                    }, [u]);
                return (0, V.useEffect)(function() {
                    return document.addEventListener("mousedown", c), document.addEventListener("keydown", d),
                        function() {
                            document.removeEventListener("mousedown", c), document.removeEventListener("keydown", d)
                        }
                }, [c, d]), W().createElement("div", {
                    className: "filters-modal-container"
                }, W().createElement("div", {
                    className: "header-container"
                }, W().createElement("h3", null, t.filterDisplayName), W().createElement("div", null, W().createElement("button", {
                    type: "button",
                    className: "header-close-button",
                    onClick: function() {
                        return u()
                    },
                    "aria-label": s(He.ActionClose)
                }, W().createElement("span", {
                    className: "icon-close"
                })))), W().createElement("div", {
                    className: "filter-options-container"
                }, t.filterOptions.map(function(e, t) {
                    return W().createElement(W().Fragment, {
                        key: e.optionId
                    }, W().createElement(Ar, {
                        option: e,
                        isSelected: r === e.optionId,
                        setSelectedOptionId: a,
                        translate: s
                    }), 0 === t && W().createElement("div", {
                        className: "filter-option-divider"
                    }))
                })), W().createElement("div", {
                    className: "action-buttons-container"
                }, W().createElement(ge.Button, {
                    onClick: e,
                    variant: ge.Button.variants.primary,
                    size: ge.Button.sizes.medium,
                    width: ge.Button.widths.full,
                    className: "apply-button",
                    isDisabled: r === t.selectedOptionId
                }, s(Fe.ActionApply) || "Apply")))
            }

            function Or(e) {
                var r = e.filter,
                    t = e.updateFilterValue,
                    a = e.sendFilterClickEvent,
                    n = e.translate,
                    o = W().useRef(null),
                    i = (u = (0, V.useState)(!1))[0],
                    l = u[1],
                    s = (e = (0, V.useState)(r.selectedOptionId))[0],
                    u = e[1],
                    e = (0, V.useMemo)(function() {
                        var e = r.filterOptions.find(function(e) {
                            return e.optionId === r.selectedOptionId
                        });
                        return null == e ? void 0 : e.optionDisplayName
                    }, [r.selectedOptionId, r.filterOptions]);
                return W().createElement("div", {
                    ref: o
                }, W().createElement(ge.Button, {
                    onClick: function() {
                        l(function(e) {
                            var t = e ? N.CloseDropdown : N.OpenDropdown,
                                n = e ? s : void 0;
                            return a(r.filterId, t, r.selectedOptionId, n), !e
                        })
                    },
                    variant: i ? ge.Button.variants.primary : ge.Button.variants.secondary,
                    size: ge.Button.sizes.medium,
                    className: "filter-select"
                }, W().createElement("span", {
                    className: "filter-display-text"
                }, e), W().createElement("span", {
                    className: i ? "icon-expand-arrow-selected" : "icon-expand-arrow"
                })), i && W().createElement(kr, {
                    filter: r,
                    dropdownContainerRef: o,
                    selectedOptionId: s,
                    setSelectedOptionId: u,
                    setIsDropdownOpen: l,
                    updateFilterValue: t,
                    sendFilterClickEvent: a,
                    translate: n
                }))
            }(Ge = function(e) {
                var t = e.translate,
                    i = e.profileUserId,
                    l = e.isOwnUser,
                    n = (0, V.useState)(null),
                    r = n[0],
                    s = n[1],
                    e = (0, V.useState)(null),
                    n = e[0],
                    u = e[1];
                return (0, V.useEffect)(function() {
                    xr(void 0, void 0, void 0, function() {
                        var n, r, a, o;
                        return Lr(this, function(e) {
                            switch (e.label) {
                                case 0:
                                    return a = [fr(i), pr(i, l)], [4, (t = a, Promise.all(t.map(function(e) {
                                        return e.then(function(e) {
                                            return {
                                                status: "fulfilled",
                                                value: e
                                            }
                                        })
                                    })))];
                                case 1:
                                    return o = e.sent(), n = o[0], r = o[1], a = n.value, o = r.value, s("fulfilled" === n.status ? a.count : 0), u("fulfilled" === r.status ? o : []), [2]
                            }
                            var t
                        })
                    }).catch(function(e) {
                        throw e
                    })
                }, [i]), 0 === r ? W().createElement("div", {
                    className: "friends-carousel-0-friends"
                }) : W().createElement("div", null, W().createElement(or, {
                    friendsCount: r,
                    translate: t
                }), W().createElement(Er, {
                    friendsList: n,
                    translate: t,
                    isOwnUser: l
                }))
            }).defaultProps = {
                translate: void 0
            };
            var Rr = (0, f.withTranslations)(Ge, tr),
                Ur = je,
                Mr = function() {
                    return (Mr = Object.assign || function(e) {
                        for (var t, n = 1, r = arguments.length; n < r; n++)
                            for (var a in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
                        return e
                    }).apply(this, arguments)
                },
                Gr = function(o, i, e) {
                    var l = Xt(),
                        t = (0, V.useRef)(null),
                        n = (0, V.useCallback)(function() {
                            var e = {};
                            return e[x.AbsPositions] = o.filters.map(function(e, t) {
                                return t
                            }), e[x.FilterIds] = o.filters.map(function(e) {
                                return e.filterId
                            }), e[x.SelectedOptionIds] = o.filters.map(function(e) {
                                return e.selectedOptionId
                            }), e[x.GameSetTypeId] = o.topicId, e[x.GameSetTargetId] = o.gameSetTargetId, e[x.SortPos] = i, e[L.DiscoverPageSessionInfo] = l, e[x.Page] = T.GamesPage, e
                        }, [o.filters, o.topicId, o.gameSetTargetId, i, l]);
                    (0, V.useEffect)(function() {
                        return null != e && e.current && (t.current = S.elementVisibilityService.observeVisibility({
                                element: e.current,
                                threshold: Re.filterImpressionsIntersectionThreshold
                            }, function(e) {
                                e && (e = n(), (e = ee.filterImpressions(e)) && S.eventStreamService.sendEvent.apply(S.eventStreamService, e), null != t && t.current && t.current())
                            })),
                            function() {
                                null != t && t.current && t.current()
                            }
                    }, [n, e]);
                    var a = (0, V.useCallback)(function(e, t, n, r) {
                        var a;
                        return Mr(((a = {})[x.ButtonName] = t, a[x.GameSetTypeId] = o.topicId, a[x.GameSetTargetId] = o.gameSetTargetId, a[x.SortPos] = i, a[L.DiscoverPageSessionInfo] = l, a[x.Page] = T.GamesPage, a[x.FilterId] = e, a[x.SelectedOptionId] = n, a), r && ((a = {})[x.PreviousOptionId] = r, a))
                    }, [o.topicId, o.gameSetTargetId, i, l]);
                    return (0, V.useCallback)(function(e, t, n, r) {
                        r = a(e, t, n, r), r = ee.gamesFilterClick(r);
                        r && S.eventStreamService.sendEvent.apply(S.eventStreamService, r)
                    }, [a])
                };
            (tr = function(e) {
                var a = e.sort,
                    t = e.positionId,
                    n = e.translate,
                    o = e.fetchGamesPageData,
                    e = (0, V.useRef)(null),
                    i = Gr(a, t, e);
                return W().createElement("div", {
                    ref: e,
                    className: "filters-container"
                }, W().createElement("div", {
                    className: "filters-header-container"
                }, W().createElement("span", {
                    className: "filters-header"
                }, a.topic)), W().createElement("div", {
                    className: "filter-items-container"
                }, a.filters.map(function(r) {
                    return W().createElement(Or, {
                        key: r.filterId,
                        filter: r,
                        updateFilterValue: function(e) {
                            return t = r.filterType, n = e, e = Sn([a]), void(o && e && (e.set(t, n), o(e)));
                            var t, n
                        },
                        sendFilterClickEvent: i,
                        translate: n
                    })
                })))
            }).defaultProps = {
                fetchGamesPageData: void 0
            };
            var jr = tr;

            function Fr() {
                return W().createElement("div", {
                    className: "grid-item-container game-card-container game-card-loading"
                }, W().createElement("div", {
                    className: "game-card-thumb-container shimmer"
                }), W().createElement("div", {
                    className: "game-card-name game-name-title shimmer"
                }), W().createElement("div", {
                    className: "game-card-name game-name-title game-name-title-half shimmer"
                }))
            }

            function Br(a) {
                var o = Xt();
                (0, V.useEffect)(function() {
                    var t = window.scrollY,
                        e = Vt(function() {
                            var e;
                            window.scrollY !== t && (e = null !== (e = null == (e = null === (e = document.getElementById("header")) || void 0 === e ? void 0 : e.getBoundingClientRect()) ? void 0 : e.bottom) && void 0 !== e ? e : 0, Tn({
                                distance: window.scrollY - t,
                                scrollAreaSize: window.innerHeight - e,
                                direction: b.Vertical,
                                startingPosition: t,
                                currentPage: a,
                                pageSession: o
                            }), t = window.scrollY)
                        }, 250),
                        n = e[0],
                        r = e[1];
                    return window.addEventListener("scroll", n),
                        function() {
                            window.removeEventListener("scroll", n), r()
                        }
                }, [a, o])
            }(je = function(e) {
                var t = e.translate,
                    n = e.sort,
                    r = e.positionId,
                    a = e.currentPage,
                    o = e.itemsPerRow,
                    i = e.startingRow,
                    l = e.gridRecommendations,
                    s = e.loadMoreGames,
                    u = e.isLoadingMoreGames,
                    c = e.isExpandHomeContentEnabled,
                    d = e.isChartsPageRenameEnabled,
                    f = e.fetchGamesPageData,
                    p = e.isReactFriendsCarouselEnabled;
                switch (n.treatmentType) {
                    case E.Carousel:
                        return W().createElement(jn, {
                            translate: t,
                            sort: n,
                            positionId: r,
                            page: a,
                            itemsPerRow: o,
                            startingRow: i,
                            loadMoreGames: s,
                            isLoadingMoreGames: u,
                            isExpandHomeContentEnabled: c,
                            isChartsPageRenameEnabled: d
                        });
                    case E.AvatarCarousel:
                        return W().createElement(Mn, {
                            sort: n
                        });
                    case E.SortlessGrid:
                        return W().createElement(er, {
                            translate: t,
                            sort: n,
                            positionId: r,
                            itemsPerRow: o,
                            startingRow: i,
                            recommendations: null != l ? l : [],
                            isExpandHomeContentEnabled: c
                        });
                    case E.FriendCarousel:
                        return W().createElement(Dr, {
                            isReactFriendsCarouselEnabled: p
                        });
                    case E.Pills:
                        return W().createElement(jr, {
                            sort: n,
                            positionId: r,
                            translate: t,
                            fetchGamesPageData: f
                        });
                    default:
                        return null
                }
            }).defaultProps = {
                loadMoreGames: void 0,
                isLoadingMoreGames: void 0,
                gridRecommendations: [],
                isExpandHomeContentEnabled: void 0,
                isChartsPageRenameEnabled: void 0,
                fetchGamesPageData: void 0
            };
            var Hr = je,
                zr = Ua(6635),
                Vr = function(e, a) {
                    var t = (0, V.useState)(new Map),
                        o = t[0],
                        n = t[1],
                        t = (0, V.useState)(new Map),
                        s = t[0],
                        i = t[1],
                        r = (0, f.usePrevious)(s),
                        l = (0, f.usePrevious)(null == e ? void 0 : e.sorts);
                    (0, V.useEffect)(function() {
                        void 0 !== r && (0, zr.isEqual)(s, r) && (0, zr.isEqual)(null == e ? void 0 : e.sorts, l) || function() {
                            var o = new Map,
                                i = new Map;
                            null != e && e.sorts.forEach(function(e) {
                                var t;
                                e.treatmentType === E.SortlessGrid && ((t = null !== (t = o.get(e.topicId)) && void 0 !== t ? t : []).push.apply(t, e.recommendationList), o.set(e.topicId, t))
                            });
                            var l = new Map;
                            null != e && e.sorts.forEach(function(e, t) {
                                var n, r, a;
                                e.treatmentType === E.SortlessGrid && (n = null !== (r = o.get(e.topicId)) && void 0 !== r ? r : [], r = null !== (a = i.get(e.topicId)) && void 0 !== a ? a : 0, void 0 !== e.numberOfRows && 0 <= e.numberOfRows ? (a = (null !== (a = s.get(t)) && void 0 !== a ? a : 0) * e.numberOfRows, l.set(t, n.slice(r, r + a)), i.set(e.topicId, r + a)) : (l.set(t, n.slice(r)), i.set(e.topicId, n.length)))
                            }), n(l)
                        }()
                    }, [null == e ? void 0 : e.sorts, l, s, r]);
                    var t = (0, V.useMemo)(function() {
                            var n = new Map,
                                r = 0;
                            return null != e && e.sorts.forEach(function(e, t) {
                                r && n.set(t, r);
                                t = function(e, t) {
                                    if (void 0 === e.numberOfRows) return (0, w.fireEvent)(ke.missingNumberOfRowsForLoggingErrorEvent), 1;
                                    if (0 === e.numberOfRows || 1 === e.numberOfRows) return e.numberOfRows;
                                    e = o.get(t), t = s.get(t);
                                    return e && t ? Math.ceil(e.length / t) : null
                                }(e, t);
                                void 0 !== r && null !== t ? r += t : r = void 0
                            }), n
                        }, [o, s, null == e ? void 0 : e.sorts]),
                        u = (0, V.useRef)(null),
                        c = (0, V.useCallback)(function(e, t) {
                            var n;
                            if (a || e.treatmentType === E.InterestGrid) return function(e, t, n) {
                                var r = n ? lt[n] : st;
                                if (!e) return r.minTilesPerRow;
                                var a = r.minTileWidth,
                                    o = r.columnGap,
                                    n = r.minTilesPerRow,
                                    r = r.maxTilesPerRow,
                                    o = Math.floor((e - t + o) / (a + o));
                                return Math.min(r, Math.max(n, o))
                            }(t, 1, null === (n = e.topicLayoutData) || void 0 === n ? void 0 : n.componentType);
                            return (null === (n = e.topicLayoutData) || void 0 === n ? void 0 : n.componentType) === F.GridTile || (null === (e = e.topicLayoutData) || void 0 === e ? void 0 : e.componentType) === F.EventTile ? t && t < ke.wideGameTileTilesPerRowBreakpointWidth ? ke.minWideGameTilesPerCarouselPage : ke.maxWideGameTilesPerCarouselPage : t && t < ke.homeFeedMaxWidth ? Math.max(1, Math.floor(t / ke.gameTileWidth)) : ke.maxTilesPerCarouselPage
                        }, [a]),
                        d = (0, V.useCallback)(function(n) {
                            var r = new Map;
                            null != e && e.sorts.forEach(function(e, t) {
                                (e.treatmentType === E.SortlessGrid || e.treatmentType === E.InterestGrid || a && e.treatmentType === E.Carousel) && r.set(t, c(e, n))
                            }), i(r)
                        }, [null == e ? void 0 : e.sorts, c, a]);
                    return (0, V.useLayoutEffect)(function() {
                        function e() {
                            var e = null === (e = null == u ? void 0 : u.current) || void 0 === e ? void 0 : e.getBoundingClientRect().width;
                            e && (document.documentElement.style.setProperty("--home-feed-width", e + "px"), d(e))
                        }
                        return e(), window.addEventListener("resize", e),
                            function() {
                                window.removeEventListener("resize", e)
                            }
                    }, [d]), {
                        homeFeedRef: u,
                        gridRecommendationsMap: o,
                        itemsPerRowMap: s,
                        startingRowNumbersMap: t
                    }
                },
                Wr = function() {
                    try {
                        return {
                            cpuCores: null === navigator || void 0 === navigator ? void 0 : navigator.hardwareConcurrency,
                            maxResolution: function() {
                                var e, t;
                                if (null !== (e = null === window || void 0 === window ? void 0 : window.screen) && void 0 !== e && e.width && null !== (t = null === window || void 0 === window ? void 0 : window.screen) && void 0 !== t && t.height) return window.screen.width + "x" + window.screen.height
                            }(),
                            maxMemory: function() {
                                if ("deviceMemory" in navigator && "number" == typeof navigator.deviceMemory) return 1024 * navigator.deviceMemory
                            }(),
                            networkType: function() {
                                var e;
                                if ("connection" in navigator && null !== (e = navigator.connection) && void 0 !== e && e.effectiveType) return navigator.connection.effectiveType
                            }()
                        }
                    } catch (e) {
                        return {}
                    }
                },
                tr = {
                    common: [],
                    feature: "Feature.ContactUpsell"
                },
                $r = (h.EnvironmentUrls.apiGatewayUrl, h.EnvironmentUrls.voiceApi);

            function qr(e, t, n, r, a, o, i) {
                try {
                    var l = e[o](i),
                        s = l.value
                } catch (e) {
                    return void n(e)
                }
                l.done ? t(s) : Promise.resolve(s).then(r, a)
            }
            var Zr = function() {
                var l, e = (l = regeneratorRuntime.mark(function e(t, n) {
                    var r, a;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return r = {
                                    retryable: !0,
                                    withCredentials: !0,
                                    url: "".concat($r, "/v1/settings/user-opt-in")
                                }, a = {
                                    isUserOptIn: t,
                                    isOptedInThroughUpsell: n
                                }, e.next = 4, C.httpService.post(r, a);
                            case 4:
                                return a = e.sent, a = a.data, e.abrupt("return", a);
                            case 7:
                            case "end":
                                return e.stop()
                        }
                    }, e)
                }), function() {
                    var e = this,
                        i = arguments;
                    return new Promise(function(t, n) {
                        var r = l.apply(e, i);

                        function a(e) {
                            qr(r, t, n, a, o, "next", e)
                        }

                        function o(e) {
                            qr(r, t, n, a, o, "throw", e)
                        }
                        a(void 0)
                    })
                });
                return function() {
                    return e.apply(this, arguments)
                }
            }();

            function Kr(e, t, n, r, a, o, i) {
                try {
                    var l = e[o](i),
                        s = l.value
                } catch (e) {
                    return void n(e)
                }
                l.done ? t(s) : Promise.resolve(s).then(r, a)
            }

            function Jr(t, e) {
                var n, r = Object.keys(t);
                return Object.getOwnPropertySymbols && (n = Object.getOwnPropertySymbols(t), e && (n = n.filter(function(e) {
                    return Object.getOwnPropertyDescriptor(t, e).enumerable
                })), r.push.apply(r, n)), r
            }

            function Yr(r) {
                for (var e = 1; e < arguments.length; e++) {
                    var a = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? Jr(Object(a), !0).forEach(function(e) {
                        var t, n;
                        t = r, e = a[n = e], n in t ? Object.defineProperty(t, n, {
                            value: e,
                            enumerable: !0,
                            configurable: !0,
                            writable: !0
                        }) : t[n] = e
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(r, Object.getOwnPropertyDescriptors(a)) : Jr(Object(a)).forEach(function(e) {
                        Object.defineProperty(r, e, Object.getOwnPropertyDescriptor(a, e))
                    })
                }
                return r
            }

            function Qr(e, n) {
                switch (e) {
                    case "ContactMethodEmail":
                        return {
                            primaryButton: {
                                text: "Action.AddEmail",
                                onClick: null === h.UpsellService || void 0 === h.UpsellService ? void 0 : h.UpsellService.renderEmailUpsell,
                                buttonClickBtnLog: "email"
                            }
                        };
                    case "ContactMethodPhoneNumber":
                        return {
                            primaryButton: {
                                text: "Action.AddPhone",
                                onClick: null === h.UpsellService || void 0 === h.UpsellService ? void 0 : h.UpsellService.renderPhoneUpsell,
                                buttonClickBtnLog: "phone"
                            }
                        };
                    case "ContactMethodPhoneNumberVoiceOptIn":
                        return {
                            primaryButton: {
                                text: "Action.AddPhone",
                                onClick: function(e) {
                                    return null === h.UpsellService || void 0 === h.UpsellService ? void 0 : h.UpsellService.renderPhoneUpsell(Yr({
                                        addPhoneAlwaysShowLegalText: !0,
                                        addPhoneRequireLegalTextCheckbox: n,
                                        addPhoneHeadingKey: "Action.AddPhoneVoice",
                                        addPhoneDescriptionKey: "Description.AddPhoneBodyVoice",
                                        addPhoneButtonKey: "Action.EnableVoice",
                                        addPhoneLegalTextKey: n ? "Description.VoiceLegalConsent" : "Description.VoiceLegalDisclaimer",
                                        beforeSuccess: (l = regeneratorRuntime.mark(function e() {
                                            var t, n;
                                            return regeneratorRuntime.wrap(function(e) {
                                                for (;;) switch (e.prev = e.next) {
                                                    case 0:
                                                        return e.prev = 0, e.next = 3, Zr(!0, !1);
                                                    case 3:
                                                        if (e.t1 = t = e.sent, e.t0 = null === e.t1, e.t0) {
                                                            e.next = 7;
                                                            break
                                                        }
                                                        e.t0 = void 0 === t;
                                                    case 7:
                                                        if (!e.t0) {
                                                            e.next = 11;
                                                            break
                                                        }
                                                        e.t2 = void 0, e.next = 12;
                                                        break;
                                                    case 11:
                                                        e.t2 = t.isUserOptIn;
                                                    case 12:
                                                        return n = e.t2, e.abrupt("return", n ? ["Heading.VoiceChatEnabled", "Description.CanNowJoinVoice"] : ["Heading.PhoneIsVerified", "Description.TurnOnVoiceChat"]);
                                                    case 16:
                                                        return e.prev = 16, e.t3 = e.catch(0), e.abrupt("return", ["Heading.PhoneIsVerified", "Description.TurnOnVoiceChat"]);
                                                    case 19:
                                                    case "end":
                                                        return e.stop()
                                                }
                                            }, e, null, [
                                                [0, 16]
                                            ])
                                        }), t = function() {
                                            var e = this,
                                                i = arguments;
                                            return new Promise(function(t, n) {
                                                var r = l.apply(e, i);

                                                function a(e) {
                                                    Kr(r, t, n, a, o, "next", e)
                                                }

                                                function o(e) {
                                                    Kr(r, t, n, a, o, "throw", e)
                                                }
                                                a(void 0)
                                            })
                                        }, function() {
                                            return t.apply(this, arguments)
                                        })
                                    }, e));
                                    var l, t
                                },
                                buttonClickBtnLog: "phone"
                            }
                        };
                    case "ContactMethodPhoneNumberEmailHorizontalLayout":
                    case "ContactMethodPhoneNumberEmailHorizontalLayoutAltContent1":
                        return {
                            primaryButton: {
                                text: "Action.AddPhoneShort",
                                onClick: null === h.UpsellService || void 0 === h.UpsellService ? void 0 : h.UpsellService.renderPhoneUpsell,
                                buttonClickBtnLog: "phone"
                            },
                            secondaryButton: {
                                text: "Action.AddEmail",
                                onClick: null === h.UpsellService || void 0 === h.UpsellService ? void 0 : h.UpsellService.renderEmailUpsell,
                                buttonClickBtnLog: "email"
                            },
                            buttonStackOrientation: oa
                        };
                    case "ContactMethodPhoneNumberEmailVerticalLayout":
                        return {
                            primaryButton: {
                                text: "Action.AddPhone",
                                onClick: null === h.UpsellService || void 0 === h.UpsellService ? void 0 : h.UpsellService.renderPhoneUpsell,
                                buttonClickBtnLog: "phone"
                            },
                            secondaryButton: {
                                text: "Action.AddEmailAddress",
                                onClick: null === h.UpsellService || void 0 === h.UpsellService ? void 0 : h.UpsellService.renderEmailUpsell,
                                buttonClickBtnLog: "email"
                            },
                            buttonStackOrientation: aa
                        };
                    case "FacebookSunset":
                        return {
                            primaryButton: {
                                text: "Action.SetPassword",
                                onClick: null === h.FacebookSunsetService || void 0 === h.FacebookSunsetService ? void 0 : h.FacebookSunsetService.openFacebookSunsetModal,
                                buttonClickBtnLog: "setPassword"
                            }
                        };
                    default:
                        return null
                }
            }
            var Xr = {
                    ContactMethodEmail: "ContactMethodEmail",
                    ContactMethodPhoneNumber: "ContactMethodPhoneNumber",
                    ContactMethodPhoneNumberVoiceOptIn: "ContactMethodPhoneNumberVoiceOptIn",
                    ContactMethodPhoneNumberEmailHorizontalLayout: "ContactMethodPhoneNumberEmailHorizontalLayout",
                    ContactMethodPhoneNumberEmailHorizontalLayoutAltContent1: "ContactMethodPhoneNumberEmailHorizontalLayoutAltContent1",
                    ContactMethodPhoneNumberEmailVerticalLayout: "ContactMethodPhoneNumberEmailVerticalLayout",
                    FacebookSunset: "FacebookSunset",
                    ContactMethodMandatoryEmailPhone: "ContactMethodMandatoryEmailPhone"
                },
                ea = {
                    ContactMethodEmail: "Label.DontGetLockedOut",
                    ContactMethodPhoneNumber: "Label.DontGetLockedOut",
                    ContactMethodPhoneNumberVoiceOptIn: "Header.UnlockVoiceChat",
                    ContactMethodPhoneNumberEmailHorizontalLayout: "Label.DontGetLockedOut",
                    ContactMethodPhoneNumberEmailHorizontalLayoutAltContent1: "Heading.FinishAccountSetup",
                    ContactMethodPhoneNumberEmailVerticalLayout: "Label.DontGetLockedOut",
                    FacebookSunset: ""
                },
                ta = {
                    ContactMethodEmail: "Description.HomePageUpsellCardAddEmailText",
                    ContactMethodPhoneNumber: "Description.HomePageUpsellCardAddPhoneText",
                    ContactMethodPhoneNumberVoiceOptIn: "Description.UnlockVoiceChat.3",
                    ContactMethodPhoneNumberEmailHorizontalLayout: "Label.RecoverYourAccount",
                    ContactMethodPhoneNumberEmailHorizontalLayoutAltContent1: "Description.ContactMethodAccessLoss",
                    ContactMethodPhoneNumberEmailVerticalLayout: "Label.RecoverYourAccount",
                    FacebookSunset: "Description.FacebookSetPasswordUpsellText"
                },
                na = {
                    ContactMethodEmail: "homePageUpsellCard",
                    ContactMethodPhoneNumber: "homePageUpsellCard",
                    ContactMethodPhoneNumberVoiceOptIn: "homePageUpsellCard",
                    ContactMethodPhoneNumberEmailHorizontalLayout: "homePageUpsellCard",
                    ContactMethodPhoneNumberEmailHorizontalLayoutAltContent1: "homePageUpsellCard",
                    ContactMethodPhoneNumberEmailVerticalLayout: "homePageUpsellCard",
                    FacebookSunset: "facebookSunsetCard"
                },
                ra = {
                    ContactMethodEmail: "email",
                    ContactMethodPhoneNumber: "phone",
                    ContactMethodPhoneNumberVoiceOptIn: "phone",
                    ContactMethodPhoneNumberEmailHorizontalLayout: "emailOrPhone",
                    ContactMethodPhoneNumberEmailHorizontalLayoutAltContent1: "emailOrPhone",
                    ContactMethodPhoneNumberEmailVerticalLayout: "emailOrPhone",
                    FacebookSunset: "facebook"
                },
                aa = "vertical",
                oa = "horizontal",
                ia = {
                    ContactMethodEmail: "upsell-card-lock-icon-image",
                    ContactMethodPhoneNumber: "upsell-card-lock-icon-image",
                    ContactMethodPhoneNumberVoiceOptIn: "icon-voice-mic-unmuted",
                    ContactMethodPhoneNumberEmailHorizontalLayout: "upsell-card-lock-icon-image",
                    ContactMethodPhoneNumberEmailHorizontalLayoutAltContent1: "upsell-card-lock-icon-image",
                    ContactMethodPhoneNumberEmailVerticalLayout: "upsell-card-lock-icon-image",
                    FacebookSunset: ""
                };

            function la(t, e) {
                var n, r = Object.keys(t);
                return Object.getOwnPropertySymbols && (n = Object.getOwnPropertySymbols(t), e && (n = n.filter(function(e) {
                    return Object.getOwnPropertyDescriptor(t, e).enumerable
                })), r.push.apply(r, n)), r
            }

            function sa(r) {
                for (var e = 1; e < arguments.length; e++) {
                    var a = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? la(Object(a), !0).forEach(function(e) {
                        var t, n;
                        t = r, e = a[n = e], n in t ? Object.defineProperty(t, n, {
                            value: e,
                            enumerable: !0,
                            configurable: !0,
                            writable: !0
                        }) : t[n] = e
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(r, Object.getOwnPropertyDescriptors(a)) : la(Object(a)).forEach(function(e) {
                        Object.defineProperty(r, e, Object.getOwnPropertyDescriptor(a, e))
                    })
                }
                return r
            }

            function ua(e, t, n, r, a) {
                a = 4 < arguments.length && void 0 !== a ? a : void 0, S.eventStreamService.sendEventWithTarget(e.type, na[n], sa(sa({}, e.params), {}, {
                    origin: t,
                    section: r,
                    btn: a
                }))
            }
            var je = S.eventStreamService.eventTypes,
                ca = "mandatory",
                da = "homepage",
                fa = {
                    cardShown: {
                        name: "cardShown",
                        type: je.modalAction,
                        params: {
                            aType: "shown"
                        }
                    },
                    buttonClick: {
                        name: "buttonClick",
                        type: "buttonClick",
                        params: {}
                    }
                };

            function pa(e, t) {
                return function(e) {
                    if (Array.isArray(e)) return e
                }(e) || function(e, t) {
                    if ("undefined" == typeof Symbol || !(Symbol.iterator in Object(e))) return;
                    var n = [],
                        r = !0,
                        a = !1,
                        o = void 0;
                    try {
                        for (var i, l = e[Symbol.iterator](); !(r = (i = l.next()).done) && (n.push(i.value), !t || n.length !== t); r = !0);
                    } catch (e) {
                        a = !0, o = e
                    } finally {
                        try {
                            r || null == l.return || l.return()
                        } finally {
                            if (a) throw o
                        }
                    }
                    return n
                }(e, t) || function(e, t) {
                    if (!e) return;
                    if ("string" == typeof e) return ma(e, t);
                    var n = Object.prototype.toString.call(e).slice(8, -1);
                    "Object" === n && e.constructor && (n = e.constructor.name);
                    if ("Map" === n || "Set" === n) return Array.from(e);
                    if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return ma(e, t)
                }(e, t) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function ma(e, t) {
                (null == t || t > e.length) && (t = e.length);
                for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
                return r
            }

            function va(e) {
                var t = e.translate,
                    n = e.cardType,
                    r = e.origin,
                    a = e.titleTextOverride,
                    o = e.bodyTextOverride,
                    i = e.requireExplicitVoiceConsent,
                    l = pa((0, V.useState)(!1), 2),
                    s = l[0],
                    u = l[1],
                    c = ra[n];
                (0, V.useEffect)(function() {
                    ua(fa.cardShown, r, n, c)
                }, []);
                var e = Qr(n, i),
                    d = null == e ? void 0 : e.primaryButton,
                    l = d ? W().createElement(ge.Button, {
                        className: "btn-primary-md",
                        id: "upsell-card-primary-button",
                        onClick: function() {
                            ua(fa.buttonClick, r, n, c, d.buttonClickBtnLog), d.onClick(function(e) {
                                u(e)
                            })
                        }
                    }, t(d.text)) : null,
                    f = null == e ? void 0 : e.secondaryButton,
                    i = f ? W().createElement(ge.Button, {
                        className: "btn-secondary-md",
                        id: "upsell-card-secondary-button",
                        onClick: function() {
                            ua(fa.buttonClick, r, n, c, f.buttonClickBtnLog), f.onClick(function(e) {
                                u(e)
                            })
                        }
                    }, t(f.text)) : null,
                    e = null !== (e = null == e ? void 0 : e.buttonStackOrientation) && void 0 !== e ? e : oa,
                    i = W().createElement("div", {
                        className: e === oa ? "upsell-card-horizontal-button-list" : "upsell-card-vertical-button-list"
                    }, l, i),
                    a = ha(a) ? t(ea[n]) : a,
                    o = ha(o) ? t(ta[n]) : o,
                    a = W().createElement("div", {
                        className: "upsell-card-text-content-group"
                    }, ea[n] ? W().createElement("div", {
                        className: "font-header-1"
                    }, " ", a) : null, W().createElement("div", {
                        className: "upsell-card-content"
                    }, " ", o)),
                    o = ia[n] ? W().createElement("div", {
                        className: "home-page-upsell-card-image ".concat(ia[n])
                    }) : null;
                return s ? null : W().createElement("div", {
                    className: "home-page-upsell-card-banner-container"
                }, W().createElement("div", {
                    className: "banner-contents"
                }, W().createElement("div", {
                    className: "icon-and-text"
                }, o, W().createElement("div", {
                    className: "banner-content-container"
                }, a)), W().createElement("div", {
                    className: "add-email-btn-container"
                }, i), W().createElement("div", {
                    id: "facebookSunsetModal-container"
                })))
            }

            function ha(e) {
                return !e || 0 === e.length
            }
            va.defaultProps = {
                origin: "homepage",
                titleTextOverride: "",
                bodyTextOverride: "",
                requireExplicitVoiceConsent: !0
            }, va.propTypes = {
                translate: te().func.isRequired,
                cardType: te().string.isRequired,
                titleTextOverride: te().string,
                bodyTextOverride: te().string,
                origin: te().string,
                requireExplicitVoiceConsent: te().bool
            };
            var ga = va,
                ya = function(e) {
                    return !![Xr.ContactMethodEmail, Xr.ContactMethodPhoneNumber, Xr.ContactMethodPhoneNumberEmailHorizontalLayout, Xr.ContactMethodPhoneNumberEmailHorizontalLayoutAltContent1, Xr.ContactMethodPhoneNumberEmailVerticalLayout, Xr.ContactMethodPhoneNumberVoiceOptIn, Xr.FacebookSunset].includes(e)
                };

            function ba(e, t, n, r, a, o, i) {
                try {
                    var l = e[o](i),
                        s = l.value
                } catch (e) {
                    return void n(e)
                }
                l.done ? t(s) : Promise.resolve(s).then(r, a)
            }

            function Ia(l) {
                return function() {
                    var e = this,
                        i = arguments;
                    return new Promise(function(t, n) {
                        var r = l.apply(e, i);

                        function a(e) {
                            ba(r, t, n, a, o, "next", e)
                        }

                        function o(e) {
                            ba(r, t, n, a, o, "throw", e)
                        }
                        a(void 0)
                    })
                }
            }

            function Pa(e, t) {
                return function(e) {
                    if (Array.isArray(e)) return e
                }(e) || function(e, t) {
                    if ("undefined" == typeof Symbol || !(Symbol.iterator in Object(e))) return;
                    var n = [],
                        r = !0,
                        a = !1,
                        o = void 0;
                    try {
                        for (var i, l = e[Symbol.iterator](); !(r = (i = l.next()).done) && (n.push(i.value), !t || n.length !== t); r = !0);
                    } catch (e) {
                        a = !0, o = e
                    } finally {
                        try {
                            r || null == l.return || l.return()
                        } finally {
                            if (a) throw o
                        }
                    }
                    return n
                }(e, t) || function(e, t) {
                    if (!e) return;
                    if ("string" == typeof e) return Ea(e, t);
                    var n = Object.prototype.toString.call(e).slice(8, -1);
                    "Object" === n && e.constructor && (n = e.constructor.name);
                    if ("Map" === n || "Set" === n) return Array.from(e);
                    if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return Ea(e, t)
                }(e, t) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function Ea(e, t) {
                (null == t || t > e.length) && (t = e.length);
                for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
                return r
            }

            function Sa(e) {
                var t = e.translate,
                    n = Xr.ContactMethodMandatoryEmailPhone,
                    r = Pa((0, V.useState)(null), 2),
                    a = r[0],
                    o = r[1],
                    i = Pa((0, V.useState)(""), 2),
                    l = i[0],
                    s = i[1],
                    e = Pa((0, V.useState)(""), 2),
                    r = e[0],
                    u = e[1],
                    i = Pa((0, V.useState)(!1), 2),
                    e = i[0],
                    c = i[1];
                return (0, V.useEffect)(function() {
                    var e = function() {
                            var e = Ia(regeneratorRuntime.mark(function e() {
                                var t;
                                return regeneratorRuntime.wrap(function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            return e.prev = 0, e.next = 3, h.HomePageUpsellCardService.getHomePageUpsellCardVariation();
                                        case 3:
                                            t = e.sent, (null == t ? void 0 : t.upsellCardType) && (o(null == t ? void 0 : t.upsellCardType), s(null == t ? void 0 : t.localizedTitleTextOverride), u(null == t ? void 0 : t.localizedBodyTextOverride)), e.next = 12;
                                            break;
                                        case 8:
                                            e.prev = 8, e.t0 = e.catch(0), console.error("Error getting the upsell card variation ".concat(e.t0)), o(null);
                                        case 12:
                                        case "end":
                                            return e.stop()
                                    }
                                }, e, null, [
                                    [0, 8]
                                ])
                            }));
                            return function() {
                                return e.apply(this, arguments)
                            }
                        }(),
                        t = function() {
                            var e = Ia(regeneratorRuntime.mark(function e() {
                                var t;
                                return regeneratorRuntime.wrap(function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            return e.prev = 0, e.next = 3, h.HomePageUpsellCardService.getVoicePolicy();
                                        case 3:
                                            null != (null == (t = e.sent) ? void 0 : t.requireExplicitVoiceConsent) && c(null == t ? void 0 : t.requireExplicitVoiceConsent), e.next = 11;
                                            break;
                                        case 7:
                                            e.prev = 7, e.t0 = e.catch(0), console.error("Error reading policy for homepage upsellcard ".concat(e.t0)), c(!0);
                                        case 11:
                                        case "end":
                                            return e.stop()
                                    }
                                }, e, null, [
                                    [0, 7]
                                ])
                            }));
                            return function() {
                                return e.apply(this, arguments)
                            }
                        }();
                    e(), t()
                }, []), (0, V.useEffect)(function() {
                    a === n && null !== h.UpsellService && void 0 !== h.UpsellService && h.UpsellService.renderContactMethodPromptModal({
                        origin: da,
                        section: ca
                    })
                }, [a]), ya(a) ? W().createElement(ga, {
                    translate: t,
                    cardType: a,
                    titleTextOverride: l,
                    bodyTextOverride: r,
                    requireExplicitVoiceConsent: e
                }) : null
            }
            Sa.propTypes = {
                translate: te().func.isRequired
            };
            var wa = Sa;

            function Ca(e) {
                var t = e.translate,
                    e = e.context;
                return W().createElement(wa, {
                    translate: t,
                    context: e
                })
            }

            function Ta(e) {
                var t, a = e.sort,
                    n = e.itemsPerRow,
                    r = e.toggleInterest,
                    o = e.interestedUniverses,
                    i = e.homePageSessionInfo,
                    l = e.translate,
                    s = (0, V.useRef)(null),
                    u = (0, V.useRef)(null),
                    c = vn().contentMetadata,
                    d = (0, V.useMemo)(function() {
                        return hn(a.recommendationList, c)
                    }, [a.recommendationList, c]),
                    f = (0, V.useCallback)(function(t) {
                        var e = null == d ? void 0 : d.findIndex(function(e) {
                            return e.universeId === t
                        });
                        if (void 0 !== e && -1 !== e) {
                            var n, r = d[e];
                            return (n = {})[x.ButtonName] = I.Interested, n[x.PlaceId] = r.placeId, n[x.UniverseId] = t, n[x.Position] = e, n[x.GameSetTypeId] = a.topicId, n[x.NumberOfLoadedTiles] = null == d ? void 0 : d.length, n[x.Page] = T.InterestCatcher, n[L.HomePageSessionInfo] = i, n[x.IsInterested] = !o.has(t), n
                        }
                    }, [o, d, i, a.topicId]),
                    p = (0, V.useCallback)(function(e) {
                        r(e);
                        e = f(e), e = ee.interestCatcherClick(e);
                        void 0 !== e && S.eventStreamService.sendEvent.apply(S.eventStreamService, e)
                    }, [r, f]),
                    e = (0, V.useCallback)(function(e) {
                        if (d) {
                            var t = e.filter(function(e) {
                                return e < (null == d ? void 0 : d.length)
                            });
                            return Na(Na(Na(((e = {})[x.RootPlaceIds] = t.map(function(e) {
                                return d[e].placeId
                            }), e[x.UniverseIds] = t.map(function(e) {
                                return d[e].universeId
                            }), e), j(d, a.topicId, t, null === (e = null == a ? void 0 : a.topicLayoutData) || void 0 === e ? void 0 : e.componentType)), J(d, a.topicId, t, null === (e = null == a ? void 0 : a.topicLayoutData) || void 0 === e ? void 0 : e.componentType)), ((e = {})[x.AbsPositions] = t, e[x.NumberOfLoadedTiles] = null == d ? void 0 : d.length, e[x.GameSetTypeId] = a.topicId, e[x.Page] = T.InterestCatcher, e[L.HomePageSessionInfo] = i, e))
                        }
                    }, [d, i, a.topicId, null === (t = null == a ? void 0 : a.topicLayoutData) || void 0 === t ? void 0 : t.componentType]);
                return tn(s, null !== (t = null == d ? void 0 : d.length) && void 0 !== t ? t : 0, e), (0, V.useLayoutEffect)(function() {
                    n && null != s && s.current && s.current.style.setProperty("--items-per-row", n.toString())
                }, [n]), W().createElement(Jn, {
                    ref: s,
                    tileRef: u,
                    gameData: d,
                    emphasis: !1,
                    translate: l,
                    isHomeGameGrid: !0,
                    isExpandHomeContentEnabled: !0,
                    buildEventProperties: function() {
                        return {}
                    },
                    componentType: null === (l = null == a ? void 0 : a.topicLayoutData) || void 0 === l ? void 0 : l.componentType,
                    playerCountStyle: null === (l = null == a ? void 0 : a.topicLayoutData) || void 0 === l ? void 0 : l.playerCountStyle,
                    playButtonStyle: null === (l = null == a ? void 0 : a.topicLayoutData) || void 0 === l ? void 0 : l.playButtonStyle,
                    topicId: null === (l = null == a ? void 0 : a.topicId) || void 0 === l ? void 0 : l.toString(),
                    shouldUseSentinelTile: !1,
                    interestedUniverses: o,
                    toggleInterest: p
                })
            }

            function _a(e) {
                var t = e.sort,
                    n = e.itemsPerRow,
                    r = e.fetchRecommendations,
                    a = e.translate,
                    o = (f = (0, V.useState)(new Set))[0],
                    i = f[1],
                    l = Xt(),
                    s = (0, V.useCallback)(function(e) {
                        var t = {};
                        return t[x.ButtonName] = e, t[L.HomePageSessionInfo] = l, t[x.InterestedUniverseIds] = Array.from(o), t[x.Page] = T.InterestCatcher, t
                    }, [l, o]),
                    u = (0, V.useCallback)(function(e) {
                        e = s(e), e = ee.interestCatcherClick(e);
                        void 0 !== e && S.eventStreamService.sendEvent.apply(S.eventStreamService, e)
                    }, [s]),
                    c = (0, V.useCallback)(function() {
                        r([]), u(I.Skip)
                    }, [r, u]),
                    d = (0, V.useCallback)(function() {
                        r(Array.from(o)), u(I.Continue)
                    }, [o, r, u]),
                    e = (0, V.useMemo)(function() {
                        return null != o && o.size ? a(ze.ActionInterestCatcherContinueSelected, {
                            numSelected: o.size
                        }) : a(ze.ActionInterestCatcherContinue)
                    }, [o, a]),
                    f = (0, V.useCallback)(function(e) {
                        var t, n;
                        null === e || void 0 === (null === (n = e.getBoundingClientRect()) || void 0 === n ? void 0 : n.top) || (n = document.getElementById("header")) && null !== (t = n.getBoundingClientRect()) && void 0 !== t && t.height && (n = n.getBoundingClientRect().height, window.scrollTo({
                            top: e.getBoundingClientRect().top + window.scrollY - n
                        }))
                    }, []);
                return W().createElement("div", {
                    ref: f,
                    className: "interest-catcher-container",
                    "data-testid": "interest-catcher-container"
                }, W().createElement("div", {
                    className: "header-container"
                }, W().createElement("div", {
                    className: "header-text-container"
                }, W().createElement("h1", {
                    className: "header-text"
                }, t.topic), W().createElement("span", {
                    className: "header-subtext"
                }, t.subtitle)), W().createElement("div", {
                    className: "header-buttons-container"
                }, !(null != o && o.size) && W().createElement(ge.Button, {
                    variant: ge.Button.variants.secondary,
                    size: ge.Button.sizes.medium,
                    title: a(ze.ActionInterestCatcherSkip),
                    onClick: c,
                    className: "skip-button"
                }, a(ze.ActionInterestCatcherSkip)), W().createElement(ge.Button, {
                    variant: ge.Button.variants.primary,
                    size: ge.Button.sizes.medium,
                    title: e,
                    onClick: d,
                    isDisabled: !(null != o && o.size),
                    className: "continue-button"
                }, e))), W().createElement(Ta, {
                    sort: t,
                    itemsPerRow: n,
                    translate: a,
                    toggleInterest: function(t) {
                        i(function(e) {
                            e = new Set(e);
                            return e.has(t) ? e.delete(t) : e.add(t), e
                        })
                    },
                    interestedUniverses: o,
                    homePageSessionInfo: l
                }))
            }
            Ca.defaultProps = {
                context: Xr.ContactMethod
            }, Ca.propTypes = {
                translate: te().func.isRequired,
                context: te().string
            };
            var xa, La = (0, f.withTranslations)(Ca, tr),
                Na = function() {
                    return (Na = Object.assign || function(e) {
                        for (var t, n = 1, r = arguments.length; n < r; n++)
                            for (var a in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
                        return e
                    }).apply(this, arguments)
                },
                Da = function() {
                    return (Da = Object.assign || function(e) {
                        for (var t, n = 1, r = arguments.length; n < r; n++)
                            for (var a in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
                        return e
                    }).apply(this, arguments)
                },
                Aa = ke.maxTilesPerCarouselPage,
                ka = n,
                Oa = t,
                Ra = (xa = (0, f.withTranslations)(function(e) {
                    var n = e.translate,
                        t = Xt(),
                        r = (0, V.useState)(void 0),
                        a = r[0],
                        o = r[1],
                        i = (0, V.useState)(!1),
                        l = i[0],
                        s = i[1],
                        u = (0, V.useMemo)(function() {
                            return Wr()
                        }, []),
                        c = (0, V.useMemo)(function() {
                            try {
                                return (0, S.dataStores.authIntentDataStore.retrieveAuthIntentDataForUser)()
                            } catch (e) {
                                return void console.error("Error retrieving auth intent data:", e)
                            }
                        }, []),
                        d = (0, V.useCallback)(function(e) {
                            o(void 0), s(!1), pe(Rt.Home, t, u, c, e).then(function(e) {
                                o(e), (0, w.fireEvent)(ke.omniRecommendationEndpointSuccessEvent)
                            }).catch(function() {
                                s(!0), (0, w.fireEvent)(ke.omniRecommendationEndpointErrorEvent)
                            })
                        }, [t, u, c]),
                        f = (0, V.useState)(!0),
                        p = f[0],
                        m = f[1],
                        e = (0, V.useState)(!1),
                        v = e[0],
                        h = e[1],
                        g = (0, V.useCallback)(function() {
                            fe(ka.homePageWeb, Oa.homePageWeb).then(function(e) {
                                m(!(null == e || !e.IsExpandHomeContentEnabled)), h(!(null == e || !e.IsReactFriendsCarouselEnabled))
                            }).catch(function() {
                                m(!1)
                            })
                        }, []);
                    (0, V.useEffect)(function() {
                        d()
                    }, [d]), (0, V.useEffect)(function() {
                        g()
                    }, [g]);
                    var r = (0, V.useCallback)(function(n) {
                            o(function(e) {
                                var t;
                                return e && Da(Da({}, e), {
                                    contentMetadata: ((t = {})[P.Game] = Da(Da({}, e.contentMetadata[P.Game]), n[P.Game]), t[P.CatalogAsset] = Da(Da({}, e.contentMetadata[P.CatalogAsset]), n[P.CatalogAsset]), t[P.CatalogBundle] = Da(Da({}, e.contentMetadata[P.CatalogBundle]), n[P.CatalogBundle]), t)
                                })
                            })
                        }, []),
                        i = Vr(a, p),
                        f = i.homeFeedRef,
                        y = i.gridRecommendationsMap,
                        b = i.itemsPerRowMap,
                        I = i.startingRowNumbersMap;
                    Br(T.HomePage);
                    e = (0, V.useMemo)(function() {
                        return !(null == a || !a.sorts) && a.sorts.every(function(e) {
                            return e.treatmentType !== E.FriendCarousel
                        })
                    }, [null == a ? void 0 : a.sorts]), i = (0, V.useMemo)(function() {
                        return null == a ? void 0 : a.sorts.findIndex(function(e) {
                            return e.treatmentType === E.InterestGrid
                        })
                    }, [null == a ? void 0 : a.sorts]);
                    if (l) return W().createElement("div", {
                        className: "game-home-page-container",
                        "data-testid": "HomePageContainerTestId"
                    }, W().createElement("h2", null, n(Be.LabelGames)), W().createElement(be, {
                        errorMessage: n(Be.LabelApiError),
                        onRefresh: function() {
                            return d()
                        }
                    }));
                    if (void 0 === a) return W().createElement("div", {
                        className: "game-home-page-container",
                        "data-testid": "HomePageContainerTestId"
                    }, W().createElement("div", {
                        className: "game-home-page-loading-title shimmer"
                    }), W().createElement("div", {
                        className: "game-home-page-loading-carousel"
                    }, Array.from({
                        length: Aa
                    }, function(e, t) {
                        return W().createElement(Fr, {
                            key: t
                        })
                    })));
                    if (void 0 !== i && -1 < i) {
                        l = a.sorts[i];
                        if (l && gn(l)) return W().createElement("div", {
                            className: "game-home-page-container",
                            "data-testid": "HomePageContainerTestId"
                        }, W().createElement("div", {
                            ref: f
                        }, W().createElement(xn.Provider, {
                            value: {
                                contentMetadata: a.contentMetadata,
                                appendContentMetadata: r
                            }
                        }, W().createElement(_a, {
                            sort: l,
                            itemsPerRow: b.get(i),
                            fetchRecommendations: d,
                            translate: n
                        }))))
                    }
                    return W().createElement("div", {
                        className: "game-home-page-container",
                        "data-testid": "HomePageContainerTestId"
                    }, W().createElement("div", {
                        ref: f
                    }, W().createElement(xn.Provider, {
                        value: {
                            contentMetadata: a.contentMetadata,
                            appendContentMetadata: r
                        }
                    }, W().createElement(wt, null, W().createElement(La, {
                        translate: n,
                        context: void 0
                    }), e && W().createElement(ar, null), a.sorts.map(function(e, t) {
                        return W().createElement(W().Fragment, {
                            key: t
                        }, W().createElement(Hr, {
                            translate: n,
                            sort: e,
                            positionId: t,
                            startingRow: I.get(t),
                            currentPage: T.HomePage,
                            itemsPerRow: b.get(t),
                            gridRecommendations: null !== (t = y.get(t)) && void 0 !== t ? t : [],
                            isExpandHomeContentEnabled: p,
                            isReactFriendsCarouselEnabled: v
                        }))
                    })))))
                }, ve), function(e) {
                    return W().createElement(Qt, null, W().createElement(xa, nn({}, e)))
                });
            (0, C.ready)(function() {
                c() && (0, e.render)(W().createElement(Ra, null), c())
            })
        }()
}();
//# sourceMappingURL=https://js.rbxcdn.com/1ec6d338c9b5848094c6179e7cc188f8-placesList.bundle.min.js.map

/* Bundle detector */
window.Roblox && window.Roblox.BundleDetector && window.Roblox.BundleDetector.bundleDetected("PlacesList");