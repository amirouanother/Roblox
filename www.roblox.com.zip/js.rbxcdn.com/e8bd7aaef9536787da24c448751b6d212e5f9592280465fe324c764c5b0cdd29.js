! function() {
    "use strict";
    var h = Roblox,
        m = CoreRobloxUtilities,
        a = "/upgrades/paymentmethods",
        d = "/info/terms",
        f = "ItemPurchaseAjaxData",
        u = "/games/",
        c = "CommonUI.Controls",
        p = "Feature.Premium",
        o = "/v1/users/{userId}/currency",
        s = "/game-passes/v1/game-passes/{productId}/purchase",
        E = "/v1/purchases/products/{productId}",
        i = "/v1/products/{productId}",
        y = "/purchase-warning/v1/purchase-warnings",
        v = "/purchase-warning/v1/purchase-warnings/acknowledge",
        l = "Success",
        U = 5e3,
        S = {
            GAME_PASS: "Game Pass",
            BUNDLE: "Bundle",
            BUNDLE_ALIAS: "Package"
        },
        A = {
            GAME_PASS: "/v1/game-passes",
            BUNDLE: "/v1/bundles/thumbnails",
            ASSET: "/v1/assets"
        },
        T = {
            size: "150x150",
            format: "Png",
            isCircular: !1
        },
        P = {
            backToShopAction: "Action.BackToShop",
            buyRobuxAndItemAction: "Action.BuyRobuxAndItem",
            buyRobux: "Action.BuyRobux",
            cancelAction: "Action.Cancel",
            equipMyAvatarAction: "Action.EquipMyAvatar",
            goToRobuxStoreAction: "Action.GoToRobuxStore",
            insufficientRobuxHeading: "Heading.InsufficientRobux",
            insufficientRobuxMessage: "Message.InsufficientRobux",
            insufficientRobuxLeaveRobloxHeading: "Heading.InsufficientRobuxLeaveRoblox",
            insufficientRobuxAskToPurchasePackageMessage: "Message.InsufficientRobuxAskToPurchasePackage",
            insufficientRobuxExceedLargestPackageMessage: "Message.InsufficientRobuxExceedLargestPackage",
            insufficientRobuxRedirectToExternalPartner: "Message.InsufficientRobuxRedirectToExternalPartner",
            purchaseSucceededHeading: "Heading.PurchaseSucceeded",
            purchaseSucceededMessage: "Message.PurchaseSucceeded",
            purchaseSucceededRobuxBalanceMessage: "Message.PurchaseSucceededRobuxBalance",
            purchasingTheItemLabel: "Label.PurchasingTheItem",
            waitingForRobuxLabel: "Label.WaitingForRobux",
            errorOccuredHeading: "Heading.ErrorOccured",
            purchasingUnavailableMessage: "Message.PurchasingUnavailable",
            purchaseErrorOccuredMessage: "Message.PurchaseErrorOccured",
            okAction: "Action.Ok",
            commonUiOkAction: "Action.OK",
            commonUiCancelAction: "Action.Cancel",
            commonUiContinueToPaymentAction: "Action.ContinueToPayment",
            featurePremiumScaryModalTitleHeading: "Heading.ScaryModalTitle",
            featurePremiumScaryModalBodyNewDescription: "Description.ScaryModalBodyNew",
            featurePremiumScaryModalBody13To17Description: "Description.ScaryModalBody13To17",
            featurePremiumScaryModalThreshold1BodyDescription: "Description.ScaryModalThreshold1Body",
            featurePremiumScaryModalThreshold2BodyDescription: "Description.ScaryModalThreshold2Body"
        },
        _ = {
            U13PaymentModal: "U13PaymentModal",
            ParentalConsentWarningPaymentModal13To17: "ParentalConsentWarningPaymentModal13To17",
            ParentalAuthorization13To17: "ParentalAuthorization13To17",
            U13MonthlyThreshold1Modal: "U13MonthlyThreshold1Modal",
            RequireEmailVerification: "RequireEmailVerification",
            U13MonthlyThreshold2Modal: "U13MonthlyThreshold2Modal",
            NoAction: "NoAction"
        },
        b = {
            EVENT_NAME: "ItemPurchaseUpsellEvent",
            CONTEXT_NAME: {
                COOKIE_PARSE_FAILED: "COOKIE_PARSE_FAILED",
                PRODUCT_INFO_REQUEST_FAILED: "PRODUCT_INFO_REQUEST_FAILED",
                PRODUCT_INFO_EMPTY: "PRODUCT_INFO_EMPTY",
                PRODUCT_ID_NOT_EXIST: "PRODUCT_ID_NOT_EXIST",
                UPSELL_FAILED: "UPSELL_FAILED"
            }
        },
        t = "WebCatalog",
        r = "WebBundle",
        w = "WebGamePass",
        g = "NoTypeParsedYet",
        M = {
            UnknownError: "UnknownError",
            UnknownErrorNoAsset: "UnknownErrorNoAsset",
            UpsellShown: "UpsellShown",
            UpsellCancelled: "UpsellCancelled",
            UpsellCancelledFromU13Modal: "UpsellCancelledFromU13Modal",
            UpsellContinued: "UpsellContinued",
            UpsellThumbnailProcessFailed: "UpsellThumbnailProcessFailed",
            ContinueBuyRobuxOnExternalSite: "ContinueBuyRobuxOnExternalSite",
            LeaveRobloxFailedToShown: "LeaveRobloxFailedToShown",
            CancelledFromLeaveRobloxModal: "CancelledFromLeaveRobloxModal",
            ConfirmLeaveRobloxModal: "ConfirmLeaveRobloxModal",
            UpsellExceedLargestEntryPoint: "UpsellExceedLargestEntryPoint",
            UpsellExceedLargestShown: "UpsellExceedLargestShown",
            UpsellExceedLargestCancelled: "UpsellExceedLargestCancelled",
            UpsellExceedLargestGoToRobuxStoreClicked: "UpsellExceedLargestGoToRobuxStoreClicked",
            UpsellExceedLargestModalExpTrue: "UpsellExceedLargestModalExpTrue",
            UpsellExceedLargestModalExpFalse: "UpsellExceedLargestModalExpTrue",
            UpsellExceedLargestModalExpError: "UpsellExceedLargestModalExpError",
            UpsellExceedLargestMetadataError: "UpsellExceedLargestMetadataError",
            UpsellExceedLargestNoThumbnailImage: "UpsellExceedLargestNoThumbnailImage",
            UpsellFromGamesPage: "UpsellFromGamesPage",
            UpsellFailed: "UpsellFailed",
            UpsellFailedDueToNoAvailablePackage: "UpsellFailedDueToNoAvailablePackage",
            UpsellFailedDueToFailedPackageRequest: "UpsellFailedDueToFailedPackageRequest",
            AutoPurchaseEntryPoint: "AutoPurchaseEntryPoint",
            AutoPurchaseStarted: "AutoPurchaseStarted",
            AutoPurchaseSucceed: "AutoPurchaseSucceed",
            AutoPurchaseSucceedClose: "AutoPurchaseSucceedClose",
            AutoPurchaseSucceedBackToShop: "AutoPurchaseSucceedBackToShop",
            AutoPurchaseSucceedEquipMyAvatar: "AutoPurchaseSucceedEquipMyAvatar",
            AutoPurchaseFailed: "AutoPurchaseFailed",
            AutoPurchaseErrorFromPurchaseApi: "AutoPurchaseErrorFromPurchaseApi",
            AutoPurchaseFailedDueToStillLowBalance: "AutoPurchaseFailedDueToStillLowBalance",
            AutoPurchasePotentialHackingActionSpotted: "AutoPurchasePotentialHackingActionSpotted",
            AutoPurchasePotentialHackingActionSpotted2: "AutoPurchasePotentialHackingActionSpotted2",
            AutoPurchasePotentialHackingActionSpotted3: "AutoPurchasePotentialHackingActionSpotted3",
            AutoPurchasePotentialHackingActionSpotted4: "AutoPurchasePotentialHackingActionSpotted4",
            ShowU13PaymentModal: "ShowU13PaymentModal",
            ShowU13MonthlyThreshold1Modal: "ShowU13MonthlyThreshold1Modal",
            ShowU13MonthlyThreshold2Modal: "ShowU13MonthlyThreshold2Modal",
            ShowParentalConsentWarningPaymentModal13To17Modal: "ShowParentalConsentWarningPaymentModal13To17Modal",
            ConfirmU13PaymentModal: "ConfirmU13PaymentModal",
            ConfirmU13MonthlyThreshold1Modal: "ConfirmU13MonthlyThreshold1Modal",
            ConfirmU13MonthlyThreshold2Modal: "ConfirmU13MonthlyThreshold2Modal",
            ConfirmParentalConsentWarningPaymentModal13To17Modal: "ConfirmParentalConsentWarningPaymentModal13To17Modal",
            U13PaymentModalEmailVerificationTriggered: "U13PaymentModalEmailVerificationTriggered",
            U13PaymentModalFailedToShow: "U13PaymentModalFailedToShow",
            U13PaymentModalNoAction: "U13PaymentModalNoAction"
        },
        x = CoreUtilities,
        I = function(e, i, l, s) {
            return new(l = l || Promise)(function(n, t) {
                function r(e) {
                    try {
                        o(s.next(e))
                    } catch (e) {
                        t(e)
                    }
                }

                function a(e) {
                    try {
                        o(s.throw(e))
                    } catch (e) {
                        t(e)
                    }
                }

                function o(e) {
                    var t;
                    e.done ? n(e.value) : ((t = e.value) instanceof l ? t : new l(function(e) {
                        e(t)
                    })).then(r, a)
                }
                o((s = s.apply(e, i || [])).next())
            })
        },
        N = function(n, r) {
            var a, o, i, l = {
                    label: 0,
                    sent: function() {
                        if (1 & i[0]) throw i[1];
                        return i[1]
                    },
                    trys: [],
                    ops: []
                },
                e = {
                    next: t(0),
                    throw: t(1),
                    return: t(2)
                };
            return "function" == typeof Symbol && (e[Symbol.iterator] = function() {
                return this
            }), e;

            function t(t) {
                return function(e) {
                    return function(t) {
                        if (a) throw new TypeError("Generator is already executing.");
                        for (; l;) try {
                            if (a = 1, o && (i = 2 & t[0] ? o.return : t[0] ? o.throw || ((i = o.return) && i.call(o), 0) : o.next) && !(i = i.call(o, t[1])).done) return i;
                            switch (o = 0, i && (t = [2 & t[0], i.value]), t[0]) {
                                case 0:
                                case 1:
                                    i = t;
                                    break;
                                case 4:
                                    return l.label++, {
                                        value: t[1],
                                        done: !1
                                    };
                                case 5:
                                    l.label++, o = t[1], t = [0];
                                    continue;
                                case 7:
                                    t = l.ops.pop(), l.trys.pop();
                                    continue;
                                default:
                                    if (!(i = 0 < (i = l.trys).length && i[i.length - 1]) && (6 === t[0] || 2 === t[0])) {
                                        l = 0;
                                        continue
                                    }
                                    if (3 === t[0] && (!i || t[1] > i[0] && t[1] < i[3])) {
                                        l.label = t[1];
                                        break
                                    }
                                    if (6 === t[0] && l.label < i[1]) {
                                        l.label = i[1], i = t;
                                        break
                                    }
                                    if (i && l.label < i[2]) {
                                        l.label = i[2], l.ops.push(t);
                                        break
                                    }
                                    i[2] && l.ops.pop(), l.trys.pop();
                                    continue
                            }
                            t = r.call(n, l)
                        } catch (e) {
                            t = [6, e], o = 0
                        } finally {
                            a = i = 0
                        }
                        if (5 & t[0]) throw t[1];
                        return {
                            value: t[0] ? t[1] : void 0,
                            done: !0
                        }
                    }([t, e])
                }
            }
        };

    function C(e, t) {
        return void 0 === t && (t = !0), t ? "<span class='icon-robux-16x16'></span><span class='text-robux'>" + h.NumberFormatting.commas(e) + "</span>" : "<span class='icon-robux-gray-16x16'></span><span class='text'>" + h.NumberFormatting.commas(e) + "</span>"
    }
    var R = function(e, i, l, s) {
            return new(l = l || Promise)(function(n, t) {
                function r(e) {
                    try {
                        o(s.next(e))
                    } catch (e) {
                        t(e)
                    }
                }

                function a(e) {
                    try {
                        o(s.throw(e))
                    } catch (e) {
                        t(e)
                    }
                }

                function o(e) {
                    var t;
                    e.done ? n(e.value) : ((t = e.value) instanceof l ? t : new l(function(e) {
                        e(t)
                    })).then(r, a)
                }
                o((s = s.apply(e, i || [])).next())
            })
        },
        L = function(n, r) {
            var a, o, i, l = {
                    label: 0,
                    sent: function() {
                        if (1 & i[0]) throw i[1];
                        return i[1]
                    },
                    trys: [],
                    ops: []
                },
                e = {
                    next: t(0),
                    throw: t(1),
                    return: t(2)
                };
            return "function" == typeof Symbol && (e[Symbol.iterator] = function() {
                return this
            }), e;

            function t(t) {
                return function(e) {
                    return function(t) {
                        if (a) throw new TypeError("Generator is already executing.");
                        for (; l;) try {
                            if (a = 1, o && (i = 2 & t[0] ? o.return : t[0] ? o.throw || ((i = o.return) && i.call(o), 0) : o.next) && !(i = i.call(o, t[1])).done) return i;
                            switch (o = 0, i && (t = [2 & t[0], i.value]), t[0]) {
                                case 0:
                                case 1:
                                    i = t;
                                    break;
                                case 4:
                                    return l.label++, {
                                        value: t[1],
                                        done: !1
                                    };
                                case 5:
                                    l.label++, o = t[1], t = [0];
                                    continue;
                                case 7:
                                    t = l.ops.pop(), l.trys.pop();
                                    continue;
                                default:
                                    if (!(i = 0 < (i = l.trys).length && i[i.length - 1]) && (6 === t[0] || 2 === t[0])) {
                                        l = 0;
                                        continue
                                    }
                                    if (3 === t[0] && (!i || t[1] > i[0] && t[1] < i[3])) {
                                        l.label = t[1];
                                        break
                                    }
                                    if (6 === t[0] && l.label < i[1]) {
                                        l.label = i[1], i = t;
                                        break
                                    }
                                    if (i && l.label < i[2]) {
                                        l.label = i[2], l.ops.push(t);
                                        break
                                    }
                                    i[2] && l.ops.pop(), l.trys.pop();
                                    continue
                            }
                            t = r.call(n, l)
                        } catch (e) {
                            t = [6, e], o = 0
                        } finally {
                            a = i = 0
                        }
                        if (5 & t[0]) throw t[1];
                        return {
                            value: t[0] ? t[1] : void 0,
                            done: !0
                        }
                    }([t, e])
                }
            }
        };

    function F() {
        var e;
        m.upsellUtil.expireUpsellCookie(), window.history && ((e = new URL(window.location.href)).searchParams.delete(m.upsellUtil.constants.UPSELL_QUERY_PARAM_KEY), e = e.href, window.history.pushState({
            path: e
        }, "", e))
    }
    var O = function(e, i, l, s) {
            return new(l = l || Promise)(function(n, t) {
                function r(e) {
                    try {
                        o(s.next(e))
                    } catch (e) {
                        t(e)
                    }
                }

                function a(e) {
                    try {
                        o(s.throw(e))
                    } catch (e) {
                        t(e)
                    }
                }

                function o(e) {
                    var t;
                    e.done ? n(e.value) : ((t = e.value) instanceof l ? t : new l(function(e) {
                        e(t)
                    })).then(r, a)
                }
                o((s = s.apply(e, i || [])).next())
            })
        },
        G = function(n, r) {
            var a, o, i, l = {
                    label: 0,
                    sent: function() {
                        if (1 & i[0]) throw i[1];
                        return i[1]
                    },
                    trys: [],
                    ops: []
                },
                e = {
                    next: t(0),
                    throw: t(1),
                    return: t(2)
                };
            return "function" == typeof Symbol && (e[Symbol.iterator] = function() {
                return this
            }), e;

            function t(t) {
                return function(e) {
                    return function(t) {
                        if (a) throw new TypeError("Generator is already executing.");
                        for (; l;) try {
                            if (a = 1, o && (i = 2 & t[0] ? o.return : t[0] ? o.throw || ((i = o.return) && i.call(o), 0) : o.next) && !(i = i.call(o, t[1])).done) return i;
                            switch (o = 0, i && (t = [2 & t[0], i.value]), t[0]) {
                                case 0:
                                case 1:
                                    i = t;
                                    break;
                                case 4:
                                    return l.label++, {
                                        value: t[1],
                                        done: !1
                                    };
                                case 5:
                                    l.label++, o = t[1], t = [0];
                                    continue;
                                case 7:
                                    t = l.ops.pop(), l.trys.pop();
                                    continue;
                                default:
                                    if (!(i = 0 < (i = l.trys).length && i[i.length - 1]) && (6 === t[0] || 2 === t[0])) {
                                        l = 0;
                                        continue
                                    }
                                    if (3 === t[0] && (!i || t[1] > i[0] && t[1] < i[3])) {
                                        l.label = t[1];
                                        break
                                    }
                                    if (6 === t[0] && l.label < i[1]) {
                                        l.label = i[1], i = t;
                                        break
                                    }
                                    if (i && l.label < i[2]) {
                                        l.label = i[2], l.ops.push(t);
                                        break
                                    }
                                    i[2] && l.ops.pop(), l.trys.pop();
                                    continue
                            }
                            t = r.call(n, l)
                        } catch (e) {
                            t = [6, e], o = 0
                        } finally {
                            a = i = 0
                        }
                        if (5 & t[0]) throw t[1];
                        return {
                            value: t[0] ? t[1] : void 0,
                            done: !0
                        }
                    }([t, e])
                }
            }
        },
        B = window.EventTracker ? EventTracker : {
            fireEvent: console.log,
            start: console.log,
            endSuccess: console.log,
            endCancel: console.log,
            endFailure: console.log
        };

    function D(e) {
        (0, B.fireEvent)(t + e)
    }

    function k(e, t) {
        var n;
        t === S.BUNDLE || t === S.BUNDLE_ALIAS ? (n = e, (0, B.fireEvent)(r + n)) : t === S.GAME_PASS ? (n = e, (0, B.fireEvent)(w + n)) : D(t ? e : M.UnknownErrorNoAsset)
    }

    function W(e, t, n, r, a) {
        var o = r.getTranslationResource(p),
            i = r.getTranslationResource(c),
            l = "<br /><br />",
            r = {
                lineBreak: l,
                linebreak: l
            },
            l = "";
        t === _.U13PaymentModal ? l = o.get(P.featurePremiumScaryModalBodyNewDescription, r) : t === _.ParentalConsentWarningPaymentModal13To17 ? l = o.get(P.featurePremiumScaryModalBody13To17Description, {}) : t === _.U13MonthlyThreshold1Modal ? l = o.get(P.featurePremiumScaryModalThreshold1BodyDescription, r) : t === _.U13MonthlyThreshold2Modal && (l = o.get(P.featurePremiumScaryModalThreshold2BodyDescription, r)), h.Dialog.open({
            titleText: o.get(P.featurePremiumScaryModalTitleHeading, {}),
            bodyContent: '<div><span class="text-description">' + l + '</span></div><div class="text-center"><div class="icon-warning"></div></div>',
            declineText: i.get(P.commonUiCancelAction, {}),
            acceptText: i.get(P.commonUiOkAction, {}),
            onAccept: function() {
                return function(r, a) {
                    return O(this, void 0, Promise, function() {
                        var t, n;
                        return G(this, function(e) {
                            switch (e.label) {
                                case 0:
                                    n = {
                                        acknowledgement: "Confirmed" + r
                                    }, t = {
                                        url: "" + h.EnvironmentUrls.apiGatewayUrl + v,
                                        withCredentials: !0,
                                        timeout: U
                                    }, e.label = 1;
                                case 1:
                                    return e.trys.push([1, 3, , 4]), [4, x.httpService.post(t, n)];
                                case 2:
                                    return e.sent(), a(), [2, Promise.resolve()];
                                case 3:
                                    return n = e.sent(), [2, Promise.reject(n)];
                                case 4:
                                    return [2]
                            }
                        })
                    })
                }(t, n).then(function() {
                    t === _.U13PaymentModal ? k(M.ConfirmU13PaymentModal, null == a ? void 0 : a.assetType) : t === _.U13MonthlyThreshold1Modal ? k(M.ConfirmU13MonthlyThreshold1Modal, null == a ? void 0 : a.assetType) : t === _.U13MonthlyThreshold2Modal ? k(M.ConfirmU13MonthlyThreshold2Modal, null == a ? void 0 : a.assetType) : k(M.ConfirmParentalConsentWarningPaymentModal13To17Modal, null == a ? void 0 : a.assetType)
                }).catch(function() {
                    n()
                }), !1
            },
            onDecline: function() {
                return k(M.UpsellCancelledFromU13Modal, null == a ? void 0 : a.assetType), F(), !1
            },
            onCancel: function() {
                return k(M.UpsellCancelledFromU13Modal, null == a ? void 0 : a.assetType), F(), !1
            },
            allowHtmlContentInBody: !0,
            allowHtmlContentInFooter: !1,
            fieldValidationRequired: !0,
            dismissable: !0,
            xToCancel: !0
        })
    }
    var e = function(e, i, l, s) {
            return new(l = l || Promise)(function(n, t) {
                function r(e) {
                    try {
                        o(s.next(e))
                    } catch (e) {
                        t(e)
                    }
                }

                function a(e) {
                    try {
                        o(s.throw(e))
                    } catch (e) {
                        t(e)
                    }
                }

                function o(e) {
                    var t;
                    e.done ? n(e.value) : ((t = e.value) instanceof l ? t : new l(function(e) {
                        e(t)
                    })).then(r, a)
                }
                o((s = s.apply(e, i || [])).next())
            })
        },
        V = function(n, r) {
            var a, o, i, l = {
                    label: 0,
                    sent: function() {
                        if (1 & i[0]) throw i[1];
                        return i[1]
                    },
                    trys: [],
                    ops: []
                },
                e = {
                    next: t(0),
                    throw: t(1),
                    return: t(2)
                };
            return "function" == typeof Symbol && (e[Symbol.iterator] = function() {
                return this
            }), e;

            function t(t) {
                return function(e) {
                    return function(t) {
                        if (a) throw new TypeError("Generator is already executing.");
                        for (; l;) try {
                            if (a = 1, o && (i = 2 & t[0] ? o.return : t[0] ? o.throw || ((i = o.return) && i.call(o), 0) : o.next) && !(i = i.call(o, t[1])).done) return i;
                            switch (o = 0, i && (t = [2 & t[0], i.value]), t[0]) {
                                case 0:
                                case 1:
                                    i = t;
                                    break;
                                case 4:
                                    return l.label++, {
                                        value: t[1],
                                        done: !1
                                    };
                                case 5:
                                    l.label++, o = t[1], t = [0];
                                    continue;
                                case 7:
                                    t = l.ops.pop(), l.trys.pop();
                                    continue;
                                default:
                                    if (!(i = 0 < (i = l.trys).length && i[i.length - 1]) && (6 === t[0] || 2 === t[0])) {
                                        l = 0;
                                        continue
                                    }
                                    if (3 === t[0] && (!i || t[1] > i[0] && t[1] < i[3])) {
                                        l.label = t[1];
                                        break
                                    }
                                    if (6 === t[0] && l.label < i[1]) {
                                        l.label = i[1], i = t;
                                        break
                                    }
                                    if (i && l.label < i[2]) {
                                        l.label = i[2], l.ops.push(t);
                                        break
                                    }
                                    i[2] && l.ops.pop(), l.trys.pop();
                                    continue
                            }
                            t = r.call(n, l)
                        } catch (e) {
                            t = [6, e], o = 0
                        } finally {
                            a = i = 0
                        }
                        if (5 & t[0]) throw t[1];
                        return {
                            value: t[0] ? t[1] : void 0,
                            done: !0
                        }
                    }([t, e])
                }
            }
        };

    function H(e) {
        m.paymentFlowAnalyticsService.sendUserPurchaseFlowEvent(m.paymentFlowAnalyticsService.ENUM_TRIGGERING_CONTEXT.WEB_CATALOG_ROBUX_UPSELL, !0, m.paymentFlowAnalyticsService.ENUM_VIEW_NAME.PURCHASE_WARNING, m.paymentFlowAnalyticsService.ENUM_PURCHASE_EVENT_TYPE.VIEW_SHOWN, e)
    }

    function X(n, r, a, o, i) {
        var l;
        return e(this, void 0, void 0, function() {
            var t;
            return V(this, function(e) {
                switch (e.label) {
                    case 0:
                        if (!r) return a(), [2, Promise.resolve()];
                        e.label = 1;
                    case 1:
                        return e.trys.push([1, 3, , 4]), [4, function(a) {
                            return R(this, void 0, Promise, function() {
                                var t, n, r;
                                return L(this, function(e) {
                                    switch (e.label) {
                                        case 0:
                                            n = !h.CurrentUser.isPremiumUser, t = {
                                                productId: a,
                                                is13To17ScaryModalEnabled: n
                                            }, n = {
                                                url: "" + h.EnvironmentUrls.apiGatewayUrl + y,
                                                withCredentials: !0,
                                                timeout: U
                                            }, e.label = 1;
                                        case 1:
                                            return e.trys.push([1, 3, , 4]), [4, x.httpService.get(n, t)];
                                        case 2:
                                            return 200 === (r = e.sent()).status && r.data.action ? [2, Promise.resolve(r.data.action)] : [2, Promise.resolve(_.NoAction)];
                                        case 3:
                                            return r = e.sent(), [2, Promise.reject(r)];
                                        case 4:
                                            return [2]
                                    }
                                })
                            })
                        }(n.roblox_product_id)];
                    case 2:
                        return (t = e.sent()) === _.U13PaymentModal || t === _.ParentalConsentWarningPaymentModal13To17 || t === _.U13MonthlyThreshold1Modal || t === _.U13MonthlyThreshold2Modal ? (t === _.U13PaymentModal ? (H(m.paymentFlowAnalyticsService.ENUM_VIEW_MESSAGE.U13_PAYMENT_MODAL), k(M.ShowU13PaymentModal, null == i ? void 0 : i.assetType)) : t === _.U13MonthlyThreshold1Modal ? (H(m.paymentFlowAnalyticsService.ENUM_VIEW_MESSAGE.U13_MONTHLY_THRESHOLD_1_MODAL), k(M.ShowU13MonthlyThreshold1Modal, null == i ? void 0 : i.assetType)) : t === _.U13MonthlyThreshold2Modal ? (H(m.paymentFlowAnalyticsService.ENUM_VIEW_MESSAGE.U13_MONTHLY_THRESHOLD_2_MODAL), k(M.ShowU13MonthlyThreshold2Modal, null == i ? void 0 : i.assetType)) : (H(m.paymentFlowAnalyticsService.ENUM_VIEW_MESSAGE.PAYMENT_MODAL_13_TO_17), k(M.ShowParentalConsentWarningPaymentModal13To17Modal, null == i ? void 0 : i.assetType)), W(0, t, a, o, i)) : t === _.RequireEmailVerification ? (k(M.U13PaymentModalEmailVerificationTriggered, null == i ? void 0 : i.assetType), null !== (l = h.EmailVerificationService.handleUserEmailVerificationRequiredByPurchaseWarning()) && void 0 !== l && l.then(function(e) {
                            H(m.paymentFlowAnalyticsService.ENUM_VIEW_MESSAGE.REQUIRE_EMAIL_VERIFICATION), null != e && e.emailAddress && null != e && e.verified && a()
                        })) : (k(M.U13PaymentModalNoAction, null == i ? void 0 : i.assetType), a()), [2, Promise.resolve()];
                    case 3:
                        return t = e.sent(), [2, Promise.reject(t)];
                    case 4:
                        return [2]
                }
            })
        })
    }

    function Y(e, t, n) {
        var r = function(e) {
            var t = m.upsellUtil.constants.UPSELL_TARGET_ITEM_URL_REGEX.exec(window.location.pathname);
            m.upsellUtil.constants.UPSELL_TARGET_ITEM_URL_REGEX.lastIndex = 0;
            var n = null;
            if (Array.isArray(t) && 0 < t.length && (n = t[0]), !n) return "";
            if (!e || Object.keys(e).length < 4) return "";
            var r = x.uuidService.generateRandomUuid(),
                t = e.expectedCurrency + "," + e.expectedPrice + "," + e.expectedSellerId + "," + (null !== (t = e.userassetId) && void 0 !== t ? t : ""),
                e = "" + (e.productId || ""),
                t = r + "," + n + "," + h.CurrentUser.userId + "," + t + "," + e;
            return (e = new Date).setHours(e.getHours() + 1), e = [m.upsellUtil.constants.UPSELL_COOKIE_KEY, "=", encodeURIComponent(t), "; expires=" + e.toUTCString(), "; path=/", "; domain=.", h.EnvironmentUrls.domain, ";"], document.cookie = e.join(""), r
        }(n);
        k(M.UpsellContinued, null == n ? void 0 : n.assetType), m.paymentFlowAnalyticsService.sendUserPurchaseFlowEvent(m.paymentFlowAnalyticsService.ENUM_TRIGGERING_CONTEXT.WEB_CATALOG_ROBUX_UPSELL, !0, m.paymentFlowAnalyticsService.ENUM_VIEW_NAME.ROBUX_UPSELL, m.paymentFlowAnalyticsService.ENUM_PURCHASE_EVENT_TYPE.USER_INPUT, m.paymentFlowAnalyticsService.ENUM_VIEW_MESSAGE.GO_TO_ROBUX_PURCHASE_PAGE), window.location.href = x.urlService.getAbsoluteUrl(a + "?ap=" + e.roblox_product_id + "&UpsellUuid=" + r + ")}")
    }

    function j(e, t, n, r, a, o, i) {
        var l, s, c, u = C(t.expectedItemPrice),
            n = "<div class='item-card-container item-preview'>\n        <div class='item-card-thumb'>\n          <img alt='item preview' src='" + (null !== (n = n.thumbnailImageUrl) && void 0 !== n ? n : "") + "' />\n        </div>\n        <div class='item-info text-name'>\n        <div class='text-overflow item-card-name'>" + (0, x.escapeHtml)()(t.assetName) + "</div>\n          <div class='text-robux item-card-price'>" + u + "</div>\n        </div>\n      </div>";
        k(M.UpsellShown, null === (u = t.buyButtonElementDataset) || void 0 === u ? void 0 : u.assetType), m.paymentFlowAnalyticsService.sendUserPurchaseFlowEvent(m.paymentFlowAnalyticsService.ENUM_TRIGGERING_CONTEXT.WEB_CATALOG_ROBUX_UPSELL, !0, m.paymentFlowAnalyticsService.ENUM_VIEW_NAME.ROBUX_UPSELL, m.paymentFlowAnalyticsService.ENUM_PURCHASE_EVENT_TYPE.VIEW_SHOWN), n = n, e = e, l = t, s = r, a = a, o = o, c = i, i = "<a class='text-link-secondary terms-of-use-link' target='_blank' href='" + x.urlService.getUrlWithLocale(d, a.getRobloxLocale()) + "'>", a = C(e.shortfallPrice, !1), e = C(s.robux_amount), i = n + o.get(P.insufficientRobuxMessage, {
            divTagStart: "<div class='modal-message-block text-center border-top'>",
            divTagEnd: "</div>",
            robuxNeeded: a,
            robuxPackageAmount: e,
            lineBreak: "",
            aTagStart: i,
            aTagEnd: "</a>"
        }), h.Dialog.open({
            titleText: o.get(P.insufficientRobuxHeading, {}),
            bodyContent: i,
            declineText: o.get(P.cancelAction, {}),
            acceptText: o.get(P.buyRobuxAndItemAction, {}),
            acceptColor: "btn-primary-md",
            onAccept: function() {
                return m.paymentFlowAnalyticsService.sendUserPurchaseFlowEvent(m.paymentFlowAnalyticsService.ENUM_TRIGGERING_CONTEXT.WEB_CATALOG_ROBUX_UPSELL, !0, m.paymentFlowAnalyticsService.ENUM_VIEW_NAME.ROBUX_UPSELL, m.paymentFlowAnalyticsService.ENUM_PURCHASE_EVENT_TYPE.USER_INPUT, m.paymentFlowAnalyticsService.ENUM_VIEW_MESSAGE.BUY_ROBUX_AND_ITEM), X(s, h.CurrentUser.isUnder13, function() {
                    return Y(s, 0, l.buyButtonElementDataset)
                }, c, l.buyButtonElementDataset).catch(function() {
                    var e;
                    k(M.U13PaymentModalFailedToShow, null === (e = l.buyButtonElementDataset) || void 0 === e ? void 0 : e.assetType), Y(s, 0, l.buyButtonElementDataset)
                }), !1
            },
            onDecline: function() {
                var e;
                m.paymentFlowAnalyticsService.sendUserPurchaseFlowEvent(m.paymentFlowAnalyticsService.ENUM_TRIGGERING_CONTEXT.WEB_CATALOG_ROBUX_UPSELL, !0, m.paymentFlowAnalyticsService.ENUM_VIEW_NAME.ROBUX_UPSELL, m.paymentFlowAnalyticsService.ENUM_PURCHASE_EVENT_TYPE.USER_INPUT, m.paymentFlowAnalyticsService.ENUM_VIEW_MESSAGE.CANCEL), k(M.UpsellCancelled, null === (e = l.buyButtonElementDataset) || void 0 === e ? void 0 : e.assetType)
            },
            onCancel: function() {
                var e;
                m.paymentFlowAnalyticsService.sendUserPurchaseFlowEvent(m.paymentFlowAnalyticsService.ENUM_TRIGGERING_CONTEXT.WEB_CATALOG_ROBUX_UPSELL, !0, m.paymentFlowAnalyticsService.ENUM_VIEW_NAME.ROBUX_UPSELL, m.paymentFlowAnalyticsService.ENUM_PURCHASE_EVENT_TYPE.USER_INPUT, m.paymentFlowAnalyticsService.ENUM_VIEW_MESSAGE.CANCEL), k(M.UpsellCancelled, null === (e = l.buyButtonElementDataset) || void 0 === e ? void 0 : e.assetType)
            },
            allowHtmlContentInBody: !0,
            allowHtmlContentInFooter: !1,
            fieldValidationRequired: !0,
            dismissable: !0,
            xToCancel: !0
        })
    }

    function n() {
        var n = this;
        this.overlayDiv = null, this.contentDiv = null, this.loadingMessageSpan = null, this.spinnerSpan = null, this.loadingOverlayElementId = "loading-overlay", this.show = function(e) {
            var t = n.getOrCreateOverlayDiv(),
                t = n.getOrCreateContentDiv(t);
            return n.getOrCreateSpinnerSpan(t), n.updateOrCreateMessage(e), n
        }, this.hide = function() {
            var e;
            null !== (e = null === (e = n.spinnerSpan) || void 0 === e ? void 0 : e.parentNode) && void 0 !== e && e.removeChild(n.spinnerSpan), null !== (e = null === (e = n.loadingMessageSpan) || void 0 === e ? void 0 : e.parentNode) && void 0 !== e && e.removeChild(n.loadingMessageSpan), null !== (e = null === (e = n.contentDiv) || void 0 === e ? void 0 : e.parentNode) && void 0 !== e && e.removeChild(n.contentDiv), null !== (e = null === (e = n.overlayDiv) || void 0 === e ? void 0 : e.parentNode) && void 0 !== e && e.removeChild(n.overlayDiv), n.overlayDiv = null, n.contentDiv = null, n.spinnerSpan = null, n.loadingMessageSpan = null
        }, this.updateMessage = function(e) {
            n._loadingMessage = e, n.updateOrCreateMessage(e)
        }, this.updateOrCreateMessage = function(e) {
            var t;
            if (n.overlayDiv) return e ? void(n.loadingMessageSpan ? n.loadingMessageSpan.innerText = e : ((t = document.createElement("span")).innerText = e, t.classList.add("loading-message"), n.getOrCreateContentDiv(n.overlayDiv).appendChild(t), n.loadingMessageSpan = t)) : (null !== (t = null === (t = n.loadingMessageSpan) || void 0 === t ? void 0 : t.parentNode) && void 0 !== t && t.removeChild(n.loadingMessageSpan), void(n.loadingMessageSpan = null))
        }, this.getOrCreateContentDiv = function(e) {
            if (n.contentDiv) return n.contentDiv;
            var t = document.createElement("div");
            return t.classList.add("loading-overlay-content"), n.contentDiv = t, e.appendChild(t), t
        }, this.getOrCreateOverlayDiv = function() {
            if (n.overlayDiv) return n.overlayDiv;
            var e = document.getElementById(n.loadingOverlayElementId);
            if (e) return n.overlayDiv = e;
            e = document.createElement("div");
            return (n.overlayDiv = e).id = n.loadingOverlayElementId, e.classList.add("loading-overlay"), document.body.appendChild(e), e
        }, this.getOrCreateSpinnerSpan = function(e) {
            if (n.spinnerSpan) return n.spinnerSpan;
            var t = document.createElement("span");
            return t.classList.add("spinner", "spinner-default"), e.appendChild(t), n.spinnerSpan = t
        }
    }
    var q = (Object.defineProperty(n.prototype, "loadingMessage", {
        get: function() {
            return this._loadingMessage
        },
        enumerable: !1,
        configurable: !0
    }), n);

    function K(e) {
        m.upsellUtil.expireUpsellCookie(), window.location.href = h.Endpoints.getAbsoluteUrl(e)
    }

    function Q() {
        window.open(h.EnvironmentUrls.vngGamesShopUrl, "_blank")
    }
    var z = function(e, i, l, s) {
            return new(l = l || Promise)(function(n, t) {
                function r(e) {
                    try {
                        o(s.next(e))
                    } catch (e) {
                        t(e)
                    }
                }

                function a(e) {
                    try {
                        o(s.throw(e))
                    } catch (e) {
                        t(e)
                    }
                }

                function o(e) {
                    var t;
                    e.done ? n(e.value) : ((t = e.value) instanceof l ? t : new l(function(e) {
                        e(t)
                    })).then(r, a)
                }
                o((s = s.apply(e, i || [])).next())
            })
        },
        J = function(n, r) {
            var a, o, i, l = {
                    label: 0,
                    sent: function() {
                        if (1 & i[0]) throw i[1];
                        return i[1]
                    },
                    trys: [],
                    ops: []
                },
                e = {
                    next: t(0),
                    throw: t(1),
                    return: t(2)
                };
            return "function" == typeof Symbol && (e[Symbol.iterator] = function() {
                return this
            }), e;

            function t(t) {
                return function(e) {
                    return function(t) {
                        if (a) throw new TypeError("Generator is already executing.");
                        for (; l;) try {
                            if (a = 1, o && (i = 2 & t[0] ? o.return : t[0] ? o.throw || ((i = o.return) && i.call(o), 0) : o.next) && !(i = i.call(o, t[1])).done) return i;
                            switch (o = 0, i && (t = [2 & t[0], i.value]), t[0]) {
                                case 0:
                                case 1:
                                    i = t;
                                    break;
                                case 4:
                                    return l.label++, {
                                        value: t[1],
                                        done: !1
                                    };
                                case 5:
                                    l.label++, o = t[1], t = [0];
                                    continue;
                                case 7:
                                    t = l.ops.pop(), l.trys.pop();
                                    continue;
                                default:
                                    if (!(i = 0 < (i = l.trys).length && i[i.length - 1]) && (6 === t[0] || 2 === t[0])) {
                                        l = 0;
                                        continue
                                    }
                                    if (3 === t[0] && (!i || t[1] > i[0] && t[1] < i[3])) {
                                        l.label = t[1];
                                        break
                                    }
                                    if (6 === t[0] && l.label < i[1]) {
                                        l.label = i[1], i = t;
                                        break
                                    }
                                    if (i && l.label < i[2]) {
                                        l.label = i[2], l.ops.push(t);
                                        break
                                    }
                                    i[2] && l.ops.pop(), l.trys.pop();
                                    continue
                            }
                            t = r.call(n, l)
                        } catch (e) {
                            t = [6, e], o = 0
                        } finally {
                            a = i = 0
                        }
                        if (5 & t[0]) throw t[1];
                        return {
                            value: t[0] ? t[1] : void 0,
                            done: !0
                        }
                    }([t, e])
                }
            }
        },
        Z = function() {
            return (Z = Object.assign || function(e) {
                for (var t, n = 1, r = arguments.length; n < r; n++)
                    for (var a in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
                return e
            }).apply(this, arguments)
        },
        $ = function(e, i, l, s) {
            return new(l = l || Promise)(function(n, t) {
                function r(e) {
                    try {
                        o(s.next(e))
                    } catch (e) {
                        t(e)
                    }
                }

                function a(e) {
                    try {
                        o(s.throw(e))
                    } catch (e) {
                        t(e)
                    }
                }

                function o(e) {
                    var t;
                    e.done ? n(e.value) : ((t = e.value) instanceof l ? t : new l(function(e) {
                        e(t)
                    })).then(r, a)
                }
                o((s = s.apply(e, i || [])).next())
            })
        },
        ee = function(n, r) {
            var a, o, i, l = {
                    label: 0,
                    sent: function() {
                        if (1 & i[0]) throw i[1];
                        return i[1]
                    },
                    trys: [],
                    ops: []
                },
                e = {
                    next: t(0),
                    throw: t(1),
                    return: t(2)
                };
            return "function" == typeof Symbol && (e[Symbol.iterator] = function() {
                return this
            }), e;

            function t(t) {
                return function(e) {
                    return function(t) {
                        if (a) throw new TypeError("Generator is already executing.");
                        for (; l;) try {
                            if (a = 1, o && (i = 2 & t[0] ? o.return : t[0] ? o.throw || ((i = o.return) && i.call(o), 0) : o.next) && !(i = i.call(o, t[1])).done) return i;
                            switch (o = 0, i && (t = [2 & t[0], i.value]), t[0]) {
                                case 0:
                                case 1:
                                    i = t;
                                    break;
                                case 4:
                                    return l.label++, {
                                        value: t[1],
                                        done: !1
                                    };
                                case 5:
                                    l.label++, o = t[1], t = [0];
                                    continue;
                                case 7:
                                    t = l.ops.pop(), l.trys.pop();
                                    continue;
                                default:
                                    if (!(i = 0 < (i = l.trys).length && i[i.length - 1]) && (6 === t[0] || 2 === t[0])) {
                                        l = 0;
                                        continue
                                    }
                                    if (3 === t[0] && (!i || t[1] > i[0] && t[1] < i[3])) {
                                        l.label = t[1];
                                        break
                                    }
                                    if (6 === t[0] && l.label < i[1]) {
                                        l.label = i[1], i = t;
                                        break
                                    }
                                    if (i && l.label < i[2]) {
                                        l.label = i[2], l.ops.push(t);
                                        break
                                    }
                                    i[2] && l.ops.pop(), l.trys.pop();
                                    continue
                            }
                            t = r.call(n, l)
                        } catch (e) {
                            t = [6, e], o = 0
                        } finally {
                            a = i = 0
                        }
                        if (5 & t[0]) throw t[1];
                        return {
                            value: t[0] ? t[1] : void 0,
                            done: !0
                        }
                    }([t, e])
                }
            }
        };

    function te(e, t) {
        try {
            h.EventStream.SendEventWithTarget(b.EVENT_NAME, e, t, h.EventStream.TargetTypes.WWW)
        } catch (e) {}
    }
    var ne = function(e, i, l, s) {
            return new(l = l || Promise)(function(n, t) {
                function r(e) {
                    try {
                        o(s.next(e))
                    } catch (e) {
                        t(e)
                    }
                }

                function a(e) {
                    try {
                        o(s.throw(e))
                    } catch (e) {
                        t(e)
                    }
                }

                function o(e) {
                    var t;
                    e.done ? n(e.value) : ((t = e.value) instanceof l ? t : new l(function(e) {
                        e(t)
                    })).then(r, a)
                }
                o((s = s.apply(e, i || [])).next())
            })
        },
        re = function(n, r) {
            var a, o, i, l = {
                    label: 0,
                    sent: function() {
                        if (1 & i[0]) throw i[1];
                        return i[1]
                    },
                    trys: [],
                    ops: []
                },
                e = {
                    next: t(0),
                    throw: t(1),
                    return: t(2)
                };
            return "function" == typeof Symbol && (e[Symbol.iterator] = function() {
                return this
            }), e;

            function t(t) {
                return function(e) {
                    return function(t) {
                        if (a) throw new TypeError("Generator is already executing.");
                        for (; l;) try {
                            if (a = 1, o && (i = 2 & t[0] ? o.return : t[0] ? o.throw || ((i = o.return) && i.call(o), 0) : o.next) && !(i = i.call(o, t[1])).done) return i;
                            switch (o = 0, i && (t = [2 & t[0], i.value]), t[0]) {
                                case 0:
                                case 1:
                                    i = t;
                                    break;
                                case 4:
                                    return l.label++, {
                                        value: t[1],
                                        done: !1
                                    };
                                case 5:
                                    l.label++, o = t[1], t = [0];
                                    continue;
                                case 7:
                                    t = l.ops.pop(), l.trys.pop();
                                    continue;
                                default:
                                    if (!(i = 0 < (i = l.trys).length && i[i.length - 1]) && (6 === t[0] || 2 === t[0])) {
                                        l = 0;
                                        continue
                                    }
                                    if (3 === t[0] && (!i || t[1] > i[0] && t[1] < i[3])) {
                                        l.label = t[1];
                                        break
                                    }
                                    if (6 === t[0] && l.label < i[1]) {
                                        l.label = i[1], i = t;
                                        break
                                    }
                                    if (i && l.label < i[2]) {
                                        l.label = i[2], l.ops.push(t);
                                        break
                                    }
                                    i[2] && l.ops.pop(), l.trys.pop();
                                    continue
                            }
                            t = r.call(n, l)
                        } catch (e) {
                            t = [6, e], o = 0
                        } finally {
                            a = i = 0
                        }
                        if (5 & t[0]) throw t[1];
                        return {
                            value: t[0] ? t[1] : void 0,
                            done: !0
                        }
                    }([t, e])
                }
            }
        };

    function ae(e) {
        F(), K(e)
    }

    function oe(e) {
        e && (e.startsWith("/catalog/") || e.startsWith("/bundles/") || e.startsWith("/game-pass/") || e.startsWith(u)) && !e.includes("UpsellUuid=") || (m.upsellUtil.expireUpsellCookie(), window.location.href = h.Endpoints.getAbsoluteUrl("/catalog"))
    }

    function ie(n, r) {
        return ne(this, void 0, Promise, function() {
            var t;
            return re(this, function(e) {
                switch (e.label) {
                    case 0:
                        if (!r) return [2, Promise.reject()];
                        e.label = 1;
                    case 1:
                        return e.trys.push([1, 3, , 4]), [4, function(r) {
                            var a;
                            return z(this, void 0, Promise, function() {
                                var t, n;
                                return J(this, function(e) {
                                    switch (e.label) {
                                        case 0:
                                            t = i.replace("{productId}", r), t = {
                                                url: "" + h.EnvironmentUrls.economyApi + t,
                                                withCredentials: !0
                                            }, e.label = 1;
                                        case 1:
                                            return e.trys.push([1, 3, , 4]), [4, x.httpService.get(t)];
                                        case 2:
                                            return 200 !== (n = e.sent()).status || n.data.reason !== l ? [2, Promise.reject(null === (a = null == n ? void 0 : n.data) || void 0 === a ? void 0 : a.reason)] : [2, Promise.resolve(n.data)];
                                        case 3:
                                            return n = e.sent(), [2, Promise.reject(n)];
                                        case 4:
                                            return [2]
                                    }
                                })
                            })
                        }(r)];
                    case 2:
                        return (t = e.sent()) && 0 !== Object.keys(t).length ? [2, t] : (k(M.AutoPurchasePotentialHackingActionSpotted3, g), te(b.CONTEXT_NAME.PRODUCT_INFO_EMPTY, {
                            itemPath: n,
                            productId: r
                        }), [2, Promise.reject()]);
                    case 3:
                        return t = e.sent(), k(M.AutoPurchasePotentialHackingActionSpotted4, g), te(b.CONTEXT_NAME.PRODUCT_INFO_REQUEST_FAILED, {
                            itemPath: n,
                            productId: r,
                            error: t
                        }), [2, Promise.reject(t)];
                    case 4:
                        return [2]
                }
            })
        })
    }

    function le(o, i, l) {
        return ne(this, void 0, Promise, function() {
            var t, n, r, a;
            return re(this, function(e) {
                switch (e.label) {
                    case 0:
                        (a = m.upsellUtil.parseUpsellCookie()) && 0 !== Object.keys(a).length && (!a.targetItemUrl || o.startsWith(a.targetItemUrl)) || (k(M.AutoPurchasePotentialHackingActionSpotted2, g), te(b.CONTEXT_NAME.COOKIE_PARSE_FAILED, {
                            itemPath: o,
                            upsellCookieData: a
                        }), ae(o)), (t = i) || ae(o), e.label = 1;
                    case 1:
                        return e.trys.push([1, 3, , 4]), [4, ie(o, a.productId)];
                    case 2:
                        return n = e.sent(), [3, 4];
                    case 3:
                        return r = e.sent(), te(b.CONTEXT_NAME.PRODUCT_ID_NOT_EXIST, {
                            itemPath: o,
                            upsellCookieData: a,
                            error: r
                        }), ae(o), [2, Promise.reject()];
                    case 4:
                        return [4, function(r, a) {
                            return $(this, void 0, Promise, function() {
                                var t, n;
                                return ee(this, function(e) {
                                    switch (e.label) {
                                        case 0:
                                            n = a === S.GAME_PASS ? (t = A.GAME_PASS, {
                                                gamePassIds: r
                                            }) : a === S.BUNDLE ? (t = A.BUNDLE, {
                                                bundleIds: r
                                            }) : (t = A.ASSET, {
                                                assetIds: r
                                            }), n = Z(Z({}, n), T), t = {
                                                url: "" + h.EnvironmentUrls.thumbnailsApi + t,
                                                withCredentials: !0
                                            }, e.label = 1;
                                        case 1:
                                            return e.trys.push([1, 3, , 4]), [4, x.httpService.get(t, n)];
                                        case 2:
                                            return 200 === (n = e.sent()).status && n.data.data && 0 !== n.data.data.length ? [2, Promise.resolve(n.data.data[0].imageUrl)] : [2, Promise.resolve(null)];
                                        case 3:
                                            return e.sent(), [2, Promise.resolve(null)];
                                        case 4:
                                            return [2]
                                    }
                                })
                            })
                        }(n.assetId, n.assetType)];
                    case 5:
                        return r = e.sent(), t.imageurl = r || t.imageurl, a = {
                            expectedPrice: a.expectedPrice || "0",
                            expectedCurrency: a.expectedCurrency || "1",
                            expectedSellerId: a.expectedSellerId || "",
                            itemId: n.assetId || (null == l ? void 0 : l.itemId),
                            itemName: n.assetName || (null == l ? void 0 : l.itemName),
                            assetType: n.assetType || (null == l ? void 0 : l.assetType),
                            assetGranted: null == l ? void 0 : l.assetGranted,
                            assetTypeDisplayName: n.assetTypeDisplayName || (null == l ? void 0 : l.assetTypeDisplayName),
                            assetTypeId: null == l ? void 0 : l.assetTypeId,
                            productId: n.productId || a.productId || (null == l ? void 0 : l.productId),
                            itemType: n.assetType || (null == l ? void 0 : l.itemType),
                            currentTime: null == l ? void 0 : l.currentTime,
                            isPurchaseEnabled: null == l ? void 0 : l.isPurchaseEnabled,
                            placeproductpromotionId: null == l ? void 0 : l.placeproductpromotionId,
                            userassetId: a.userAssetId || (null == l ? void 0 : l.userassetId)
                        }, [2, [t, a]]
                }
            })
        })
    }

    function se(n, e, t, r) {
        var a = "<span>" + t.get(P.purchaseSucceededRobuxBalanceMessage, {
                userRobuxBalance: C(e)
            }) + "</span>",
            e = "<div class='item-content'>\n        <div class='item-card-container item-preview'>\n          <div class='item-card-thumb'>\n            <img alt='item preview' src='" + n.itemThumbnailUrl + "'/>\n          </div>\n        </div>\n        <div class='text-center'>\n          " + t.get(P.purchaseSucceededMessage, {
                assetName: n.assetName
            }) + "\n          " + a + "\n        </div>\n      </div>",
            a = n.assetType !== S.GAME_PASS ? t.get(P.equipMyAvatarAction, {}) : t.get(P.okAction, {});
        h.Dialog.open({
            titleText: t.get(P.purchaseSucceededHeading, {}),
            bodyContent: e,
            declineText: t.get(P.backToShopAction, {}),
            acceptText: a,
            acceptColor: "btn-primary-md",
            onAccept: function() {
                m.paymentFlowAnalyticsService.sendUserPurchaseFlowEvent(m.paymentFlowAnalyticsService.ENUM_TRIGGERING_CONTEXT.WEB_CATALOG_ROBUX_UPSELL, !0, m.paymentFlowAnalyticsService.ENUM_VIEW_NAME.PURCHASE_WARNING, m.paymentFlowAnalyticsService.ENUM_PURCHASE_EVENT_TYPE.USER_INPUT, m.paymentFlowAnalyticsService.ENUM_VIEW_MESSAGE.OK), k(M.AutoPurchaseSucceedEquipMyAvatar, n.assetType);
                var e, t = n.itemPath;
                return h.Endpoints && h.Endpoints.supportLocalizedUrls && (t = h.Endpoints.removeUrlLocale(t)), n.assetType !== S.GAME_PASS ? void 0 !== (e = h.Endpoints.getAbsoluteUrl("/my/avatar")) && "" !== e && (m.upsellUtil.expireUpsellCookie(), window.location.href = e) : t.startsWith(u) ? K(n.itemPath + "?#!/store") : K(n.itemPath), !1
            },
            onDecline: function() {
                return r.show(), m.paymentFlowAnalyticsService.sendUserPurchaseFlowEvent(m.paymentFlowAnalyticsService.ENUM_TRIGGERING_CONTEXT.WEB_CATALOG_ROBUX_UPSELL, !0, m.paymentFlowAnalyticsService.ENUM_VIEW_NAME.PURCHASE_WARNING, m.paymentFlowAnalyticsService.ENUM_PURCHASE_EVENT_TYPE.USER_INPUT, m.paymentFlowAnalyticsService.ENUM_VIEW_MESSAGE.CANCEL), k(M.AutoPurchaseSucceedBackToShop, n.assetType), K(n.itemPath), !1
            },
            onCancel: function() {
                return r.show(), m.paymentFlowAnalyticsService.sendUserPurchaseFlowEvent(m.paymentFlowAnalyticsService.ENUM_TRIGGERING_CONTEXT.WEB_CATALOG_ROBUX_UPSELL, !0, m.paymentFlowAnalyticsService.ENUM_VIEW_NAME.PURCHASE_WARNING, m.paymentFlowAnalyticsService.ENUM_PURCHASE_EVENT_TYPE.USER_INPUT, m.paymentFlowAnalyticsService.ENUM_VIEW_MESSAGE.CANCEL), k(M.AutoPurchaseSucceedClose, n.assetType), K(n.itemPath), !1
            },
            allowHtmlContentInBody: !0,
            allowHtmlContentInFooter: !1,
            fieldValidationRequired: !0,
            showDecline: n.assetType !== S.GAME_PASS,
            dismissable: !1,
            xToCancel: !0
        })
    }

    function ce(e, t) {
        h.Dialog.open({
            titleText: t.get(P.errorOccuredHeading, {}),
            bodyContent: t.get(P.purchaseErrorOccuredMessage, {}),
            imageUrl: e.alertImageUrl,
            acceptText: t.get(P.okAction, {}),
            acceptColor: "btn-secondary-md",
            declineColor: "btn-none",
            dismissable: !0,
            allowHtmlContentInBody: !0
        })
    }
    var ue = function(e, i, l, s) {
            return new(l = l || Promise)(function(n, t) {
                function r(e) {
                    try {
                        o(s.next(e))
                    } catch (e) {
                        t(e)
                    }
                }

                function a(e) {
                    try {
                        o(s.throw(e))
                    } catch (e) {
                        t(e)
                    }
                }

                function o(e) {
                    var t;
                    e.done ? n(e.value) : ((t = e.value) instanceof l ? t : new l(function(e) {
                        e(t)
                    })).then(r, a)
                }
                o((s = s.apply(e, i || [])).next())
            })
        },
        de = function(n, r) {
            var a, o, i, l = {
                    label: 0,
                    sent: function() {
                        if (1 & i[0]) throw i[1];
                        return i[1]
                    },
                    trys: [],
                    ops: []
                },
                e = {
                    next: t(0),
                    throw: t(1),
                    return: t(2)
                };
            return "function" == typeof Symbol && (e[Symbol.iterator] = function() {
                return this
            }), e;

            function t(t) {
                return function(e) {
                    return function(t) {
                        if (a) throw new TypeError("Generator is already executing.");
                        for (; l;) try {
                            if (a = 1, o && (i = 2 & t[0] ? o.return : t[0] ? o.throw || ((i = o.return) && i.call(o), 0) : o.next) && !(i = i.call(o, t[1])).done) return i;
                            switch (o = 0, i && (t = [2 & t[0], i.value]), t[0]) {
                                case 0:
                                case 1:
                                    i = t;
                                    break;
                                case 4:
                                    return l.label++, {
                                        value: t[1],
                                        done: !1
                                    };
                                case 5:
                                    l.label++, o = t[1], t = [0];
                                    continue;
                                case 7:
                                    t = l.ops.pop(), l.trys.pop();
                                    continue;
                                default:
                                    if (!(i = 0 < (i = l.trys).length && i[i.length - 1]) && (6 === t[0] || 2 === t[0])) {
                                        l = 0;
                                        continue
                                    }
                                    if (3 === t[0] && (!i || t[1] > i[0] && t[1] < i[3])) {
                                        l.label = t[1];
                                        break
                                    }
                                    if (6 === t[0] && l.label < i[1]) {
                                        l.label = i[1], i = t;
                                        break
                                    }
                                    if (i && l.label < i[2]) {
                                        l.label = i[2], l.ops.push(t);
                                        break
                                    }
                                    i[2] && l.ops.pop(), l.trys.pop();
                                    continue
                            }
                            t = r.call(n, l)
                        } catch (e) {
                            t = [6, e], o = 0
                        } finally {
                            a = i = 0
                        }
                        if (5 & t[0]) throw t[1];
                        return {
                            value: t[0] ? t[1] : void 0,
                            done: !0
                        }
                    }([t, e])
                }
            }
        };

    function pe(u, d, p, E) {
        return ue(this, void 0, Promise, function() {
            var a, o, i, l, s, c;
            return de(this, function(e) {
                switch (e.label) {
                    case 0:
                        a = {
                            url: u,
                            withCredentials: !0,
                            retryable: !1,
                            noCache: !0,
                            noPragma: !0
                        }, e.label = 1;
                    case 1:
                        return e.trys.push([1, 3, , 4]), o = {
                            expectedCurrency: d.expectedCurrency,
                            expectedPrice: d.expectedPrice,
                            expectedSellerId: d.expectedSellerId,
                            expectedPromoId: d.expectedPromoId,
                            userAssetId: d.userAssetId
                        }, [4, x.httpService.post(a, o)];
                    case 2:
                        return (o = e.sent(), 500 === (o = o.data).statusCode) ? (k(M.AutoPurchaseErrorFromPurchaseApi, d.assetType), void 0 === o.showDivID && (o.showDivID = o.showDivId), void 0 === o.AssetID && (o.AssetID = o.assetId), p.hide(), (0, h.ItemPurchase)().openErrorView(o), F(), [2, Promise.resolve()]) : (d.isLibrary && h.EventStream && h.UrlParser && (t = o.assetId, n = h.CurrentUser && h.CurrentUser.userId, r = h.UrlParser.getParametersAsObject(), i = {
                            assetId: t,
                            category: r.Category,
                            creatorId: r.CreatorId,
                            genre: r.GenreCsv,
                            page: r.Page,
                            position: r.Position,
                            searchKeyword: r.SearchKeyword,
                            sortAggregation: r.SortAggregation,
                            sortType: r.SortType,
                            userId: n,
                            searchId: r.SearchId
                        }, h.EventStream.SendEventWithTarget("LibraryAssetAcquired", "Marketplace", i, h.EventStream.TargetTypes.WWW)), k(M.AutoPurchaseSucceed, d.assetType), p.hide(), l = d.userBalance - d.expectedPrice, se(d, l, E, p), [2, Promise.resolve()]);
                    case 3:
                        if (i = e.sent(), p.hide(), k(M.AutoPurchaseFailed, d.assetType), "object" != typeof(l = i) || !("responseText" in l.request)) return [2, Promise.reject(l.request)];
                        if ("Bad Request" === (s = l.request).responseText) ce(d, E);
                        else try {
                            c = JSON.parse(s.responseText), (0, h.ItemPurchase)().openErrorView(c), F()
                        } catch (e) {
                            return [2, Promise.reject(e)]
                        }
                        return [2, Promise.reject(i)];
                    case 4:
                        return [2]
                }
                var t, n, r
            })
        })
    }

    function Ee(r, a, o, i) {
        var l;
        return void 0 === a && (a = void 0), ue(this, void 0, Promise, function() {
            var t, n;
            return de(this, function(e) {
                return null !== (l = r.itemContainerElemClassList) && void 0 !== l && l.contains("btn-disabled-primary") ? [2, Promise.resolve()] : (t = "" + h.EnvironmentUrls.apiGatewayUrl + s.replace("{productId}", r.productId), n = "" + h.EnvironmentUrls.economyApi + E.replace("{productId}", r.productId), a ? [2, a({
                    productId: r.productId,
                    expectedPrice: r.expectedPrice,
                    expectedCurrency: r.expectedCurrency,
                    expectedPromoId: null === (l = r.expectedPromoId) || void 0 === l ? void 0 : l.toString(),
                    expectedSellerId: r.expectedSellerId,
                    userAssetId: null === (l = r.userAssetId) || void 0 === l ? void 0 : l.toString()
                })] : (k(M.AutoPurchaseStarted, r.assetType), r.assetType === S.GAME_PASS ? [2, pe(t, r, o, i)] : [2, pe(n, r, o, i)]))
            })
        })
    }
    var ye = function(e, i, l, s) {
            return new(l = l || Promise)(function(n, t) {
                function r(e) {
                    try {
                        o(s.next(e))
                    } catch (e) {
                        t(e)
                    }
                }

                function a(e) {
                    try {
                        o(s.throw(e))
                    } catch (e) {
                        t(e)
                    }
                }

                function o(e) {
                    var t;
                    e.done ? n(e.value) : ((t = e.value) instanceof l ? t : new l(function(e) {
                        e(t)
                    })).then(r, a)
                }
                o((s = s.apply(e, i || [])).next())
            })
        },
        ve = function(n, r) {
            var a, o, i, l = {
                    label: 0,
                    sent: function() {
                        if (1 & i[0]) throw i[1];
                        return i[1]
                    },
                    trys: [],
                    ops: []
                },
                e = {
                    next: t(0),
                    throw: t(1),
                    return: t(2)
                };
            return "function" == typeof Symbol && (e[Symbol.iterator] = function() {
                return this
            }), e;

            function t(t) {
                return function(e) {
                    return function(t) {
                        if (a) throw new TypeError("Generator is already executing.");
                        for (; l;) try {
                            if (a = 1, o && (i = 2 & t[0] ? o.return : t[0] ? o.throw || ((i = o.return) && i.call(o), 0) : o.next) && !(i = i.call(o, t[1])).done) return i;
                            switch (o = 0, i && (t = [2 & t[0], i.value]), t[0]) {
                                case 0:
                                case 1:
                                    i = t;
                                    break;
                                case 4:
                                    return l.label++, {
                                        value: t[1],
                                        done: !1
                                    };
                                case 5:
                                    l.label++, o = t[1], t = [0];
                                    continue;
                                case 7:
                                    t = l.ops.pop(), l.trys.pop();
                                    continue;
                                default:
                                    if (!(i = 0 < (i = l.trys).length && i[i.length - 1]) && (6 === t[0] || 2 === t[0])) {
                                        l = 0;
                                        continue
                                    }
                                    if (3 === t[0] && (!i || t[1] > i[0] && t[1] < i[3])) {
                                        l.label = t[1];
                                        break
                                    }
                                    if (6 === t[0] && l.label < i[1]) {
                                        l.label = i[1], i = t;
                                        break
                                    }
                                    if (i && l.label < i[2]) {
                                        l.label = i[2], l.ops.push(t);
                                        break
                                    }
                                    i[2] && l.ops.pop(), l.trys.pop();
                                    continue
                            }
                            t = r.call(n, l)
                        } catch (e) {
                            t = [6, e], o = 0
                        } finally {
                            a = i = 0
                        }
                        if (5 & t[0]) throw t[1];
                        return {
                            value: t[0] ? t[1] : void 0,
                            done: !0
                        }
                    }([t, e])
                }
            }
        },
        he = function(e) {
            e = document.querySelector('.PurchaseButton[data-product-id="' + e.productId + '"]'), e = null == e ? void 0 : e.closest(".store-card"), e = null == e ? void 0 : e.querySelector(".gear-passes-asset img");
            return e ? e.src : null
        },
        me = function(e, t, n) {
            if (void 0 === n && (n = window.location.pathname), n.startsWith(u)) {
                if (!t) throw new Error("button data not exist");
                k(M.UpsellFromGamesPage, t.assetType);
                n = he(t);
                if (!n) throw k(M.UpsellThumbnailProcessFailed, t.assetType), new Error("thumbnail image url process failed");
                return n
            }
            return e.imageurl
        },
        fe = HeaderScripts;

    function Ue(e, t, n, r) {
        var a = C(e),
            o = C(parseInt(n.expectedPrice, 10)),
            e = window.location.pathname;
        h.Endpoints && h.Endpoints.supportLocalizedUrls && (e = h.Endpoints.removeUrlLocale(e));
        e.startsWith(u) && (t = null !== (e = he(n)) && void 0 !== e ? e : t);
        a = "<div class='item-card-container item-preview'>\n        <div class='item-card-thumb'>\n          <img alt='item preview' src='" + t + "' />\n        </div>\n        <div class='item-info text-name'>\n        <div class='text-overflow item-card-name'>" + (0, x.escapeHtml)()(n.itemName) + "</div>\n          <div class='text-robux item-card-price'>" + o + "</div>\n        </div>\n      </div>" + r.get(P.insufficientRobuxExceedLargestPackageMessage, {
            divTagStart: "<div class='modal-message-block text-center border-top'>",
            divTagEnd: "</div>",
            robuxNeeded: a
        });
        m.paymentFlowAnalyticsService.sendUserPurchaseFlowEvent(m.paymentFlowAnalyticsService.ENUM_TRIGGERING_CONTEXT.WEB_CATALOG_ROBUX_UPSELL, !0, m.paymentFlowAnalyticsService.ENUM_VIEW_NAME.ROBUX_UPSELL_EXCEED_LARGEST_PACKAGE, m.paymentFlowAnalyticsService.ENUM_PURCHASE_EVENT_TYPE.VIEW_SHOWN), k(M.UpsellExceedLargestShown, n.assetType), h.Dialog.open({
            titleText: r.get(P.insufficientRobuxHeading, {}),
            bodyContent: a,
            declineText: r.get(P.cancelAction, {}),
            acceptText: r.get(P.goToRobuxStoreAction, {}),
            acceptColor: "btn-primary-md",
            onAccept: function() {
                var e, t;
                return m.paymentFlowAnalyticsService.sendUserPurchaseFlowEvent(m.paymentFlowAnalyticsService.ENUM_TRIGGERING_CONTEXT.WEB_CATALOG_ROBUX_UPSELL, !0, m.paymentFlowAnalyticsService.ENUM_VIEW_NAME.ROBUX_UPSELL_EXCEED_LARGEST_PACKAGE, m.paymentFlowAnalyticsService.ENUM_PURCHASE_EVENT_TYPE.USER_INPUT, m.paymentFlowAnalyticsService.ENUM_VIEW_MESSAGE.GO_TO_ROBUX_STORE), k(M.UpsellExceedLargestGoToRobuxStoreClicked, null == n ? void 0 : n.assetType), e = null !== (t = null === (e = fe.deviceMeta.getDeviceMeta()) || void 0 === e ? void 0 : e.isTablet) && void 0 !== t && t, t = null !== (t = null === (t = fe.deviceMeta.getDeviceMeta()) || void 0 === t ? void 0 : t.isUniversalApp) && void 0 !== t && t, window.location.href = e && t ? x.urlService.getUrlWithQueries("/Upgrades/Robux.aspx", {
                    ctx: ""
                }) : h.Endpoints.getAbsoluteUrl("/upgrades/robux?ctx=upsell"), !1
            },
            onDecline: function() {
                m.paymentFlowAnalyticsService.sendUserPurchaseFlowEvent(m.paymentFlowAnalyticsService.ENUM_TRIGGERING_CONTEXT.WEB_CATALOG_ROBUX_UPSELL, !0, m.paymentFlowAnalyticsService.ENUM_VIEW_NAME.ROBUX_UPSELL_EXCEED_LARGEST_PACKAGE, m.paymentFlowAnalyticsService.ENUM_PURCHASE_EVENT_TYPE.USER_INPUT, m.paymentFlowAnalyticsService.ENUM_VIEW_MESSAGE.CANCEL), k(M.UpsellExceedLargestCancelled, null == n ? void 0 : n.assetType)
            },
            onCancel: function() {
                m.paymentFlowAnalyticsService.sendUserPurchaseFlowEvent(m.paymentFlowAnalyticsService.ENUM_TRIGGERING_CONTEXT.WEB_CATALOG_ROBUX_UPSELL, !0, m.paymentFlowAnalyticsService.ENUM_VIEW_NAME.ROBUX_UPSELL_EXCEED_LARGEST_PACKAGE, m.paymentFlowAnalyticsService.ENUM_PURCHASE_EVENT_TYPE.USER_INPUT, m.paymentFlowAnalyticsService.ENUM_VIEW_MESSAGE.CANCEL), k(M.UpsellCancelled, null == n ? void 0 : n.assetType)
            },
            allowHtmlContentInBody: !0,
            allowHtmlContentInFooter: !1,
            fieldValidationRequired: !0,
            dismissable: !0,
            xToCancel: !0
        })
    }
    var Se = function(e, i, l, s) {
            return new(l = l || Promise)(function(n, t) {
                function r(e) {
                    try {
                        o(s.next(e))
                    } catch (e) {
                        t(e)
                    }
                }

                function a(e) {
                    try {
                        o(s.throw(e))
                    } catch (e) {
                        t(e)
                    }
                }

                function o(e) {
                    var t;
                    e.done ? n(e.value) : ((t = e.value) instanceof l ? t : new l(function(e) {
                        e(t)
                    })).then(r, a)
                }
                o((s = s.apply(e, i || [])).next())
            })
        },
        Ae = function(n, r) {
            var a, o, i, l = {
                    label: 0,
                    sent: function() {
                        if (1 & i[0]) throw i[1];
                        return i[1]
                    },
                    trys: [],
                    ops: []
                },
                e = {
                    next: t(0),
                    throw: t(1),
                    return: t(2)
                };
            return "function" == typeof Symbol && (e[Symbol.iterator] = function() {
                return this
            }), e;

            function t(t) {
                return function(e) {
                    return function(t) {
                        if (a) throw new TypeError("Generator is already executing.");
                        for (; l;) try {
                            if (a = 1, o && (i = 2 & t[0] ? o.return : t[0] ? o.throw || ((i = o.return) && i.call(o), 0) : o.next) && !(i = i.call(o, t[1])).done) return i;
                            switch (o = 0, i && (t = [2 & t[0], i.value]), t[0]) {
                                case 0:
                                case 1:
                                    i = t;
                                    break;
                                case 4:
                                    return l.label++, {
                                        value: t[1],
                                        done: !1
                                    };
                                case 5:
                                    l.label++, o = t[1], t = [0];
                                    continue;
                                case 7:
                                    t = l.ops.pop(), l.trys.pop();
                                    continue;
                                default:
                                    if (!(i = 0 < (i = l.trys).length && i[i.length - 1]) && (6 === t[0] || 2 === t[0])) {
                                        l = 0;
                                        continue
                                    }
                                    if (3 === t[0] && (!i || t[1] > i[0] && t[1] < i[3])) {
                                        l.label = t[1];
                                        break
                                    }
                                    if (6 === t[0] && l.label < i[1]) {
                                        l.label = i[1], i = t;
                                        break
                                    }
                                    if (i && l.label < i[2]) {
                                        l.label = i[2], l.ops.push(t);
                                        break
                                    }
                                    i[2] && l.ops.pop(), l.trys.pop();
                                    continue
                            }
                            t = r.call(n, l)
                        } catch (e) {
                            t = [6, e], o = 0
                        } finally {
                            a = i = 0
                        }
                        if (5 & t[0]) throw t[1];
                        return {
                            value: t[0] ? t[1] : void 0,
                            done: !0
                        }
                    }([t, e])
                }
            }
        },
        Te = function(e, i, l, s) {
            return new(l = l || Promise)(function(n, t) {
                function r(e) {
                    try {
                        o(s.next(e))
                    } catch (e) {
                        t(e)
                    }
                }

                function a(e) {
                    try {
                        o(s.throw(e))
                    } catch (e) {
                        t(e)
                    }
                }

                function o(e) {
                    var t;
                    e.done ? n(e.value) : ((t = e.value) instanceof l ? t : new l(function(e) {
                        e(t)
                    })).then(r, a)
                }
                o((s = s.apply(e, i || [])).next())
            })
        },
        Pe = function(n, r) {
            var a, o, i, l = {
                    label: 0,
                    sent: function() {
                        if (1 & i[0]) throw i[1];
                        return i[1]
                    },
                    trys: [],
                    ops: []
                },
                e = {
                    next: t(0),
                    throw: t(1),
                    return: t(2)
                };
            return "function" == typeof Symbol && (e[Symbol.iterator] = function() {
                return this
            }), e;

            function t(t) {
                return function(e) {
                    return function(t) {
                        if (a) throw new TypeError("Generator is already executing.");
                        for (; l;) try {
                            if (a = 1, o && (i = 2 & t[0] ? o.return : t[0] ? o.throw || ((i = o.return) && i.call(o), 0) : o.next) && !(i = i.call(o, t[1])).done) return i;
                            switch (o = 0, i && (t = [2 & t[0], i.value]), t[0]) {
                                case 0:
                                case 1:
                                    i = t;
                                    break;
                                case 4:
                                    return l.label++, {
                                        value: t[1],
                                        done: !1
                                    };
                                case 5:
                                    l.label++, o = t[1], t = [0];
                                    continue;
                                case 7:
                                    t = l.ops.pop(), l.trys.pop();
                                    continue;
                                default:
                                    if (!(i = 0 < (i = l.trys).length && i[i.length - 1]) && (6 === t[0] || 2 === t[0])) {
                                        l = 0;
                                        continue
                                    }
                                    if (3 === t[0] && (!i || t[1] > i[0] && t[1] < i[3])) {
                                        l.label = t[1];
                                        break
                                    }
                                    if (6 === t[0] && l.label < i[1]) {
                                        l.label = i[1], i = t;
                                        break
                                    }
                                    if (i && l.label < i[2]) {
                                        l.label = i[2], l.ops.push(t);
                                        break
                                    }
                                    i[2] && l.ops.pop(), l.trys.pop();
                                    continue
                            }
                            t = r.call(n, l)
                        } catch (e) {
                            t = [6, e], o = 0
                        } finally {
                            a = i = 0
                        }
                        if (5 & t[0]) throw t[1];
                        return {
                            value: t[0] ? t[1] : void 0,
                            done: !0
                        }
                    }([t, e])
                }
            }
        };

    function _e(i, l, s) {
        return Te(this, void 0, void 0, function() {
            return Pe(this, function(e) {
                try {
                    return m.paymentFlowAnalyticsService.sendUserPurchaseFlowEvent(m.paymentFlowAnalyticsService.ENUM_TRIGGERING_CONTEXT.WEB_CATALOG_ROBUX_UPSELL, !0, m.paymentFlowAnalyticsService.ENUM_VIEW_NAME.LEAVE_ROBLOX_WARNING, m.paymentFlowAnalyticsService.ENUM_PURCHASE_EVENT_TYPE.VIEW_SHOWN, m.paymentFlowAnalyticsService.ENUM_VIEW_MESSAGE.EXTERNAL_LINK_MODAL), k(M.ContinueBuyRobuxOnExternalSite, null == s ? void 0 : s.assetType), t = i, r = s, a = (n = l).getTranslationResource(p), o = n.getTranslationResource(c), n = {
                        lineBreak: n = "<br /><br />",
                        linebreak: n
                    }, n = a.get(P.insufficientRobuxAskToPurchasePackageMessage, n) || "This purchase must be completed on our partner’s website. You will be returned to Roblox after the purchase is completed.<br /><br /> Proceed to partner website for payment?", h.Dialog.open({
                        titleText: a.get(P.insufficientRobuxLeaveRobloxHeading, {}) || "Leaving Roblox",
                        bodyContent: "<div class='modal-message-block text-center'>" + n + "</div>",
                        declineText: o.get(P.commonUiCancelAction, {}),
                        acceptText: o.get(P.commonUiContinueToPaymentAction, {}) || "Continue to Payment",
                        onAccept: function() {
                            m.paymentFlowAnalyticsService.sendUserPurchaseFlowEvent(m.paymentFlowAnalyticsService.ENUM_TRIGGERING_CONTEXT.WEB_CATALOG_ROBUX_UPSELL, !0, m.paymentFlowAnalyticsService.ENUM_VIEW_NAME.LEAVE_ROBLOX_WARNING, m.paymentFlowAnalyticsService.ENUM_PURCHASE_EVENT_TYPE.USER_INPUT, m.paymentFlowAnalyticsService.ENUM_VIEW_MESSAGE.CONTINUE_TO_VNG), k(M.ConfirmLeaveRobloxModal, null == r ? void 0 : r.assetType), t()
                        },
                        onDecline: function() {
                            m.paymentFlowAnalyticsService.sendUserPurchaseFlowEvent(m.paymentFlowAnalyticsService.ENUM_TRIGGERING_CONTEXT.WEB_CATALOG_ROBUX_UPSELL, !0, m.paymentFlowAnalyticsService.ENUM_VIEW_NAME.LEAVE_ROBLOX_WARNING, m.paymentFlowAnalyticsService.ENUM_PURCHASE_EVENT_TYPE.USER_INPUT, m.paymentFlowAnalyticsService.ENUM_VIEW_MESSAGE.CANCEL), k(M.CancelledFromLeaveRobloxModal, null == r ? void 0 : r.assetType)
                        },
                        onCancel: function() {
                            m.paymentFlowAnalyticsService.sendUserPurchaseFlowEvent(m.paymentFlowAnalyticsService.ENUM_TRIGGERING_CONTEXT.WEB_CATALOG_ROBUX_UPSELL, !0, m.paymentFlowAnalyticsService.ENUM_VIEW_NAME.LEAVE_ROBLOX_WARNING, m.paymentFlowAnalyticsService.ENUM_PURCHASE_EVENT_TYPE.USER_INPUT, m.paymentFlowAnalyticsService.ENUM_VIEW_MESSAGE.CANCEL), k(M.CancelledFromLeaveRobloxModal, null == r ? void 0 : r.assetType)
                        },
                        allowHtmlContentInBody: !0,
                        allowHtmlContentInFooter: !1,
                        fieldValidationRequired: !0,
                        dismissable: !0,
                        xToCancel: !0
                    }), [2, Promise.resolve()]
                } catch (e) {
                    return [2, Promise.reject(e)]
                }
                var t, n, r, a, o;
                return [2]
            })
        })
    }
    var be = function(e, i, l, s) {
            return new(l = l || Promise)(function(n, t) {
                function r(e) {
                    try {
                        o(s.next(e))
                    } catch (e) {
                        t(e)
                    }
                }

                function a(e) {
                    try {
                        o(s.throw(e))
                    } catch (e) {
                        t(e)
                    }
                }

                function o(e) {
                    var t;
                    e.done ? n(e.value) : ((t = e.value) instanceof l ? t : new l(function(e) {
                        e(t)
                    })).then(r, a)
                }
                o((s = s.apply(e, i || [])).next())
            })
        },
        we = function(n, r) {
            var a, o, i, l = {
                    label: 0,
                    sent: function() {
                        if (1 & i[0]) throw i[1];
                        return i[1]
                    },
                    trys: [],
                    ops: []
                },
                e = {
                    next: t(0),
                    throw: t(1),
                    return: t(2)
                };
            return "function" == typeof Symbol && (e[Symbol.iterator] = function() {
                return this
            }), e;

            function t(t) {
                return function(e) {
                    return function(t) {
                        if (a) throw new TypeError("Generator is already executing.");
                        for (; l;) try {
                            if (a = 1, o && (i = 2 & t[0] ? o.return : t[0] ? o.throw || ((i = o.return) && i.call(o), 0) : o.next) && !(i = i.call(o, t[1])).done) return i;
                            switch (o = 0, i && (t = [2 & t[0], i.value]), t[0]) {
                                case 0:
                                case 1:
                                    i = t;
                                    break;
                                case 4:
                                    return l.label++, {
                                        value: t[1],
                                        done: !1
                                    };
                                case 5:
                                    l.label++, o = t[1], t = [0];
                                    continue;
                                case 7:
                                    t = l.ops.pop(), l.trys.pop();
                                    continue;
                                default:
                                    if (!(i = 0 < (i = l.trys).length && i[i.length - 1]) && (6 === t[0] || 2 === t[0])) {
                                        l = 0;
                                        continue
                                    }
                                    if (3 === t[0] && (!i || t[1] > i[0] && t[1] < i[3])) {
                                        l.label = t[1];
                                        break
                                    }
                                    if (6 === t[0] && l.label < i[1]) {
                                        l.label = i[1], i = t;
                                        break
                                    }
                                    if (i && l.label < i[2]) {
                                        l.label = i[2], l.ops.push(t);
                                        break
                                    }
                                    i[2] && l.ops.pop(), l.trys.pop();
                                    continue
                            }
                            t = r.call(n, l)
                        } catch (e) {
                            t = [6, e], o = 0
                        } finally {
                            a = i = 0
                        }
                        if (5 & t[0]) throw t[1];
                        return {
                            value: t[0] ? t[1] : void 0,
                            done: !0
                        }
                    }([t, e])
                }
            }
        };

    function ge() {
        var t = this;
        this._state = {
            purchased: !1,
            retryRemainTimes: 5,
            timeoutHandle: null
        }, this._checkBalanceAndPurchase = function(r, a) {
            return be(t, void 0, Promise, function() {
                var t, n = this;
                return we(this, function(e) {
                    switch (e.label) {
                        case 0:
                            if (this._state.purchased) return [2, Promise.resolve()];
                            e.label = 1;
                        case 1:
                            return e.trys.push([1, 5, , 6]), t = this.translationResource.get(P.waitingForRobuxLabel, {}), this.loadingOverlay.updateMessage(t), [4, function() {
                                return ye(this, void 0, Promise, function() {
                                    var t, n;
                                    return ve(this, function(e) {
                                        switch (e.label) {
                                            case 0:
                                                t = h.CurrentUser.userId, t = {
                                                    url: "" + h.EnvironmentUrls.economyApi + o.replace("{userId}", t),
                                                    withCredentials: !0,
                                                    retryable: !1,
                                                    noCache: !0
                                                }, e.label = 1;
                                            case 1:
                                                return e.trys.push([1, 3, , 4]), [4, x.httpService.get(t)];
                                            case 2:
                                                return 200 === (n = e.sent()).status ? [2, n.data.robux] : [2, Promise.reject()];
                                            case 3:
                                                return n = e.sent(), [2, Promise.reject(n)];
                                            case 4:
                                                return [2]
                                        }
                                    })
                                })
                            }()];
                        case 2:
                            return t = e.sent(), (r.userBalance = t) >= r.expectedPrice ? [4, Ee(r, a, this.loadingOverlay, this.translationResource)] : [3, 4];
                        case 3:
                            e.sent(), this._stopPeriodicChecking(), this._state.purchased = !0, e.label = 4;
                        case 4:
                            return this._state.purchased || (0 < this._state.retryRemainTimes ? (this._state.timeoutHandle = setTimeout(function() {
                                return be(n, void 0, void 0, function() {
                                    return we(this, function(e) {
                                        switch (e.label) {
                                            case 0:
                                                return [4, this._checkBalanceAndPurchase(r, a)];
                                            case 1:
                                                return e.sent(), [2]
                                        }
                                    })
                                })
                            }, 1e3), --this._state.retryRemainTimes) : (k(M.AutoPurchaseFailedDueToStillLowBalance, null == r ? void 0 : r.assetType), this._processGenericErrorState(r))), [3, 6];
                        case 5:
                            return e.sent(), k(M.AutoPurchaseFailed, null == r ? void 0 : r.assetType), this._processGenericErrorState(r), [3, 6];
                        case 6:
                            return [2, Promise.resolve()]
                    }
                })
            })
        }, this._stopPeriodicChecking = function() {
            t._state.timeoutHandle && (clearTimeout(t._state.timeoutHandle), t._state.timeoutHandle = null)
        }, this._processGenericErrorState = function(e) {
            t.loadingOverlay.hide(), ce(e, t.translationResource), F()
        }, this.intl = new h.Intl, this.intlProvider = new h.TranslationResourceProvider(this.intl), this.translationResource = this.intlProvider.getTranslationResource("Purchasing.PurchaseDialog"), this.loadingOverlay = new q
    }
    var Me = (ge.prototype.startItemUpsellProcess = function(c, u, d, p) {
        var e, E, y, v;
        return void 0 === p && (p = null === (e = document.getElementById(f)) || void 0 === e ? void 0 : e.dataset), be(this, void 0, Promise, function() {
            var i, l, s;
            return we(this, function(e) {
                switch (e.label) {
                    case 0:
                        if (!(i = p)) return d(c), [2, Promise.reject(c)];
                        if (l = m.upsellUtil.constants.UPSELL_TARGET_ITEM_URL_REGEX.exec(window.location.pathname), m.upsellUtil.constants.UPSELL_TARGET_ITEM_URL_REGEX.lastIndex = 0, !Array.isArray(l)) return [3, 5];
                        e.label = 1;
                    case 1:
                        return e.trys.push([1, 4, , 5]), [4, function() {
                            return Se(this, void 0, Promise, function() {
                                var t, n;
                                return Ae(this, function(e) {
                                    switch (e.label) {
                                        case 0:
                                            t = {
                                                url: h.EnvironmentUrls.universalAppConfigurationApi + "/v1/behaviors/vng-buy-robux/content",
                                                withCredentials: !0
                                            }, e.label = 1;
                                        case 1:
                                            return e.trys.push([1, 3, , 4]), [4, x.httpService.get(t)];
                                        case 2:
                                            return n = e.sent(), [2, Promise.resolve(n.data.shouldShowVng)];
                                        case 3:
                                            return n = e.sent(), [2, Promise.reject(n)];
                                        case 4:
                                            return [2]
                                    }
                                })
                            })
                        }()];
                    case 2:
                        return e.sent() ? (m.paymentFlowAnalyticsService.startRobuxUpsellFlow(null !== (E = null === (E = u.buyButtonElementDataset) || void 0 === E ? void 0 : E.assetType) && void 0 !== E ? E : "", !(null === (E = u.buyButtonElementDataset) || void 0 === E || !E.userassetId), null !== (E = null === (E = u.buyButtonElementDataset) || void 0 === E ? void 0 : E.isPrivateServer) && void 0 !== E && E, null !== (E = null === (E = u.buyButtonElementDataset) || void 0 === E ? void 0 : E.isPlace) && void 0 !== E && E), i.thumbnailImageUrl = me(i, u.buyButtonElementDataset), t = u, n = i, r = this.translationResource, a = this.intlProvider, o = C(t.expectedItemPrice), n = "<div class='item-card-container item-preview'>\n        <div class='item-card-thumb'>\n          <img alt='item preview' src='" + (null !== (n = n.thumbnailImageUrl) && void 0 !== n ? n : "") + "' />\n        </div>\n        <div class='item-info text-name'>\n        <div class='text-overflow item-card-name'>" + (0, x.escapeHtml)()(t.assetName) + "</div>\n          <div class='text-robux item-card-price'>" + o + "</div>\n        </div>\n      </div>", k(M.UpsellShown, null === (o = t.buyButtonElementDataset) || void 0 === o ? void 0 : o.assetType), m.paymentFlowAnalyticsService.sendUserPurchaseFlowEvent(m.paymentFlowAnalyticsService.ENUM_TRIGGERING_CONTEXT.WEB_CATALOG_ROBUX_UPSELL, !0, m.paymentFlowAnalyticsService.ENUM_VIEW_NAME.ROBUX_UPSELL, m.paymentFlowAnalyticsService.ENUM_PURCHASE_EVENT_TYPE.VIEW_SHOWN), o = n + (r.get(P.insufficientRobuxAskToPurchasePackageMessage, {}) || "<div class='modal-message-block text-center border-top'>Sorry, you don't have enough Robux to buy this item. Would you like to purchase a Robux package?</div>"), n = r.get(P.insufficientRobuxRedirectToExternalPartner, {}) || "<div class='text-footer modal-message-block text-center'> You will be taken to our partner’s page to complete the purchase.</div>", h.Dialog.open({
                            titleText: r.get(P.insufficientRobuxHeading, {}) || "Insufficient Robux",
                            bodyContent: o,
                            declineText: r.get(P.cancelAction, {}),
                            acceptText: r.get(P.buyRobux, {}) || "Buy Robux",
                            onAccept: function() {
                                return m.paymentFlowAnalyticsService.sendUserPurchaseFlowEvent(m.paymentFlowAnalyticsService.ENUM_TRIGGERING_CONTEXT.WEB_CATALOG_ROBUX_UPSELL, !0, m.paymentFlowAnalyticsService.ENUM_VIEW_NAME.ROBUX_UPSELL, m.paymentFlowAnalyticsService.ENUM_PURCHASE_EVENT_TYPE.USER_INPUT, m.paymentFlowAnalyticsService.ENUM_VIEW_MESSAGE.BUY_ROBUX), _e(Q, a, t.buyButtonElementDataset).catch(function() {
                                    var e;
                                    k(M.LeaveRobloxFailedToShown, null === (e = t.buyButtonElementDataset) || void 0 === e ? void 0 : e.assetType), Q()
                                }), !1
                            },
                            onDecline: function() {
                                var e;
                                m.paymentFlowAnalyticsService.sendUserPurchaseFlowEvent(m.paymentFlowAnalyticsService.ENUM_TRIGGERING_CONTEXT.WEB_CATALOG_ROBUX_UPSELL, !0, m.paymentFlowAnalyticsService.ENUM_VIEW_NAME.ROBUX_UPSELL, m.paymentFlowAnalyticsService.ENUM_PURCHASE_EVENT_TYPE.USER_INPUT, m.paymentFlowAnalyticsService.ENUM_VIEW_MESSAGE.CANCEL), k(M.UpsellCancelled, null === (e = t.buyButtonElementDataset) || void 0 === e ? void 0 : e.assetType)
                            },
                            onCancel: function() {
                                var e;
                                m.paymentFlowAnalyticsService.sendUserPurchaseFlowEvent(m.paymentFlowAnalyticsService.ENUM_TRIGGERING_CONTEXT.WEB_CATALOG_ROBUX_UPSELL, !0, m.paymentFlowAnalyticsService.ENUM_VIEW_NAME.ROBUX_UPSELL, m.paymentFlowAnalyticsService.ENUM_PURCHASE_EVENT_TYPE.USER_INPUT, m.paymentFlowAnalyticsService.ENUM_VIEW_MESSAGE.CANCEL), k(M.UpsellCancelled, null === (e = t.buyButtonElementDataset) || void 0 === e ? void 0 : e.assetType)
                            },
                            allowHtmlContentInBody: !0,
                            allowHtmlContentInFooter: !0,
                            footerText: n,
                            fieldValidationRequired: !0,
                            dismissable: !0,
                            xToCancel: !0
                        }), [2, Promise.resolve()]) : [4, function(r, a) {
                            return I(this, void 0, Promise, function() {
                                var t, n;
                                return N(this, function(e) {
                                    switch (e.label) {
                                        case 0:
                                            t = parseInt(r.userBalanceRobux, 10), n = {
                                                upsell_platform: "WEB",
                                                user_robux_balance: t,
                                                attempt_robux_amount: a.expectedItemPrice
                                            }, t = {
                                                url: h.EnvironmentUrls.apiGatewayUrl + "/payments-gateway/v1/products/get-upsell-product",
                                                withCredentials: !0
                                            }, e.label = 1;
                                        case 1:
                                            return e.trys.push([1, 3, , 4]), [4, x.httpService.post(t, n)];
                                        case 2:
                                            return [2, e.sent()];
                                        case 3:
                                            return n = e.sent(), [2, Promise.reject(n)];
                                        case 4:
                                            return [2]
                                    }
                                })
                            })
                        }(i, u)];
                    case 3:
                        return 200 === (s = e.sent()).status ? (m.paymentFlowAnalyticsService.startRobuxUpsellFlow(null !== (y = null === (y = u.buyButtonElementDataset) || void 0 === y ? void 0 : y.assetType) && void 0 !== y ? y : "", !(null === (y = u.buyButtonElementDataset) || void 0 === y || !y.userassetId), null !== (y = null === (y = u.buyButtonElementDataset) || void 0 === y ? void 0 : y.isPrivateServer) && void 0 !== y && y, null !== (y = null === (y = u.buyButtonElementDataset) || void 0 === y ? void 0 : y.isPlace) && void 0 !== y && y), i.thumbnailImageUrl = me(i, u.buyButtonElementDataset), j(c, u, i, s.data, this.intl, this.translationResource, this.intlProvider), [2, Promise.resolve()]) : (204 === s.status ? k(M.UpsellFailedDueToNoAvailablePackage, null === (y = u.buyButtonElementDataset) || void 0 === y ? void 0 : y.assetType) : k(M.UpsellFailedDueToFailedPackageRequest, null === (v = u.buyButtonElementDataset) || void 0 === v ? void 0 : v.assetType), [3, 5]);
                    case 4:
                        return s = e.sent(), k(M.UpsellFailed, null === (v = u.buyButtonElementDataset) || void 0 === v ? void 0 : v.assetType), d(c), [2, Promise.reject(s)];
                    case 5:
                        return d(c), [2, Promise.reject(c)]
                }
                var t, n, r, a, o
            })
        })
    }, ge.prototype.showExceedLargestInsufficientRobuxModal = function(e, t, n, r) {
        var a, o;
        void 0 === r && (r = null === (a = document.getElementById(f)) || void 0 === a ? void 0 : a.dataset), k(M.UpsellExceedLargestEntryPoint, null == t ? void 0 : t.assetType);
        var i = r;
        if (null == i || !i.imageurl) return k(M.UpsellExceedLargestNoThumbnailImage, null == t ? void 0 : t.assetType), void n();
        try {
            m.paymentFlowAnalyticsService.startRobuxUpsellFlow(null !== (o = null == t ? void 0 : t.assetType) && void 0 !== o ? o : "", !(null == t || !t.userassetId), null !== (o = null == t ? void 0 : t.isPrivateServer) && void 0 !== o && o, null !== (o = null == t ? void 0 : t.isPlace) && void 0 !== o && o), Ue(e, i.imageurl, t, this.translationResource), k(M.UpsellExceedLargestModalExpTrue, null == t ? void 0 : t.assetType)
        } catch (e) {
            k(M.UpsellExceedLargestModalExpError, null == t ? void 0 : t.assetType), n()
        }
    }, ge.prototype.initiateAutoPurchase = function(o, i, l, s) {
        var c;
        return void 0 === l && (l = document.getElementById(f)), void 0 === s && (s = document.getElementById("item-container")), be(this, void 0, Promise, function() {
            var t, n, r, a;
            return we(this, function(e) {
                switch (e.label) {
                    case 0:
                        return this._state = {
                            purchased: !1,
                            retryRemainTimes: 5,
                            timeoutHandle: null
                        }, this.loadingOverlay.show(), k(M.AutoPurchaseEntryPoint, g), oe(o), [4, function(c, u, d, p) {
                            return ne(this, void 0, Promise, function() {
                                var t, n, r, a, o, i, l, s;
                                return re(this, function(e) {
                                    switch (e.label) {
                                        case 0:
                                            return [4, le(p, d, u)];
                                        case 1:
                                            return i = e.sent(), s = i[0], t = i[1], n = t.placeproductpromotionId, l = h.MetaDataValues && h.MetaDataValues.getPageName() || "", r = "LibraryItem" === l, a = parseInt(s.userBalanceRobux, 10), o = parseInt(t.expectedCurrency, 10), i = parseInt(t.expectedPrice, 10), l = parseInt(t.expectedSellerId, 10), s = {
                                                itemContainerElemClassList: null == c ? void 0 : c.classList,
                                                assetType: t.assetType,
                                                assetName: (0, x.escapeHtml)()(t.itemName),
                                                expectedSellerId: l,
                                                expectedCurrency: o,
                                                expectedPrice: i,
                                                productId: t.productId,
                                                isLibrary: r,
                                                itemThumbnailUrl: s.imageurl,
                                                itemPath: p,
                                                alertImageUrl: s.alerturl,
                                                userBalance: a,
                                                itemPurchaseAjaxData: s,
                                                itemDetail: t
                                            }, n && (s.expectedPromoId = parseInt(n, 10)), t.userassetId && (s.userAssetId = parseInt(t.userassetId, 10)), [2, s]
                                    }
                                })
                            })
                        }(s, null == s ? void 0 : s.dataset, null == l ? void 0 : l.dataset, o)];
                    case 1:
                        t = e.sent(), a = this.translationResource.get(P.purchasingTheItemLabel, {}), n = t.userBalance, r = t.expectedPrice, e.label = 2;
                    case 2:
                        return (e.trys.push([2, 6, , 7]), o.startsWith(u) && null !== (c = document.getElementById("tab-store")) && void 0 !== c && c.click(), r < n) ? (this.loadingOverlay.updateMessage(a), [4, Ee(t, i, this.loadingOverlay, this.translationResource)]) : [3, 4];
                    case 3:
                        return e.sent(), this._state.purchased = !0, [2, Promise.resolve()];
                    case 4:
                        return [4, this._checkBalanceAndPurchase(t, i)];
                    case 5:
                        return e.sent(), [3, 7];
                    case 6:
                        return a = e.sent(), k(M.AutoPurchaseFailed, null == t ? void 0 : t.assetType), te(b.CONTEXT_NAME.UPSELL_FAILED, {
                            itemPurchaseObj: t,
                            error: a
                        }), F(), [3, 7];
                    case 7:
                        return [2, Promise.resolve()]
                }
            })
        })
    }, ge);
    void 0 === window.Roblox && (window.Roblox = {}), void 0 === window.Roblox.ItemPurchaseUpsellService && (window.Roblox.ItemPurchaseUpsellService = new Me)
}();
//# sourceMappingURL=https://js.rbxcdn.com/5151955afddf6a8b6455b25bba292197-itemPurchaseUpsell.bundle.min.js.map

/* Bundle detector */
window.Roblox && window.Roblox.BundleDetector && window.Roblox.BundleDetector.bundleDetected("ItemPurchaseUpsell");