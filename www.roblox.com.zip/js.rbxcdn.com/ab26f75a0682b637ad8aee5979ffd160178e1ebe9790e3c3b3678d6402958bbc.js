! function() {
    var e = {
            965: function(e, t, i) {
                var n = {
                    "./notificationIndicatorDirective.js": 4692,
                    "./notificationStreamIconDirective.js": 5014,
                    "./notificationStreamIndicatorDirective.js": 3319
                };

                function a(e) {
                    var t = o(e);
                    return i(t)
                }

                function o(e) {
                    if (!i.o(n, e)) {
                        var t = new Error("Cannot find module '" + e + "'");
                        throw t.code = "MODULE_NOT_FOUND", t
                    }
                    return n[e]
                }
                a.keys = function() {
                    return Object.keys(n)
                }, a.resolve = o, e.exports = a, a.id = 965
            },
            6408: function(e, t, i) {
                var n = {
                    "./abbreviateCountFilter.js": 3800
                };

                function a(e) {
                    var t = o(e);
                    return i(t)
                }

                function o(e) {
                    if (!i.o(n, e)) {
                        var t = new Error("Cannot find module '" + e + "'");
                        throw t.code = "MODULE_NOT_FOUND", t
                    }
                    return n[e]
                }
                a.keys = function() {
                    return Object.keys(n)
                }, a.resolve = o, e.exports = a, a.id = 6408
            },
            2594: function(e, t, i) {
                var n = {
                    "./directives/templates/notificationIndicator.html": 7359,
                    "./directives/templates/notificationStreamIcon.html": 632,
                    "./directives/templates/notificationStreamIndicator.html": 539
                };

                function a(e) {
                    var t = o(e);
                    return i(t)
                }

                function o(e) {
                    if (!i.o(n, e)) {
                        var t = new Error("Cannot find module '" + e + "'");
                        throw t.code = "MODULE_NOT_FOUND", t
                    }
                    return n[e]
                }
                a.keys = function() {
                    return Object.keys(n)
                }, a.resolve = o, e.exports = a, a.id = 2594
            },
            8652: function(e, t, i) {
                var n = {
                    "./gameUpdatesConstants.js": 9474,
                    "./notificationStreamConstants.js": 7085,
                    "./signalR.js": 4835
                };

                function a(e) {
                    var t = o(e);
                    return i(t)
                }

                function o(e) {
                    if (!i.o(n, e)) {
                        var t = new Error("Cannot find module '" + e + "'");
                        throw t.code = "MODULE_NOT_FOUND", t
                    }
                    return n[e]
                }
                a.keys = function() {
                    return Object.keys(n)
                }, a.resolve = o, e.exports = a, a.id = 8652
            },
            4903: function(e, t, i) {
                var n = {
                    "./notificationStreamController.js": 3375,
                    "./notificationsController.js": 2568
                };

                function a(e) {
                    var t = o(e);
                    return i(t)
                }

                function o(e) {
                    if (!i.o(n, e)) {
                        var t = new Error("Cannot find module '" + e + "'");
                        throw t.code = "MODULE_NOT_FOUND", t
                    }
                    return n[e]
                }
                a.keys = function() {
                    return Object.keys(n)
                }, a.resolve = o, e.exports = a, a.id = 4903
            },
            3702: function(e, t, i) {
                var n = {
                    "./clickInCardDirective.js": 1091,
                    "./developerMetricsAvailableDirective.js": 7062,
                    "./friendRequestDirective.js": 4675,
                    "./gameUpdateDirective.js": 561,
                    "./groupMembershipDirective.js": 9768,
                    "./lazyLoadingDirective.js": 2040,
                    "./notificationCardDirective.js": 8367,
                    "./notificationContentDirective.js": 1964,
                    "./notificationContentViewDirective.js": 3008,
                    "./notificationStreamBaseDirective.js": 6113,
                    "./notificationStreamBaseViewDirective.js": 131,
                    "./notificationStreamBodyDirective.js": 7968,
                    "./notificationStreamContainerDirective.js": 3672,
                    "./privateMessageDirective.js": 9273,
                    "./sendrMetaActionsListDirective.js": 1841,
                    "./sendrNotificationDirective.js": 1265,
                    "./testDirective.js": 329
                };

                function a(e) {
                    var t = o(e);
                    return i(t)
                }

                function o(e) {
                    if (!i.o(n, e)) {
                        var t = new Error("Cannot find module '" + e + "'");
                        throw t.code = "MODULE_NOT_FOUND", t
                    }
                    return n[e]
                }
                a.keys = function() {
                    return Object.keys(n)
                }, a.resolve = o, e.exports = a, a.id = 3702
            },
            3748: function(e, t, i) {
                var n = {
                    "./sortGameUpdatesFilter.js": 6097,
                    "./sortNotificationsByEventDateDesc.js": 2900
                };

                function a(e) {
                    var t = o(e);
                    return i(t)
                }

                function o(e) {
                    if (!i.o(n, e)) {
                        var t = new Error("Cannot find module '" + e + "'");
                        throw t.code = "MODULE_NOT_FOUND", t
                    }
                    return n[e]
                }
                a.keys = function() {
                    return Object.keys(n)
                }, a.resolve = o, e.exports = a, a.id = 3748
            },
            3545: function(e, t, i) {
                var n = {
                    "./gameUpdatesService.js": 6009,
                    "./gameUpdatesUtility.js": 4298,
                    "./layoutLibraryI18nService.js": 5078,
                    "./notificationStreamService.js": 8892,
                    "./notificationStreamUtility.js": 1294
                };

                function a(e) {
                    var t = o(e);
                    return i(t)
                }

                function o(e) {
                    if (!i.o(n, e)) {
                        var t = new Error("Cannot find module '" + e + "'");
                        throw t.code = "MODULE_NOT_FOUND", t
                    }
                    return n[e]
                }
                a.keys = function() {
                    return Object.keys(n)
                }, a.resolve = o, e.exports = a, a.id = 3545
            },
            6012: function(e, t, i) {
                var n = {
                    "./directives/templates/developerMetricsAvailable.html": 2175,
                    "./directives/templates/friendRequest.html": 6511,
                    "./directives/templates/gameUpdateActionPopoverTemplate.html": 1282,
                    "./directives/templates/gameUpdateTemplate.html": 3851,
                    "./directives/templates/groupMembership.html": 9585,
                    "./directives/templates/newGameUpdateTemplate.html": 8537,
                    "./directives/templates/notificationContentViewTemplate.html": 5951,
                    "./directives/templates/notificationStreamBaseView.html": 3732,
                    "./directives/templates/notificationStreamContainer.html": 3322,
                    "./directives/templates/privateMessage.html": 8190,
                    "./directives/templates/test.html": 3834
                };

                function a(e) {
                    var t = o(e);
                    return i(t)
                }

                function o(e) {
                    if (!i.o(n, e)) {
                        var t = new Error("Cannot find module '" + e + "'");
                        throw t.code = "MODULE_NOT_FOUND", t
                    }
                    return n[e]
                }
                a.keys = function() {
                    return Object.keys(n)
                }, a.resolve = o, e.exports = a, a.id = 6012
            },
            3544: function(e) {
                function t(e) {
                    return e.replace(/([a-z])([A-Z])/g, "$1-$2").toLowerCase()
                }

                function i(e) {
                    return e.split("/").pop().replace(".html", "")
                }
                var n = {
                    importFilesUnderPath: function(e) {
                        e.keys().forEach(e)
                    },
                    templateCacheGenerator: function(e, n, a, o) {
                        return e.module(n, []).run(["$templateCache", function(e) {
                            a && a.keys().forEach((function(n) {
                                var o = t(i(n));
                                e.put(o, a(n))
                            })), o && o.keys().forEach((function(n) {
                                var a = t(i(n));
                                e.put(a, o(n).replace(/<\/?script[^>]*>/gi, ""))
                            }))
                        }])
                    }
                };
                e.exports = n
            },
            4692: function(e, t, i) {
                "use strict";
                i.r(t);
                var n = i(1887);

                function a(e, t, i) {
                    return {
                        restrict: "A",
                        replace: !0,
                        scope: !0,
                        templateUrl: e.templates.notificationIndicatorTemplate,
                        link: function(e, n, a) {
                            t.bind("Roblox.NotificationStream.UnreadNotifications", (function(t, n) {
                                var a;
                                i.debug(" ----- notificationStreamIconController --- args.count --------".concat(n.count)), e.$evalAsync((a = n, e.layout = e.layout || {}, e.layout.unreadNotifications = a.count, void(e.layout.isNotificationContentOpen = a.isNotificationContentOpen)))
                            }))
                        }
                    }
                }
                a.$inject = ["notificationStreamUtility", "$document", "$log"], n.Z.directive("notificationIndicator", a), t.default = a
            },
            5014: function(e, t, i) {
                "use strict";
                i.r(t);
                var n = i(1887);

                function a(e, t) {
                    return {
                        restrict: "A",
                        replace: !0,
                        scope: !0,
                        templateUrl: e.templates.notificationStreamIconTemplate
                    }
                }
                a.$inject = ["notificationStreamUtility", "$log"], n.Z.directive("a", a), t.default = a
            },
            3319: function(e, t, i) {
                "use strict";
                i.r(t);
                var n = i(792),
                    a = i(1887);

                function o(e, t, i, a, o) {
                    return {
                        restrict: "A",
                        replace: !0,
                        scope: !0,
                        templateUrl: e.templates.notificationStreamIndicatorTemplate,
                        link: function(r, c, s) {
                            function l(e) {
                                r.layout.unreadNotifications = e.count, r.layout.isNotificationContentOpen = e.isNotificationContentOpen
                            }
                            r.layout = r.layout || {}, r.getUnreadNotificationCount = function() {
                                a.unreadCount().then((function(e) {
                                    if (e) {
                                        var t = e.unreadNotifications;
                                        t > 0 && o.sendEventWithTarget(o.eventNames.notificationStream.openCTA, o.context.seen, {
                                            count: t,
                                            sendrVersion: 0
                                        }), r.layout.unreadNotifications = t
                                    }
                                }), (function() {
                                    i.debug("--- unreadCount call failed from notificationStreamIndicatorDirective----- ")
                                })).catch((function(e) {
                                    i.error(e)
                                }))
                            }, t.bind("Roblox.NotificationStream.UpdateNotificationsCount", (function(e, t) {
                                i.debug(" ----- notificationStreamIconController --- args.count --------".concat(t.count)), r.$evalAsync(l(t))
                            })), t.bind("Roblox.NotificationStream.ClearUnreadNotifications", (function() {
                                r.layout.unreadNotifications > 0 && (l({
                                    count: 0,
                                    isNotificationContentOpen: !0
                                }), a.clearUnread().then((function() {
                                    r.layout.unreadNotifications = 0
                                })))
                            })), r.initializeRealTimeSubscriptions = function() {
                                angular.isDefined(n.RealTime) && n.RealTime.Factory.GetClient().Subscribe(e.notificationsName.NotificationStream, r.getUnreadNotificationCount)
                            }, r.layout && r.layout.isNotificationContentOpen || (r.getUnreadNotificationCount(), r.initializeRealTimeSubscriptions());
                            "serviceWorker" in navigator && navigator.serviceWorker.getRegistrations().then((function(e) {
                                e.forEach((function(e) {
                                    var t;
                                    null !== (t = e.active) && void 0 !== t && t.scriptURL && ("/service-workers/push-notifications" === new URL(e.active.scriptURL).pathname && e.unregister())
                                }))
                            }))
                        }
                    }
                }
                o.$inject = ["notificationStreamUtility", "$document", "$log", "notificationStreamService", "eventStreamService"], a.Z.directive("notificationStreamIndicator", o), t.default = o
            },
            3800: function(e, t, i) {
                "use strict";

                function n() {
                    var e = {
                        100: "99+",
                        1e3: "1K+"
                    };
                    return function(t, i, n) {
                        return i || (i = 100), n || (n = e[i]), t >= i ? n : t
                    }
                }
                i.r(t), i(1887).Z.filter("abbreivateCount", n), t.default = n
            },
            1887: function(e, t, i) {
                "use strict";
                var n = i(5734),
                    a = i.n(n)().module("notificationStreamIcon", ["robloxApp", "notificationStream", "notificationStreamIconHtmlTemplate"]);
                t.Z = a
            },
            9474: function(e, t, i) {
                "use strict";
                i.r(t);
                var n = i(792),
                    a = {
                        endpoints: {
                            getReadEndpoint: function() {
                                return {
                                    url: "".concat(n.EnvironmentUrls.notificationApi, "/v2/stream-notifications/game-update-notification-read"),
                                    retryable: !1,
                                    withCredentials: !0
                                }
                            },
                            getGameFollowingsEndpoint: function(e) {
                                return {
                                    url: "".concat(n.EnvironmentUrls.followingsApi, "/v1/users/").concat(e, "/universes"),
                                    retryable: !0,
                                    withCredentials: !0
                                }
                            },
                            getFollowGameEndpoint: function(e, t) {
                                return {
                                    url: "".concat(n.EnvironmentUrls.followingsApi, "/v1/users/").concat(e, "/universes/").concat(t),
                                    retryable: !1,
                                    withCredentials: !0
                                }
                            },
                            getGameDetailsEndpoint: function() {
                                return {
                                    url: "".concat(n.EnvironmentUrls.gamesApi, "/v1/games/multiget-place-details"),
                                    retryable: !0,
                                    withCredentials: !0
                                }
                            },
                            getGameUpdatesEndpoint: function() {
                                return {
                                    url: "".concat(n.EnvironmentUrls.notificationApi, "/v2/stream-notifications/get-latest-game-updates"),
                                    retryable: !0,
                                    withCredentials: !0
                                }
                            },
                            getAbuseReportUrl: function(e, t, i) {
                                return "".concat(n.EnvironmentUrls.websiteUrl, "/abusereport/gameupdate?id=").concat(e, "&redirectUrl=").concat(i)
                            }
                        },
                        apiParams: {
                            gameUpdateBatchSize: 100,
                            placeDetailBatchSize: 100
                        },
                        gameNameMaxLength: 30,
                        gameUpdateInteractions: {
                            played: "Played",
                            seen: "Seen",
                            unfollowed: "Unfollowed"
                        }
                    };
                i(2077).Z.constant("gameUpdatesConstants", a), t.default = a
            },
            7085: function(e, t, i) {
                "use strict";
                i.r(t);
                var n = {
                    experimentionLayer: "Notifications.StreamNotificationUX",
                    recentGameUpdateRetrievedEventName: "nsRecentGameUpdateRetrieved",
                    acceptFriendGroupCount: "nsAcceptFriendGroupCount",
                    streamNotificationsLayer: "Notifications.StreamNotificationUX"
                };
                i(2077).Z.constant("notificationStreamConstants", n), t.default = n
            },
            4835: function(e, t, i) {
                "use strict";
                i.r(t);
                var n = {
                    notifications: {
                        NotificationStream: "NotificationStream"
                    },
                    types: {
                        NewNotification: "NewNotification",
                        NotificationsRead: "NotificationsRead",
                        NotificationMarkedInteracted: "NotificationMarkedInteracted",
                        NotificationRevoked: "NotificationRevoked"
                    }
                };
                i(2077).Z.constant("signalR", n), t.default = n
            },
            3375: function(e, t, i) {
                "use strict";
                i.r(t), i.d(t, {
                    default: function() {
                        return v
                    }
                });
                var n = i(792),
                    a = i(5734),
                    o = i.n(a),
                    r = CoreRobloxUtilities,
                    c = i(2077);

                function s(e, t) {
                    return function(e) {
                        if (Array.isArray(e)) return e
                    }(e) || function(e, t) {
                        if ("undefined" == typeof Symbol || !(Symbol.iterator in Object(e))) return;
                        var i = [],
                            n = !0,
                            a = !1,
                            o = void 0;
                        try {
                            for (var r, c = e[Symbol.iterator](); !(n = (r = c.next()).done) && (i.push(r.value), !t || i.length !== t); n = !0);
                        } catch (e) {
                            a = !0, o = e
                        } finally {
                            try {
                                n || null == c.return || c.return()
                            } finally {
                                if (a) throw o
                            }
                        }
                        return i
                    }(e, t) || function(e, t) {
                        if (!e) return;
                        if ("string" == typeof e) return l(e, t);
                        var i = Object.prototype.toString.call(e).slice(8, -1);
                        "Object" === i && e.constructor && (i = e.constructor.name);
                        if ("Map" === i || "Set" === i) return Array.from(e);
                        if ("Arguments" === i || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(i)) return l(e, t)
                    }(e, t) || function() {
                        throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                    }()
                }

                function l(e, t) {
                    (null == t || t > e.length) && (t = e.length);
                    for (var i = 0, n = new Array(t); i < t; i++) n[i] = e[i];
                    return n
                }

                function u(e, t) {
                    var i = Object.keys(e);
                    if (Object.getOwnPropertySymbols) {
                        var n = Object.getOwnPropertySymbols(e);
                        t && (n = n.filter((function(t) {
                            return Object.getOwnPropertyDescriptor(e, t).enumerable
                        }))), i.push.apply(i, n)
                    }
                    return i
                }

                function d(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var i = null != arguments[t] ? arguments[t] : {};
                        t % 2 ? u(Object(i), !0).forEach((function(t) {
                            f(e, t, i[t])
                        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(i)) : u(Object(i)).forEach((function(t) {
                            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(i, t))
                        }))
                    }
                    return e
                }

                function f(e, t, i) {
                    return t in e ? Object.defineProperty(e, t, {
                        value: i,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : e[t] = i, e
                }

                function p(e, t, i, n, a, o, r) {
                    try {
                        var c = e[o](r),
                            s = c.value
                    } catch (e) {
                        return void i(e)
                    }
                    c.done ? t(s) : Promise.resolve(s).then(n, a)
                }

                function m(e) {
                    return function() {
                        var t = this,
                            i = arguments;
                        return new Promise((function(n, a) {
                            var o = e.apply(t, i);

                            function r(e) {
                                p(o, n, a, r, c, "next", e)
                            }

                            function c(e) {
                                p(o, n, a, r, c, "throw", e)
                            }
                            r(void 0)
                        }))
                    }
                }

                function g(e, t, i, a, c, l, u, f, p, g, v, y) {
                    var b = c.parseEpochMilliseconds,
                        h = y.notificationSourceType;

                    function S(e, t) {
                        return N.apply(this, arguments)
                    }

                    function N() {
                        return (N = m(regeneratorRuntime.mark((function e(t, i) {
                            var n, a, o, c;
                            return regeneratorRuntime.wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        return o = i.map((function(e) {
                                            return e.id
                                        })), e.next = 3, r.cryptoUtil.hashStringWithSha256("".concat(JSON.stringify(o)).concat(Date.now()));
                                    case 3:
                                        return c = e.sent, u.sendEventWithTarget(u.eventNames.notificationStream.notificationsBundleCreated, u.context.fetched, d(d({}, null === (n = i[0]) || void 0 === n || null === (a = n.content) || void 0 === a ? void 0 : a.clientEventsPayload), {}, {
                                            bundleKey: t,
                                            bundleId: c,
                                            totalNotifications: i.length,
                                            notificationIds: o
                                        })), e.abrupt("return", {
                                            bundleKey: t,
                                            bundleId: c,
                                            notificationSourceType: h.sendrBundle,
                                            eventDate: i[0].eventDate,
                                            notifications: i
                                        });
                                    case 6:
                                    case "end":
                                        return e.stop()
                                }
                            }), e)
                        })))).apply(this, arguments)
                    }
                    e.buildNotificationsList = function(t) {
                        var i = [],
                            n = {};
                        t.forEach((function(t) {
                            var a, o, r, s = t.metadataCollection,
                                l = t.notificationSourceType,
                                f = t.notificationSourceType,
                                p = "0";
                            if (null !== (a = t.content) && void 0 !== a && a.notificationType && (f = t.content.notificationType, p = t.content.minVersion.toString()), u.sendEventWithTarget(u.eventNames.notificationStream.notificationRetrieved, u.context.fetched, d(d({}, null == t || null === (o = t.content) || void 0 === o ? void 0 : o.clientEventsPayload), {}, {
                                    sendrVersion: p,
                                    notificationType: f,
                                    notificationId: t.id
                                })), c.isNotificationTypeValid(l)) {
                                c.isGameUpdateNotification(l) || c.isReactNotification(l) || s.forEach((function(t) {
                                    var n = c.normalizeUser(l, t);
                                    if (n && null != n.userId && null != n.userName) {
                                        var a = n.userId,
                                            o = n.userName;
                                        if (e.library.userIdList.indexOf(a) > -1) return !1;
                                        i.push(a), e.library.userIdList.push(a), e.library.userLibrary[a] = {
                                            id: a,
                                            name: o,
                                            profileLink: c.getAbsoluteUrl(c.links.profileLink, {
                                                id: a
                                            })
                                        }
                                    }
                                })), t.isClickable = c.isCardClickable(t), e.notificationIds.indexOf(t.id) < 0 && e.notificationIds.push(t.id);
                                var m = null === (r = t.content) || void 0 === r ? void 0 : r.bundleKey;
                                m ? (n[m] || (n[m] = []), n[m].push(t)) : e.notifications[t.id] = t
                            }
                        })), Object.entries(n).forEach(function() {
                            var t = m(regeneratorRuntime.mark((function t(i) {
                                var n, a, o, r, c;
                                return regeneratorRuntime.wrap((function(t) {
                                    for (;;) switch (t.prev = t.next) {
                                        case 0:
                                            if (a = s(i, 2), o = a[0], r = a[1], !(c = null === (n = r[0]) || void 0 === n ? void 0 : n.id)) {
                                                t.next = 6;
                                                break
                                            }
                                            return t.next = 5, S(o, r);
                                        case 5:
                                            e.notifications[c] = t.sent;
                                        case 6:
                                        case "end":
                                            return t.stop()
                                    }
                                }), t)
                            })));
                            return function(e) {
                                return t.apply(this, arguments)
                            }
                        }()), e.layout.emptyNotificationEnabled = 0 === e.notificationIds.length
                    }, e.buildGameUpdateNotifications = function(t) {
                        if (t && 0 !== t.length) {
                            var i = e.library.gameUpdateModels;
                            f.getGameFollowingsForUserAsync(e.library.currentUserId).then((function(e) {
                                var t, n = [];
                                for (t = 0; t < e.length; t++) n.push(e[t].universeId);
                                return p.getGameUpdatesAsync(n, i)
                            })).then((function(n) {
                                var a, o = p.aggregateGameUpdateNotifications(t, i);
                                if (o) {
                                    e.notifications[o.id] = o, e.notificationIds.unshift(o.id), p.fillGameDetails(i), 1 === o.metadataCollection.length && (a = i[o.metadataCollection[0].UniverseId], f.markGameUpdateInteractedAsync(a.universeId, a.createdOnKey, g.gameUpdateInteractions.seen, e.library.currentUserId));
                                    for (var r = p.sortGameUpdatesByCreatedDate(i, !1), c = b((new Date).toUTCString()), s = 0, d = 0; d < r.length; d++) {
                                        if (!(c / 1e3 - r[d].createdOn / 1e3 <= 1209600)) break;
                                        s++
                                    }
                                    u.sendEventWithTarget(l.recentGameUpdateRetrievedEventName, u.context.fetched, {
                                        sendrVersion: "0",
                                        notificationType: "GameUpdate",
                                        notificationId: o.id,
                                        recentGroupedNotificationCount: s
                                    })
                                }
                            }))
                        }
                    }, e.getRecentNotifications = function() {
                        e.layout.getRecentDataInitialized = !1, a.getRecentNotifications(e.notificationApiParams.startIndexOfNotifications, e.notificationApiParams.pageSizeOfNotifications).then((function(t) {
                            var i = [],
                                n = [];
                            e.layout.getRecentDataInitialized = !0, e.layout.isGetRecentDataLoadedRequested = !1, t && t.length > 0 && (o().forEach(t, (function(e) {
                                c.isGameUpdateNotification(e.notificationSourceType) ? i.push(e) : n.push(e)
                            })), e.buildNotificationsList(n), i.length > 0 && e.buildGameUpdateNotifications(i), e.layout.isLazyLoadingRequested = !0, t.length > 0 && (e.notificationApiParams.startIndexOfNotifications = e.notificationApiParams.startIndexOfNotifications + e.notificationApiParams.pageSizeOfNotifications, e.notificationApiParams.loadMoreNotifications = !0))
                        }), (function() {
                            v.debug("--- getRecentNotifications call failed ----- "), e.layout.getRecentDataInitialized = !0
                        }))
                    }, e.setNotificationContentOpen = function(t) {
                        (e.layout.isNotificationContentOpen = t, t) || (window.removeEventListener("Roblox.NotificationStream.StreamClosed", e.handleStreamClosed), n.RealTime.Factory.GetClient().Unsubscribe(c.notificationsName.NotificationStream, e.handleNotificationStreamNotification))
                    }, e.clearUnreadNotifications = function() {
                        e.library.unreadNotifications > 0 && (e.library.unreadNotifications = 0, t.triggerHandler("Roblox.NotificationStream.UpdateNotificationsCount", {
                            count: 0,
                            isNotificationContentOpen: e.layout.isNotificationContentOpen
                        }))
                    }, e.openNotificationStream = function() {
                        e.layout.isGetRecentDataLoadedRequested && (e.resetNotificationStreamData(), e.getRecentNotifications()), t.triggerHandler("Roblox.NotificationStream.ClearUnreadNotifications", {}), e.clearUnreadNotifications()
                    }, e.toggleNotificationContent = function(t) {
                        t ? e.setNotificationContentOpen(!1) : (e.library.inApp || e.setNotificationContentOpen(!e.layout.isNotificationContentOpen), e.layout.isNotificationContentOpen && e.layout.isGetRecentDataLoadedRequested && e.openNotificationStream()), e.layout.isNotificationContentOpen && e.layout.bannerEnabled && (e.layout.bannerEnabled = !1), e.layout.isLazyLoadingRequested && (e.layout.isLazyLoadingRequested = !1)
                    }, e.getUnreadNotificationCount = function() {
                        return a.unreadCount().then((function(i) {
                            if (i) {
                                e.library.unreadNotifications = i.unreadNotifications;
                                var n, a = i.unreadNotifications,
                                    o = e.layout.isNotificationContentOpen;
                                if (o ? e.layout.bannerText = c.textTemplate.newNotification(e.library.unreadNotifications) : t.triggerHandler("Roblox.NotificationStream.UpdateNotifications", {
                                        count: i.unreadNotifications,
                                        isNotificationContentOpen: o
                                    }), e.layout.unreadNotifications !== a && a > 0) n = o ? u.eventNames.notificationStream.refreshCTA : u.eventNames.notificationStream.openCTA, u.sendEventWithTarget(n, u.context.seen, {
                                    count: a,
                                    sendrVersion: 0
                                })
                            }
                        }), (function() {
                            v.debug("--- unreadCount call failed ----- ")
                        }))
                    }, e.resetNotificationStreamData = function() {
                        e.notificationIds = [], e.notifications = {}, e.notificationApiParams && (e.notificationApiParams.startIndexOfNotifications = 0)
                    }, e.reloadNotificationStreamData = function() {
                        e.resetNotificationStreamData(), t.triggerHandler("Roblox.NotificationStream.ClearUnreadNotifications", {}), e.getRecentNotifications(), e.layout.bannerEnabled = !1
                    }, e.updateNewNotificationInfo = function() {
                        e.layout.isGetRecentDataLoadedRequested = !0, e.getUnreadNotificationCount(), e.$evalAsync((function() {
                            e.layout.isNotificationContentOpen && (e.layout.bannerEnabled = !0)
                        }))
                    }, e.updateSettingsInLibrary = function(t) {
                        e.library.bannerDismissTimeSpan = t.bannerDismissTimeSpan, e.library.signalRDisconnectionResponseInMilliseconds = t.signalRDisconnectionResponseInMilliseconds, e.library.eventStreamMetaData = {
                            userId: e.library.currentUserId,
                            inApp: e.library.inApp
                        }, e.library.canLaunchGameFromGameUpdate = t.canLaunchGameFromGameUpdate
                    }, e.handleSignalRSuccess = function() {
                        e.$evalAsync((function() {
                            e.layout.errorBannerEnabled = !1
                        }))
                    }, e.handleSignalRError = function() {
                        i((function() {
                            e.layout.errorBannerEnabled = !0, e.layout.errorText = c.textTemplate.noNetworkConnectionText()
                        }), e.library.signalRDisconnectionResponseInMilliseconds)
                    }, e.handleNotificationStreamNotification = function(t) {
                        switch (v.debug("--------- this is NotificationStream subscription -----------".concat(t.Type)), t.Type) {
                            case c.signalRType.NewNotification:
                                e.updateNewNotificationInfo();
                                break;
                            case c.signalRType.NotificationsRead:
                                e.clearUnreadNotifications();
                                break;
                            case c.signalRType.NotificationRevoked:
                                e.getUnreadNotificationCount(), e.layout.isStreamBodyInteracted || e.reloadNotificationStreamData()
                        }
                    }, e.getAccountSettingsPolicy = function() {
                        a.getAccountSettingsPolicy().then((function(t) {
                            e.library.isNotificationPreferencesPageEnabled = t && t.displayReactNotificationsTab
                        }), (function(e) {
                            v.debug(e)
                        }))
                    }, e.closeErrorBanner = function() {
                        e.layout.errorBannerEnabled = !1, e.layout.errorText = ""
                    }, e.closeBanner = function() {
                        e.layout.bannerEnabled = !1, e.layout.bannerText = ""
                    }, e.getNotificationListItemClass = function(e) {
                        return c.isReactNotification(e.notificationSourceType) ? "" : {
                            "notification-stream-item": !0,
                            unInteracted: !e.isInteracted,
                            "slide-out-left": e.isSlideOut,
                            "turn-off": e.isTurnOff,
                            clickable: e.isClickable,
                            "game-update": c.isGameUpdateNotification(e.notificationSourceType)
                        }
                    }, e.initializeRealTimeSubscriptions = function() {
                        if (o().isDefined(n.RealTime)) {
                            var t = n.RealTime.Factory.GetClient();
                            t.SubscribeToConnectionEvents(e.handleSignalRSuccess, e.handleSignalRSuccess, e.handleSignalRError, c.notificationsName.NotificationStream), t.Subscribe(c.notificationsName.NotificationStream, e.handleNotificationStreamNotification)
                        }
                    }, e.getUnreadNotificationCountFromDom = function() {
                        var t = o().element(".notification-stream-icon .notification-red");
                        t && !Number.isNaN(t) && (e.library.unreadNotifications = parseInt(t.html(), 10))
                    }, e.handleStreamClosed = function() {
                        e.setNotificationContentOpen(!1)
                    }, e.initializeNotificationStream = function() {
                        ! function() {
                            try {
                                e.library = e.library || c.library, e.resetNotificationStreamData(), e.getAccountSettingsPolicy(), a.initialize().then((function(t) {
                                    t && (c.layout.pageDataInitialized = !0, e.updateSettingsInLibrary(t))
                                }), (function() {
                                    v.debug("----- initialize data request failed ----")
                                }))
                            } catch (e) {
                                var t = "initializePageData:";
                                e && e.message && (t += e.message), v.debug(t)
                            }
                        }(),
                        function() {
                            if (e.layout = o().copy(c.layout), e.notificationApiParams = o().copy(c.notificationApiParams), e.library.inApp) {
                                var t = o().copy(e.library.eventStreamMetaData);
                                t.countOfUnreadNotification = e.library.unreadNotifications, t.sendrVersion = 0, u.sendEventWithTarget(u.eventNames.notificationStream.openContent, u.context.inApp, t), e.getUnreadNotificationCount().then((function() {
                                    a.clearUnread().then((function() {
                                        e.library.unreadNotifications = 0
                                    }))
                                })), e.setNotificationContentOpen(!0)
                            } else e.getUnreadNotificationCountFromDom()
                        }(),
                        function() {
                            if (!e.layout.isNotificationContentOpen) {
                                var t = o().copy(e.library.eventStreamMetaData);
                                t.countOfUnreadNotification = e.library.unreadNotifications, t.sendrVersion = 0, u.sendEventWithTarget(u.eventNames.notificationStream.openContent, "click", t)
                            }
                            e.toggleNotificationContent()
                        }(), e.initializeRealTimeSubscriptions(), window.addEventListener("Roblox.NotificationStream.StreamClosed", e.handleStreamClosed)
                    }, e.initializeNotificationStream()
                }
                g.$inject = ["$scope", "$document", "$timeout", "notificationStreamService", "notificationStreamUtility", "notificationStreamConstants", "eventStreamService", "gameUpdatesService", "gameUpdatesUtility", "gameUpdatesConstants", "$log", "layoutLibraryService"], c.Z.controller("notificationStreamController", g);
                var v = g
            },
            2568: function(e, t, i) {
                "use strict";
                i.r(t);
                var n = i(5734),
                    a = i.n(n),
                    o = i(2077);

                function r(e, t) {
                    var i = Object.keys(e);
                    if (Object.getOwnPropertySymbols) {
                        var n = Object.getOwnPropertySymbols(e);
                        t && (n = n.filter((function(t) {
                            return Object.getOwnPropertyDescriptor(e, t).enumerable
                        }))), i.push.apply(i, n)
                    }
                    return i
                }

                function c(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var i = null != arguments[t] ? arguments[t] : {};
                        t % 2 ? r(Object(i), !0).forEach((function(t) {
                            s(e, t, i[t])
                        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(i)) : r(Object(i)).forEach((function(t) {
                            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(i, t))
                        }))
                    }
                    return e
                }

                function s(e, t, i) {
                    return t in e ? Object.defineProperty(e, t, {
                        value: i,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : e[t] = i, e
                }

                function l(e, t, i, n, o, r, s, l, u, d) {
                    function f(t, i, n) {
                        var o = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : {},
                            s = e.notifications[i],
                            l = a().copy(e.library.eventStreamMetaData);
                        l.notificationId = i, l.sendrVersion = 0, s && (l.notificationType = s.notificationSourceType);
                        var u = c(c({}, l), o);
                        r.sendEventWithTarget(t, n, u)
                    }
                    var p;
                    e.parseErrorFromApiResponse = function(e) {
                        return e && e.errors && e.errors[0]
                    }, e.acceptFriend = function(i, n, a) {
                        d.debug("---------------- acceptFriend --------- ");
                        var o = e.notifications[n];
                        e.interactNotification(o), t.acceptFriendV2(i).then((function(t) {
                            e.onAcceptFriendSuccess(n, a)
                        }), (function(t) {
                            var i = e.parseErrorFromApiResponse(t);
                            i && i.userFacingMessage && (e.layout.errorText = i.userFacingMessage, e.layout.errorBannerEnabled = !0)
                        }))
                    }, e.onAcceptFriendSuccess = function(t, n) {
                        var a = e.notifications[t];
                        a.friendRequestActionType = i.friendRequestActionType.chatBtn, a.metadataCollection[0].IsAccepted = !0, a.isFlipped = !0, u.triggerHandler("Roblox.Friends.CountChanged"), f(r.eventNames.notificationStream.acceptFriendRequest, t, n.type)
                    }, e.ignoreFriend = function(i, n, a) {
                        d.debug("---------------- ignoreFriend --------- ");
                        var o = e.notifications[n];
                        e.interactNotification(o), t.ignoreFriendV2(i).then((function(t) {
                            e.onIgnoreFriend(n, a)
                        }), (function(t) {
                            e.onIgnoreFriend(n, a)
                        }))
                    }, e.onIgnoreFriend = function(t, i) {
                        e.notifications[t].isSlideOut = !0, f(r.eventNames.notificationStream.ignoreFriendRequest, t, i.type)
                    }, e.removeNotification = function(t) {
                        d.debug("---------------- removeNotification --------- notificationId:  ".concat(t));
                        var i = e.notificationIds.indexOf(t);
                        e.notificationIds.splice(i, 1), delete e.notifications[t]
                    }, e.chat = function(t, i, n) {
                        var a = e.notifications[i];
                        e.interactNotification(a);
                        var o = l.buildPermissionVerifier(e.library);
                        o.uwpApp.hybridRequired = !0, l.startChat(t, o), f(r.eventNames.notificationStream.chat, i, n.type)
                    }, e.interactNotification = function(e) {
                        e.isInteracted || t.markInteracted(e.id).then((function() {
                            e.isInteracted = !0
                        }))
                    }, e.clickCard = function(t) {
                        var a, c, l = "",
                            u = {};
                        switch (t.notificationSourceType) {
                            case i.notificationSourceType.friendRequestReceived:
                                if (e.interactNotification(t), t.eventCount > 1 || 0 === t.metadataCollection.length) l = i.links.friendRequestLink, e.library.inApp ? (u = {
                                    feature: i.links.friendRequestTabName,
                                    urlPath: l
                                }, o.navigateToFeature(u, (function(e) {
                                    d.debug("openUserFriendsPage ---- status:".concat(e))
                                }))) : window.location.href = s.getAbsoluteUrl(l);
                                else if (t.metadataCollection && t.metadataCollection.length > 0) {
                                    var p = t.metadataCollection[0];
                                    l = i.links.profileLink;
                                    var m = p.SenderUserId;
                                    e.library.inApp ? o.openUserProfile(parseInt(m), (function(e) {
                                        d.debug("openUserProfile ---- status:".concat(e))
                                    })) : window.location.href = i.getAbsoluteUrl(l, {
                                        id: m
                                    })
                                }
                                break;
                            case i.notificationSourceType.friendRequestAccepted:
                                e.interactNotification(t), l = i.links.friendsLink;
                                var g = null !== (a = t.eventCount) && void 0 !== a ? a : null === (c = t.metadataCollection) || void 0 === c ? void 0 : c.length;
                                f(n.acceptFriendGroupCount, t.id, t.notificationSourceType, {
                                    count: g
                                }), e.library.inApp ? (u = {
                                    feature: i.links.friendsTabName,
                                    urlPath: l
                                }, o.navigateToFeature(u, (function(e) {
                                    d.debug("openUserFriendsPage ---- status:".concat(e))
                                }))) : window.location.href = s.getAbsoluteUrl(l);
                                break;
                            case i.notificationSourceType.privateMessageReceived:
                                if (e.interactNotification(t), t.eventCount > 1 || 0 === t.metadataCollection.length) l = i.links.inboxLink;
                                else if (t.metadataCollection && t.metadataCollection.length > 0) {
                                    p = t.metadataCollection[0];
                                    l = i.links.inboxLink + i.links.inboxMessageDetailQuery + p.MessageId
                                }
                                f(r.eventNames.notificationStream.goToMessages, t.id, t.notificationSourceType, {
                                    targetUrl: l
                                }), e.library.inApp ? (u = {
                                    feature: i.links.inboxTabName,
                                    urlPath: l
                                }, o.navigateToFeature(u, (function(e) {
                                    d.debug("openUserProfile ---- status:".concat(e))
                                }))) : window.location.href = s.getAbsoluteUrl(l);
                                break;
                            case i.notificationSourceType.developerMetricsAvailable:
                                e.interactNotification(t);
                                break;
                            case i.notificationSourceType.groupJoinRequestAccepted:
                                if (e.interactNotification(t), 0 === t.metadataCollection.length) l = i.links.myGroupsLink, f(r.eventNames.notificationStream.goToGroupPage, t.id, t.notificationSourceType, {
                                    groupId: 0
                                }), e.library.inApp ? (u = {
                                    feature: i.links.groupsTabName,
                                    urlPath: l
                                }, o.navigateToFeature(u, (function(e) {
                                    d.debug("openGroupDetails ---- status:".concat(e))
                                }))) : window.location.href = s.getAbsoluteUrl(l);
                                else if (t.metadataCollection && t.metadataCollection.length > 0) {
                                    p = t.metadataCollection[0];
                                    l = i.links.groupLink;
                                    var v = p.AccepterGroupId;
                                    u = {
                                        feature: i.links.groupsTabName,
                                        urlPath: l
                                    }, f(r.eventNames.notificationStream.goToGroupPage, t.id, t.notificationSourceType, {
                                        groupId: v
                                    }), e.library.inApp ? o.navigateToFeature(u, (function(e) {
                                        d.debug("openGroupDetails ---- status:".concat(e))
                                    })) : window.location.href = i.getAbsoluteUrl(l, {
                                        id: v
                                    })
                                }
                        }
                    }, e.notificationSourceType = i.notificationSourceType, e.contentViewManager = (p = {}, {
                        addContentView: function(e) {
                            p[e.viewId] = e
                        },
                        selectContentView: function(e) {
                            var t, i = null !== (t = this.getCurrentContentViewId) && void 0 !== t ? t : "",
                                n = p[e];
                            n && (a().forEach(p, (function(e) {
                                e.isActive = !1
                            })), n.isActive = !0, "" !== i && i !== e && r.sendEventWithTarget(r.eventNames.notificationStream.pageChanged, r.context.click, {
                                targetPage: e,
                                sendrVersion: 0
                            }))
                        },
                        getCurrentContentViewId: function() {
                            var e = "";
                            return a().forEach(p, (function(t, i) {
                                t.isActive && (e = i)
                            })), e
                        }
                    }), u.bind("Roblox.Popover.Status", (function(t, i) {
                        d.debug("notificationsController"), i.isOpen || e.contentViewManager.selectContentView(e.library.notificationContentViews.main)
                    }))
                }
                l.$inject = ["$scope", "notificationStreamService", "notificationStreamUtility", "notificationStreamConstants", "hybridService", "eventStreamService", "urlService", "chatDispatchService", "$document", "$log"], o.Z.controller("notificationsController", l), t.default = l
            },
            1091: function(e, t, i) {
                "use strict";
                i.r(t);
                var n = i(5734),
                    a = i.n(n),
                    o = i(2077);

                function r(e, t, i, n, o) {
                    return {
                        restrict: "A",
                        scope: !0,
                        link: function(r, c, s) {
                            c.bind("click", (function(s) {
                                if (!s.target) return !1;
                                var l = a().element(s.target),
                                    u = l.attr("type"),
                                    d = a().copy(r.library.eventStreamMetaData);
                                d.sendrVersion = 0;
                                var f = c.attr("type"),
                                    p = e.eventNames.notificationStream[f];
                                if (null !== p && r.notification && (d.notificationType = r.notification.notificationSourceType, d.notificationId = r.notification.id, e.sendEventWithTarget(p, e.context.click, d)), s.target && u && (r.notification && (d.notificationType = r.notification.notificationSourceType, r.interactNotification(r.notification)), p = e.eventNames.notificationStream[u], e.sendEventWithTarget(p, s.type, d), r.library.inApp)) {
                                    switch (s.stopPropagation(), s.preventDefault(), u) {
                                        case i.links.settingLinkName:
                                            var m = {
                                                feature: i.links.settingTabName,
                                                urlPath: i.links.settingLink
                                            };
                                            t.navigateToFeature(m, (function(e) {
                                                n.debug("navigateToFeature ---- status:".concat(e))
                                            }));
                                            break;
                                        case i.links.friendRequestLinkName:
                                            m = {
                                                feature: i.links.friendRequestTabName,
                                                urlPath: i.links.friendRequestLink
                                            };
                                            t.navigateToFeature(m, (function(e) {
                                                n.debug("openUserProfile ---- status:".concat(e))
                                            }));
                                            break;
                                        case i.links.profileLinkName:
                                            var g;
                                            g = l.attr("href") && l.attr("href").match(/users\/(\d+)/, "") ? l.attr("href").match(/users\/(\d+)/, "")[1] : r.userIds[0], t.openUserProfile(parseInt(g), (function(e) {
                                                n.debug("openUserProfile ---- status:".concat(e))
                                            }));
                                            break;
                                        case i.links.groupLinkName:
                                            var v;
                                            if (l.attr("href") && l.attr("href").match(/groups\/(\d+)/, "")) {
                                                var y = l.attr("href").match(/groups\/(\d+)/, "")[1];
                                                v = o("formatString")(i.links.groupLink, {
                                                    id: y
                                                })
                                            } else v = i.links.myGroupsLink;
                                            m = {
                                                feature: i.links.groupsTabName,
                                                urlPath: v
                                            }, t.navigateToFeature(m, (function(e) {
                                                n.debug("openGroupDetails ---- status:".concat(e))
                                            }))
                                    }
                                    return !1
                                }
                            }))
                        }
                    }
                }
                r.$inject = ["eventStreamService", "hybridService", "notificationStreamUtility", "$log", "$filter"], o.Z.directive("clickInCard", r), t.default = r
            },
            7062: function(e, t, i) {
                "use strict";
                i.r(t);
                var n = i(792),
                    a = i(2077);

                function o(e, t, i, a) {
                    return {
                        restrict: "A",
                        replace: !0,
                        scope: {
                            notification: "=",
                            appMeta: "=",
                            library: "=",
                            layout: "=",
                            interactNotification: "&"
                        },
                        templateUrl: t.templates.developerMetricsAvailableTemplate,
                        link: function(o, r, c) {
                            ! function() {
                                o.notificationSourceType = t.notificationSourceType, o.developerMetricsAvailableLayout = {
                                    month: "",
                                    year: "",
                                    universeId: -1,
                                    gameName: "",
                                    gameNameLinked: "",
                                    rootPlaceId: -1,
                                    gameLinkUrl: null,
                                    gameIconUrl: null
                                };
                                var r = o.notification.metadataCollection;
                                if (r && r.length > 0) {
                                    var c = r[0],
                                        s = i.getAbsoluteUrl("/places/".concat(c.rootPlaceId, "/stats"));
                                    o.developerMetricsAvailableLayout.month = function(e) {
                                        for (var t = (new n.Intl).getMonthsList("long"), i = 0, a = t.length; i < a; i++)
                                            if (t[i].value === e) return t[i].name;
                                        return ""
                                    }(c.month), o.developerMetricsAvailableLayout.year = c.year, o.developerMetricsAvailableLayout.universeId = c.universeId, o.developerMetricsAvailableLayout.gameName = c.gameName, o.developerMetricsAvailableLayout.gameNameLinked = '<a class="text-name font-caption-header" href="'.concat(s, '">').concat(c.gameName, "</a>"), o.developerMetricsAvailableLayout.rootPlaceId = c.rootPlaceId, o.developerMetricsAvailableLayout.gameLinkUrl = s, o.developerMetricsAvailableLayout.notificationId = o.notification.id, o.viewButtonHandler = function() {
                                        e.location.href = o.developerMetricsAvailableLayout.gameLinkUrl;
                                        var i = a.eventNames.notificationStream.viewDeveloperMetrics,
                                            n = {
                                                notificationId: o.developerMetricsAvailableLayout.notificationId,
                                                notificationType: t.notificationSourceType.developerMetricsAvailable,
                                                universeId: o.developerMetricsAvailableLayout.universeId,
                                                sendrVersion: 0
                                            };
                                        a.sendEventWithTarget(i, a.context.click, n)
                                    }
                                }
                            }()
                        }
                    }
                }
                o.$inject = ["$window", "notificationStreamUtility", "urlService", "eventStreamService"], a.Z.directive("developerMetricsAvailable", o), t.default = o
            },
            4675: function(e, t, i) {
                "use strict";
                i.r(t);
                var n = i(2077);

                function a(e, t, i) {
                    return {
                        restrict: "A",
                        replace: !0,
                        scope: {
                            notification: "=",
                            library: "=",
                            layout: "=",
                            appMeta: "=",
                            acceptFriend: "&",
                            ignoreFriend: "&",
                            chat: "&",
                            interactNotification: "&"
                        },
                        templateUrl: e.templates.friendRequestTemplate,
                        link: function(t, n, a) {
                            var o = t.notification.metadataCollection,
                                r = t.notification.notificationSourceType,
                                c = o.length,
                                s = t.notification.eventCount ? t.notification.eventCount : c,
                                l = "",
                                u = "";
                            t.notificationSourceType = e.notificationSourceType, t.friendRequestLink = e.layout.friendRequestLink, t.thumbnailTypes = i.thumbnailTypes,
                                function() {
                                    if (t.userIds = [], t.notificationDisplayText = "", o.forEach((function(i, n) {
                                            var a = e.normalizeUser(r, i),
                                                o = a.userId,
                                                c = a.userName,
                                                d = a.displayName,
                                                f = t.library.userLibrary[o] && t.library.userLibrary[o].profileLink ? t.library.userLibrary[o].profileLink : e.getAbsoluteUrl(e.links.profileLink, {
                                                    id: o
                                                });
                                            t.userIds.indexOf(o) < 0 && t.userIds.push(o);
                                            var p = e.getUserHtmlTemplate(r, s),
                                                m = e.getFormatString(p, {
                                                    userId: o,
                                                    userName: c,
                                                    displayName: d,
                                                    profileLink: f
                                                });
                                            n < 1 ? l += m : n < 2 && (u += m)
                                        })), 0 === c) t.notificationDisplayText = e.normalizeYouHaveText(r, s);
                                    else if (s > 2 || s > c) {
                                        var i = c > 2 ? s - 2 : s - c;
                                        t.notificationDisplayText = e.normalizeMultipleDisplayText(r, l, u, i), t.requestConfirmedText = e.normalizeMultipleConfirmedText(r, l, u, i)
                                    } else 2 === s ? (t.notificationDisplayText = e.normalizeDoubleDisplayText(r, l, u), t.requestConfirmedText = e.normalizeDoubleConfirmedText(r, l, u)) : (t.notificationDisplayText = e.normalizeSingleDisplayText(r, l), t.requestConfirmedText = e.normalizeSingleConfirmedText(r, l))
                                }(), t.friendRequestActionType = e.friendRequestActionType, t.notification.notificationSourceType === e.notificationSourceType.friendRequestReceived ? 1 !== c || 1 !== s || o[0].IsAccepted ? 1 === c && 1 === s && o[0].IsAccepted ? t.notification.friendRequestActionType = e.friendRequestActionType.chatBtn : t.notification.friendRequestActionType = e.friendRequestActionType.viewAllBtn : t.notification.friendRequestActionType = o[0].IsAccepted ? e.friendRequestActionType.chatBtn : e.friendRequestActionType.acceptIgnoreBtns : t.notification.notificationSourceType === e.notificationSourceType.friendRequestAccepted && 1 === c && 1 === s && (t.notification.friendRequestActionType = e.friendRequestActionType.chatBtn)
                        }
                    }
                }
                a.$inject = ["notificationStreamUtility", "$log", "thumbnailConstants"], n.Z.directive("friendRequest", a), t.default = a
            },
            561: function(e, t, i) {
                "use strict";
                i.r(t), i.d(t, {
                    default: function() {
                        return s
                    }
                });
                var n = i(792),
                    a = (CoreUtilities, i(5734)),
                    o = i.n(a),
                    r = i(2077);

                function c(e, t, i, a, r, c, s, l, u, d) {
                    var f = a.gameUpdateInteractions;
                    return {
                        restrict: "A",
                        replace: !0,
                        templateUrl: function(e, t) {
                            return void 0 === t.newDesign || null === t.newDesign ? r.templates.gameUpdateTemplate : r.templates.newGameUpdateTemplate
                        },
                        scope: {
                            library: "=",
                            appMeta: "=",
                            contentViewManager: "=",
                            newDesign: "=?",
                            notification: "=?",
                            gameUpdateModel: "=?"
                        },
                        link: function(a, s, p) {
                            var m, g = $(s);
                            if (!a.gameUpdateModel) {
                                if (!a.notification) return;
                                if ((m = a.notification.metadataCollection) && m.length > 0 && (a.gameUpdateModel = a.library.gameUpdateModels[m[0].UniverseId]), !a.gameUpdateModel) return
                            }
                            var v = "".concat(a.gameUpdateModel.rootPlaceId, "-").concat(a.gameUpdateModel.createdOn);
                            a.notificationSourceType = r.notificationSourceType, a.thumbnailTypes = u.thumbnailTypes, m && m.length > 1 && (a.isAggregated = !0, a.aggregatedDisplayText = i.formatAggregatedDisplayText(l("escapeHtml")(m[0].GameName), l("escapeHtml")(m[1].GameName), a.notification.eventCount - 2)), a.gameNameMaxLength = i.gameNameMaxLength, a.actionMenuTemplate = "game-update-action-popover-template", a.isActionMenuOpen = !1, a.getEventExtraParams = function() {
                                var e;
                                return {
                                    notifId: v,
                                    notifType: "gameUpdate",
                                    pid: a.gameUpdateModel.rootPlaceId,
                                    sourceId: a.gameUpdateModel.universeId,
                                    isAggregate: null !== (e = a.isAggregated) && void 0 !== e && e,
                                    nsPage: a.contentViewManager.getCurrentContentViewId(),
                                    sendrVersion: 0
                                }
                            }, a.$watch("isActionMenuOpen", (function(e, t) {
                                e && !t ? d.sendEventWithTarget(d.eventNames.notificationStream.openMetaActions, d.context.click, a.getEventExtraParams()) : t && !e && d.sendEventWithTarget(d.eventNames.notificationStream.closeMetaActions, d.context.click, a.getEventExtraParams())
                            })), a.goToGameDetails = function() {
                                d.sendEventWithTarget(d.eventNames.notificationStream.goToGameDetails, d.context.click, a.getEventExtraParams()), a.library.inApp ? c.navigateToFeature({
                                    feature: "GameDetails",
                                    urlPath: a.gameUpdateModel.gameLinkUrlForApp
                                }) : e.location.href = urlService.getAbsoluteUrl(a.gameUpdateModel.gameLinkUrl)
                            }, a.playButtonHandler = function() {
                                t.markGameUpdateInteractedAsync(a.gameUpdateModel.universeId, a.gameUpdateModel.createdOnKey, f.played, a.library.currentUserId), a.library.inApp ? c.launchGame({
                                    placeId: a.gameUpdateModel.rootPlaceId,
                                    requestType: "RequestGame",
                                    isPartyLeader: !1
                                }) : n.GameLauncher.joinMultiplayerGame(a.gameUpdateModel.rootPlaceId, !0, !1), d.sendEventWithTarget(d.eventNames.notificationStream.launchExperience, d.context.click, a.getEventExtraParams())
                            }, a.viewGameUpdates = function() {
                                a.contentViewManager.selectContentView(a.library.notificationContentViews.gameUpdates), o().forEach(a.library.gameUpdateModels, (function(e) {
                                    e.seen || t.markGameUpdateInteractedAsync(e.universeId, e.createdOnKey, f.seen, a.library.currentUserId).then((function() {
                                        e.seen = !0
                                    }), (function() {}))
                                }))
                            }, a.followGame = function() {
                                d.sendEventWithTarget(d.eventNames.notificationStream.follow, d.context.click, a.getEventExtraParams()), t.followGameAsync(a.library.currentUserId, a.gameUpdateModel.universeId).then((function() {
                                    g.focus(), a.gameUpdateModel.isUnfollowed = !1, a.gameUpdateModel.updateMessage || i.getGameUpdatesAsync([a.gameUpdateModel.universeId], a.library.gameUpdateModels, null)
                                }), (function() {}))
                            }, a.unfollowGame = function(e) {
                                e && e.stopPropagation && e.stopPropagation(), d.sendEventWithTarget(d.eventNames.notificationStream.unfollow, d.context.click, a.getEventExtraParams()), t.unfollowGameAsync(a.library.currentUserId, a.gameUpdateModel.universeId).then((function() {
                                    g.focus(), a.gameUpdateModel.isUnfollowed = !0, a.isActionMenuOpen = !1, t.markGameUpdateInteractedAsync(a.gameUpdateModel.universeId, a.gameUpdateModel.createdOnKey, f.unfollowed, a.library.currentUserId)
                                }), (function() {}))
                            }, a.reportAbuse = function() {
                                t.reportAbuse(a.gameUpdateModel.universeId, new Date(a.gameUpdateModel.createdOn)), d.sendEventWithTarget(d.eventNames.notificationStream.report, d.context.click, a.getEventExtraParams())
                            }, a.closeActionMenu = function() {
                                a.isActionMenuOpen = !1
                            }
                        }
                    }
                }
                c.$inject = ["$window", "gameUpdatesService", "gameUpdatesUtility", "gameUpdatesConstants", "notificationStreamUtility", "hybridService", "$log", "$filter", "thumbnailConstants", "eventStreamService"], r.Z.directive("gameUpdate", c);
                var s = c
            },
            9768: function(e, t, i) {
                "use strict";
                i.r(t);
                var n = i(2077);

                function a(e, t, i, n) {
                    return {
                        restrict: "A",
                        replace: !0,
                        scope: {
                            notification: "=",
                            appMeta: "=",
                            library: "=",
                            layout: "=",
                            interactNotification: "&"
                        },
                        templateUrl: e.templates.groupMembershipTemplate,
                        link: function(t, a, o) {
                            var r = t.notification.metadataCollection,
                                c = t.notification.notificationSourceType,
                                s = r.length,
                                l = t.notification.eventCount ? t.notification.eventCount : s,
                                u = "",
                                d = "";
                            t.thumbnailTypes = i.thumbnailTypes, t.groupMembershipLayout = {},
                                function() {
                                    if (t.notificationDisplayText = "", r.forEach((function(i, a) {
                                            var o = i.AccepterGroupId,
                                                r = i.AccepterGroupName,
                                                c = e.getAbsoluteUrl(e.layout.groupLink, {
                                                    id: o
                                                }),
                                                s = e.getGroupHtmlTemplate(),
                                                l = e.getFormatString(s, {
                                                    groupId: o,
                                                    groupName: n("escapeHtml")(r),
                                                    groupLink: c
                                                });
                                            a < 1 ? (u += l, t.groupMembershipLayout = {
                                                groupId: o,
                                                groupName: r,
                                                groupLink: c
                                            }) : a < 2 && (d += l)
                                        })), 0 === s) t.notificationDisplayText = e.normalizeYouHaveText(c, l);
                                    else if (l > 2 || l > s) {
                                        var i = s > 2 ? l - 2 : l - s;
                                        t.notificationDisplayText = e.normalizeMultipleDisplayText(c, u, d, i)
                                    } else t.notificationDisplayText = 2 === l ? e.normalizeDoubleDisplayText(c, u, d) : e.normalizeSingleDisplayText(c, u)
                                }()
                        }
                    }
                }
                a.$inject = ["notificationStreamUtility", "$log", "thumbnailConstants", "$filter"], n.Z.directive("groupMembership", a), t.default = a
            },
            2040: function(e, t, i) {
                "use strict";
                i.r(t);
                i(792);
                var n = i(5734),
                    a = i.n(n),
                    o = i(2077);

                function r(e, t, i) {
                    return {
                        restrict: "A",
                        scope: !0,
                        link: function(t, n, o) {
                            t.callbackLazyLoad = function() {
                                if (!t.notificationApiParams || t.layout.isNotificationsLoading) return !1;
                                t.notificationApiParams.loadMoreNotifications && (t.layout.isNotificationsLoading = !0, t.layout.notiticationsLazyLoadingEnabled = !0, e.getRecentNotifications(t.notificationApiParams.startIndexOfNotifications, t.notificationApiParams.pageSizeOfNotifications).then((function(e) {
                                    t.layout.notiticationsLazyLoadingEnabled = !1, e && e.length > 0 ? (t.buildNotificationsList(e), t.notificationApiParams.startIndexOfNotifications = t.notificationApiParams.startIndexOfNotifications + t.notificationApiParams.pageSizeOfNotifications) : (t.notificationApiParams.loadMoreNotifications = !1, t.notificationApiParams.startIndexOfNotifications = 0), t.layout.isNotificationsLoading = !1
                                }), (function() {
                                    t.layout.notiticationsLazyLoadingEnabled = !1, i.debug("---error from get Notificaitons in lazyLoadingDirective.js---"), t.layout.isNotificationsLoading = !1
                                })))
                            }, t.setupScrollbar = function() {
                                n.mCustomScrollbar({
                                    autoExpandScrollbar: !1,
                                    scrollInertia: 5,
                                    contentTouchScroll: 1,
                                    mouseWheel: {
                                        preventDefault: !0
                                    },
                                    callbacks: {
                                        onTotalScrollOffset: 100,
                                        onTotalScroll: t.callbackLazyLoad,
                                        onOverflowYNone: t.callbackLazyLoad
                                    }
                                })
                            }, t.destroyScrollbar = function() {
                                i.debug("----- destroyScrollbar ----"), n.mCustomScrollbar("destroy")
                            };
                            var r = t.$watch((function() {
                                return t.layout && t.layout.isLazyLoadingRequested
                            }), (function(e, n) {
                                a().isDefined(e) && e !== n && (i.debug("----- initializeLayout ----"), e ? t.setupScrollbar() : t.destroyScrollbar())
                            }), !0);
                            t.$on("$destroy", (function() {
                                r && r()
                            }))
                        }
                    }
                }
                r.$inject = ["notificationStreamService", "$document", "$log"], o.Z.directive("lazyLoading", r), t.default = r
            },
            8367: function(e, t, i) {
                "use strict";
                i.r(t);
                var n = i(5734),
                    a = i.n(n),
                    o = i(2077);

                function r(e, t) {
                    var i = {
                            transition: "transitionend",
                            OTransition: "oTransitionEnd",
                            MozTransition: "transitionend",
                            WebkitTransition: "webkitTransitionEnd"
                        },
                        n = function() {
                            var e, t = document.createElement("supportedEvent");
                            for (e in i)
                                if (a().isDefined(t.style[e])) return i[e]
                        }();
                    return {
                        restrict: "A",
                        link: function(i, a, o) {
                            a.bind(n, (function(t) {
                                e.debug("got a css transition event", t), t.target.className.search("slide-out-left") >= 0 && i.$evalAsync((function() {
                                    i.removeNotification(i.notification.id)
                                }))
                            })), i.updateNotificationSetting = function(n) {
                                t.updateNotificationSettings(i.notification.notificationSourceType, n).then((function(t) {
                                    e.debug("turnOffNotification -- success", t), i.notification.isTurnOff = !n
                                }), (function(t) {
                                    e.debug("turnOffNotification --fail")
                                }))
                            }
                        }
                    }
                }
                r.$inject = ["$log", "notificationStreamService"], o.Z.directive("notificationCard", r), t.default = r
            },
            1964: function(e, t, i) {
                "use strict";
                i.r(t);
                var n = i(2077);

                function a(e, t) {
                    return {
                        restrict: "A",
                        replace: !0,
                        scope: !0,
                        templateUrl: e.templates.notificationContentTemplate
                    }
                }
                a.$inject = ["notificationStreamUtility", "$log"], n.Z.directive("notificationContent", a), t.default = a
            },
            3008: function(e, t, i) {
                "use strict";
                i.r(t);
                var n = i(2077);

                function a(e, t) {
                    return {
                        restrict: "A",
                        replace: !0,
                        transclude: !0,
                        templateUrl: e.templates.notificationContentViewTemplate,
                        scope: {
                            library: "=",
                            contentViewManager: "=",
                            viewId: "@",
                            isActive: "=?"
                        },
                        link: function(e, t, i) {
                            e.contentViewManager.addContentView(e)
                        }
                    }
                }
                a.$inject = ["notificationStreamUtility", "$log"], n.Z.directive("notificationContentView", a), t.default = a
            },
            6113: function(e, t, i) {
                "use strict";
                i.r(t);
                var n = i(2077);

                function a(e, t) {
                    return {
                        restrict: "A",
                        replace: !0,
                        scope: !0,
                        templateUrl: e.templates.notificationStreamBaseViewTemplate
                    }
                }
                a.$inject = ["notificationStreamUtility", "$log"], n.Z.directive("notificationStreamBase", a), t.default = a
            },
            131: function(e, t, i) {
                "use strict";
                i.r(t);
                var n = i(2077);

                function a(e, t) {
                    return {
                        restrict: "A",
                        replace: !0,
                        scope: !0,
                        templateUrl: e.templates.notificationStreamBaseViewTemplate
                    }
                }
                a.$inject = ["notificationStreamUtility", "$log"], n.Z.directive("notificationStreamBaseView", a), t.default = a
            },
            7968: function(e, t, i) {
                "use strict";
                i.r(t);
                var n = i(2077);

                function a(e, t) {
                    return {
                        restrict: "A",
                        replace: !0,
                        scope: !0,
                        link: function(i, n, a) {
                            e.on("click touchstart", (function(e) {
                                i.layout && (!i.layout.isStreamBodyInteracted && n.has(e.target).length > 0 ? i.layout.isStreamBodyInteracted = !0 : i.layout.isStreamBodyInteracted && !n.has(e.target).length > 0 && (i.layout.isStreamBodyInteracted = !1), t.debug(" ------------------scope.layout.isStreamBodyInteracted----------------- " + i.layout.isStreamBodyInteracted))
                            }))
                        }
                    }
                }
                a.$inject = ["$document", "$log"], n.Z.directive("notificationStreamBody", a), t.default = a
            },
            3672: function(e, t, i) {
                "use strict";
                i.r(t);
                var n = i(2077);

                function a(e, t) {
                    return {
                        restrict: "A",
                        replace: !0,
                        scope: !0,
                        templateUrl: e.templates.notificationStreamContainerTemplate
                    }
                }
                a.$inject = ["notificationStreamUtility", "$log"], n.Z.directive("notificationStreamContainer", a), t.default = a
            },
            9273: function(e, t, i) {
                "use strict";
                i.r(t);
                var n = i(792),
                    a = i(2077);

                function o(e, t, i) {
                    return {
                        restrict: "A",
                        replace: !0,
                        scope: {
                            notification: "=",
                            appMeta: "=",
                            library: "=",
                            layout: "=",
                            interactNotification: "&"
                        },
                        templateUrl: e.templates.privateMessageTemplate,
                        link: function(t, a, o) {
                            ! function() {
                                t.thumbnailTypes = i.thumbnailTypes, t.notificationSourceType = e.notificationSourceType, t.friendRequestLink = e.layout.friendRequestLink, t.privateMessageLayout = {
                                    displayUserId: null,
                                    displayUserName: "",
                                    messagePreview: "",
                                    isStacked: !1
                                };
                                var a = t.notification.metadataCollection,
                                    o = t.notification.notificationSourceType;
                                if ((t.notification.eventCount > 1 || a && 0 === a.length) && (t.privateMessageLayout.isStacked = !0), a && a.length > 0) {
                                    var r = e.normalizeUser(o, a[0]);
                                    t.privateMessageLayout.displayUserId = r.userId, t.privateMessageLayout.displayUserName = n.DisplayNames && n.DisplayNames.Enabled() ? r.displayName : r.userName, t.privateMessageLayout.messagePreview = a[0].BodyPreview
                                }
                            }()
                        }
                    }
                }
                o.$inject = ["notificationStreamUtility", "$log", "thumbnailConstants"], a.Z.directive("privateMessage", o), t.default = o
            },
            1841: function(e, t, i) {
                "use strict";
                i.r(t);
                var n = i(792);

                function a() {
                    return {
                        restrict: "A",
                        link: function(e, t) {
                            t.ready((function() {
                                null === n.NotificationStreamService || void 0 === n.NotificationStreamService || n.NotificationStreamService.renderSendrModalContainer(t[0])
                            }))
                        }
                    }
                }
                i(2077).Z.directive("sendrMetaActionsList", a), t.default = a
            },
            1265: function(e, t, i) {
                "use strict";
                i.r(t);
                var n = i(792);

                function a() {
                    return {
                        restrict: "A",
                        link: function(e, t) {
                            t.ready((function() {
                                null === n.NotificationStreamService || void 0 === n.NotificationStreamService || n.NotificationStreamService.renderSendrNotification(t[0])
                            }))
                        }
                    }
                }
                i(2077).Z.directive("sendrNotification", a), t.default = a
            },
            329: function(e, t, i) {
                "use strict";
                i.r(t);
                var n = i(2077);

                function a(e, t) {
                    return {
                        restrict: "A",
                        replace: !0,
                        scope: !0,
                        templateUrl: e.templates.testTemplate,
                        link: function(e, t, i) {
                            var n = e.notification.metadataCollection;
                            e.notificationDisplayText = "", n.forEach((function(t) {
                                e.notificationDisplayText += t.Detail
                            }))
                        }
                    }
                }
                a.$inject = ["notificationStreamUtility", "$log"], n.Z.directive("test", a), t.default = a
            },
            6097: function(e, t, i) {
                "use strict";
                i.r(t);
                var n = i(2077);

                function a(e) {
                    return function(t) {
                        return e.sortGameUpdatesByCreatedDate(t, !1)
                    }
                }
                a.$inject = ["gameUpdatesUtility"], n.Z.filter("sortGameUpdates", a), t.default = a
            },
            2900: function(e, t, i) {
                "use strict";
                i.r(t);
                var n = i(2077);

                function a(e) {
                    return function(t) {
                        return e.sortNotificationsByEventDate(t, !1)
                    }
                }
                a.$inject = ["notificationStreamUtility"], n.Z.filter("sortNotificationsByEventDateDesc", a), t.default = a
            },
            2077: function(e, t, i) {
                "use strict";
                var n = i(792),
                    a = i(5734),
                    o = i.n(a)().module("notificationStream", ["robloxApp", "ui.bootstrap", "notificationStreamHtmlTemplate", "thumbnails"]).config(["languageResourceProvider", function(e) {
                        var t = (new n.TranslationResourceProvider).getTranslationResource("Notifications.NotificationStream");
                        e.setTranslationResources([t])
                    }]);
                t.Z = o
            },
            6009: function(e, t, i) {
                "use strict";
                i.r(t);
                var n = i(792),
                    a = i(5734),
                    o = i.n(a),
                    r = i(2077);

                function c(e, t, i, a, r, c) {
                    var s = r.endpoints,
                        l = r.apiParams;

                    function u(i, n, a, o) {
                        var r, c, s = [],
                            l = 0;
                        for (c = n.slice(l, a); c.length > 0 && l < n.length;) r = o(c), s.push(e.httpGet(i, r)), l += a, c = n.slice(l, l + a);
                        return t.all(s)
                    }
                    return {
                        markGameUpdateReadAsync: function(t, i, n) {
                            var a = s.getReadEndpoint(),
                                o = {
                                    universeId: t,
                                    createdOn: i.toString(),
                                    currentUserId: n
                                };
                            return e.httpPost(a, o)
                        },
                        markGameUpdateInteractedAsync: function(t, i, n, a) {
                            var o = s.getInteractedEndpoint(),
                                r = {
                                    universeId: t,
                                    createdOnKey: i,
                                    interactionType: n,
                                    currentUserId: a
                                };
                            return e.httpPost(o, r)
                        },
                        multiGetPlaceDetailsAsync: function(e) {
                            return e && 0 !== e.length ? function(e) {
                                return u(s.getGameDetailsEndpoint(), e, l.placeDetailBatchSize, (function(e) {
                                    return {
                                        placeIds: e
                                    }
                                })).then((function(e) {
                                    var t = {};
                                    return e && 0 !== e.length ? (o().forEach(e, (function(e) {
                                        e && o().forEach(e, (function(e) {
                                            t[e.placeId] = {
                                                universeId: e.universeId,
                                                isPlayable: e.isPlayable,
                                                imageToken: e.imageToken
                                            }
                                        }))
                                    })), t) : null
                                }))
                            }(e) : t((function(e, t) {
                                e(null)
                            }))
                        },
                        multiGetGameUpdatesAsync: function(e, i) {
                            return e && 0 !== e.length ? function(e, t) {
                                return u(s.getGameUpdatesEndpoint(), e, l.gameUpdateBatchSize, (function(e) {
                                    return {
                                        universeIds: e
                                    }
                                })).then((function(e) {
                                    var t = [];
                                    return e && 0 !== e.length ? (o().forEach(e, (function(e) {
                                        e && o().forEach(e, (function(e) {
                                            t.push(e)
                                        }))
                                    })), t) : null
                                }))
                            }(e) : t((function(e, t) {
                                e(null)
                            }))
                        },
                        getGameFollowingsForUserAsync: function(t) {
                            var i = s.getGameFollowingsEndpoint(t);
                            return e.httpGet(i, {})
                        },
                        followGameAsync: function(t, i) {
                            var n = s.getFollowGameEndpoint(t, i);
                            return e.httpPost(n, {})
                        },
                        unfollowGameAsync: function(t, i) {
                            var n = s.getFollowGameEndpoint(t, i);
                            return e.httpDelete(n, {})
                        },
                        reportAbuse: function(e, t) {
                            var i = a.getAbsoluteUrl(s.getAbuseReportUrl(e, t, encodeURIComponent(c.location.href)));
                            n.AbuseReportDispatcher ? n.AbuseReportDispatcher.triggerUrlAction(i) : c.location.href = i
                        }
                    }
                }
                c.$inject = ["httpService", "$q", "$log", "urlService", "gameUpdatesConstants", "$window"], r.Z.factory("gameUpdatesService", c), t.default = c
            },
            4298: function(e, t, i) {
                "use strict";
                i.r(t);
                var n = i(5734),
                    a = i.n(n),
                    o = i(2077);

                function r(e, t, i, n, o, r) {
                    var c = n.parseEpochMilliseconds,
                        s = r.gameNameMaxLength;
                    return {
                        formatAggregatedDisplayText: function(e, t, i) {
                            return 0 === i ? o.gameUpdates.formatDisplayTextDouble(e, t) : o.gameUpdates.formatDisplayTextMultiple(e, t, i)
                        },
                        getGameUpdatesAsync: function(i, n, a) {
                            return e.multiGetGameUpdatesAsync(i, a ? new Date(a.getTime() - 6e4) : null).then((function(e) {
                                var i, a, o, r, l, u;
                                if (!e || 0 === e.length) return null;
                                for (i = 0; i < e.length; i++) a = e[i], r = c(a.createdOn), n.hasOwnProperty(a.universeId) ? ((o = n[a.universeId]).updateMessage = a.content, o.createdOn = r, o.createdOnKey = a.createdOnKey) : n[a.universeId] = {
                                    universeId: a.universeId,
                                    rootPlaceId: a.rootPlaceId,
                                    updateMessage: a.content,
                                    createdOn: r,
                                    createdOnKey: a.createdOnKey,
                                    gameName: a.universeName,
                                    truncatedGameName: (l = a.universeName, u = void 0, u = l, l && l.length > s && (u = "".concat(l.substr(0, s - 3), "...")), u),
                                    isPlayable: null,
                                    gameLinkUrl: a.rootPlaceId ? t.getAbsoluteUrl("/games/".concat(a.rootPlaceId, "?originatorType=GameUpdateNotification&originatorId=").concat(r)) : null,
                                    gameLinkUrlForApp: a.rootPlaceId ? "games/".concat(a.rootPlaceId, "?originatorType=GameUpdateNotification&originatorId=").concat(r) : null
                                };
                                return e
                            }))
                        },
                        fillGameDetails: function(t) {
                            var i, n, o = [];
                            for (i in t) t.hasOwnProperty(i) && null === (n = t[i]).isPlayable && o.push(n.rootPlaceId);
                            0 !== o.length && e.multiGetPlaceDetailsAsync(o).then((function(e) {
                                if (e) return a().forEach(e, (function(e, i) {
                                    var n = t[e.universeId];
                                    n && (n.isPlayable = e.isPlayable)
                                })), e
                            }))
                        },
                        aggregateGameUpdateNotifications: function(e, t) {
                            if (!e || 0 === e.length) return null;
                            var i = null,
                                n = null,
                                o = null,
                                r = 0,
                                s = {},
                                l = {};
                            return l.id = e[0].id, l.notificationSourceType = e[0].notificationSourceType, l.metadataCollection = [], a().forEach(e, (function(e) {
                                var u;
                                e.eventDate && (u = c(e.eventDate), (!i || i < u) && (i = u, o = e.eventDate), (!n || n > u) && (n = u)), a().forEach(e.metadataCollection, (function(e) {
                                    t.hasOwnProperty(e.UniverseId) && !s.hasOwnProperty(e.UniverseId) && (l.metadataCollection.push(e), s[e.UniverseId] = !0)
                                })), e.eventCount && (r += e.eventCount)
                            })), l.eventDate = o, l.minEventDate = new Date(n), l.eventCount = Math.max(r, l.metadataCollection.length), l.metadataCollection.length > 0 ? l : null
                        },
                        sortGameUpdatesByCreatedDate: function(e, t) {
                            if (!e) return null;
                            var i = Object.keys(e).map((function(t) {
                                return e[t]
                            }));
                            return i.sort((function(e, i) {
                                return t ? e.createdOn - i.createdOn : i.createdOn - e.createdOn
                            })), i
                        }
                    }
                }
                r.$inject = ["gameUpdatesService", "urlService", "$log", "notificationStreamUtility", "layoutLibraryService", "gameUpdatesConstants"], o.Z.factory("gameUpdatesUtility", r), t.default = r
            },
            5078: function(e, t, i) {
                "use strict";
                i.r(t);
                var n = i(2077);

                function a(e, t) {
                    var i = t;
                    return {
                        links: {
                            profileLinkName: "goToProfilePage",
                            profileLink: "/users/{id}/profile",
                            friendRequestLinkName: "viewAllFriendRequests",
                            friendRequestTabName: "Friends",
                            friendRequestLink: "/users/friends#!/friend-requests",
                            settingLinkName: "goToSettingPage",
                            settingTabName: "Settings",
                            settingLink: "/my/account#!/notifications",
                            friendsTabName: "Friends",
                            friendsLink: "/users/friends",
                            inboxTabName: "Messages",
                            inboxLink: "/my/messages/#!/inbox",
                            inboxMessageDetailQuery: "?conversationId=",
                            groupLinkName: "goToGroupPage",
                            groupLink: "/groups/{id}",
                            myGroupsLink: "/my/groups"
                        },
                        stringTemplates: {
                            boldLink: "<a class='font-caption-header'>{username}</a>",
                            userLink: "<a class='text-name small font-caption-header' type='goToProfilePage' user_id='{userid}' href='{profilelink}'>{username}</a>",
                            boldDisplayNameLink: "<a class='font-caption-header'>{displayname}</a>",
                            displayNameLink: "<span class='cursor-pointer text-name paired-name'><a class='element small text-emphasis' type='goToProfilePage' user_id='{userid}' href='{profilelink}'>{displayname}</a><span class='text-emphasis small connector'>@</span><span class='small element'>{username}</span></span>",
                            groupLink: "<a class='text-name small font-caption-header' type='goToGroupPage' group_id='{groupid}' href='{grouplink}'>{groupname}</a>"
                        },
                        newFriendRequests: function(e) {
                            return i.get("Message.YouHaveNewFriendRequests", {
                                numberOfRequests: e
                            })
                        },
                        newFriends: function(e) {
                            return i.get("Message.YouHaveNewFriends", {
                                numberOfFriends: e
                            })
                        },
                        newGroups: function(e) {
                            return i.get("Message.YouHaveBeenAcceptedToNewGroups", {
                                numberOfGroups: e
                            })
                        },
                        friendRequestAcceptedSingle: function(e) {
                            return i.get("Message.FriendRequestAcceptedSingle", {
                                userOne: e
                            })
                        },
                        friendRequestAcceptedDouble: function(e, t) {
                            return i.get("Message.FriendRequestAcceptedDouble", {
                                userOne: e,
                                userTwo: t
                            })
                        },
                        friendRequestAcceptedMultiple: function(e, t, n) {
                            return i.get("Message.FriendRequestAcceptedMultiple", {
                                userOne: e,
                                userTwo: t,
                                userMultipleCount: n
                            })
                        },
                        groupJoinRequestAcceptedSingle: function(e) {
                            return i.get("Message.GroupJoinRequestAcceptedSingle", {
                                groupOne: e
                            })
                        },
                        groupJoinRequestAcceptedDouble: function(e, t) {
                            return i.get("Message.GroupJoinRequestAcceptedDouble", {
                                groupOne: e,
                                groupTwo: t
                            })
                        },
                        groupJoinRequestAcceptedMultiple: function(e, t, n) {
                            return i.get("Message.GroupJoinRequestAcceptedMultiple", {
                                groupOne: e,
                                groupTwo: t,
                                groupMultipleCount: n
                            })
                        },
                        friendRequestSentSingle: function(e) {
                            return i.get("Message.FriendRequestSentSingle", {
                                userOne: e
                            })
                        },
                        friendRequestSentDouble: function(e, t) {
                            return i.get("Message.FriendRequestSentDouble", {
                                userOne: e,
                                userTwo: t
                            })
                        },
                        friendRequestSentMultiple: function(e, t, n) {
                            return i.get("Message.FriendRequestSentMultiple", {
                                userOne: e,
                                userTwo: t,
                                userMultipleCount: n
                            })
                        },
                        confirmAcceptedSingle: function(e) {
                            return i.get("Message.ConfirmAcceptedSingle", {
                                userOne: e
                            })
                        },
                        confirmAcceptedDouble: function(e, t) {
                            return i.get("Message.ConfirmAcceptedDouble", {
                                userOne: e,
                                userTwo: t
                            })
                        },
                        confirmAcceptedMultiple: function(e, t, n) {
                            return i.get("Message.ConfirmAcceptedMultiple", {
                                userOne: e,
                                userTwo: t,
                                userMultipleCount: n
                            })
                        },
                        confirmSentSingle: function(e) {
                            return i.get("Message.ConfirmSentSingle", {
                                userOne: e
                            })
                        },
                        confirmSentDouble: function(e, t) {
                            return i.get("Message.ConfirmSentDouble", {
                                userOne: e,
                                userTwo: t
                            })
                        },
                        confirmSentMultiple: function(e, t, n) {
                            return i.get("Message.ConfirmSentMultiple", {
                                userOne: e,
                                userTwo: t,
                                userMultipleCount: n
                            })
                        },
                        textTemplate: {
                            newNotification: function(e) {
                                return i.get("Message.NumberofNewNotifications", {
                                    notificationCount: e
                                })
                            },
                            noNetworkConnectionText: function() {
                                return i.get("Label.NoNetworkConnectionText")
                            }
                        },
                        friendRequestActionType: {
                            acceptIgnoreBtns: "AcceptIgnoreBtns",
                            chatBtn: "chatBtn",
                            viewAllBtn: "ViewAllBtn"
                        },
                        directiveTemplatesName: {
                            notificationIndicatorTemplate: "notification-indicator",
                            notificationStreamIndicatorTemplate: "notification-stream-indicator",
                            notificationContentTemplate: "notification-content",
                            friendRequestReceivedTemplate: "friend-request-received",
                            friendRequestAcceptedTemplate: "friend-request-accepted",
                            friendRequestTemplate: "friend-request",
                            privateMessageTemplate: "private-message",
                            developerMetricsAvailableTemplate: "developer-metrics-available",
                            testTemplate: "test",
                            newGameUpdateTemplate: "new-game-update-template",
                            notificationStreamBaseTemplate: "notification-stream-base",
                            notificationStreamIconTemplate: "notification-stream-icon",
                            notificationContentViewTemplate: "notification-content-view-template",
                            gameUpdateTemplate: "game-update-template",
                            gameUpdateActionPopoverTemplate: "game-update-action-popover-template",
                            groupMembershipTemplate: "group-membership",
                            notificationStreamBaseViewTemplate: "notification-stream-base-view",
                            notificationStreamContainerTemplate: "notification-stream-container"
                        },
                        notificationSourceType: {
                            test: "Test",
                            friendRequestReceived: "FriendRequestReceived",
                            friendRequestAccepted: "FriendRequestAccepted",
                            privateMessageReceived: "PrivateMessageReceived",
                            developerMetricsAvailable: "DeveloperMetricsAvailable",
                            gameUpdate: "GameUpdate",
                            groupJoinRequestAccepted: "GroupJoinRequestAccepted",
                            sendr: "Sendr",
                            sendrBundle: "SendrBundle"
                        },
                        gameUpdates: {
                            formatDisplayTextDouble: function(e, t) {
                                return i.get("Message.AggregatedGameUpdateDouble", {
                                    gameOne: "<span class='font-caption-header'>".concat(e, "</span>"),
                                    gameTwo: "<span class='font-caption-header'>".concat(t, "</span>")
                                })
                            },
                            formatDisplayTextMultiple: function(e, t, n) {
                                return i.get("Message.AggregatedGameUpdateMultiple", {
                                    gameOne: "<span class='font-caption-header'>".concat(e, "</span>"),
                                    gameTwo: "<span class='font-caption-header'>".concat(t, "</span>"),
                                    otherCount: n
                                })
                            }
                        }
                    }
                }
                a.$inject = ["$log", "languageResource"], n.Z.factory("layoutLibraryService", a), t.default = a
            },
            8892: function(e, t, i) {
                "use strict";
                i.r(t);
                var n = i(792),
                    a = i(2077);

                function o(e, t, i) {
                    var a = n.EnvironmentUrls.notificationApi,
                        o = n.EnvironmentUrls.friendsApi;
                    return {
                        endpoints: {
                            initializeData: {
                                url: "".concat(a, "/v2/stream-notifications/metadata"),
                                retryable: !0
                            },
                            unreadCount: {
                                url: "".concat(a, "/v2/stream-notifications/unread-count"),
                                retryable: !0,
                                withCredentials: !0
                            },
                            getRecent: {
                                url: "".concat(a, "/v2/stream-notifications/get-recent"),
                                retryable: !0,
                                withCredentials: !0
                            },
                            clearUnread: {
                                url: "".concat(a, "/v2/stream-notifications/clear-unread"),
                                retryable: !1,
                                withCredentials: !0
                            },
                            markInteracted: {
                                url: "".concat(a, "/v2/stream-notifications/mark-interacted"),
                                retryable: !1,
                                withCredentials: !0
                            },
                            updateNotificationSettings: {
                                url: "".concat(a, "/v2/notifications/update-notification-settings"),
                                retryable: !1,
                                withCredentials: !0
                            },
                            getAccountSettingsPolicy: {
                                url: "".concat(n.EnvironmentUrls.universalAppConfigurationApi, "/v1/behaviors/account-settings-ui/content"),
                                withCredentials: !0,
                                noCache: !1
                            }
                        },
                        initialize: function() {
                            return e.httpGet(this.endpoints.initializeData, {})
                        },
                        getAccountSettingsPolicy: function() {
                            return e.httpGet(this.endpoints.getAccountSettingsPolicy, {})
                        },
                        unreadCount: function() {
                            return e.httpGet(this.endpoints.unreadCount, {})
                        },
                        clearUnread: function() {
                            return e.httpPost(this.endpoints.clearUnread, {})
                        },
                        getRecentNotifications: function(t, i) {
                            var n = {
                                startIndex: t,
                                maxRows: i
                            };
                            return e.httpGet(this.endpoints.getRecent, n)
                        },
                        markInteracted: function(t) {
                            var i = {
                                eventId: t
                            };
                            return e.httpPost(this.endpoints.markInteracted, i)
                        },
                        acceptFriendV2: function(t) {
                            var i = {
                                url: "".concat(o, "/v1/users/").concat(t, "/accept-friend-request"),
                                withCredentials: !0
                            };
                            return e.httpPost(i)
                        },
                        ignoreFriendV2: function(t) {
                            var i = {
                                url: "".concat(o, "/v1/users/").concat(t, "/decline-friend-request"),
                                withCredentials: !0
                            };
                            return e.httpPost(i)
                        },
                        updateNotificationSettings: function(t, i) {
                            var n = {
                                    notificationSourceType: t,
                                    receiverDestinationType: "NotificationStream",
                                    isEnabled: i
                                },
                                a = [];
                            return a.push(n), e.httpPost(this.endpoints.updateNotificationSettings, a)
                        }
                    }
                }
                o.$inject = ["httpService", "$log", "urlService"], a.Z.factory("notificationStreamService", o), t.default = o
            },
            1294: function(e, t, i) {
                "use strict";
                i.r(t), i.d(t, {
                    default: function() {
                        return l
                    }
                });
                var n = i(792),
                    a = HeaderScripts,
                    o = i(5734),
                    r = i.n(o),
                    c = i(2077);

                function s(e, t, i) {
                    var o = t.notificationSourceType,
                        c = t.links,
                        s = t.stringTemplates;

                    function l(e) {
                        if (!e) return null;
                        if (e.getTime) return e.getTime();
                        if ("string" == typeof e) {
                            var t = /Date\((\d+)\)/.exec(e);
                            return t ? parseInt(t[1]) : new Date(e).getTime() || null
                        }
                        return null
                    }
                    return {
                        templates: t.directiveTemplatesName,
                        links: c,
                        textTemplate: t.textTemplate,
                        stringTemplates: s,
                        layout: {
                            pageDataInitialized: !1,
                            firstTimeNotificationStream: !1,
                            getRecentDataInitialized: !1,
                            isNotificationContentOpen: !1,
                            isLazyLoadingRequested: !1,
                            isGetRecentDataLoadedRequested: !0,
                            notificationsScrollbarSelector: "#notification-stream-scrollbar",
                            settingLink: n.Endpoints ? n.Endpoints.getAbsoluteUrl(c.settingLink) : c.settingLink,
                            groupLink: n.Endpoints ? n.Endpoints.getAbsoluteUrl(c.groupLink) : c.groupLink,
                            friendRequestLink: n.Endpoints ? n.Endpoints.getAbsoluteUrl(c.friendRequestLink) : c.friendRequestLink,
                            bannerEnabled: !1,
                            emptyNotificationEnabled: !1,
                            notificationsLazyLoadingEnabled: !1,
                            isNotificationsLoading: !1,
                            isStreamBodyInteracted: !1,
                            isDisplayNamesEnabled: n.DisplayNames && n.DisplayNames.Enabled(),
                            bannerText: "",
                            errorText: "",
                            dataBindSelector: "#notification-stream",
                            dataContainerSelector: "#notification-stream-container"
                        },
                        notificationApiParams: {
                            startIndexOfNotifications: 0,
                            pageSizeOfNotifications: 20,
                            loadMoreNotifications: !1
                        },
                        library: {
                            unreadNotifications: 0,
                            userIdList: [],
                            userLibrary: {},
                            prefixLocalStoragekey: "user_",
                            inApp: !!n.DeviceMeta && (0, n.DeviceMeta)().isInApp,
                            isPhone: !!n.DeviceMeta && (0, n.DeviceMeta)().isPhone,
                            isTouch: !!n.DeviceFeatureDetection && n.DeviceFeatureDetection.isTouch,
                            eventStreamMetaData: {},
                            gameUpdateModels: {},
                            notificationContentViews: {
                                main: "main",
                                gameUpdates: "gameUpdates"
                            },
                            canLaunchGameFromGameUpdate: !1,
                            currentUserId: a.authenticatedUser.id
                        },
                        notificationsName: e.notifications,
                        notificationSourceType: o,
                        signalRType: e.types,
                        friendRequestReceivedLayout: t.friendRequestReceivedLayout,
                        friendRequestAcceptedLayout: t.friendRequestAcceptedLayout,
                        friendRequestActionType: t.friendRequestActionType,
                        getAbsoluteUrl: function(e, t) {
                            return n.Endpoints ? n.Endpoints.generateAbsoluteUrl(e, t, !0) : getFormatString(e, t)
                        },
                        getFormatString: function(e, t) {
                            for (var i in t) {
                                var n = t[i],
                                    a = new RegExp("{".concat(i.toLowerCase(), "(:.*?)?\\??}"));
                                e = e.replace(a, n)
                            }
                            return e
                        },
                        isNotificationTypeValid: function(e) {
                            var t = !1;
                            for (var i in o)
                                if (o[i] === e) {
                                    t = !0;
                                    break
                                }
                            return t
                        },
                        isCardClickable: function(e) {
                            switch (e.notificationSourceType) {
                                case o.friendRequestAccepted:
                                    return e.eventCount > 1 || 1 === e.eventCount && 0 === e.metadataCollection.length;
                                case o.privateMessageReceived:
                                case o.developerMetricsAvailable:
                                case o.groupJoinRequestAccepted:
                                    return !0
                            }
                            return !1
                        },
                        normalizeUser: function(e, t) {
                            var i = {
                                userId: null,
                                userName: null,
                                displayName: null
                            };
                            switch (e) {
                                case o.friendRequestReceived:
                                    i.userId = t.SenderUserId, i.userName = t.SenderUserName, i.displayName = t.SenderDisplayName;
                                    break;
                                case o.friendRequestAccepted:
                                    i.userId = t.AccepterUserId, i.userName = t.AccepterUserName, i.displayName = t.AccepterDisplayName;
                                    break;
                                case o.privateMessageReceived:
                                    i.userId = t.AuthorUserId, i.userName = t.AuthorUserName, i.displayName = t.AuthorDisplayName;
                                    break;
                                case o.developerMetricsAvailable:
                                case o.test:
                            }
                            return i
                        },
                        getUserHtmlTemplate: function(e, t) {
                            var i = "",
                                a = n.DisplayNames && n.DisplayNames.Enabled();
                            switch (e) {
                                case o.friendRequestAccepted:
                                    i = t > 1 ? a ? s.boldDisplayNameLink : s.boldLink : a ? s.displayNameLink : s.userLink;
                                    break;
                                case o.friendRequestReceived:
                                default:
                                    i = a ? s.displayNameLink : s.userLink
                            }
                            return i
                        },
                        getGroupHtmlTemplate: function() {
                            return s.groupLink
                        },
                        normalizeYouHaveText: function(e, i) {
                            switch (e) {
                                case o.friendRequestReceived:
                                    return t.newFriendRequests(i);
                                case o.friendRequestAccepted:
                                    return t.newFriends(i);
                                case o.groupJoinRequestAccepted:
                                    return t.newGroups(i);
                                default:
                                    return ""
                            }
                        },
                        normalizeSingleDisplayText: function(e, i) {
                            switch (e) {
                                case o.friendRequestReceived:
                                    return t.friendRequestSentSingle(i);
                                case o.friendRequestAccepted:
                                    return t.friendRequestAcceptedSingle(i);
                                case o.groupJoinRequestAccepted:
                                    return t.groupJoinRequestAcceptedSingle(i);
                                default:
                                    return ""
                            }
                        },
                        normalizeSingleConfirmedText: function(e, i) {
                            switch (e) {
                                case o.friendRequestReceived:
                                    return t.confirmSentSingle(i);
                                case o.friendRequestAccepted:
                                    return t.confirmAcceptedSingle(i);
                                default:
                                    return ""
                            }
                        },
                        normalizeDoubleDisplayText: function(e, i, n) {
                            switch (e) {
                                case o.friendRequestReceived:
                                    return t.friendRequestSentDouble(i, n);
                                case o.friendRequestAccepted:
                                    return t.friendRequestAcceptedDouble(i, n);
                                case o.groupJoinRequestAccepted:
                                    return t.groupJoinRequestAcceptedDouble(i, n);
                                default:
                                    return ""
                            }
                        },
                        normalizeDoubleConfirmedText: function(e, i, n) {
                            switch (e) {
                                case o.friendRequestReceived:
                                    return t.confirmSentDouble(i, n);
                                case o.friendRequestAccepted:
                                    return t.confirmAcceptedDouble(i, n);
                                default:
                                    return ""
                            }
                        },
                        normalizeMultipleDisplayText: function(e, i, n, a) {
                            switch (e) {
                                case o.friendRequestReceived:
                                    return t.friendRequestSentMultiple(i, n, a);
                                case o.friendRequestAccepted:
                                    return t.friendRequestAcceptedMultiple(i, n, a);
                                case o.groupJoinRequestAccepted:
                                    return t.groupJoinRequestAcceptedMultiple(i, n, a);
                                default:
                                    return ""
                            }
                        },
                        normalizeMultipleConfirmedText: function(e, i, n, a) {
                            switch (e) {
                                case o.friendRequestReceived:
                                    return t.confirmSentMultiple(i, n, a);
                                case o.friendRequestAccepted:
                                    return t.confirmAcceptedMultiple(i, n, a);
                                default:
                                    return ""
                            }
                        },
                        buildScrollbar: function(e) {
                            r().element(e).mCustomScrollbar({
                                autoHideScrollbar: !1,
                                autoExpandScrollbar: !1,
                                contentTouchScroll: 1e4,
                                documentTouchScroll: !1,
                                mouseWheel: {
                                    preventDefault: !0
                                },
                                advanced: {
                                    autoScrollOnFocus: !1
                                }
                            })
                        },
                        isGameUpdateNotification: function(e) {
                            return e === o.gameUpdate
                        },
                        isReactNotification: function(e) {
                            return e === o.sendr || e === o.sendrBundle
                        },
                        parseEpochMilliseconds: l,
                        sortNotificationsByEventDate: function(e, t) {
                            if (!e) return null;
                            var i = Object.keys(e).map((function(t) {
                                return e[t]
                            }));
                            return i.sort((function(e, i) {
                                var n = l(e.eventDate) || 0,
                                    a = l(i.eventDate) || 0;
                                return t ? n - a : a - n
                            })), i
                        }
                    }
                }
                s.$inject = ["signalR", "layoutLibraryService", "$log"], c.Z.factory("notificationStreamUtility", s);
                var l = s
            },
            7359: function(e) {
                e.exports = ' <a id="nav-ns-icon" class="roblox-popover rbx-menu-item notification-stream-icon" data-bind="notification-stream-base" data-container="notification-stream-container"> <span class="icon-nav-notification-stream" id="nav-notifications"></span> <span class="notification-red notification" ng-show="layout.unreadNotifications > 0 && (!layout.isNotificationContentOpen)"> {{layout.unreadNotifications | abbreivateCount}} </span> </a>'
            },
            632: function(e) {
                e.exports = '<div class="notification-stream" ng-class="{\'inApp\': library.inApp}"> <div notification-indicator></div> </div>'
            },
            539: function(e) {
                e.exports = '<div class="notification-stream-indicator" ng-class="{\'inApp\': library.inApp}"> <a id="nav-ns-icon" class="rbx-menu-item notification-stream-icon"> <span class="icon-common-notification-bell" id="common-notification-bell"></span> <span class="notification-red notification bell-red-badge" id="notifications-bell-badge" ng-show="layout.unreadNotifications > 0"> {{layout.unreadNotifications | abbreivateCount}} </span> </a> </div>'
            },
            2175: function(e) {
                e.exports = '<div class="developer-metrics-notification-container"> <div class="notification-content-container"> <div class="notification-image-container"> <div title="{{developerMetricsAvailableLayout.gameName}}"> <a class="text-name font-caption-header" ng-href="{{developerMetricsAvailableLayout.gameLinkUrl}}" click-in-card type="viewDeveloperMetrics" onclick="event.stopPropagation()"> <thumbnail-2d class="notification-icon" thumbnail-target-id="developerMetricsAvailableLayout.universeId" thumbnail-type="thumbnailTypes.gameIcon"> </thumbnail-2d> </a> </div> </div> <div class="notification-item-content"> <div class="notification-data-container"> <span class="small text notification-display-text" ng-bind-html="\'Message.DeveloperMetricsAvailable\' | translate:developerMetricsAvailableLayout"> </span> <div class="text-date-hint"> {{notification.eventDate | datetime: \'full\'}} </div> </div> </div> <div class="notification-action-container"> <button class="view-button btn-primary-xs font-caption-header" ng-class="{\'btn-full-width\': library.isPhone }" ng-click="viewButtonHandler()" ng-bind="\'Action.View\' | translate"></button> </div> </div> </div>'
            },
            6511: function(e) {
                e.exports = '<div> <div> <div class="notification-item-front"> <div class="notification-content-container"> <div class="notification-image-container"> <div class="avatar avatar-headshot-sm" ng-if="userIds.length >= 1" title="{{library.userLibrary[userIds[0]].name}}"> <a ng-href="{{library.userLibrary[userIds[0]].profileLink}}" type="goToProfilePage" user_id="{{userIds[0]}}" click-in-card> <thumbnail-2d class="avatar-card-image" thumbnail-target-id="userIds[0]" thumbnail-type="thumbnailTypes.avatarHeadshot"> </thumbnail-2d> </a> </div> <span class="icon-nav-group notification-image-placeholder" ng-if="!userIds || userIds.length == 0"></span> </div> <div class="notification-item-content"> <div class="notification-data-container font-caption-body"> <span class="small text notification-display-text" click-in-card ng-hide="notification.metadataCollection[0].IsAccepted" ng-bind-html="notificationDisplayText"></span> <span class="small text notification-display-text" click-in-card ng-show="notification.metadataCollection[0].IsAccepted" ng-bind-html="requestConfirmedText"></span> <div class="text-date-hint" ng-bind="notification.eventDate | datetime: \'full\'"></div> </div> </div> </div> <div class="notification-action-container" ng-show="(notification.friendRequestActionType ===\r\n                        friendRequestActionType.acceptIgnoreBtns) ||\r\n                        (notification.friendRequestActionType ===\r\n                        friendRequestActionType.chatBtn) || (notification.friendRequestActionType === friendRequestActionType.viewAllBtn)"> <button class="btn-control-xs font-caption-header btn-min-width" id="ignore-fr-btn" ng-show="notification.friendRequestActionType === friendRequestActionType.acceptIgnoreBtns" ng-click="ignoreFriend({targetUserId: userIds[0], notificationId: notification.id, event: $event})" ng-bind="\'Action.Ignore\' | translate"></button> <button class="btn-primary-xs font-caption-header btn-min-width" id="accept-fr-btn" ng-show="notification.friendRequestActionType === friendRequestActionType.acceptIgnoreBtns" ng-click="acceptFriend({targetUserId: userIds[0], notificationId: notification.id, event: $event})" ng-bind="\'Action.Accept\' | translate"></button> <button class="btn-primary-xs roblox-popover-close font-caption-header btn-min-width" id="chat-btn" ng-class="{\'btn-full-width\': library.isPhone}" ng-show="notification.friendRequestActionType === friendRequestActionType.chatBtn" ng-click="chat({friendId: userIds[0], notificationId: notification.id, event: $event})" ng-bind="\'Action.Chat\' | translate"></button> <a class="btn-secondary-xs font-caption-header btn-min-width btn-full-width" id="view-all-btn" ng-show="notification.friendRequestActionType === friendRequestActionType.viewAllBtn" click-in-card type="viewAllFriendRequests" ng-href="{{friendRequestLink}}"><span ng-bind="\'Action.ViewAll\' | translate"></span></a> </div> </div> <div class="notification-item-back"> <div class="notification-content-container"> <div class="notification-image-container"> <div class="avatar avatar-headshot-sm" ng-if="userIds.length >= 1" title="{{library.userLibrary[userIds[0]].name}}"> <a ng-href="{{library.userLibrary[userIds[0]].profileLink}}" type="goToProfilePage" user_id="{{userIds[0]}}" click-in-card> <thumbnail-2d class="avatar-card-image" thumbnail-target-id="userIds[0]" thumbnail-type="thumbnailTypes.avatarHeadshot"> </thumbnail-2d> </a> </div> <span class="icon-nav-group notification-image-placeholder" ng-if="!userIds || userIds.length == 0"></span> </div> <div class="notification-item-content"> <div class="notification-data-container font-caption-body"> <span class="text notification-display-text" click-in-card ng-show="notification.metadataCollection[0].IsAccepted" ng-bind-html="requestConfirmedText"></span> <div class="text-date-hint" ng-bind="notification.eventDate | datetime: \'full\'"></div> </div> </div> </div> <div class="notification-action-container" ng-show="notification.notificationSourceType == notificationSourceType.friendRequestReceived"> <button class="btn-primary-xs font-caption-header btn-min-width" id="chat-btn" ng-class="{\'btn-full-width\': library.isPhone}" ng-show="notification.friendRequestActionType == friendRequestActionType.chatBtn" ng-click="chat({friendId: userIds[0], notificationId: notification.id, event: $event})"> <span ng-bind="\'Action.Chat\' | translate"></span> </button> </div> </div> </div> </div> '
            },
            1282: function(e) {
                e.exports = '<div> <ul class="dropdown-menu" role="menu"> <li> <a class="unfollow-link" ng-click="unfollowGame($event)"><span class="action-icon icon-follow-game-gray"></span><span ng-bind="\'Action.UnfollowGame\' | translate:{gameName: gameUpdateModel.truncatedGameName}"></span></a> </li> <li> <a class="report-abuse-link" ng-click="reportAbuse()"><span class="action-icon icon-report-darkgray"></span><span ng-bind="\'Action.ReportAbuse\' | translate"></span></a> </li> <li class="li-cancel-link"> <a class="cancel-link" ng-click="closeActionMenu()"><span class="action-icon icon-close"></span><span ng-bind="\'Action.Cancel\' | translate"></span></a> </li> </ul> </div>'
            },
            3851: function(e) {
                e.exports = '<div class="game-update-notification-container" ng-class="{ \'active\':isActionMenuOpen }"> <div class="notification-image-container" ng-show="isAggregated || !gameUpdateModel.isUnfollowed"> <div ng-if="gameUpdateModel.universeId !== null" title="{{gameUpdateModel.gameName}}"> <a ng-click="goToGameDetails()"> <thumbnail-2d class="notification-icon" thumbnail-target-id="gameUpdateModel.universeId" thumbnail-type="thumbnailTypes.gameIcon"> </thumbnail-2d> </a> </div> </div> <div class="notification-item-content" ng-show="!isAggregated && !gameUpdateModel.isUnfollowed"> <a class="more-link" uib-popover-template="actionMenuTemplate" popover-trigger="\'outsideClick\'" popover-placement="bottom-right" popover-is-open="isActionMenuOpen" popover-append-to-body="true" popover-class="game-update-action-menu" popover-animation="false"> <span class="icon-more-gray-vertical"></span> </a> <div class="notification-data-container" ng-class="{ \'single-game-update\': !isAggregated, \'play-button-visible\':library.canLaunchGameFromGameUpdate }"> <span class="small text notification-display-text"> <a class="text-name font-caption-header" ng-click="goToGameDetails()"> {{gameUpdateModel.truncatedGameName}} </a> : {{gameUpdateModel.updateMessage}} </span> <span class="spinner spinner-sm" ng-if="!gameUpdateModel.updateMessage"></span> <div class="text-secondary text-date-hint"> {{gameUpdateModel.createdOn | datetime: \'full\'}} </div> </div> <div class="notification-action-container" ng-show="!isAggregated && !gameUpdateModel.isUnfollowed"> <div class="font-caption-body not-playable-message" ng-if="library.canLaunchGameFromGameUpdate && gameUpdateModel.isPlayable === false"> <span ng-bind="\'Message.GameNotPlayableOnDevice\' | translate"></span> </div> <button class="play-button btn-growth-xs font-caption-header" ng-class="{\'btn-full-width\': library.isPhone }" ng-if="library.canLaunchGameFromGameUpdate && gameUpdateModel.isPlayable" ng-click="playButtonHandler()" ng-bind="\'Action.Play\' | translate"></button> </div> </div> <div class="notification-item-content aggregated" ng-show="isAggregated" ng-click="viewGameUpdates()"> <div class="notification-data-container"> <span class="small text notification-display-text" ng-bind-html="aggregatedDisplayText"></span> <div class="text-secondary text-date-hint"> {{gameUpdateModel.createdOn | datetime: \'full\'}} </div> </div> <span class="icon-right"></span> </div> <div ng-show="!isAggregated && gameUpdateModel.isUnfollowed"> <div class="unfollowed-game-update-notification small text" ng-class="{ \'play-button-visible\':library.canLaunchGameFromGameUpdate }"> <span ng-bind="\'Message.UnfollowedGame\' | translate:{gameName: gameUpdateModel.truncatedGameName}"></span><a class="undo-unfollow-link text-link small" ng-click="followGame()" ng-bind="\'Action.Undo\' | translate"></a> </div> </div> </div> '
            },
            9585: function(e) {
                e.exports = '<div class="notification-content-container"> <div class="notification-image-container"> <div ng-if="groupMembershipLayout.groupId !== null" title="{{groupMembershipLayout.groupName}}"> <a ng-href="{{groupMembershipLayout.groupLink}}" type="goToGroupPage" click-in-card onclick="event.stopPropagation()"> <thumbnail-2d class="notification-icon" thumbnail-target-id="groupMembershipLayout.groupId" thumbnail-type="thumbnailTypes.groupIcon"> </thumbnail-2d> </a> </div> </div> <div class="notification-item-content"> <div class="notification-data-container"> <span class="font-caption-body text notification-display-text" ng-bind-html="notificationDisplayText"> </span> <div class="text-date-hint" ng-bind="notification.eventDate | datetime: \'full\'"></div> </div> </div> </div> '
            },
            8537: function(e) {
                e.exports = '<div class="game-update-notification-container" ng-class="{ \'active\':isActionMenuOpen }"> <div class="notification-content-container"> <div class="notification-image-container" ng-show="isAggregated || !gameUpdateModel.isUnfollowed"> <div ng-if="gameUpdateModel.universeId !== null" title="{{gameUpdateModel.gameName}}"> <a ng-click="goToGameDetails()"> <thumbnail-2d class="notification-icon" thumbnail-target-id="gameUpdateModel.universeId" thumbnail-type="thumbnailTypes.gameIcon"> </thumbnail-2d> </a> </div> </div> <div class="notification-item-content" ng-show="!isAggregated && !gameUpdateModel.isUnfollowed"> <a class="more-link" uib-popover-template="actionMenuTemplate" popover-trigger="\'outsideClick\'" popover-placement="bottom-right" popover-is-open="isActionMenuOpen" popover-append-to-body="true" popover-class="game-update-action-menu" popover-animation="false"> <span class="icon-more-gray-vertical"></span> </a> <div class="notification-data-container" ng-class="{ \'single-game-update\': !isAggregated, \'play-button-visible\':library.canLaunchGameFromGameUpdate }"> <span class="small text notification-display-text"> <a class="text-name font-caption-header" ng-click="goToGameDetails()"> {{gameUpdateModel.truncatedGameName}} </a> : {{gameUpdateModel.updateMessage}} </span> <span class="spinner spinner-sm" ng-if="!gameUpdateModel.updateMessage"></span> <div class="text-secondary text-date-hint"> {{gameUpdateModel.createdOn | datetime: \'full\'}} </div> </div> </div> <div class="notification-item-content aggregated" ng-show="isAggregated" ng-click="viewGameUpdates()"> <div class="notification-data-container"> <span class="small text notification-display-text" ng-bind-html="aggregatedDisplayText"></span> <div class="text-secondary text-date-hint"> {{gameUpdateModel.createdOn | datetime: \'full\'}} </div> </div> <div class="notification-right-icon-container"> <span class="icon-right"></span> </div> </div> <div class="notification-action-container" ng-show="!isAggregated && !gameUpdateModel.isUnfollowed"> <div class="font-caption-body not-playable-message" ng-if="library.canLaunchGameFromGameUpdate && gameUpdateModel.isPlayable === false"> <span ng-bind="\'Message.GameNotPlayableOnDevice\' | translate"></span> </div> <button class="play-button btn-growth-xs font-caption-header" ng-class="{\'btn-full-width\': library.isPhone }" ng-if="library.canLaunchGameFromGameUpdate && gameUpdateModel.isPlayable" ng-click="playButtonHandler()" ng-bind="\'Action.Play\' | translate"></button> </div> <div ng-show="!isAggregated && gameUpdateModel.isUnfollowed"> <div class="unfollowed-game-update-notification small text" ng-class="{ \'play-button-visible\':library.canLaunchGameFromGameUpdate }"> <span ng-bind="\'Message.UnfollowedGame\' | translate:{gameName: gameUpdateModel.truncatedGameName}"></span><a class="undo-unfollow-link text-link small" ng-click="followGame()" ng-bind="\'Action.Undo\' | translate"></a> </div> </div> </div> </div> '
            },
            5951: function(e) {
                e.exports = '<div class="notification-content-view" ng-show="isActive" ng-transclude></div>'
            },
            3732: function(e) {
                e.exports = '<div ng-controller="notificationStreamController" id="notification-stream-base-view" ng-class="{\'inApp\': library.inApp,\'isPhone\': library.isPhone}" class="new-notification-stream-2022"> <div notification-stream-container></div> </div> '
            },
            3322: function(e) {
                e.exports = '<div class="notification-stream-content" id="notification-stream-container" ng-cloak> <div ng-controller="notificationsController" class="notification-stream-wrap open"> <div class="notification-stream-container" ng-class="{\'notification-stream-container-app\': library.inApp}"> <div notification-content-view library="library" content-view-manager="contentViewManager" view-id="{{library.notificationContentViews.main}}" is-active="true"> <div class="notification-stream-header" ng-hide="library.isPhone || library.iniOSApp"> <span class="text-label font-caption-header" ng-bind="\'Label.Notifications\' | translate"></span> <a class="text-link font-caption-header" click-in-card type="goToSettingPage" ng-href="{{layout.settingLink}}" ng-bind="\'Label.Settings\' | translate" ng-show="library.isNotificationPreferencesPageEnabled"></a> </div> <div id="notification-stream-body" class="notification-stream-body" notification-stream-body ng-class="{\'notification-stream-body-height\' :layout.getRecentDataInitialized && notificationIds.length == 0,\'notification-stream-body-no-header\' : library.isPhone ||library.iniOSApp }"> <div class="small notification-stream-banner banner-new" ng-class="{\'on\': layout.isNotificationContentOpen && layout.bannerEnabled}"> <span class="banner-text" ng-click="reloadNotificationStreamData()">{{layout.bannerText}}</span> <span id="close" class="icon-close-white" ng-click="closeBanner()"></span> </div> <div class="small notification-stream-banner banner-error" ng-class="{\'on\': layout.isNotificationContentOpen && layout.errorBannerEnabled}"> <span class="banner-text">{{layout.errorText}}</span> <span id="close" class="icon-close-white" ng-click="closeErrorBanner()"></span> </div> <div ng-show="layout.getRecentDataInitialized && notificationIds.length > 0" class="notification-stream-data"> <div id="sendr-meta-actions-container" sendr-meta-actions-list/> <div id="notification-stream-scrollbar" class="rbx-scrollbar notification-stream-scrollbar" lazy-loading> <ul class="notification-stream-list"> <li ng-repeat="notification in notifications | sortNotificationsByEventDateDesc" notification-card id="notification-stream-{{notification.id}}" ng-class="getNotificationListItemClass(notification)"> <div ng-if="notification.notificationSourceType == notificationSourceType.friendRequestReceived" friend-request notification="notification" library="library" layout="layout" app-meta="appMeta" accept-friend="acceptFriend(targetUserId, notificationId, event)" ignore-friend="ignoreFriend(targetUserId, notificationId, event)" chat="chat(friendId, notificationId, event)" interact-notification="interactNotification(notification)" class="notification-item" ng-hide="notification.isTurnOff" ng-class="{\'flipped\': notification.isFlipped}"></div> <div ng-if="notification.notificationSourceType == notificationSourceType.friendRequestAccepted" friend-request notification="notification" library="library" layout="layout" app-meta="appMeta" chat="chat(friendId, notificationId, event)" interact-notification="interactNotification(notification)" ng-hide="notification.isTurnOff" class="notification-item" ng-click="notification.isClickable ?  clickCard(notification) : null"></div> <div ng-if="notification.notificationSourceType == notificationSourceType.test" test notification="notification" interact-notification="interactNotification(notification)" class="notification-item"></div> <div ng-if="notification.notificationSourceType == notificationSourceType.privateMessageReceived" private-message notification="notification" interact-notification="interactNotification(notification)" app-meta="appMeta" library="library" layout="layout" class="notification-item notification-stream-pm" ng-click="notification.isClickable ?  clickCard(notification) : null"></div> <div ng-if="notification.notificationSourceType == notificationSourceType.developerMetricsAvailable" developer-metrics-available notification="notification" interact-notification="interactNotification(notification)" app-meta="appMeta" library="library" layout="layout" class="notification-item notification-stream-pm" ng-click="notification.isClickable ?  clickCard(notification) : null"></div> <div ng-if="notification.notificationSourceType ==\r\n                  notificationSourceType.gameUpdate" game-update notification="notification" library="library" layout="layout" new-design content-view-manager="contentViewManager" app-meta="appMeta" class="notification-item" ng-hide="notification.isTurnOff" ng-click="null"></div> <div ng-if="notification.notificationSourceType == notificationSourceType.groupJoinRequestAccepted" group-membership notification="notification" library="library" layout="layout" app-meta="appMeta" interact-notification="interactNotification(notification)" ng-hide="notification.isTurnOff" class="notification-item" ng-click="notification.isClickable ?  clickCard(notification) : null"></div> <div ng-if="notification.notificationSourceType ==\r\n                  notificationSourceType.sendr || notification.notificationSourceType ==\r\n                  notificationSourceType.sendrBundle" class="sendr-notification-container" sendr-notification notification-data="{{notification}}"/> <div class="small turn-off-container" ng-hide="!notification.isTurnOff"> <span class="turn-off-text">You have turned off notifications for</span> <a class="text-link small" ng-click="updateNotificationSetting(true)">Undo</a> </div> <span class="hidden icon-turn-off" ng-click="updateNotificationSetting(false)"></span> </li> </ul> <div class="notifications-lazy-loading" ng-show="layout.notiticationsLazyLoadingEnabled"> <span class="spinner spinner-sm"></span> </div> </div> </div> <div class="notification-stream-loading" ng-hide="layout.getRecentDataInitialized"> <span class="spinner spinner-sm"></span> </div> <div class="container-empty" ng-show="layout.getRecentDataInitialized && notificationIds.length === 0"> <div><span class="text" ng-bind="\'Label.AllCaughtUp\' | translate"></span></div> </div> </div> </div> </div> <div notification-content-view class="game-updates" library="library" content-view-manager="contentViewManager" view-id="{{library.notificationContentViews.gameUpdates}}" is-active="false"> <div class="notification-stream-header"> <a class="back-icon icon-left" ng-click="contentViewManager.selectContentView(library.notificationContentViews.main)"></a> <span class="text-label font-caption-header game-updates-header" ng-click="contentViewManager.selectContentView(library.notificationContentViews.main)" ng-bind="\'Heading.BackToAllNotifications\' | translate"> </span> </div> <div id="notification-stream-body" class="notification-stream-body game-updates"> <div class="notification-stream-data"> <div id="notification-stream-scrollbar" class="rbx-scrollbar notification-stream-scrollbar" lazy-loading> <ul class="notification-stream-list"> <li ng-repeat="gameUpdateModel in library.gameUpdateModels | sortGameUpdates" class="notification-stream-item unInteracted game-update"> <div game-update game-update-model="gameUpdateModel" library="library" new-design app-meta="appMeta" class="notification-item" ng-click="null" content-view-manager="contentViewManager"></div> </li> </ul> </div> </div> </div> </div> </div> </div> '
            },
            8190: function(e) {
                e.exports = '<div class="notification-content-container"> <div class="notification-image-container"> <div class="avatar avatar-headshot-sm" ng-if="privateMessageLayout.displayUserId !== null" title="{{privateMessageLayout.displayUserName}}"> <a ng-href="{{library.userLibrary[privateMessageLayout.displayUserId].profileLink}}" type="goToProfilePage" user_id="{{privateMessageLayout.displayUserId}}" click-in-card onclick="event.stopPropagation()"> <thumbnail-2d class="avatar-card-image" thumbnail-target-id="privateMessageLayout.displayUserId" thumbnail-type="thumbnailTypes.avatarHeadshot"> </thumbnail-2d> </a> </div> <span class="icon-nav-group" ng-if="privateMessageLayout.displayUserId === null"></span> </div> <div class="notification-item-content"> <div class="notification-data-container"> <div class="font-caption-body notification-display-text" ng-class="{\'text\': notification.isInteracted, \'text-emphasis\': !notification.isInteracted}" ng-show="!privateMessageLayout.isStacked"> <span class="font-caption-body message-header" ng-bind-html="\'Message.MessageFrom\' | translate:{username: \'<span class=font-caption-header>\' + privateMessageLayout.displayUserName + \'</span>\'}"> </span> <span class="text-secondary message-preview" ng-bind="privateMessageLayout.messagePreview"></span> </div> <div class="font-caption-body notification-display-text" ng-class="{\'text\': notification.isInteracted, \'text-emphasis\': !notification.isInteracted}" ng-show="privateMessageLayout.isStacked" ng-bind-html="\'Message.YouReceivedMessages\' | translate:{numberOfMessagesText: \'<span class=font-caption-header>\' + notification.eventCount + \'</span>\', numberOfMessages: notification.eventCount}"></div> <div class="text-date-hint" ng-bind="notification.eventDate | datetime: \'full\'"></div> </div> </div> </div> '
            },
            3834: function(e) {
                e.exports = '<div> <div class="notification-item-test"> <div class="notification-item-content"> <div class="notification-data-container"> <span class="text notification-display-text">{{notificationDisplayText}}</span> <div class="text-date-hint">{{notification.eventDate | datetime: \'full\'}}</div> </div> </div> </div> </div>'
            },
            792: function(e) {
                "use strict";
                e.exports = Roblox
            },
            5734: function(e) {
                "use strict";
                e.exports = angular
            }
        },
        t = {};

    function i(n) {
        if (t[n]) return t[n].exports;
        var a = t[n] = {
            exports: {}
        };
        return e[n](a, a.exports, i), a.exports
    }
    i.n = function(e) {
            var t = e && e.__esModule ? function() {
                return e.default
            } : function() {
                return e
            };
            return i.d(t, {
                a: t
            }), t
        }, i.d = function(e, t) {
            for (var n in t) i.o(t, n) && !i.o(e, n) && Object.defineProperty(e, n, {
                enumerable: !0,
                get: t[n]
            })
        }, i.o = function(e, t) {
            return Object.prototype.hasOwnProperty.call(e, t)
        }, i.r = function(e) {
            "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
                value: "Module"
            }), Object.defineProperty(e, "__esModule", {
                value: !0
            })
        },
        function() {
            "use strict";
            var e = i(5734),
                t = i.n(e),
                n = i(3544),
                a = i(1887),
                o = i(2077);
            (0, n.importFilesUnderPath)(i(965)), (0, n.importFilesUnderPath)(i(6408));
            var r = i(2594);
            (0, n.templateCacheGenerator)(t(), "notificationStreamIconHtmlTemplate", r);
            t().element((function() {
                t().bootstrap("#notification-stream-icon-container", [a.Z.name])
            })), (0, n.importFilesUnderPath)(i(8652)), (0, n.importFilesUnderPath)(i(3748)), (0, n.importFilesUnderPath)(i(3702)), (0, n.importFilesUnderPath)(i(4903)), (0, n.importFilesUnderPath)(i(3545));
            var c = i(6012);
            (0, n.templateCacheGenerator)(t(), "notificationStreamHtmlTemplate", c);
            t().element((function() {
                t().bootstrap(".notification-stream-base", [o.Z.name])
            }));
            a.Z, o.Z
        }()
}();
//# sourceMappingURL=https://js.rbxcdn.com/b5f99668b7d6f646928a88fc7c1039d6-notificationStream.bundle.min.js.map

/* Bundle detector */
window.Roblox && window.Roblox.BundleDetector && window.Roblox.BundleDetector.bundleDetected("NotificationStream");