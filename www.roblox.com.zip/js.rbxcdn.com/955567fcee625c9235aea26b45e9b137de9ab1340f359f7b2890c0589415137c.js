var Roblox = Roblox || {};
Roblox.LangDynamicDefault = Roblox.LangDynamicDefault || {};
Roblox.LangDynamicDefault["Authentication.Captcha"] = {
    "Action.Reload": "Reload",
    "Action.Submit": "Submit",
    "Response.CaptchaNotEnteredError": "Please fill out the Captcha",
    "Header.PleaseConfirmYouAreHuman": "Please Confirm You Are Human",
    "Message.Error.Default": "An unknown error occurred while displaying captcha.",
    "Action.PleaseTryAgain": "Please try again.",
    "Header.RobotChallenge": "Robot Challenge",
    "Description.VerifyingYouAreNotBot": "Verifying you're not a bot"
};
window.Roblox && window.Roblox.BundleDetector && window.Roblox.BundleDetector.bundleDetected("DynamicLocalizationResourceScript_Authentication.Captcha");