var Roblox = Roblox || {};
Roblox.LangDynamicDefault = Roblox.LangDynamicDefault || {};
Roblox.LangDynamicDefault["Common.AlertsAndOptions"] = {
    "Label.sRobux": "Robux",
    "Label.sBuyRobux": "Buy Robux",
    "Label.sSettings": "Settings",
    "Label.sHelp": "Help",
    "Label.sLogout": "Logout",
    "Label.sRobuxMessage": "{robuxValue} Robux",
    "Label.sQuickLogin": "Quick Sign In",
    "Labels.sQuickLogInWeb": "Quick Log In",
    "Description.KoreaScreentimeToastText": "Excessive experience use can interfere with normal daily life. You have visited on Roblox for {NumberOfHours} hour(s).",
    "Title.Warning": "Warning",
    "Action.OK": "OK",
    "Action.SkipToMainContent": "Skip to Main Content",
    "Label.sSwitchAccount": "Switch Accounts",
    "Description.AccountSwitchedConfirmationBannerText": "You switched to {accountName}"
};
window.Roblox && window.Roblox.BundleDetector && window.Roblox.BundleDetector.bundleDetected("DynamicLocalizationResourceScript_Common.AlertsAndOptions");