! function() {
    var n = {
            512: function(e) {
                "use strict";
                var p = {
                    single_source_shortest_paths: function(e, t, n) {
                        var r = {},
                            a = {};
                        a[t] = 0;
                        var o, i, c, u, l, s, f, d = p.PriorityQueue.make();
                        for (d.push(t, 0); !d.empty();)
                            for (c in i = (o = d.pop()).value, u = o.cost, l = e[i] || {}) l.hasOwnProperty(c) && (s = u + l[c], f = a[c], (void 0 === a[c] || s < f) && (a[c] = s, d.push(c, s), r[c] = i));
                        if (void 0 === n || void 0 !== a[n]) return r;
                        n = ["Could not find a path from ", t, " to ", n, "."].join("");
                        throw new Error(n)
                    },
                    extract_shortest_path_from_predecessor_list: function(e, t) {
                        for (var n = [], r = t; r;) n.push(r), e[r], r = e[r];
                        return n.reverse(), n
                    },
                    find_path: function(e, t, n) {
                        t = p.single_source_shortest_paths(e, t, n);
                        return p.extract_shortest_path_from_predecessor_list(t, n)
                    },
                    PriorityQueue: {
                        make: function(e) {
                            var t, n = p.PriorityQueue,
                                r = {};
                            for (t in e = e || {}, n) n.hasOwnProperty(t) && (r[t] = n[t]);
                            return r.queue = [], r.sorter = e.sorter || n.default_sorter, r
                        },
                        default_sorter: function(e, t) {
                            return e.cost - t.cost
                        },
                        push: function(e, t) {
                            t = {
                                value: e,
                                cost: t
                            };
                            this.queue.push(t), this.queue.sort(this.sorter)
                        },
                        pop: function() {
                            return this.queue.shift()
                        },
                        empty: function() {
                            return 0 === this.queue.length
                        }
                    }
                };
                e.exports = p
            },
            899: function(e) {
                "use strict";
                e.exports = function(e) {
                    for (var t = [], n = e.length, r = 0; r < n; r++) {
                        var a, o = e.charCodeAt(r);
                        55296 <= o && o <= 56319 && r + 1 < n && (56320 <= (a = e.charCodeAt(r + 1)) && a <= 57343 && (o = 1024 * (o - 55296) + a - 56320 + 65536, r += 1)), o < 128 ? t.push(o) : o < 2048 ? (t.push(o >> 6 | 192), t.push(63 & o | 128)) : o < 55296 || 57344 <= o && o < 65536 ? (t.push(o >> 12 | 224), t.push(o >> 6 & 63 | 128), t.push(63 & o | 128)) : 65536 <= o && o <= 1114111 ? (t.push(o >> 18 | 240), t.push(o >> 12 & 63 | 128), t.push(o >> 6 & 63 | 128), t.push(63 & o | 128)) : t.push(239, 191, 189)
                    }
                    return new Uint8Array(t).buffer
                }
            },
            47: function(e, t, n) {
                "use strict";
                /**
                 * @license React
                 * use-sync-external-store-shim.production.min.js
                 *
                 * Copyright (c) Facebook, Inc. and its affiliates.
                 *
                 * This source code is licensed under the MIT license found in the
                 * LICENSE file in the root directory of this source tree.
                 */
                var r = n(804);
                var a = "function" == typeof Object.is ? Object.is : function(e, t) {
                        return e === t && (0 !== e || 1 / e == 1 / t) || e != e && t != t
                    },
                    i = r.useState,
                    c = r.useEffect,
                    u = r.useLayoutEffect,
                    l = r.useDebugValue;

                function s(e) {
                    var t = e.getSnapshot;
                    e = e.value;
                    try {
                        var n = t();
                        return !a(e, n)
                    } catch (e) {
                        return 1
                    }
                }
                n = "undefined" == typeof window || void 0 === window.document || void 0 === window.document.createElement ? function(e, t) {
                    return t()
                } : function(e, t) {
                    var n = t(),
                        r = i({
                            inst: {
                                value: n,
                                getSnapshot: t
                            }
                        }),
                        a = r[0].inst,
                        o = r[1];
                    return u(function() {
                        a.value = n, a.getSnapshot = t, s(a) && o({
                            inst: a
                        })
                    }, [e, n, t]), c(function() {
                        return s(a) && o({
                            inst: a
                        }), e(function() {
                            s(a) && o({
                                inst: a
                            })
                        })
                    }, [e]), l(n), n
                };
                t.useSyncExternalStore = void 0 !== r.useSyncExternalStore ? r.useSyncExternalStore : n
            },
            693: function(e, t, n) {
                "use strict";
                /**
                 * @license React
                 * use-sync-external-store-shim/with-selector.production.min.js
                 *
                 * Copyright (c) Facebook, Inc. and its affiliates.
                 *
                 * This source code is licensed under the MIT license found in the
                 * LICENSE file in the root directory of this source tree.
                 */
                var r = n(804),
                    n = n(644);
                var s = "function" == typeof Object.is ? Object.is : function(e, t) {
                        return e === t && (0 !== e || 1 / e == 1 / t) || e != e && t != t
                    },
                    a = n.useSyncExternalStore,
                    o = r.useRef,
                    f = r.useEffect,
                    d = r.useMemo,
                    p = r.useDebugValue;
                t.useSyncExternalStoreWithSelector = function(e, n, i, c, u) {
                    var l, t = o(null);
                    null === t.current ? (l = {
                        hasValue: !1,
                        value: null
                    }, t.current = l) : l = t.current, t = d(function() {
                        function e(e) {
                            if (!o) {
                                if (o = !0, e = c(r = e), void 0 !== u && l.hasValue) {
                                    var t = l.value;
                                    if (u(t, e)) return a = t
                                }
                                return a = e
                            }
                            if (t = a, s(r, e)) return t;
                            var n = c(e);
                            return void 0 !== u && u(t, n) ? t : (r = e, a = n)
                        }
                        var r, a, o = !1,
                            t = void 0 === i ? null : i;
                        return [function() {
                            return e(n())
                        }, null === t ? void 0 : function() {
                            return e(t())
                        }]
                    }, [n, i, c, u]);
                    var r = a(e, t[0], t[1]);
                    return f(function() {
                        l.hasValue = !0, l.value = r
                    }, [r]), p(r), r
                }
            },
            644: function(e, t, n) {
                "use strict";
                e.exports = n(47)
            },
            626: function(e, t, n) {
                "use strict";
                e.exports = n(693)
            },
            508: function(e, t, n) {
                "use strict";
                var r = n(714),
                    a = {
                        childContextTypes: !0,
                        contextType: !0,
                        contextTypes: !0,
                        defaultProps: !0,
                        displayName: !0,
                        getDefaultProps: !0,
                        getDerivedStateFromError: !0,
                        getDerivedStateFromProps: !0,
                        mixins: !0,
                        propTypes: !0,
                        type: !0
                    },
                    f = {
                        name: !0,
                        length: !0,
                        prototype: !0,
                        caller: !0,
                        callee: !0,
                        arguments: !0,
                        arity: !0
                    },
                    o = {
                        $$typeof: !0,
                        compare: !0,
                        defaultProps: !0,
                        displayName: !0,
                        propTypes: !0,
                        type: !0
                    },
                    i = {};

                function d(e) {
                    return r.isMemo(e) ? o : i[e.$$typeof] || a
                }
                i[r.ForwardRef] = {
                    $$typeof: !0,
                    render: !0,
                    defaultProps: !0,
                    displayName: !0,
                    propTypes: !0
                }, i[r.Memo] = o;
                var p = Object.defineProperty,
                    m = Object.getOwnPropertyNames,
                    h = Object.getOwnPropertySymbols,
                    v = Object.getOwnPropertyDescriptor,
                    g = Object.getPrototypeOf,
                    y = Object.prototype;
                e.exports = function e(t, n, r) {
                    if ("string" != typeof n) {
                        var a;
                        !y || (a = g(n)) && a !== y && e(t, a, r);
                        var o = m(n);
                        h && (o = o.concat(h(n)));
                        for (var i = d(t), c = d(n), u = 0; u < o.length; ++u) {
                            var l = o[u];
                            if (!(f[l] || r && r[l] || c && c[l] || i && i[l])) {
                                var s = v(n, l);
                                try {
                                    p(t, l, s)
                                } catch (e) {}
                            }
                        }
                    }
                    return t
                }
            },
            341: function(e, t) {
                "use strict";
                /** @license React v16.13.1
                 * react-is.production.min.js
                 *
                 * Copyright (c) Facebook, Inc. and its affiliates.
                 *
                 * This source code is licensed under the MIT license found in the
                 * LICENSE file in the root directory of this source tree.
                 */
                function n(e) {
                    return (n = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                        return typeof e
                    } : function(e) {
                        return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                    })(e)
                }
                var r = "function" == typeof Symbol && Symbol.for,
                    a = r ? Symbol.for("react.element") : 60103,
                    o = r ? Symbol.for("react.portal") : 60106,
                    i = r ? Symbol.for("react.fragment") : 60107,
                    c = r ? Symbol.for("react.strict_mode") : 60108,
                    u = r ? Symbol.for("react.profiler") : 60114,
                    l = r ? Symbol.for("react.provider") : 60109,
                    s = r ? Symbol.for("react.context") : 60110,
                    f = r ? Symbol.for("react.async_mode") : 60111,
                    d = r ? Symbol.for("react.concurrent_mode") : 60111,
                    p = r ? Symbol.for("react.forward_ref") : 60112,
                    m = r ? Symbol.for("react.suspense") : 60113,
                    h = r ? Symbol.for("react.suspense_list") : 60120,
                    v = r ? Symbol.for("react.memo") : 60115,
                    g = r ? Symbol.for("react.lazy") : 60116,
                    y = r ? Symbol.for("react.block") : 60121,
                    b = r ? Symbol.for("react.fundamental") : 60117,
                    E = r ? Symbol.for("react.responder") : 60118,
                    w = r ? Symbol.for("react.scope") : 60119;

                function S(e) {
                    if ("object" === n(e) && null !== e) {
                        var t = e.$$typeof;
                        switch (t) {
                            case a:
                                switch (e = e.type) {
                                    case f:
                                    case d:
                                    case i:
                                    case u:
                                    case c:
                                    case m:
                                        return e;
                                    default:
                                        switch (e = e && e.$$typeof) {
                                            case s:
                                            case p:
                                            case g:
                                            case v:
                                            case l:
                                                return e;
                                            default:
                                                return t
                                        }
                                }
                            case o:
                                return t
                        }
                    }
                }

                function C(e) {
                    return S(e) === d
                }
                t.AsyncMode = f, t.ConcurrentMode = d, t.ContextConsumer = s, t.ContextProvider = l, t.Element = a, t.ForwardRef = p, t.Fragment = i, t.Lazy = g, t.Memo = v, t.Portal = o, t.Profiler = u, t.StrictMode = c, t.Suspense = m, t.isAsyncMode = function(e) {
                    return C(e) || S(e) === f
                }, t.isConcurrentMode = C, t.isContextConsumer = function(e) {
                    return S(e) === s
                }, t.isContextProvider = function(e) {
                    return S(e) === l
                }, t.isElement = function(e) {
                    return "object" === n(e) && null !== e && e.$$typeof === a
                }, t.isForwardRef = function(e) {
                    return S(e) === p
                }, t.isFragment = function(e) {
                    return S(e) === i
                }, t.isLazy = function(e) {
                    return S(e) === g
                }, t.isMemo = function(e) {
                    return S(e) === v
                }, t.isPortal = function(e) {
                    return S(e) === o
                }, t.isProfiler = function(e) {
                    return S(e) === u
                }, t.isStrictMode = function(e) {
                    return S(e) === c
                }, t.isSuspense = function(e) {
                    return S(e) === m
                }, t.isValidElementType = function(e) {
                    return "string" == typeof e || "function" == typeof e || e === i || e === d || e === u || e === c || e === m || e === h || "object" === n(e) && null !== e && (e.$$typeof === g || e.$$typeof === v || e.$$typeof === l || e.$$typeof === s || e.$$typeof === p || e.$$typeof === b || e.$$typeof === E || e.$$typeof === w || e.$$typeof === y)
                }, t.typeOf = S
            },
            714: function(e, t, n) {
                "use strict";
                e.exports = n(341)
            },
            443: function(e, t) {
                "use strict";
                Symbol.for("react.element"), Symbol.for("react.portal"), Symbol.for("react.fragment"), Symbol.for("react.strict_mode"), Symbol.for("react.profiler"), Symbol.for("react.provider"), Symbol.for("react.context"), Symbol.for("react.server_context"), Symbol.for("react.forward_ref"), Symbol.for("react.suspense"), Symbol.for("react.suspense_list"), Symbol.for("react.memo"), Symbol.for("react.lazy"), Symbol.for("react.offscreen");
                Symbol.for("react.module.reference")
            },
            386: function(e, t, n) {
                "use strict";
                n(443)
            },
            28: function(e, t, n) {
                var u = n(827),
                    l = n(421),
                    r = n(895),
                    a = n(398);

                function o(r, a, o, i, t) {
                    var e = [].slice.call(arguments, 1),
                        n = e.length,
                        e = "function" == typeof e[n - 1];
                    if (!e && !u()) throw new Error("Callback required as last argument");
                    if (!e) {
                        if (n < 1) throw new Error("Too few arguments provided");
                        return 1 === n ? (o = a, a = i = void 0) : 2 !== n || a.getContext || (i = o, o = a, a = void 0), new Promise(function(e, t) {
                            try {
                                var n = l.create(o, i);
                                e(r(n, a, i))
                            } catch (e) {
                                t(e)
                            }
                        })
                    }
                    if (n < 2) throw new Error("Too few arguments provided");
                    2 === n ? (t = o, o = a, a = i = void 0) : 3 === n && (a.getContext && void 0 === t ? (t = i, i = void 0) : (t = i, i = o, o = a, a = void 0));
                    try {
                        var c = l.create(o, i);
                        t(null, r(c, a, i))
                    } catch (e) {
                        t(e)
                    }
                }
                l.create, o.bind(null, r.render), t.hz = o.bind(null, r.renderToDataURL), o.bind(null, function(e, t, n) {
                    return a.render(e, n)
                })
            },
            827: function(e) {
                e.exports = function() {
                    return "function" == typeof Promise && Promise.prototype && Promise.prototype.then
                }
            },
            965: function(e, i, t) {
                var o = t(814).getSymbolSize;
                i.getRowColCoords = function(e) {
                    if (1 === e) return [];
                    for (var t = Math.floor(e / 7) + 2, e = o(e), n = 145 === e ? 26 : 2 * Math.ceil((e - 13) / (2 * t - 2)), r = [e - 7], a = 1; a < t - 1; a++) r[a] = r[a - 1] - n;
                    return r.push(6), r.reverse()
                }, i.getPositions = function(e) {
                    for (var t = [], n = i.getRowColCoords(e), r = n.length, a = 0; a < r; a++)
                        for (var o = 0; o < r; o++) 0 === a && 0 === o || 0 === a && o === r - 1 || a === r - 1 && 0 === o || t.push([n[a], n[o]]);
                    return t
                }
            },
            224: function(e, t, n) {
                var r = n(937),
                    a = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", " ", "$", "%", "*", "+", "-", ".", "/", ":"];

                function o(e) {
                    this.mode = r.ALPHANUMERIC, this.data = e
                }
                o.getBitsLength = function(e) {
                    return 11 * Math.floor(e / 2) + e % 2 * 6
                }, o.prototype.getLength = function() {
                    return this.data.length
                }, o.prototype.getBitsLength = function() {
                    return o.getBitsLength(this.data.length)
                }, o.prototype.write = function(e) {
                    for (var t = 0; t + 2 <= this.data.length; t += 2) {
                        var n = 45 * a.indexOf(this.data[t]);
                        n += a.indexOf(this.data[t + 1]), e.put(n, 11)
                    }
                    this.data.length % 2 && e.put(a.indexOf(this.data[t]), 6)
                }, e.exports = o
            },
            596: function(e) {
                function t() {
                    this.buffer = [], this.length = 0
                }
                t.prototype = {
                    get: function(e) {
                        var t = Math.floor(e / 8);
                        return 1 == (this.buffer[t] >>> 7 - e % 8 & 1)
                    },
                    put: function(e, t) {
                        for (var n = 0; n < t; n++) this.putBit(1 == (e >>> t - n - 1 & 1))
                    },
                    getLengthInBits: function() {
                        return this.length
                    },
                    putBit: function(e) {
                        var t = Math.floor(this.length / 8);
                        this.buffer.length <= t && this.buffer.push(0), e && (this.buffer[t] |= 128 >>> this.length % 8), this.length++
                    }
                }, e.exports = t
            },
            534: function(e) {
                function t(e) {
                    if (!e || e < 1) throw new Error("BitMatrix size must be defined and greater than 0");
                    this.size = e, this.data = new Uint8Array(e * e), this.reservedBit = new Uint8Array(e * e)
                }
                t.prototype.set = function(e, t, n, r) {
                    t = e * this.size + t;
                    this.data[t] = n, r && (this.reservedBit[t] = !0)
                }, t.prototype.get = function(e, t) {
                    return this.data[e * this.size + t]
                }, t.prototype.xor = function(e, t, n) {
                    this.data[e * this.size + t] ^= n
                }, t.prototype.isReserved = function(e, t) {
                    return this.reservedBit[e * this.size + t]
                }, e.exports = t
            },
            823: function(e, t, n) {
                var r = n(899),
                    a = n(937);

                function o(e) {
                    this.mode = a.BYTE, "string" == typeof e && (e = r(e)), this.data = new Uint8Array(e)
                }
                o.getBitsLength = function(e) {
                    return 8 * e
                }, o.prototype.getLength = function() {
                    return this.data.length
                }, o.prototype.getBitsLength = function() {
                    return o.getBitsLength(this.data.length)
                }, o.prototype.write = function(e) {
                    for (var t = 0, n = this.data.length; t < n; t++) e.put(this.data[t], 8)
                }, e.exports = o
            },
            889: function(e, t, n) {
                var r = n(422),
                    a = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 1, 2, 2, 4, 1, 2, 4, 4, 2, 4, 4, 4, 2, 4, 6, 5, 2, 4, 6, 6, 2, 5, 8, 8, 4, 5, 8, 8, 4, 5, 8, 11, 4, 8, 10, 11, 4, 9, 12, 16, 4, 9, 16, 16, 6, 10, 12, 18, 6, 10, 17, 16, 6, 11, 16, 19, 6, 13, 18, 21, 7, 14, 21, 25, 8, 16, 20, 25, 8, 17, 23, 25, 9, 17, 23, 34, 9, 18, 25, 30, 10, 20, 27, 32, 12, 21, 29, 35, 12, 23, 34, 37, 12, 25, 34, 40, 13, 26, 35, 42, 14, 28, 38, 45, 15, 29, 40, 48, 16, 31, 43, 51, 17, 33, 45, 54, 18, 35, 48, 57, 19, 37, 51, 60, 19, 38, 53, 63, 20, 40, 56, 66, 21, 43, 59, 70, 22, 45, 62, 74, 24, 47, 65, 77, 25, 49, 68, 81],
                    o = [7, 10, 13, 17, 10, 16, 22, 28, 15, 26, 36, 44, 20, 36, 52, 64, 26, 48, 72, 88, 36, 64, 96, 112, 40, 72, 108, 130, 48, 88, 132, 156, 60, 110, 160, 192, 72, 130, 192, 224, 80, 150, 224, 264, 96, 176, 260, 308, 104, 198, 288, 352, 120, 216, 320, 384, 132, 240, 360, 432, 144, 280, 408, 480, 168, 308, 448, 532, 180, 338, 504, 588, 196, 364, 546, 650, 224, 416, 600, 700, 224, 442, 644, 750, 252, 476, 690, 816, 270, 504, 750, 900, 300, 560, 810, 960, 312, 588, 870, 1050, 336, 644, 952, 1110, 360, 700, 1020, 1200, 390, 728, 1050, 1260, 420, 784, 1140, 1350, 450, 812, 1200, 1440, 480, 868, 1290, 1530, 510, 924, 1350, 1620, 540, 980, 1440, 1710, 570, 1036, 1530, 1800, 570, 1064, 1590, 1890, 600, 1120, 1680, 1980, 630, 1204, 1770, 2100, 660, 1260, 1860, 2220, 720, 1316, 1950, 2310, 750, 1372, 2040, 2430];
                t.getBlocksCount = function(e, t) {
                    switch (t) {
                        case r.L:
                            return a[4 * (e - 1) + 0];
                        case r.M:
                            return a[4 * (e - 1) + 1];
                        case r.Q:
                            return a[4 * (e - 1) + 2];
                        case r.H:
                            return a[4 * (e - 1) + 3];
                        default:
                            return
                    }
                }, t.getTotalCodewordsCount = function(e, t) {
                    switch (t) {
                        case r.L:
                            return o[4 * (e - 1) + 0];
                        case r.M:
                            return o[4 * (e - 1) + 1];
                        case r.Q:
                            return o[4 * (e - 1) + 2];
                        case r.H:
                            return o[4 * (e - 1) + 3];
                        default:
                            return
                    }
                }
            },
            422: function(e, n) {
                n.L = {
                    bit: 1
                }, n.M = {
                    bit: 0
                }, n.Q = {
                    bit: 3
                }, n.H = {
                    bit: 2
                }, n.isValid = function(e) {
                    return e && void 0 !== e.bit && 0 <= e.bit && e.bit < 4
                }, n.from = function(e, t) {
                    if (n.isValid(e)) return e;
                    try {
                        return function(e) {
                            if ("string" != typeof e) throw new Error("Param is not a string");
                            switch (e.toLowerCase()) {
                                case "l":
                                case "low":
                                    return n.L;
                                case "m":
                                case "medium":
                                    return n.M;
                                case "q":
                                case "quartile":
                                    return n.Q;
                                case "h":
                                case "high":
                                    return n.H;
                                default:
                                    throw new Error("Unknown EC Level: " + e)
                            }
                        }(e)
                    } catch (e) {
                        return t
                    }
                }
            },
            125: function(e, t, n) {
                var r = n(814).getSymbolSize;
                t.getPositions = function(e) {
                    e = r(e);
                    return [
                        [0, 0],
                        [e - 7, 0],
                        [0, e - 7]
                    ]
                }
            },
            336: function(e, t, n) {
                var r = n(814),
                    a = r.getBCHDigit(1335);
                t.getEncodedBits = function(e, t) {
                    for (var t = e.bit << 3 | t, n = t << 10; 0 <= r.getBCHDigit(n) - a;) n ^= 1335 << r.getBCHDigit(n) - a;
                    return 21522 ^ (t << 10 | n)
                }
            },
            376: function(e, t) {
                var r = new Uint8Array(512),
                    a = new Uint8Array(256);
                ! function() {
                    for (var e = 1, t = 0; t < 255; t++) r[t] = e, a[e] = t, 256 & (e <<= 1) && (e ^= 285);
                    for (var n = 255; n < 512; n++) r[n] = r[n - 255]
                }(), t.log = function(e) {
                    if (e < 1) throw new Error("log(" + e + ")");
                    return a[e]
                }, t.exp = function(e) {
                    return r[e]
                }, t.mul = function(e, t) {
                    return 0 === e || 0 === t ? 0 : r[a[e] + a[t]]
                }
            },
            57: function(e, t, n) {
                var r = n(937),
                    a = n(814);

                function o(e) {
                    this.mode = r.KANJI, this.data = e
                }
                o.getBitsLength = function(e) {
                    return 13 * e
                }, o.prototype.getLength = function() {
                    return this.data.length
                }, o.prototype.getBitsLength = function() {
                    return o.getBitsLength(this.data.length)
                }, o.prototype.write = function(e) {
                    for (var t = 0; t < this.data.length; t++) {
                        var n = a.toSJIS(this.data[t]);
                        if (33088 <= n && n <= 40956) n -= 33088;
                        else {
                            if (!(57408 <= n && n <= 60351)) throw new Error("Invalid SJIS character: " + this.data[t] + "\nMake sure your charset is UTF-8");
                            n -= 49472
                        }
                        n = 192 * (n >>> 8 & 255) + (255 & n), e.put(n, 13)
                    }
                }, e.exports = o
            },
            910: function(e, c) {
                c.Patterns = {
                    PATTERN000: 0,
                    PATTERN001: 1,
                    PATTERN010: 2,
                    PATTERN011: 3,
                    PATTERN100: 4,
                    PATTERN101: 5,
                    PATTERN110: 6,
                    PATTERN111: 7
                };
                var s = 3,
                    i = 3,
                    u = 40,
                    a = 10;
                c.isValid = function(e) {
                    return null != e && "" !== e && !isNaN(e) && 0 <= e && e <= 7
                }, c.from = function(e) {
                    return c.isValid(e) ? parseInt(e, 10) : void 0
                }, c.getPenaltyN1 = function(e) {
                    for (var t = e.size, n = 0, r = 0, a = 0, o = null, i = null, c = 0; c < t; c++) {
                        o = i = null;
                        for (var u = r = a = 0; u < t; u++) {
                            var l = e.get(c, u);
                            l === o ? r++ : (5 <= r && (n += s + (r - 5)), o = l, r = 1), (l = e.get(u, c)) === i ? a++ : (5 <= a && (n += s + (a - 5)), i = l, a = 1)
                        }
                        5 <= r && (n += s + (r - 5)), 5 <= a && (n += s + (a - 5))
                    }
                    return n
                }, c.getPenaltyN2 = function(e) {
                    for (var t = e.size, n = 0, r = 0; r < t - 1; r++)
                        for (var a = 0; a < t - 1; a++) {
                            var o = e.get(r, a) + e.get(r, a + 1) + e.get(r + 1, a) + e.get(r + 1, a + 1);
                            4 !== o && 0 !== o || n++
                        }
                    return n * i
                }, c.getPenaltyN3 = function(e) {
                    for (var t = e.size, n = 0, r = 0, a = 0, o = 0; o < t; o++)
                        for (var i = r = a = 0; i < t; i++) r = r << 1 & 2047 | e.get(o, i), 10 <= i && (1488 === r || 93 === r) && n++, a = a << 1 & 2047 | e.get(i, o), 10 <= i && (1488 === a || 93 === a) && n++;
                    return n * u
                }, c.getPenaltyN4 = function(e) {
                    for (var t = 0, n = e.data.length, r = 0; r < n; r++) t += e.data[r];
                    return Math.abs(Math.ceil(100 * t / n / 5) - 10) * a
                }, c.applyMask = function(e, t) {
                    for (var n = t.size, r = 0; r < n; r++)
                        for (var a = 0; a < n; a++) t.isReserved(a, r) || t.xor(a, r, function(e, t, n) {
                            switch (e) {
                                case c.Patterns.PATTERN000:
                                    return (t + n) % 2 == 0;
                                case c.Patterns.PATTERN001:
                                    return t % 2 == 0;
                                case c.Patterns.PATTERN010:
                                    return n % 3 == 0;
                                case c.Patterns.PATTERN011:
                                    return (t + n) % 3 == 0;
                                case c.Patterns.PATTERN100:
                                    return (Math.floor(t / 2) + Math.floor(n / 3)) % 2 == 0;
                                case c.Patterns.PATTERN101:
                                    return t * n % 2 + t * n % 3 == 0;
                                case c.Patterns.PATTERN110:
                                    return (t * n % 2 + t * n % 3) % 2 == 0;
                                case c.Patterns.PATTERN111:
                                    return (t * n % 3 + (t + n) % 2) % 2 == 0;
                                default:
                                    throw new Error("bad maskPattern:" + e)
                            }
                        }(e, a, r))
                }, c.getBestMask = function(e, t) {
                    for (var n = Object.keys(c.Patterns).length, r = 0, a = 1 / 0, o = 0; o < n; o++) {
                        t(o), c.applyMask(o, e);
                        var i = c.getPenaltyN1(e) + c.getPenaltyN2(e) + c.getPenaltyN3(e) + c.getPenaltyN4(e);
                        c.applyMask(o, e), i < a && (a = i, r = o)
                    }
                    return r
                }
            },
            937: function(e, n, t) {
                var r = t(148),
                    a = t(598);
                n.NUMERIC = {
                    id: "Numeric",
                    bit: 1,
                    ccBits: [10, 12, 14]
                }, n.ALPHANUMERIC = {
                    id: "Alphanumeric",
                    bit: 2,
                    ccBits: [9, 11, 13]
                }, n.BYTE = {
                    id: "Byte",
                    bit: 4,
                    ccBits: [8, 16, 16]
                }, n.KANJI = {
                    id: "Kanji",
                    bit: 8,
                    ccBits: [8, 10, 12]
                }, n.MIXED = {
                    bit: -1
                }, n.getCharCountIndicator = function(e, t) {
                    if (!e.ccBits) throw new Error("Invalid mode: " + e);
                    if (!r.isValid(t)) throw new Error("Invalid version: " + t);
                    return 1 <= t && t < 10 ? e.ccBits[0] : t < 27 ? e.ccBits[1] : e.ccBits[2]
                }, n.getBestModeForData = function(e) {
                    return a.testNumeric(e) ? n.NUMERIC : a.testAlphanumeric(e) ? n.ALPHANUMERIC : a.testKanji(e) ? n.KANJI : n.BYTE
                }, n.toString = function(e) {
                    if (e && e.id) return e.id;
                    throw new Error("Invalid mode")
                }, n.isValid = function(e) {
                    return e && e.bit && e.ccBits
                }, n.from = function(e, t) {
                    if (n.isValid(e)) return e;
                    try {
                        return function(e) {
                            if ("string" != typeof e) throw new Error("Param is not a string");
                            switch (e.toLowerCase()) {
                                case "numeric":
                                    return n.NUMERIC;
                                case "alphanumeric":
                                    return n.ALPHANUMERIC;
                                case "kanji":
                                    return n.KANJI;
                                case "byte":
                                    return n.BYTE;
                                default:
                                    throw new Error("Unknown mode: " + e)
                            }
                        }(e)
                    } catch (e) {
                        return t
                    }
                }
            },
            758: function(e, t, n) {
                var r = n(937);

                function a(e) {
                    this.mode = r.NUMERIC, this.data = e.toString()
                }
                a.getBitsLength = function(e) {
                    return 10 * Math.floor(e / 3) + (e % 3 ? e % 3 * 3 + 1 : 0)
                }, a.prototype.getLength = function() {
                    return this.data.length
                }, a.prototype.getBitsLength = function() {
                    return a.getBitsLength(this.data.length)
                }, a.prototype.write = function(e) {
                    for (var t, n, r = 0; r + 3 <= this.data.length; r += 3) t = this.data.substr(r, 3), n = parseInt(t, 10), e.put(n, 10);
                    var a = this.data.length - r;
                    0 < a && (t = this.data.substr(r), n = parseInt(t, 10), e.put(n, 3 * a + 1))
                }, e.exports = a
            },
            378: function(e, r, t) {
                var i = t(376);
                r.mul = function(e, t) {
                    for (var n = new Uint8Array(e.length + t.length - 1), r = 0; r < e.length; r++)
                        for (var a = 0; a < t.length; a++) n[r + a] ^= i.mul(e[r], t[a]);
                    return n
                }, r.mod = function(e, t) {
                    for (var n = new Uint8Array(e); 0 <= n.length - t.length;) {
                        for (var r = n[0], a = 0; a < t.length; a++) n[a] ^= i.mul(t[a], r);
                        for (var o = 0; o < n.length && 0 === n[o];) o++;
                        n = n.slice(o)
                    }
                    return n
                }, r.generateECPolynomial = function(e) {
                    for (var t = new Uint8Array([1]), n = 0; n < e; n++) t = r.mul(t, new Uint8Array([1, i.exp(n)]));
                    return t
                }
            },
            421: function(e, t, n) {
                var S = n(814),
                    o = n(422),
                    i = n(596),
                    c = n(534),
                    l = n(965),
                    s = n(125),
                    f = n(910),
                    C = n(889),
                    A = n(630),
                    d = n(701),
                    u = n(336),
                    p = n(937),
                    m = n(59);

                function h(e, t, n) {
                    for (var r, a = e.size, o = u.getEncodedBits(t, n), i = 0; i < 15; i++) r = 1 == (o >> i & 1), i < 6 ? e.set(i, 8, r, !0) : i < 8 ? e.set(i + 1, 8, r, !0) : e.set(a - 15 + i, 8, r, !0), i < 8 ? e.set(8, a - i - 1, r, !0) : i < 9 ? e.set(8, 15 - i - 1 + 1, r, !0) : e.set(8, 15 - i - 1, r, !0);
                    e.set(a - 8, 8, 1, !0)
                }

                function v(t, e, n) {
                    var r = new i;
                    n.forEach(function(e) {
                        r.put(e.mode.bit, 4), r.put(e.getLength(), p.getCharCountIndicator(e.mode, t)), e.write(r)
                    });
                    n = 8 * (S.getSymbolTotalCodewords(t) - C.getTotalCodewordsCount(t, e));
                    for (r.getLengthInBits() + 4 <= n && r.put(0, 4); r.getLengthInBits() % 8 != 0;) r.putBit(0);
                    for (var a = (n - r.getLengthInBits()) / 8, o = 0; o < a; o++) r.put(o % 2 ? 17 : 236, 8);
                    return function(e, t, n) {
                        for (var r = S.getSymbolTotalCodewords(t), a = C.getTotalCodewordsCount(t, n), a = r - a, o = C.getBlocksCount(t, n), i = o - r % o, n = Math.floor(r / o), c = Math.floor(a / o), u = c + 1, l = n - c, s = new A(l), f = 0, d = new Array(o), p = new Array(o), m = 0, h = new Uint8Array(e.buffer), v = 0; v < o; v++) {
                            var g = v < i ? c : u;
                            d[v] = h.slice(f, f + g), p[v] = s.encode(d[v]), f += g, m = Math.max(m, g)
                        }
                        var y, b, E = new Uint8Array(r),
                            w = 0;
                        for (y = 0; y < m; y++)
                            for (b = 0; b < o; b++) y < d[b].length && (E[w++] = d[b][y]);
                        for (y = 0; y < l; y++)
                            for (b = 0; b < o; b++) E[w++] = p[b][y];
                        return E
                    }(r, t, e)
                }

                function g(e, u, t, n) {
                    var r;
                    if (Array.isArray(e)) r = m.fromArray(e);
                    else {
                        if ("string" != typeof e) throw new Error("Invalid data");
                        var a, o = u;
                        o || (a = m.rawSplit(e), o = d.getBestVersionForData(a, t)), r = m.fromString(e, o || 40)
                    }
                    e = d.getBestVersionForData(r, t);
                    if (!e) throw new Error("The amount of data is too big to be stored in a QR Code");
                    if (u) {
                        if (u < e) throw new Error("\nThe chosen QR Code version cannot contain this amount of data.\nMinimum version required to store current data is: " + e + ".\n")
                    } else u = e;
                    o = v(u, t, r), e = S.getSymbolSize(u), e = new c(e);
                    return function(e) {
                            for (var t = e.size, n = s.getPositions(u), r = 0; r < n.length; r++)
                                for (var a = n[r][0], o = n[r][1], i = -1; i <= 7; i++)
                                    if (!(a + i <= -1 || t <= a + i))
                                        for (var c = -1; c <= 7; c++) o + c <= -1 || t <= o + c || (0 <= i && i <= 6 && (0 === c || 6 === c) || 0 <= c && c <= 6 && (0 === i || 6 === i) || 2 <= i && i <= 4 && 2 <= c && c <= 4 ? e.set(a + i, o + c, !0, !0) : e.set(a + i, o + c, !1, !0))
                        }(e),
                        function(e) {
                            for (var t = e.size, n = 8; n < t - 8; n++) {
                                var r = n % 2 == 0;
                                e.set(n, 6, r, !0), e.set(6, n, r, !0)
                            }
                        }(e),
                        function(e) {
                            for (var t = l.getPositions(u), n = 0; n < t.length; n++)
                                for (var r = t[n][0], a = t[n][1], o = -2; o <= 2; o++)
                                    for (var i = -2; i <= 2; i++) - 2 === o || 2 === o || -2 === i || 2 === i || 0 === o && 0 === i ? e.set(r + o, a + i, !0, !0) : e.set(r + o, a + i, !1, !0)
                        }(e), h(e, t, 0), 7 <= u && function(e) {
                            for (var t, n, r, a = e.size, o = d.getEncodedBits(u), i = 0; i < 18; i++) t = Math.floor(i / 3), n = i % 3 + a - 8 - 3, r = 1 == (o >> i & 1), e.set(t, n, r, !0), e.set(n, t, r, !0)
                        }(e),
                        function(e, t) {
                            for (var n = e.size, r = -1, a = n - 1, o = 7, i = 0, c = n - 1; 0 < c; c -= 2)
                                for (6 === c && c--;;) {
                                    for (var u, l = 0; l < 2; l++) e.isReserved(a, c - l) || (u = !1, i < t.length && (u = 1 == (t[i] >>> o & 1)), e.set(a, c - l, u), -1 === --o && (i++, o = 7));
                                    if ((a += r) < 0 || n <= a) {
                                        a -= r, r = -r;
                                        break
                                    }
                                }
                        }(e, o), isNaN(n) && (n = f.getBestMask(e, h.bind(null, e, t))), f.applyMask(n, e), h(e, t, n), {
                            modules: e,
                            version: u,
                            errorCorrectionLevel: t,
                            maskPattern: n,
                            segments: r
                        }
                }
                t.create = function(e, t) {
                    if (void 0 === e || "" === e) throw new Error("No input text");
                    var n, r, a = o.M;
                    return void 0 !== t && (a = o.from(t.errorCorrectionLevel, o.M), n = d.from(t.version), r = f.from(t.maskPattern), t.toSJISFunc && S.setToSJISFunction(t.toSJISFunc)), g(e, n, a, r)
                }
            },
            630: function(e, t, n) {
                var r = n(378);

                function a(e) {
                    this.genPoly = void 0, this.degree = e, this.degree && this.initialize(this.degree)
                }
                a.prototype.initialize = function(e) {
                    this.degree = e, this.genPoly = r.generateECPolynomial(this.degree)
                }, a.prototype.encode = function(e) {
                    if (!this.genPoly) throw new Error("Encoder not initialized");
                    var t = new Uint8Array(e.length + this.degree);
                    t.set(e);
                    var n = r.mod(t, this.genPoly),
                        e = this.degree - n.length;
                    if (0 < e) {
                        t = new Uint8Array(this.degree);
                        return t.set(n, e), t
                    }
                    return n
                }, e.exports = a
            },
            598: function(e, t) {
                var n = "(?:[u3000-u303F]|[u3040-u309F]|[u30A0-u30FF]|[uFF00-uFFEF]|[u4E00-u9FAF]|[u2605-u2606]|[u2190-u2195]|u203B|[u2010u2015u2018u2019u2025u2026u201Cu201Du2225u2260]|[u0391-u0451]|[u00A7u00A8u00B1u00B4u00D7u00F7])+",
                    r = "(?:(?![A-Z0-9 $%*+\\-./:]|" + (n = n.replace(/u/g, "\\u")) + ")(?:.|[\r\n]))+";
                t.KANJI = new RegExp(n, "g"), t.BYTE_KANJI = new RegExp("[^A-Z0-9 $%*+\\-./:]+", "g"), t.BYTE = new RegExp(r, "g"), t.NUMERIC = new RegExp("[0-9]+", "g"), t.ALPHANUMERIC = new RegExp("[A-Z $%*+\\-./:]+", "g");
                var a = new RegExp("^" + n + "$"),
                    o = new RegExp("^[0-9]+$"),
                    i = new RegExp("^[A-Z0-9 $%*+\\-./:]+$");
                t.testKanji = function(e) {
                    return a.test(e)
                }, t.testNumeric = function(e) {
                    return o.test(e)
                }, t.testAlphanumeric = function(e) {
                    return i.test(e)
                }
            },
            59: function(e, i, t) {
                var m = t(937),
                    r = t(758),
                    a = t(224),
                    o = t(823),
                    c = t(57),
                    u = t(598),
                    l = t(814),
                    s = t(512);

                function f(e) {
                    return unescape(encodeURIComponent(e)).length
                }

                function d(e, t, n) {
                    for (var r, a = []; null !== (r = e.exec(n));) a.push({
                        data: r[0],
                        index: r.index,
                        mode: t,
                        length: r[0].length
                    });
                    return a
                }

                function p(e) {
                    var t, n = d(u.NUMERIC, m.NUMERIC, e),
                        r = d(u.ALPHANUMERIC, m.ALPHANUMERIC, e),
                        e = l.isKanjiModeEnabled() ? (t = d(u.BYTE, m.BYTE, e), d(u.KANJI, m.KANJI, e)) : (t = d(u.BYTE_KANJI, m.BYTE, e), []);
                    return n.concat(r, t, e).sort(function(e, t) {
                        return e.index - t.index
                    }).map(function(e) {
                        return {
                            data: e.data,
                            mode: e.mode,
                            length: e.length
                        }
                    })
                }

                function h(e, t) {
                    switch (t) {
                        case m.NUMERIC:
                            return r.getBitsLength(e);
                        case m.ALPHANUMERIC:
                            return a.getBitsLength(e);
                        case m.KANJI:
                            return c.getBitsLength(e);
                        case m.BYTE:
                            return o.getBitsLength(e)
                    }
                }

                function n(e, t) {
                    var n = m.getBestModeForData(e),
                        t = m.from(t, n);
                    if (t !== m.BYTE && t.bit < n.bit) throw new Error('"' + e + '" cannot be encoded with mode ' + m.toString(t) + ".\n Suggested mode is: " + m.toString(n));
                    switch (t !== m.KANJI || l.isKanjiModeEnabled() || (t = m.BYTE), t) {
                        case m.NUMERIC:
                            return new r(e);
                        case m.ALPHANUMERIC:
                            return new a(e);
                        case m.KANJI:
                            return new c(e);
                        case m.BYTE:
                            return new o(e)
                    }
                }
                i.fromArray = function(e) {
                    return e.reduce(function(e, t) {
                        return "string" == typeof t ? e.push(n(t, null)) : t.data && e.push(n(t.data, t.mode)), e
                    }, [])
                }, i.fromString = function(e, t) {
                    for (var n = function(e, t) {
                            for (var n = {}, r = {
                                    start: {}
                                }, a = ["start"], o = 0; o < e.length; o++) {
                                for (var i = e[o], c = [], u = 0; u < i.length; u++) {
                                    var l = i[u],
                                        s = "" + o + u;
                                    c.push(s), n[s] = {
                                        node: l,
                                        lastCount: 0
                                    }, r[s] = {};
                                    for (var f = 0; f < a.length; f++) {
                                        var d = a[f];
                                        n[d] && n[d].node.mode === l.mode ? (r[d][s] = h(n[d].lastCount + l.length, l.mode) - h(n[d].lastCount, l.mode), n[d].lastCount += l.length) : (n[d] && (n[d].lastCount = l.length), r[d][s] = h(l.length, l.mode) + 4 + m.getCharCountIndicator(l.mode, t))
                                    }
                                }
                                a = c
                            }
                            for (var p = 0; p < a.length; p++) r[a[p]].end = 0;
                            return {
                                map: r,
                                table: n
                            }
                        }(function(e) {
                            for (var t = [], n = 0; n < e.length; n++) {
                                var r = e[n];
                                switch (r.mode) {
                                    case m.NUMERIC:
                                        t.push([r, {
                                            data: r.data,
                                            mode: m.ALPHANUMERIC,
                                            length: r.length
                                        }, {
                                            data: r.data,
                                            mode: m.BYTE,
                                            length: r.length
                                        }]);
                                        break;
                                    case m.ALPHANUMERIC:
                                        t.push([r, {
                                            data: r.data,
                                            mode: m.BYTE,
                                            length: r.length
                                        }]);
                                        break;
                                    case m.KANJI:
                                        t.push([r, {
                                            data: r.data,
                                            mode: m.BYTE,
                                            length: f(r.data)
                                        }]);
                                        break;
                                    case m.BYTE:
                                        t.push([{
                                            data: r.data,
                                            mode: m.BYTE,
                                            length: f(r.data)
                                        }])
                                }
                            }
                            return t
                        }(p(e, l.isKanjiModeEnabled())), t), r = s.find_path(n.map, "start", "end"), a = [], o = 1; o < r.length - 1; o++) a.push(n.table[r[o]].node);
                    return i.fromArray(a.reduce(function(e, t) {
                        var n = 0 <= e.length - 1 ? e[e.length - 1] : null;
                        return n && n.mode === t.mode ? e[e.length - 1].data += t.data : e.push(t), e
                    }, []))
                }, i.rawSplit = function(e) {
                    return i.fromArray(p(e, l.isKanjiModeEnabled()))
                }
            },
            814: function(e, t) {
                var n, r = [0, 26, 44, 70, 100, 134, 172, 196, 242, 292, 346, 404, 466, 532, 581, 655, 733, 815, 901, 991, 1085, 1156, 1258, 1364, 1474, 1588, 1706, 1828, 1921, 2051, 2185, 2323, 2465, 2611, 2761, 2876, 3034, 3196, 3362, 3532, 3706];
                t.getSymbolSize = function(e) {
                    if (!e) throw new Error('"version" cannot be null or undefined');
                    if (e < 1 || 40 < e) throw new Error('"version" should be in range from 1 to 40');
                    return 4 * e + 17
                }, t.getSymbolTotalCodewords = function(e) {
                    return r[e]
                }, t.getBCHDigit = function(e) {
                    for (var t = 0; 0 !== e;) t++, e >>>= 1;
                    return t
                }, t.setToSJISFunction = function(e) {
                    if ("function" != typeof e) throw new Error('"toSJISFunc" is not a valid function.');
                    n = e
                }, t.isKanjiModeEnabled = function() {
                    return void 0 !== n
                }, t.toSJIS = function(e) {
                    return n(e)
                }
            },
            148: function(e, t) {
                t.isValid = function(e) {
                    return !isNaN(e) && 1 <= e && e <= 40
                }
            },
            701: function(e, a, t) {
                var o = t(814),
                    i = t(889),
                    r = t(422),
                    c = t(937),
                    u = t(148),
                    n = o.getBCHDigit(7973);

                function l(e, t) {
                    return c.getCharCountIndicator(e, t) + 4
                }

                function s(e, t) {
                    for (var n = 1; n <= 40; n++)
                        if (function(e, n) {
                                var r = 0;
                                return e.forEach(function(e) {
                                    var t = l(e.mode, n);
                                    r += t + e.getBitsLength()
                                }), r
                            }(e, n) <= a.getCapacity(n, t, c.MIXED)) return n
                }
                a.from = function(e, t) {
                    return u.isValid(e) ? parseInt(e, 10) : t
                }, a.getCapacity = function(e, t, n) {
                    if (!u.isValid(e)) throw new Error("Invalid QR Code version");
                    void 0 === n && (n = c.BYTE);
                    t = 8 * (o.getSymbolTotalCodewords(e) - i.getTotalCodewordsCount(e, t));
                    if (n === c.MIXED) return t;
                    var r = t - l(n, e);
                    switch (n) {
                        case c.NUMERIC:
                            return Math.floor(r / 10 * 3);
                        case c.ALPHANUMERIC:
                            return Math.floor(r / 11 * 2);
                        case c.KANJI:
                            return Math.floor(r / 13);
                        case c.BYTE:
                        default:
                            return Math.floor(r / 8)
                    }
                }, a.getBestVersionForData = function(e, t) {
                    var n, t = r.from(t, r.M);
                    if (Array.isArray(e)) {
                        if (1 < e.length) return s(e, t);
                        if (0 === e.length) return 1;
                        n = e[0]
                    } else n = e;
                    return function(e, t, n) {
                        for (var r = 1; r <= 40; r++)
                            if (t <= a.getCapacity(r, n, e)) return r
                    }(n.mode, n.getLength(), t)
                }, a.getEncodedBits = function(e) {
                    if (!u.isValid(e) || e < 7) throw new Error("Invalid QR Code version");
                    for (var t = e << 12; 0 <= o.getBCHDigit(t) - n;) t ^= 7973 << o.getBCHDigit(t) - n;
                    return e << 12 | t
                }
            },
            895: function(e, r, t) {
                var i = t(467);
                r.render = function(e, t, n) {
                    var r = n,
                        a = t;
                    void 0 !== r || t && t.getContext || (r = t, t = void 0), t || (a = function() {
                        try {
                            return document.createElement("canvas")
                        } catch (e) {
                            throw new Error("You need to specify a canvas element")
                        }
                    }()), r = i.getOptions(r);
                    var o = i.getImageWidth(e.modules.size, r),
                        n = a.getContext("2d"),
                        t = n.createImageData(o, o);
                    return i.qrToImageData(t.data, e, r), r = a, o = o, n.clearRect(0, 0, r.width, r.height), r.style || (r.style = {}), r.height = o, r.width = o, r.style.height = o + "px", r.style.width = o + "px", n.putImageData(t, 0, 0), a
                }, r.renderToDataURL = function(e, t, n) {
                    void 0 !== n || t && t.getContext || (n = t, t = void 0), n = n || {};
                    e = r.render(e, t, n), t = n.type || "image/png", n = n.rendererOpts || {};
                    return e.toDataURL(t, n.quality)
                }
            },
            398: function(e, t, n) {
                var i = n(467);

                function c(e, t) {
                    var n = e.a / 255,
                        e = t + '="' + e.hex + '"';
                    return n < 1 ? e + " " + t + '-opacity="' + n.toFixed(2).slice(1) + '"' : e
                }

                function s(e, t, n) {
                    t = e + t;
                    return void 0 !== n && (t += " " + n), t
                }
                t.render = function(e, t, n) {
                    var r = i.getOptions(t),
                        a = e.modules.size,
                        o = e.modules.data,
                        t = a + 2 * r.margin,
                        e = r.color.light.a ? "<path " + c(r.color.light, "fill") + ' d="M0 0h' + t + "v" + t + 'H0z"/>' : "",
                        a = "<path " + c(r.color.dark, "stroke") + ' d="' + function(e, t, n) {
                            for (var r = "", a = 0, o = !1, i = 0, c = 0; c < e.length; c++) {
                                var u = Math.floor(c % t),
                                    l = Math.floor(c / t);
                                u || o || (o = !0), e[c] ? (i++, 0 < c && 0 < u && e[c - 1] || (r += o ? s("M", u + n, .5 + l + n) : s("m", a, 0), a = 0, o = !1), u + 1 < t && e[c + 1] || (r += s("h", i), i = 0)) : a++
                            }
                            return r
                        }(o, a, r.margin) + '"/>',
                        t = 'viewBox="0 0 ' + t + " " + t + '"',
                        a = '<svg xmlns="http://www.w3.org/2000/svg" ' + (r.width ? 'width="' + r.width + '" height="' + r.width + '" ' : "") + t + ' shape-rendering="crispEdges">' + e + a + "</svg>\n";
                    return "function" == typeof n && n(null, a), a
                }
            },
            467: function(e, p) {
                function a(e) {
                    if ("number" == typeof e && (e = e.toString()), "string" != typeof e) throw new Error("Color should be defined as hex string");
                    var t = e.slice().replace("#", "").split("");
                    if (t.length < 3 || 5 === t.length || 8 < t.length) throw new Error("Invalid hex color: " + e);
                    3 !== t.length && 4 !== t.length || (t = Array.prototype.concat.apply([], t.map(function(e) {
                        return [e, e]
                    }))), 6 === t.length && t.push("F", "F");
                    e = parseInt(t.join(""), 16);
                    return {
                        r: e >> 24 & 255,
                        g: e >> 16 & 255,
                        b: e >> 8 & 255,
                        a: 255 & e,
                        hex: "#" + t.slice(0, 6).join("")
                    }
                }
                p.getOptions = function(e) {
                    (e = e || {}).color || (e.color = {});
                    var t = void 0 === e.margin || null === e.margin || e.margin < 0 ? 4 : e.margin,
                        n = e.width && 21 <= e.width ? e.width : void 0,
                        r = e.scale || 4;
                    return {
                        width: n,
                        scale: n ? 4 : r,
                        margin: t,
                        color: {
                            dark: a(e.color.dark || "#000000ff"),
                            light: a(e.color.light || "#ffffffff")
                        },
                        type: e.type,
                        rendererOpts: e.rendererOpts || {}
                    }
                }, p.getScale = function(e, t) {
                    return t.width && t.width >= e + 2 * t.margin ? t.width / (e + 2 * t.margin) : t.scale
                }, p.getImageWidth = function(e, t) {
                    var n = p.getScale(e, t);
                    return Math.floor((e + 2 * t.margin) * n)
                }, p.qrToImageData = function(e, t, n) {
                    for (var r = t.modules.size, a = t.modules.data, o = p.getScale(r, n), i = Math.floor((r + 2 * n.margin) * o), c = n.margin * o, u = [n.color.light, n.color.dark], l = 0; l < i; l++)
                        for (var s = 0; s < i; s++) {
                            var f = 4 * (l * i + s),
                                d = n.color.light;
                            c <= l && c <= s && l < i - c && s < i - c && (d = u[a[Math.floor((l - c) / o) * r + Math.floor((s - c) / o)] ? 1 : 0]), e[f++] = d.r, e[f++] = d.g, e[f++] = d.b, e[f] = d.a
                        }
                }
            },
            779: function(e, t) {
                var n;
                /*!
                	Copyright (c) 2018 Jed Watson.
                	Licensed under the MIT License (MIT), see
                	http://jedwatson.github.io/classnames
                */
                ! function() {
                    "use strict";
                    var i = {}.hasOwnProperty;

                    function c() {
                        for (var e = [], t = 0; t < arguments.length; t++) {
                            var n = arguments[t];
                            if (n) {
                                var r, a = typeof n;
                                if ("string" == a || "number" == a) e.push(n);
                                else if (Array.isArray(n)) !n.length || (r = c.apply(null, n)) && e.push(r);
                                else if ("object" == a)
                                    if (n.toString === Object.prototype.toString || n.toString.toString().includes("[native code]"))
                                        for (var o in n) i.call(n, o) && n[o] && e.push(o);
                                    else e.push(n.toString())
                            }
                        }
                        return e.join(" ")
                    }
                    e.exports ? (c.default = c, e.exports = c) : void 0 === (n = function() {
                        return c
                    }.apply(t, [])) || (e.exports = n)
                }()
            },
            804: function(e) {
                "use strict";
                e.exports = React
            }
        },
        r = {};

    function Kr(e) {
        if (r[e]) return r[e].exports;
        var t = r[e] = {
            exports: {}
        };
        return n[e](t, t.exports, Kr), t.exports
    }
    Kr.n = function(e) {
            var t = e && e.__esModule ? function() {
                return e.default
            } : function() {
                return e
            };
            return Kr.d(t, {
                a: t
            }), t
        }, Kr.d = function(e, t) {
            for (var n in t) Kr.o(t, n) && !Kr.o(e, n) && Object.defineProperty(e, n, {
                enumerable: !0,
                get: t[n]
            })
        }, Kr.g = function() {
            if ("object" == typeof globalThis) return globalThis;
            try {
                return this || new Function("return this")()
            } catch (e) {
                if ("object" == typeof window) return window
            }
        }(), Kr.o = function(e, t) {
            return Object.prototype.hasOwnProperty.call(e, t)
        },
        function() {
            "use strict";
            var w = Kr(804),
                S = Kr.n(w),
                e = Roblox,
                t = Kr.n(e),
                n = ReactDOM,
                i = CoreUtilities,
                r = "access-management-upsell-container",
                a = ReactUtilities,
                o = Kr(644),
                c = Kr(626),
                u = function(e) {
                    e()
                },
                l = function() {
                    return u
                },
                s = Symbol.for("react-redux-context"),
                f = "undefined" != typeof globalThis ? globalThis : {};

            function d() {
                if (!w.createContext) return {};
                var e = null != (t = f[s]) ? t : f[s] = new Map,
                    t = e.get(w.createContext);
                return t || (t = w.createContext(null), e.set(w.createContext, t)), t
            }
            var p = d();

            function m(e) {
                var t = 0 < arguments.length && void 0 !== e ? e : p;
                return function() {
                    return (0, w.useContext)(t)
                }
            }

            function h() {
                throw new Error("uSES not initialized!")
            }
            var v = m();

            function g(e, t) {
                return e === t
            }
            var y = h;

            function b(e) {
                var e = 0 < arguments.length && void 0 !== e ? e : p,
                    s = e === p ? v : m(e);
                return function(t, e) {
                    var n = 1 < arguments.length && void 0 !== e ? e : {},
                        r = "function" == typeof n ? {
                            equalityFn: n
                        } : n,
                        a = r.equalityFn,
                        o = void 0 === a ? g : a,
                        i = r.stabilityCheck,
                        c = void 0 === i ? void 0 : i,
                        u = r.noopCheck;
                    var l = s(),
                        e = l.store,
                        n = l.subscription,
                        a = l.getServerState,
                        i = l.stabilityCheck,
                        c = (l.noopCheck, (0, w.useRef)(!0), (0, w.useCallback)((r = {}, u = t.name, l = function(e) {
                            return t(e)
                        }, u in r ? Object.defineProperty(r, u, {
                            value: l,
                            enumerable: !0,
                            configurable: !0,
                            writable: !0
                        }) : r[u] = l, r)[t.name], [t, i, c])),
                        o = y(n.addNestedSub, e.getState, a || e.getState, c, o);
                    return (0, w.useDebugValue)(o), o
                }
            }
            var E = b();
            Kr(508), Kr(386);
            var C = {
                notify: function() {},
                get: function() {
                    return []
                }
            };

            function A(t, n) {
                var o, i = C;

                function c() {
                    e.onStateChange && e.onStateChange()
                }

                function r() {
                    var e, r, a;
                    o || (o = n ? n.addNestedSub(c) : t.subscribe(c), e = l(), a = r = null, i = {
                        clear: function() {
                            a = r = null
                        },
                        notify: function() {
                            e(function() {
                                for (var e = r; e;) e.callback(), e = e.next
                            })
                        },
                        get: function() {
                            for (var e = [], t = r; t;) e.push(t), t = t.next;
                            return e
                        },
                        subscribe: function(e) {
                            var t = !0,
                                n = a = {
                                    callback: e,
                                    next: null,
                                    prev: a
                                };
                            return n.prev ? n.prev.next = n : r = n,
                                function() {
                                    t && null !== r && (t = !1, n.next ? n.next.prev = n.prev : a = n.prev, n.prev ? n.prev.next = n.next : r = n.next)
                                }
                        }
                    })
                }
                var e = {
                    addNestedSub: function(e) {
                        return r(), i.subscribe(e)
                    },
                    notifyNestedSubs: function() {
                        i.notify()
                    },
                    handleChangeWrapper: c,
                    isSubscribed: function() {
                        return Boolean(o)
                    },
                    trySubscribe: r,
                    tryUnsubscribe: function() {
                        o && (o(), o = void 0, i.clear(), i = C)
                    },
                    getListeners: function() {
                        return i
                    }
                };
                return e
            }
            var P = !("undefined" == typeof window || void 0 === window.document || void 0 === window.document.createElement) ? w.useLayoutEffect : w.useEffect;

            function I(e) {
                var t = e.store,
                    n = e.context,
                    r = e.children,
                    a = e.serverState,
                    o = e.stabilityCheck,
                    i = void 0 === o ? "once" : o,
                    c = void 0 === (e = e.noopCheck) ? "once" : e,
                    u = w.useMemo(function() {
                        var e = A(t);
                        return {
                            store: t,
                            subscription: e,
                            getServerState: a ? function() {
                                return a
                            } : void 0,
                            stabilityCheck: i,
                            noopCheck: c
                        }
                    }, [t, a, i, c]),
                    l = w.useMemo(function() {
                        return t.getState()
                    }, [t]);
                return P(function() {
                    var e = u.subscription;
                    return e.onStateChange = e.notifyNestedSubs, e.trySubscribe(), l !== t.getState() && e.notifyNestedSubs(),
                        function() {
                            e.tryUnsubscribe(), e.onStateChange = void 0
                        }
                }, [u, l]), n = n || p, w.createElement(n.Provider, {
                    value: u
                }, r)
            }

            function k(e) {
                var e = 0 < arguments.length && void 0 !== e ? e : p,
                    t = e === p ? v : m(e);
                return function() {
                    return t().store
                }
            }
            var x = k();

            function N(e) {
                var e = 0 < arguments.length && void 0 !== e ? e : p,
                    t = e === p ? x : k(e);
                return function() {
                    return t().dispatch
                }
            }
            var T, M = N();
            T = c.useSyncExternalStoreWithSelector, y = T, o.useSyncExternalStore, T = n.unstable_batchedUpdates, u = T;
            var R = ReactStyleGuide;

            function L(e) {
                for (var t = arguments.length, n = Array(1 < t ? t - 1 : 0), r = 1; r < t; r++) n[r - 1] = arguments[r];
                throw Error("[Immer] minified error nr: " + e + (n.length ? " " + n.map(function(e) {
                    return "'" + e + "'"
                }).join(",") : "") + ". Find the full error at: https://bit.ly/3cXEKWf")
            }

            function D(e) {
                return e && e[be]
            }

            function O(e) {
                var t;
                return e && (function(e) {
                    if (e && "object" == typeof e) {
                        e = Object.getPrototypeOf(e);
                        if (null === e) return 1;
                        e = Object.hasOwnProperty.call(e, "constructor") && e.constructor;
                        return e === Object || "function" == typeof e && Function.toString.call(e) === Ee
                    }
                }(e) || Array.isArray(e) || e[ye] || null !== (t = e.constructor) && void 0 !== t && t[ye] || q(e) || H(e))
            }

            function U(n, r, t) {
                void 0 === t && (t = !1), 0 === V(n) ? (t ? Object.keys : we)(n).forEach(function(e) {
                    t && "symbol" == typeof e || r(e, n[e], n)
                }) : n.forEach(function(e, t) {
                    return r(t, e, n)
                })
            }

            function V(e) {
                var t = e[be];
                return t ? 3 < t.i ? t.i - 4 : t.i : Array.isArray(e) ? 1 : q(e) ? 2 : H(e) ? 3 : 0
            }

            function B(e, t) {
                return 2 === V(e) ? e.has(t) : Object.prototype.hasOwnProperty.call(e, t)
            }

            function F(e, t) {
                return 2 === V(e) ? e.get(t) : e[t]
            }

            function j(e, t, n) {
                var r = V(e);
                2 === r ? e.set(t, n) : 3 === r ? e.add(n) : e[t] = n
            }

            function _(e, t) {
                return e === t ? 0 !== e || 1 / e == 1 / t : e != e && t != t
            }

            function q(e) {
                return me && e instanceof Map
            }

            function H(e) {
                return he && e instanceof Set
            }

            function z(e) {
                return e.o || e.t
            }

            function K(e) {
                if (Array.isArray(e)) return Array.prototype.slice.call(e);
                var t = Se(e);
                delete t[be];
                for (var n = we(t), r = 0; r < n.length; r++) {
                    var a = n[r],
                        o = t[a];
                    !1 === o.writable && (o.writable = !0, o.configurable = !0), (o.get || o.set) && (t[a] = {
                        configurable: !0,
                        writable: !0,
                        enumerable: o.enumerable,
                        value: e[a]
                    })
                }
                return Object.create(Object.getPrototypeOf(e), t)
            }

            function G(e, t) {
                return void 0 === t && (t = !1), W(e) || D(e) || !O(e) || (1 < V(e) && (e.set = e.add = e.clear = e.delete = $), Object.freeze(e), t && U(e, function(e, t) {
                    return G(t, !0)
                }, !0)), e
            }

            function $() {
                L(2)
            }

            function W(e) {
                return null == e || "object" != typeof e || Object.isFrozen(e)
            }

            function Y(e) {
                var t = Ce[e];
                return t || L(18, e), t
            }

            function J(e, t) {
                Ce[e] || (Ce[e] = t)
            }

            function Q(e, t) {
                t && (Y("Patches"), e.u = [], e.s = [], e.v = t)
            }

            function X(e) {
                Z(e), e.p.forEach(te), e.p = null
            }

            function Z(e) {
                e === pe && (pe = e.l)
            }

            function ee(e) {
                return pe = {
                    p: [],
                    l: pe,
                    h: e,
                    m: !0,
                    _: 0
                }
            }

            function te(e) {
                e = e[be];
                0 === e.i || 1 === e.i ? e.j() : e.g = !0
            }

            function ne(e, t) {
                t._ = t.p.length;
                var n = t.p[0],
                    r = void 0 !== e && e !== n;
                return t.h.O || Y("ES5").S(t, e, r), r ? (n[be].P && (X(t), L(4)), O(e) && (e = re(t, e), t.l || oe(t, e)), t.u && Y("Patches").M(n[be].t, e, t.u, t.s)) : e = re(t, n, []), X(t), t.u && t.v(t.u, t.s), e !== ge ? e : void 0
            }

            function re(n, r, a) {
                if (W(r)) return r;
                var o, e, i, c = r[be];
                return c ? c.A !== n ? r : c.P ? (c.I || (c.I = !0, c.A._--, e = o = 4 === c.i || 5 === c.i ? c.o = K(c.k) : c.o, i = !1, 3 === c.i && (e = new Set(o), o.clear(), i = !0), U(e, function(e, t) {
                    return ae(n, c, o, e, t, a, i)
                }), oe(n, o, !1), a && n.u && Y("Patches").N(c, a, n.u, n.s)), c.o) : (oe(n, c.t, !0), c.t) : (U(r, function(e, t) {
                    return ae(n, c, r, e, t, a)
                }, !0), r)
            }

            function ae(e, t, n, r, a, o, i) {
                if (D(a)) {
                    o = re(e, a, o && t && 3 !== t.i && !B(t.R, r) ? o.concat(r) : void 0);
                    if (j(n, r, o), !D(o)) return;
                    e.m = !1
                } else i && n.add(a);
                O(a) && !W(a) && (!e.h.D && e._ < 1 || (re(e, a), t && t.A.l || oe(e, a)))
            }

            function oe(e, t, n) {
                void 0 === n && (n = !1), !e.l && e.h.D && e.m && G(t, n)
            }

            function ie(e, t) {
                var n = e[be];
                return (n ? z(n) : e)[t]
            }

            function ce(e, t) {
                if (t in e)
                    for (var n = Object.getPrototypeOf(e); n;) {
                        var r = Object.getOwnPropertyDescriptor(n, t);
                        if (r) return r;
                        n = Object.getPrototypeOf(n)
                    }
            }

            function ue(e) {
                e.P || (e.P = !0, e.l && ue(e.l))
            }

            function le(e) {
                e.o || (e.o = K(e.t))
            }

            function se(e, t, n) {
                t = q(t) ? Y("MapSet").F(t, n) : H(t) ? Y("MapSet").T(t, n) : e.O ? function(e, t) {
                    var n = Array.isArray(e),
                        r = {
                            i: n ? 1 : 0,
                            A: t ? t.A : pe,
                            P: !1,
                            I: !1,
                            R: {},
                            l: t,
                            t: e,
                            k: null,
                            o: null,
                            j: null,
                            C: !1
                        },
                        t = r,
                        e = Ae;
                    n && (t = [r], e = Pe);
                    t = Proxy.revocable(t, e), e = t.revoke, t = t.proxy;
                    return r.k = t, r.j = e, t
                }(t, n) : Y("ES5").J(t, n);
                return (n ? n.A : pe).p.push(t), t
            }

            function fe(e, t) {
                switch (t) {
                    case 2:
                        return new Map(e);
                    case 3:
                        return Array.from(e)
                }
                return K(e)
            }

            function de() {
                function u(n, e) {
                    var t = o[n];
                    return t ? t.enumerable = e : o[n] = t = {
                        configurable: !0,
                        enumerable: e,
                        get: function() {
                            var e = this[be];
                            return Ae.get(e, n)
                        },
                        set: function(e) {
                            var t = this[be];
                            Ae.set(t, n, e)
                        }
                    }, t
                }

                function r(e) {
                    for (var t = e.length - 1; 0 <= t; t--) {
                        var n = e[t][be];
                        if (!n.P) switch (n.i) {
                            case 5:
                                s(n) && ue(n);
                                break;
                            case 4:
                                a(n) && ue(n)
                        }
                    }
                }

                function a(e) {
                    for (var t = e.t, n = e.k, r = we(n), a = r.length - 1; 0 <= a; a--) {
                        var o = r[a];
                        if (o !== be) {
                            var i = t[o];
                            if (void 0 === i && !B(t, o)) return !0;
                            var c = n[o],
                                o = c && c[be];
                            if (o ? o.t !== i : !_(c, i)) return !0
                        }
                    }
                    e = !!t[be];
                    return r.length !== we(t).length + (e ? 0 : 1)
                }

                function s(e) {
                    var t = e.k;
                    if (t.length !== e.t.length) return !0;
                    e = Object.getOwnPropertyDescriptor(t, t.length - 1);
                    if (e && !e.get) return !0;
                    for (var n = 0; n < t.length; n++)
                        if (!t.hasOwnProperty(n)) return !0;
                    return !1
                }
                var o = {};
                J("ES5", {
                    J: function(e, t) {
                        var n = Array.isArray(e),
                            r = function(e, t) {
                                if (e) {
                                    for (var n = Array(t.length), r = 0; r < t.length; r++) Object.defineProperty(n, "" + r, u(r, !0));
                                    return n
                                }
                                var a = Se(t);
                                delete a[be];
                                for (var o = we(a), i = 0; i < o.length; i++) {
                                    var c = o[i];
                                    a[c] = u(c, e || !!a[c].enumerable)
                                }
                                return Object.create(Object.getPrototypeOf(t), a)
                            }(n, e),
                            e = {
                                i: n ? 5 : 4,
                                A: t ? t.A : pe,
                                P: !1,
                                I: !1,
                                R: {},
                                l: t,
                                t: e,
                                k: r,
                                o: null,
                                g: !1,
                                C: !1
                            };
                        return Object.defineProperty(r, be, {
                            value: e,
                            writable: !0
                        }), r
                    },
                    S: function(e, t, n) {
                        n ? D(t) && t[be].A === e && r(e.p) : (e.u && function t(e) {
                            if (e && "object" == typeof e) {
                                var n = e[be];
                                if (n) {
                                    var r = n.t,
                                        a = n.k,
                                        o = n.R,
                                        e = n.i;
                                    if (4 === e) U(a, function(e) {
                                        e !== be && (void 0 !== r[e] || B(r, e) ? o[e] || t(a[e]) : (o[e] = !0, ue(n)))
                                    }), U(r, function(e) {
                                        void 0 !== a[e] || B(a, e) || (o[e] = !1, ue(n))
                                    });
                                    else if (5 === e) {
                                        if (s(n) && (ue(n), o.length = !0), a.length < r.length)
                                            for (var i = a.length; i < r.length; i++) o[i] = !1;
                                        else
                                            for (var c = r.length; c < a.length; c++) o[c] = !0;
                                        for (var u = Math.min(a.length, r.length), l = 0; l < u; l++) a.hasOwnProperty(l) || (o[l] = !0), void 0 === o[l] && t(a[l])
                                    }
                                }
                            }
                        }(e.p[0]), r(e.p))
                    },
                    K: function(e) {
                        return (4 === e.i ? a : s)(e)
                    }
                })
            }
            var pe, c = "undefined" != typeof Symbol && "symbol" == typeof Symbol("x"),
                me = "undefined" != typeof Map,
                he = "undefined" != typeof Set,
                ve = "undefined" != typeof Proxy && void 0 !== Proxy.revocable && "undefined" != typeof Reflect,
                ge = c ? Symbol.for("immer-nothing") : ((De = {})["immer-nothing"] = !0, De),
                ye = c ? Symbol.for("immer-draftable") : "__$immer_draftable",
                be = c ? Symbol.for("immer-state") : "__$immer_state",
                Ee = "" + Object.prototype.constructor,
                we = "undefined" != typeof Reflect && Reflect.ownKeys ? Reflect.ownKeys : void 0 !== Object.getOwnPropertySymbols ? function(e) {
                    return Object.getOwnPropertyNames(e).concat(Object.getOwnPropertySymbols(e))
                } : Object.getOwnPropertyNames,
                Se = Object.getOwnPropertyDescriptors || function(t) {
                    var n = {};
                    return we(t).forEach(function(e) {
                        n[e] = Object.getOwnPropertyDescriptor(t, e)
                    }), n
                },
                Ce = {},
                Ae = {
                    get: function(e, t) {
                        if (t === be) return e;
                        var n, r, a = z(e);
                        if (!B(a, t)) return n = e, (r = ce(a, t)) ? "value" in r ? r.value : null === (r = r.get) || void 0 === r ? void 0 : r.call(n.k) : void 0;
                        a = a[t];
                        return !e.I && O(a) && a === ie(e.t, t) ? (le(e), e.o[t] = se(e.A.h, a, e)) : a
                    },
                    has: function(e, t) {
                        return t in z(e)
                    },
                    ownKeys: function(e) {
                        return Reflect.ownKeys(z(e))
                    },
                    set: function(e, t, n) {
                        var r = ce(z(e), t);
                        if (null != r && r.set) return r.set.call(e.k, n), !0;
                        if (!e.P) {
                            var a = ie(z(e), t),
                                r = null == a ? void 0 : a[be];
                            if (r && r.t === n) return e.o[t] = n, !(e.R[t] = !1);
                            if (_(n, a) && (void 0 !== n || B(e.t, t))) return !0;
                            le(e), ue(e)
                        }
                        return e.o[t] === n && (void 0 !== n || t in e.o) || Number.isNaN(n) && Number.isNaN(e.o[t]) || (e.o[t] = n, e.R[t] = !0), !0
                    },
                    deleteProperty: function(e, t) {
                        return void 0 !== ie(e.t, t) || t in e.t ? (e.R[t] = !1, le(e), ue(e)) : delete e.R[t], e.o && delete e.o[t], !0
                    },
                    getOwnPropertyDescriptor: function(e, t) {
                        var n = z(e),
                            r = Reflect.getOwnPropertyDescriptor(n, t);
                        return r && {
                            writable: !0,
                            configurable: 1 !== e.i || "length" !== t,
                            enumerable: r.enumerable,
                            value: n[t]
                        }
                    },
                    defineProperty: function() {
                        L(11)
                    },
                    getPrototypeOf: function(e) {
                        return Object.getPrototypeOf(e.t)
                    },
                    setPrototypeOf: function() {
                        L(12)
                    }
                },
                Pe = {};

            function Ie(e) {
                var f = this;
                this.O = ve, this.D = !0, this.produce = function(e, o, t) {
                    if ("function" == typeof e && "function" != typeof o) {
                        var i = o;
                        o = e;
                        var c = f;
                        return function(e) {
                            var t = this;
                            void 0 === e && (e = i);
                            for (var n = arguments.length, r = Array(1 < n ? n - 1 : 0), a = 1; a < n; a++) r[a - 1] = arguments[a];
                            return c.produce(e, function(e) {
                                return o.call.apply(o, [t, e].concat(r))
                            })
                        }
                    }
                    var n, r, a;
                    if ("function" != typeof o && L(6), void 0 !== t && "function" != typeof t && L(7), O(e)) {
                        var u = ee(f),
                            l = se(f, e, void 0),
                            s = !0;
                        try {
                            n = o(l), s = !1
                        } finally {
                            (s ? X : Z)(u)
                        }
                        return "undefined" != typeof Promise && n instanceof Promise ? n.then(function(e) {
                            return Q(u, t), ne(e, u)
                        }, function(e) {
                            throw X(u), e
                        }) : (Q(u, t), ne(n, u))
                    }
                    if (!e || "object" != typeof e) return void 0 === (n = o(e)) && (n = e), n === ge && (n = void 0), f.D && G(n, !0), t && (r = [], a = [], Y("Patches").M(e, n, r, a), t(r, a)), n;
                    L(21, e)
                }, this.produceWithPatches = function(a, e) {
                    if ("function" == typeof a) return function(e) {
                        for (var t = arguments.length, n = Array(1 < t ? t - 1 : 0), r = 1; r < t; r++) n[r - 1] = arguments[r];
                        return f.produceWithPatches(e, function(e) {
                            return a.apply(void 0, [e].concat(n))
                        })
                    };
                    var n, r, e = f.produce(a, e, function(e, t) {
                        n = e, r = t
                    });
                    return "undefined" != typeof Promise && e instanceof Promise ? e.then(function(e) {
                        return [e, n, r]
                    }) : [e, n, r]
                }, "boolean" == typeof(null == e ? void 0 : e.useProxies) && this.setUseProxies(e.useProxies), "boolean" == typeof(null == e ? void 0 : e.autoFreeze) && this.setAutoFreeze(e.autoFreeze)
            }
            U(Ae, function(e, t) {
                Pe[e] = function() {
                    return arguments[0] = arguments[0][0], t.apply(this, arguments)
                }
            }), Pe.deleteProperty = function(e, t) {
                return Pe.set.call(this, e, t, void 0)
            }, Pe.set = function(e, t, n) {
                return Ae.set.call(this, e[0], t, n, e[0])
            }, c = (De = new((o = Ie.prototype).createDraft = function(e) {
                O(e) || L(8), D(e) && (D(t = e) || L(22, t), e = function n(e) {
                    if (!O(e)) return e;
                    var r, a = e[be],
                        t = V(e);
                    if (a) {
                        if (!a.P && (a.i < 4 || !Y("ES5").K(a))) return a.t;
                        a.I = !0, r = fe(e, t), a.I = !1
                    } else r = fe(e, t);
                    return U(r, function(e, t) {
                        a && F(a.t, e) === t || j(r, e, n(t))
                    }), 3 === t ? new Set(r) : r
                }(t));
                var t = ee(this),
                    e = se(this, e, void 0);
                return e[be].C = !0, Z(t), e
            }, o.finishDraft = function(e, t) {
                e = (e && e[be]).A;
                return Q(e, t), ne(void 0, e)
            }, o.setAutoFreeze = function(e) {
                this.D = e
            }, o.setUseProxies = function(e) {
                e && !ve && L(20), this.O = e
            }, o.applyPatches = function(e, t) {
                for (var n = t.length - 1; 0 <= n; n--) {
                    var r = t[n];
                    if (0 === r.path.length && "replace" === r.op) {
                        e = r.value;
                        break
                    }
                } - 1 < n && (t = t.slice(n + 1));
                var a = Y("Patches").$;
                return D(e) ? a(e, t) : this.produce(e, function(e) {
                    return a(e, t)
                })
            }, Ie)).produce, De.produceWithPatches.bind(De), De.setAutoFreeze.bind(De), De.setUseProxies.bind(De), De.applyPatches.bind(De), De.createDraft.bind(De), De.finishDraft.bind(De);
            var ke = c,
                xe = Redux,
                o = ReduxThunk,
                Ne = Kr.n(o);

            function Te(e) {
                return (Te = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                    return typeof e
                } : function(e) {
                    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                })(e)
            }

            function Me(e, t, n) {
                return t in e ? Ve(e, t, {
                    enumerable: !0,
                    configurable: !0,
                    writable: !0,
                    value: n
                }) : e[t] = n
            }

            function Re(e, t) {
                return Be(e, Fe(t))
            }
            var Le, De = (Le = function(e, t) {
                    return (Le = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function(e, t) {
                            e.__proto__ = t
                        } || function(e, t) {
                            for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
                        })(e, t)
                }, function(e, t) {
                    if ("function" != typeof t && null !== t) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");

                    function n() {
                        this.constructor = e
                    }
                    Le(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                }),
                Oe = function(n, r) {
                    var a, o, i, c = {
                            label: 0,
                            sent: function() {
                                if (1 & i[0]) throw i[1];
                                return i[1]
                            },
                            trys: [],
                            ops: []
                        },
                        e = {
                            next: t(0),
                            throw: t(1),
                            return: t(2)
                        };
                    return "function" == typeof Symbol && (e[Symbol.iterator] = function() {
                        return this
                    }), e;

                    function t(t) {
                        return function(e) {
                            return function(t) {
                                if (a) throw new TypeError("Generator is already executing.");
                                for (; c;) try {
                                    if (a = 1, o && (i = 2 & t[0] ? o.return : t[0] ? o.throw || ((i = o.return) && i.call(o), 0) : o.next) && !(i = i.call(o, t[1])).done) return i;
                                    switch (o = 0, i && (t = [2 & t[0], i.value]), t[0]) {
                                        case 0:
                                        case 1:
                                            i = t;
                                            break;
                                        case 4:
                                            return c.label++, {
                                                value: t[1],
                                                done: !1
                                            };
                                        case 5:
                                            c.label++, o = t[1], t = [0];
                                            continue;
                                        case 7:
                                            t = c.ops.pop(), c.trys.pop();
                                            continue;
                                        default:
                                            if (!(i = 0 < (i = c.trys).length && i[i.length - 1]) && (6 === t[0] || 2 === t[0])) {
                                                c = 0;
                                                continue
                                            }
                                            if (3 === t[0] && (!i || t[1] > i[0] && t[1] < i[3])) {
                                                c.label = t[1];
                                                break
                                            }
                                            if (6 === t[0] && c.label < i[1]) {
                                                c.label = i[1], i = t;
                                                break
                                            }
                                            if (i && c.label < i[2]) {
                                                c.label = i[2], c.ops.push(t);
                                                break
                                            }
                                            i[2] && c.ops.pop(), c.trys.pop();
                                            continue
                                    }
                                    t = r.call(n, c)
                                } catch (e) {
                                    t = [6, e], o = 0
                                } finally {
                                    a = i = 0
                                }
                                if (5 & t[0]) throw t[1];
                                return {
                                    value: t[0] ? t[1] : void 0,
                                    done: !0
                                }
                            }([t, e])
                        }
                    }
                },
                Ue = function(e, t) {
                    for (var n = 0, r = t.length, a = e.length; n < r; n++, a++) e[a] = t[n];
                    return e
                },
                Ve = Object.defineProperty,
                Be = Object.defineProperties,
                Fe = Object.getOwnPropertyDescriptors,
                je = Object.getOwnPropertySymbols,
                _e = Object.prototype.hasOwnProperty,
                qe = Object.prototype.propertyIsEnumerable,
                He = function(e, t) {
                    for (var n in t = t || {}) _e.call(t, n) && Me(e, n, t[n]);
                    if (je)
                        for (var r = 0, a = je(t); r < a.length; r++) {
                            n = a[r];
                            qe.call(t, n) && Me(e, n, t[n])
                        }
                    return e
                },
                ze = function(e, i, c) {
                    return new Promise(function(t, n) {
                        function r(e) {
                            try {
                                o(c.next(e))
                            } catch (e) {
                                n(e)
                            }
                        }

                        function a(e) {
                            try {
                                o(c.throw(e))
                            } catch (e) {
                                n(e)
                            }
                        }
                        var o = function(e) {
                            return e.done ? t(e.value) : Promise.resolve(e.value).then(r, a)
                        };
                        o((c = c.apply(e, i)).next())
                    })
                },
                Ke = "undefined" != typeof window && window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ ? window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ : function() {
                    if (0 !== arguments.length) return "object" === Te(arguments[0]) ? xe.compose : xe.compose.apply(null, arguments)
                };

            function Ge(e) {
                if ("object" !== Te(e) || null === e) return !1;
                e = Object.getPrototypeOf(e);
                if (null === e) return !0;
                for (var t = e; null !== Object.getPrototypeOf(t);) t = Object.getPrototypeOf(t);
                return e === t
            }
            var $e, We = ($e = Array, De(Ye, $e), Object.defineProperty(Ye, Symbol.species, {
                get: function() {
                    return Ye
                },
                enumerable: !1,
                configurable: !0
            }), Ye.prototype.concat = function() {
                for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
                return $e.prototype.concat.apply(this, e)
            }, Ye.prototype.prepend = function() {
                for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
                return new(1 === e.length && Array.isArray(e[0]) ? Ye.bind.apply(Ye, Ue([void 0], e[0].concat(this))) : Ye.bind.apply(Ye, Ue([void 0], e.concat(this))))
            }, Ye);

            function Ye() {
                for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
                var n = $e.apply(this, e) || this;
                return Object.setPrototypeOf(n, Ye.prototype), n
            }
            var Je, Qe = (Je = Array, De(Xe, Je), Object.defineProperty(Xe, Symbol.species, {
                get: function() {
                    return Xe
                },
                enumerable: !1,
                configurable: !0
            }), Xe.prototype.concat = function() {
                for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
                return Je.prototype.concat.apply(this, e)
            }, Xe.prototype.prepend = function() {
                for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
                return new(1 === e.length && Array.isArray(e[0]) ? Xe.bind.apply(Xe, Ue([void 0], e[0].concat(this))) : Xe.bind.apply(Xe, Ue([void 0], e.concat(this))))
            }, Xe);

            function Xe() {
                for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
                var n = Je.apply(this, e) || this;
                return Object.setPrototypeOf(n, Xe.prototype), n
            }

            function Ze(e) {
                return O(e) ? ke(e, function() {}) : e
            }

            function et() {
                return function(e) {
                    void 0 === e && (e = {});
                    var t = e.thunk,
                        n = void 0 === t || t,
                        t = e.immutableCheck,
                        e = e.serializableCheck,
                        e = new We;
                    n && ("boolean" == typeof n ? e.push(Ne()) : e.push(Ne().withExtraArgument(n.extraArgument)));
                    0;
                    return e
                }
            }

            function tt(r, a) {
                function e() {
                    for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
                    if (a) {
                        var n = a.apply(void 0, e);
                        if (!n) throw new Error("prepareAction did not return an object");
                        return He(He({
                            type: r,
                            payload: n.payload
                        }, "meta" in n && {
                            meta: n.meta
                        }), "error" in n && {
                            error: n.error
                        })
                    }
                    return {
                        type: r,
                        payload: e[0]
                    }
                }
                return e.toString = function() {
                    return "" + r
                }, e.type = r, e.match = function(e) {
                    return e.type === r
                }, e
            }

            function nt(e) {
                var t, n = {},
                    r = [],
                    a = {
                        addCase: function(e, t) {
                            e = "string" == typeof e ? e : e.type;
                            if (e in n) throw new Error("addCase cannot be called with two reducers for the same action type");
                            return n[e] = t, a
                        },
                        addMatcher: function(e, t) {
                            return r.push({
                                matcher: e,
                                reducer: t
                            }), a
                        },
                        addDefaultCase: function(e) {
                            return t = e, a
                        }
                    };
                return e(a), [n, r, t]
            }

            function rt(r) {
                var o = r.name;
                if (!o) throw new Error("`name` is a required option for createSlice");
                var n, a = "function" == typeof r.initialState ? r.initialState : Ze(r.initialState),
                    i = r.reducers || {},
                    e = Object.keys(i),
                    c = {},
                    u = {},
                    l = {};

                function s() {
                    var e = "function" == typeof r.extraReducers ? nt(r.extraReducers) : [r.extraReducers],
                        t = e[0],
                        n = void 0 === t ? {} : t,
                        t = e[1],
                        o = void 0 === t ? [] : t,
                        e = e[2],
                        i = void 0 === e ? void 0 : e,
                        c = He(He({}, n), u);
                    return function(e, t, n, r) {
                        void 0 === n && (n = []);
                        var a, o, i = (r = "function" == typeof t ? nt(t) : [t, n, r])[0],
                            c = r[1],
                            u = r[2];

                        function l(e, r) {
                            void 0 === e && (e = o());
                            var t = Ue([i[r.type]], c.filter(function(e) {
                                return (0, e.matcher)(r)
                            }).map(function(e) {
                                return e.reducer
                            }));
                            return 0 === t.filter(function(e) {
                                return !!e
                            }).length && (t = [u]), t.reduce(function(e, t) {
                                if (t) {
                                    var n;
                                    if (D(e)) return void 0 === (n = t(e, r)) ? e : n;
                                    if (O(e)) return ke(e, function(e) {
                                        return t(e, r)
                                    });
                                    if (void 0 !== (n = t(e, r))) return n;
                                    if (null === e) return e;
                                    throw Error("A case reducer on a non-draftable value must not return undefined")
                                }
                                return e
                            }, e)
                        }
                        return o = "function" == typeof e ? function() {
                            return Ze(e())
                        } : (a = Ze(e), function() {
                            return a
                        }), l.getInitialState = o, l
                    }(a, function(e) {
                        for (var t in c) e.addCase(t, c[t]);
                        for (var n = 0, r = o; n < r.length; n++) {
                            var a = r[n];
                            e.addMatcher(a.matcher, a.reducer)
                        }
                        i && e.addDefaultCase(i)
                    })
                }
                return e.forEach(function(e) {
                    var t, n, r = i[e],
                        a = o + "/" + e;
                    "reducer" in r ? (t = r.reducer, n = r.prepare) : t = r, c[e] = t, u[a] = t, l[e] = n ? tt(a, n) : tt(a)
                }), {
                    name: o,
                    reducer: function(e, t) {
                        return (n = n || s())(e, t)
                    },
                    actions: l,
                    caseReducers: c,
                    getInitialState: function() {
                        return (n = n || s()).getInitialState()
                    }
                }
            }

            function at(e) {
                void 0 === e && (e = 21);
                for (var t = "", n = e; n--;) t += "ModuleSymbhasOwnPr-0123456789ABCDEFGHNRVfgctiUvz_KqYTJkLxpZXIjQW" [64 * Math.random() | 0];
                return t
            }
            var ot = ["name", "message", "stack", "code"],
                it = function(e, t) {
                    this.payload = e, this.meta = t
                },
                ct = function(e, t) {
                    this.payload = e, this.meta = t
                },
                c = (ut.withTypes = function() {
                    return ut
                }, ut);

            function ut(e, p, m) {
                var h = tt(e + "/fulfilled", function(e, t, n, r) {
                        return {
                            payload: e,
                            meta: Re(He({}, r || {}), {
                                arg: n,
                                requestId: t,
                                requestStatus: "fulfilled"
                            })
                        }
                    }),
                    v = tt(e + "/pending", function(e, t, n) {
                        return {
                            payload: void 0,
                            meta: Re(He({}, n || {}), {
                                arg: t,
                                requestId: e,
                                requestStatus: "pending"
                            })
                        }
                    }),
                    g = tt(e + "/rejected", function(e, t, n, r, a) {
                        return {
                            payload: r,
                            error: (m && m.serializeError || function(e) {
                                if ("object" !== Te(e) || null === e) return {
                                    message: String(e)
                                };
                                for (var t = {}, n = 0, r = ot; n < r.length; n++) {
                                    var a = r[n];
                                    "string" == typeof e[a] && (t[a] = e[a])
                                }
                                return t
                            })(e || "Rejected"),
                            meta: Re(He({}, a || {}), {
                                arg: n,
                                requestId: t,
                                rejectedWithValue: !!r,
                                requestStatus: "rejected",
                                aborted: "AbortError" === (null == e ? void 0 : e.name),
                                condition: "ConditionError" === (null == e ? void 0 : e.name)
                            })
                        }
                    }),
                    t = "undefined" != typeof AbortController ? AbortController : (n.prototype.abort = function() {
                        0
                    }, n);

                function n() {
                    this.signal = {
                        aborted: !1,
                        addEventListener: function() {},
                        dispatchEvent: function() {
                            return !1
                        },
                        onabort: function() {},
                        removeEventListener: function() {},
                        reason: void 0,
                        throwIfAborted: function() {}
                    }
                }
                return Object.assign(function(d) {
                    return function(o, i, c) {
                        var u, l = null != m && m.idGenerator ? m.idGenerator(d) : at(),
                            s = new t;

                        function f(e) {
                            u = e, s.abort()
                        }
                        var e = function() {
                            return ze(this, null, function() {
                                var n, r, a;
                                return Oe(this, function(e) {
                                    switch (e.label) {
                                        case 0:
                                            return e.trys.push([0, 4, , 5]), r = null == (r = null == m ? void 0 : m.condition) ? void 0 : r.call(m, d, {
                                                getState: i,
                                                extra: c
                                            }), null === (t = r) || "object" !== Te(t) || "function" != typeof t.then ? [3, 2] : [4, r];
                                        case 1:
                                            r = e.sent(), e.label = 2;
                                        case 2:
                                            if (!1 === r || s.signal.aborted) throw {
                                                name: "ConditionError",
                                                message: "Aborted due to condition callback returning false."
                                            };
                                            return a = new Promise(function(e, t) {
                                                return s.signal.addEventListener("abort", function() {
                                                    return t({
                                                        name: "AbortError",
                                                        message: u || "Aborted"
                                                    })
                                                })
                                            }), o(v(l, d, null == (r = null == m ? void 0 : m.getPendingMeta) ? void 0 : r.call(m, {
                                                requestId: l,
                                                arg: d
                                            }, {
                                                getState: i,
                                                extra: c
                                            }))), [4, Promise.race([a, Promise.resolve(p(d, {
                                                dispatch: o,
                                                getState: i,
                                                extra: c,
                                                requestId: l,
                                                signal: s.signal,
                                                abort: f,
                                                rejectWithValue: function(e, t) {
                                                    return new it(e, t)
                                                },
                                                fulfillWithValue: function(e, t) {
                                                    return new ct(e, t)
                                                }
                                            })).then(function(e) {
                                                if (e instanceof it) throw e;
                                                return e instanceof ct ? h(e.payload, l, d, e.meta) : h(e, l, d)
                                            })])];
                                        case 3:
                                            return n = e.sent(), [3, 5];
                                        case 4:
                                            return a = e.sent(), n = a instanceof it ? g(null, l, d, a.payload, a.meta) : g(a, l, d), [3, 5];
                                        case 5:
                                            return m && !m.dispatchConditionRejection && g.match(n) && n.meta.condition || o(n), [2, n]
                                    }
                                    var t
                                })
                            })
                        }();
                        return Object.assign(e, {
                            abort: f,
                            requestId: l,
                            arg: d,
                            unwrap: function() {
                                return e.then(lt)
                            }
                        })
                    }
                }, {
                    pending: v,
                    rejected: g,
                    fulfilled: h,
                    typePrefix: e
                })
            }

            function lt(e) {
                if (e.meta && e.meta.rejectedWithValue) throw e.payload;
                if (e.error) throw e.error;
                return e.payload
            }

            function st(t) {
                return function(e) {
                    setTimeout(e, t)
                }
            }
            o = "listener", De = "completed", Object.assign, tt((o = "listenerMiddleware") + "/add"), tt(o + "/removeAll"), tt(o + "/remove"), "function" == typeof queueMicrotask && queueMicrotask.bind("undefined" != typeof window ? window : void 0 !== Kr.g ? Kr.g : globalThis), "undefined" != typeof window && window.requestAnimationFrame || st(10), de();
            var ft = e.EnvironmentUrls.apiGatewayUrl,
                dt = function(e, t) {
                    void 0 === t && (t = null);
                    var n = btoa(JSON.stringify(t)),
                        r = t ? (void 0 === (n = n) && (n = null), {
                            retryable: !0,
                            withCredentials: !0,
                            url: ft + "/access-management/v1/upsell-feature-access?featureName=" + e + "&extraParameters=" + n
                        }) : {
                            retryable: !0,
                            withCredentials: !0,
                            url: ft + "/access-management/v1/upsell-feature-access?featureName=" + e
                        };
                    return new Promise(function(t) {
                        i.httpService.get(r).then(function(e) {
                            e = e.data;
                            t(e)
                        }, function(e) {
                            throw e
                        })
                    })
                };
            (De = Gt = Gt || {}).Granted = "Granted", De.Denied = "Denied", De.Actionable = "Actionable";
            var pt = Gt;
            (Gt = yn = yn || {}).VerificationStarted = "VERIFICATION_STARTED", Gt.verificationInProgress = "VERIFICATION_IN_PROGRESS", Gt.VerificationPending = "VERIFICATION_PENDING", Gt.VerificationFailed = "VERIFICATION_FAILED", Gt.VerificationSucceded = "VERIFICATION_SUCCEEDED", Gt.AMPCheckFailed = "AMP_CHECK_FAILED", Gt.EmailUpdateFailed = "EMAIL_UPDATE_FAILED";
            var mt = yn;
            (Gt = jt = jt || {}).GovernmentId = "GovernmentId", Gt.Phone = "PHONE", Gt.Email = "EMAIL", Gt.AddedEmail = "AddedEmail", Gt.ParentConsentRequest = "ParentConsent", Gt.ParentLinkRequest = "ParentLink";
            var ht, vt, gt, yt, bt, Et = jt;

            function wt(e) {
                return e.accessManagement.showUpsell
            }

            function St(e) {
                return e.accessManagement.featureName
            }

            function Ct(e) {
                return e.accessManagement.ampFeatureCheckData
            }

            function At(e) {
                return e.accessManagement.featureAccess
            }

            function Pt(e) {
                return e.accessManagement.stage
            }

            function It(e) {
                return e.accessManagement.verificationStageRecourse
            }

            function kt(e, t) {
                void 0 === t && (t = []);
                var n = {
                    heading: "Heading.VerificationSuccessful",
                    icon: "success-icon",
                    bodyText: ["Label.DateOfBirthUpdated"],
                    buttonText: "Action.Close",
                    footerText: null
                };
                switch (e) {
                    case bt.SUCCESS_GENERIC:
                        break;
                    case bt.FAILURE:
                        n = $t($t({}, n), {
                            heading: "Heading.VerificationFailed",
                            icon: "failure-icon",
                            bodyText: ["Label.FailedVerification"],
                            buttonText: "Action.Close"
                        });
                        break;
                    case bt.PENDING:
                        n = $t($t({}, n), {
                            heading: "Heading.VerificationPending",
                            icon: "failure-icon",
                            bodyText: ["Label.PendingVerification"],
                            buttonText: "Action.Close"
                        });
                        break;
                    case bt.ERROR:
                        n = $t($t({}, n), {
                            heading: "Heading.Error",
                            icon: "failure-icon",
                            bodyText: ["Label.GenericError"]
                        });
                        break;
                    case bt.TEMP_BAN:
                        n = $t($t({}, n), {
                            heading: "Heading.Error",
                            icon: "failure-icon",
                            bodyText: ["Label.VerificationDeclined"]
                        });
                        break;
                    case bt.LANDING:
                    case bt.EMAIL:
                    case bt.MODAL:
                    case bt.POLLING:
                    case bt.EMAIL_CONTINUE:
                    case bt.EXTERNAL_EMAIL:
                    case bt.VENDOR_LINK:
                }
                return n.bodyText = Wt(Wt([], n.bodyText), t), n
            }

            function xt() {
                var e = {
                    retryable: !0,
                    withCredentials: !0,
                    url: fn + "/age-verification-service/v1/persona-id-verification/start-verification"
                };
                return i.httpService.post(e, {
                    generateLink: !0
                }).then(function(e) {
                    return e.data
                }).catch(function(e) {
                    e = i.httpService.parseErrorCode(e);
                    throw new Error("Error to start ID verification: " + (e || "unknown"))
                })
            }

            function Nt(e) {
                var t = {
                        retryable: !0,
                        withCredentials: !0,
                        url: fn + "/age-verification-service/v1/persona-id-verification/verified-status"
                    },
                    e = {
                        token: e
                    };
                return i.httpService.get(t, e).then(function(e) {
                    return e.data
                }).catch(function(e) {
                    e = i.httpService.parseErrorCode(e);
                    throw new Error("Error to get ID verification status: " + (e || "unknown"))
                })
            }

            function Tt(e) {
                return e.verification.IDVerificationState
            }

            function Mt() {
                return {
                    retryable: !0,
                    withCredentials: !0,
                    url: En + "/v1/email"
                }
            }

            function Rt(e) {
                return e.emailVerification
            }(yn = ht = ht || {}).Prologue = "PROLOGUE", yn.Verification = "VERIFICATION", yn.Epilogue = "EPILOGUE", (Gt = vt = vt || {})[Gt.VendorLink = 0] = "VendorLink", Gt[Gt.Checklist = 1] = "Checklist", Gt[Gt.Complete = 2] = "Complete", (jt = gt = gt || {})[jt.Unknown = 0] = "Unknown", jt[jt.Success = 1] = "Success", jt[jt.Failure = 2] = "Failure", jt[jt.RequiresManualReview = 3] = "RequiresManualReview", jt[jt.RequiresRetry = 4] = "RequiresRetry", jt[jt.Started = 5] = "Started", jt[jt.Submitted = 6] = "Submitted", jt[jt.Stored = 7] = "Stored", jt[jt.Expired = 8] = "Expired", (yn = yt = yt || {})[yn.NoError = 0] = "NoError", yn[yn.UnknownError = 1] = "UnknownError", yn[yn.InvalidDocument = 2] = "InvalidDocument", yn[yn.InvalidSelfie = 3] = "InvalidSelfie", yn[yn.BelowMinimumAge = 4] = "BelowMinimumAge", yn[yn.LowQualityMedia = 5] = "LowQualityMedia", yn[yn.DocumentUnsupported = 6] = "DocumentUnsupported", (Gt = bt = bt || {})[Gt.LANDING = 0] = "LANDING", Gt[Gt.EMAIL = 1] = "EMAIL", Gt[Gt.MODAL = 2] = "MODAL", Gt[Gt.SUCCESS_GENERIC = 3] = "SUCCESS_GENERIC", Gt[Gt.FAILURE = 4] = "FAILURE", Gt[Gt.PENDING = 5] = "PENDING", Gt[Gt.POLLING = 6] = "POLLING", Gt[Gt.EMAIL_CONTINUE = 7] = "EMAIL_CONTINUE", Gt[Gt.EXTERNAL_EMAIL = 8] = "EXTERNAL_EMAIL", Gt[Gt.ERROR = 9] = "ERROR", Gt[Gt.TEMP_BAN = 10] = "TEMP_BAN", Gt[Gt.VENDOR_LINK = 11] = "VENDOR_LINK";
            var Lt = CoreRobloxUtilities,
                Dt = function(e, t, n) {
                    Lt.eventStreamService.sendEventWithTarget(e, t, n)
                },
                Ot = function() {
                    return (Ot = Object.assign || function(e) {
                        for (var t, n = 1, r = arguments.length; n < r; n++)
                            for (var a in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
                        return e
                    }).apply(this, arguments)
                },
                Ut = function(e, i, c, u) {
                    return new(c = c || Promise)(function(n, t) {
                        function r(e) {
                            try {
                                o(u.next(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function a(e) {
                            try {
                                o(u.throw(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function o(e) {
                            var t;
                            e.done ? n(e.value) : ((t = e.value) instanceof c ? t : new c(function(e) {
                                e(t)
                            })).then(r, a)
                        }
                        o((u = u.apply(e, i || [])).next())
                    })
                },
                Vt = function(n, r) {
                    var a, o, i, c = {
                            label: 0,
                            sent: function() {
                                if (1 & i[0]) throw i[1];
                                return i[1]
                            },
                            trys: [],
                            ops: []
                        },
                        e = {
                            next: t(0),
                            throw: t(1),
                            return: t(2)
                        };
                    return "function" == typeof Symbol && (e[Symbol.iterator] = function() {
                        return this
                    }), e;

                    function t(t) {
                        return function(e) {
                            return function(t) {
                                if (a) throw new TypeError("Generator is already executing.");
                                for (; c;) try {
                                    if (a = 1, o && (i = 2 & t[0] ? o.return : t[0] ? o.throw || ((i = o.return) && i.call(o), 0) : o.next) && !(i = i.call(o, t[1])).done) return i;
                                    switch (o = 0, i && (t = [2 & t[0], i.value]), t[0]) {
                                        case 0:
                                        case 1:
                                            i = t;
                                            break;
                                        case 4:
                                            return c.label++, {
                                                value: t[1],
                                                done: !1
                                            };
                                        case 5:
                                            c.label++, o = t[1], t = [0];
                                            continue;
                                        case 7:
                                            t = c.ops.pop(), c.trys.pop();
                                            continue;
                                        default:
                                            if (!(i = 0 < (i = c.trys).length && i[i.length - 1]) && (6 === t[0] || 2 === t[0])) {
                                                c = 0;
                                                continue
                                            }
                                            if (3 === t[0] && (!i || t[1] > i[0] && t[1] < i[3])) {
                                                c.label = t[1];
                                                break
                                            }
                                            if (6 === t[0] && c.label < i[1]) {
                                                c.label = i[1], i = t;
                                                break
                                            }
                                            if (i && c.label < i[2]) {
                                                c.label = i[2], c.ops.push(t);
                                                break
                                            }
                                            i[2] && c.ops.pop(), c.trys.pop();
                                            continue
                                    }
                                    t = r.call(n, c)
                                } catch (e) {
                                    t = [6, e], o = 0
                                } finally {
                                    a = i = 0
                                }
                                if (5 & t[0]) throw t[1];
                                return {
                                    value: t[0] ? t[1] : void 0,
                                    done: !0
                                }
                            }([t, e])
                        }
                    }
                },
                Bt = {
                    featureName: null,
                    ampFeatureCheckData: void 0,
                    stage: null,
                    verificationStageRecourse: null,
                    featureAccess: {
                        loading: !1,
                        data: null,
                        error: null
                    },
                    showUpsell: !1,
                    redirectLink: null,
                    loading: !1
                },
                Ft = c("accessManagement/fetchFeatureAccess", function(r, a) {
                    return Ut(void 0, void 0, void 0, function() {
                        var t, n;
                        return Vt(this, function(e) {
                            switch (e.label) {
                                case 0:
                                    return e.trys.push([0, 2, , 3]), t = r.featureName, n = r.ampFeatureCheckData, [4, dt(t, n)];
                                case 1:
                                    return [2, e.sent()];
                                case 2:
                                    return n = e.sent(), Dt(mt.AMPCheckFailed, null, {
                                        error: JSON.stringify(n)
                                    }), [2, a.rejectWithValue("Failed to fetch AMP response")];
                                case 3:
                                    return [2]
                            }
                        })
                    })
                }),
                jt = rt({
                    name: "accessManagement",
                    initialState: Bt,
                    reducers: {
                        resetAccessManagementStore: function() {
                            return Bt
                        },
                        setFeatureName: function(e, t) {
                            e.featureName = t.payload
                        },
                        setAmpFeatureCheckData: function(e, t) {
                            e.ampFeatureCheckData = t.payload
                        },
                        showUpsell: function(e, t) {
                            e.showUpsell = t.payload
                        },
                        setFeatureAccess: function(e, t) {
                            e.featureAccess = t.payload
                        },
                        setRedirectLink: function(e, t) {
                            e.redirectLink = t.payload
                        },
                        setStage: function(e, t) {
                            e.stage = t.payload
                        },
                        setVerificationStageRecourse: function(e, t) {
                            e.verificationStageRecourse = t.payload
                        }
                    },
                    extraReducers: function(e) {
                        e.addCase(Ft.pending, function(e) {
                            e.featureAccess.loading = !0
                        }).addCase(Ft.fulfilled, function(e, t) {
                            t = t.payload;
                            e.featureAccess = Ot(Ot({}, e.featureAccess), {
                                loading: !1,
                                data: t
                            }), e.featureName = t.featureName, t.access === pt.Actionable && (e.showUpsell = !0, e.verificationStageRecourse = t.recourses[0])
                        }).addCase(Ft.rejected, function(e, t) {
                            e.featureAccess = Ot(Ot({}, e.featureAccess), {
                                loading: !1,
                                error: t.error.message || "Something went wrong"
                            })
                        })
                    }
                }),
                _t = (yn = jt.actions).resetAccessManagementStore,
                qt = (yn.setFeatureAccess, yn.setFeatureName, yn.setAmpFeatureCheckData),
                Ht = yn.setRedirectLink,
                zt = yn.setVerificationStageRecourse,
                Kt = (yn.showUpsell, yn.setStage),
                Gt = jt.reducer,
                $t = function() {
                    return ($t = Object.assign || function(e) {
                        for (var t, n = 1, r = arguments.length; n < r; n++)
                            for (var a in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
                        return e
                    }).apply(this, arguments)
                },
                Wt = function(e, t) {
                    for (var n = 0, r = t.length, a = e.length; n < r; n++, a++) e[a] = t[n];
                    return e
                },
                Yt = [{
                    label: "Label.ConnectingToMobile",
                    statusCode: [gt.Unknown]
                }, {
                    label: "Label.VerifyingYou",
                    statusCode: [gt.Started]
                }, {
                    label: "Label.VerificationWaitingForResults",
                    statusCode: [gt.Submitted]
                }, {
                    label: "Label.UpdatingRoblox",
                    statusCode: [gt.Success, gt.Stored]
                }],
                Jt = "Action.RestartSession",
                Qt = "Action.StartSession",
                Xt = "Label.HavingTroubleScanCode",
                Zt = "Label.PleaseDoNotClose",
                en = "Label.VerificationDataSubmitted",
                tn = "Label.VerifyInBrowser",
                nn = "Label.AgeVerifyPrompt",
                rn = "Label.PrepareId",
                an = "Label.ValidIdList",
                on = "Label.UseSmartphone",
                cn = "Label.SmartphoneRequired",
                un = "Label.ScanQRCode",
                ln = "Label.PrivacyNoticeAndLink",
                sn = Kr(28),
                fn = e.EnvironmentUrls.apiGatewayUrl,
                dn = function() {
                    return (dn = Object.assign || function(e) {
                        for (var t, n = 1, r = arguments.length; n < r; n++)
                            for (var a in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
                        return e
                    }).apply(this, arguments)
                },
                pn = function(e, i, c, u) {
                    return new(c = c || Promise)(function(n, t) {
                        function r(e) {
                            try {
                                o(u.next(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function a(e) {
                            try {
                                o(u.throw(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function o(e) {
                            var t;
                            e.done ? n(e.value) : ((t = e.value) instanceof c ? t : new c(function(e) {
                                e(t)
                            })).then(r, a)
                        }
                        o((u = u.apply(e, i || [])).next())
                    })
                },
                mn = function(n, r) {
                    var a, o, i, c = {
                            label: 0,
                            sent: function() {
                                if (1 & i[0]) throw i[1];
                                return i[1]
                            },
                            trys: [],
                            ops: []
                        },
                        e = {
                            next: t(0),
                            throw: t(1),
                            return: t(2)
                        };
                    return "function" == typeof Symbol && (e[Symbol.iterator] = function() {
                        return this
                    }), e;

                    function t(t) {
                        return function(e) {
                            return function(t) {
                                if (a) throw new TypeError("Generator is already executing.");
                                for (; c;) try {
                                    if (a = 1, o && (i = 2 & t[0] ? o.return : t[0] ? o.throw || ((i = o.return) && i.call(o), 0) : o.next) && !(i = i.call(o, t[1])).done) return i;
                                    switch (o = 0, i && (t = [2 & t[0], i.value]), t[0]) {
                                        case 0:
                                        case 1:
                                            i = t;
                                            break;
                                        case 4:
                                            return c.label++, {
                                                value: t[1],
                                                done: !1
                                            };
                                        case 5:
                                            c.label++, o = t[1], t = [0];
                                            continue;
                                        case 7:
                                            t = c.ops.pop(), c.trys.pop();
                                            continue;
                                        default:
                                            if (!(i = 0 < (i = c.trys).length && i[i.length - 1]) && (6 === t[0] || 2 === t[0])) {
                                                c = 0;
                                                continue
                                            }
                                            if (3 === t[0] && (!i || t[1] > i[0] && t[1] < i[3])) {
                                                c.label = t[1];
                                                break
                                            }
                                            if (6 === t[0] && c.label < i[1]) {
                                                c.label = i[1], i = t;
                                                break
                                            }
                                            if (i && c.label < i[2]) {
                                                c.label = i[2], c.ops.push(t);
                                                break
                                            }
                                            i[2] && c.ops.pop(), c.trys.pop();
                                            continue
                                    }
                                    t = r.call(n, c)
                                } catch (e) {
                                    t = [6, e], o = 0
                                } finally {
                                    a = i = 0
                                }
                                if (5 & t[0]) throw t[1];
                                return {
                                    value: t[0] ? t[1] : void 0,
                                    done: !0
                                }
                            }([t, e])
                        }
                    }
                },
                hn = {
                    verified: null,
                    IDVerificationState: {
                        page: vt.VendorLink,
                        vendorVerificationData: {
                            daysUntilNextVerification: 0,
                            sessionIdentifier: null,
                            verificationLink: null,
                            qrCode: null,
                            loading: !1
                        },
                        loading: null,
                        status: null,
                        completionPageState: null,
                        error: null
                    }
                },
                vn = c("verification/startIDVerification", function(e, a) {
                    return pn(void 0, void 0, void 0, function() {
                        var r;
                        return mn(this, function(e) {
                            switch (e.label) {
                                case 0:
                                    return e.trys.push([0, 2, , 3]), [4, xt()];
                                case 1:
                                    return (r = e.sent()).qrCode = (t = r.verificationLink, sn.hz(t, function(e, t) {
                                        n = t
                                    }), n), [2, r];
                                case 2:
                                    return r = e.sent(), Dt(mt.VerificationFailed, Et.GovernmentId, {
                                        error: JSON.stringify(r)
                                    }), [2, a.rejectWithValue("Failed to start ID Verification")];
                                case 3:
                                    return [2]
                            }
                            var t, n
                        })
                    })
                }),
                gn = c("verification/fetchIDVerificationStatus", function(n, r) {
                    return pn(void 0, void 0, void 0, function() {
                        var t;
                        return mn(this, function(e) {
                            switch (e.label) {
                                case 0:
                                    return e.trys.push([0, 2, , 3]), [4, Nt(n)];
                                case 1:
                                    return [2, e.sent()];
                                case 2:
                                    return t = e.sent(), Dt(mt.VerificationFailed, Et.GovernmentId, {
                                        error: JSON.stringify(t)
                                    }), [2, r.rejectWithValue("Failed to fetch ID Verification status")];
                                case 3:
                                    return [2]
                            }
                        })
                    })
                }),
                yn = rt({
                    name: "verification",
                    initialState: hn,
                    reducers: {
                        resetVerificationStore: function() {
                            return hn
                        },
                        setVerified: function(e, t) {
                            e.verified = t.payload
                        },
                        setIDVerificationState: function(e, t) {
                            e.IDVerificationState = dn({}, t.payload)
                        },
                        setIDVPage: function(e, t) {
                            e.IDVerificationState.page = t.payload
                        }
                    },
                    extraReducers: function(e) {
                        e.addCase(vn.pending, function(e, t) {
                            var n = e.IDVerificationState.vendorVerificationData;
                            n.loading = !0, e.IDVerificationState = dn(dn({}, e.IDVerificationState), {
                                vendorVerificationData: n,
                                loading: !0
                            })
                        }).addCase(vn.fulfilled, function(e, t) {
                            var n = t.payload,
                                r = n.daysUntilNextVerification,
                                t = null;
                            n.loading = !1, null != r && 0 < r && (t = kt(bt.TEMP_BAN, ["Label.FailedVerificationInvalidDocument"])), e.IDVerificationState = dn(dn({}, e.IDVerificationState), {
                                vendorVerificationData: n,
                                completionPageState: t,
                                loading: !1
                            })
                        }).addCase(vn.rejected, function(e, t) {
                            var n = e.IDVerificationState.vendorVerificationData;
                            n.loading = !1, e.IDVerificationState = dn(dn({}, e.IDVerificationState), {
                                vendorVerificationData: n,
                                loading: !1,
                                error: t.error.message || "Something went wrong"
                            })
                        }).addCase(gn.pending, function(e) {
                            e.IDVerificationState = dn(dn({}, e.IDVerificationState), {
                                loading: !0
                            })
                        }).addCase(gn.fulfilled, function(e, t) {
                            var n, r = t.payload,
                                a = e.IDVerificationState.page;
                            switch (r.sessionStatus) {
                                case gt.RequiresRetry:
                                case gt.Failure:
                                    switch (a = vt.Complete, r.sessionErrorCode) {
                                        case yt.InvalidDocument:
                                        case yt.BelowMinimumAge:
                                            n = kt(bt.FAILURE, ["Label.FailedVerificationInvalidDocument"]);
                                            break;
                                        case yt.LowQualityMedia:
                                        case yt.InvalidSelfie:
                                            n = kt(bt.FAILURE, ["Label.FailedVerificationLowQuality"]);
                                            break;
                                        case yt.DocumentUnsupported:
                                            n = kt(bt.FAILURE, ["Label.FailedVerificationUnsupportedDocument"]);
                                            break;
                                        default:
                                            n = kt(bt.FAILURE)
                                    }
                                    break;
                                case gt.RequiresManualReview:
                                    a = vt.Complete, n = kt(bt.PENDING);
                                    break;
                                case gt.Success:
                                case gt.Stored:
                                    a = vt.Complete, n = kt(bt.SUCCESS_GENERIC);
                                    break;
                                case gt.Started:
                                    a = vt.Checklist, Dt(mt.VerificationStarted, Et.GovernmentId, {
                                        session: e.IDVerificationState.vendorVerificationData.sessionIdentifier
                                    });
                                    break;
                                case gt.Submitted:
                                    Dt(mt.verificationInProgress, Et.GovernmentId, {
                                        session: e.IDVerificationState.vendorVerificationData.sessionIdentifier
                                    })
                            }
                            e.IDVerificationState = dn(dn({}, e.IDVerificationState), {
                                loading: !1,
                                status: r,
                                completionPageState: n,
                                page: a
                            })
                        }).addCase(gn.rejected, function(e, t) {
                            e.IDVerificationState = dn(dn({}, e.IDVerificationState), {
                                loading: !1,
                                error: t.error.message || "Something went wrong"
                            })
                        })
                    }
                }),
                bn = (jt = yn.actions).resetVerificationStore,
                jt = (jt.setVerified, jt.setIDVerificationState, jt.setIDVPage, yn.reducer),
                En = (e.EnvironmentUrls.apiGatewayUrl, e.EnvironmentUrls.accountSettingsApi),
                wn = (e.EnvironmentUrls.voiceApi, function(e, i, c, u) {
                    return new(c = c || Promise)(function(n, t) {
                        function r(e) {
                            try {
                                o(u.next(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function a(e) {
                            try {
                                o(u.throw(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function o(e) {
                            var t;
                            e.done ? n(e.value) : ((t = e.value) instanceof c ? t : new c(function(e) {
                                e(t)
                            })).then(r, a)
                        }
                        o((u = u.apply(e, i || [])).next())
                    })
                }),
                Sn = function(n, r) {
                    var a, o, i, c = {
                            label: 0,
                            sent: function() {
                                if (1 & i[0]) throw i[1];
                                return i[1]
                            },
                            trys: [],
                            ops: []
                        },
                        e = {
                            next: t(0),
                            throw: t(1),
                            return: t(2)
                        };
                    return "function" == typeof Symbol && (e[Symbol.iterator] = function() {
                        return this
                    }), e;

                    function t(t) {
                        return function(e) {
                            return function(t) {
                                if (a) throw new TypeError("Generator is already executing.");
                                for (; c;) try {
                                    if (a = 1, o && (i = 2 & t[0] ? o.return : t[0] ? o.throw || ((i = o.return) && i.call(o), 0) : o.next) && !(i = i.call(o, t[1])).done) return i;
                                    switch (o = 0, i && (t = [2 & t[0], i.value]), t[0]) {
                                        case 0:
                                        case 1:
                                            i = t;
                                            break;
                                        case 4:
                                            return c.label++, {
                                                value: t[1],
                                                done: !1
                                            };
                                        case 5:
                                            c.label++, o = t[1], t = [0];
                                            continue;
                                        case 7:
                                            t = c.ops.pop(), c.trys.pop();
                                            continue;
                                        default:
                                            if (!(i = 0 < (i = c.trys).length && i[i.length - 1]) && (6 === t[0] || 2 === t[0])) {
                                                c = 0;
                                                continue
                                            }
                                            if (3 === t[0] && (!i || t[1] > i[0] && t[1] < i[3])) {
                                                c.label = t[1];
                                                break
                                            }
                                            if (6 === t[0] && c.label < i[1]) {
                                                c.label = i[1], i = t;
                                                break
                                            }
                                            if (i && c.label < i[2]) {
                                                c.label = i[2], c.ops.push(t);
                                                break
                                            }
                                            i[2] && c.ops.pop(), c.trys.pop();
                                            continue
                                    }
                                    t = r.call(n, c)
                                } catch (e) {
                                    t = [6, e], o = 0
                                } finally {
                                    a = i = 0
                                }
                                if (5 & t[0]) throw t[1];
                                return {
                                    value: t[0] ? t[1] : void 0,
                                    done: !0
                                }
                            }([t, e])
                        }
                    }
                },
                Cn = {
                    emailAddress: null,
                    isEmailVerified: !1,
                    isEmailAdded: !1,
                    loading: !1,
                    error: !1
                },
                An = c("emailVerification/updateUserEmail", function(a, o) {
                    return wn(void 0, void 0, void 0, function() {
                        var r;
                        return Sn(this, function(e) {
                            switch (e.label) {
                                case 0:
                                    return e.trys.push([0, 2, , 3]), [4, (t = {
                                        emailAddress: a
                                    }, n = Mt(), i.httpService.post(n, t).then(function() {
                                        return !0
                                    }).catch(function(e) {
                                        throw new Error("Error to update email address: " + JSON.stringify(e))
                                    }))];
                                case 1:
                                    return [2, e.sent()];
                                case 2:
                                    return r = e.sent(), Dt(mt.EmailUpdateFailed, Et.AddedEmail, {
                                        error: JSON.stringify(r)
                                    }), [2, o.rejectWithValue("Failed to update email address")];
                                case 3:
                                    return [2]
                            }
                            var t, n
                        })
                    })
                }),
                Pn = c("emailVerification/getUserEmailStatus", function(e, r) {
                    return wn(void 0, void 0, void 0, function() {
                        var n;
                        return Sn(this, function(e) {
                            switch (e.label) {
                                case 0:
                                    return e.trys.push([0, 2, , 3]), [4, (t = Mt(), i.httpService.get(t).then(function(e) {
                                        return e.data
                                    }).catch(function(e) {
                                        throw new Error("Error to get email address: " + JSON.stringify(e))
                                    }))];
                                case 1:
                                    return [2, e.sent()];
                                case 2:
                                    return n = e.sent(), Dt(mt.EmailUpdateFailed, Et.AddedEmail, {
                                        error: JSON.stringify(n)
                                    }), [2, r.rejectWithValue("Failed to fetch email address")];
                                case 3:
                                    return [2]
                            }
                            var t
                        })
                    })
                }),
                yn = rt({
                    name: "emailVerification",
                    initialState: Cn,
                    reducers: {
                        resetEmailVerificationStore: function() {
                            return Cn
                        },
                        setUserEmailData: function(e, t) {
                            e.emailAddress = t.payload
                        }
                    },
                    extraReducers: function(e) {
                        e.addCase(An.pending, function(e) {
                            e.loading = !0
                        }).addCase(An.fulfilled, function(e, t) {
                            e.isEmailAdded = !0, e.loading = !1
                        }).addCase(An.rejected, function(e, t) {
                            e.loading = !1, e.error = !0
                        }).addCase(Pn.pending, function(e) {
                            e.loading = !0
                        }).addCase(Pn.fulfilled, function(e, t) {
                            t = t.payload;
                            e.emailAddress = t.emailAddress, e.isEmailVerified = t.isEmailVerified, e.loading = !1
                        }).addCase(Pn.rejected, function(e) {
                            e.loading = !1
                        })
                    }
                }),
                In = (c = yn.actions).resetEmailVerificationStore,
                kn = (c.setUserEmailData, function(e) {
                    var t, n = et(),
                        r = void 0 === (o = (i = e || {}).reducer) ? void 0 : o,
                        e = void 0 === (a = i.middleware) ? n() : a,
                        a = void 0 === (o = i.devTools) || o,
                        o = void 0 === (o = i.preloadedState) ? void 0 : o,
                        i = void 0 === (i = i.enhancers) ? void 0 : i;
                    if ("function" == typeof r) t = r;
                    else {
                        if (!Ge(r)) throw new Error('"reducer" is a required argument, and must be a function or an object of functions that can be passed to combineReducers');
                        t = (0, xe.combineReducers)(r)
                    }
                    return "function" == typeof(r = e) && (r = r(n)), e = xe.applyMiddleware.apply(void 0, r), n = xe.compose, a && (n = Ke(He({
                        trace: !1
                    }, "object" === Te(a) && a))), r = new Qe(e), a = r, Array.isArray(i) ? a = Ue([e], i) : "function" == typeof i && (a = i(r)), a = n.apply(void 0, a), (0, xe.createStore)(t, o, a)
                }({
                    reducer: {
                        accessManagement: Gt,
                        verification: jt,
                        emailVerification: yn.reducer
                    }
                })),
                xn = "StartAccessManagementUpsell",
                Nn = {
                    Cancel: "Action.Cancel",
                    EmailMyParent: "Action.EmailMyParent",
                    VerifyID: "Action.VerifyID",
                    AskNow: "Action.AskNow"
                },
                Tn = {
                    AskYourParent: "Title.AskYourParent",
                    VerifyYourAge: "Title.VerifyYourAge"
                },
                Mn = {
                    Vpc: "Description.PrologueTextVpc",
                    VpcConnectingText: "Description.PrologueConnectingTextVpc",
                    Idv: "Description.PrologueTextIdv",
                    IdvConnectingText: "Description.PrologueConnectingTextIdv",
                    IdvAndVpc: "Description.PrologueTextIdvAndVpc",
                    IdvAndVpcConnectingText: "Description.PrologueConnectingTextIdvAndVpc"
                },
                jt = Lt.eventStreamService.eventTypes,
                yn = "ageVerification",
                Rn = {
                    emailRegex: "^\\w+([-+.]\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*$",
                    translationKeys: {
                        addEmailToAccountKeys: {
                            btnText: "Action.Continue",
                            ActionChangeEmail: "Action.ChangeEmail",
                            ActionSent: "Action.Sent",
                            ActionContinue: "Action.Continue",
                            ActionGenericSkip: "Action.GenericSkip",
                            DescriptionAddEmailTextOver13: "Description.IDVerificationAddEmailText",
                            DescriptionAddEmailTextUnder13: "Description.IDVerificationAddEmailText",
                            HeadingAddEmail: "Heading.AddEmail",
                            LabelEmailInputPlaceholderOver13: "Label.EmailInputPlaceholderOver13",
                            LabelEmailInputPlaceholderUnder13: "Label.EmailInputPlaceholderUnder13",
                            MessageInvalidEmailAddress: "Message.InvalidEmailAddress"
                        }
                    },
                    events: {
                        showAddEmailModal: {
                            name: "showAddEmailModal",
                            type: jt.modalAction,
                            context: yn,
                            params: {
                                aType: "shown",
                                field: "addEmail"
                            }
                        },
                        useAddEmailField: {
                            name: "useAddEmailField",
                            type: jt.formInteraction,
                            context: yn,
                            params: {
                                btn: "emailAddress",
                                field: "addEmail"
                            }
                        },
                        addEmailConfirm: {
                            name: "addEmailConfirm",
                            type: jt.buttonClick,
                            context: yn,
                            params: {
                                btn: "continue",
                                field: "addEmail"
                            }
                        }
                    }
                },
                Ln = function() {
                    return (Ln = Object.assign || function(e) {
                        for (var t, n = 1, r = arguments.length; n < r; n++)
                            for (var a in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
                        return e
                    }).apply(this, arguments)
                },
                Dn = Rn.events,
                On = {
                    useAddEmailToAccountEvent: function(e) {
                        var t = Dn.useAddEmailField;
                        Lt.eventStreamService.sendEventWithTarget(t.type, t.context, Ln(Ln({}, t.params), {
                            origin: e
                        }))
                    },
                    addEmailToAccountEvent: function(e) {
                        var t = Dn.addEmailConfirm;
                        Lt.eventStreamService.sendEventWithTarget(t.type, t.context, Ln(Ln({}, t.params), {
                            origin: e
                        }))
                    }
                },
                Un = function(n, e) {
                    function t(e) {
                        m(e), y("");
                        var t = b.test(p) ? g ? n(g) : "" : n(v.MessageInvalidEmailAddress);
                        h(t), f(u || e.length <= 0 || 0 < t.length)
                    }
                    var r = M(),
                        a = (0, w.useState)(!1),
                        o = a[0],
                        i = a[1],
                        c = (0, w.useState)(!1),
                        u = c[0],
                        l = (c[1], (0, w.useState)(!0)),
                        s = l[0],
                        f = l[1],
                        d = (0, w.useState)(""),
                        p = d[0],
                        m = d[1],
                        a = (0, w.useState)(""),
                        c = a[0],
                        h = a[1],
                        l = (0, w.useMemo)(function() {
                            return {
                                open: function() {
                                    return i(!0)
                                },
                                close: function() {
                                    r(In()), i(!1)
                                }
                            }
                        }, []),
                        d = Rn.emailRegex,
                        v = Rn.translationKeys.addEmailToAccountKeys,
                        a = (0, w.useState)(""),
                        g = a[0],
                        y = a[1],
                        b = new RegExp(d),
                        d = function() {
                            r(In()), i(!1), e()
                        },
                        c = S().createElement(S().Fragment, null, S().createElement("div", {
                            className: "email-upsell-image"
                        }), S().createElement("p", {
                            className: "email-upsell-text-body"
                        }, n(v.DescriptionAddEmailTextOver13, {
                            emailAddress: p
                        })), S().createElement("input", {
                            type: "email",
                            className: (c ? "input-field-error" : "") + " form-control input-field email-upsell-modal-input",
                            placeholder: n(v.LabelEmailInputPlaceholderOver13),
                            value: p,
                            onFocus: function() {
                                return On.useAddEmailToAccountEvent("")
                            },
                            onChange: function(e) {
                                return t(e.target.value)
                            }
                        }), c && S().createElement("p", {
                            className: "text-error modal-error-message"
                        }, n(c)));
                    return [S().createElement(R.Modal, {
                        show: o,
                        onHide: d,
                        backdrop: !0,
                        className: "mail-upsell-android-modal",
                        size: "sm",
                        "aria-labelledby": "contained-modal-title-vcenter",
                        scrollable: "true",
                        centered: !0
                    }, S().createElement(R.Modal.Header, {
                        useBaseBootstrapComponent: !0
                    }, S().createElement("div", {
                        className: "email-upsell-title-container"
                    }, S().createElement("button", {
                        type: "button",
                        className: "email-upsell-title-button",
                        onClick: d
                    }, S().createElement("span", {
                        className: "close icon-close"
                    })), S().createElement(R.Modal.Title, {
                        id: "contained-modal-title-vcenter"
                    }, n(v.HeadingAddEmail)))), S().createElement(R.Modal.Body, null, c), S().createElement(R.Modal.Footer, null, S().createElement(R.Button, {
                        className: "modal-button email-upsell-btn",
                        variant: R.Button.variants.cta,
                        size: R.Button.sizes.medium,
                        isDisabled: s,
                        onClick: function() {
                            y(""), r(An(p))
                        }
                    }, n(v.btnText)))), l]
                },
                Vn = (0, a.withTranslations)(function(e) {
                    var t = e.translate,
                        n = e.onHide,
                        r = M(),
                        a = E(Rt),
                        o = E(St),
                        i = E(Ct),
                        e = Un(t, n),
                        t = e[0],
                        c = e[1];
                    return (0, w.useEffect)(function() {
                        c.open()
                    }, []), (0, w.useEffect)(function() {
                        a.error && (c.close(), n())
                    }, [c, a]), (0, w.useEffect)(function() {
                        a.isEmailAdded && (c.close(), setTimeout(function() {
                            return r(Ft({
                                featureName: o,
                                ampFeatureCheckData: i
                            }))
                        }, 500))
                    }, [a]), S().createElement("div", null, t)
                }, {
                    common: ["CommonUI.Controls"],
                    feature: "Feature.VerificationUpsell"
                }),
                Bn = HeaderScripts;

            function Fn(e) {
                var n = e.translate,
                    t = e.onHide,
                    e = (o = E(Tt)).status,
                    r = o.vendorVerificationData,
                    a = e.sessionStatus,
                    o = r.qrCode,
                    e = !((null == (e = Bn.deviceMeta.getDeviceMeta()) ? void 0 : e.isPhone) || (null == e ? void 0 : e.isTablet) || "phone" === (null == e ? void 0 : e.deviceType)) && o,
                    i = Yt.findIndex(function(e) {
                        return e.statusCode.includes(a)
                    });
                return S().createElement(S().Fragment, null, S().createElement(R.Modal.Header, {
                    useBaseBootstrapComponent: !0
                }, S().createElement("div", {
                    className: "email-upsell-title-container"
                }, S().createElement("button", {
                    type: "button",
                    className: "email-upsell-title-button",
                    onClick: t
                }, S().createElement("span", {
                    className: "close icon-close"
                })), S().createElement(R.Modal.Title, {
                    id: "contained-modal-title-vcenter"
                }, n("Heading.IdentityVerification")))), S().createElement(R.Modal.Body, {
                    className: "verification-checklist-page-content"
                }, S().createElement("div", {
                    className: "cta"
                }, n(a === gt.Success || a === gt.Stored || a === gt.Submitted ? en : tn)), S().createElement("ul", {
                    className: "checklist-wrapper"
                }, Yt.map(function(e, t) {
                    return t <= i ? S().createElement("li", {
                        className: "checklist-item"
                    }, S().createElement("span", {
                        className: "check-wrapper"
                    }, S().createElement("span", {
                        className: t === i ? "spinner spinner-sm" : "icon-checkmark"
                    })), S().createElement("span", {
                        className: "checklist-text"
                    }, n(e.label))) : null
                })), e && S().createElement("div", {
                    className: "verification-link-page-content"
                }, S().createElement("div", {
                    className: "qr-code-wrapper"
                }, S().createElement("img", {
                    className: "qr-code-img",
                    src: o,
                    alt: "qr"
                })), S().createElement("div", {
                    className: "footer-text"
                }, n(Xt))), !e && S().createElement("a", {
                    href: r.verificationLink,
                    target: "_blank",
                    rel: "noreferrer"
                }, S().createElement(R.Button, {
                    onClick: function() {
                        Dt(mt.VerificationStarted, Et.GovernmentId, {
                            session: r.sessionIdentifier
                        })
                    },
                    className: "primary-link",
                    variant: R.Button.variants.primary,
                    size: R.Button.sizes.medium,
                    width: R.Button.widths.full
                }, n(Jt))), S().createElement("div", {
                    className: "footer-text"
                }, n(Zt))))
            }

            function jn(e) {
                var t = e.translate,
                    n = e.onHide,
                    r = E(Tt).vendorVerificationData,
                    a = r.loading,
                    o = r.qrCode,
                    e = !((null == (e = Bn.deviceMeta.getDeviceMeta()) ? void 0 : e.isPhone) || (null == e ? void 0 : e.isTablet) || "phone" === (null == e ? void 0 : e.deviceType)) && o;
                return S().createElement(S().Fragment, null, S().createElement(R.Modal.Header, {
                    useBaseBootstrapComponent: !0
                }, S().createElement("button", {
                    type: "button",
                    className: "email-upsell-title-button",
                    onClick: n
                }, S().createElement("span", {
                    className: "close icon-close"
                })), S().createElement("div", {
                    className: "email-upsell-title-container"
                }, S().createElement(R.Modal.Title, {
                    id: "contained-modal-title-vcenter"
                }, t("Heading.IdentityVerification")))), a ? S().createElement(R.Loading, null) : S().createElement(R.Modal.Body, {
                    className: "verification-link-page-content"
                }, S().createElement("div", {
                    className: "verification-link-upsell"
                }, t(nn)), S().createElement("div", {
                    className: "preparation-list-wrapper"
                }, S().createElement("div", {
                    className: "preparation-list-item"
                }, S().createElement("span", {
                    className: "icon-menu-document"
                }), S().createElement("div", {
                    className: "preparation-list-text"
                }, S().createElement("div", {
                    className: "preparation-title"
                }, t(rn)), S().createElement("div", {
                    className: "preparation-text"
                }, t(an)))), e && S().createElement("div", {
                    className: "preparation-list-item"
                }, S().createElement("span", {
                    className: "icon-menu-mobile"
                }), S().createElement("div", {
                    className: "preparation-list-text"
                }, S().createElement("div", {
                    className: "preparation-title"
                }, t(on)), S().createElement("div", {
                    className: "preparation-text"
                }, t(cn))))), e && S().createElement("div", null, S().createElement("div", {
                    className: "verification-link-upsell"
                }, t(un)), S().createElement("div", {
                    className: "qr-code-wrapper"
                }, S().createElement("img", {
                    className: "qr-code-img",
                    src: o,
                    alt: "qr"
                }))), S().createElement("p", {
                    className: "verification-link-legal",
                    dangerouslySetInnerHTML: {
                        __html: t(ln, {
                            spanStart: "<a class='text-link' href='https://en.help.roblox.com/hc/en-us/articles/4412863575316'>",
                            spanEnd: "</a>"
                        })
                    }
                }), !e && S().createElement("a", {
                    href: r.verificationLink,
                    target: "_self",
                    rel: "noreferrer"
                }, S().createElement(R.Button, {
                    onClick: function() {
                        return console.log("start sesesion")
                    },
                    className: "primary-link",
                    variant: R.Button.variants.primary,
                    size: R.Button.sizes.medium,
                    width: R.Button.widths.full
                }, t(Qt)))))
            }

            function _n(e) {
                var t = e.translate,
                    n = e.onHide,
                    r = (u = E(Tt)).completionPageState,
                    a = u.status,
                    o = u.vendorVerificationData.daysUntilNextVerification,
                    i = r.heading,
                    c = r.bodyText,
                    e = r.icon,
                    u = r.footerText,
                    r = r.buttonText,
                    a = a.sessionStatus === gt.Failure;
                return S().createElement(S().Fragment, null, S().createElement(R.Modal.Header, {
                    useBaseBootstrapComponent: !0
                }, S().createElement("div", {
                    className: "email-upsell-title-container"
                }, S().createElement("button", {
                    type: "button",
                    className: "email-upsell-title-button",
                    onClick: n
                }, S().createElement("span", {
                    className: "close icon-close"
                })), S().createElement(R.Modal.Title, {
                    id: "contained-modal-title-vcenter"
                }, t(i)))), S().createElement(R.Modal.Body, null, e && S().createElement("div", {
                    className: e
                }), S().createElement("ul", {
                    className: a ? "content-list error-text" : "content-list"
                }, c.map(function(e) {
                    return S().createElement("li", null, t(e, {
                        age: 18,
                        days: o
                    }))
                }))), S().createElement(R.Modal.Footer, null, u && S().createElement("p", {
                    className: "small"
                }, S().createElement("b", null, t(u))), S().createElement("span", {
                    key: r
                }, S().createElement(R.Button, {
                    className: "button-stack-button primary-link",
                    variant: R.Button.variants.primary,
                    size: R.Button.sizes.medium,
                    onClick: n
                }, t(r)))))
            }

            function qn(e) {
                var t = e.translate,
                    n = e.onHidecallback,
                    r = (0, w.useRef)(Number(new Date) + 18e5),
                    a = M(),
                    o = E(Tt),
                    i = E(St),
                    c = E(Ct),
                    u = o.loading,
                    l = o.vendorVerificationData,
                    s = E(Tt).page;

                function f() {
                    a(bn()), n()
                }(0, w.useEffect)(function() {
                    a(vn()), r.current = Number(new Date) + 18e5
                }, [a]), (0, w.useEffect)(function() {
                    !u && null != l.verificationLink && o.page !== vt.Complete && Number(new Date) < r.current && setTimeout(function() {
                        a(gn(l.sessionIdentifier))
                    }, 15e3)
                }, [o.loading]), (0, w.useEffect)(function() {
                    s === vt.Complete && a(Ft({
                        featureName: i,
                        ampFeatureCheckData: c
                    }))
                }, [s]);
                var d = null;
                switch (s) {
                    case vt.VendorLink:
                        d = S().createElement(jn, {
                            translate: t,
                            onHide: f
                        });
                        break;
                    case vt.Checklist:
                        d = S().createElement(Fn, {
                            translate: t,
                            onHide: f
                        });
                        break;
                    case vt.Complete:
                        d = S().createElement(_n, {
                            translate: t,
                            onHide: f
                        });
                        break;
                    default:
                        d = S().createElement(jn, {
                            translate: t,
                            onHide: f
                        })
                }
                return S().createElement(S().Fragment, null, d)
            }

            function Hn(e) {
                return e.translate, S().createElement(S().Fragment, null)
            }
            var zn = e.EnvironmentUrls.apiGatewayUrl + "/child-requests-api/v1/send-request-to-new-parent",
                Kn = e.EnvironmentUrls.apiGatewayUrl + "/child-requests-api/v1/send-request-to-all-parents",
                Gn = e.EnvironmentUrls.userSettingsApi + "/v1/account-insights/parent-emails",
                $n = function(e, i, c, u) {
                    return new(c = c || Promise)(function(n, t) {
                        function r(e) {
                            try {
                                o(u.next(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function a(e) {
                            try {
                                o(u.throw(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function o(e) {
                            var t;
                            e.done ? n(e.value) : ((t = e.value) instanceof c ? t : new c(function(e) {
                                e(t)
                            })).then(r, a)
                        }
                        o((u = u.apply(e, i || [])).next())
                    })
                },
                Wn = function(n, r) {
                    var a, o, i, c = {
                            label: 0,
                            sent: function() {
                                if (1 & i[0]) throw i[1];
                                return i[1]
                            },
                            trys: [],
                            ops: []
                        },
                        e = {
                            next: t(0),
                            throw: t(1),
                            return: t(2)
                        };
                    return "function" == typeof Symbol && (e[Symbol.iterator] = function() {
                        return this
                    }), e;

                    function t(t) {
                        return function(e) {
                            return function(t) {
                                if (a) throw new TypeError("Generator is already executing.");
                                for (; c;) try {
                                    if (a = 1, o && (i = 2 & t[0] ? o.return : t[0] ? o.throw || ((i = o.return) && i.call(o), 0) : o.next) && !(i = i.call(o, t[1])).done) return i;
                                    switch (o = 0, i && (t = [2 & t[0], i.value]), t[0]) {
                                        case 0:
                                        case 1:
                                            i = t;
                                            break;
                                        case 4:
                                            return c.label++, {
                                                value: t[1],
                                                done: !1
                                            };
                                        case 5:
                                            c.label++, o = t[1], t = [0];
                                            continue;
                                        case 7:
                                            t = c.ops.pop(), c.trys.pop();
                                            continue;
                                        default:
                                            if (!(i = 0 < (i = c.trys).length && i[i.length - 1]) && (6 === t[0] || 2 === t[0])) {
                                                c = 0;
                                                continue
                                            }
                                            if (3 === t[0] && (!i || t[1] > i[0] && t[1] < i[3])) {
                                                c.label = t[1];
                                                break
                                            }
                                            if (6 === t[0] && c.label < i[1]) {
                                                c.label = i[1], i = t;
                                                break
                                            }
                                            if (i && c.label < i[2]) {
                                                c.label = i[2], c.ops.push(t);
                                                break
                                            }
                                            i[2] && c.ops.pop(), c.trys.pop();
                                            continue
                                    }
                                    t = r.call(n, c)
                                } catch (e) {
                                    t = [6, e], o = 0
                                } finally {
                                    a = i = 0
                                }
                                if (5 & t[0]) throw t[1];
                                return {
                                    value: t[0] ? t[1] : void 0,
                                    done: !0
                                }
                            }([t, e])
                        }
                    }
                },
                Yn = {
                    sendRequestToNewParent: function(r) {
                        return $n(void 0, void 0, Promise, function() {
                            var t, n;
                            return Wn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return t = {
                                            url: zn,
                                            withCredentials: !0
                                        }, n = r.requestDetails, [4, i.httpService.post(t, r)];
                                    case 1:
                                        return t = e.sent(), n && (n = Object.keys(n)[0], Lt.localStorageService.setLocalStorage("Roblox.ParentalRequest." + n + "CooldownExpirationTime", t.data.lockedUntil)), [2, t.data]
                                }
                            })
                        })
                    },
                    sendRequestToAllParents: function(r) {
                        return $n(void 0, void 0, Promise, function() {
                            var t, n;
                            return Wn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return t = {
                                            url: Kn,
                                            withCredentials: !0
                                        }, n = r.requestDetails, [4, i.httpService.post(t, r)];
                                    case 1:
                                        return t = e.sent(), n && (n = Object.keys(n)[0], Lt.localStorageService.setLocalStorage("Roblox.ParentalRequest." + n + "CooldownExpirationTime", t.data.lockedUntil)), [2, t.data]
                                }
                            })
                        })
                    }
                },
                yn = Kr(779),
                Jn = Kr.n(yn),
                Qn = function(e) {
                    var t = e.translate,
                        n = e.title,
                        r = e.body,
                        a = e.actionButtonTranslateKey,
                        o = void 0 === a ? "" : a,
                        i = e.neutralButtonTranslateKey,
                        c = e.footer,
                        u = e.size,
                        l = void 0 === u ? "sm" : u,
                        s = e.onAction,
                        f = e.disableActionButton,
                        d = e.disabledNeutralButton,
                        a = e.dualActionButton,
                        u = void 0 !== a && a,
                        a = e.onHide,
                        p = void 0 === a ? function() {} : a,
                        m = e.onNeutral,
                        a = (0, w.useState)(!1),
                        e = a[0],
                        h = a[1],
                        v = (0, w.useMemo)(function() {
                            return {
                                open: function() {
                                    return h(!0)
                                },
                                close: function() {
                                    return h(!1)
                                }
                            }
                        }, []),
                        a = Jn()({
                            "modal-half-width-button": i,
                            "modal-full-width-button": !i
                        });
                    return [S().createElement(R.Modal, {
                        show: e,
                        onHide: function() {
                            v.close(), p()
                        },
                        backdrop: !0,
                        className: "user-settings-modal",
                        size: l,
                        "aria-labelledby": "user-settings-modal-title",
                        scrollable: !0,
                        centered: !0
                    }, S().createElement(R.Modal.Header, {
                        useBaseBootstrapComponent: !0
                    }, S().createElement("div", {
                        className: "user-settings-modal-title-container"
                    }, S().createElement(R.Modal.Title, {
                        id: "user-settings-modal-title"
                    }, n)), S().createElement("button", {
                        type: "button",
                        className: "close close-button",
                        onClick: function() {
                            v.close(), p()
                        }
                    }, S().createElement("span", {
                        className: "icon-close"
                    }))), S().createElement(R.Modal.Body, null, r), S().createElement(R.Modal.Footer, null, o && S().createElement(R.Button, {
                        className: a,
                        variant: R.Button.variants.primary,
                        size: R.Button.sizes.medium,
                        isDisabled: f,
                        onClick: function() {
                            null != s && s(), v.close()
                        }
                    }, t(o)), i && S().createElement(R.Button, {
                        className: a,
                        variant: u ? R.Button.variants.primary : R.Button.variants.secondary,
                        size: R.Button.sizes.medium,
                        isDisabled: d,
                        onClick: function() {
                            null != m && m(), v.close()
                        }
                    }, t(i))), c && S().createElement("div", {
                        className: "text-footer user-settings-modal-text-footer border-top"
                    }, c)), v]
                },
                Xn = {
                    privacyPolicyUrl: e.EnvironmentUrls.websiteUrl + "/info/privacy",
                    chargebackWizardSessionTokenLocalStorageKey: "Roblox.ChargebackWizardSessionToken",
                    defaultCooldownTimeInMs: 9e5,
                    emailRegex: "^\\w+([-+.]\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*$",
                    translationKeys: {
                        gatherParentEmail: {
                            title: "Title.EnterParentEmail",
                            body: "Description.EnterParentEmailV3",
                            footer: "Description.ParentalEmailFooter",
                            unknownError: "Message.SomethingWentWrong",
                            invalidEmailError: "Message.InvalidEmail",
                            btnText: "Action.Submit",
                            emailPlaceholder: "Label.Email",
                            emailTooManyChildrenError: "Message.EmailIneligible",
                            childTooManyParentsError: "Message.ExistAccountWithEmail",
                            emailTooManyRequest: "Message.TooManyAttempts",
                            alreadyApplied: "Description.AllSet"
                        },
                        emailSentConfirmation: {
                            title: "Title.RequestSent",
                            oneParentBody: "Message.EmailSent",
                            pluralParentBody: "Message.EmailSentPluralParent",
                            btnText: "Action.OK"
                        },
                        exitWarning: {
                            title: "Title.AreYouSure",
                            body: "Description.ExitEnterEmail",
                            actionBtnText: "Action.EnterEmail",
                            neutralBtnText: "Action.Cancel"
                        }
                    },
                    events: {
                        chargebackContext: {
                            parentalEntry: "parentalEntry",
                            settingsAge: "settingsAgeChargeback",
                            settingsRequestSent: "settingsChargebackRequestSent"
                        },
                        savePaymentMethodsContext: {
                            parentalEntry: "parentalEntryDevsubs",
                            settingsAge: "settingsAgeSavePaymentMethods",
                            settingsRequestSent: "settingsSavePaymentMethodsRequestSent"
                        },
                        changeBirthdayContext: {
                            parentalEntry: "parentalEntryAgeChange",
                            settingsAge: "settingsAgeChangeBirthday",
                            settingsRequestSent: "settingsAgeChangeVerifyRequestSent"
                        },
                        eventName: {
                            authPageLoad: "authPageload",
                            authButtonClick: "authButtonClick",
                            authFormInteraction: "authFormInteraction",
                            authMsgShown: "authMsgShown",
                            authModalShown: "authModalShown"
                        },
                        state: {
                            sessionId: "sessionId",
                            unknown: "unknown",
                            changeBirthday: {
                                U13To18: "U13To18",
                                U13To1318: "U13To1318",
                                U13ToU13: "U13ToU13"
                            }
                        },
                        field: {
                            email: "email",
                            errorMessage: "errorMessage",
                            logoutPopup: "logoutPopup",
                            parentalEmailMismatch: "parentalEmailMismatch"
                        },
                        btn: {
                            verifyCancel: "verifyCancel",
                            continue: "continue",
                            submit: "submit"
                        },
                        text: {
                            enterParentEmail: "Enter Parent's Email",
                            sendEmail: "Send Email",
                            submit: "Submit",
                            ok: "OK",
                            requestSent: "Request Sent"
                        }
                    }
                };
            (e = er = er || {}).Unknown = "Unknown", e.InvalidUserID = "InvalidUserID", e.InvalidParameter = "InvalidParameter", e.ServiceUnavailable = "ServiceUnavailable", e.NoLinkedParents = "NoLinkedParents", e.ConsentAlreadyApplied = "ConsentAlreadyApplied", e.SenderFlooded = "SenderFlooded", e.ReceiverFlooded = "ReceiverFlooded", e.SenderFloodedRequestCreated = "SenderFloodedRequestCreated", e.IllegalState = "IllegalState", e.InvalidEmailAddress = "InvalidEmailAddress", e.EmailNotUnique = "EmailNotUnique", e.LinkingIneligible = "LinkingIneligible", e.AlreadyLinked = "AlreadyLinked", e.ChildAtLinkLimit = "ChildAtLinkLimit", e.ParentAtLinkLimit = "ParentAtLinkLimit", e.UpdateUserSettingRequestInvalid = "UpdateUserSettingRequestInvalid", e.ConsentAlreadyRequestedConflictingData = "ConsentAlreadyRequestedConflictingData", e.ReceiverNotWhitelisted = "ReceiverNotWhitelisted", e.InvalidComplianceFeature = "InvalidComplianceFeature", e.ChildTooOld = "ChildTooOld", e.UserForgotten = "UserForgotten";
            var Zn, er, tr = er,
                nr = Xn.translationKeys.gatherParentEmail,
                rr = function(e) {
                    switch (e) {
                        case tr.ChildAtLinkLimit:
                            return nr.childTooManyParentsError;
                        case tr.ParentAtLinkLimit:
                            return nr.emailTooManyChildrenError;
                        case tr.SenderFlooded:
                        case tr.ReceiverFlooded:
                            return nr.emailTooManyRequest;
                        case tr.ConsentAlreadyApplied:
                        case tr.AlreadyLinked:
                            return nr.body;
                        case tr.InvalidEmailAddress:
                            return nr.invalidEmailError;
                        default:
                            return nr.unknownError
                    }
                };

            function ar(e, t) {
                return (t ? t + ", " : "") + (e ? "sessionId: " + e + ", " : "")
            }

            function or(e) {
                var t;
                switch (e) {
                    case ur.ChargebackReenableAccount:
                        t = lr.chargebackContext;
                        break;
                    case ur.SavePaymentMethods:
                        t = lr.savePaymentMethodsContext;
                        break;
                    case ur.UpdateBirthdate:
                        t = lr.changeBirthdayContext;
                        break;
                    default:
                        t = lr.chargebackContext
                }
                return t
            }

            function ir(e) {
                function t() {
                    return dr(void 0, void 0, void 0, function() {
                        var a, o;
                        return pr(this, function(e) {
                            switch (e.label) {
                                case 0:
                                    return e.trys.push([0, 2, , 3]), [4, Yn.sendRequestToAllParents({
                                        requestType: i,
                                        requestDetails: u
                                    })];
                                case 1:
                                    return o = e.sent(), a = null == u ? void 0 : u.newBirthdate, a = new Date(a), a = fr.getAgeRange(a), t = ur.UpdateBirthdate, n = a, r = o.sessionId, t = or(t), Lt.eventStreamService.sendEventWithTarget(lr.eventName.authPageLoad, t.settingsRequestSent, {
                                        state: ar(r, n),
                                        associatedText: lr.text.requestSent
                                    }), c(o.sessionId), [3, 3];
                                case 2:
                                    return (o = e.sent()) instanceof Error && (o = rr(o.message), l(o)), s.open(), [3, 3];
                                case 3:
                                    return [2]
                            }
                            var t, n, r
                        })
                    })
                }
                var n = e.translate,
                    i = e.consentType,
                    c = e.successCallBack,
                    r = e.onHideCallback,
                    u = void 0 === (a = e.value) ? null : a,
                    a = (e = (0, w.useState)(Xn.translationKeys.gatherParentEmail.unknownError))[0],
                    l = e[1],
                    e = Xn.translationKeys.emailSentConfirmation,
                    e = (a = Qn({
                        translate: n,
                        title: n(Xn.translationKeys.gatherParentEmail.unknownError),
                        body: S().createElement("p", null, n(a)),
                        actionButtonTranslateKey: e.btnText,
                        onAction: function() {
                            l(""), s.close(), r()
                        },
                        onHide: r
                    }))[0],
                    s = a[1];
                return (0, w.useEffect)(function() {
                    t()
                }, []), S().createElement("div", null, e)
            }

            function cr(e) {
                var t = e.translate,
                    n = e.consentType,
                    r = e.successCallback,
                    a = e.onHidecallback,
                    e = e.value,
                    e = (a = vr(t, n, r, a, e))[0],
                    o = a[1];
                return (0, w.useEffect)(function() {
                    o.open()
                }, []), S().createElement(S().Fragment, null, e)
            }(er = Zn = Zn || {}).ChargebackReenableAccount = "ChargebackReenableAccount", er.SavePaymentMethods = "SavePaymentMethods", er.UpdateUserSetting = "UpdateUserSetting", er.UpdateBirthdate = "UpdateBirthdate", er.LinkToChild = "LinkToChild", er.Unknown = "Unknown";
            var ur = Zn,
                lr = Xn.events,
                sr = {
                    calculateAge: function(e) {
                        var t = (new Date).toISOString().split("T")[0],
                            e = new Date(t).getTime() - e.getTime(),
                            e = new Date(e);
                        return Math.abs(e.getUTCFullYear() - 1970)
                    },
                    getAgeRange: function(e) {
                        var t = Xn.events.state.changeBirthday;
                        return sr.calculateAge(e) < 13 ? t.U13ToU13 : t.U13To1318
                    }
                },
                fr = sr,
                dr = function(e, i, c, u) {
                    return new(c = c || Promise)(function(n, t) {
                        function r(e) {
                            try {
                                o(u.next(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function a(e) {
                            try {
                                o(u.throw(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function o(e) {
                            var t;
                            e.done ? n(e.value) : ((t = e.value) instanceof c ? t : new c(function(e) {
                                e(t)
                            })).then(r, a)
                        }
                        o((u = u.apply(e, i || [])).next())
                    })
                },
                pr = function(n, r) {
                    var a, o, i, c = {
                            label: 0,
                            sent: function() {
                                if (1 & i[0]) throw i[1];
                                return i[1]
                            },
                            trys: [],
                            ops: []
                        },
                        e = {
                            next: t(0),
                            throw: t(1),
                            return: t(2)
                        };
                    return "function" == typeof Symbol && (e[Symbol.iterator] = function() {
                        return this
                    }), e;

                    function t(t) {
                        return function(e) {
                            return function(t) {
                                if (a) throw new TypeError("Generator is already executing.");
                                for (; c;) try {
                                    if (a = 1, o && (i = 2 & t[0] ? o.return : t[0] ? o.throw || ((i = o.return) && i.call(o), 0) : o.next) && !(i = i.call(o, t[1])).done) return i;
                                    switch (o = 0, i && (t = [2 & t[0], i.value]), t[0]) {
                                        case 0:
                                        case 1:
                                            i = t;
                                            break;
                                        case 4:
                                            return c.label++, {
                                                value: t[1],
                                                done: !1
                                            };
                                        case 5:
                                            c.label++, o = t[1], t = [0];
                                            continue;
                                        case 7:
                                            t = c.ops.pop(), c.trys.pop();
                                            continue;
                                        default:
                                            if (!(i = 0 < (i = c.trys).length && i[i.length - 1]) && (6 === t[0] || 2 === t[0])) {
                                                c = 0;
                                                continue
                                            }
                                            if (3 === t[0] && (!i || t[1] > i[0] && t[1] < i[3])) {
                                                c.label = t[1];
                                                break
                                            }
                                            if (6 === t[0] && c.label < i[1]) {
                                                c.label = i[1], i = t;
                                                break
                                            }
                                            if (i && c.label < i[2]) {
                                                c.label = i[2], c.ops.push(t);
                                                break
                                            }
                                            i[2] && c.ops.pop(), c.trys.pop();
                                            continue
                                    }
                                    t = r.call(n, c)
                                } catch (e) {
                                    t = [6, e], o = 0
                                } finally {
                                    a = i = 0
                                }
                                if (5 & t[0]) throw t[1];
                                return {
                                    value: t[0] ? t[1] : void 0,
                                    done: !0
                                }
                            }([t, e])
                        }
                    }
                },
                mr = function(e, i, c, u) {
                    return new(c = c || Promise)(function(n, t) {
                        function r(e) {
                            try {
                                o(u.next(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function a(e) {
                            try {
                                o(u.throw(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function o(e) {
                            var t;
                            e.done ? n(e.value) : ((t = e.value) instanceof c ? t : new c(function(e) {
                                e(t)
                            })).then(r, a)
                        }
                        o((u = u.apply(e, i || [])).next())
                    })
                },
                hr = function(n, r) {
                    var a, o, i, c = {
                            label: 0,
                            sent: function() {
                                if (1 & i[0]) throw i[1];
                                return i[1]
                            },
                            trys: [],
                            ops: []
                        },
                        e = {
                            next: t(0),
                            throw: t(1),
                            return: t(2)
                        };
                    return "function" == typeof Symbol && (e[Symbol.iterator] = function() {
                        return this
                    }), e;

                    function t(t) {
                        return function(e) {
                            return function(t) {
                                if (a) throw new TypeError("Generator is already executing.");
                                for (; c;) try {
                                    if (a = 1, o && (i = 2 & t[0] ? o.return : t[0] ? o.throw || ((i = o.return) && i.call(o), 0) : o.next) && !(i = i.call(o, t[1])).done) return i;
                                    switch (o = 0, i && (t = [2 & t[0], i.value]), t[0]) {
                                        case 0:
                                        case 1:
                                            i = t;
                                            break;
                                        case 4:
                                            return c.label++, {
                                                value: t[1],
                                                done: !1
                                            };
                                        case 5:
                                            c.label++, o = t[1], t = [0];
                                            continue;
                                        case 7:
                                            t = c.ops.pop(), c.trys.pop();
                                            continue;
                                        default:
                                            if (!(i = 0 < (i = c.trys).length && i[i.length - 1]) && (6 === t[0] || 2 === t[0])) {
                                                c = 0;
                                                continue
                                            }
                                            if (3 === t[0] && (!i || t[1] > i[0] && t[1] < i[3])) {
                                                c.label = t[1];
                                                break
                                            }
                                            if (6 === t[0] && c.label < i[1]) {
                                                c.label = i[1], i = t;
                                                break
                                            }
                                            if (i && c.label < i[2]) {
                                                c.label = i[2], c.ops.push(t);
                                                break
                                            }
                                            i[2] && c.ops.pop(), c.trys.pop();
                                            continue
                                    }
                                    t = r.call(n, c)
                                } catch (e) {
                                    t = [6, e], o = 0
                                } finally {
                                    a = i = 0
                                }
                                if (5 & t[0]) throw t[1];
                                return {
                                    value: t[0] ? t[1] : void 0,
                                    done: !0
                                }
                            }([t, e])
                        }
                    }
                },
                vr = function(e, a, o, t, i) {
                    function n() {
                        return mr(void 0, void 0, void 0, function() {
                            var r;
                            return hr(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        b(""), Lt.localStorageService.removeLocalStorage(v), e.label = 1;
                                    case 1:
                                        return e.trys.push([1, 3, , 4]), [4, Yn.sendRequestToNewParent({
                                            email: p,
                                            requestType: a,
                                            requestDetails: i
                                        })];
                                    case 2:
                                        return r = e.sent(), t = a, n = r.sessionId, t = or(t), Lt.eventStreamService.sendEventWithTarget(lr.eventName.authButtonClick, t.parentalEntry, {
                                            btn: lr.btn.submit,
                                            associatedText: lr.text.sendEmail,
                                            state: ar(n)
                                        }), f(!1), h.close(), o(r.sessionId, p), [3, 4];
                                    case 3:
                                        return r = e.sent(), m(""), f(!1), r instanceof Error ? (r = rr(r.message), b(r)) : b(g.unknownError), [3, 4];
                                    case 4:
                                        return [2]
                                }
                                var t, n
                            })
                        })
                    }
                    var r = (0, w.useState)(!1),
                        c = r[0],
                        u = r[1],
                        l = (0, w.useState)(!1),
                        s = l[0],
                        f = l[1],
                        d = (0, w.useState)(""),
                        p = d[0],
                        m = d[1],
                        h = (0, w.useMemo)(function() {
                            return {
                                open: function() {
                                    return u(!0)
                                },
                                close: function() {
                                    return u(!1)
                                }
                            }
                        }, []),
                        r = Xn.privacyPolicyUrl,
                        v = Xn.chargebackWizardSessionTokenLocalStorageKey,
                        l = Xn.emailRegex,
                        g = Xn.translationKeys.gatherParentEmail,
                        d = (0, w.useState)(""),
                        y = d[0],
                        b = d[1],
                        E = new RegExp(l),
                        l = function() {
                            return 0 < p.length && !E.test(p) ? e(g.invalidEmailError) : y ? e(y) : ""
                        },
                        r = S().createElement(S().Fragment, null, S().createElement("div", {
                            className: "parental-consent-modal-body"
                        }, S().createElement("span", {
                            dangerouslySetInnerHTML: {
                                __html: e(g.body, {
                                    lineBreak: "<br /><br />"
                                })
                            }
                        })), S().createElement("form", {
                            className: "form-horizontal",
                            autoComplete: "off"
                        }, S().createElement("div", {
                            id: "parent-email-container",
                            className: "form-group"
                        }, S().createElement("input", {
                            id: "parent-email-address",
                            type: "email",
                            className: "form-control input-field",
                            placeholder: e(g.emailPlaceholder),
                            autoComplete: "off",
                            value: p,
                            onChange: function(e) {
                                m(e.target.value), b("")
                            },
                            onFocus: function() {
                                return function(e) {
                                    e = or(e);
                                    Lt.eventStreamService.sendEventWithTarget(lr.eventName.authFormInteraction, e.parentalEntry, {
                                        field: lr.field.email,
                                        associatedText: lr.text.enterParentEmail
                                    })
                                }(a)
                            }
                        })), S().createElement("input", {
                            type: "text",
                            className: "hidden",
                            name: "fake-username"
                        }), S().createElement("input", {
                            type: "password",
                            className: "hidden",
                            name: "fake-password",
                            autoComplete: "new-password"
                        })), S().createElement("div", {
                            className: "form-group"
                        }, S().createElement("p", {
                            className: "text-error form-control-label"
                        }, l())), S().createElement("div", {
                            className: "text-footer user-settings-modal-text-footer",
                            dangerouslySetInnerHTML: {
                                __html: e(g.footer, {
                                    linkStart: "<a class='text-link' rel='noreferrer' target='_blank' href='" + r + "'>",
                                    linkEnd: "</a>"
                                })
                            }
                        }));
                    return [S().createElement(R.Modal, {
                        show: c,
                        onHide: function() {
                            h.close(), t()
                        },
                        backdrop: !0,
                        className: "user-settings-modal",
                        size: "sm",
                        "aria-labelledby": "user-settings-modal-title",
                        centered: !0
                    }, S().createElement(R.Modal.Header, {
                        useBaseBootstrapComponent: !0
                    }, S().createElement("div", {
                        className: "user-settings-modal-title-container"
                    }, S().createElement(R.Modal.Title, {
                        id: "user-settings-modal-title"
                    }, e(g.title))), S().createElement("button", {
                        type: "button",
                        className: "close close-button",
                        onClick: function() {
                            h.close(), t()
                        }
                    }, S().createElement("span", {
                        className: "icon-close"
                    }))), S().createElement(R.Modal.Body, null, r), S().createElement(R.Modal.Footer, null, S().createElement(R.Button, {
                        variant: R.Button.variants.primary,
                        size: R.Button.sizes.medium,
                        width: R.Button.widths.full,
                        isDisabled: "" === p || "" !== l(),
                        isLoading: s,
                        onClick: function() {
                            return mr(void 0, void 0, void 0, function() {
                                return hr(this, function(e) {
                                    switch (e.label) {
                                        case 0:
                                            return f(!0), [4, n()];
                                        case 1:
                                            return e.sent(), [2]
                                    }
                                })
                            })
                        }
                    }, e(g.btnText)))), h]
                },
                gr = function(e, i, c, u) {
                    return new(c = c || Promise)(function(n, t) {
                        function r(e) {
                            try {
                                o(u.next(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function a(e) {
                            try {
                                o(u.throw(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function o(e) {
                            var t;
                            e.done ? n(e.value) : ((t = e.value) instanceof c ? t : new c(function(e) {
                                e(t)
                            })).then(r, a)
                        }
                        o((u = u.apply(e, i || [])).next())
                    })
                },
                yr = function(n, r) {
                    var a, o, i, c = {
                            label: 0,
                            sent: function() {
                                if (1 & i[0]) throw i[1];
                                return i[1]
                            },
                            trys: [],
                            ops: []
                        },
                        e = {
                            next: t(0),
                            throw: t(1),
                            return: t(2)
                        };
                    return "function" == typeof Symbol && (e[Symbol.iterator] = function() {
                        return this
                    }), e;

                    function t(t) {
                        return function(e) {
                            return function(t) {
                                if (a) throw new TypeError("Generator is already executing.");
                                for (; c;) try {
                                    if (a = 1, o && (i = 2 & t[0] ? o.return : t[0] ? o.throw || ((i = o.return) && i.call(o), 0) : o.next) && !(i = i.call(o, t[1])).done) return i;
                                    switch (o = 0, i && (t = [2 & t[0], i.value]), t[0]) {
                                        case 0:
                                        case 1:
                                            i = t;
                                            break;
                                        case 4:
                                            return c.label++, {
                                                value: t[1],
                                                done: !1
                                            };
                                        case 5:
                                            c.label++, o = t[1], t = [0];
                                            continue;
                                        case 7:
                                            t = c.ops.pop(), c.trys.pop();
                                            continue;
                                        default:
                                            if (!(i = 0 < (i = c.trys).length && i[i.length - 1]) && (6 === t[0] || 2 === t[0])) {
                                                c = 0;
                                                continue
                                            }
                                            if (3 === t[0] && (!i || t[1] > i[0] && t[1] < i[3])) {
                                                c.label = t[1];
                                                break
                                            }
                                            if (6 === t[0] && c.label < i[1]) {
                                                c.label = i[1], i = t;
                                                break
                                            }
                                            if (i && c.label < i[2]) {
                                                c.label = i[2], c.ops.push(t);
                                                break
                                            }
                                            i[2] && c.ops.pop(), c.trys.pop();
                                            continue
                                    }
                                    t = r.call(n, c)
                                } catch (e) {
                                    t = [6, e], o = 0
                                } finally {
                                    a = i = 0
                                }
                                if (5 & t[0]) throw t[1];
                                return {
                                    value: t[0] ? t[1] : void 0,
                                    done: !0
                                }
                            }([t, e])
                        }
                    }
                },
                br = {
                    getLinkedParentEmails: function() {
                        return gr(void 0, void 0, Promise, function() {
                            var t;
                            return yr(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return t = {
                                            url: Gn,
                                            withCredentials: !0
                                        }, [4, i.httpService.get(t)];
                                    case 1:
                                        return [2, e.sent().data]
                                }
                            })
                        })
                    }
                },
                Er = function(e, i, c, u) {
                    return new(c = c || Promise)(function(n, t) {
                        function r(e) {
                            try {
                                o(u.next(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function a(e) {
                            try {
                                o(u.throw(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function o(e) {
                            var t;
                            e.done ? n(e.value) : ((t = e.value) instanceof c ? t : new c(function(e) {
                                e(t)
                            })).then(r, a)
                        }
                        o((u = u.apply(e, i || [])).next())
                    })
                },
                wr = function(n, r) {
                    var a, o, i, c = {
                            label: 0,
                            sent: function() {
                                if (1 & i[0]) throw i[1];
                                return i[1]
                            },
                            trys: [],
                            ops: []
                        },
                        e = {
                            next: t(0),
                            throw: t(1),
                            return: t(2)
                        };
                    return "function" == typeof Symbol && (e[Symbol.iterator] = function() {
                        return this
                    }), e;

                    function t(t) {
                        return function(e) {
                            return function(t) {
                                if (a) throw new TypeError("Generator is already executing.");
                                for (; c;) try {
                                    if (a = 1, o && (i = 2 & t[0] ? o.return : t[0] ? o.throw || ((i = o.return) && i.call(o), 0) : o.next) && !(i = i.call(o, t[1])).done) return i;
                                    switch (o = 0, i && (t = [2 & t[0], i.value]), t[0]) {
                                        case 0:
                                        case 1:
                                            i = t;
                                            break;
                                        case 4:
                                            return c.label++, {
                                                value: t[1],
                                                done: !1
                                            };
                                        case 5:
                                            c.label++, o = t[1], t = [0];
                                            continue;
                                        case 7:
                                            t = c.ops.pop(), c.trys.pop();
                                            continue;
                                        default:
                                            if (!(i = 0 < (i = c.trys).length && i[i.length - 1]) && (6 === t[0] || 2 === t[0])) {
                                                c = 0;
                                                continue
                                            }
                                            if (3 === t[0] && (!i || t[1] > i[0] && t[1] < i[3])) {
                                                c.label = t[1];
                                                break
                                            }
                                            if (6 === t[0] && c.label < i[1]) {
                                                c.label = i[1], i = t;
                                                break
                                            }
                                            if (i && c.label < i[2]) {
                                                c.label = i[2], c.ops.push(t);
                                                break
                                            }
                                            i[2] && c.ops.pop(), c.trys.pop();
                                            continue
                                    }
                                    t = r.call(n, c)
                                } catch (e) {
                                    t = [6, e], o = 0
                                } finally {
                                    a = i = 0
                                }
                                if (5 & t[0]) throw t[1];
                                return {
                                    value: t[0] ? t[1] : void 0,
                                    done: !0
                                }
                            }([t, e])
                        }
                    }
                },
                Sr = (0, a.withTranslations)(function(e) {
                    var t = e.translate,
                        n = e.recourse,
                        r = e.onHidecallback,
                        a = e.value,
                        o = void 0 === a ? null : a,
                        e = Xn.translationKeys.emailSentConfirmation,
                        i = n.action,
                        a = n.parentConsentTypes,
                        c = null == a ? void 0 : a[0],
                        n = (0, w.useState)([]),
                        a = n[0],
                        u = n[1],
                        a = Qn({
                            translate: t,
                            title: t(e.title),
                            body: 1 === a.length ? S().createElement("p", {
                                dangerouslySetInnerHTML: {
                                    __html: t(e.oneParentBody, {
                                        parentEmail: a[0]
                                    })
                                }
                            }) : S().createElement("p", null, t(e.pluralParentBody)),
                            actionButtonTranslateKey: e.btnText,
                            onAction: function() {
                                l.close(), r()
                            },
                            onHide: r
                        }),
                        e = a[0],
                        l = a[1];
                    (0, w.useEffect)(function() {
                        i === Et.ParentConsentRequest && Er(void 0, void 0, void 0, function() {
                            return wr(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, br.getLinkedParentEmails().then(function(e) {
                                            u(e.parentEmails)
                                        })];
                                    case 1:
                                        return e.sent(), [2]
                                }
                            })
                        })
                    }, [i]);
                    a = function(e, t) {
                        var n;
                        t && u([t]), l.open(), c === ur.UpdateBirthdate && (n = null == o ? void 0 : o.newBirthdate, t = new Date(n), n = fr.getAgeRange(t), t = ur.UpdateBirthdate, n = n, e = e, t = or(t), Lt.eventStreamService.sendEventWithTarget(lr.eventName.authButtonClick, t.parentalEntry, {
                            btn: lr.btn.continue,
                            associatedText: lr.text.ok,
                            state: ar(e, n)
                        }))
                    };
                    return S().createElement("div", null, i === Et.ParentConsentRequest && S().createElement(ir, {
                        translate: t,
                        consentType: c,
                        successCallBack: a,
                        onHideCallback: r,
                        value: o
                    }), i === Et.ParentLinkRequest && S().createElement(cr, {
                        translate: t,
                        consentType: c,
                        successCallback: a,
                        onHidecallback: r,
                        value: o
                    }), e)
                }, {
                    common: ["CommonUI.Controls", "CommonUI.Features", "Amp.Upsell"],
                    feature: "Feature.Parents"
                }),
                Cr = {
                    CanCorrectAge: "PrologueSetting.PromptLine.CanCorrectAge"
                },
                Ar = {};

            function Pr(e, t, n) {
                return n(Ar[e] || t)
            }

            function Ir(e, t, n, r) {
                e = Cr[e];
                return e ? r(e) + ", " + r(n) : r(t)
            }
            var kr = {
                state: {
                    U13To18: "U13To18",
                    U13To1318: "U13To1318",
                    U13ToU13: "U13ToU13"
                },
                text: {
                    IdvOrVpc: "Verify Your Age/Parent Permission Needed",
                    VerifyId: "Verify ID",
                    EmailMyParent: "Email My Parent",
                    Cancel: 'X icon or "Cancel"'
                },
                btn: {
                    VerifyId: "verifyId",
                    EmailParent: "emailParent",
                    verifyCancel: "verifyCancel"
                },
                context: {
                    SettingsAgeChangeVerify: "settingsAgeChangeVerify"
                },
                eventName: {
                    AuthPageload: "authPageload",
                    AuthButtonClick: "authButtonClick"
                }
            };

            function xr(e, t) {
                "CanCorrectAge" === e && Lt.eventStreamService.sendEventWithTarget(kr.eventName.AuthButtonClick, kr.context.SettingsAgeChangeVerify, {
                    btn: kr.btn.VerifyId,
                    state: t ? kr.state.U13To18 : kr.state.U13To1318,
                    associatedText: kr.text.VerifyId
                })
            }

            function Nr(e, t) {
                "CanCorrectAge" === e && Lt.eventStreamService.sendEventWithTarget(kr.eventName.AuthButtonClick, kr.context.SettingsAgeChangeVerify, {
                    btn: kr.btn.EmailParent,
                    state: t ? kr.state.U13ToU13 : kr.state.U13To1318,
                    associatedText: kr.text.EmailMyParent
                })
            }

            function Tr(e) {
                var t;
                switch (e) {
                    case "Idv":
                        t = kr.state.U13To18;
                        break;
                    case "Vpc":
                        t = kr.state.U13ToU13;
                        break;
                    case "IdvOrVpc":
                        t = kr.state.U13To1318
                }
                return t
            }

            function Mr(e, t) {
                "CanCorrectAge" === e && (t = Tr(t), Lt.eventStreamService.sendEventWithTarget(kr.eventName.AuthButtonClick, kr.context.SettingsAgeChangeVerify, {
                    btn: kr.btn.verifyCancel,
                    state: t,
                    associatedText: kr.text.Cancel
                }))
            }

            function Rr(e, t) {
                "CanCorrectAge" === e && (t = Tr(t), Lt.eventStreamService.sendEventWithTarget(kr.eventName.AuthPageload, kr.context.SettingsAgeChangeVerify, {
                    state: t,
                    associatedText: kr.text.IdvOrVpc
                }))
            }

            function Lr(e) {
                var t, n = e.translate,
                    r = e.onHide,
                    a = M(),
                    o = [null, null],
                    i = o[0],
                    c = o[1],
                    e = E(At).data.recourses;
                if (1 === (o = e.map(function(e) {
                        return e.action
                    })).length) switch (o[0]) {
                    case Et.ParentConsentRequest:
                    case Et.ParentLinkRequest:
                        t = Dr({
                            translate: n,
                            onHide: r
                        }), i = t[0], c = t[1];
                        break;
                    case Et.GovernmentId:
                        t = Ur({
                            translate: n,
                            onHide: r
                        }), i = t[0], c = t[1]
                }
                return 2 === o.length && o.includes(Et.GovernmentId) && (o.includes(Et.ParentConsentRequest) || o.includes(Et.ParentLinkRequest)) && (o = Or({
                    translate: n,
                    onHide: r
                }), i = o[0], c = o[1]), (0, w.useEffect)(function() {
                    i ? c.open() : a(Kt(ht.Verification))
                }, [a, i, c, e]), i
            }
            var Dr = function(e) {
                    var t = e.translate,
                        n = e.onHide,
                        r = M(),
                        a = E(St),
                        o = E(At).data.recourses,
                        i = Mn.Vpc,
                        c = Mn.VpcConnectingText,
                        u = Ir(a, i, c, t),
                        e = S().createElement("div", null, S().createElement("div", {
                            className: "text-description"
                        }, " ", u, " ")),
                        i = Tn.AskYourParent,
                        c = Pr(a, i, t),
                        u = Nn.AskNow,
                        i = Nn.Cancel,
                        u = Qn({
                            translate: t,
                            title: c,
                            body: e,
                            actionButtonTranslateKey: u,
                            neutralButtonTranslateKey: i,
                            onAction: function() {
                                Nr(a, !0), r(zt(o[0])), r(Kt(ht.Verification)), l.close()
                            },
                            size: "sm",
                            onHide: function() {
                                Mr(a, "Vpc"), n()
                            },
                            onNeutral: function() {
                                Mr(a, "Vpc"), n()
                            }
                        }),
                        i = u[0],
                        l = u[1];
                    return (0, w.useEffect)(function() {
                        l.open(), Rr(a, "Vpc")
                    }, []), [i, l]
                },
                Or = function(e) {
                    var t = e.translate,
                        n = e.onHide,
                        r = M(),
                        a = E(St),
                        o = E(At).data.recourses,
                        i = Mn.IdvAndVpc,
                        c = Mn.IdvAndVpcConnectingText,
                        u = Ir(a, i, c, t),
                        e = S().createElement("div", null, S().createElement("div", {
                            className: "text-description"
                        }, " ", u, " ")),
                        i = Tn.VerifyYourAge,
                        c = Pr(a, i, t),
                        u = Nn.VerifyID,
                        i = Nn.EmailMyParent,
                        u = Qn({
                            translate: t,
                            title: c,
                            body: e,
                            dualActionButton: !0,
                            actionButtonTranslateKey: u,
                            neutralButtonTranslateKey: i,
                            onAction: function() {
                                xr(a, !1);
                                var e = o.filter(function(e) {
                                    return e.action === Et.GovernmentId
                                })[0];
                                r(zt(e)), r(Kt(ht.Verification)), l.close()
                            },
                            size: "sm",
                            onHide: function() {
                                Mr(a, "IdvOrVpc"), n()
                            },
                            onNeutral: function() {
                                Nr(a, !1);
                                var e = o.filter(function(e) {
                                    return e.action !== Et.GovernmentId
                                })[0];
                                r(zt(e)), r(Kt(ht.Verification)), l.close()
                            }
                        }),
                        i = u[0],
                        l = u[1];
                    return (0, w.useEffect)(function() {
                        l.open(), Rr(a, "IdvOrVpc")
                    }, []), [i, l]
                },
                Ur = function(e) {
                    var t = e.translate,
                        n = e.onHide,
                        r = M(),
                        a = E(St),
                        o = E(At).data.recourses,
                        i = Mn.Idv,
                        c = Mn.IdvConnectingText,
                        u = Ir(a, i, c, t),
                        e = S().createElement("div", null, S().createElement("div", {
                            className: "text-description"
                        }, " ", u, " ")),
                        i = Tn.VerifyYourAge,
                        c = Pr(a, i, t),
                        u = Nn.VerifyID,
                        i = Nn.Cancel,
                        u = Qn({
                            translate: t,
                            title: c,
                            body: e,
                            actionButtonTranslateKey: u,
                            neutralButtonTranslateKey: i,
                            onAction: function() {
                                xr(a, !0), r(zt(o[0])), r(Kt(ht.Verification)), l.close()
                            },
                            size: "sm",
                            onHide: function() {
                                Mr(a, "Idv"), n()
                            },
                            onNeutral: function() {
                                Mr(a, "Idv"), n()
                            }
                        }),
                        i = u[0],
                        l = u[1];
                    return (0, w.useEffect)(function() {
                        l.open(), Rr(a, "Idv")
                    }, []), [i, l]
                };

            function Vr() {
                return S().createElement(R.Loading, null)
            }
            var Br = function(e, i, c, u) {
                    return new(c = c || Promise)(function(n, t) {
                        function r(e) {
                            try {
                                o(u.next(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function a(e) {
                            try {
                                o(u.throw(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function o(e) {
                            var t;
                            e.done ? n(e.value) : ((t = e.value) instanceof c ? t : new c(function(e) {
                                e(t)
                            })).then(r, a)
                        }
                        o((u = u.apply(e, i || [])).next())
                    })
                },
                Fr = function(n, r) {
                    var a, o, i, c = {
                            label: 0,
                            sent: function() {
                                if (1 & i[0]) throw i[1];
                                return i[1]
                            },
                            trys: [],
                            ops: []
                        },
                        e = {
                            next: t(0),
                            throw: t(1),
                            return: t(2)
                        };
                    return "function" == typeof Symbol && (e[Symbol.iterator] = function() {
                        return this
                    }), e;

                    function t(t) {
                        return function(e) {
                            return function(t) {
                                if (a) throw new TypeError("Generator is already executing.");
                                for (; c;) try {
                                    if (a = 1, o && (i = 2 & t[0] ? o.return : t[0] ? o.throw || ((i = o.return) && i.call(o), 0) : o.next) && !(i = i.call(o, t[1])).done) return i;
                                    switch (o = 0, i && (t = [2 & t[0], i.value]), t[0]) {
                                        case 0:
                                        case 1:
                                            i = t;
                                            break;
                                        case 4:
                                            return c.label++, {
                                                value: t[1],
                                                done: !1
                                            };
                                        case 5:
                                            c.label++, o = t[1], t = [0];
                                            continue;
                                        case 7:
                                            t = c.ops.pop(), c.trys.pop();
                                            continue;
                                        default:
                                            if (!(i = 0 < (i = c.trys).length && i[i.length - 1]) && (6 === t[0] || 2 === t[0])) {
                                                c = 0;
                                                continue
                                            }
                                            if (3 === t[0] && (!i || t[1] > i[0] && t[1] < i[3])) {
                                                c.label = t[1];
                                                break
                                            }
                                            if (6 === t[0] && c.label < i[1]) {
                                                c.label = i[1], i = t;
                                                break
                                            }
                                            if (i && c.label < i[2]) {
                                                c.label = i[2], c.ops.push(t);
                                                break
                                            }
                                            i[2] && c.ops.pop(), c.trys.pop();
                                            continue
                                    }
                                    t = r.call(n, c)
                                } catch (e) {
                                    t = [6, e], o = 0
                                } finally {
                                    a = i = 0
                                }
                                if (5 & t[0]) throw t[1];
                                return {
                                    value: t[0] ? t[1] : void 0,
                                    done: !0
                                }
                            }([t, e])
                        }
                    }
                };

            function jr(e) {
                var t, n = e.translate,
                    s = M(),
                    r = E(Pt),
                    a = E(At),
                    o = E(wt),
                    i = E(It),
                    c = (0, w.useState)(function(e) {
                        return e
                    }),
                    u = c[0],
                    f = c[1],
                    l = (e = (0, w.useState)({}))[0],
                    d = e[1],
                    e = (c = (0, w.useState)(!1))[0],
                    p = c[1];

                function m(l) {
                    return Br(this, void 0, void 0, function() {
                        var t, n, r, a, o, i, c, u;
                        return Fr(this, function(e) {
                            switch (e.label) {
                                case 0:
                                    t = l.detail, n = t.featureName, r = t.redirectLink, a = t.ampFeatureCheckData, o = t.isAsyncCall, i = t.usePrologue, c = t.ampRecourseData, u = t.closeCallback, f(function() {
                                        return function(e) {
                                            return u(e)
                                        }
                                    }), e.label = 1;
                                case 1:
                                    return e.trys.push([1, 3, , 4]), [4, s(Ft({
                                        featureName: n,
                                        ampFeatureCheckData: a
                                    }))];
                                case 2:
                                    return e.sent(), [3, 4];
                                case 3:
                                    return e.sent(), [3, 4];
                                case 4:
                                    return s(Ht(r)), p(o), a && s(qt(a)), c && d(c), s(Kt(i ? ht.Prologue : ht.Verification)), [2]
                            }
                        })
                    })
                }

                function h() {
                    s(_t()), u(a.data.access)
                }(0, w.useEffect)(function() {
                    var e = m;
                    return window.addEventListener(xn, e),
                        function() {
                            return window.removeEventListener(xn, e)
                        }
                }, []), (0, w.useEffect)(function() {
                    var e, t = [pt.Granted, pt.Denied];
                    null !== (e = null == a ? void 0 : a.data) && void 0 !== e && e.access && t.includes(a.data.access) && u(a.data.access)
                }, [a]);
                var v = e ? function() {
                    s(_t()), u(pt.Denied)
                } : h;

                function g() {
                    if (i) switch (i.action) {
                        case Et.AddedEmail:
                            return S().createElement(Vn, {
                                translate: n,
                                onHide: h
                            });
                        case Et.GovernmentId:
                            return S().createElement(qn, {
                                translate: n,
                                onHidecallback: v
                            });
                        case Et.ParentConsentRequest:
                        case Et.ParentLinkRequest:
                            return S().createElement(Sr, {
                                recourse: i,
                                translate: n,
                                onHidecallback: v,
                                value: l
                            });
                        default:
                            return S().createElement(Hn, {
                                translate: n
                            })
                    }
                    return S().createElement(Hn, {
                        translate: n
                    })
                }
                switch ((0, w.useEffect)(function() {
                    t = g()
                }, [i]), r) {
                    case ht.Prologue:
                        null != a.data && (t = S().createElement(Lr, {
                            translate: n,
                            onHide: v
                        }));
                        break;
                    case ht.Verification:
                        null != a.data && (t = g());
                        break;
                    case ht.Epilogue:
                        t = S().createElement(Hn, {
                            translate: n
                        });
                        break;
                    default:
                        t = S().createElement(Vr, null)
                }
                return S().createElement(S().Fragment, null, S().createElement(R.Modal, {
                    show: o,
                    onHide: h,
                    size: "sm",
                    "aria-labelledby": "access-management-modal-title",
                    className: "access-management-upsell-modal",
                    scrollable: "true",
                    centered: "true"
                }, t))
            }
            var _r = (0, a.withTranslations)(function(e) {
                    return e = e.translate, S().createElement(I, {
                        store: kn
                    }, S().createElement(jr, {
                        translate: e
                    }))
                }, {
                    common: ["CommonUI.Controls", "CommonUI.Features", "Amp.Upsell"],
                    feature: "Verification.Identity"
                }),
                qr = function(e, i, c, u) {
                    return new(c = c || Promise)(function(n, t) {
                        function r(e) {
                            try {
                                o(u.next(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function a(e) {
                            try {
                                o(u.throw(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function o(e) {
                            var t;
                            e.done ? n(e.value) : ((t = e.value) instanceof c ? t : new c(function(e) {
                                e(t)
                            })).then(r, a)
                        }
                        o((u = u.apply(e, i || [])).next())
                    })
                },
                Hr = function(n, r) {
                    var a, o, i, c = {
                            label: 0,
                            sent: function() {
                                if (1 & i[0]) throw i[1];
                                return i[1]
                            },
                            trys: [],
                            ops: []
                        },
                        e = {
                            next: t(0),
                            throw: t(1),
                            return: t(2)
                        };
                    return "function" == typeof Symbol && (e[Symbol.iterator] = function() {
                        return this
                    }), e;

                    function t(t) {
                        return function(e) {
                            return function(t) {
                                if (a) throw new TypeError("Generator is already executing.");
                                for (; c;) try {
                                    if (a = 1, o && (i = 2 & t[0] ? o.return : t[0] ? o.throw || ((i = o.return) && i.call(o), 0) : o.next) && !(i = i.call(o, t[1])).done) return i;
                                    switch (o = 0, i && (t = [2 & t[0], i.value]), t[0]) {
                                        case 0:
                                        case 1:
                                            i = t;
                                            break;
                                        case 4:
                                            return c.label++, {
                                                value: t[1],
                                                done: !1
                                            };
                                        case 5:
                                            c.label++, o = t[1], t = [0];
                                            continue;
                                        case 7:
                                            t = c.ops.pop(), c.trys.pop();
                                            continue;
                                        default:
                                            if (!(i = 0 < (i = c.trys).length && i[i.length - 1]) && (6 === t[0] || 2 === t[0])) {
                                                c = 0;
                                                continue
                                            }
                                            if (3 === t[0] && (!i || t[1] > i[0] && t[1] < i[3])) {
                                                c.label = t[1];
                                                break
                                            }
                                            if (6 === t[0] && c.label < i[1]) {
                                                c.label = i[1], i = t;
                                                break
                                            }
                                            if (i && c.label < i[2]) {
                                                c.label = i[2], c.ops.push(t);
                                                break
                                            }
                                            i[2] && c.ops.pop(), c.trys.pop();
                                            continue
                                    }
                                    t = r.call(n, c)
                                } catch (e) {
                                    t = [6, e], o = 0
                                } finally {
                                    a = i = 0
                                }
                                if (5 & t[0]) throw t[1];
                                return {
                                    value: t[0] ? t[1] : void 0,
                                    done: !0
                                }
                            }([t, e])
                        }
                    }
                },
                a = function(e) {
                    var n = e.featureName,
                        t = e.redirectLink,
                        r = void 0 === t ? null : t,
                        t = e.ampFeatureCheckData,
                        a = void 0 === t ? [] : t,
                        t = e.isAsyncCall,
                        o = void 0 === t || t,
                        t = e.usePrologue,
                        i = void 0 !== t && t,
                        e = e.ampRecourseData,
                        c = void 0 === e ? null : e;
                    return qr(void 0, void 0, Promise, function() {
                        return Hr(this, function(e) {
                            return [2, new Promise(function(t) {
                                var e = new CustomEvent(xn, {
                                    detail: {
                                        featureName: n,
                                        redirectLink: r,
                                        ampFeatureCheckData: a,
                                        isAsyncCall: o,
                                        usePrologue: i,
                                        ampRecourseData: c,
                                        closeCallback: function(e) {
                                            t(e === pt.Granted)
                                        }
                                    }
                                });
                                window.dispatchEvent(e)
                            })]
                        })
                    })
                };

            function zr() {
                var e = document.getElementById(r);
                e ? (0, n.render)(S().createElement(_r, null), e) : window.requestAnimationFrame(zr)
            }
            t().AccessManagementUpsellV2Service = {
                startAccessManagementUpsell: a
            }, (0, i.ready)(function() {
                r && zr()
            })
        }()
}();
//# sourceMappingURL=https://js.rbxcdn.com/9565351b2c26455aab064ad8b8c8c100-accessManagementUpsellV2.bundle.min.js.map

/* Bundle detector */
window.Roblox && window.Roblox.BundleDetector && window.Roblox.BundleDetector.bundleDetected("AccessManagementUpsellV2");