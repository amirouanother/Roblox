! function() {
    var n = {
            9644: function(e, t, n) {
                e.exports = n(5644)
            },
            353: function(e, t, u) {
                "use strict";
                var c = u(3044),
                    l = u(6955),
                    d = u(8030),
                    h = u(1875),
                    v = u(842),
                    p = u(8618);
                e.exports = function(s) {
                    return new Promise(function(t, n) {
                        var r = s.data,
                            a = s.headers;
                        c.isFormData(r) && delete a["Content-Type"];
                        var e, o, i = new XMLHttpRequest;
                        if (s.auth && (e = s.auth.username || "", o = s.auth.password || "", a.Authorization = "Basic " + btoa(e + ":" + o)), i.open(s.method.toUpperCase(), d(s.url, s.params, s.paramsSerializer), !0), i.timeout = s.timeout, i.onreadystatechange = function() {
                                var e;
                                i && 4 === i.readyState && (0 !== i.status || i.responseURL && 0 === i.responseURL.indexOf("file:")) && (e = "getAllResponseHeaders" in i ? h(i.getAllResponseHeaders()) : null, e = {
                                    data: s.responseType && "text" !== s.responseType ? i.response : i.responseText,
                                    status: i.status,
                                    statusText: i.statusText,
                                    headers: e,
                                    config: s,
                                    request: i
                                }, l(t, n, e), i = null)
                            }, i.onerror = function() {
                                n(p("Network Error", s, null, i)), i = null
                            }, i.ontimeout = function() {
                                n(p("timeout of " + s.timeout + "ms exceeded", s, "ECONNABORTED", i)), i = null
                            }, c.isStandardBrowserEnv() && (o = u(2233), (o = (s.withCredentials || v(s.url)) && s.xsrfCookieName ? o.read(s.xsrfCookieName) : void 0) && (a[s.xsrfHeaderName] = o)), "setRequestHeader" in i && c.forEach(a, function(e, t) {
                                void 0 === r && "content-type" === t.toLowerCase() ? delete a[t] : i.setRequestHeader(t, e)
                            }), s.withCredentials && (i.withCredentials = !0), s.responseType) try {
                            i.responseType = s.responseType
                        } catch (e) {
                            if ("json" !== s.responseType) throw e
                        }
                        "function" == typeof s.onDownloadProgress && i.addEventListener("progress", s.onDownloadProgress), "function" == typeof s.onUploadProgress && i.upload && i.upload.addEventListener("progress", s.onUploadProgress), s.cancelToken && s.cancelToken.promise.then(function(e) {
                            i && (i.abort(), n(e), i = null)
                        }), void 0 === r && (r = null), i.send(r)
                    })
                }
            },
            5644: function(e, t, n) {
                "use strict";
                var r = n(3044),
                    a = n(3644),
                    o = n(2215),
                    i = n(1439);

                function s(e) {
                    var t = new o(e),
                        e = a(o.prototype.request, t);
                    return r.extend(e, o.prototype, t), r.extend(e, t), e
                }
                var u = s(i);
                u.Axios = o, u.create = function(e) {
                    return s(r.merge(i, e))
                }, u.Cancel = n(6714), u.CancelToken = n(4089), u.isCancel = n(8041), u.all = function(e) {
                    return Promise.all(e)
                }, u.spread = n(783), e.exports = u, e.exports.default = u
            },
            6714: function(e) {
                "use strict";

                function t(e) {
                    this.message = e
                }
                t.prototype.toString = function() {
                    return "Cancel" + (this.message ? ": " + this.message : "")
                }, t.prototype.__CANCEL__ = !0, e.exports = t
            },
            4089: function(e, t, n) {
                "use strict";
                var r = n(6714);

                function a(e) {
                    if ("function" != typeof e) throw new TypeError("executor must be a function.");
                    var t;
                    this.promise = new Promise(function(e) {
                        t = e
                    });
                    var n = this;
                    e(function(e) {
                        n.reason || (n.reason = new r(e), t(n.reason))
                    })
                }
                a.prototype.throwIfRequested = function() {
                    if (this.reason) throw this.reason
                }, a.source = function() {
                    var t;
                    return {
                        token: new a(function(e) {
                            t = e
                        }),
                        cancel: t
                    }
                }, e.exports = a
            },
            8041: function(e) {
                "use strict";
                e.exports = function(e) {
                    return !(!e || !e.__CANCEL__)
                }
            },
            2215: function(e, t, n) {
                "use strict";
                var a = n(1439),
                    o = n(3044),
                    r = n(946),
                    i = n(6895);

                function s(e) {
                    this.defaults = e, this.interceptors = {
                        request: new r,
                        response: new r
                    }
                }
                s.prototype.request = function(e, t) {
                    "string" == typeof e && (e = o.merge({
                        url: arguments[0]
                    }, t)), (e = o.merge(a, {
                        method: "get"
                    }, this.defaults, e)).method = e.method.toLowerCase();
                    var n = [i, void 0],
                        r = Promise.resolve(e);
                    for (this.interceptors.request.forEach(function(e) {
                            n.unshift(e.fulfilled, e.rejected)
                        }), this.interceptors.response.forEach(function(e) {
                            n.push(e.fulfilled, e.rejected)
                        }); n.length;) r = r.then(n.shift(), n.shift());
                    return r
                }, o.forEach(["delete", "get", "head", "options"], function(n) {
                    s.prototype[n] = function(e, t) {
                        return this.request(o.merge(t || {}, {
                            method: n,
                            url: e
                        }))
                    }
                }), o.forEach(["post", "put", "patch"], function(r) {
                    s.prototype[r] = function(e, t, n) {
                        return this.request(o.merge(n || {}, {
                            method: r,
                            url: e,
                            data: t
                        }))
                    }
                }), e.exports = s
            },
            946: function(e, t, n) {
                "use strict";
                var r = n(3044);

                function a() {
                    this.handlers = []
                }
                a.prototype.use = function(e, t) {
                    return this.handlers.push({
                        fulfilled: e,
                        rejected: t
                    }), this.handlers.length - 1
                }, a.prototype.eject = function(e) {
                    this.handlers[e] && (this.handlers[e] = null)
                }, a.prototype.forEach = function(t) {
                    r.forEach(this.handlers, function(e) {
                        null !== e && t(e)
                    })
                }, e.exports = a
            },
            8618: function(e, t, n) {
                "use strict";
                var o = n(1935);
                e.exports = function(e, t, n, r, a) {
                    e = new Error(e);
                    return o(e, t, n, r, a)
                }
            },
            6895: function(e, t, n) {
                "use strict";
                var r = n(3044),
                    a = n(8556),
                    o = n(8041),
                    i = n(1439),
                    s = n(9192),
                    u = n(8762);

                function c(e) {
                    e.cancelToken && e.cancelToken.throwIfRequested()
                }
                e.exports = function(t) {
                    return c(t), t.baseURL && !s(t.url) && (t.url = u(t.baseURL, t.url)), t.headers = t.headers || {}, t.data = a(t.data, t.headers, t.transformRequest), t.headers = r.merge(t.headers.common || {}, t.headers[t.method] || {}, t.headers || {}), r.forEach(["delete", "get", "head", "post", "put", "patch", "common"], function(e) {
                        delete t.headers[e]
                    }), (t.adapter || i.adapter)(t).then(function(e) {
                        return c(t), e.data = a(e.data, e.headers, t.transformResponse), e
                    }, function(e) {
                        return o(e) || (c(t), e && e.response && (e.response.data = a(e.response.data, e.response.headers, t.transformResponse))), Promise.reject(e)
                    })
                }
            },
            1935: function(e) {
                "use strict";
                e.exports = function(e, t, n, r, a) {
                    return e.config = t, n && (e.code = n), e.request = r, e.response = a, e
                }
            },
            6955: function(e, t, n) {
                "use strict";
                var a = n(8618);
                e.exports = function(e, t, n) {
                    var r = n.config.validateStatus;
                    n.status && r && !r(n.status) ? t(a("Request failed with status code " + n.status, n.config, null, n.request, n)) : e(n)
                }
            },
            8556: function(e, t, n) {
                "use strict";
                var r = n(3044);
                e.exports = function(t, n, e) {
                    return r.forEach(e, function(e) {
                        t = e(t, n)
                    }), t
                }
            },
            1439: function(e, t, n) {
                "use strict";
                var r = n(3044),
                    a = n(8868),
                    o = {
                        "Content-Type": "application/x-www-form-urlencoded"
                    };

                function i(e, t) {
                    !r.isUndefined(e) && r.isUndefined(e["Content-Type"]) && (e["Content-Type"] = t)
                }
                var s, u = {
                    adapter: ("undefined" == typeof XMLHttpRequest && "undefined" == typeof process || (s = n(353)), s),
                    transformRequest: [function(e, t) {
                        return a(t, "Content-Type"), r.isFormData(e) || r.isArrayBuffer(e) || r.isBuffer(e) || r.isStream(e) || r.isFile(e) || r.isBlob(e) ? e : r.isArrayBufferView(e) ? e.buffer : r.isURLSearchParams(e) ? (i(t, "application/x-www-form-urlencoded;charset=utf-8"), e.toString()) : r.isObject(e) ? (i(t, "application/json;charset=utf-8"), JSON.stringify(e)) : e
                    }],
                    transformResponse: [function(e) {
                        if ("string" == typeof e) try {
                            e = JSON.parse(e)
                        } catch (e) {}
                        return e
                    }],
                    timeout: 0,
                    xsrfCookieName: "XSRF-TOKEN",
                    xsrfHeaderName: "X-XSRF-TOKEN",
                    maxContentLength: -1,
                    validateStatus: function(e) {
                        return 200 <= e && e < 300
                    },
                    headers: {
                        common: {
                            Accept: "application/json, text/plain, */*"
                        }
                    }
                };
                r.forEach(["delete", "get", "head"], function(e) {
                    u.headers[e] = {}
                }), r.forEach(["post", "put", "patch"], function(e) {
                    u.headers[e] = r.merge(o)
                }), e.exports = u
            },
            3644: function(e) {
                "use strict";
                e.exports = function(n, r) {
                    return function() {
                        for (var e = new Array(arguments.length), t = 0; t < e.length; t++) e[t] = arguments[t];
                        return n.apply(r, e)
                    }
                }
            },
            8030: function(e, t, n) {
                "use strict";
                var a = n(3044);

                function o(e) {
                    return encodeURIComponent(e).replace(/%40/gi, "@").replace(/%3A/gi, ":").replace(/%24/g, "$").replace(/%2C/gi, ",").replace(/%20/g, "+").replace(/%5B/gi, "[").replace(/%5D/gi, "]")
                }
                e.exports = function(e, t, n) {
                    if (!t) return e;
                    var r, t = n ? n(t) : a.isURLSearchParams(t) ? t.toString() : (r = [], a.forEach(t, function(e, t) {
                        null != e && (a.isArray(e) ? t += "[]" : e = [e], a.forEach(e, function(e) {
                            a.isDate(e) ? e = e.toISOString() : a.isObject(e) && (e = JSON.stringify(e)), r.push(o(t) + "=" + o(e))
                        }))
                    }), r.join("&"));
                    return t && (e += (-1 === e.indexOf("?") ? "?" : "&") + t), e
                }
            },
            8762: function(e) {
                "use strict";
                e.exports = function(e, t) {
                    return t ? e.replace(/\/+$/, "") + "/" + t.replace(/^\/+/, "") : e
                }
            },
            2233: function(e, t, n) {
                "use strict";
                var s = n(3044);
                e.exports = s.isStandardBrowserEnv() ? {
                    write: function(e, t, n, r, a, o) {
                        var i = [];
                        i.push(e + "=" + encodeURIComponent(t)), s.isNumber(n) && i.push("expires=" + new Date(n).toGMTString()), s.isString(r) && i.push("path=" + r), s.isString(a) && i.push("domain=" + a), !0 === o && i.push("secure"), document.cookie = i.join("; ")
                    },
                    read: function(e) {
                        e = document.cookie.match(new RegExp("(^|;\\s*)(" + e + ")=([^;]*)"));
                        return e ? decodeURIComponent(e[3]) : null
                    },
                    remove: function(e) {
                        this.write(e, "", Date.now() - 864e5)
                    }
                } : {
                    write: function() {},
                    read: function() {
                        return null
                    },
                    remove: function() {}
                }
            },
            9192: function(e) {
                "use strict";
                e.exports = function(e) {
                    return /^([a-z][a-z\d\+\-\.]*:)?\/\//i.test(e)
                }
            },
            842: function(e, t, n) {
                "use strict";
                var r, a, o, i = n(3044);

                function s(e) {
                    return a && (o.setAttribute("href", e), e = o.href), o.setAttribute("href", e), {
                        href: o.href,
                        protocol: o.protocol ? o.protocol.replace(/:$/, "") : "",
                        host: o.host,
                        search: o.search ? o.search.replace(/^\?/, "") : "",
                        hash: o.hash ? o.hash.replace(/^#/, "") : "",
                        hostname: o.hostname,
                        port: o.port,
                        pathname: "/" === o.pathname.charAt(0) ? o.pathname : "/" + o.pathname
                    }
                }
                e.exports = i.isStandardBrowserEnv() ? (a = /(msie|trident)/i.test(navigator.userAgent), o = document.createElement("a"), r = s(window.location.href), function(e) {
                    e = i.isString(e) ? s(e) : e;
                    return e.protocol === r.protocol && e.host === r.host
                }) : function() {
                    return !0
                }
            },
            8868: function(e, t, n) {
                "use strict";
                var a = n(3044);
                e.exports = function(n, r) {
                    a.forEach(n, function(e, t) {
                        t !== r && t.toUpperCase() === r.toUpperCase() && (n[r] = e, delete n[t])
                    })
                }
            },
            1875: function(e, t, n) {
                "use strict";
                var a = n(3044),
                    o = ["age", "authorization", "content-length", "content-type", "etag", "expires", "from", "host", "if-modified-since", "if-unmodified-since", "last-modified", "location", "max-forwards", "proxy-authorization", "referer", "retry-after", "user-agent"];
                e.exports = function(e) {
                    var t, n, r = {};
                    return e && a.forEach(e.split("\n"), function(e) {
                        n = e.indexOf(":"), t = a.trim(e.substr(0, n)).toLowerCase(), n = a.trim(e.substr(n + 1)), t && (r[t] && 0 <= o.indexOf(t) || (r[t] = "set-cookie" === t ? (r[t] || []).concat([n]) : r[t] ? r[t] + ", " + n : n))
                    }), r
                }
            },
            783: function(e) {
                "use strict";
                e.exports = function(t) {
                    return function(e) {
                        return t.apply(null, e)
                    }
                }
            },
            3044: function(e, t, n) {
                "use strict";
                var a = n(3644),
                    n = n(3335),
                    r = Object.prototype.toString;

                function o(e) {
                    return "[object Array]" === r.call(e)
                }

                function i(e) {
                    return null !== e && "object" == typeof e
                }

                function s(e) {
                    return "[object Function]" === r.call(e)
                }

                function u(e, t) {
                    if (null != e)
                        if ("object" != typeof e && (e = [e]), o(e))
                            for (var n = 0, r = e.length; n < r; n++) t.call(null, e[n], n, e);
                        else
                            for (var a in e) Object.prototype.hasOwnProperty.call(e, a) && t.call(null, e[a], a, e)
                }
                e.exports = {
                    isArray: o,
                    isArrayBuffer: function(e) {
                        return "[object ArrayBuffer]" === r.call(e)
                    },
                    isBuffer: n,
                    isFormData: function(e) {
                        return "undefined" != typeof FormData && e instanceof FormData
                    },
                    isArrayBufferView: function(e) {
                        return e = "undefined" != typeof ArrayBuffer && ArrayBuffer.isView ? ArrayBuffer.isView(e) : e && e.buffer && e.buffer instanceof ArrayBuffer
                    },
                    isString: function(e) {
                        return "string" == typeof e
                    },
                    isNumber: function(e) {
                        return "number" == typeof e
                    },
                    isObject: i,
                    isUndefined: function(e) {
                        return void 0 === e
                    },
                    isDate: function(e) {
                        return "[object Date]" === r.call(e)
                    },
                    isFile: function(e) {
                        return "[object File]" === r.call(e)
                    },
                    isBlob: function(e) {
                        return "[object Blob]" === r.call(e)
                    },
                    isFunction: s,
                    isStream: function(e) {
                        return i(e) && s(e.pipe)
                    },
                    isURLSearchParams: function(e) {
                        return "undefined" != typeof URLSearchParams && e instanceof URLSearchParams
                    },
                    isStandardBrowserEnv: function() {
                        return ("undefined" == typeof navigator || "ReactNative" !== navigator.product) && ("undefined" != typeof window && "undefined" != typeof document)
                    },
                    forEach: u,
                    merge: function n() {
                        var r = {};

                        function e(e, t) {
                            "object" == typeof r[t] && "object" == typeof e ? r[t] = n(r[t], e) : r[t] = e
                        }
                        for (var t = 0, a = arguments.length; t < a; t++) u(arguments[t], e);
                        return r
                    },
                    extend: function(n, e, r) {
                        return u(e, function(e, t) {
                            n[t] = r && "function" == typeof e ? a(e, r) : e
                        }), n
                    },
                    trim: function(e) {
                        return e.replace(/^\s*/, "").replace(/\s*$/, "")
                    }
                }
            },
            1745: function(e) {
                "use strict";

                function n(e) {
                    return (n = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                        return typeof e
                    } : function(e) {
                        return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                    })(e)
                }
                var t = "%[a-f0-9]{2}",
                    a = new RegExp(t, "gi"),
                    s = new RegExp("(" + t + ")+", "gi");

                function u(t) {
                    try {
                        return decodeURIComponent(t)
                    } catch (e) {
                        for (var n = t.match(a), r = 1; r < n.length; r++) n = (t = function e(t, n) {
                            try {
                                return decodeURIComponent(t.join(""))
                            } catch (e) {}
                            if (1 === t.length) return t;
                            n = n || 1;
                            var r = t.slice(0, n),
                                n = t.slice(n);
                            return Array.prototype.concat.call([], e(r), e(n))
                        }(n, r).join("")).match(a);
                        return t
                    }
                }
                e.exports = function(t) {
                    if ("string" != typeof t) throw new TypeError("Expected `encodedURI` to be of type `string`, got `" + n(t) + "`");
                    try {
                        return t = t.replace(/\+/g, " "), decodeURIComponent(t)
                    } catch (e) {
                        return function(e) {
                            for (var t = {
                                    "%FE%FF": "��",
                                    "%FF%FE": "��"
                                }, n = s.exec(e); n;) {
                                try {
                                    t[n[0]] = decodeURIComponent(n[0])
                                } catch (e) {
                                    var r = u(n[0]);
                                    r !== n[0] && (t[n[0]] = r)
                                }
                                n = s.exec(e)
                            }
                            t["%C2"] = "�";
                            for (var a = Object.keys(t), o = 0; o < a.length; o++) {
                                var i = a[o];
                                e = e.replace(new RegExp(i, "g"), t[i])
                            }
                            return e
                        }(t)
                    }
                }
            },
            6933: function(e, s, t) {
                "use strict";

                function p(e, t) {
                    return function(e) {
                        if (Array.isArray(e)) return e
                    }(e) || function(e, t) {
                        if ("undefined" == typeof Symbol || !(Symbol.iterator in Object(e))) return;
                        var n = [],
                            r = !0,
                            a = !1,
                            o = void 0;
                        try {
                            for (var i, s = e[Symbol.iterator](); !(r = (i = s.next()).done) && (n.push(i.value), !t || n.length !== t); r = !0);
                        } catch (e) {
                            a = !0, o = e
                        } finally {
                            try {
                                r || null == s.return || s.return()
                            } finally {
                                if (a) throw o
                            }
                        }
                        return n
                    }(e, t) || m(e, t) || function() {
                        throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                    }()
                }

                function f(e) {
                    return (f = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                        return typeof e
                    } : function(e) {
                        return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                    })(e)
                }

                function c(e) {
                    return function(e) {
                        if (Array.isArray(e)) return r(e)
                    }(e) || function(e) {
                        if ("undefined" != typeof Symbol && Symbol.iterator in Object(e)) return Array.from(e)
                    }(e) || m(e) || function() {
                        throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                    }()
                }

                function m(e, t) {
                    if (e) {
                        if ("string" == typeof e) return r(e, t);
                        var n = Object.prototype.toString.call(e).slice(8, -1);
                        return "Object" === n && e.constructor && (n = e.constructor.name), "Map" === n || "Set" === n ? Array.from(e) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? r(e, t) : void 0
                    }
                }

                function r(e, t) {
                    (null == t || t > e.length) && (t = e.length);
                    for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
                    return r
                }
                var n = t(3162),
                    a = t(1745),
                    g = t(9393);

                function I(e) {
                    if ("string" != typeof e || 1 !== e.length) throw new TypeError("arrayFormatSeparator must be single character string")
                }

                function l(e, t) {
                    return t.encode ? (t.strict ? n : encodeURIComponent)(e) : e
                }

                function y(e, t) {
                    return t.decode ? a(e) : e
                }

                function u(e) {
                    var t = e.indexOf("#");
                    return -1 !== t && (e = e.slice(0, t)), e
                }

                function o(e) {
                    var t = (e = u(e)).indexOf("?");
                    return -1 === t ? "" : e.slice(t + 1)
                }

                function b(e, t) {
                    return t.parseNumbers && !Number.isNaN(Number(e)) && "string" == typeof e && "" !== e.trim() ? e = Number(e) : !t.parseBooleans || null === e || "true" !== e.toLowerCase() && "false" !== e.toLowerCase() || (e = "true" === e.toLowerCase()), e
                }

                function i(e, t) {
                    I((t = Object.assign({
                        decode: !0,
                        sort: !0,
                        arrayFormat: "none",
                        arrayFormatSeparator: ",",
                        parseNumbers: !1,
                        parseBooleans: !1
                    }, t)).arrayFormatSeparator);
                    var n = function(o) {
                            var r;
                            switch (o.arrayFormat) {
                                case "index":
                                    return function(e, t, n) {
                                        r = /\[(\d*)\]$/.exec(e), e = e.replace(/\[\d*\]$/, ""), r ? (void 0 === n[e] && (n[e] = {}), n[e][r[1]] = t) : n[e] = t
                                    };
                                case "bracket":
                                    return function(e, t, n) {
                                        r = /(\[\])$/.exec(e), e = e.replace(/\[\]$/, ""), r ? void 0 !== n[e] ? n[e] = [].concat(n[e], t) : n[e] = [t] : n[e] = t
                                    };
                                case "comma":
                                case "separator":
                                    return function(e, t, n) {
                                        var r = "string" == typeof t && t.includes(o.arrayFormatSeparator),
                                            a = "string" == typeof t && !r && y(t, o).includes(o.arrayFormatSeparator);
                                        t = a ? y(t, o) : t;
                                        t = r || a ? t.split(o.arrayFormatSeparator).map(function(e) {
                                            return y(e, o)
                                        }) : null === t ? t : y(t, o);
                                        n[e] = t
                                    };
                                default:
                                    return function(e, t, n) {
                                        void 0 !== n[e] ? n[e] = [].concat(n[e], t) : n[e] = t
                                    }
                            }
                        }(t),
                        r = Object.create(null);
                    if ("string" != typeof e) return r;
                    if (!(e = e.trim().replace(/^[?#&]/, ""))) return r;
                    var a = function(e, t) {
                        var n;
                        if ("undefined" == typeof Symbol || null == e[Symbol.iterator]) {
                            if (Array.isArray(e) || (n = m(e)) || t && e && "number" == typeof e.length) {
                                n && (e = n);
                                var r = 0,
                                    t = function() {};
                                return {
                                    s: t,
                                    n: function() {
                                        return r >= e.length ? {
                                            done: !0
                                        } : {
                                            done: !1,
                                            value: e[r++]
                                        }
                                    },
                                    e: function(e) {
                                        throw e
                                    },
                                    f: t
                                }
                            }
                            throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                        }
                        var a, o = !0,
                            i = !1;
                        return {
                            s: function() {
                                n = e[Symbol.iterator]()
                            },
                            n: function() {
                                var e = n.next();
                                return o = e.done, e
                            },
                            e: function(e) {
                                i = !0, a = e
                            },
                            f: function() {
                                try {
                                    o || null == n.return || n.return()
                                } finally {
                                    if (i) throw a
                                }
                            }
                        }
                    }(e.split("&"));
                    try {
                        for (a.s(); !(i = a.n()).done;) {
                            var o = i.value,
                                i = p(g(t.decode ? o.replace(/\+/g, " ") : o, "="), 2),
                                o = i[0],
                                i = void 0 === (i = i[1]) ? null : ["comma", "separator"].includes(t.arrayFormat) ? i : y(i, t);
                            n(y(o, t), i, r)
                        }
                    } catch (e) {
                        a.e(e)
                    } finally {
                        a.f()
                    }
                    for (var s = 0, u = Object.keys(r); s < u.length; s++) {
                        var c = u[s],
                            l = r[c];
                        if ("object" === f(l) && null !== l)
                            for (var d = 0, h = Object.keys(l); d < h.length; d++) {
                                var v = h[d];
                                l[v] = b(l[v], t)
                            } else r[c] = b(l, t)
                    }
                    return !1 === t.sort ? r : (!0 === t.sort ? Object.keys(r).sort() : Object.keys(r).sort(t.sort)).reduce(function(e, t) {
                        var n = r[t];
                        return Boolean(n) && "object" === f(n) && !Array.isArray(n) ? e[t] = function e(t) {
                            return Array.isArray(t) ? t.sort() : "object" === f(t) ? e(Object.keys(t)).sort(function(e, t) {
                                return Number(e) - Number(t)
                            }).map(function(e) {
                                return t[e]
                            }) : t
                        }(n) : e[t] = n, e
                    }, Object.create(null))
                }
                s.extract = o, s.parse = i, s.stringify = function(n, r) {
                    if (!n) return "";
                    I((r = Object.assign({
                        encode: !0,
                        strict: !0,
                        arrayFormat: "none",
                        arrayFormatSeparator: ","
                    }, r)).arrayFormatSeparator);
                    for (var e, a = function(a) {
                            switch (a.arrayFormat) {
                                case "index":
                                    return function(r) {
                                        return function(e, t) {
                                            var n = e.length;
                                            return void 0 === t || a.skipNull && null === t || a.skipEmptyString && "" === t ? e : [].concat(c(e), null === t ? [
                                                [l(r, a), "[", n, "]"].join("")
                                            ] : [
                                                [l(r, a), "[", l(n, a), "]=", l(t, a)].join("")
                                            ])
                                        }
                                    };
                                case "bracket":
                                    return function(n) {
                                        return function(e, t) {
                                            return void 0 === t || a.skipNull && null === t || a.skipEmptyString && "" === t ? e : [].concat(c(e), null === t ? [
                                                [l(n, a), "[]"].join("")
                                            ] : [
                                                [l(n, a), "[]=", l(t, a)].join("")
                                            ])
                                        }
                                    };
                                case "comma":
                                case "separator":
                                    return function(n) {
                                        return function(e, t) {
                                            return null == t || 0 === t.length ? e : 0 === e.length ? [
                                                [l(n, a), "=", l(t, a)].join("")
                                            ] : [
                                                [e, l(t, a)].join(a.arrayFormatSeparator)
                                            ]
                                        }
                                    };
                                default:
                                    return function(n) {
                                        return function(e, t) {
                                            return void 0 === t || a.skipNull && null === t || a.skipEmptyString && "" === t ? e : [].concat(c(e), null === t ? [l(n, a)] : [
                                                [l(n, a), "=", l(t, a)].join("")
                                            ])
                                        }
                                    }
                            }
                        }(r), t = {}, o = 0, i = Object.keys(n); o < i.length; o++) {
                        var s = i[o];
                        e = s, r.skipNull && null == n[e] || r.skipEmptyString && "" === n[e] || (t[s] = n[s])
                    }
                    var u = Object.keys(t);
                    return !1 !== r.sort && u.sort(r.sort), u.map(function(e) {
                        var t = n[e];
                        return void 0 === t ? "" : null === t ? l(e, r) : Array.isArray(t) ? t.reduce(a(e), []).join("&") : l(e, r) + "=" + l(t, r)
                    }).filter(function(e) {
                        return 0 < e.length
                    }).join("&")
                }, s.parseUrl = function(e, t) {
                    t = Object.assign({
                        decode: !0
                    }, t);
                    var n = p(g(e, "#"), 2),
                        r = n[0],
                        n = n[1];
                    return Object.assign({
                        url: r.split("?")[0] || "",
                        query: i(o(e), t)
                    }, t && t.parseFragmentIdentifier && n ? {
                        fragmentIdentifier: y(n, t)
                    } : {})
                }, s.stringifyUrl = function(e, t) {
                    t = Object.assign({
                        encode: !0,
                        strict: !0
                    }, t);
                    var n = u(e.url).split("?")[0] || "",
                        r = s.extract(e.url),
                        a = s.parse(r, {
                            sort: !1
                        }),
                        o = Object.assign(a, e.query),
                        i = (i = s.stringify(o, t)) && "?".concat(i),
                        a = (r = e.url, a = "", -1 !== (o = r.indexOf("#")) && (a = r.slice(o)), a);
                    return e.fragmentIdentifier && (a = "#".concat(l(e.fragmentIdentifier, t))), "".concat(n).concat(i).concat(a)
                }
            },
            9393: function(e) {
                "use strict";
                e.exports = function(e, t) {
                    if ("string" != typeof e || "string" != typeof t) throw new TypeError("Expected the arguments to be of type `string`");
                    if ("" === t) return [e];
                    var n = e.indexOf(t);
                    return -1 === n ? [e] : [e.slice(0, n), e.slice(n + t.length)]
                }
            },
            3162: function(e) {
                "use strict";
                e.exports = function(e) {
                    return encodeURIComponent(e).replace(/[!'()*]/g, function(e) {
                        return "%".concat(e.charCodeAt(0).toString(16).toUpperCase())
                    })
                }
            },
            3335: function(e) {
                /*!
                 * Determine if an object is a Buffer
                 *
                 * @author   Feross Aboukhadijeh <https://feross.org>
                 * @license  MIT
                 */
                e.exports = function(e) {
                    return null != e && null != e.constructor && "function" == typeof e.constructor.isBuffer && e.constructor.isBuffer(e)
                }
            },
            1718: function(v, f, m) {
                var L; /*! https://mths.be/punycode v1.3.2 by @mathias */
                v = m.nmd(v),
                    function() {
                        f && f.nodeType, v && v.nodeType;
                        var e = "object" == typeof m.g && m.g;
                        e.global !== e && e.window !== e && e.self;
                        var t, g = 2147483647,
                            I = 36,
                            y = 1,
                            b = 26,
                            a = 38,
                            o = 700,
                            P = 72,
                            G = 128,
                            w = "-",
                            n = /^xn--/,
                            r = /[^\x20-\x7E]/,
                            i = /[\x2E\u3002\uFF0E\uFF61]/g,
                            s = {
                                overflow: "Overflow: input needs wider integers to process",
                                "not-basic": "Illegal input >= 0x80 (not a basic code point)",
                                "invalid-input": "Invalid input"
                            },
                            u = I - y,
                            C = Math.floor,
                            T = String.fromCharCode;

                        function A(e) {
                            throw RangeError(s[e])
                        }

                        function c(e, t) {
                            for (var n = e.length, r = []; n--;) r[n] = t(e[n]);
                            return r
                        }

                        function l(e, t) {
                            var n = e.split("@"),
                                r = "";
                            return 1 < n.length && (r = n[0] + "@", e = n[1]), r + c((e = e.replace(i, ".")).split("."), t).join(".")
                        }

                        function S(e) {
                            for (var t, n, r = [], a = 0, o = e.length; a < o;) 55296 <= (t = e.charCodeAt(a++)) && t <= 56319 && a < o ? 56320 == (64512 & (n = e.charCodeAt(a++))) ? r.push(((1023 & t) << 10) + (1023 & n) + 65536) : (r.push(t), a--) : r.push(t);
                            return r
                        }

                        function p(e) {
                            return c(e, function(e) {
                                var t = "";
                                return 65535 < e && (t += T((e -= 65536) >>> 10 & 1023 | 55296), e = 56320 | 1023 & e), t += T(e)
                            }).join("")
                        }

                        function R(e, t) {
                            return e + 22 + 75 * (e < 26) - ((0 != t) << 5)
                        }

                        function E(e, t, n) {
                            var r = 0;
                            for (e = n ? C(e / o) : e >> 1, e += C(e / t); u * b >> 1 < e; r += I) e = C(e / u);
                            return C(r + (u + 1) * e / (e + a))
                        }

                        function d(e) {
                            var t, n, r, a, o, i, s, u = [],
                                c = e.length,
                                l = 0,
                                d = G,
                                h = P,
                                v = e.lastIndexOf(w);
                            for (v < 0 && (v = 0), n = 0; n < v; ++n) 128 <= e.charCodeAt(n) && A("not-basic"), u.push(e.charCodeAt(n));
                            for (r = 0 < v ? v + 1 : 0; r < c;) {
                                for (a = l, o = 1, i = I; c <= r && A("invalid-input"), s = e.charCodeAt(r++), (I <= (s = s - 48 < 10 ? s - 22 : s - 65 < 26 ? s - 65 : s - 97 < 26 ? s - 97 : I) || s > C((g - l) / o)) && A("overflow"), l += s * o, !(s < (s = i <= h ? y : h + b <= i ? b : i - h)); i += I) o > C(g / (s = I - s)) && A("overflow"), o *= s;
                                h = E(l - a, t = u.length + 1, 0 == a), C(l / t) > g - d && A("overflow"), d += C(l / t), l %= t, u.splice(l++, 0, d)
                            }
                            return p(u)
                        }

                        function h(e) {
                            for (var t, n, r, a, o, i, s, u, c, l, d, h = [], v = (e = S(e)).length, p = G, f = P, m = t = 0; m < v; ++m)(u = e[m]) < 128 && h.push(T(u));
                            for (n = r = h.length, r && h.push(w); n < v;) {
                                for (a = g, m = 0; m < v; ++m) p <= (u = e[m]) && u < a && (a = u);
                                for (a - p > C((g - t) / (c = n + 1)) && A("overflow"), t += (a - p) * c, p = a, m = 0; m < v; ++m)
                                    if ((u = e[m]) < p && ++t > g && A("overflow"), u == p) {
                                        for (o = t, i = I; !(o < (s = i <= f ? y : f + b <= i ? b : i - f)); i += I) d = o - s, l = I - s, h.push(T(R(s + d % l, 0))), o = C(d / l);
                                        h.push(T(R(o, 0))), f = E(t, c, n == r), t = 0, ++n
                                    }++t, ++p
                            }
                            return h.join("")
                        }
                        t = {
                            version: "1.3.2",
                            ucs2: {
                                decode: S,
                                encode: p
                            },
                            decode: d,
                            encode: h,
                            toASCII: function(e) {
                                return l(e, function(e) {
                                    return r.test(e) ? "xn--" + h(e) : e
                                })
                            },
                            toUnicode: function(e) {
                                return l(e, function(e) {
                                    return n.test(e) ? d(e.slice(4).toLowerCase()) : e
                                })
                            }
                        }, void 0 === (L = function() {
                            return t
                        }.call(f, m, f, v)) || (v.exports = L)
                    }()
            },
            2808: function(e) {
                "use strict";
                e.exports = function(e, t, n, r) {
                    t = t || "&", n = n || "=";
                    var a = {};
                    if ("string" != typeof e || 0 === e.length) return a;
                    var o = /\+/g;
                    e = e.split(t);
                    t = 1e3;
                    r && "number" == typeof r.maxKeys && (t = r.maxKeys);
                    var i = e.length;
                    0 < t && t < i && (i = t);
                    for (var s = 0; s < i; ++s) {
                        var u, c = e[s].replace(o, "%20"),
                            l = c.indexOf(n),
                            d = 0 <= l ? (u = c.substr(0, l), c.substr(l + 1)) : (u = c, ""),
                            h = decodeURIComponent(u),
                            l = decodeURIComponent(d);
                        c = a, d = h, Object.prototype.hasOwnProperty.call(c, d) ? Array.isArray(a[h]) ? a[h].push(l) : a[h] = [a[h], l] : a[h] = l
                    }
                    return a
                }
            },
            1368: function(e) {
                "use strict";

                function o(e) {
                    switch (typeof e) {
                        case "string":
                            return e;
                        case "boolean":
                            return e ? "true" : "false";
                        case "number":
                            return isFinite(e) ? e : "";
                        default:
                            return ""
                    }
                }
                e.exports = function(n, r, a, e) {
                    return r = r || "&", a = a || "=", null === n && (n = void 0), "object" == typeof n ? Object.keys(n).map(function(e) {
                        var t = encodeURIComponent(o(e)) + a;
                        return Array.isArray(n[e]) ? n[e].map(function(e) {
                            return t + encodeURIComponent(o(e))
                        }).join(r) : t + encodeURIComponent(o(n[e]))
                    }).join(r) : e ? encodeURIComponent(o(e)) + a + encodeURIComponent(o(n)) : ""
                }
            },
            6642: function(e, t, n) {
                "use strict";
                t.decode = t.parse = n(2808), t.encode = t.stringify = n(1368)
            },
            883: function(e, t, n) {
                "use strict";
                var A = n(1718),
                    S = n(5225);

                function P() {
                    this.protocol = null, this.slashes = null, this.auth = null, this.host = null, this.port = null, this.hostname = null, this.hash = null, this.search = null, this.query = null, this.pathname = null, this.path = null, this.href = null
                }
                t.Qc = a, t.DB = function(e, t) {
                    return a(e, !1, !0).resolve(t)
                }, t.WU = function(e) {
                    S.isString(e) && (e = a(e));
                    return e instanceof P ? e.format() : P.prototype.format.call(e)
                };
                var R = /^([a-z0-9.+-]+:)/i,
                    r = /:[0-9]*$/,
                    E = /^(\/\/?(?!\/)[^\?\s]*)(\?[^\s]*)?$/,
                    t = ["{", "}", "|", "\\", "^", "`"].concat(["<", ">", '"', "`", " ", "\r", "\n", "\t"]),
                    L = ["'"].concat(t),
                    U = ["%", "/", "?", ";", "#"].concat(L),
                    q = ["/", "?", "#"],
                    O = /^[+a-z0-9A-Z_-]{0,63}$/,
                    D = /^([+a-z0-9A-Z_-]{0,63})(.*)$/,
                    x = {
                        javascript: !0,
                        "javascript:": !0
                    },
                    _ = {
                        javascript: !0,
                        "javascript:": !0
                    },
                    B = {
                        http: !0,
                        https: !0,
                        ftp: !0,
                        gopher: !0,
                        file: !0,
                        "http:": !0,
                        "https:": !0,
                        "ftp:": !0,
                        "gopher:": !0,
                        "file:": !0
                    },
                    F = n(6642);

                function a(e, t, n) {
                    if (e && S.isObject(e) && e instanceof P) return e;
                    var r = new P;
                    return r.parse(e, t, n), r
                }
                P.prototype.parse = function(e, t, n) {
                    if (!S.isString(e)) throw new TypeError("Parameter 'url' must be a string, not " + typeof e);
                    var r = e.indexOf("?"),
                        a = -1 !== r && r < e.indexOf("#") ? "?" : "#",
                        r = e.split(a);
                    r[0] = r[0].replace(/\\/g, "/");
                    var o = (o = e = r.join(a)).trim();
                    if (!n && 1 === e.split("#").length) {
                        var i = E.exec(o);
                        if (i) return this.path = o, this.href = o, this.pathname = i[1], i[2] ? (this.search = i[2], this.query = t ? F.parse(this.search.substr(1)) : this.search.substr(1)) : t && (this.search = "", this.query = {}), this
                    }
                    var s, i = R.exec(o);
                    if (i && (T = (i = i[0]).toLowerCase(), this.protocol = T, o = o.substr(i.length)), (n || i || o.match(/^\/\/[^@\/]+@[^@\/]+/)) && (!(s = "//" === o.substr(0, 2)) || i && _[i] || (o = o.substr(2), this.slashes = !0)), !_[i] && (s || i && !B[i])) {
                        for (var u = -1, c = 0; c < q.length; c++) - 1 !== (l = o.indexOf(q[c])) && (-1 === u || l < u) && (u = l); - 1 !== (P = -1 === u ? o.lastIndexOf("@") : o.lastIndexOf("@", u)) && (G = o.slice(0, P), o = o.slice(P + 1), this.auth = decodeURIComponent(G)), u = -1;
                        for (var l, c = 0; c < U.length; c++) - 1 !== (l = o.indexOf(U[c])) && (-1 === u || l < u) && (u = l); - 1 === u && (u = o.length), this.host = o.slice(0, u), o = o.slice(u), this.parseHost(), this.hostname = this.hostname || "";
                        var d = "[" === this.hostname[0] && "]" === this.hostname[this.hostname.length - 1];
                        if (!d)
                            for (var h = this.hostname.split(/\./), c = 0, v = h.length; c < v; c++) {
                                var p = h[c];
                                if (p && !p.match(O)) {
                                    for (var f = "", m = 0, g = p.length; m < g; m++) 127 < p.charCodeAt(m) ? f += "x" : f += p[m];
                                    if (!f.match(O)) {
                                        var I = h.slice(0, c),
                                            y = h.slice(c + 1),
                                            b = p.match(D);
                                        b && (I.push(b[1]), y.unshift(b[2])), y.length && (o = "/" + y.join(".") + o), this.hostname = I.join(".");
                                        break
                                    }
                                }
                            }
                        255 < this.hostname.length ? this.hostname = "" : this.hostname = this.hostname.toLowerCase(), d || (this.hostname = A.toASCII(this.hostname));
                        var P = this.port ? ":" + this.port : "",
                            G = this.hostname || "";
                        this.host = G + P, this.href += this.host, d && (this.hostname = this.hostname.substr(1, this.hostname.length - 2), "/" !== o[0] && (o = "/" + o))
                    }
                    if (!x[T])
                        for (c = 0, v = L.length; c < v; c++) {
                            var w, C = L[c]; - 1 !== o.indexOf(C) && ((w = encodeURIComponent(C)) === C && (w = escape(C)), o = o.split(C).join(w))
                        }
                    d = o.indexOf("#"); - 1 !== d && (this.hash = o.substr(d), o = o.slice(0, d));
                    var T, d = o.indexOf("?");
                    return -1 !== d ? (this.search = o.substr(d), this.query = o.substr(d + 1), t && (this.query = F.parse(this.query)), o = o.slice(0, d)) : t && (this.search = "", this.query = {}), o && (this.pathname = o), B[T] && this.hostname && !this.pathname && (this.pathname = "/"), (this.pathname || this.search) && (P = this.pathname || "", T = this.search || "", this.path = P + T), this.href = this.format(), this
                }, P.prototype.format = function() {
                    var e = this.auth || "";
                    e && (e = (e = encodeURIComponent(e)).replace(/%3A/i, ":"), e += "@");
                    var t = this.protocol || "",
                        n = this.pathname || "",
                        r = this.hash || "",
                        a = !1,
                        o = "";
                    this.host ? a = e + this.host : this.hostname && (a = e + (-1 === this.hostname.indexOf(":") ? this.hostname : "[" + this.hostname + "]"), this.port && (a += ":" + this.port)), this.query && S.isObject(this.query) && Object.keys(this.query).length && (o = F.stringify(this.query));
                    o = this.search || o && "?" + o || "";
                    return t && ":" !== t.substr(-1) && (t += ":"), this.slashes || (!t || B[t]) && !1 !== a ? (a = "//" + (a || ""), n && "/" !== n.charAt(0) && (n = "/" + n)) : a = a || "", r && "#" !== r.charAt(0) && (r = "#" + r), o && "?" !== o.charAt(0) && (o = "?" + o), t + a + (n = n.replace(/[?#]/g, function(e) {
                        return encodeURIComponent(e)
                    })) + (o = o.replace("#", "%23")) + r
                }, P.prototype.resolve = function(e) {
                    return this.resolveObject(a(e, !1, !0)).format()
                }, P.prototype.resolveObject = function(e) {
                    S.isString(e) && ((v = new P).parse(e, !1, !0), e = v);
                    for (var t = new P, n = Object.keys(this), r = 0; r < n.length; r++) {
                        var a = n[r];
                        t[a] = this[a]
                    }
                    if (t.hash = e.hash, "" === e.href) return t.href = t.format(), t;
                    if (e.slashes && !e.protocol) {
                        for (var o = Object.keys(e), i = 0; i < o.length; i++) {
                            var s = o[i];
                            "protocol" !== s && (t[s] = e[s])
                        }
                        return B[t.protocol] && t.hostname && !t.pathname && (t.path = t.pathname = "/"), t.href = t.format(), t
                    }
                    if (e.protocol && e.protocol !== t.protocol) {
                        if (!B[e.protocol]) {
                            for (var u = Object.keys(e), c = 0; c < u.length; c++) {
                                var l = u[c];
                                t[l] = e[l]
                            }
                            return t.href = t.format(), t
                        }
                        if (t.protocol = e.protocol, e.host || _[e.protocol]) t.pathname = e.pathname;
                        else {
                            for (var d = (e.pathname || "").split("/"); d.length && !(e.host = d.shift()););
                            e.host || (e.host = ""), e.hostname || (e.hostname = ""), "" !== d[0] && d.unshift(""), d.length < 2 && d.unshift(""), t.pathname = d.join("/")
                        }
                        return t.search = e.search, t.query = e.query, t.host = e.host || "", t.auth = e.auth, t.hostname = e.hostname || e.host, t.port = e.port, (t.pathname || t.search) && (p = t.pathname || "", f = t.search || "", t.path = p + f), t.slashes = t.slashes || e.slashes, t.href = t.format(), t
                    }
                    var h = t.pathname && "/" === t.pathname.charAt(0),
                        v = e.host || e.pathname && "/" === e.pathname.charAt(0),
                        p = v || h || t.host && e.pathname,
                        f = p,
                        m = t.pathname && t.pathname.split("/") || [],
                        d = e.pathname && e.pathname.split("/") || [],
                        h = t.protocol && !B[t.protocol];
                    if (h && (t.hostname = "", t.port = null, t.host && ("" === m[0] ? m[0] = t.host : m.unshift(t.host)), t.host = "", e.protocol && (e.hostname = null, e.port = null, e.host && ("" === d[0] ? d[0] = e.host : d.unshift(e.host)), e.host = null), p = p && ("" === d[0] || "" === m[0])), v) t.host = (e.host || "" === e.host ? e : t).host, t.hostname = (e.hostname || "" === e.hostname ? e : t).hostname, t.search = e.search, t.query = e.query, m = d;
                    else if (d.length)(m = m || []).pop(), m = m.concat(d), t.search = e.search, t.query = e.query;
                    else if (!S.isNullOrUndefined(e.search)) return h && (t.hostname = t.host = m.shift(), (b = !!(t.host && 0 < t.host.indexOf("@")) && t.host.split("@")) && (t.auth = b.shift(), t.host = t.hostname = b.shift())), t.search = e.search, t.query = e.query, S.isNull(t.pathname) && S.isNull(t.search) || (t.path = (t.pathname || "") + (t.search || "")), t.href = t.format(), t;
                    if (!m.length) return t.pathname = null, t.search ? t.path = "/" + t.search : t.path = null, t.href = t.format(), t;
                    for (var g = m.slice(-1)[0], v = (t.host || e.host || 1 < m.length) && ("." === g || ".." === g) || "" === g, I = 0, y = m.length; 0 <= y; y--) "." === (g = m[y]) ? m.splice(y, 1) : ".." === g ? (m.splice(y, 1), I++) : I && (m.splice(y, 1), I--);
                    if (!p && !f)
                        for (; I--;) m.unshift("..");
                    !p || "" === m[0] || m[0] && "/" === m[0].charAt(0) || m.unshift(""), v && "/" !== m.join("/").substr(-1) && m.push("");
                    var b, v = "" === m[0] || m[0] && "/" === m[0].charAt(0);
                    return h && (t.hostname = t.host = !v && m.length ? m.shift() : "", (b = !!(t.host && 0 < t.host.indexOf("@")) && t.host.split("@")) && (t.auth = b.shift(), t.host = t.hostname = b.shift())), (p = p || t.host && m.length) && !v && m.unshift(""), m.length ? t.pathname = m.join("/") : (t.pathname = null, t.path = null), S.isNull(t.pathname) && S.isNull(t.search) || (t.path = (t.pathname || "") + (t.search || "")), t.auth = e.auth || t.auth, t.slashes = t.slashes || e.slashes, t.href = t.format(), t
                }, P.prototype.parseHost = function() {
                    var e = this.host,
                        t = r.exec(e);
                    t && (":" !== (t = t[0]) && (this.port = t.substr(1)), e = e.substr(0, e.length - t.length)), e && (this.hostname = e)
                }
            },
            5225: function(e) {
                "use strict";
                e.exports = {
                    isString: function(e) {
                        return "string" == typeof e
                    },
                    isObject: function(e) {
                        return "object" == typeof e && null !== e
                    },
                    isNull: function(e) {
                        return null === e
                    },
                    isNullOrUndefined: function(e) {
                        return null == e
                    }
                }
            }
        },
        r = {};

    function Vl(e) {
        if (r[e]) return r[e].exports;
        var t = r[e] = {
            id: e,
            loaded: !1,
            exports: {}
        };
        return n[e].call(t.exports, t, t.exports, Vl), t.loaded = !0, t.exports
    }
    Vl.n = function(e) {
            var t = e && e.__esModule ? function() {
                return e.default
            } : function() {
                return e
            };
            return Vl.d(t, {
                a: t
            }), t
        }, Vl.d = function(e, t) {
            for (var n in t) Vl.o(t, n) && !Vl.o(e, n) && Object.defineProperty(e, n, {
                enumerable: !0,
                get: t[n]
            })
        }, Vl.g = function() {
            if ("object" == typeof globalThis) return globalThis;
            try {
                return this || new Function("return this")()
            } catch (e) {
                if ("object" == typeof window) return window
            }
        }(), Vl.o = function(e, t) {
            return Object.prototype.hasOwnProperty.call(e, t)
        }, Vl.nmd = function(e) {
            return e.paths = [], e.children || (e.children = []), e
        },
        function() {
            "use strict";

            function n(t, n, i) {
                return e(void 0, void 0, Promise, function() {
                    return l(this, function(e) {
                        try {
                            return [2, new Promise(function(a, o) {
                                u = t, c = n;
                                var e = indexedDB.open(u, 1);
                                e.onsuccess = function(t) {
                                    var e, n, r = t.target.result;
                                    r.objectStoreNames.contains(c) ? ((n = (e = r.transaction(c, "readwrite")).objectStore(c).delete(i)).onsuccess = function() {
                                        r.close(), a()
                                    }, n.onerror = function(e) {
                                        o(t.target.error)
                                    }, e.oncomplete = function(e) {
                                        r.close()
                                    }) : (r.close(), a())
                                }, e.onerror = function(e) {
                                    o(e.target.error)
                                }
                            })]
                        } catch (e) {
                            return console.warn("delete crypto record error: ", e), [2, {}]
                        }
                        return [2]
                    })
                })
            }

            function s() {
                return e(void 0, void 0, Promise, function() {
                    var n;
                    return l(this, function(e) {
                        try {
                            return n = indexedDB.deleteDatabase(u), [2, new Promise(function(e, t) {
                                n.onerror = function() {
                                    return t(n.error)
                                }, n.onsuccess = function() {
                                    return e()
                                }
                            })]
                        } catch (e) {
                            return console.warn("delete crypto db error: ", e), [2, {}]
                        }
                        return [2]
                    })
                })
            }

            function r(e) {
                if (window.TextEncoder) return (new TextEncoder).encode(e);
                for (var t = decodeURIComponent(encodeURIComponent(e)), n = new Uint8Array(t.length), r = 0; r < t.length; r++) n[r] = t.charCodeAt(r);
                return n
            }

            function a(e) {
                var t = "roblox.com",
                    n = "robloxlabs.com",
                    r = e || (null === (r = window.location) || void 0 === r ? void 0 : r.hostname);
                return -1 < r.indexOf(t) || -1 < r.indexOf(n)
            }
            var u, c, e = function(e, i, s, u) {
                    return new(s = s || Promise)(function(n, t) {
                        function r(e) {
                            try {
                                o(u.next(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function a(e) {
                            try {
                                o(u.throw(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function o(e) {
                            var t;
                            e.done ? n(e.value) : ((t = e.value) instanceof s ? t : new s(function(e) {
                                e(t)
                            })).then(r, a)
                        }
                        o((u = u.apply(e, i || [])).next())
                    })
                },
                l = function(n, r) {
                    var a, o, i, s = {
                            label: 0,
                            sent: function() {
                                if (1 & i[0]) throw i[1];
                                return i[1]
                            },
                            trys: [],
                            ops: []
                        },
                        e = {
                            next: t(0),
                            throw: t(1),
                            return: t(2)
                        };
                    return "function" == typeof Symbol && (e[Symbol.iterator] = function() {
                        return this
                    }), e;

                    function t(t) {
                        return function(e) {
                            return function(t) {
                                if (a) throw new TypeError("Generator is already executing.");
                                for (; s;) try {
                                    if (a = 1, o && (i = 2 & t[0] ? o.return : t[0] ? o.throw || ((i = o.return) && i.call(o), 0) : o.next) && !(i = i.call(o, t[1])).done) return i;
                                    switch (o = 0, i && (t = [2 & t[0], i.value]), t[0]) {
                                        case 0:
                                        case 1:
                                            i = t;
                                            break;
                                        case 4:
                                            return s.label++, {
                                                value: t[1],
                                                done: !1
                                            };
                                        case 5:
                                            s.label++, o = t[1], t = [0];
                                            continue;
                                        case 7:
                                            t = s.ops.pop(), s.trys.pop();
                                            continue;
                                        default:
                                            if (!(i = 0 < (i = s.trys).length && i[i.length - 1]) && (6 === t[0] || 2 === t[0])) {
                                                s = 0;
                                                continue
                                            }
                                            if (3 === t[0] && (!i || t[1] > i[0] && t[1] < i[3])) {
                                                s.label = t[1];
                                                break
                                            }
                                            if (6 === t[0] && s.label < i[1]) {
                                                s.label = i[1], i = t;
                                                break
                                            }
                                            if (i && s.label < i[2]) {
                                                s.label = i[2], s.ops.push(t);
                                                break
                                            }
                                            i[2] && s.ops.pop(), s.trys.pop();
                                            continue
                                    }
                                    t = r.call(n, s)
                                } catch (e) {
                                    t = [6, e], o = 0
                                } finally {
                                    a = i = 0
                                }
                                if (5 & t[0]) throw t[1];
                                return {
                                    value: t[0] ? t[1] : void 0,
                                    done: !0
                                }
                            }([t, e])
                        }
                    }
                },
                d = function(t, r, i) {
                    return e(void 0, void 0, Promise, function() {
                        return l(this, function(e) {
                            try {
                                return [2, new Promise(function(a, o) {
                                    u = t, c = r;
                                    var n = indexedDB.open(u, 1);
                                    n.onsuccess = function(t) {
                                        var n = t.target.result;
                                        try {
                                            var e = n.transaction(c, "readonly"),
                                                r = e.objectStore(c).get(i);
                                            r.onsuccess = function(e) {
                                                e = e.target.result;
                                                a(e)
                                            }, r.onerror = function(e) {
                                                o(t.target.error)
                                            }, e.oncomplete = function(e) {
                                                n.close()
                                            }
                                        } catch (e) {
                                            o(e)
                                        }
                                    }, n.onerror = function(e) {
                                        o(e.target.error)
                                    }, n.onupgradeneeded = function(e) {
                                        var t = n.result;
                                        t.objectStoreNames.contains(c) || t.createObjectStore(c)
                                    }
                                })]
                            } catch (e) {
                                return console.warn("get value from indexedDB error: ", e), [2, {}]
                            }
                            return [2]
                        })
                    })
                },
                h = function(t, n, a, o) {
                    return e(void 0, void 0, Promise, function() {
                        var r;
                        return l(this, function(e) {
                            try {
                                return u = t, c = n, r = indexedDB.open(u, 1), [2, new Promise(function(t, n) {
                                    r.onerror = function(e) {
                                        console.error("indexeddb request error"), n()
                                    }, r.onupgradeneeded = function(e) {
                                        var t = r.result;
                                        t.objectStoreNames.contains(c) || t.createObjectStore(c)
                                    }, r.onsuccess = function(e) {
                                        try {
                                            e.target.result.transaction(c, "readwrite").objectStore(c).put(o, a).onsuccess = function() {
                                                t()
                                            }
                                        } catch (e) {
                                            console.error("indexeddb transaction error"), n()
                                        }
                                    }
                                })]
                            } catch (e) {
                                console.warn("updating indexedDB error: ", e)
                            }
                            return [2]
                        })
                    })
                },
                t = {
                    getCryptoKeyPair: d,
                    putCryptoKeyPair: h,
                    deleteCryptoDB: s,
                    deleteCryptoKeyPair: n
                },
                o = function(e, i, s, u) {
                    return new(s = s || Promise)(function(n, t) {
                        function r(e) {
                            try {
                                o(u.next(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function a(e) {
                            try {
                                o(u.throw(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function o(e) {
                            var t;
                            e.done ? n(e.value) : ((t = e.value) instanceof s ? t : new s(function(e) {
                                e(t)
                            })).then(r, a)
                        }
                        o((u = u.apply(e, i || [])).next())
                    })
                },
                i = function(n, r) {
                    var a, o, i, s = {
                            label: 0,
                            sent: function() {
                                if (1 & i[0]) throw i[1];
                                return i[1]
                            },
                            trys: [],
                            ops: []
                        },
                        e = {
                            next: t(0),
                            throw: t(1),
                            return: t(2)
                        };
                    return "function" == typeof Symbol && (e[Symbol.iterator] = function() {
                        return this
                    }), e;

                    function t(t) {
                        return function(e) {
                            return function(t) {
                                if (a) throw new TypeError("Generator is already executing.");
                                for (; s;) try {
                                    if (a = 1, o && (i = 2 & t[0] ? o.return : t[0] ? o.throw || ((i = o.return) && i.call(o), 0) : o.next) && !(i = i.call(o, t[1])).done) return i;
                                    switch (o = 0, i && (t = [2 & t[0], i.value]), t[0]) {
                                        case 0:
                                        case 1:
                                            i = t;
                                            break;
                                        case 4:
                                            return s.label++, {
                                                value: t[1],
                                                done: !1
                                            };
                                        case 5:
                                            s.label++, o = t[1], t = [0];
                                            continue;
                                        case 7:
                                            t = s.ops.pop(), s.trys.pop();
                                            continue;
                                        default:
                                            if (!(i = 0 < (i = s.trys).length && i[i.length - 1]) && (6 === t[0] || 2 === t[0])) {
                                                s = 0;
                                                continue
                                            }
                                            if (3 === t[0] && (!i || t[1] > i[0] && t[1] < i[3])) {
                                                s.label = t[1];
                                                break
                                            }
                                            if (6 === t[0] && s.label < i[1]) {
                                                s.label = i[1], i = t;
                                                break
                                            }
                                            if (i && s.label < i[2]) {
                                                s.label = i[2], s.ops.push(t);
                                                break
                                            }
                                            i[2] && s.ops.pop(), s.trys.pop();
                                            continue
                                    }
                                    t = r.call(n, s)
                                } catch (e) {
                                    t = [6, e], o = 0
                                } finally {
                                    a = i = 0
                                }
                                if (5 & t[0]) throw t[1];
                                return {
                                    value: t[0] ? t[1] : void 0,
                                    done: !0
                                }
                            }([t, e])
                        }
                    }
                },
                v = (fe = (En = function() {
                    var e = document.querySelector('meta[name="hardware-backed-authentication-data"]'),
                        e = (null == e ? void 0 : e.dataset) || {};
                    return {
                        isBoundAuthTokenEnabled: "true" === e.isBoundAuthTokenEnabled,
                        boundAuthTokenWhitelist: e.boundAuthTokenWhitelist || "",
                        boundAuthTokenExemptlist: e.boundAuthTokenExemptlist || "",
                        hbaIndexedDBName: e.hbaIndexedDbName || "",
                        hbaIndexedDBObjStoreName: e.hbaIndexedDbObjStoreName || "",
                        hbaIndexedDBKeyName: e.hbaIndexedDbKeyName || "",
                        hbaIndexedDBVersion: parseInt(e.hbaIndexedDbVersion, 10) || 1,
                        batEventSampleRate: parseInt(e.batEventSampleRate, 10) || 0,
                        isSecureAuthenticationIntentEnabled: "true" === e.isSecureAuthenticationIntentEnabled
                    }
                })()).hbaIndexedDBName,
                p = fe.hbaIndexedDBObjStoreName,
                f = function(t) {
                    return o(void 0, void 0, Promise, function() {
                        return i(this, function(e) {
                            switch (e.label) {
                                case 0:
                                    return v && p ? [4, n(v, p, t)] : [3, 2];
                                case 1:
                                    e.sent(), e.label = 2;
                                case 2:
                                    return [2]
                            }
                        })
                    })
                },
                m = Roblox,
                g = Vl.n(m),
                I = Vl(9644),
                y = Vl.n(I),
                b = RobloxTracer,
                P = (ae = document.querySelector('meta[name="request-duplication-meta-data"]'), ie = parseFloat(null == ae || null === (ie = ae.dataset) || void 0 === ie ? void 0 : ie.duplicationRatio), ie = Number.isNaN(ie) ? 0 : ie, {
                    duplicationEnabled: "true" === (null == ae || null === (re = ae.dataset) || void 0 === re ? void 0 : re.duplicationEnabled),
                    apiSitesAllowList: null !== (oe = null == ae || null === (oe = ae.dataset) || void 0 === oe ? void 0 : oe.apiSitesAllowList) && void 0 !== oe ? oe : "",
                    duplicationRatio: ie
                }),
                G = P.apiSitesAllowList.split(","),
                w = function(e, t) {
                    return P.duplicationEnabled && !t && (n = e, !(!a() || !a(n)) && (0 < G.length && G.some(function(e) {
                        return 0 < e.length && n.includes(e)
                    })));
                    var n
                },
                C = function() {
                    var e = P.duplicationRatio;
                    if (e <= 0) return 0;
                    var t = Math.floor(e),
                        e = e - t,
                        t = t;
                    return 0 < e && Math.random() < e && (t += 1), t
                },
                T = {
                    retryAttemptHeaderEnabled: "True" === (null == (se = document.querySelector('meta[name="page-retry-header-enabled"]')) || null === (pe = se.dataset) || void 0 === pe ? void 0 : pe.retryAttemptHeaderEnabled)
                },
                A = function() {
                    return T.retryAttemptHeaderEnabled
                };
            (Wr = Ve = Ve || {}).GET = "get", Wr.HEAD = "head", Wr.POST = "post", Wr.PUT = "put", Wr.DELETE = "delete", Wr.OPTIONS = "options", Wr.PATCH = "patch";
            var S = Object.freeze(Ve);
            ($r = Pn = Pn || {})[$r.ok = 200] = "ok", $r[$r.accepted = 202] = "accepted", $r[$r.movedPermanently = 301] = "movedPermanently", $r[$r.badRequest = 400] = "badRequest", $r[$r.unauthorized = 401] = "unauthorized", $r[$r.forbidden = 403] = "forbidden", $r[$r.notFound = 404] = "notFound", $r[$r.methodNotAllowed = 405] = "methodNotAllowed", $r[$r.conflict = 409] = "conflict", $r[$r.payloadTooLarge = 413] = "payloadTooLarge", $r[$r.tooManyAttempts = 429] = "tooManyAttempts", $r[$r.serverError = 500] = "serverError", $r[$r.serviceUnavailable = 503] = "serviceUnavailable";
            var R = Object.freeze(Pn),
                E = function() {
                    return (E = Object.assign || function(e) {
                        for (var t, n = 1, r = arguments.length; n < r; n++)
                            for (var a in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
                        return e
                    }).apply(this, arguments)
                },
                L = "x-csrf-token",
                U = R.forbidden,
                q = "Generic Challenge:",
                O = "rblx-challenge-id",
                D = "rblx-challenge-type",
                x = "rblx-challenge-metadata",
                _ = "x-retry-attempt",
                B = m.XsrfToken.getToken();
            y().interceptors.request.use(function(e) {
                var t, n, r = e.method,
                    a = e.noCache,
                    o = e.noPragma,
                    i = e.headers,
                    s = e.url,
                    u = E({}, e);
                if (r !== S.POST && r !== S.PATCH && r !== S.DELETE || (B = B || m.XsrfToken.getToken(), a && (u.headers = E({
                        "Cache-Control": "no-cache, no-store, must-revalidate",
                        Pragma: "no-cache",
                        Expires: 0
                    }, i)), o && u.headers.Pragma && delete u.headers.Pragma, u.headers[L] = B), m.Endpoints && m.Endpoints.supportLocalizedUrls && m.Endpoints.getAcceptLanguageValue && ((t = m.Endpoints.getAcceptLanguageValue(s)) && (u.headers["Accept-Language"] = t)), b.isTracerEnabled && b.apiSiteRequestValidator.isApiSiteAvailableForTracing(s) && (t = {
                        tags: {
                            isDuplicate: (null === (t = e.isDuplicate) || void 0 === t ? void 0 : t.toString()) || "false"
                        }
                    }, t = b.instrumentation.createAndGetSpan(b.tracerConstants.operationNames.httpRequest, t), b.tags.setXHRRequestTags(t, {
                        component: "axios",
                        method: r,
                        url: s
                    }), b.logs.setXHRRequestLogs(t), n = b.inject.httpRequestCarrier(t), Object.keys(n).forEach(function(e) {
                        u.headers[e] = n[e]
                    }), u.tracerConfig = {
                        requestSpan: t
                    }), w(s, e.isDuplicate)) {
                    var c = E({}, e);
                    c.isDuplicate = !0;
                    for (var l = C(), d = 0; d < l; d++) y().request(c).catch(function(e) {
                        console.log("~~~~ duplicated request failed ~~~~ " + e)
                    })
                }
                return u
            }, null), y().interceptors.response.use(function(e) {
                var t = e.status,
                    n = e.config,
                    r = n.url,
                    n = n.tracerConfig;
                return n && b.apiSiteRequestValidator.isApiSiteAvailableForTracing(r) && (n = n.requestSpan, b.tags.setXHRResponseTags(n, {
                    status: t
                }), b.logs.setXHRResponseSuccessLogs(n), b.instrumentation.finalizeSpan(n)), e
            }, function(e) {
                var t = e.config,
                    n = e.response;
                if (n) {
                    var r = n.status,
                        a = n.headers,
                        o = n.config,
                        i = a[L];
                    if (r === U && i) return o.headers[L] = i, B = i, m.XsrfToken.setToken(i), y().request(o);
                    A() && (i = 1, o.headers[_] && (i = Number(o.headers[_]) + 1), o.headers[_] = String(i)), null != o && o.tracerConfig && b.apiSiteRequestValidator.isApiSiteAvailableForTracing(o.url) && (u = o.tracerConfig.requestSpan, b.tags.setXHRResponseErrorTags(u, {
                        status: r
                    }), b.logs.setXHRResponseErrorLogs(u), b.instrumentation.finalizeSpan(u));
                    var r = a["rblx-challenge-id"],
                        s = a["rblx-challenge-type"],
                        u = a["rblx-challenge-metadata"],
                        a = void 0 !== r || void 0 !== s || void 0 !== u;
                    if (void 0 !== r && void 0 !== s && void 0 !== u) {
                        if (g() && g().AccountIntegrityChallengeService) return g().AccountIntegrityChallengeService.Generic.interceptChallenge({
                            retryRequest: function(e, t) {
                                return o.headers[O] = e, o.headers[D] = s, o.headers[x] = t, y().request(o)
                            },
                            containerId: "generic-challenge-container",
                            challengeId: r,
                            challengeTypeRaw: s,
                            challengeMetadataJsonBase64: u
                        });
                        console.error(q, "Got challenge but challenge component not available")
                    } else a && console.error(q, "Got only partial challenge headers")
                }
                return null != t && t.fullError || y().isCancel(e) ? Promise.reject(e) : Promise.reject(n)
            });
            var F = y();

            function N(n) {
                return function(e, t) {
                    return n.chain(e, function(e) {
                        return n.map(t(e), function() {
                            return e
                        })
                    })
                }
            }
            var k = function(e, t, n) {
                if (n || 2 === arguments.length)
                    for (var r, a = 0, o = t.length; a < o; a++) !r && a in t || ((r = r || Array.prototype.slice.call(t, 0, a))[a] = t[a]);
                return e.concat(r || Array.prototype.slice.call(t))
            };

            function M(e) {
                return e
            }

            function j(e, t, n, r, a, o, i, s, u) {
                switch (arguments.length) {
                    case 1:
                        return e;
                    case 2:
                        return t(e);
                    case 3:
                        return n(t(e));
                    case 4:
                        return r(n(t(e)));
                    case 5:
                        return a(r(n(t(e))));
                    case 6:
                        return o(a(r(n(t(e)))));
                    case 7:
                        return i(o(a(r(n(t(e))))));
                    case 8:
                        return s(i(o(a(r(n(t(e)))))));
                    case 9:
                        return u(s(i(o(a(r(n(t(e))))))));
                    default:
                        for (var c = e, l = 1; l < arguments.length; l++) c = arguments[l](c);
                        return c
                }
            }
            var z = function(t, n) {
                var e = "number" == typeof t ? function(e) {
                    return e.length >= t
                } : t;
                return function() {
                    var t = Array.from(arguments);
                    return e(arguments) ? n.apply(this, t) : function(e) {
                        return n.apply(void 0, k([e], t, !1))
                    }
                }
            };

            function W(n) {
                return function(e, t) {
                    return n.map(e, function() {
                        return t
                    })
                }
            }

            function V(e) {
                return {
                    _tag: "Left",
                    left: e
                }
            }

            function H(e) {
                return {
                    _tag: "Right",
                    right: e
                }
            }
            var Q, K = [],
                X = {},
                J = (Object.prototype.hasOwnProperty, V),
                Y = H,
                Z = z(2, function(e, t) {
                    return me(e) ? e : t(e.right)
                }),
                ee = function(e, t) {
                    return j(e, ue(t))
                },
                te = function(e, t) {
                    return j(e, ce(t))
                },
                ne = function(e, t, n) {
                    return j(e, le(t, n))
                },
                re = function(e, t) {
                    return j(e, de(t))
                },
                ae = function(e, t) {
                    return j(e, he(t))
                },
                oe = function(e, t) {
                    return j(e, ve(t))
                },
                ie = function(e, t) {
                    return function(e, t) {
                        for (var n = t(e);
                            "Left" === n._tag;) n = t(n.left);
                        return n.right
                    }(t(e), function(e) {
                        return me(e) ? Y(J(e.left)) : me(e.right) ? J(t(e.right.left)) : Y(Y(e.right.right))
                    })
                },
                se = "Either",
                ue = function(t) {
                    return function(e) {
                        return me(e) ? e : Y(t(e.right))
                    }
                },
                ce = (z(2, W(pe = {
                    URI: se,
                    map: ee
                })), W(pe), function(t) {
                    return function(e) {
                        return me(e) ? e : me(t) ? t : Y(e.right(t.right))
                    }
                }),
                le = function(t, n) {
                    return function(e) {
                        return me(e) ? J(t(e.left)) : Y(n(e.right))
                    }
                },
                de = function(t) {
                    return function(e) {
                        return me(e) ? J(t(e.left)) : e
                    }
                },
                he = function(t) {
                    return function(e) {
                        return me(e) ? t() : e
                    }
                },
                ve = function(t) {
                    return function(e) {
                        return me(e) ? e : Y(t(e))
                    }
                },
                pe = J,
                fe = {
                    URI: se,
                    fromEither: M
                },
                me = function(e) {
                    return "Left" === e._tag
                },
                ge = function(e) {
                    return "Right" === e._tag
                };

            function Ie(t, e) {
                var n, r = Object.keys(t);
                return Object.getOwnPropertySymbols && (n = Object.getOwnPropertySymbols(t), e && (n = n.filter(function(e) {
                    return Object.getOwnPropertyDescriptor(t, e).enumerable
                })), r.push.apply(r, n)), r
            }

            function ye(r) {
                for (var e = 1; e < arguments.length; e++) {
                    var a = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? Ie(Object(a), !0).forEach(function(e) {
                        var t, n;
                        t = r, e = a[n = e], n in t ? Object.defineProperty(t, n, {
                            value: e,
                            enumerable: !0,
                            configurable: !0,
                            writable: !0
                        }) : t[n] = e
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(r, Object.getOwnPropertyDescriptors(a)) : Ie(Object(a)).forEach(function(e) {
                        Object.defineProperty(r, e, Object.getOwnPropertyDescriptor(a, e))
                    })
                }
                return r
            }

            function be() {
                return void 0 !== m.EventStream
            }

            function Pe(e, t, n, r) {
                be() && m.EventStream.SendEventWithTarget && (r = Object.values(Te).includes(r) ? r : Te.WWW, m.EventStream.SendEventWithTarget(e, t, n, r))
            }

            function Ge() {
                Ae.sendEventWithTarget(Se.eventName.saiCreated, Se.context.hba, {})
            }

            function we(e) {
                Ae.sendEventWithTarget(Se.eventName.saiMissing, Se.context.hba, {
                    messageRaw: e.message
                })
            }
            N(Z = {
                URI: se,
                map: ee,
                ap: te,
                chain: Z
            }), (I = Q = Q || {}).RequestExempt = "RequestExempt", I.RequestExemptError = "RequestExemptError", I.GetKeyPairFailed = "GetKeyPairFailed", I.UpdateKeyPairFailed = "UpdateKeyPairFailed", I.NoKeyPairFound = "NoKeyPairFound", I.RequestBodyHashFailed = "RequestBodyHashFailed", I.SignatureFailed = "SignatureFailed", I.Unknown = "Unknown";
            var Ce, Te = ye(ye({}, {
                    DEFAULT: 0,
                    WWW: 1,
                    STUDIO: 2,
                    DIAGNOSTIC: 3
                }), be() ? m.EventStream.TargetTypes : {}),
                Ae = {
                    eventTypes: {
                        formInteraction: "formInteraction",
                        modalAction: "modalAction",
                        pageLoad: "pageLoad",
                        buttonClick: "buttonClick"
                    },
                    targetTypes: Te,
                    sendEvent: function(e, t) {
                        var n = e.name,
                            r = e.type,
                            a = e.context,
                            e = e.requiredParams,
                            o = ye({
                                btn: n
                            }, t);
                        Array.isArray(e) && e.forEach(function(e) {
                            Object.prototype.hasOwnProperty.call(o, e) || console.info("A required event parameter '".concat(e, "' is not provided"))
                        }), Pe(r, a, o)
                    },
                    sendEventWithTarget: Pe,
                    sendGamePlayEvent: function(e, t, n, r) {
                        m.GamePlayEvents && m.GamePlayEvents.SendGamePlayIntent && m.GamePlayEvents.SendGamePlayIntent(e, t, n, r)
                    }
                },
                Se = {
                    eventName: {
                        batCreated: "batCreated",
                        batMissing: "batMissing",
                        saiCreated: "saiCreated",
                        saiMissing: "saiMissing"
                    },
                    context: {
                        hba: "hba"
                    },
                    sessionStorageState: {
                        batSuccessEventSent: "batSuccessEventSent",
                        batMissingEventSent: "batMissingEventSent"
                    }
                },
                Re = function(e, t) {
                    1e6 * Math.random() < t && Ae.sendEventWithTarget(Se.eventName.batCreated, Se.context.hba, {
                        field: e
                    })
                },
                Ee = function(e, t, n) {
                    1e6 * Math.random() < n && Ae.sendEventWithTarget(Se.eventName.batMissing, Se.context.hba, {
                        field: e,
                        kind: t.kind,
                        messageRaw: t.message
                    })
                },
                Le = function(e) {
                    return function(t) {
                        if ("object" == typeof(e = t) && null !== e && "message" in e && "string" == typeof e.message) return t;
                        var e;
                        try {
                            return new Error(JSON.stringify(t))
                        } catch (e) {
                            return new Error(String(t))
                        }
                    }(e).message
                },
                Ue = function() {
                    return (Ue = Object.assign || function(e) {
                        for (var t, n = 1, r = arguments.length; n < r; n++)
                            for (var a in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
                        return e
                    }).apply(this, arguments)
                },
                qe = function(e, i, s, u) {
                    return new(s = s || Promise)(function(n, t) {
                        function r(e) {
                            try {
                                o(u.next(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function a(e) {
                            try {
                                o(u.throw(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function o(e) {
                            var t;
                            e.done ? n(e.value) : ((t = e.value) instanceof s ? t : new s(function(e) {
                                e(t)
                            })).then(r, a)
                        }
                        o((u = u.apply(e, i || [])).next())
                    })
                },
                Oe = function(n, r) {
                    var a, o, i, s = {
                            label: 0,
                            sent: function() {
                                if (1 & i[0]) throw i[1];
                                return i[1]
                            },
                            trys: [],
                            ops: []
                        },
                        e = {
                            next: t(0),
                            throw: t(1),
                            return: t(2)
                        };
                    return "function" == typeof Symbol && (e[Symbol.iterator] = function() {
                        return this
                    }), e;

                    function t(t) {
                        return function(e) {
                            return function(t) {
                                if (a) throw new TypeError("Generator is already executing.");
                                for (; s;) try {
                                    if (a = 1, o && (i = 2 & t[0] ? o.return : t[0] ? o.throw || ((i = o.return) && i.call(o), 0) : o.next) && !(i = i.call(o, t[1])).done) return i;
                                    switch (o = 0, i && (t = [2 & t[0], i.value]), t[0]) {
                                        case 0:
                                        case 1:
                                            i = t;
                                            break;
                                        case 4:
                                            return s.label++, {
                                                value: t[1],
                                                done: !1
                                            };
                                        case 5:
                                            s.label++, o = t[1], t = [0];
                                            continue;
                                        case 7:
                                            t = s.ops.pop(), s.trys.pop();
                                            continue;
                                        default:
                                            if (!(i = 0 < (i = s.trys).length && i[i.length - 1]) && (6 === t[0] || 2 === t[0])) {
                                                s = 0;
                                                continue
                                            }
                                            if (3 === t[0] && (!i || t[1] > i[0] && t[1] < i[3])) {
                                                s.label = t[1];
                                                break
                                            }
                                            if (6 === t[0] && s.label < i[1]) {
                                                s.label = i[1], i = t;
                                                break
                                            }
                                            if (i && s.label < i[2]) {
                                                s.label = i[2], s.ops.push(t);
                                                break
                                            }
                                            i[2] && s.ops.pop(), s.trys.pop();
                                            continue
                                    }
                                    t = r.call(n, s)
                                } catch (e) {
                                    t = [6, e], o = 0
                                } finally {
                                    a = i = 0
                                }
                                if (5 & t[0]) throw t[1];
                                return {
                                    value: t[0] ? t[1] : void 0,
                                    done: !0
                                }
                            }([t, e])
                        }
                    }
                },
                De = "|",
                xe = [".roblox.com", ".robloxlabs.com", ".roblox.qq.com"],
                _e = (Wr = En()).isBoundAuthTokenEnabled,
                Be = Wr.hbaIndexedDBName,
                Fe = Wr.hbaIndexedDBObjStoreName,
                Ne = Wr.hbaIndexedDBKeyName,
                ke = Wr.batEventSampleRate,
                Me = function(e) {
                    for (var t = 0; t < xe.length; t++)
                        if (function(e) {
                                try {
                                    return new URL(e).hostname
                                } catch (e) {
                                    return ""
                                }
                            }(e.url).endsWith(xe[t])) return !0;
                    return !1
                };

            function je(e) {
                try {
                    return m.CurrentUser ? null !== m.CurrentUser && void 0 !== m.CurrentUser && m.CurrentUser.isAuthenticated ? Me(e) ? Be ? Fe ? Ne ? _e ? Y(!0) : J({
                        kind: Q.RequestExempt,
                        message: "BoundAuthTokenNotEnabled"
                    }) : J({
                        kind: Q.RequestExempt,
                        message: "EmptyIndexedDbKeyName"
                    }) : J({
                        kind: Q.RequestExempt,
                        message: "EmptyIndexedDbObjectStoreName"
                    }) : J({
                        kind: Q.RequestExempt,
                        message: "EmptyIndexedDbName"
                    }) : J({
                        kind: Q.RequestExempt,
                        message: "UrlNotFromAllowedHost"
                    }) : J({
                        kind: Q.RequestExempt,
                        message: "CurrentUserNotAuthenticated"
                    }) : J({
                        kind: Q.RequestExempt,
                        message: "NoCurrentUser"
                    })
                } catch (e) {
                    return J({
                        kind: Q.RequestExemptError,
                        message: Le(e)
                    })
                }
            }

            function ze(s) {
                return qe(this, void 0, Promise, function() {
                    var t, n, r, a, o, i;
                    return Oe(this, function(e) {
                        switch (e.label) {
                            case 0:
                                if (e.trys.push([0, 17, , 18]), Ce) return [3, 8];
                                e.label = 1;
                            case 1:
                                return e.trys.push([1, 3, , 4]), [4, d(Be, Fe, Ne)];
                            case 2:
                                return Ce = e.sent(), [3, 4];
                            case 3:
                                return t = e.sent(), [2, J({
                                    message: Le(t),
                                    kind: Q.GetKeyPairFailed
                                })];
                            case 4:
                                return e.trys.push([4, 7, , 8]), Ce ? [3, 6] : [4, function() {
                                    return qe(this, void 0, Promise, function() {
                                        var t, n;
                                        return Oe(this, function(e) {
                                            switch (e.label) {
                                                case 0:
                                                    return t = (null === m.Cookies || void 0 === m.Cookies ? void 0 : m.Cookies.getBrowserTrackerId()) || "", [4, d(Be, Fe, t)];
                                                case 1:
                                                    return (n = e.sent()) && Ne ? [4, h(Be, Fe, Ne, n)] : [3, 4];
                                                case 2:
                                                    return e.sent(), [4, d(Be, Fe, Ne)];
                                                case 3:
                                                    n = e.sent(), e.label = 4;
                                                case 4:
                                                    return [2, n]
                                            }
                                        })
                                    })
                                }()];
                            case 5:
                                Ce = e.sent(), e.label = 6;
                            case 6:
                                return [3, 8];
                            case 7:
                                return t = e.sent(), [2, J({
                                    message: Le(t),
                                    kind: Q.UpdateKeyPairFailed
                                })];
                            case 8:
                                if (!Ce) return [2, J({
                                    message: "",
                                    kind: Q.NoKeyPairFound
                                })];
                                n = Math.floor(Date.now() / 1e3).toString(), a = void 0, "object" == typeof s.data ? a = JSON.stringify(s.data) : "string" == typeof s.data && (a = s.data), r = "", e.label = 9;
                            case 9:
                                return e.trys.push([9, 11, , 12]), [4, Pt.hashStringWithSha256(a)];
                            case 10:
                                return r = e.sent(), [3, 12];
                            case 11:
                                return a = e.sent(), [2, J({
                                    message: Le(a),
                                    kind: Q.RequestBodyHashFailed
                                })];
                            case 12:
                                o = [r, n].join(De), i = "", e.label = 13;
                            case 13:
                                return e.trys.push([13, 15, , 16]), [4, Pt.sign(Ce.privateKey, o)];
                            case 14:
                                return i = e.sent(), [3, 16];
                            case 15:
                                return o = e.sent(), [2, J({
                                    message: Le(o),
                                    kind: Q.SignatureFailed
                                })];
                            case 16:
                                return [2, Y([r, n, i].join(De))];
                            case 17:
                                return i = e.sent(), console.warn("BAT generation error:", i), [2, J({
                                    message: Le(i),
                                    kind: Q.Unknown
                                })];
                            case 18:
                                return [2]
                        }
                    })
                })
            }

            function We(r) {
                return qe(this, void 0, Promise, function() {
                    var t, n;
                    return Oe(this, function(e) {
                        switch (e.label) {
                            case 0:
                                return n = je(r), me(n) ? (Ee(r.url, n.left, ke), [2, r]) : [4, ze(r)];
                            case 1:
                                return t = e.sent(), n = Ue({}, r), ge(t) ? (n.headers = Ue(Ue({}, n.headers), {
                                    "x-bound-auth-token": t.right
                                }), Re(r.url, ke)) : Ee(r.url, t.left, ke), [2, n]
                        }
                    })
                })
            }
            var Ve = {
                    shouldRequestWithBoundAuthToken: je,
                    generateBoundAuthToken: ze,
                    buildConfigBoundAuthToken: We
                },
                He = function() {
                    return (He = Object.assign || function(e) {
                        for (var t, n = 1, r = arguments.length; n < r; n++)
                            for (var a in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
                        return e
                    }).apply(this, arguments)
                };

            function Qe(e) {
                return e || Promise.reject(new Error("No config found")), We(e).then(function(e) {
                    return F((e = He({}, t = e), t.noCache && (e.headers = He({
                        "Cache-Control": "no-cache, no-store, must-revalidate",
                        Pragma: "no-cache",
                        Expires: 0
                    }, e.headers)), t.noPragma && e.headers.Pragma && delete e.headers.Pragma, t.authBearerToken && (e.headers = He(He({}, e.headers), {
                        "X-Auth-Bearer-Token": t.authBearerToken
                    })), e));
                    var t
                })
            }

            function Ke(e, t) {
                return Qe(He(He({
                    method: S.GET,
                    url: e.url
                }, e), {
                    params: t
                }))
            }

            function Xe(e, t) {
                return Qe(He(He({
                    method: S.POST,
                    url: e.url
                }, e), {
                    data: t
                }))
            }

            function Je(e) {
                var t = [];
                return e && "object" == typeof e && (e = e.errors) instanceof Array ? (e.forEach(function(e) {
                    !e || "object" != typeof e || "number" == typeof(e = e.code) && t.push(e)
                }), t) : []
            }

            function Ye() {
                return at(void 0, void 0, Promise, function() {
                    var t;
                    return ot(this, function(e) {
                        switch (e.label) {
                            case 0:
                                return t = m.EnvironmentUrls.apiGatewayUrl + "/hba-service/v1/getServerNonce", t = {
                                    url: t,
                                    withCredentials: !0
                                }, [4, rt.get(t)];
                            case 1:
                                return [2, e.sent().data]
                        }
                    })
                })
            }

            function $e(t) {
                return it(void 0, void 0, Promise, function() {
                    return st(this, function(e) {
                        switch (e.label) {
                            case 0:
                                return ut && ct && lt ? [4, h(ut, ct, lt, t).catch(function(e) {
                                    console.error("putting cryptoKeyPair error")
                                })] : [3, 2];
                            case 1:
                                e.sent(), e.label = 2;
                            case 2:
                                return [2]
                        }
                    })
                })
            }

            function Ze(e) {
                for (var t = new Uint8Array(e.length), n = 0; n < e.length; n++) t[n] = e.charCodeAt(n);
                return t.buffer
            }

            function et(e) {
                for (var t = "", n = new Uint8Array(e), r = 0; r < n.byteLength; r++) t += String.fromCharCode(n[r]);
                return btoa(t)
            }
            var tt, nt, rt = {
                    methods: S,
                    get: Ke,
                    post: Xe,
                    delete: function(e, t) {
                        return Qe(He(He({
                            method: S.DELETE,
                            url: e.url
                        }, e), {
                            params: t
                        }))
                    },
                    patch: function(e, t) {
                        return Qe(He(He({
                            method: S.PATCH,
                            url: e.url
                        }, e), {
                            data: t
                        }))
                    },
                    put: function(e, t) {
                        return Qe(He(He({
                            method: S.PUT,
                            url: e.url
                        }, e), {
                            data: t
                        }))
                    },
                    buildBatchPromises: function(e, t, n, r, a) {
                        for (var o = [], i = 0, s = e.slice(i, t), u = a || "userIds"; 0 < s.length;) {
                            var c = {};
                            c[u] = s, r ? o.push(Xe(n, c)) : o.push(Ke(n, c)), i += 1, s = e.slice(i * t, i * t + t)
                        }
                        return Promise.all(o)
                    },
                    createCancelToken: function() {
                        return F.CancelToken.source()
                    },
                    isCancelled: function(e) {
                        return F.isCancel(e)
                    },
                    getApiErrorCodes: Je,
                    parseErrorCode: function(e) {
                        var t = Je(e);
                        return "object" == typeof e && Je(e.data).forEach(function(e) {
                            return t.push(e)
                        }), t[0] || null
                    }
                },
                at = function(e, i, s, u) {
                    return new(s = s || Promise)(function(n, t) {
                        function r(e) {
                            try {
                                o(u.next(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function a(e) {
                            try {
                                o(u.throw(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function o(e) {
                            var t;
                            e.done ? n(e.value) : ((t = e.value) instanceof s ? t : new s(function(e) {
                                e(t)
                            })).then(r, a)
                        }
                        o((u = u.apply(e, i || [])).next())
                    })
                },
                ot = function(n, r) {
                    var a, o, i, s = {
                            label: 0,
                            sent: function() {
                                if (1 & i[0]) throw i[1];
                                return i[1]
                            },
                            trys: [],
                            ops: []
                        },
                        e = {
                            next: t(0),
                            throw: t(1),
                            return: t(2)
                        };
                    return "function" == typeof Symbol && (e[Symbol.iterator] = function() {
                        return this
                    }), e;

                    function t(t) {
                        return function(e) {
                            return function(t) {
                                if (a) throw new TypeError("Generator is already executing.");
                                for (; s;) try {
                                    if (a = 1, o && (i = 2 & t[0] ? o.return : t[0] ? o.throw || ((i = o.return) && i.call(o), 0) : o.next) && !(i = i.call(o, t[1])).done) return i;
                                    switch (o = 0, i && (t = [2 & t[0], i.value]), t[0]) {
                                        case 0:
                                        case 1:
                                            i = t;
                                            break;
                                        case 4:
                                            return s.label++, {
                                                value: t[1],
                                                done: !1
                                            };
                                        case 5:
                                            s.label++, o = t[1], t = [0];
                                            continue;
                                        case 7:
                                            t = s.ops.pop(), s.trys.pop();
                                            continue;
                                        default:
                                            if (!(i = 0 < (i = s.trys).length && i[i.length - 1]) && (6 === t[0] || 2 === t[0])) {
                                                s = 0;
                                                continue
                                            }
                                            if (3 === t[0] && (!i || t[1] > i[0] && t[1] < i[3])) {
                                                s.label = t[1];
                                                break
                                            }
                                            if (6 === t[0] && s.label < i[1]) {
                                                s.label = i[1], i = t;
                                                break
                                            }
                                            if (i && s.label < i[2]) {
                                                s.label = i[2], s.ops.push(t);
                                                break
                                            }
                                            i[2] && s.ops.pop(), s.trys.pop();
                                            continue
                                    }
                                    t = r.call(n, s)
                                } catch (e) {
                                    t = [6, e], o = 0
                                } finally {
                                    a = i = 0
                                }
                                if (5 & t[0]) throw t[1];
                                return {
                                    value: t[0] ? t[1] : void 0,
                                    done: !0
                                }
                            }([t, e])
                        }
                    }
                },
                it = function(e, i, s, u) {
                    return new(s = s || Promise)(function(n, t) {
                        function r(e) {
                            try {
                                o(u.next(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function a(e) {
                            try {
                                o(u.throw(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function o(e) {
                            var t;
                            e.done ? n(e.value) : ((t = e.value) instanceof s ? t : new s(function(e) {
                                e(t)
                            })).then(r, a)
                        }
                        o((u = u.apply(e, i || [])).next())
                    })
                },
                st = function(n, r) {
                    var a, o, i, s = {
                            label: 0,
                            sent: function() {
                                if (1 & i[0]) throw i[1];
                                return i[1]
                            },
                            trys: [],
                            ops: []
                        },
                        e = {
                            next: t(0),
                            throw: t(1),
                            return: t(2)
                        };
                    return "function" == typeof Symbol && (e[Symbol.iterator] = function() {
                        return this
                    }), e;

                    function t(t) {
                        return function(e) {
                            return function(t) {
                                if (a) throw new TypeError("Generator is already executing.");
                                for (; s;) try {
                                    if (a = 1, o && (i = 2 & t[0] ? o.return : t[0] ? o.throw || ((i = o.return) && i.call(o), 0) : o.next) && !(i = i.call(o, t[1])).done) return i;
                                    switch (o = 0, i && (t = [2 & t[0], i.value]), t[0]) {
                                        case 0:
                                        case 1:
                                            i = t;
                                            break;
                                        case 4:
                                            return s.label++, {
                                                value: t[1],
                                                done: !1
                                            };
                                        case 5:
                                            s.label++, o = t[1], t = [0];
                                            continue;
                                        case 7:
                                            t = s.ops.pop(), s.trys.pop();
                                            continue;
                                        default:
                                            if (!(i = 0 < (i = s.trys).length && i[i.length - 1]) && (6 === t[0] || 2 === t[0])) {
                                                s = 0;
                                                continue
                                            }
                                            if (3 === t[0] && (!i || t[1] > i[0] && t[1] < i[3])) {
                                                s.label = t[1];
                                                break
                                            }
                                            if (6 === t[0] && s.label < i[1]) {
                                                s.label = i[1], i = t;
                                                break
                                            }
                                            if (i && s.label < i[2]) {
                                                s.label = i[2], s.ops.push(t);
                                                break
                                            }
                                            i[2] && s.ops.pop(), s.trys.pop();
                                            continue
                                    }
                                    t = r.call(n, s)
                                } catch (e) {
                                    t = [6, e], o = 0
                                } finally {
                                    a = i = 0
                                }
                                if (5 & t[0]) throw t[1];
                                return {
                                    value: t[0] ? t[1] : void 0,
                                    done: !0
                                }
                            }([t, e])
                        }
                    }
                },
                ut = ($r = En()).hbaIndexedDBName,
                ct = $r.hbaIndexedDBObjStoreName,
                lt = $r.hbaIndexedDBKeyName,
                dt = function(e, i, s, u) {
                    return new(s = s || Promise)(function(n, t) {
                        function r(e) {
                            try {
                                o(u.next(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function a(e) {
                            try {
                                o(u.throw(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function o(e) {
                            var t;
                            e.done ? n(e.value) : ((t = e.value) instanceof s ? t : new s(function(e) {
                                e(t)
                            })).then(r, a)
                        }
                        o((u = u.apply(e, i || [])).next())
                    })
                },
                ht = function(n, r) {
                    var a, o, i, s = {
                            label: 0,
                            sent: function() {
                                if (1 & i[0]) throw i[1];
                                return i[1]
                            },
                            trys: [],
                            ops: []
                        },
                        e = {
                            next: t(0),
                            throw: t(1),
                            return: t(2)
                        };
                    return "function" == typeof Symbol && (e[Symbol.iterator] = function() {
                        return this
                    }), e;

                    function t(t) {
                        return function(e) {
                            return function(t) {
                                if (a) throw new TypeError("Generator is already executing.");
                                for (; s;) try {
                                    if (a = 1, o && (i = 2 & t[0] ? o.return : t[0] ? o.throw || ((i = o.return) && i.call(o), 0) : o.next) && !(i = i.call(o, t[1])).done) return i;
                                    switch (o = 0, i && (t = [2 & t[0], i.value]), t[0]) {
                                        case 0:
                                        case 1:
                                            i = t;
                                            break;
                                        case 4:
                                            return s.label++, {
                                                value: t[1],
                                                done: !1
                                            };
                                        case 5:
                                            s.label++, o = t[1], t = [0];
                                            continue;
                                        case 7:
                                            t = s.ops.pop(), s.trys.pop();
                                            continue;
                                        default:
                                            if (!(i = 0 < (i = s.trys).length && i[i.length - 1]) && (6 === t[0] || 2 === t[0])) {
                                                s = 0;
                                                continue
                                            }
                                            if (3 === t[0] && (!i || t[1] > i[0] && t[1] < i[3])) {
                                                s.label = t[1];
                                                break
                                            }
                                            if (6 === t[0] && s.label < i[1]) {
                                                s.label = i[1], i = t;
                                                break
                                            }
                                            if (i && s.label < i[2]) {
                                                s.label = i[2], s.ops.push(t);
                                                break
                                            }
                                            i[2] && s.ops.pop(), s.trys.pop();
                                            continue
                                    }
                                    t = r.call(n, s)
                                } catch (e) {
                                    t = [6, e], o = 0
                                } finally {
                                    a = i = 0
                                }
                                if (5 & t[0]) throw t[1];
                                return {
                                    value: t[0] ? t[1] : void 0,
                                    done: !0
                                }
                            }([t, e])
                        }
                    }
                },
                vt = (Pn = En()).hbaIndexedDBName,
                pt = Pn.hbaIndexedDBObjStoreName,
                ft = Pn.hbaIndexedDBKeyName,
                mt = Pn.isSecureAuthenticationIntentEnabled,
                gt = function(e, i, s, u) {
                    return new(s = s || Promise)(function(n, t) {
                        function r(e) {
                            try {
                                o(u.next(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function a(e) {
                            try {
                                o(u.throw(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function o(e) {
                            var t;
                            e.done ? n(e.value) : ((t = e.value) instanceof s ? t : new s(function(e) {
                                e(t)
                            })).then(r, a)
                        }
                        o((u = u.apply(e, i || [])).next())
                    })
                },
                It = function(n, r) {
                    var a, o, i, s = {
                            label: 0,
                            sent: function() {
                                if (1 & i[0]) throw i[1];
                                return i[1]
                            },
                            trys: [],
                            ops: []
                        },
                        e = {
                            next: t(0),
                            throw: t(1),
                            return: t(2)
                        };
                    return "function" == typeof Symbol && (e[Symbol.iterator] = function() {
                        return this
                    }), e;

                    function t(t) {
                        return function(e) {
                            return function(t) {
                                if (a) throw new TypeError("Generator is already executing.");
                                for (; s;) try {
                                    if (a = 1, o && (i = 2 & t[0] ? o.return : t[0] ? o.throw || ((i = o.return) && i.call(o), 0) : o.next) && !(i = i.call(o, t[1])).done) return i;
                                    switch (o = 0, i && (t = [2 & t[0], i.value]), t[0]) {
                                        case 0:
                                        case 1:
                                            i = t;
                                            break;
                                        case 4:
                                            return s.label++, {
                                                value: t[1],
                                                done: !1
                                            };
                                        case 5:
                                            s.label++, o = t[1], t = [0];
                                            continue;
                                        case 7:
                                            t = s.ops.pop(), s.trys.pop();
                                            continue;
                                        default:
                                            if (!(i = 0 < (i = s.trys).length && i[i.length - 1]) && (6 === t[0] || 2 === t[0])) {
                                                s = 0;
                                                continue
                                            }
                                            if (3 === t[0] && (!i || t[1] > i[0] && t[1] < i[3])) {
                                                s.label = t[1];
                                                break
                                            }
                                            if (6 === t[0] && s.label < i[1]) {
                                                s.label = i[1], i = t;
                                                break
                                            }
                                            if (i && s.label < i[2]) {
                                                s.label = i[2], s.ops.push(t);
                                                break
                                            }
                                            i[2] && s.ops.pop(), s.trys.pop();
                                            continue
                                    }
                                    t = r.call(n, s)
                                } catch (e) {
                                    t = [6, e], o = 0
                                } finally {
                                    a = i = 0
                                }
                                if (5 & t[0]) throw t[1];
                                return {
                                    value: t[0] ? t[1] : void 0,
                                    done: !0
                                }
                            }([t, e])
                        }
                    }
                },
                yt = {
                    name: "ECDSA",
                    namedCurve: "P-256"
                },
                bt = {
                    name: "ECDSA",
                    hash: {
                        name: "SHA-256"
                    }
                },
                Pt = {
                    arrayBufferToBase64String: et,
                    base64StringToArrayBuffer: function(e) {
                        e = atob(e);
                        return Ze(e)
                    },
                    exportPublicKeyAsSpki: function(n) {
                        return gt(void 0, void 0, Promise, function() {
                            var t;
                            return It(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, crypto.subtle.exportKey("spki", n)];
                                    case 1:
                                        return t = e.sent(), [2, et(t)]
                                }
                            })
                        })
                    },
                    generateSigningKeyPairUnextractable: function() {
                        return gt(void 0, void 0, Promise, function() {
                            return It(this, function(e) {
                                return [2, crypto.subtle.generateKey(yt, !1, ["sign"])]
                            })
                        })
                    },
                    hashStringWithSha256: function(n) {
                        return gt(void 0, void 0, Promise, function() {
                            var t;
                            return It(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return t = r(n), [4, crypto.subtle.digest(bt.hash.name, t)];
                                    case 1:
                                        return t = e.sent(), [2, et(t)]
                                }
                            })
                        })
                    },
                    sign: function(n, r) {
                        return gt(void 0, void 0, Promise, function() {
                            var t;
                            return It(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, crypto.subtle.sign(bt, n, Ze(r))];
                                    case 1:
                                        return t = e.sent(), [2, et(t)]
                                }
                            })
                        })
                    },
                    stringToArrayBuffer: Ze,
                    getHbaMeta: En,
                    deleteUserCryptoKeyPairUponLogout: f,
                    generateSecureAuthIntent: R = function() {
                        return dt(void 0, void 0, Promise, function() {
                            var t, n, r, a, o, i;
                            return ht(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        if (!mt || m.DeviceMeta && (0, m.DeviceMeta)().isInApp) return [2, null];
                                        e.label = 1;
                                    case 1:
                                        return e.trys.push([1, 14, , 15]), [4, Ye()];
                                    case 2:
                                        if (!(t = e.sent())) return console.warn("No hba server nonce available."), we({
                                            message: "NonceUnavailable"
                                        }), [2, null];
                                        if (n = {}, !(vt && pt && ft)) return [3, 6];
                                        e.label = 3;
                                    case 3:
                                        return e.trys.push([3, 5, , 6]), [4, d(vt, pt, ft)];
                                    case 4:
                                        return n = e.sent(), [3, 6];
                                    case 5:
                                        return e.sent(), n = {}, [3, 6];
                                    case 6:
                                        return n && 0 !== Object.keys(n).length ? [3, 11] : [4, Pt.generateSigningKeyPairUnextractable()];
                                    case 7:
                                        return n = e.sent(), [4, s()];
                                    case 8:
                                        return e.sent(), [4, $e(n)];
                                    case 9:
                                        return e.sent(), [4, d(vt, pt, ft)];
                                    case 10:
                                        n = e.sent(), e.label = 11;
                                    case 11:
                                        return [4, Pt.exportPublicKeyAsSpki(n.publicKey)];
                                    case 12:
                                        return r = e.sent(), a = Math.floor(Date.now() / 1e3), o = [r, a, t].join("|"), [4, Pt.sign(n.privateKey, o)];
                                    case 13:
                                        return i = e.sent(), i = {
                                            clientPublicKey: r,
                                            clientEpochTimestamp: a,
                                            serverNonce: t,
                                            saiSignature: i
                                        }, Ge(), [2, i];
                                    case 14:
                                        return i = e.sent(), we({
                                            message: Le(i)
                                        }), [2, null];
                                    case 15:
                                        return [2]
                                }
                            })
                        })
                    }
                },
                Gt = Vl(883),
                z = (tt = function(e, t) {
                    return (tt = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function(e, t) {
                            e.__proto__ = t
                        } || function(e, t) {
                            for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
                        })(e, t)
                }, function(e, t) {
                    if ("function" != typeof t && null !== t) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");

                    function n() {
                        this.constructor = e
                    }
                    tt(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                }),
                wt = m.EnvironmentUrls.catalogApi.replace(/\/+$/, ""),
                Ct = ",",
                Z = function(e, t, n) {
                    void 0 === t && (t = wt), void 0 === n && (n = F), this.basePath = t, this.axios = n, e && (this.configuration = e, this.basePath = e.basePath || this.basePath)
                },
                Tt = (nt = Error, z(At, nt), At);

            function At(e, t) {
                t = nt.call(this, t) || this;
                return t.field = e, t.name = "RequiredError", t
            }
            var St, fe = (St = function(e, t) {
                    return (St = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function(e, t) {
                            e.__proto__ = t
                        } || function(e, t) {
                            for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
                        })(e, t)
                }, function(e, t) {
                    if ("function" != typeof t && null !== t) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");

                    function n() {
                        this.constructor = e
                    }
                    St(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                }),
                Rt = function() {
                    return (Rt = Object.assign || function(e) {
                        for (var t, n = 1, r = arguments.length; n < r; n++)
                            for (var a in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
                        return e
                    }).apply(this, arguments)
                },
                Et = function(e, i, s, u) {
                    return new(s = s || Promise)(function(n, t) {
                        function r(e) {
                            try {
                                o(u.next(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function a(e) {
                            try {
                                o(u.throw(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function o(e) {
                            var t;
                            e.done ? n(e.value) : ((t = e.value) instanceof s ? t : new s(function(e) {
                                e(t)
                            })).then(r, a)
                        }
                        o((u = u.apply(e, i || [])).next())
                    })
                },
                Lt = function(n, r) {
                    var a, o, i, s = {
                            label: 0,
                            sent: function() {
                                if (1 & i[0]) throw i[1];
                                return i[1]
                            },
                            trys: [],
                            ops: []
                        },
                        e = {
                            next: t(0),
                            throw: t(1),
                            return: t(2)
                        };
                    return "function" == typeof Symbol && (e[Symbol.iterator] = function() {
                        return this
                    }), e;

                    function t(t) {
                        return function(e) {
                            return function(t) {
                                if (a) throw new TypeError("Generator is already executing.");
                                for (; s;) try {
                                    if (a = 1, o && (i = 2 & t[0] ? o.return : t[0] ? o.throw || ((i = o.return) && i.call(o), 0) : o.next) && !(i = i.call(o, t[1])).done) return i;
                                    switch (o = 0, i && (t = [2 & t[0], i.value]), t[0]) {
                                        case 0:
                                        case 1:
                                            i = t;
                                            break;
                                        case 4:
                                            return s.label++, {
                                                value: t[1],
                                                done: !1
                                            };
                                        case 5:
                                            s.label++, o = t[1], t = [0];
                                            continue;
                                        case 7:
                                            t = s.ops.pop(), s.trys.pop();
                                            continue;
                                        default:
                                            if (!(i = 0 < (i = s.trys).length && i[i.length - 1]) && (6 === t[0] || 2 === t[0])) {
                                                s = 0;
                                                continue
                                            }
                                            if (3 === t[0] && (!i || t[1] > i[0] && t[1] < i[3])) {
                                                s.label = t[1];
                                                break
                                            }
                                            if (6 === t[0] && s.label < i[1]) {
                                                s.label = i[1], i = t;
                                                break
                                            }
                                            if (i && s.label < i[2]) {
                                                s.label = i[2], s.ops.push(t);
                                                break
                                            }
                                            i[2] && s.ops.pop(), s.trys.pop();
                                            continue
                                    }
                                    t = r.call(n, s)
                                } catch (e) {
                                    t = [6, e], o = 0
                                } finally {
                                    a = i = 0
                                }
                                if (5 & t[0]) throw t[1];
                                return {
                                    value: t[0] ? t[1] : void 0,
                                    done: !0
                                }
                            }([t, e])
                        }
                    }
                };

            function Ut(h) {
                var e = this;
                return {
                    v1AssetsAssetIdBundlesGet: function(i, s, u, c, l) {
                        return void 0 === l && (l = {}), Et(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return Lt(this, function(e) {
                                if (null == i) throw new Tt("assetId", "Required parameter assetId was null or undefined when calling v1AssetsAssetIdBundlesGet.");
                                return a = "/v1/assets/{assetId}/bundles".replace("{assetId}", encodeURIComponent(String(i))), t = Gt.Qc(a, !0), h && (o = h.baseOptions), n = Rt(Rt({
                                    method: "GET"
                                }, o), l), r = {}, a = {}, void 0 !== s && (a.sortOrder = s), void 0 !== u && (a.limit = u), void 0 !== c && (a.cursor = c), t.query = Rt(Rt(Rt({}, t.query), a), l.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = Rt(Rt(Rt({}, r), o), l.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1BundlesBundleIdDetailsGet: function(i, s) {
                        return void 0 === s && (s = {}), Et(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return Lt(this, function(e) {
                                if (null == i) throw new Tt("bundleId", "Required parameter bundleId was null or undefined when calling v1BundlesBundleIdDetailsGet.");
                                return a = "/v1/bundles/{bundleId}/details".replace("{bundleId}", encodeURIComponent(String(i))), t = Gt.Qc(a, !0), h && (o = h.baseOptions), n = Rt(Rt({
                                    method: "GET"
                                }, o), s), r = {}, a = {}, t.query = Rt(Rt(Rt({}, t.query), a), s.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = Rt(Rt(Rt({}, r), o), s.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1BundlesBundleIdRecommendationsGet: function(i, s, u) {
                        return void 0 === u && (u = {}), Et(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return Lt(this, function(e) {
                                if (null == i) throw new Tt("bundleId", "Required parameter bundleId was null or undefined when calling v1BundlesBundleIdRecommendationsGet.");
                                return a = "/v1/bundles/{bundleId}/recommendations".replace("{bundleId}", encodeURIComponent(String(i))), t = Gt.Qc(a, !0), h && (o = h.baseOptions), n = Rt(Rt({
                                    method: "GET"
                                }, o), u), r = {}, a = {}, void 0 !== s && (a.numItems = s), t.query = Rt(Rt(Rt({}, t.query), a), u.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = Rt(Rt(Rt({}, r), o), u.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1BundlesBundleIdUnpackPost: function(i, s) {
                        return void 0 === s && (s = {}), Et(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return Lt(this, function(e) {
                                if (null == i) throw new Tt("bundleId", "Required parameter bundleId was null or undefined when calling v1BundlesBundleIdUnpackPost.");
                                return a = "/v1/bundles/{bundleId}/unpack".replace("{bundleId}", encodeURIComponent(String(i))), t = Gt.Qc(a, !0), h && (o = h.baseOptions), n = Rt(Rt({
                                    method: "POST"
                                }, o), s), r = {}, a = {}, t.query = Rt(Rt(Rt({}, t.query), a), s.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = Rt(Rt(Rt({}, r), o), s.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1BundlesDetailsGet: function(i, s) {
                        return void 0 === s && (s = {}), Et(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return Lt(this, function(e) {
                                if (null == i) throw new Tt("bundleIds", "Required parameter bundleIds was null or undefined when calling v1BundlesDetailsGet.");
                                return t = Gt.Qc("/v1/bundles/details", !0), h && (o = h.baseOptions), n = Rt(Rt({
                                    method: "GET"
                                }, o), s), r = {}, a = {}, i && (a.bundleIds = i.join(Ct)), t.query = Rt(Rt(Rt({}, t.query), a), s.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = Rt(Rt(Rt({}, r), o), s.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1UsersUserIdBundlesBundleTypeGet: function(i, s, u, c, l, d) {
                        return void 0 === d && (d = {}), Et(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return Lt(this, function(e) {
                                if (null == i) throw new Tt("userId", "Required parameter userId was null or undefined when calling v1UsersUserIdBundlesBundleTypeGet.");
                                if (null == s) throw new Tt("bundleType", "Required parameter bundleType was null or undefined when calling v1UsersUserIdBundlesBundleTypeGet.");
                                return a = "/v1/users/{userId}/bundles/{bundleType}".replace("{userId}", encodeURIComponent(String(i))).replace("{bundleType}", encodeURIComponent(String(s))), t = Gt.Qc(a, !0), h && (o = h.baseOptions), n = Rt(Rt({
                                    method: "GET"
                                }, o), d), r = {}, a = {}, void 0 !== u && (a.limit = u), void 0 !== c && (a.cursor = c), void 0 !== l && (a.sortOrder = l), t.query = Rt(Rt(Rt({}, t.query), a), d.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = Rt(Rt(Rt({}, r), o), d.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1UsersUserIdBundlesGet: function(i, s, u, c, l) {
                        return void 0 === l && (l = {}), Et(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return Lt(this, function(e) {
                                if (null == i) throw new Tt("userId", "Required parameter userId was null or undefined when calling v1UsersUserIdBundlesGet.");
                                return a = "/v1/users/{userId}/bundles".replace("{userId}", encodeURIComponent(String(i))), t = Gt.Qc(a, !0), h && (o = h.baseOptions), n = Rt(Rt({
                                    method: "GET"
                                }, o), l), r = {}, a = {}, void 0 !== s && (a.sortOrder = s), void 0 !== u && (a.limit = u), void 0 !== c && (a.cursor = c), t.query = Rt(Rt(Rt({}, t.query), a), l.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = Rt(Rt(Rt({}, r), o), l.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    }
                }
            }

            function qt(u) {
                return {
                    v1AssetsAssetIdBundlesGet: function(t, r, a, o, i) {
                        return Et(this, void 0, Promise, function() {
                            var n;
                            return Lt(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, Ut(u).v1AssetsAssetIdBundlesGet(t, r, a, o, i)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = wt);
                                            t = Rt(Rt({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1BundlesBundleIdDetailsGet: function(t, r) {
                        return Et(this, void 0, Promise, function() {
                            var n;
                            return Lt(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, Ut(u).v1BundlesBundleIdDetailsGet(t, r)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = wt);
                                            t = Rt(Rt({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1BundlesBundleIdRecommendationsGet: function(t, r, a) {
                        return Et(this, void 0, Promise, function() {
                            var n;
                            return Lt(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, Ut(u).v1BundlesBundleIdRecommendationsGet(t, r, a)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = wt);
                                            t = Rt(Rt({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1BundlesBundleIdUnpackPost: function(t, r) {
                        return Et(this, void 0, Promise, function() {
                            var n;
                            return Lt(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, Ut(u).v1BundlesBundleIdUnpackPost(t, r)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = wt);
                                            t = Rt(Rt({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1BundlesDetailsGet: function(t, r) {
                        return Et(this, void 0, Promise, function() {
                            var n;
                            return Lt(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, Ut(u).v1BundlesDetailsGet(t, r)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = wt);
                                            t = Rt(Rt({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1UsersUserIdBundlesBundleTypeGet: function(t, r, a, o, i, s) {
                        return Et(this, void 0, Promise, function() {
                            var n;
                            return Lt(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, Ut(u).v1UsersUserIdBundlesBundleTypeGet(t, r, a, o, i, s)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = wt);
                                            t = Rt(Rt({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1UsersUserIdBundlesGet: function(t, r, a, o, i) {
                        return Et(this, void 0, Promise, function() {
                            var n;
                            return Lt(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, Ut(u).v1UsersUserIdBundlesGet(t, r, a, o, i)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = wt);
                                            t = Rt(Rt({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    }
                }
            }(X = {}).Accessories = "Accessories", X.All = "All", X.AvatarAnimations = "AvatarAnimations", X.BackAccessories = "BackAccessories", X.BodyParts = "BodyParts", X.Clothing = "Clothing", X.Collectibles = "Collectibles", X.FaceAccessories = "FaceAccessories", X.Faces = "Faces", X.Featured = "Featured", X.FrontAccessories = "FrontAccessories", X.Gear = "Gear", X.HairAccessories = "HairAccessories", X.Hats = "Hats", X.Heads = "Heads", X.NeckAccessories = "NeckAccessories", X.Pants = "Pants", X.Shirts = "Shirts", X.ShoulderAccessories = "ShoulderAccessories", X.Tshirts = "Tshirts", X.WaistAccessories = "WaistAccessories", X.Bundles = "Bundles", X.AnimationBundles = "AnimationBundles", X.EmoteAnimations = "EmoteAnimations", X.CommunityCreations = "CommunityCreations", X.Melee = "Melee", X.Ranged = "Ranged", X.Explosive = "Explosive", X.PowerUp = "PowerUp", X.Navigation = "Navigation", X.Musical = "Musical", X.Social = "Social", X.Building = "Building", X.Transport = "Transport", X.Premium = "Premium", X.Recommended = "Recommended", (K = {}).Accessories = "Accessories", K.All = "All", K.AvatarAnimations = "AvatarAnimations", K.BodyParts = "BodyParts", K.Clothing = "Clothing", K.Collectibles = "Collectibles", K.Featured = "Featured", K.Gear = "Gear", K.CommunityCreations = "CommunityCreations", K.Premium = "Premium", K.Recommended = "Recommended", (te = {}).Accessories = "Accessories", te.All = "All", te.AvatarAnimations = "AvatarAnimations", te.BodyParts = "BodyParts", te.Clothing = "Clothing", te.Collectibles = "Collectibles", te.Featured = "Featured", te.Gear = "Gear", te.CommunityCreations = "CommunityCreations", te.Premium = "Premium", te.Recommended = "Recommended", (ne = {}).User = "User", ne.Group = "Group", (re = {}).All = "All", re.Robux = "Robux", re.Tickets = "Tickets", re.CustomRobux = "CustomRobux", re.CustomTickets = "CustomTickets", re.Free = "Free", (ae = {}).Relevance = "Relevance", ae.Favorited = "Favorited", ae.Sales = "Sales", ae.Updated = "Updated", ae.PriceAsc = "PriceAsc", ae.PriceDesc = "PriceDesc", (oe = {}).Past12Hours = "Past12Hours", oe.PastDay = "PastDay", oe.Past3Days = "Past3Days", oe.PastWeek = "PastWeek", oe.PastMonth = "PastMonth", oe.AllTime = "AllTime", (ie = {}).Accessories = "Accessories", ie.All = "All", ie.AvatarAnimations = "AvatarAnimations", ie.BodyParts = "BodyParts", ie.Clothing = "Clothing", ie.Collectibles = "Collectibles", ie.Featured = "Featured", ie.Gear = "Gear", ie.CommunityCreations = "CommunityCreations", ie.Premium = "Premium", ie.Recommended = "Recommended", (pe = {}).Accessories = "Accessories", pe.All = "All", pe.AvatarAnimations = "AvatarAnimations", pe.BackAccessories = "BackAccessories", pe.BodyParts = "BodyParts", pe.Clothing = "Clothing", pe.Collectibles = "Collectibles", pe.FaceAccessories = "FaceAccessories", pe.Faces = "Faces", pe.Featured = "Featured", pe.FrontAccessories = "FrontAccessories", pe.Gear = "Gear", pe.HairAccessories = "HairAccessories", pe.Hats = "Hats", pe.Heads = "Heads", pe.NeckAccessories = "NeckAccessories", pe.Pants = "Pants", pe.Shirts = "Shirts", pe.ShoulderAccessories = "ShoulderAccessories", pe.Tshirts = "Tshirts", pe.WaistAccessories = "WaistAccessories", pe.Bundles = "Bundles", pe.AnimationBundles = "AnimationBundles", pe.EmoteAnimations = "EmoteAnimations", pe.CommunityCreations = "CommunityCreations", pe.Melee = "Melee", pe.Ranged = "Ranged", pe.Explosive = "Explosive", pe.PowerUp = "PowerUp", pe.Navigation = "Navigation", pe.Musical = "Musical", pe.Social = "Social", pe.Building = "Building", pe.Transport = "Transport", pe.Premium = "Premium", pe.Recommended = "Recommended", (I = {}).Accessories = "Accessories", I.All = "All", I.AvatarAnimations = "AvatarAnimations", I.BodyParts = "BodyParts", I.Clothing = "Clothing", I.Collectibles = "Collectibles", I.Featured = "Featured", I.Gear = "Gear", I.CommunityCreations = "CommunityCreations", I.Premium = "Premium", I.Recommended = "Recommended", (Wr = {}).All = "All", Wr.Robux = "Robux", Wr.Tickets = "Tickets", Wr.CustomRobux = "CustomRobux", Wr.CustomTickets = "CustomTickets", Wr.Free = "Free", ($r = {}).All = "All", $r.Robux = "Robux", $r.Tickets = "Tickets", $r.CustomRobux = "CustomRobux", $r.CustomTickets = "CustomTickets", $r.Free = "Free", (Pn = {}).All = "All", Pn.Robux = "Robux", Pn.Tickets = "Tickets", Pn.CustomRobux = "CustomRobux", Pn.CustomTickets = "CustomTickets", Pn.Free = "Free", (En = {}).Asset = "Asset", En.Bundle = "Bundle", (f = {}).Image = "Image", f.TShirt = "TShirt", f.Audio = "Audio", f.Mesh = "Mesh", f.Lua = "Lua", f.HTML = "HTML", f.Text = "Text", f.Hat = "Hat", f.Place = "Place", f.Model = "Model", f.Shirt = "Shirt", f.Pants = "Pants", f.Decal = "Decal", f.Avatar = "Avatar", f.Head = "Head", f.Face = "Face", f.Gear = "Gear", f.Badge = "Badge", f.GroupEmblem = "GroupEmblem", f.Animation = "Animation", f.Arms = "Arms", f.Legs = "Legs", f.Torso = "Torso", f.RightArm = "RightArm", f.LeftArm = "LeftArm", f.LeftLeg = "LeftLeg", f.RightLeg = "RightLeg", f.Package = "Package", f.YouTubeVideo = "YouTubeVideo", f.GamePass = "GamePass", f.App = "App", f.Code = "Code", f.Plugin = "Plugin", f.SolidModel = "SolidModel", f.MeshPart = "MeshPart", f.HairAccessory = "HairAccessory", f.FaceAccessory = "FaceAccessory", f.NeckAccessory = "NeckAccessory", f.ShoulderAccessory = "ShoulderAccessory", f.FrontAccessory = "FrontAccessory", f.BackAccessory = "BackAccessory", f.WaistAccessory = "WaistAccessory", f.ClimbAnimation = "ClimbAnimation", f.DeathAnimation = "DeathAnimation", f.FallAnimation = "FallAnimation", f.IdleAnimation = "IdleAnimation", f.JumpAnimation = "JumpAnimation", f.RunAnimation = "RunAnimation", f.SwimAnimation = "SwimAnimation", f.WalkAnimation = "WalkAnimation", f.PoseAnimation = "PoseAnimation", f.LocalizationTableManifest = "LocalizationTableManifest", f.LocalizationTableTranslation = "LocalizationTableTranslation", f.EmoteAnimation = "EmoteAnimation", f.Video = "Video", f.TexturePack = "TexturePack", (R = {}).BodyParts = "BodyParts", R.AvatarAnimations = "AvatarAnimations", (z = {}).All = "All", z.Tutorial = "Tutorial", z.Scary = "Scary", z.TownAndCity = "TownAndCity", z.War = "War", z.Funny = "Funny", z.Fantasy = "Fantasy", z.Adventure = "Adventure", z.SciFi = "SciFi", z.Pirate = "Pirate", z.FPS = "FPS", z.RPG = "RPG", z.Sports = "Sports", z.Ninja = "Ninja", z.WildWest = "WildWest", (X = {}).New = "New", X.Sale = "Sale", X.XboxExclusive = "XboxExclusive", X.AmazonExclusive = "AmazonExclusive", X.GooglePlayExclusive = "GooglePlayExclusive", X.IosExclusive = "IosExclusive", X.SaleTimer = "SaleTimer", (K = {}).ThirteenPlus = "ThirteenPlus", K.LimitedUnique = "LimitedUnique", K.Limited = "Limited", K.BuildersClub = "BuildersClub", K.TurboBuildersClub = "TurboBuildersClub", K.OutrageousBuildersClub = "OutrageousBuildersClub", K.Rthro = "Rthro", (te = {}).User = "User", te.Group = "Group", (ne = {}).Asset = "Asset", ne.Bundle = "Bundle", (re = {}).Image = "Image", re.TShirt = "TShirt", re.Audio = "Audio", re.Mesh = "Mesh", re.Lua = "Lua", re.HTML = "HTML", re.Text = "Text", re.Hat = "Hat", re.Place = "Place", re.Model = "Model", re.Shirt = "Shirt", re.Pants = "Pants", re.Decal = "Decal", re.Avatar = "Avatar", re.Head = "Head", re.Face = "Face", re.Gear = "Gear", re.Badge = "Badge", re.GroupEmblem = "GroupEmblem", re.Animation = "Animation", re.Arms = "Arms", re.Legs = "Legs", re.Torso = "Torso", re.RightArm = "RightArm", re.LeftArm = "LeftArm", re.LeftLeg = "LeftLeg", re.RightLeg = "RightLeg", re.Package = "Package", re.YouTubeVideo = "YouTubeVideo", re.GamePass = "GamePass", re.App = "App", re.Code = "Code", re.Plugin = "Plugin", re.SolidModel = "SolidModel", re.MeshPart = "MeshPart", re.HairAccessory = "HairAccessory", re.FaceAccessory = "FaceAccessory", re.NeckAccessory = "NeckAccessory", re.ShoulderAccessory = "ShoulderAccessory", re.FrontAccessory = "FrontAccessory", re.BackAccessory = "BackAccessory", re.WaistAccessory = "WaistAccessory", re.ClimbAnimation = "ClimbAnimation", re.DeathAnimation = "DeathAnimation", re.FallAnimation = "FallAnimation", re.IdleAnimation = "IdleAnimation", re.JumpAnimation = "JumpAnimation", re.RunAnimation = "RunAnimation", re.SwimAnimation = "SwimAnimation", re.WalkAnimation = "WalkAnimation", re.PoseAnimation = "PoseAnimation", re.LocalizationTableManifest = "LocalizationTableManifest", re.LocalizationTableTranslation = "LocalizationTableTranslation", re.EmoteAnimation = "EmoteAnimation", re.Video = "Video", re.TexturePack = "TexturePack", (ae = {}).BodyParts = "BodyParts", ae.AvatarAnimations = "AvatarAnimations", (oe = {}).All = "All", oe.Tutorial = "Tutorial", oe.Scary = "Scary", oe.TownAndCity = "TownAndCity", oe.War = "War", oe.Funny = "Funny", oe.Fantasy = "Fantasy", oe.Adventure = "Adventure", oe.SciFi = "SciFi", oe.Pirate = "Pirate", oe.FPS = "FPS", oe.RPG = "RPG", oe.Sports = "Sports", oe.Ninja = "Ninja", oe.WildWest = "WildWest", (ie = {}).New = "New", ie.Sale = "Sale", ie.XboxExclusive = "XboxExclusive", ie.AmazonExclusive = "AmazonExclusive", ie.GooglePlayExclusive = "GooglePlayExclusive", ie.IosExclusive = "IosExclusive", ie.SaleTimer = "SaleTimer", (pe = {}).ThirteenPlus = "ThirteenPlus", pe.LimitedUnique = "LimitedUnique", pe.Limited = "Limited", pe.BuildersClub = "BuildersClub", pe.TurboBuildersClub = "TurboBuildersClub", pe.OutrageousBuildersClub = "OutrageousBuildersClub", pe.Rthro = "Rthro", (I = {}).User = "User", I.Group = "Group", (Wr = {}).Accessories = "Accessories", Wr.All = "All", Wr.AvatarAnimations = "AvatarAnimations", Wr.BodyParts = "BodyParts", Wr.Clothing = "Clothing", Wr.Collectibles = "Collectibles", Wr.Featured = "Featured", Wr.Gear = "Gear", Wr.CommunityCreations = "CommunityCreations", Wr.Premium = "Premium", Wr.Recommended = "Recommended", ($r = {}).Accessories = "Accessories", $r.All = "All", $r.AvatarAnimations = "AvatarAnimations", $r.BackAccessories = "BackAccessories", $r.BodyParts = "BodyParts", $r.Clothing = "Clothing", $r.Collectibles = "Collectibles", $r.FaceAccessories = "FaceAccessories", $r.Faces = "Faces", $r.Featured = "Featured", $r.FrontAccessories = "FrontAccessories", $r.Gear = "Gear", $r.HairAccessories = "HairAccessories", $r.Hats = "Hats", $r.Heads = "Heads", $r.NeckAccessories = "NeckAccessories", $r.Pants = "Pants", $r.Shirts = "Shirts", $r.ShoulderAccessories = "ShoulderAccessories", $r.Tshirts = "Tshirts", $r.WaistAccessories = "WaistAccessories", $r.Bundles = "Bundles", $r.AnimationBundles = "AnimationBundles", $r.EmoteAnimations = "EmoteAnimations", $r.CommunityCreations = "CommunityCreations", $r.Melee = "Melee", $r.Ranged = "Ranged", $r.Explosive = "Explosive", $r.PowerUp = "PowerUp", $r.Navigation = "Navigation", $r.Musical = "Musical", $r.Social = "Social", $r.Building = "Building", $r.Transport = "Transport", $r.Premium = "Premium", $r.Recommended = "Recommended", (Pn = {}).Past12Hours = "Past12Hours", Pn.PastDay = "PastDay", Pn.Past3Days = "Past3Days", Pn.PastWeek = "PastWeek", Pn.PastMonth = "PastMonth", Pn.AllTime = "AllTime", (En = {}).All = "All", En.Robux = "Robux", En.Tickets = "Tickets", En.CustomRobux = "CustomRobux", En.CustomTickets = "CustomTickets", En.Free = "Free", (f = {}).TownAndCity = "TownAndCity", f.Medieval = "Medieval", f.SciFi = "SciFi", f.Fighting = "Fighting", f.Horror = "Horror", f.Naval = "Naval", f.Adventure = "Adventure", f.Sports = "Sports", f.Comedy = "Comedy", f.Western = "Western", f.Military = "Military", f.Building = "Building", f.Fps = "Fps", f.Rpg = "Rpg", (R = {}).Relevance = "Relevance", R.Favorited = "Favorited", R.Sales = "Sales", R.Updated = "Updated", R.PriceAsc = "PriceAsc", R.PriceDesc = "PriceDesc", (z = {}).User = "User", z.Group = "Group", (X = {}).Asset = "Asset", X.Bundle = "Bundle", (K = {}).Accessories = "Accessories", K.All = "All", K.AvatarAnimations = "AvatarAnimations", K.BodyParts = "BodyParts", K.Clothing = "Clothing", K.Collectibles = "Collectibles", K.Featured = "Featured", K.Gear = "Gear", K.CommunityCreations = "CommunityCreations", K.Premium = "Premium", K.Recommended = "Recommended", (te = {}).TownAndCity = "TownAndCity", te.Medieval = "Medieval", te.SciFi = "SciFi", te.Fighting = "Fighting", te.Horror = "Horror", te.Naval = "Naval", te.Adventure = "Adventure", te.Sports = "Sports", te.Comedy = "Comedy", te.Western = "Western", te.Military = "Military", te.Building = "Building", te.Fps = "Fps", te.Rpg = "Rpg", (ne = {}).Asset = "Asset", ne.Bundle = "Bundle", (re = {}).All = "All", re.Robux = "Robux", re.Tickets = "Tickets", re.CustomRobux = "CustomRobux", re.CustomTickets = "CustomTickets", re.Free = "Free", (ae = {}).Past12Hours = "Past12Hours", ae.PastDay = "PastDay", ae.Past3Days = "Past3Days", ae.PastWeek = "PastWeek", ae.PastMonth = "PastMonth", ae.AllTime = "AllTime", (oe = {}).Relevance = "Relevance", oe.Favorited = "Favorited", oe.Sales = "Sales", oe.Updated = "Updated", oe.PriceAsc = "PriceAsc", oe.PriceDesc = "PriceDesc", (ie = {}).Asc = "Asc", ie.Desc = "Desc", (pe = {}).Accessories = "Accessories", pe.All = "All", pe.AvatarAnimations = "AvatarAnimations", pe.BackAccessories = "BackAccessories", pe.BodyParts = "BodyParts", pe.Clothing = "Clothing", pe.Collectibles = "Collectibles", pe.FaceAccessories = "FaceAccessories", pe.Faces = "Faces", pe.Featured = "Featured", pe.FrontAccessories = "FrontAccessories", pe.Gear = "Gear", pe.HairAccessories = "HairAccessories", pe.Hats = "Hats", pe.Heads = "Heads", pe.NeckAccessories = "NeckAccessories", pe.Pants = "Pants", pe.Shirts = "Shirts", pe.ShoulderAccessories = "ShoulderAccessories", pe.Tshirts = "Tshirts", pe.WaistAccessories = "WaistAccessories", pe.Bundles = "Bundles", pe.AnimationBundles = "AnimationBundles", pe.EmoteAnimations = "EmoteAnimations", pe.CommunityCreations = "CommunityCreations", pe.Melee = "Melee", pe.Ranged = "Ranged", pe.Explosive = "Explosive", pe.PowerUp = "PowerUp", pe.Navigation = "Navigation", pe.Musical = "Musical", pe.Social = "Social", pe.Building = "Building", pe.Transport = "Transport", pe.Premium = "Premium", pe.Recommended = "Recommended", (I = {}).Asc = "Asc", I.Desc = "Desc", (Wr = {}).Forward = "Forward", Wr.Backward = "Backward", ($r = {}).Asc = "Asc", $r.Desc = "Desc", (Pn = {}).Forward = "Forward", Pn.Backward = "Backward", (En = {}).Asc = "Asc", En.Desc = "Desc", (f = {}).Forward = "Forward", f.Backward = "Backward", (R = {}).Asc = "Asc", R.Desc = "Desc", (z = {}).Forward = "Forward", z.Backward = "Backward";
            var Ot, X = (fe(Dt, Ot = Z), Dt.prototype.v1AssetsAssetIdBundlesGet = function(e, t, n, r, a) {
                var o = this;
                return qt(this.configuration).v1AssetsAssetIdBundlesGet(e, t, n, r, a).then(function(e) {
                    return e(o.axios, o.basePath)
                })
            }, Dt.prototype.v1BundlesBundleIdDetailsGet = function(e, t) {
                var n = this;
                return qt(this.configuration).v1BundlesBundleIdDetailsGet(e, t).then(function(e) {
                    return e(n.axios, n.basePath)
                })
            }, Dt.prototype.v1BundlesBundleIdRecommendationsGet = function(e, t, n) {
                var r = this;
                return qt(this.configuration).v1BundlesBundleIdRecommendationsGet(e, t, n).then(function(e) {
                    return e(r.axios, r.basePath)
                })
            }, Dt.prototype.v1BundlesBundleIdUnpackPost = function(e, t) {
                var n = this;
                return qt(this.configuration).v1BundlesBundleIdUnpackPost(e, t).then(function(e) {
                    return e(n.axios, n.basePath)
                })
            }, Dt.prototype.v1BundlesDetailsGet = function(e, t) {
                var n = this;
                return qt(this.configuration).v1BundlesDetailsGet(e, t).then(function(e) {
                    return e(n.axios, n.basePath)
                })
            }, Dt.prototype.v1UsersUserIdBundlesBundleTypeGet = function(e, t, n, r, a, o) {
                var i = this;
                return qt(this.configuration).v1UsersUserIdBundlesBundleTypeGet(e, t, n, r, a, o).then(function(e) {
                    return e(i.axios, i.basePath)
                })
            }, Dt.prototype.v1UsersUserIdBundlesGet = function(e, t, n, r, a) {
                var o = this;
                return qt(this.configuration).v1UsersUserIdBundlesGet(e, t, n, r, a).then(function(e) {
                    return e(o.axios, o.basePath)
                })
            }, Dt);

            function Dt() {
                return null !== Ot && Ot.apply(this, arguments) || this
            }

            function xt(c) {
                var e = this;
                return {
                    v1CatalogItemsDetailsPost: function(i, s) {
                        return void 0 === s && (s = {}), Et(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return Lt(this, function(e) {
                                if (null == i) throw new Tt("model", "Required parameter model was null or undefined when calling v1CatalogItemsDetailsPost.");
                                return t = Gt.Qc("/v1/catalog/items/details", !0), c && (o = c.baseOptions), n = Rt(Rt({
                                    method: "POST"
                                }, o), s), a = {}, (r = {})["Content-Type"] = "application/json", t.query = Rt(Rt(Rt({}, t.query), a), s.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = Rt(Rt(Rt({}, r), o), s.headers), o = "string" != typeof i || "application/json" === n.headers["Content-Type"], n.data = o ? JSON.stringify(void 0 !== i ? i : {}) : i || "", [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1CatalogItemsItemIdDetailsGet: function(i, s, u) {
                        return void 0 === u && (u = {}), Et(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return Lt(this, function(e) {
                                if (null == i) throw new Tt("itemId", "Required parameter itemId was null or undefined when calling v1CatalogItemsItemIdDetailsGet.");
                                if (null == s) throw new Tt("itemType", "Required parameter itemType was null or undefined when calling v1CatalogItemsItemIdDetailsGet.");
                                return a = "/v1/catalog/items/{itemId}/details".replace("{itemId}", encodeURIComponent(String(i))), t = Gt.Qc(a, !0), c && (o = c.baseOptions), n = Rt(Rt({
                                    method: "GET"
                                }, o), u), r = {}, a = {}, void 0 !== s && (a.itemType = s), t.query = Rt(Rt(Rt({}, t.query), a), u.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = Rt(Rt(Rt({}, r), o), u.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1CatalogMetadataGet: function(i) {
                        return void 0 === i && (i = {}), Et(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return Lt(this, function(e) {
                                return t = Gt.Qc("/v1/catalog/metadata", !0), c && (o = c.baseOptions), n = Rt(Rt({
                                    method: "GET"
                                }, o), i), r = {}, a = {}, t.query = Rt(Rt(Rt({}, t.query), a), i.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = Rt(Rt(Rt({}, r), o), i.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1CatalogSortsGet: function(i) {
                        return void 0 === i && (i = {}), Et(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return Lt(this, function(e) {
                                return t = Gt.Qc("/v1/catalog/sorts", !0), c && (o = c.baseOptions), n = Rt(Rt({
                                    method: "GET"
                                }, o), i), r = {}, a = {}, t.query = Rt(Rt(Rt({}, t.query), a), i.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = Rt(Rt(Rt({}, r), o), i.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    }
                }
            }

            function _t(o) {
                return {
                    v1CatalogItemsDetailsPost: function(t, r) {
                        return Et(this, void 0, Promise, function() {
                            var n;
                            return Lt(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, xt(o).v1CatalogItemsDetailsPost(t, r)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = wt);
                                            t = Rt(Rt({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1CatalogItemsItemIdDetailsGet: function(t, r, a) {
                        return Et(this, void 0, Promise, function() {
                            var n;
                            return Lt(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, xt(o).v1CatalogItemsItemIdDetailsGet(t, r, a)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = wt);
                                            t = Rt(Rt({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1CatalogMetadataGet: function(t) {
                        return Et(this, void 0, Promise, function() {
                            var n;
                            return Lt(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, xt(o).v1CatalogMetadataGet(t)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = wt);
                                            t = Rt(Rt({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1CatalogSortsGet: function(t) {
                        return Et(this, void 0, Promise, function() {
                            var n;
                            return Lt(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, xt(o).v1CatalogSortsGet(t)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = wt);
                                            t = Rt(Rt({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    }
                }
            }
            var Bt, Ft, Nt, kt, K = (fe(Mt, Bt = Z), Mt.prototype.v1CatalogItemsDetailsPost = function(e, t) {
                var n = this;
                return _t(this.configuration).v1CatalogItemsDetailsPost(e, t).then(function(e) {
                    return e(n.axios, n.basePath)
                })
            }, Mt.prototype.v1CatalogItemsItemIdDetailsGet = function(e, t, n) {
                var r = this;
                return _t(this.configuration).v1CatalogItemsItemIdDetailsGet(e, t, n).then(function(e) {
                    return e(r.axios, r.basePath)
                })
            }, Mt.prototype.v1CatalogMetadataGet = function(e) {
                var t = this;
                return _t(this.configuration).v1CatalogMetadataGet(e).then(function(e) {
                    return e(t.axios, t.basePath)
                })
            }, Mt.prototype.v1CatalogSortsGet = function(e) {
                var t = this;
                return _t(this.configuration).v1CatalogSortsGet(e).then(function(e) {
                    return e(t.axios, t.basePath)
                })
            }, Mt);

            function Mt() {
                return null !== Bt && Bt.apply(this, arguments) || this
            }

            function jt(s) {
                var e = this;
                return {
                    v1AssetToCategoryGet: function(i) {
                        return void 0 === i && (i = {}), Et(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return Lt(this, function(e) {
                                return t = Gt.Qc("/v1/asset-to-category", !0), s && (o = s.baseOptions), n = Rt(Rt({
                                    method: "GET"
                                }, o), i), r = {}, a = {}, t.query = Rt(Rt(Rt({}, t.query), a), i.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = Rt(Rt(Rt({}, r), o), i.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1AssetToSubcategoryGet: function(i) {
                        return void 0 === i && (i = {}), Et(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return Lt(this, function(e) {
                                return t = Gt.Qc("/v1/asset-to-subcategory", !0), s && (o = s.baseOptions), n = Rt(Rt({
                                    method: "GET"
                                }, o), i), r = {}, a = {}, t.query = Rt(Rt(Rt({}, t.query), a), i.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = Rt(Rt(Rt({}, r), o), i.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1CategoriesGet: function(i) {
                        return void 0 === i && (i = {}), Et(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return Lt(this, function(e) {
                                return t = Gt.Qc("/v1/categories", !0), s && (o = s.baseOptions), n = Rt(Rt({
                                    method: "GET"
                                }, o), i), r = {}, a = {}, t.query = Rt(Rt(Rt({}, t.query), a), i.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = Rt(Rt(Rt({}, r), o), i.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1SubcategoriesGet: function(i) {
                        return void 0 === i && (i = {}), Et(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return Lt(this, function(e) {
                                return t = Gt.Qc("/v1/subcategories", !0), s && (o = s.baseOptions), n = Rt(Rt({
                                    method: "GET"
                                }, o), i), r = {}, a = {}, t.query = Rt(Rt(Rt({}, t.query), a), i.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = Rt(Rt(Rt({}, r), o), i.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    }
                }
            }

            function zt(r) {
                return {
                    v1AssetToCategoryGet: function(t) {
                        return Et(this, void 0, Promise, function() {
                            var n;
                            return Lt(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, jt(r).v1AssetToCategoryGet(t)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = wt);
                                            t = Rt(Rt({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1AssetToSubcategoryGet: function(t) {
                        return Et(this, void 0, Promise, function() {
                            var n;
                            return Lt(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, jt(r).v1AssetToSubcategoryGet(t)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = wt);
                                            t = Rt(Rt({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1CategoriesGet: function(t) {
                        return Et(this, void 0, Promise, function() {
                            var n;
                            return Lt(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, jt(r).v1CategoriesGet(t)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = wt);
                                            t = Rt(Rt({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1SubcategoriesGet: function(t) {
                        return Et(this, void 0, Promise, function() {
                            var n;
                            return Lt(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, jt(r).v1SubcategoriesGet(t)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = wt);
                                            t = Rt(Rt({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    }
                }
            }

            function Wt() {
                return null !== Ft && Ft.apply(this, arguments) || this
            }

            function Vt(a) {
                return {
                    v1ExclusiveItemsAppStoreTypeBundlesGet: function(t, r) {
                        return Et(this, void 0, Promise, function() {
                            var n;
                            return Lt(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, function(u) {
                                            var e = this;
                                            return {
                                                v1ExclusiveItemsAppStoreTypeBundlesGet: function(i, s) {
                                                    return void 0 === s && (s = {}), Et(e, void 0, Promise, function() {
                                                        var t, n, r, a, o;
                                                        return Lt(this, function(e) {
                                                            if (null == i) throw new Tt("appStoreType", "Required parameter appStoreType was null or undefined when calling v1ExclusiveItemsAppStoreTypeBundlesGet.");
                                                            return a = "/v1/exclusive-items/{appStoreType}/bundles".replace("{appStoreType}", encodeURIComponent(String(i))), t = Gt.Qc(a, !0), u && (o = u.baseOptions), n = Rt(Rt({
                                                                method: "GET"
                                                            }, o), s), r = {}, a = {}, t.query = Rt(Rt(Rt({}, t.query), a), s.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = Rt(Rt(Rt({}, r), o), s.headers), [2, {
                                                                url: Gt.WU(t),
                                                                options: n
                                                            }]
                                                        })
                                                    })
                                                }
                                            }
                                        }(a).v1ExclusiveItemsAppStoreTypeBundlesGet(t, r)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = wt);
                                            t = Rt(Rt({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    }
                }
            }

            function Ht() {
                return null !== Nt && Nt.apply(this, arguments) || this
            }

            function Qt(c) {
                var e = this;
                return {
                    v1FavoritesAssetsAssetIdCountGet: function(i, s) {
                        return void 0 === s && (s = {}), Et(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return Lt(this, function(e) {
                                if (null == i) throw new Tt("assetId", "Required parameter assetId was null or undefined when calling v1FavoritesAssetsAssetIdCountGet.");
                                return a = "/v1/favorites/assets/{assetId}/count".replace("{assetId}", encodeURIComponent(String(i))), t = Gt.Qc(a, !0), c && (o = c.baseOptions), n = Rt(Rt({
                                    method: "GET"
                                }, o), s), r = {}, a = {}, t.query = Rt(Rt(Rt({}, t.query), a), s.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = Rt(Rt(Rt({}, r), o), s.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1FavoritesBundlesBundleIdCountGet: function(i, s) {
                        return void 0 === s && (s = {}), Et(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return Lt(this, function(e) {
                                if (null == i) throw new Tt("bundleId", "Required parameter bundleId was null or undefined when calling v1FavoritesBundlesBundleIdCountGet.");
                                return a = "/v1/favorites/bundles/{bundleId}/count".replace("{bundleId}", encodeURIComponent(String(i))), t = Gt.Qc(a, !0), c && (o = c.baseOptions), n = Rt(Rt({
                                    method: "GET"
                                }, o), s), r = {}, a = {}, t.query = Rt(Rt(Rt({}, t.query), a), s.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = Rt(Rt(Rt({}, r), o), s.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1FavoritesUsersUserIdAssetsAssetIdFavoriteDelete: function(i, s, u) {
                        return void 0 === u && (u = {}), Et(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return Lt(this, function(e) {
                                if (null == i) throw new Tt("userId", "Required parameter userId was null or undefined when calling v1FavoritesUsersUserIdAssetsAssetIdFavoriteDelete.");
                                if (null == s) throw new Tt("assetId", "Required parameter assetId was null or undefined when calling v1FavoritesUsersUserIdAssetsAssetIdFavoriteDelete.");
                                return a = "/v1/favorites/users/{userId}/assets/{assetId}/favorite".replace("{userId}", encodeURIComponent(String(i))).replace("{assetId}", encodeURIComponent(String(s))), t = Gt.Qc(a, !0), c && (o = c.baseOptions), n = Rt(Rt({
                                    method: "DELETE"
                                }, o), u), r = {}, a = {}, t.query = Rt(Rt(Rt({}, t.query), a), u.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = Rt(Rt(Rt({}, r), o), u.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1FavoritesUsersUserIdAssetsAssetIdFavoriteGet: function(i, s, u) {
                        return void 0 === u && (u = {}), Et(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return Lt(this, function(e) {
                                if (null == i) throw new Tt("userId", "Required parameter userId was null or undefined when calling v1FavoritesUsersUserIdAssetsAssetIdFavoriteGet.");
                                if (null == s) throw new Tt("assetId", "Required parameter assetId was null or undefined when calling v1FavoritesUsersUserIdAssetsAssetIdFavoriteGet.");
                                return a = "/v1/favorites/users/{userId}/assets/{assetId}/favorite".replace("{userId}", encodeURIComponent(String(i))).replace("{assetId}", encodeURIComponent(String(s))), t = Gt.Qc(a, !0), c && (o = c.baseOptions), n = Rt(Rt({
                                    method: "GET"
                                }, o), u), r = {}, a = {}, t.query = Rt(Rt(Rt({}, t.query), a), u.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = Rt(Rt(Rt({}, r), o), u.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1FavoritesUsersUserIdAssetsAssetIdFavoritePost: function(i, s, u) {
                        return void 0 === u && (u = {}), Et(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return Lt(this, function(e) {
                                if (null == i) throw new Tt("userId", "Required parameter userId was null or undefined when calling v1FavoritesUsersUserIdAssetsAssetIdFavoritePost.");
                                if (null == s) throw new Tt("assetId", "Required parameter assetId was null or undefined when calling v1FavoritesUsersUserIdAssetsAssetIdFavoritePost.");
                                return a = "/v1/favorites/users/{userId}/assets/{assetId}/favorite".replace("{userId}", encodeURIComponent(String(i))).replace("{assetId}", encodeURIComponent(String(s))), t = Gt.Qc(a, !0), c && (o = c.baseOptions), n = Rt(Rt({
                                    method: "POST"
                                }, o), u), r = {}, a = {}, t.query = Rt(Rt(Rt({}, t.query), a), u.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = Rt(Rt(Rt({}, r), o), u.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1FavoritesUsersUserIdBundlesBundleIdFavoriteDelete: function(i, s, u) {
                        return void 0 === u && (u = {}), Et(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return Lt(this, function(e) {
                                if (null == i) throw new Tt("userId", "Required parameter userId was null or undefined when calling v1FavoritesUsersUserIdBundlesBundleIdFavoriteDelete.");
                                if (null == s) throw new Tt("bundleId", "Required parameter bundleId was null or undefined when calling v1FavoritesUsersUserIdBundlesBundleIdFavoriteDelete.");
                                return a = "/v1/favorites/users/{userId}/bundles/{bundleId}/favorite".replace("{userId}", encodeURIComponent(String(i))).replace("{bundleId}", encodeURIComponent(String(s))), t = Gt.Qc(a, !0), c && (o = c.baseOptions), n = Rt(Rt({
                                    method: "DELETE"
                                }, o), u), r = {}, a = {}, t.query = Rt(Rt(Rt({}, t.query), a), u.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = Rt(Rt(Rt({}, r), o), u.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1FavoritesUsersUserIdBundlesBundleIdFavoriteGet: function(i, s, u) {
                        return void 0 === u && (u = {}), Et(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return Lt(this, function(e) {
                                if (null == i) throw new Tt("userId", "Required parameter userId was null or undefined when calling v1FavoritesUsersUserIdBundlesBundleIdFavoriteGet.");
                                if (null == s) throw new Tt("bundleId", "Required parameter bundleId was null or undefined when calling v1FavoritesUsersUserIdBundlesBundleIdFavoriteGet.");
                                return a = "/v1/favorites/users/{userId}/bundles/{bundleId}/favorite".replace("{userId}", encodeURIComponent(String(i))).replace("{bundleId}", encodeURIComponent(String(s))), t = Gt.Qc(a, !0), c && (o = c.baseOptions), n = Rt(Rt({
                                    method: "GET"
                                }, o), u), r = {}, a = {}, t.query = Rt(Rt(Rt({}, t.query), a), u.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = Rt(Rt(Rt({}, r), o), u.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1FavoritesUsersUserIdBundlesBundleIdFavoritePost: function(i, s, u) {
                        return void 0 === u && (u = {}), Et(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return Lt(this, function(e) {
                                if (null == i) throw new Tt("userId", "Required parameter userId was null or undefined when calling v1FavoritesUsersUserIdBundlesBundleIdFavoritePost.");
                                if (null == s) throw new Tt("bundleId", "Required parameter bundleId was null or undefined when calling v1FavoritesUsersUserIdBundlesBundleIdFavoritePost.");
                                return a = "/v1/favorites/users/{userId}/bundles/{bundleId}/favorite".replace("{userId}", encodeURIComponent(String(i))).replace("{bundleId}", encodeURIComponent(String(s))), t = Gt.Qc(a, !0), c && (o = c.baseOptions), n = Rt(Rt({
                                    method: "POST"
                                }, o), u), r = {}, a = {}, t.query = Rt(Rt(Rt({}, t.query), a), u.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = Rt(Rt(Rt({}, r), o), u.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    }
                }
            }

            function Kt(o) {
                return {
                    v1FavoritesAssetsAssetIdCountGet: function(t, r) {
                        return Et(this, void 0, Promise, function() {
                            var n;
                            return Lt(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, Qt(o).v1FavoritesAssetsAssetIdCountGet(t, r)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = wt);
                                            t = Rt(Rt({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1FavoritesBundlesBundleIdCountGet: function(t, r) {
                        return Et(this, void 0, Promise, function() {
                            var n;
                            return Lt(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, Qt(o).v1FavoritesBundlesBundleIdCountGet(t, r)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = wt);
                                            t = Rt(Rt({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1FavoritesUsersUserIdAssetsAssetIdFavoriteDelete: function(t, r, a) {
                        return Et(this, void 0, Promise, function() {
                            var n;
                            return Lt(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, Qt(o).v1FavoritesUsersUserIdAssetsAssetIdFavoriteDelete(t, r, a)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = wt);
                                            t = Rt(Rt({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1FavoritesUsersUserIdAssetsAssetIdFavoriteGet: function(t, r, a) {
                        return Et(this, void 0, Promise, function() {
                            var n;
                            return Lt(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, Qt(o).v1FavoritesUsersUserIdAssetsAssetIdFavoriteGet(t, r, a)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = wt);
                                            t = Rt(Rt({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1FavoritesUsersUserIdAssetsAssetIdFavoritePost: function(t, r, a) {
                        return Et(this, void 0, Promise, function() {
                            var n;
                            return Lt(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, Qt(o).v1FavoritesUsersUserIdAssetsAssetIdFavoritePost(t, r, a)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = wt);
                                            t = Rt(Rt({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1FavoritesUsersUserIdBundlesBundleIdFavoriteDelete: function(t, r, a) {
                        return Et(this, void 0, Promise, function() {
                            var n;
                            return Lt(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, Qt(o).v1FavoritesUsersUserIdBundlesBundleIdFavoriteDelete(t, r, a)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = wt);
                                            t = Rt(Rt({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1FavoritesUsersUserIdBundlesBundleIdFavoriteGet: function(t, r, a) {
                        return Et(this, void 0, Promise, function() {
                            var n;
                            return Lt(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, Qt(o).v1FavoritesUsersUserIdBundlesBundleIdFavoriteGet(t, r, a)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = wt);
                                            t = Rt(Rt({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1FavoritesUsersUserIdBundlesBundleIdFavoritePost: function(t, r, a) {
                        return Et(this, void 0, Promise, function() {
                            var n;
                            return Lt(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, Qt(o).v1FavoritesUsersUserIdBundlesBundleIdFavoritePost(t, r, a)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = wt);
                                            t = Rt(Rt({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    }
                }
            }

            function Xt() {
                return null !== kt && kt.apply(this, arguments) || this
            }

            function Jt(l) {
                var e = this;
                return {
                    v1RecommendationsAssetAssetTypeIdGet: function(i, s, u, c) {
                        return void 0 === c && (c = {}), Et(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return Lt(this, function(e) {
                                if (null == i) throw new Tt("assetTypeId", "Required parameter assetTypeId was null or undefined when calling v1RecommendationsAssetAssetTypeIdGet.");
                                return a = "/v1/recommendations/asset/{assetTypeId}".replace("{assetTypeId}", encodeURIComponent(String(i))), t = Gt.Qc(a, !0), l && (o = l.baseOptions), n = Rt(Rt({
                                    method: "GET"
                                }, o), c), r = {}, a = {}, void 0 !== s && (a.numItems = s), void 0 !== u && (a.contextAssetId = u), t.query = Rt(Rt(Rt({}, t.query), a), c.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = Rt(Rt(Rt({}, r), o), c.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1RecommendationsMetadataGet: function(i, s) {
                        return void 0 === s && (s = {}), Et(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return Lt(this, function(e) {
                                return t = Gt.Qc("/v1/recommendations/metadata", !0), l && (o = l.baseOptions), n = Rt(Rt({
                                    method: "GET"
                                }, o), s), r = {}, a = {}, void 0 !== i && (a.page = i), t.query = Rt(Rt(Rt({}, t.query), a), s.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = Rt(Rt(Rt({}, r), o), s.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    }
                }
            }

            function Yt(i) {
                return {
                    v1RecommendationsAssetAssetTypeIdGet: function(t, r, a, o) {
                        return Et(this, void 0, Promise, function() {
                            var n;
                            return Lt(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, Jt(i).v1RecommendationsAssetAssetTypeIdGet(t, r, a, o)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = wt);
                                            t = Rt(Rt({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1RecommendationsMetadataGet: function(t, r) {
                        return Et(this, void 0, Promise, function() {
                            var n;
                            return Lt(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, Jt(i).v1RecommendationsMetadataGet(t, r)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = wt);
                                            t = Rt(Rt({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    }
                }
            }
            fe(Wt, Ft = Z), Wt.prototype.v1AssetToCategoryGet = function(e) {
                var t = this;
                return zt(this.configuration).v1AssetToCategoryGet(e).then(function(e) {
                    return e(t.axios, t.basePath)
                })
            }, Wt.prototype.v1AssetToSubcategoryGet = function(e) {
                var t = this;
                return zt(this.configuration).v1AssetToSubcategoryGet(e).then(function(e) {
                    return e(t.axios, t.basePath)
                })
            }, Wt.prototype.v1CategoriesGet = function(e) {
                var t = this;
                return zt(this.configuration).v1CategoriesGet(e).then(function(e) {
                    return e(t.axios, t.basePath)
                })
            }, Wt.prototype.v1SubcategoriesGet = function(e) {
                var t = this;
                return zt(this.configuration).v1SubcategoriesGet(e).then(function(e) {
                    return e(t.axios, t.basePath)
                })
            }, fe(Ht, Nt = Z), Ht.prototype.v1ExclusiveItemsAppStoreTypeBundlesGet = function(e, t) {
                var n = this;
                return Vt(this.configuration).v1ExclusiveItemsAppStoreTypeBundlesGet(e, t).then(function(e) {
                    return e(n.axios, n.basePath)
                })
            }, fe(Xt, kt = Z), Xt.prototype.v1FavoritesAssetsAssetIdCountGet = function(e, t) {
                var n = this;
                return Kt(this.configuration).v1FavoritesAssetsAssetIdCountGet(e, t).then(function(e) {
                    return e(n.axios, n.basePath)
                })
            }, Xt.prototype.v1FavoritesBundlesBundleIdCountGet = function(e, t) {
                var n = this;
                return Kt(this.configuration).v1FavoritesBundlesBundleIdCountGet(e, t).then(function(e) {
                    return e(n.axios, n.basePath)
                })
            }, Xt.prototype.v1FavoritesUsersUserIdAssetsAssetIdFavoriteDelete = function(e, t, n) {
                var r = this;
                return Kt(this.configuration).v1FavoritesUsersUserIdAssetsAssetIdFavoriteDelete(e, t, n).then(function(e) {
                    return e(r.axios, r.basePath)
                })
            }, Xt.prototype.v1FavoritesUsersUserIdAssetsAssetIdFavoriteGet = function(e, t, n) {
                var r = this;
                return Kt(this.configuration).v1FavoritesUsersUserIdAssetsAssetIdFavoriteGet(e, t, n).then(function(e) {
                    return e(r.axios, r.basePath)
                })
            }, Xt.prototype.v1FavoritesUsersUserIdAssetsAssetIdFavoritePost = function(e, t, n) {
                var r = this;
                return Kt(this.configuration).v1FavoritesUsersUserIdAssetsAssetIdFavoritePost(e, t, n).then(function(e) {
                    return e(r.axios, r.basePath)
                })
            }, Xt.prototype.v1FavoritesUsersUserIdBundlesBundleIdFavoriteDelete = function(e, t, n) {
                var r = this;
                return Kt(this.configuration).v1FavoritesUsersUserIdBundlesBundleIdFavoriteDelete(e, t, n).then(function(e) {
                    return e(r.axios, r.basePath)
                })
            }, Xt.prototype.v1FavoritesUsersUserIdBundlesBundleIdFavoriteGet = function(e, t, n) {
                var r = this;
                return Kt(this.configuration).v1FavoritesUsersUserIdBundlesBundleIdFavoriteGet(e, t, n).then(function(e) {
                    return e(r.axios, r.basePath)
                })
            }, Xt.prototype.v1FavoritesUsersUserIdBundlesBundleIdFavoritePost = function(e, t, n) {
                var r = this;
                return Kt(this.configuration).v1FavoritesUsersUserIdBundlesBundleIdFavoritePost(e, t, n).then(function(e) {
                    return e(r.axios, r.basePath)
                })
            };
            var $t, Zt, te = (fe(en, $t = Z), en.prototype.v1RecommendationsAssetAssetTypeIdGet = function(e, t, n, r) {
                var a = this;
                return Yt(this.configuration).v1RecommendationsAssetAssetTypeIdGet(e, t, n, r).then(function(e) {
                    return e(a.axios, a.basePath)
                })
            }, en.prototype.v1RecommendationsMetadataGet = function(e, t) {
                var n = this;
                return Yt(this.configuration).v1RecommendationsMetadataGet(e, t).then(function(e) {
                    return e(n.axios, n.basePath)
                })
            }, en);

            function en() {
                return null !== $t && $t.apply(this, arguments) || this
            }

            function tn(C) {
                var e = this;
                return {
                    v1SearchItemsDetailsGet: function(i, s, u, c, l, d, h, v, p, f, m, g, I, y, b, P, G, w) {
                        return void 0 === w && (w = {}), Et(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return Lt(this, function(e) {
                                return t = Gt.Qc("/v1/search/items/details", !0), C && (o = C.baseOptions), n = Rt(Rt({
                                    method: "GET"
                                }, o), w), r = {}, a = {}, void 0 !== i && (a["model.category"] = i), void 0 !== s && (a["model.subcategory"] = s), void 0 !== u && (a["model.sortAggregation"] = u), void 0 !== c && (a["model.sortCurrency"] = c), l && (a["model.genres"] = l), void 0 !== d && (a["model.sortType"] = d), void 0 !== h && (a["model.creatorType"] = h), void 0 !== v && (a["model.creatorTargetId"] = v), void 0 !== p && (a["model.creatorName"] = p), void 0 !== f && (a["model.maxPrice"] = f), void 0 !== m && (a["model.minPrice"] = m), void 0 !== g && (a["model.keyword"] = g), void 0 !== I && (a["model.includeNotForSale"] = I), y && (a["model.tagNames"] = y), void 0 !== b && (a.sortOrder = b), void 0 !== P && (a.limit = P), void 0 !== G && (a.cursor = G), t.query = Rt(Rt(Rt({}, t.query), a), w.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = Rt(Rt(Rt({}, r), o), w.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1SearchItemsGet: function(i, s, u, c, l, d, h, v, p, f, m, g, I, y, b, P, G, w) {
                        return void 0 === w && (w = {}), Et(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return Lt(this, function(e) {
                                return t = Gt.Qc("/v1/search/items", !0), C && (o = C.baseOptions), n = Rt(Rt({
                                    method: "GET"
                                }, o), w), r = {}, a = {}, void 0 !== i && (a["model.category"] = i), void 0 !== s && (a["model.subcategory"] = s), void 0 !== u && (a["model.sortAggregation"] = u), void 0 !== c && (a["model.sortCurrency"] = c), l && (a["model.genres"] = l), void 0 !== d && (a["model.sortType"] = d), void 0 !== h && (a["model.creatorType"] = h), void 0 !== v && (a["model.creatorTargetId"] = v), void 0 !== p && (a["model.creatorName"] = p), void 0 !== f && (a["model.maxPrice"] = f), void 0 !== m && (a["model.minPrice"] = m), void 0 !== g && (a["model.keyword"] = g), void 0 !== I && (a["model.includeNotForSale"] = I), y && (a["model.tagNames"] = y), void 0 !== b && (a.sortOrder = b), void 0 !== P && (a.limit = P), void 0 !== G && (a.cursor = G), t.query = Rt(Rt(Rt({}, t.query), a), w.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = Rt(Rt(Rt({}, r), o), w.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1SearchNavigationMenuItemsGet: function(i) {
                        return void 0 === i && (i = {}), Et(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return Lt(this, function(e) {
                                return t = Gt.Qc("/v1/search/navigation-menu-items", !0), C && (o = C.baseOptions), n = Rt(Rt({
                                    method: "GET"
                                }, o), i), r = {}, a = {}, t.query = Rt(Rt(Rt({}, t.query), a), i.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = Rt(Rt(Rt({}, r), o), i.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    }
                }
            }

            function nn(b) {
                return {
                    v1SearchItemsDetailsGet: function(t, r, a, o, i, s, u, c, l, d, h, v, p, f, m, g, I, y) {
                        return Et(this, void 0, Promise, function() {
                            var n;
                            return Lt(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, tn(b).v1SearchItemsDetailsGet(t, r, a, o, i, s, u, c, l, d, h, v, p, f, m, g, I, y)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = wt);
                                            t = Rt(Rt({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1SearchItemsGet: function(t, r, a, o, i, s, u, c, l, d, h, v, p, f, m, g, I, y) {
                        return Et(this, void 0, Promise, function() {
                            var n;
                            return Lt(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, tn(b).v1SearchItemsGet(t, r, a, o, i, s, u, c, l, d, h, v, p, f, m, g, I, y)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = wt);
                                            t = Rt(Rt({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1SearchNavigationMenuItemsGet: function(t) {
                        return Et(this, void 0, Promise, function() {
                            var n;
                            return Lt(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, tn(b).v1SearchNavigationMenuItemsGet(t)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = wt);
                                            t = Rt(Rt({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    }
                }
            }

            function rn() {
                return null !== Zt && Zt.apply(this, arguments) || this
            }
            fe(rn, Zt = Z), rn.prototype.v1SearchItemsDetailsGet = function(e, t, n, r, a, o, i, s, u, c, l, d, h, v, p, f, m, g) {
                var I = this;
                return nn(this.configuration).v1SearchItemsDetailsGet(e, t, n, r, a, o, i, s, u, c, l, d, h, v, p, f, m, g).then(function(e) {
                    return e(I.axios, I.basePath)
                })
            }, rn.prototype.v1SearchItemsGet = function(e, t, n, r, a, o, i, s, u, c, l, d, h, v, p, f, m, g) {
                var I = this;
                return nn(this.configuration).v1SearchItemsGet(e, t, n, r, a, o, i, s, u, c, l, d, h, v, p, f, m, g).then(function(e) {
                    return e(I.axios, I.basePath)
                })
            }, rn.prototype.v1SearchNavigationMenuItemsGet = function(e) {
                var t = this;
                return nn(this.configuration).v1SearchNavigationMenuItemsGet(e).then(function(e) {
                    return e(t.axios, t.basePath)
                })
            };
            var an, on, sn = new X,
                un = new K,
                cn = new te,
                ne = {
                    getAssetRecommendations: function(e, t, n) {
                        return cn.v1RecommendationsAssetAssetTypeIdGet(e, t, n)
                    },
                    getBundleRecommendations: function(e, t) {
                        return sn.v1BundlesBundleIdRecommendationsGet(e, t, {
                            withCredentials: !0
                        })
                    },
                    postItemDetails: function(e) {
                        return un.v1CatalogItemsDetailsPost(e, {
                            withCredentials: !0
                        })
                    }
                },
                re = (an = function(e, t) {
                    return (an = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function(e, t) {
                            e.__proto__ = t
                        } || function(e, t) {
                            for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
                        })(e, t)
                }, function(e, t) {
                    if ("function" != typeof t && null !== t) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");

                    function n() {
                        this.constructor = e
                    }
                    an(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                }),
                ln = m.EnvironmentUrls.gameInternationalizationApi.replace(/\/+$/, ""),
                ae = function(e, t, n) {
                    void 0 === t && (t = ln), void 0 === n && (n = F), this.basePath = t, this.axios = n, e && (this.configuration = e, this.basePath = e.basePath || this.basePath)
                },
                dn = (on = Error, re(hn, on), hn);

            function hn(e, t) {
                t = on.call(this, t) || this;
                return t.field = e, t.name = "RequiredError", t
            }
            var vn, pn, oe = (vn = function(e, t) {
                    return (vn = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function(e, t) {
                            e.__proto__ = t
                        } || function(e, t) {
                            for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
                        })(e, t)
                }, function(e, t) {
                    if ("function" != typeof t && null !== t) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");

                    function n() {
                        this.constructor = e
                    }
                    vn(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                }),
                fn = function() {
                    return (fn = Object.assign || function(e) {
                        for (var t, n = 1, r = arguments.length; n < r; n++)
                            for (var a in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
                        return e
                    }).apply(this, arguments)
                },
                mn = function(e, i, s, u) {
                    return new(s = s || Promise)(function(n, t) {
                        function r(e) {
                            try {
                                o(u.next(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function a(e) {
                            try {
                                o(u.throw(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function o(e) {
                            var t;
                            e.done ? n(e.value) : ((t = e.value) instanceof s ? t : new s(function(e) {
                                e(t)
                            })).then(r, a)
                        }
                        o((u = u.apply(e, i || [])).next())
                    })
                },
                gn = function(n, r) {
                    var a, o, i, s = {
                            label: 0,
                            sent: function() {
                                if (1 & i[0]) throw i[1];
                                return i[1]
                            },
                            trys: [],
                            ops: []
                        },
                        e = {
                            next: t(0),
                            throw: t(1),
                            return: t(2)
                        };
                    return "function" == typeof Symbol && (e[Symbol.iterator] = function() {
                        return this
                    }), e;

                    function t(t) {
                        return function(e) {
                            return function(t) {
                                if (a) throw new TypeError("Generator is already executing.");
                                for (; s;) try {
                                    if (a = 1, o && (i = 2 & t[0] ? o.return : t[0] ? o.throw || ((i = o.return) && i.call(o), 0) : o.next) && !(i = i.call(o, t[1])).done) return i;
                                    switch (o = 0, i && (t = [2 & t[0], i.value]), t[0]) {
                                        case 0:
                                        case 1:
                                            i = t;
                                            break;
                                        case 4:
                                            return s.label++, {
                                                value: t[1],
                                                done: !1
                                            };
                                        case 5:
                                            s.label++, o = t[1], t = [0];
                                            continue;
                                        case 7:
                                            t = s.ops.pop(), s.trys.pop();
                                            continue;
                                        default:
                                            if (!(i = 0 < (i = s.trys).length && i[i.length - 1]) && (6 === t[0] || 2 === t[0])) {
                                                s = 0;
                                                continue
                                            }
                                            if (3 === t[0] && (!i || t[1] > i[0] && t[1] < i[3])) {
                                                s.label = t[1];
                                                break
                                            }
                                            if (6 === t[0] && s.label < i[1]) {
                                                s.label = i[1], i = t;
                                                break
                                            }
                                            if (i && s.label < i[2]) {
                                                s.label = i[2], s.ops.push(t);
                                                break
                                            }
                                            i[2] && s.ops.pop(), s.trys.pop();
                                            continue
                                    }
                                    t = r.call(n, s)
                                } catch (e) {
                                    t = [6, e], o = 0
                                } finally {
                                    a = i = 0
                                }
                                if (5 & t[0]) throw t[1];
                                return {
                                    value: t[0] ? t[1] : void 0,
                                    done: !0
                                }
                            }([t, e])
                        }
                    }
                };

            function In(c) {
                var e = this;
                return {
                    v1AutolocalizationGamesGameIdAutolocalizationtablePatch: function(i, s, u) {
                        return void 0 === u && (u = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                if (null == i) throw new dn("gameId", "Required parameter gameId was null or undefined when calling v1AutolocalizationGamesGameIdAutolocalizationtablePatch.");
                                if (null == s) throw new dn("request", "Required parameter request was null or undefined when calling v1AutolocalizationGamesGameIdAutolocalizationtablePatch.");
                                return r = "/v1/autolocalization/games/{gameId}/autolocalizationtable".replace("{gameId}", encodeURIComponent(String(i))), t = Gt.Qc(r, !0), c && (o = c.baseOptions), n = fn(fn({
                                    method: "PATCH"
                                }, o), u), a = {}, (r = {})["Content-Type"] = "application/json", t.query = fn(fn(fn({}, t.query), a), u.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), u.headers), o = "string" != typeof s || "application/json" === n.headers["Content-Type"], n.data = o ? JSON.stringify(void 0 !== s ? s : {}) : s || "", [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1AutolocalizationGamesGameIdAutolocalizationtablePost: function(i, s) {
                        return void 0 === s && (s = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                if (null == i) throw new dn("gameId", "Required parameter gameId was null or undefined when calling v1AutolocalizationGamesGameIdAutolocalizationtablePost.");
                                return a = "/v1/autolocalization/games/{gameId}/autolocalizationtable".replace("{gameId}", encodeURIComponent(String(i))), t = Gt.Qc(a, !0), c && (o = c.baseOptions), n = fn(fn({
                                    method: "POST"
                                }, o), s), r = {}, a = {}, t.query = fn(fn(fn({}, t.query), a), s.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), s.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1AutolocalizationGamesGameIdAutoscrapeCleanupRequestPost: function(i, s, u) {
                        return void 0 === u && (u = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                if (null == i) throw new dn("gameId", "Required parameter gameId was null or undefined when calling v1AutolocalizationGamesGameIdAutoscrapeCleanupRequestPost.");
                                if (null == s) throw new dn("request", "Required parameter request was null or undefined when calling v1AutolocalizationGamesGameIdAutoscrapeCleanupRequestPost.");
                                return r = "/v1/autolocalization/games/{gameId}/autoscrape-cleanup-request".replace("{gameId}", encodeURIComponent(String(i))), t = Gt.Qc(r, !0), c && (o = c.baseOptions), n = fn(fn({
                                    method: "POST"
                                }, o), u), a = {}, (r = {})["Content-Type"] = "application/json", t.query = fn(fn(fn({}, t.query), a), u.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), u.headers), o = "string" != typeof s || "application/json" === n.headers["Content-Type"], n.data = o ? JSON.stringify(void 0 !== s ? s : {}) : s || "", [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1AutolocalizationGamesGameIdGet: function(i, s) {
                        return void 0 === s && (s = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                if (null == i) throw new dn("gameId", "Required parameter gameId was null or undefined when calling v1AutolocalizationGamesGameIdGet.");
                                return a = "/v1/autolocalization/games/{gameId}".replace("{gameId}", encodeURIComponent(String(i))), t = Gt.Qc(a, !0), c && (o = c.baseOptions), n = fn(fn({
                                    method: "GET"
                                }, o), s), r = {}, a = {}, t.query = fn(fn(fn({}, t.query), a), s.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), s.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1AutolocalizationGamesGameIdPatch: function(i, s, u) {
                        return void 0 === u && (u = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                if (null == i) throw new dn("gameId", "Required parameter gameId was null or undefined when calling v1AutolocalizationGamesGameIdPatch.");
                                if (null == s) throw new dn("request", "Required parameter request was null or undefined when calling v1AutolocalizationGamesGameIdPatch.");
                                return r = "/v1/autolocalization/games/{gameId}".replace("{gameId}", encodeURIComponent(String(i))), t = Gt.Qc(r, !0), c && (o = c.baseOptions), n = fn(fn({
                                    method: "PATCH"
                                }, o), u), a = {}, (r = {})["Content-Type"] = "application/json", t.query = fn(fn(fn({}, t.query), a), u.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), u.headers), o = "string" != typeof s || "application/json" === n.headers["Content-Type"], n.data = o ? JSON.stringify(void 0 !== s ? s : {}) : s || "", [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1AutolocalizationGamesGameIdSettingsPatch: function(i, s, u) {
                        return void 0 === u && (u = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                if (null == i) throw new dn("gameId", "Required parameter gameId was null or undefined when calling v1AutolocalizationGamesGameIdSettingsPatch.");
                                if (null == s) throw new dn("request", "Required parameter request was null or undefined when calling v1AutolocalizationGamesGameIdSettingsPatch.");
                                return r = "/v1/autolocalization/games/{gameId}/settings".replace("{gameId}", encodeURIComponent(String(i))), t = Gt.Qc(r, !0), c && (o = c.baseOptions), n = fn(fn({
                                    method: "PATCH"
                                }, o), u), a = {}, (r = {})["Content-Type"] = "application/json", t.query = fn(fn(fn({}, t.query), a), u.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), u.headers), o = "string" != typeof s || "application/json" === n.headers["Content-Type"], n.data = o ? JSON.stringify(void 0 !== s ? s : {}) : s || "", [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1AutolocalizationMetadataGet: function(i) {
                        return void 0 === i && (i = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                return t = Gt.Qc("/v1/autolocalization/metadata", !0), c && (o = c.baseOptions), n = fn(fn({
                                    method: "GET"
                                }, o), i), r = {}, a = {}, t.query = fn(fn(fn({}, t.query), a), i.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), i.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    }
                }
            }

            function yn(o) {
                return {
                    v1AutolocalizationGamesGameIdAutolocalizationtablePatch: function(t, r, a) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, In(o).v1AutolocalizationGamesGameIdAutolocalizationtablePatch(t, r, a)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1AutolocalizationGamesGameIdAutolocalizationtablePost: function(t, r) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, In(o).v1AutolocalizationGamesGameIdAutolocalizationtablePost(t, r)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1AutolocalizationGamesGameIdAutoscrapeCleanupRequestPost: function(t, r, a) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, In(o).v1AutolocalizationGamesGameIdAutoscrapeCleanupRequestPost(t, r, a)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1AutolocalizationGamesGameIdGet: function(t, r) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, In(o).v1AutolocalizationGamesGameIdGet(t, r)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1AutolocalizationGamesGameIdPatch: function(t, r, a) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, In(o).v1AutolocalizationGamesGameIdPatch(t, r, a)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1AutolocalizationGamesGameIdSettingsPatch: function(t, r, a) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, In(o).v1AutolocalizationGamesGameIdSettingsPatch(t, r, a)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1AutolocalizationMetadataGet: function(t) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, In(o).v1AutolocalizationMetadataGet(t)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    }
                }
            }(ie = {}).User = "User", ie.Group = "Group", (pe = {}).Asc = "Asc", pe.Desc = "Desc", (I = {}).Approved = "Approved", I.PendingReview = "PendingReview", I.UnAvailable = "UnAvailable", I.Rejected = "Rejected", I.Error = "Error", (Wr = {}).Approved = "Approved", Wr.PendingReview = "PendingReview", Wr.UnAvailable = "UnAvailable", Wr.Rejected = "Rejected", Wr.Error = "Error", ($r = {}).Approved = "Approved", $r.PendingReview = "PendingReview", $r.UnAvailable = "UnAvailable", $r.Rejected = "Rejected", $r.Error = "Error", (Pn = {}).Approved = "Approved", Pn.PendingReview = "PendingReview", Pn.UnAvailable = "UnAvailable", Pn.Rejected = "Rejected", Pn.Error = "Error", (En = {}).Name = "Name", En.Description = "Description", (f = {}).Asc = "Asc", f.Desc = "Desc", (R = {}).User = "User", R.Group = "Group", (z = {}).Language = "Language", z.Locale = "Locale", (fe = {}).Language = "Language", fe.Locale = "Locale", (Z = {}).Language = "Language", Z.Locale = "Locale", (X = {}).Approved = "Approved", X.PendingReview = "PendingReview", X.UnAvailable = "UnAvailable", X.Rejected = "Rejected", X.Error = "Error", (K = pn = pn || {}).Language = "Language", K.Locale = "Locale", (te = {}).GameTranslationStatus = "GameTranslationStatus", te.GameTranslationStatusForTranslatorGroup = "GameTranslationStatusForTranslatorGroup", te.GameTranslationStatusForTranslator = "GameTranslationStatusForTranslator", te.Test = "Test", (re = {}).InProgress = "inProgress", re.Ready = "ready", re.Unavailable = "unavailable", (ie = {}).Automation = "Automation", ie.User = "User", (pe = {}).LanguageOrLocaleSupportedForGame = "LanguageOrLocaleSupportedForGame", pe.LanguageOrLocaleNotSupportedForGame = "LanguageOrLocaleNotSupportedForGame", pe.LanguageOrLocaleIsSource = "LanguageOrLocaleIsSource", pe.InsufficientPermission = "InsufficientPermission", pe.GameDoesNotExist = "GameDoesNotExist", pe.GameDoesNotHaveTable = "GameDoesNotHaveTable", pe.UnknownError = "UnknownError", (I = {}).Success = "Success", I.LanguageOrLocaleNotSupportedForGame = "LanguageOrLocaleNotSupportedForGame", (Wr = {}).Language = "Language", Wr.Locale = "Locale", ($r = {}).User = "User", $r.Automation = "Automation";
            var bn, Pn = (oe(Gn, bn = ae), Gn.prototype.v1AutolocalizationGamesGameIdAutolocalizationtablePatch = function(e, t, n) {
                var r = this;
                return yn(this.configuration).v1AutolocalizationGamesGameIdAutolocalizationtablePatch(e, t, n).then(function(e) {
                    return e(r.axios, r.basePath)
                })
            }, Gn.prototype.v1AutolocalizationGamesGameIdAutolocalizationtablePost = function(e, t) {
                var n = this;
                return yn(this.configuration).v1AutolocalizationGamesGameIdAutolocalizationtablePost(e, t).then(function(e) {
                    return e(n.axios, n.basePath)
                })
            }, Gn.prototype.v1AutolocalizationGamesGameIdAutoscrapeCleanupRequestPost = function(e, t, n) {
                var r = this;
                return yn(this.configuration).v1AutolocalizationGamesGameIdAutoscrapeCleanupRequestPost(e, t, n).then(function(e) {
                    return e(r.axios, r.basePath)
                })
            }, Gn.prototype.v1AutolocalizationGamesGameIdGet = function(e, t) {
                var n = this;
                return yn(this.configuration).v1AutolocalizationGamesGameIdGet(e, t).then(function(e) {
                    return e(n.axios, n.basePath)
                })
            }, Gn.prototype.v1AutolocalizationGamesGameIdPatch = function(e, t, n) {
                var r = this;
                return yn(this.configuration).v1AutolocalizationGamesGameIdPatch(e, t, n).then(function(e) {
                    return e(r.axios, r.basePath)
                })
            }, Gn.prototype.v1AutolocalizationGamesGameIdSettingsPatch = function(e, t, n) {
                var r = this;
                return yn(this.configuration).v1AutolocalizationGamesGameIdSettingsPatch(e, t, n).then(function(e) {
                    return e(r.axios, r.basePath)
                })
            }, Gn.prototype.v1AutolocalizationMetadataGet = function(e) {
                var t = this;
                return yn(this.configuration).v1AutolocalizationMetadataGet(e).then(function(e) {
                    return e(t.axios, t.basePath)
                })
            }, Gn);

            function Gn() {
                return null !== bn && bn.apply(this, arguments) || this
            }

            function wn(c) {
                var e = this;
                return {
                    v1AutomaticTranslationGamesGameIdFeatureStatusGet: function(i, s) {
                        return void 0 === s && (s = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                if (null == i) throw new dn("gameId", "Required parameter gameId was null or undefined when calling v1AutomaticTranslationGamesGameIdFeatureStatusGet.");
                                return a = "/v1/automatic-translation/games/{gameId}/feature-status".replace("{gameId}", encodeURIComponent(String(i))), t = Gt.Qc(a, !0), c && (o = c.baseOptions), n = fn(fn({
                                    method: "GET"
                                }, o), s), r = {}, a = {}, t.query = fn(fn(fn({}, t.query), a), s.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), s.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1AutomaticTranslationGamesGameIdQuotaGet: function(i, s) {
                        return void 0 === s && (s = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                if (null == i) throw new dn("gameId", "Required parameter gameId was null or undefined when calling v1AutomaticTranslationGamesGameIdQuotaGet.");
                                return a = "/v1/automatic-translation/games/{gameId}/quota".replace("{gameId}", encodeURIComponent(String(i))), t = Gt.Qc(a, !0), c && (o = c.baseOptions), n = fn(fn({
                                    method: "GET"
                                }, o), s), r = {}, a = {}, t.query = fn(fn(fn({}, t.query), a), s.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), s.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1AutomaticTranslationLanguagesLanguageCodeTargetLanguagesGet: function(i, s, u) {
                        return void 0 === u && (u = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                if (null == i) throw new dn("languageCode", "Required parameter languageCode was null or undefined when calling v1AutomaticTranslationLanguagesLanguageCodeTargetLanguagesGet.");
                                return a = "/v1/automatic-translation/languages/{languageCode}/target-languages".replace("{languageCode}", encodeURIComponent(String(i))), t = Gt.Qc(a, !0), c && (o = c.baseOptions), n = fn(fn({
                                    method: "GET"
                                }, o), u), r = {}, a = {}, s && (a.targetLanguages = s), t.query = fn(fn(fn({}, t.query), a), u.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), u.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    }
                }
            }

            function Cn(o) {
                return {
                    v1AutomaticTranslationGamesGameIdFeatureStatusGet: function(t, r) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, wn(o).v1AutomaticTranslationGamesGameIdFeatureStatusGet(t, r)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1AutomaticTranslationGamesGameIdQuotaGet: function(t, r) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, wn(o).v1AutomaticTranslationGamesGameIdQuotaGet(t, r)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1AutomaticTranslationLanguagesLanguageCodeTargetLanguagesGet: function(t, r, a) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, wn(o).v1AutomaticTranslationLanguagesLanguageCodeTargetLanguagesGet(t, r, a)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    }
                }
            }
            var Tn, An, Sn, Rn, En = (oe(Ln, Tn = ae), Ln.prototype.v1AutomaticTranslationGamesGameIdFeatureStatusGet = function(e, t) {
                var n = this;
                return Cn(this.configuration).v1AutomaticTranslationGamesGameIdFeatureStatusGet(e, t).then(function(e) {
                    return e(n.axios, n.basePath)
                })
            }, Ln.prototype.v1AutomaticTranslationGamesGameIdQuotaGet = function(e, t) {
                var n = this;
                return Cn(this.configuration).v1AutomaticTranslationGamesGameIdQuotaGet(e, t).then(function(e) {
                    return e(n.axios, n.basePath)
                })
            }, Ln.prototype.v1AutomaticTranslationLanguagesLanguageCodeTargetLanguagesGet = function(e, t, n) {
                var r = this;
                return Cn(this.configuration).v1AutomaticTranslationLanguagesLanguageCodeTargetLanguagesGet(e, t, n).then(function(e) {
                    return e(r.axios, r.basePath)
                })
            }, Ln);

            function Ln() {
                return null !== Tn && Tn.apply(this, arguments) || this
            }

            function Un(d) {
                var e = this;
                return {
                    v1BadgesBadgeIdDescriptionLanguageCodesLanguageCodePatch: function(i, s, u, c) {
                        return void 0 === c && (c = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                if (null == i) throw new dn("badgeId", "Required parameter badgeId was null or undefined when calling v1BadgesBadgeIdDescriptionLanguageCodesLanguageCodePatch.");
                                if (null == s) throw new dn("languageCode", "Required parameter languageCode was null or undefined when calling v1BadgesBadgeIdDescriptionLanguageCodesLanguageCodePatch.");
                                if (null == u) throw new dn("request", "Required parameter request was null or undefined when calling v1BadgesBadgeIdDescriptionLanguageCodesLanguageCodePatch.");
                                return r = "/v1/badges/{badgeId}/description/language-codes/{languageCode}".replace("{badgeId}", encodeURIComponent(String(i))).replace("{languageCode}", encodeURIComponent(String(s))), t = Gt.Qc(r, !0), d && (o = d.baseOptions), n = fn(fn({
                                    method: "PATCH"
                                }, o), c), a = {}, (r = {})["Content-Type"] = "application/json", t.query = fn(fn(fn({}, t.query), a), c.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), c.headers), o = "string" != typeof u || "application/json" === n.headers["Content-Type"], n.data = o ? JSON.stringify(void 0 !== u ? u : {}) : u || "", [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1BadgesBadgeIdIconsGet: function(i, s, u, c) {
                        return void 0 === c && (c = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                if (null == i) throw new dn("badgeId", "Required parameter badgeId was null or undefined when calling v1BadgesBadgeIdIconsGet.");
                                return a = "/v1/badges/{badgeId}/icons".replace("{badgeId}", encodeURIComponent(String(i))), t = Gt.Qc(a, !0), d && (o = d.baseOptions), n = fn(fn({
                                    method: "GET"
                                }, o), c), r = {}, a = {}, void 0 !== s && (a.width = s), void 0 !== u && (a.height = u), t.query = fn(fn(fn({}, t.query), a), c.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), c.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1BadgesBadgeIdIconsLanguageCodesLanguageCodeDelete: function(i, s, u) {
                        return void 0 === u && (u = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                if (null == i) throw new dn("badgeId", "Required parameter badgeId was null or undefined when calling v1BadgesBadgeIdIconsLanguageCodesLanguageCodeDelete.");
                                if (null == s) throw new dn("languageCode", "Required parameter languageCode was null or undefined when calling v1BadgesBadgeIdIconsLanguageCodesLanguageCodeDelete.");
                                return a = "/v1/badges/{badgeId}/icons/language-codes/{languageCode}".replace("{badgeId}", encodeURIComponent(String(i))).replace("{languageCode}", encodeURIComponent(String(s))), t = Gt.Qc(a, !0), d && (o = d.baseOptions), n = fn(fn({
                                    method: "DELETE"
                                }, o), u), r = {}, a = {}, t.query = fn(fn(fn({}, t.query), a), u.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), u.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1BadgesBadgeIdIconsLanguageCodesLanguageCodePost: function(s, u, c, l) {
                        return void 0 === l && (l = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o, i;
                            return gn(this, function(e) {
                                if (null == s) throw new dn("badgeId", "Required parameter badgeId was null or undefined when calling v1BadgesBadgeIdIconsLanguageCodesLanguageCodePost.");
                                if (null == u) throw new dn("languageCode", "Required parameter languageCode was null or undefined when calling v1BadgesBadgeIdIconsLanguageCodesLanguageCodePost.");
                                return o = "/v1/badges/{badgeId}/icons/language-codes/{languageCode}".replace("{badgeId}", encodeURIComponent(String(s))).replace("{languageCode}", encodeURIComponent(String(u))), t = Gt.Qc(o, !0), d && (i = d.baseOptions), n = fn(fn({
                                    method: "POST"
                                }, i), l), r = {}, a = {}, o = new FormData, void 0 !== c && o.append("request.files", c), r["Content-Type"] = "multipart/form-data", t.query = fn(fn(fn({}, t.query), a), l.query), delete t.search, i = i && i.headers ? i.headers : {}, n.headers = fn(fn(fn({}, r), i), l.headers), n.data = o, [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1BadgesBadgeIdNameDescriptionGet: function(i, s) {
                        return void 0 === s && (s = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                if (null == i) throw new dn("badgeId", "Required parameter badgeId was null or undefined when calling v1BadgesBadgeIdNameDescriptionGet.");
                                return a = "/v1/badges/{badgeId}/name-description".replace("{badgeId}", encodeURIComponent(String(i))), t = Gt.Qc(a, !0), d && (o = d.baseOptions), n = fn(fn({
                                    method: "GET"
                                }, o), s), r = {}, a = {}, t.query = fn(fn(fn({}, t.query), a), s.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), s.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1BadgesBadgeIdNameDescriptionLanguageCodesLanguageCodeDelete: function(i, s, u) {
                        return void 0 === u && (u = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                if (null == i) throw new dn("badgeId", "Required parameter badgeId was null or undefined when calling v1BadgesBadgeIdNameDescriptionLanguageCodesLanguageCodeDelete.");
                                if (null == s) throw new dn("languageCode", "Required parameter languageCode was null or undefined when calling v1BadgesBadgeIdNameDescriptionLanguageCodesLanguageCodeDelete.");
                                return a = "/v1/badges/{badgeId}/name-description/language-codes/{languageCode}".replace("{badgeId}", encodeURIComponent(String(i))).replace("{languageCode}", encodeURIComponent(String(s))), t = Gt.Qc(a, !0), d && (o = d.baseOptions), n = fn(fn({
                                    method: "DELETE"
                                }, o), u), r = {}, a = {}, t.query = fn(fn(fn({}, t.query), a), u.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), u.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1BadgesBadgeIdNameDescriptionLanguageCodesLanguageCodePatch: function(i, s, u, c) {
                        return void 0 === c && (c = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                if (null == i) throw new dn("badgeId", "Required parameter badgeId was null or undefined when calling v1BadgesBadgeIdNameDescriptionLanguageCodesLanguageCodePatch.");
                                if (null == s) throw new dn("languageCode", "Required parameter languageCode was null or undefined when calling v1BadgesBadgeIdNameDescriptionLanguageCodesLanguageCodePatch.");
                                if (null == u) throw new dn("request", "Required parameter request was null or undefined when calling v1BadgesBadgeIdNameDescriptionLanguageCodesLanguageCodePatch.");
                                return r = "/v1/badges/{badgeId}/name-description/language-codes/{languageCode}".replace("{badgeId}", encodeURIComponent(String(i))).replace("{languageCode}", encodeURIComponent(String(s))), t = Gt.Qc(r, !0), d && (o = d.baseOptions), n = fn(fn({
                                    method: "PATCH"
                                }, o), c), a = {}, (r = {})["Content-Type"] = "application/json", t.query = fn(fn(fn({}, t.query), a), c.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), c.headers), o = "string" != typeof u || "application/json" === n.headers["Content-Type"], n.data = o ? JSON.stringify(void 0 !== u ? u : {}) : u || "", [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1BadgesBadgeIdNameLanguageCodesLanguageCodePatch: function(i, s, u, c) {
                        return void 0 === c && (c = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                if (null == i) throw new dn("badgeId", "Required parameter badgeId was null or undefined when calling v1BadgesBadgeIdNameLanguageCodesLanguageCodePatch.");
                                if (null == s) throw new dn("languageCode", "Required parameter languageCode was null or undefined when calling v1BadgesBadgeIdNameLanguageCodesLanguageCodePatch.");
                                if (null == u) throw new dn("request", "Required parameter request was null or undefined when calling v1BadgesBadgeIdNameLanguageCodesLanguageCodePatch.");
                                return r = "/v1/badges/{badgeId}/name/language-codes/{languageCode}".replace("{badgeId}", encodeURIComponent(String(i))).replace("{languageCode}", encodeURIComponent(String(s))), t = Gt.Qc(r, !0), d && (o = d.baseOptions), n = fn(fn({
                                    method: "PATCH"
                                }, o), c), a = {}, (r = {})["Content-Type"] = "application/json", t.query = fn(fn(fn({}, t.query), a), c.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), c.headers), o = "string" != typeof u || "application/json" === n.headers["Content-Type"], n.data = o ? JSON.stringify(void 0 !== u ? u : {}) : u || "", [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    }
                }
            }

            function qn(i) {
                return {
                    v1BadgesBadgeIdDescriptionLanguageCodesLanguageCodePatch: function(t, r, a, o) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, Un(i).v1BadgesBadgeIdDescriptionLanguageCodesLanguageCodePatch(t, r, a, o)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1BadgesBadgeIdIconsGet: function(t, r, a, o) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, Un(i).v1BadgesBadgeIdIconsGet(t, r, a, o)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1BadgesBadgeIdIconsLanguageCodesLanguageCodeDelete: function(t, r, a) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, Un(i).v1BadgesBadgeIdIconsLanguageCodesLanguageCodeDelete(t, r, a)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1BadgesBadgeIdIconsLanguageCodesLanguageCodePost: function(t, r, a, o) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, Un(i).v1BadgesBadgeIdIconsLanguageCodesLanguageCodePost(t, r, a, o)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1BadgesBadgeIdNameDescriptionGet: function(t, r) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, Un(i).v1BadgesBadgeIdNameDescriptionGet(t, r)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1BadgesBadgeIdNameDescriptionLanguageCodesLanguageCodeDelete: function(t, r, a) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, Un(i).v1BadgesBadgeIdNameDescriptionLanguageCodesLanguageCodeDelete(t, r, a)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1BadgesBadgeIdNameDescriptionLanguageCodesLanguageCodePatch: function(t, r, a, o) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, Un(i).v1BadgesBadgeIdNameDescriptionLanguageCodesLanguageCodePatch(t, r, a, o)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1BadgesBadgeIdNameLanguageCodesLanguageCodePatch: function(t, r, a, o) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, Un(i).v1BadgesBadgeIdNameLanguageCodesLanguageCodePatch(t, r, a, o)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    }
                }
            }

            function On() {
                return null !== An && An.apply(this, arguments) || this
            }

            function Dn(d) {
                var e = this;
                return {
                    v1DeveloperProductsDeveloperProductIdDescriptionLanguageCodesLanguageCodePatch: function(i, s, u, c) {
                        return void 0 === c && (c = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                if (null == i) throw new dn("developerProductId", "Required parameter developerProductId was null or undefined when calling v1DeveloperProductsDeveloperProductIdDescriptionLanguageCodesLanguageCodePatch.");
                                if (null == s) throw new dn("languageCode", "Required parameter languageCode was null or undefined when calling v1DeveloperProductsDeveloperProductIdDescriptionLanguageCodesLanguageCodePatch.");
                                if (null == u) throw new dn("request", "Required parameter request was null or undefined when calling v1DeveloperProductsDeveloperProductIdDescriptionLanguageCodesLanguageCodePatch.");
                                return r = "/v1/developer-products/{developerProductId}/description/language-codes/{languageCode}".replace("{developerProductId}", encodeURIComponent(String(i))).replace("{languageCode}", encodeURIComponent(String(s))), t = Gt.Qc(r, !0), d && (o = d.baseOptions), n = fn(fn({
                                    method: "PATCH"
                                }, o), c), a = {}, (r = {})["Content-Type"] = "application/json", t.query = fn(fn(fn({}, t.query), a), c.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), c.headers), o = "string" != typeof u || "application/json" === n.headers["Content-Type"], n.data = o ? JSON.stringify(void 0 !== u ? u : {}) : u || "", [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1DeveloperProductsDeveloperProductIdIconsGet: function(i, s, u, c) {
                        return void 0 === c && (c = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                if (null == i) throw new dn("developerProductId", "Required parameter developerProductId was null or undefined when calling v1DeveloperProductsDeveloperProductIdIconsGet.");
                                return a = "/v1/developer-products/{developerProductId}/icons".replace("{developerProductId}", encodeURIComponent(String(i))), t = Gt.Qc(a, !0), d && (o = d.baseOptions), n = fn(fn({
                                    method: "GET"
                                }, o), c), r = {}, a = {}, void 0 !== s && (a.width = s), void 0 !== u && (a.height = u), t.query = fn(fn(fn({}, t.query), a), c.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), c.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1DeveloperProductsDeveloperProductIdIconsLanguageCodesLanguageCodeDelete: function(i, s, u) {
                        return void 0 === u && (u = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                if (null == i) throw new dn("developerProductId", "Required parameter developerProductId was null or undefined when calling v1DeveloperProductsDeveloperProductIdIconsLanguageCodesLanguageCodeDelete.");
                                if (null == s) throw new dn("languageCode", "Required parameter languageCode was null or undefined when calling v1DeveloperProductsDeveloperProductIdIconsLanguageCodesLanguageCodeDelete.");
                                return a = "/v1/developer-products/{developerProductId}/icons/language-codes/{languageCode}".replace("{developerProductId}", encodeURIComponent(String(i))).replace("{languageCode}", encodeURIComponent(String(s))), t = Gt.Qc(a, !0), d && (o = d.baseOptions), n = fn(fn({
                                    method: "DELETE"
                                }, o), u), r = {}, a = {}, t.query = fn(fn(fn({}, t.query), a), u.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), u.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1DeveloperProductsDeveloperProductIdIconsLanguageCodesLanguageCodePost: function(s, u, c, l) {
                        return void 0 === l && (l = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o, i;
                            return gn(this, function(e) {
                                if (null == s) throw new dn("developerProductId", "Required parameter developerProductId was null or undefined when calling v1DeveloperProductsDeveloperProductIdIconsLanguageCodesLanguageCodePost.");
                                if (null == u) throw new dn("languageCode", "Required parameter languageCode was null or undefined when calling v1DeveloperProductsDeveloperProductIdIconsLanguageCodesLanguageCodePost.");
                                return o = "/v1/developer-products/{developerProductId}/icons/language-codes/{languageCode}".replace("{developerProductId}", encodeURIComponent(String(s))).replace("{languageCode}", encodeURIComponent(String(u))), t = Gt.Qc(o, !0), d && (i = d.baseOptions), n = fn(fn({
                                    method: "POST"
                                }, i), l), r = {}, a = {}, o = new FormData, void 0 !== c && o.append("request.files", c), r["Content-Type"] = "multipart/form-data", t.query = fn(fn(fn({}, t.query), a), l.query), delete t.search, i = i && i.headers ? i.headers : {}, n.headers = fn(fn(fn({}, r), i), l.headers), n.data = o, [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1DeveloperProductsDeveloperProductIdNameDescriptionGet: function(i, s) {
                        return void 0 === s && (s = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                if (null == i) throw new dn("developerProductId", "Required parameter developerProductId was null or undefined when calling v1DeveloperProductsDeveloperProductIdNameDescriptionGet.");
                                return a = "/v1/developer-products/{developerProductId}/name-description".replace("{developerProductId}", encodeURIComponent(String(i))), t = Gt.Qc(a, !0), d && (o = d.baseOptions), n = fn(fn({
                                    method: "GET"
                                }, o), s), r = {}, a = {}, t.query = fn(fn(fn({}, t.query), a), s.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), s.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1DeveloperProductsDeveloperProductIdNameDescriptionLanguageCodesLanguageCodeDelete: function(i, s, u) {
                        return void 0 === u && (u = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                if (null == i) throw new dn("developerProductId", "Required parameter developerProductId was null or undefined when calling v1DeveloperProductsDeveloperProductIdNameDescriptionLanguageCodesLanguageCodeDelete.");
                                if (null == s) throw new dn("languageCode", "Required parameter languageCode was null or undefined when calling v1DeveloperProductsDeveloperProductIdNameDescriptionLanguageCodesLanguageCodeDelete.");
                                return a = "/v1/developer-products/{developerProductId}/name-description/language-codes/{languageCode}".replace("{developerProductId}", encodeURIComponent(String(i))).replace("{languageCode}", encodeURIComponent(String(s))), t = Gt.Qc(a, !0), d && (o = d.baseOptions), n = fn(fn({
                                    method: "DELETE"
                                }, o), u), r = {}, a = {}, t.query = fn(fn(fn({}, t.query), a), u.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), u.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1DeveloperProductsDeveloperProductIdNameDescriptionLanguageCodesLanguageCodePatch: function(i, s, u, c) {
                        return void 0 === c && (c = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                if (null == i) throw new dn("developerProductId", "Required parameter developerProductId was null or undefined when calling v1DeveloperProductsDeveloperProductIdNameDescriptionLanguageCodesLanguageCodePatch.");
                                if (null == s) throw new dn("languageCode", "Required parameter languageCode was null or undefined when calling v1DeveloperProductsDeveloperProductIdNameDescriptionLanguageCodesLanguageCodePatch.");
                                if (null == u) throw new dn("request", "Required parameter request was null or undefined when calling v1DeveloperProductsDeveloperProductIdNameDescriptionLanguageCodesLanguageCodePatch.");
                                return r = "/v1/developer-products/{developerProductId}/name-description/language-codes/{languageCode}".replace("{developerProductId}", encodeURIComponent(String(i))).replace("{languageCode}", encodeURIComponent(String(s))), t = Gt.Qc(r, !0), d && (o = d.baseOptions), n = fn(fn({
                                    method: "PATCH"
                                }, o), c), a = {}, (r = {})["Content-Type"] = "application/json", t.query = fn(fn(fn({}, t.query), a), c.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), c.headers), o = "string" != typeof u || "application/json" === n.headers["Content-Type"], n.data = o ? JSON.stringify(void 0 !== u ? u : {}) : u || "", [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1DeveloperProductsDeveloperProductIdNameLanguageCodesLanguageCodePatch: function(i, s, u, c) {
                        return void 0 === c && (c = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                if (null == i) throw new dn("developerProductId", "Required parameter developerProductId was null or undefined when calling v1DeveloperProductsDeveloperProductIdNameLanguageCodesLanguageCodePatch.");
                                if (null == s) throw new dn("languageCode", "Required parameter languageCode was null or undefined when calling v1DeveloperProductsDeveloperProductIdNameLanguageCodesLanguageCodePatch.");
                                if (null == u) throw new dn("request", "Required parameter request was null or undefined when calling v1DeveloperProductsDeveloperProductIdNameLanguageCodesLanguageCodePatch.");
                                return r = "/v1/developer-products/{developerProductId}/name/language-codes/{languageCode}".replace("{developerProductId}", encodeURIComponent(String(i))).replace("{languageCode}", encodeURIComponent(String(s))), t = Gt.Qc(r, !0), d && (o = d.baseOptions), n = fn(fn({
                                    method: "PATCH"
                                }, o), c), a = {}, (r = {})["Content-Type"] = "application/json", t.query = fn(fn(fn({}, t.query), a), c.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), c.headers), o = "string" != typeof u || "application/json" === n.headers["Content-Type"], n.data = o ? JSON.stringify(void 0 !== u ? u : {}) : u || "", [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    }
                }
            }

            function xn(i) {
                return {
                    v1DeveloperProductsDeveloperProductIdDescriptionLanguageCodesLanguageCodePatch: function(t, r, a, o) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, Dn(i).v1DeveloperProductsDeveloperProductIdDescriptionLanguageCodesLanguageCodePatch(t, r, a, o)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1DeveloperProductsDeveloperProductIdIconsGet: function(t, r, a, o) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, Dn(i).v1DeveloperProductsDeveloperProductIdIconsGet(t, r, a, o)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1DeveloperProductsDeveloperProductIdIconsLanguageCodesLanguageCodeDelete: function(t, r, a) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, Dn(i).v1DeveloperProductsDeveloperProductIdIconsLanguageCodesLanguageCodeDelete(t, r, a)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1DeveloperProductsDeveloperProductIdIconsLanguageCodesLanguageCodePost: function(t, r, a, o) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, Dn(i).v1DeveloperProductsDeveloperProductIdIconsLanguageCodesLanguageCodePost(t, r, a, o)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1DeveloperProductsDeveloperProductIdNameDescriptionGet: function(t, r) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, Dn(i).v1DeveloperProductsDeveloperProductIdNameDescriptionGet(t, r)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1DeveloperProductsDeveloperProductIdNameDescriptionLanguageCodesLanguageCodeDelete: function(t, r, a) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, Dn(i).v1DeveloperProductsDeveloperProductIdNameDescriptionLanguageCodesLanguageCodeDelete(t, r, a)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1DeveloperProductsDeveloperProductIdNameDescriptionLanguageCodesLanguageCodePatch: function(t, r, a, o) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, Dn(i).v1DeveloperProductsDeveloperProductIdNameDescriptionLanguageCodesLanguageCodePatch(t, r, a, o)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1DeveloperProductsDeveloperProductIdNameLanguageCodesLanguageCodePatch: function(t, r, a, o) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, Dn(i).v1DeveloperProductsDeveloperProductIdNameLanguageCodesLanguageCodePatch(t, r, a, o)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    }
                }
            }

            function _n() {
                return null !== Sn && Sn.apply(this, arguments) || this
            }

            function Bn(d) {
                var e = this;
                return {
                    v1GameIconGamesGameIdGet: function(i, s, u, c) {
                        return void 0 === c && (c = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                if (null == i) throw new dn("gameId", "Required parameter gameId was null or undefined when calling v1GameIconGamesGameIdGet.");
                                return a = "/v1/game-icon/games/{gameId}".replace("{gameId}", encodeURIComponent(String(i))), t = Gt.Qc(a, !0), d && (o = d.baseOptions), n = fn(fn({
                                    method: "GET"
                                }, o), c), r = {}, a = {}, void 0 !== s && (a.width = s), void 0 !== u && (a.height = u), t.query = fn(fn(fn({}, t.query), a), c.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), c.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1GameIconGamesGameIdLanguageCodesLanguageCodeDelete: function(i, s, u) {
                        return void 0 === u && (u = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                if (null == i) throw new dn("gameId", "Required parameter gameId was null or undefined when calling v1GameIconGamesGameIdLanguageCodesLanguageCodeDelete.");
                                if (null == s) throw new dn("languageCode", "Required parameter languageCode was null or undefined when calling v1GameIconGamesGameIdLanguageCodesLanguageCodeDelete.");
                                return a = "/v1/game-icon/games/{gameId}/language-codes/{languageCode}".replace("{gameId}", encodeURIComponent(String(i))).replace("{languageCode}", encodeURIComponent(String(s))), t = Gt.Qc(a, !0), d && (o = d.baseOptions), n = fn(fn({
                                    method: "DELETE"
                                }, o), u), r = {}, a = {}, t.query = fn(fn(fn({}, t.query), a), u.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), u.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1GameIconGamesGameIdLanguageCodesLanguageCodePost: function(s, u, c, l) {
                        return void 0 === l && (l = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o, i;
                            return gn(this, function(e) {
                                if (null == s) throw new dn("gameId", "Required parameter gameId was null or undefined when calling v1GameIconGamesGameIdLanguageCodesLanguageCodePost.");
                                if (null == u) throw new dn("languageCode", "Required parameter languageCode was null or undefined when calling v1GameIconGamesGameIdLanguageCodesLanguageCodePost.");
                                return o = "/v1/game-icon/games/{gameId}/language-codes/{languageCode}".replace("{gameId}", encodeURIComponent(String(s))).replace("{languageCode}", encodeURIComponent(String(u))), t = Gt.Qc(o, !0), d && (i = d.baseOptions), n = fn(fn({
                                    method: "POST"
                                }, i), l), r = {}, a = {}, o = new FormData, void 0 !== c && o.append("request.files", c), r["Content-Type"] = "multipart/form-data", t.query = fn(fn(fn({}, t.query), a), l.query), delete t.search, i = i && i.headers ? i.headers : {}, n.headers = fn(fn(fn({}, r), i), l.headers), n.data = o, [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    }
                }
            }

            function Fn(i) {
                return {
                    v1GameIconGamesGameIdGet: function(t, r, a, o) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, Bn(i).v1GameIconGamesGameIdGet(t, r, a, o)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1GameIconGamesGameIdLanguageCodesLanguageCodeDelete: function(t, r, a) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, Bn(i).v1GameIconGamesGameIdLanguageCodesLanguageCodeDelete(t, r, a)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1GameIconGamesGameIdLanguageCodesLanguageCodePost: function(t, r, a, o) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, Bn(i).v1GameIconGamesGameIdLanguageCodesLanguageCodePost(t, r, a, o)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    }
                }
            }

            function Nn() {
                return null !== Rn && Rn.apply(this, arguments) || this
            }

            function kn(l) {
                var e = this;
                return {
                    v1GameLocalizationStatusGameIdTranslationCountsGet: function(i, s) {
                        return void 0 === s && (s = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                if (null == i) throw new dn("gameId", "Required parameter gameId was null or undefined when calling v1GameLocalizationStatusGameIdTranslationCountsGet.");
                                return a = "/v1/game-localization-status/{gameId}/translation-counts".replace("{gameId}", encodeURIComponent(String(i))), t = Gt.Qc(a, !0), l && (o = l.baseOptions), n = fn(fn({
                                    method: "GET"
                                }, o), s), r = {}, a = {}, t.query = fn(fn(fn({}, t.query), a), s.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), s.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1GameLocalizationStatusTranslationCountsForLanguageOrLocaleGet: function(i, s, u, c) {
                        return void 0 === c && (c = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                if (null == i) throw new dn("gameIds", "Required parameter gameIds was null or undefined when calling v1GameLocalizationStatusTranslationCountsForLanguageOrLocaleGet.");
                                if (null == s) throw new dn("languageOrLocaleCode", "Required parameter languageOrLocaleCode was null or undefined when calling v1GameLocalizationStatusTranslationCountsForLanguageOrLocaleGet.");
                                if (null == u) throw new dn("languageOrLocaleType", "Required parameter languageOrLocaleType was null or undefined when calling v1GameLocalizationStatusTranslationCountsForLanguageOrLocaleGet.");
                                return t = Gt.Qc("/v1/game-localization-status/translation-counts-for-language-or-locale", !0), l && (o = l.baseOptions), n = fn(fn({
                                    method: "GET"
                                }, o), c), r = {}, a = {}, i && (a.gameIds = i), void 0 !== s && (a.languageOrLocaleCode = s), void 0 !== u && (a.languageOrLocaleType = u), t.query = fn(fn(fn({}, t.query), a), c.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), c.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    }
                }
            }

            function Mn(i) {
                return {
                    v1GameLocalizationStatusGameIdTranslationCountsGet: function(t, r) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, kn(i).v1GameLocalizationStatusGameIdTranslationCountsGet(t, r)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1GameLocalizationStatusTranslationCountsForLanguageOrLocaleGet: function(t, r, a, o) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, kn(i).v1GameLocalizationStatusTranslationCountsForLanguageOrLocaleGet(t, r, a, o)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    }
                }
            }
            oe(On, An = ae), On.prototype.v1BadgesBadgeIdDescriptionLanguageCodesLanguageCodePatch = function(e, t, n, r) {
                var a = this;
                return qn(this.configuration).v1BadgesBadgeIdDescriptionLanguageCodesLanguageCodePatch(e, t, n, r).then(function(e) {
                    return e(a.axios, a.basePath)
                })
            }, On.prototype.v1BadgesBadgeIdIconsGet = function(e, t, n, r) {
                var a = this;
                return qn(this.configuration).v1BadgesBadgeIdIconsGet(e, t, n, r).then(function(e) {
                    return e(a.axios, a.basePath)
                })
            }, On.prototype.v1BadgesBadgeIdIconsLanguageCodesLanguageCodeDelete = function(e, t, n) {
                var r = this;
                return qn(this.configuration).v1BadgesBadgeIdIconsLanguageCodesLanguageCodeDelete(e, t, n).then(function(e) {
                    return e(r.axios, r.basePath)
                })
            }, On.prototype.v1BadgesBadgeIdIconsLanguageCodesLanguageCodePost = function(e, t, n, r) {
                var a = this;
                return qn(this.configuration).v1BadgesBadgeIdIconsLanguageCodesLanguageCodePost(e, t, n, r).then(function(e) {
                    return e(a.axios, a.basePath)
                })
            }, On.prototype.v1BadgesBadgeIdNameDescriptionGet = function(e, t) {
                var n = this;
                return qn(this.configuration).v1BadgesBadgeIdNameDescriptionGet(e, t).then(function(e) {
                    return e(n.axios, n.basePath)
                })
            }, On.prototype.v1BadgesBadgeIdNameDescriptionLanguageCodesLanguageCodeDelete = function(e, t, n) {
                var r = this;
                return qn(this.configuration).v1BadgesBadgeIdNameDescriptionLanguageCodesLanguageCodeDelete(e, t, n).then(function(e) {
                    return e(r.axios, r.basePath)
                })
            }, On.prototype.v1BadgesBadgeIdNameDescriptionLanguageCodesLanguageCodePatch = function(e, t, n, r) {
                var a = this;
                return qn(this.configuration).v1BadgesBadgeIdNameDescriptionLanguageCodesLanguageCodePatch(e, t, n, r).then(function(e) {
                    return e(a.axios, a.basePath)
                })
            }, On.prototype.v1BadgesBadgeIdNameLanguageCodesLanguageCodePatch = function(e, t, n, r) {
                var a = this;
                return qn(this.configuration).v1BadgesBadgeIdNameLanguageCodesLanguageCodePatch(e, t, n, r).then(function(e) {
                    return e(a.axios, a.basePath)
                })
            }, oe(_n, Sn = ae), _n.prototype.v1DeveloperProductsDeveloperProductIdDescriptionLanguageCodesLanguageCodePatch = function(e, t, n, r) {
                var a = this;
                return xn(this.configuration).v1DeveloperProductsDeveloperProductIdDescriptionLanguageCodesLanguageCodePatch(e, t, n, r).then(function(e) {
                    return e(a.axios, a.basePath)
                })
            }, _n.prototype.v1DeveloperProductsDeveloperProductIdIconsGet = function(e, t, n, r) {
                var a = this;
                return xn(this.configuration).v1DeveloperProductsDeveloperProductIdIconsGet(e, t, n, r).then(function(e) {
                    return e(a.axios, a.basePath)
                })
            }, _n.prototype.v1DeveloperProductsDeveloperProductIdIconsLanguageCodesLanguageCodeDelete = function(e, t, n) {
                var r = this;
                return xn(this.configuration).v1DeveloperProductsDeveloperProductIdIconsLanguageCodesLanguageCodeDelete(e, t, n).then(function(e) {
                    return e(r.axios, r.basePath)
                })
            }, _n.prototype.v1DeveloperProductsDeveloperProductIdIconsLanguageCodesLanguageCodePost = function(e, t, n, r) {
                var a = this;
                return xn(this.configuration).v1DeveloperProductsDeveloperProductIdIconsLanguageCodesLanguageCodePost(e, t, n, r).then(function(e) {
                    return e(a.axios, a.basePath)
                })
            }, _n.prototype.v1DeveloperProductsDeveloperProductIdNameDescriptionGet = function(e, t) {
                var n = this;
                return xn(this.configuration).v1DeveloperProductsDeveloperProductIdNameDescriptionGet(e, t).then(function(e) {
                    return e(n.axios, n.basePath)
                })
            }, _n.prototype.v1DeveloperProductsDeveloperProductIdNameDescriptionLanguageCodesLanguageCodeDelete = function(e, t, n) {
                var r = this;
                return xn(this.configuration).v1DeveloperProductsDeveloperProductIdNameDescriptionLanguageCodesLanguageCodeDelete(e, t, n).then(function(e) {
                    return e(r.axios, r.basePath)
                })
            }, _n.prototype.v1DeveloperProductsDeveloperProductIdNameDescriptionLanguageCodesLanguageCodePatch = function(e, t, n, r) {
                var a = this;
                return xn(this.configuration).v1DeveloperProductsDeveloperProductIdNameDescriptionLanguageCodesLanguageCodePatch(e, t, n, r).then(function(e) {
                    return e(a.axios, a.basePath)
                })
            }, _n.prototype.v1DeveloperProductsDeveloperProductIdNameLanguageCodesLanguageCodePatch = function(e, t, n, r) {
                var a = this;
                return xn(this.configuration).v1DeveloperProductsDeveloperProductIdNameLanguageCodesLanguageCodePatch(e, t, n, r).then(function(e) {
                    return e(a.axios, a.basePath)
                })
            }, oe(Nn, Rn = ae), Nn.prototype.v1GameIconGamesGameIdGet = function(e, t, n, r) {
                var a = this;
                return Fn(this.configuration).v1GameIconGamesGameIdGet(e, t, n, r).then(function(e) {
                    return e(a.axios, a.basePath)
                })
            }, Nn.prototype.v1GameIconGamesGameIdLanguageCodesLanguageCodeDelete = function(e, t, n) {
                var r = this;
                return Fn(this.configuration).v1GameIconGamesGameIdLanguageCodesLanguageCodeDelete(e, t, n).then(function(e) {
                    return e(r.axios, r.basePath)
                })
            }, Nn.prototype.v1GameIconGamesGameIdLanguageCodesLanguageCodePost = function(e, t, n, r) {
                var a = this;
                return Fn(this.configuration).v1GameIconGamesGameIdLanguageCodesLanguageCodePost(e, t, n, r).then(function(e) {
                    return e(a.axios, a.basePath)
                })
            };
            var jn, zn, Wn, f = (oe(Vn, jn = ae), Vn.prototype.v1GameLocalizationStatusGameIdTranslationCountsGet = function(e, t) {
                var n = this;
                return Mn(this.configuration).v1GameLocalizationStatusGameIdTranslationCountsGet(e, t).then(function(e) {
                    return e(n.axios, n.basePath)
                })
            }, Vn.prototype.v1GameLocalizationStatusTranslationCountsForLanguageOrLocaleGet = function(e, t, n, r) {
                var a = this;
                return Mn(this.configuration).v1GameLocalizationStatusTranslationCountsForLanguageOrLocaleGet(e, t, n, r).then(function(e) {
                    return e(a.axios, a.basePath)
                })
            }, Vn);

            function Vn() {
                return null !== jn && jn.apply(this, arguments) || this
            }

            function Hn(d) {
                var e = this;
                return {
                    v1GamePassesGamePassIdDescriptionLanguageCodesLanguageCodePatch: function(i, s, u, c) {
                        return void 0 === c && (c = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                if (null == i) throw new dn("gamePassId", "Required parameter gamePassId was null or undefined when calling v1GamePassesGamePassIdDescriptionLanguageCodesLanguageCodePatch.");
                                if (null == s) throw new dn("languageCode", "Required parameter languageCode was null or undefined when calling v1GamePassesGamePassIdDescriptionLanguageCodesLanguageCodePatch.");
                                if (null == u) throw new dn("request", "Required parameter request was null or undefined when calling v1GamePassesGamePassIdDescriptionLanguageCodesLanguageCodePatch.");
                                return r = "/v1/game-passes/{gamePassId}/description/language-codes/{languageCode}".replace("{gamePassId}", encodeURIComponent(String(i))).replace("{languageCode}", encodeURIComponent(String(s))), t = Gt.Qc(r, !0), d && (o = d.baseOptions), n = fn(fn({
                                    method: "PATCH"
                                }, o), c), a = {}, (r = {})["Content-Type"] = "application/json", t.query = fn(fn(fn({}, t.query), a), c.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), c.headers), o = "string" != typeof u || "application/json" === n.headers["Content-Type"], n.data = o ? JSON.stringify(void 0 !== u ? u : {}) : u || "", [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1GamePassesGamePassIdIconsGet: function(i, s, u, c) {
                        return void 0 === c && (c = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                if (null == i) throw new dn("gamePassId", "Required parameter gamePassId was null or undefined when calling v1GamePassesGamePassIdIconsGet.");
                                return a = "/v1/game-passes/{gamePassId}/icons".replace("{gamePassId}", encodeURIComponent(String(i))), t = Gt.Qc(a, !0), d && (o = d.baseOptions), n = fn(fn({
                                    method: "GET"
                                }, o), c), r = {}, a = {}, void 0 !== s && (a.width = s), void 0 !== u && (a.height = u), t.query = fn(fn(fn({}, t.query), a), c.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), c.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1GamePassesGamePassIdIconsLanguageCodesLanguageCodeDelete: function(i, s, u) {
                        return void 0 === u && (u = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                if (null == i) throw new dn("gamePassId", "Required parameter gamePassId was null or undefined when calling v1GamePassesGamePassIdIconsLanguageCodesLanguageCodeDelete.");
                                if (null == s) throw new dn("languageCode", "Required parameter languageCode was null or undefined when calling v1GamePassesGamePassIdIconsLanguageCodesLanguageCodeDelete.");
                                return a = "/v1/game-passes/{gamePassId}/icons/language-codes/{languageCode}".replace("{gamePassId}", encodeURIComponent(String(i))).replace("{languageCode}", encodeURIComponent(String(s))), t = Gt.Qc(a, !0), d && (o = d.baseOptions), n = fn(fn({
                                    method: "DELETE"
                                }, o), u), r = {}, a = {}, t.query = fn(fn(fn({}, t.query), a), u.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), u.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1GamePassesGamePassIdIconsLanguageCodesLanguageCodePost: function(s, u, c, l) {
                        return void 0 === l && (l = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o, i;
                            return gn(this, function(e) {
                                if (null == s) throw new dn("gamePassId", "Required parameter gamePassId was null or undefined when calling v1GamePassesGamePassIdIconsLanguageCodesLanguageCodePost.");
                                if (null == u) throw new dn("languageCode", "Required parameter languageCode was null or undefined when calling v1GamePassesGamePassIdIconsLanguageCodesLanguageCodePost.");
                                return o = "/v1/game-passes/{gamePassId}/icons/language-codes/{languageCode}".replace("{gamePassId}", encodeURIComponent(String(s))).replace("{languageCode}", encodeURIComponent(String(u))), t = Gt.Qc(o, !0), d && (i = d.baseOptions), n = fn(fn({
                                    method: "POST"
                                }, i), l), r = {}, a = {}, o = new FormData, void 0 !== c && o.append("request.files", c), r["Content-Type"] = "multipart/form-data", t.query = fn(fn(fn({}, t.query), a), l.query), delete t.search, i = i && i.headers ? i.headers : {}, n.headers = fn(fn(fn({}, r), i), l.headers), n.data = o, [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1GamePassesGamePassIdNameDescriptionGet: function(i, s) {
                        return void 0 === s && (s = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                if (null == i) throw new dn("gamePassId", "Required parameter gamePassId was null or undefined when calling v1GamePassesGamePassIdNameDescriptionGet.");
                                return a = "/v1/game-passes/{gamePassId}/name-description".replace("{gamePassId}", encodeURIComponent(String(i))), t = Gt.Qc(a, !0), d && (o = d.baseOptions), n = fn(fn({
                                    method: "GET"
                                }, o), s), r = {}, a = {}, t.query = fn(fn(fn({}, t.query), a), s.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), s.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1GamePassesGamePassIdNameDescriptionLanguageCodesLanguageCodeDelete: function(i, s, u) {
                        return void 0 === u && (u = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                if (null == i) throw new dn("gamePassId", "Required parameter gamePassId was null or undefined when calling v1GamePassesGamePassIdNameDescriptionLanguageCodesLanguageCodeDelete.");
                                if (null == s) throw new dn("languageCode", "Required parameter languageCode was null or undefined when calling v1GamePassesGamePassIdNameDescriptionLanguageCodesLanguageCodeDelete.");
                                return a = "/v1/game-passes/{gamePassId}/name-description/language-codes/{languageCode}".replace("{gamePassId}", encodeURIComponent(String(i))).replace("{languageCode}", encodeURIComponent(String(s))), t = Gt.Qc(a, !0), d && (o = d.baseOptions), n = fn(fn({
                                    method: "DELETE"
                                }, o), u), r = {}, a = {}, t.query = fn(fn(fn({}, t.query), a), u.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), u.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1GamePassesGamePassIdNameDescriptionLanguageCodesLanguageCodePatch: function(i, s, u, c) {
                        return void 0 === c && (c = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                if (null == i) throw new dn("gamePassId", "Required parameter gamePassId was null or undefined when calling v1GamePassesGamePassIdNameDescriptionLanguageCodesLanguageCodePatch.");
                                if (null == s) throw new dn("languageCode", "Required parameter languageCode was null or undefined when calling v1GamePassesGamePassIdNameDescriptionLanguageCodesLanguageCodePatch.");
                                if (null == u) throw new dn("request", "Required parameter request was null or undefined when calling v1GamePassesGamePassIdNameDescriptionLanguageCodesLanguageCodePatch.");
                                return r = "/v1/game-passes/{gamePassId}/name-description/language-codes/{languageCode}".replace("{gamePassId}", encodeURIComponent(String(i))).replace("{languageCode}", encodeURIComponent(String(s))), t = Gt.Qc(r, !0), d && (o = d.baseOptions), n = fn(fn({
                                    method: "PATCH"
                                }, o), c), a = {}, (r = {})["Content-Type"] = "application/json", t.query = fn(fn(fn({}, t.query), a), c.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), c.headers), o = "string" != typeof u || "application/json" === n.headers["Content-Type"], n.data = o ? JSON.stringify(void 0 !== u ? u : {}) : u || "", [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1GamePassesGamePassIdNameLanguageCodesLanguageCodePatch: function(i, s, u, c) {
                        return void 0 === c && (c = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                if (null == i) throw new dn("gamePassId", "Required parameter gamePassId was null or undefined when calling v1GamePassesGamePassIdNameLanguageCodesLanguageCodePatch.");
                                if (null == s) throw new dn("languageCode", "Required parameter languageCode was null or undefined when calling v1GamePassesGamePassIdNameLanguageCodesLanguageCodePatch.");
                                if (null == u) throw new dn("request", "Required parameter request was null or undefined when calling v1GamePassesGamePassIdNameLanguageCodesLanguageCodePatch.");
                                return r = "/v1/game-passes/{gamePassId}/name/language-codes/{languageCode}".replace("{gamePassId}", encodeURIComponent(String(i))).replace("{languageCode}", encodeURIComponent(String(s))), t = Gt.Qc(r, !0), d && (o = d.baseOptions), n = fn(fn({
                                    method: "PATCH"
                                }, o), c), a = {}, (r = {})["Content-Type"] = "application/json", t.query = fn(fn(fn({}, t.query), a), c.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), c.headers), o = "string" != typeof u || "application/json" === n.headers["Content-Type"], n.data = o ? JSON.stringify(void 0 !== u ? u : {}) : u || "", [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    }
                }
            }

            function Qn(i) {
                return {
                    v1GamePassesGamePassIdDescriptionLanguageCodesLanguageCodePatch: function(t, r, a, o) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, Hn(i).v1GamePassesGamePassIdDescriptionLanguageCodesLanguageCodePatch(t, r, a, o)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1GamePassesGamePassIdIconsGet: function(t, r, a, o) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, Hn(i).v1GamePassesGamePassIdIconsGet(t, r, a, o)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1GamePassesGamePassIdIconsLanguageCodesLanguageCodeDelete: function(t, r, a) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, Hn(i).v1GamePassesGamePassIdIconsLanguageCodesLanguageCodeDelete(t, r, a)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1GamePassesGamePassIdIconsLanguageCodesLanguageCodePost: function(t, r, a, o) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, Hn(i).v1GamePassesGamePassIdIconsLanguageCodesLanguageCodePost(t, r, a, o)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1GamePassesGamePassIdNameDescriptionGet: function(t, r) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, Hn(i).v1GamePassesGamePassIdNameDescriptionGet(t, r)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1GamePassesGamePassIdNameDescriptionLanguageCodesLanguageCodeDelete: function(t, r, a) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, Hn(i).v1GamePassesGamePassIdNameDescriptionLanguageCodesLanguageCodeDelete(t, r, a)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1GamePassesGamePassIdNameDescriptionLanguageCodesLanguageCodePatch: function(t, r, a, o) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, Hn(i).v1GamePassesGamePassIdNameDescriptionLanguageCodesLanguageCodePatch(t, r, a, o)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1GamePassesGamePassIdNameLanguageCodesLanguageCodePatch: function(t, r, a, o) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, Hn(i).v1GamePassesGamePassIdNameLanguageCodesLanguageCodePatch(t, r, a, o)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    }
                }
            }

            function Kn() {
                return null !== zn && zn.apply(this, arguments) || this
            }

            function Xn(d) {
                var e = this;
                return {
                    v1GameThumbnailsGamesGameIdImagesGet: function(i, s, u, c) {
                        return void 0 === c && (c = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                if (null == i) throw new dn("gameId", "Required parameter gameId was null or undefined when calling v1GameThumbnailsGamesGameIdImagesGet.");
                                return a = "/v1/game-thumbnails/games/{gameId}/images".replace("{gameId}", encodeURIComponent(String(i))), t = Gt.Qc(a, !0), d && (o = d.baseOptions), n = fn(fn({
                                    method: "GET"
                                }, o), c), r = {}, a = {}, void 0 !== s && (a.width = s), void 0 !== u && (a.height = u), t.query = fn(fn(fn({}, t.query), a), c.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), c.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1GameThumbnailsGamesGameIdLanguageCodesLanguageCodeImagePost: function(s, u, c, l) {
                        return void 0 === l && (l = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o, i;
                            return gn(this, function(e) {
                                if (null == s) throw new dn("gameId", "Required parameter gameId was null or undefined when calling v1GameThumbnailsGamesGameIdLanguageCodesLanguageCodeImagePost.");
                                if (null == u) throw new dn("languageCode", "Required parameter languageCode was null or undefined when calling v1GameThumbnailsGamesGameIdLanguageCodesLanguageCodeImagePost.");
                                return o = "/v1/game-thumbnails/games/{gameId}/language-codes/{languageCode}/image".replace("{gameId}", encodeURIComponent(String(s))).replace("{languageCode}", encodeURIComponent(String(u))), t = Gt.Qc(o, !0), d && (i = d.baseOptions), n = fn(fn({
                                    method: "POST"
                                }, i), l), r = {}, a = {}, o = new FormData, void 0 !== c && o.append("gameThumbnailRequest.files", c), r["Content-Type"] = "multipart/form-data", t.query = fn(fn(fn({}, t.query), a), l.query), delete t.search, i = i && i.headers ? i.headers : {}, n.headers = fn(fn(fn({}, r), i), l.headers), n.data = o, [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1GameThumbnailsGamesGameIdLanguageCodesLanguageCodeImagesImageIdDelete: function(i, s, u, c) {
                        return void 0 === c && (c = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                if (null == i) throw new dn("gameId", "Required parameter gameId was null or undefined when calling v1GameThumbnailsGamesGameIdLanguageCodesLanguageCodeImagesImageIdDelete.");
                                if (null == s) throw new dn("languageCode", "Required parameter languageCode was null or undefined when calling v1GameThumbnailsGamesGameIdLanguageCodesLanguageCodeImagesImageIdDelete.");
                                if (null == u) throw new dn("imageId", "Required parameter imageId was null or undefined when calling v1GameThumbnailsGamesGameIdLanguageCodesLanguageCodeImagesImageIdDelete.");
                                return a = "/v1/game-thumbnails/games/{gameId}/language-codes/{languageCode}/images/{imageId}".replace("{gameId}", encodeURIComponent(String(i))).replace("{languageCode}", encodeURIComponent(String(s))).replace("{imageId}", encodeURIComponent(String(u))), t = Gt.Qc(a, !0), d && (o = d.baseOptions), n = fn(fn({
                                    method: "DELETE"
                                }, o), c), r = {}, a = {}, t.query = fn(fn(fn({}, t.query), a), c.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), c.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1GameThumbnailsGamesGameIdLanguageCodesLanguageCodeImagesOrderPost: function(i, s, u, c) {
                        return void 0 === c && (c = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                if (null == i) throw new dn("gameId", "Required parameter gameId was null or undefined when calling v1GameThumbnailsGamesGameIdLanguageCodesLanguageCodeImagesOrderPost.");
                                if (null == s) throw new dn("languageCode", "Required parameter languageCode was null or undefined when calling v1GameThumbnailsGamesGameIdLanguageCodesLanguageCodeImagesOrderPost.");
                                if (null == u) throw new dn("request", "Required parameter request was null or undefined when calling v1GameThumbnailsGamesGameIdLanguageCodesLanguageCodeImagesOrderPost.");
                                return r = "/v1/game-thumbnails/games/{gameId}/language-codes/{languageCode}/images/order".replace("{gameId}", encodeURIComponent(String(i))).replace("{languageCode}", encodeURIComponent(String(s))), t = Gt.Qc(r, !0), d && (o = d.baseOptions), n = fn(fn({
                                    method: "POST"
                                }, o), c), a = {}, (r = {})["Content-Type"] = "application/json", t.query = fn(fn(fn({}, t.query), a), c.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), c.headers), o = "string" != typeof u || "application/json" === n.headers["Content-Type"], n.data = o ? JSON.stringify(void 0 !== u ? u : {}) : u || "", [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    }
                }
            }

            function Jn(i) {
                return {
                    v1GameThumbnailsGamesGameIdImagesGet: function(t, r, a, o) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, Xn(i).v1GameThumbnailsGamesGameIdImagesGet(t, r, a, o)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1GameThumbnailsGamesGameIdLanguageCodesLanguageCodeImagePost: function(t, r, a, o) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, Xn(i).v1GameThumbnailsGamesGameIdLanguageCodesLanguageCodeImagePost(t, r, a, o)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1GameThumbnailsGamesGameIdLanguageCodesLanguageCodeImagesImageIdDelete: function(t, r, a, o) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, Xn(i).v1GameThumbnailsGamesGameIdLanguageCodesLanguageCodeImagesImageIdDelete(t, r, a, o)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1GameThumbnailsGamesGameIdLanguageCodesLanguageCodeImagesOrderPost: function(t, r, a, o) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, Xn(i).v1GameThumbnailsGamesGameIdLanguageCodesLanguageCodeImagesOrderPost(t, r, a, o)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    }
                }
            }

            function Yn() {
                return null !== Wn && Wn.apply(this, arguments) || this
            }

            function $n(l) {
                var e = this;
                return {
                    v1LocalizationtableAvailableLanguagesGet: function(i) {
                        return void 0 === i && (i = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                return t = Gt.Qc("/v1/localizationtable/available-languages", !0), l && (o = l.baseOptions), n = fn(fn({
                                    method: "GET"
                                }, o), i), r = {}, a = {}, t.query = fn(fn(fn({}, t.query), a), i.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), i.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1LocalizationtableGamesGameIdAssetsGenerationRequestPost: function(i, s) {
                        return void 0 === s && (s = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                if (null == i) throw new dn("gameId", "Required parameter gameId was null or undefined when calling v1LocalizationtableGamesGameIdAssetsGenerationRequestPost.");
                                return a = "/v1/localizationtable/games/{gameId}/assets-generation-request".replace("{gameId}", encodeURIComponent(String(i))), t = Gt.Qc(a, !0), l && (o = l.baseOptions), n = fn(fn({
                                    method: "POST"
                                }, o), s), r = {}, a = {}, t.query = fn(fn(fn({}, t.query), a), s.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), s.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1LocalizationtableGametablesGameIdPatch: function(i, s, u) {
                        return void 0 === u && (u = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                if (null == i) throw new dn("gameId", "Required parameter gameId was null or undefined when calling v1LocalizationtableGametablesGameIdPatch.");
                                if (null == s) throw new dn("request", "Required parameter request was null or undefined when calling v1LocalizationtableGametablesGameIdPatch.");
                                return r = "/v1/localizationtable/gametables/{gameId}".replace("{gameId}", encodeURIComponent(String(i))), t = Gt.Qc(r, !0), l && (o = l.baseOptions), n = fn(fn({
                                    method: "PATCH"
                                }, o), u), a = {}, (r = {})["Content-Type"] = "application/json", t.query = fn(fn(fn({}, t.query), a), u.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), u.headers), o = "string" != typeof s || "application/json" === n.headers["Content-Type"], n.data = o ? JSON.stringify(void 0 !== s ? s : {}) : s || "", [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1LocalizationtableTablesGet: function(i, s) {
                        return void 0 === s && (s = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                if (null == i) throw new dn("assetId", "Required parameter assetId was null or undefined when calling v1LocalizationtableTablesGet.");
                                return t = Gt.Qc("/v1/localizationtable/tables", !0), l && (o = l.baseOptions), n = fn(fn({
                                    method: "GET"
                                }, o), s), r = {}, a = {}, void 0 !== i && (a.assetId = i), t.query = fn(fn(fn({}, t.query), a), s.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), s.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1LocalizationtableTablesPost: function(i, s) {
                        return void 0 === s && (s = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                if (null == i) throw new dn("request", "Required parameter request was null or undefined when calling v1LocalizationtableTablesPost.");
                                return t = Gt.Qc("/v1/localizationtable/tables", !0), l && (o = l.baseOptions), n = fn(fn({
                                    method: "POST"
                                }, o), s), a = {}, (r = {})["Content-Type"] = "application/json", t.query = fn(fn(fn({}, t.query), a), s.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), s.headers), o = "string" != typeof i || "application/json" === n.headers["Content-Type"], n.data = o ? JSON.stringify(void 0 !== i ? i : {}) : i || "", [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1LocalizationtableTablesTableIdEntriesGet: function(i, s, u, c) {
                        return void 0 === c && (c = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                if (null == i) throw new dn("tableId", "Required parameter tableId was null or undefined when calling v1LocalizationtableTablesTableIdEntriesGet.");
                                return a = "/v1/localizationtable/tables/{tableId}/entries".replace("{tableId}", encodeURIComponent(String(i))), t = Gt.Qc(a, !0), l && (o = l.baseOptions), n = fn(fn({
                                    method: "GET"
                                }, o), c), r = {}, a = {}, void 0 !== s && (a.cursor = s), void 0 !== u && (a.gameId = u), t.query = fn(fn(fn({}, t.query), a), c.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), c.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1LocalizationtableTablesTableIdEntriesTranslationHistoryPost: function(i, s, u, c) {
                        return void 0 === c && (c = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                if (null == i) throw new dn("tableId", "Required parameter tableId was null or undefined when calling v1LocalizationtableTablesTableIdEntriesTranslationHistoryPost.");
                                if (null == s) throw new dn("request", "Required parameter request was null or undefined when calling v1LocalizationtableTablesTableIdEntriesTranslationHistoryPost.");
                                return a = "/v1/localizationtable/tables/{tableId}/entries/translation-history".replace("{tableId}", encodeURIComponent(String(i))), t = Gt.Qc(a, !0), l && (o = l.baseOptions), n = fn(fn({
                                    method: "POST"
                                }, o), c), r = {}, a = {}, void 0 !== u && (a.gameId = u), r["Content-Type"] = "application/json", t.query = fn(fn(fn({}, t.query), a), c.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), c.headers), o = "string" != typeof s || "application/json" === n.headers["Content-Type"], n.data = o ? JSON.stringify(void 0 !== s ? s : {}) : s || "", [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1LocalizationtableTablesTableIdEntryCountGet: function(i, s, u) {
                        return void 0 === u && (u = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                if (null == i) throw new dn("tableId", "Required parameter tableId was null or undefined when calling v1LocalizationtableTablesTableIdEntryCountGet.");
                                return a = "/v1/localizationtable/tables/{tableId}/entry-count".replace("{tableId}", encodeURIComponent(String(i))), t = Gt.Qc(a, !0), l && (o = l.baseOptions), n = fn(fn({
                                    method: "GET"
                                }, o), u), r = {}, a = {}, void 0 !== s && (a.gameId = s), t.query = fn(fn(fn({}, t.query), a), u.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), u.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1LocalizationtableTablesTableIdGet: function(i, s) {
                        return void 0 === s && (s = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                if (null == i) throw new dn("tableId", "Required parameter tableId was null or undefined when calling v1LocalizationtableTablesTableIdGet.");
                                return a = "/v1/localizationtable/tables/{tableId}".replace("{tableId}", encodeURIComponent(String(i))), t = Gt.Qc(a, !0), l && (o = l.baseOptions), n = fn(fn({
                                    method: "GET"
                                }, o), s), r = {}, a = {}, t.query = fn(fn(fn({}, t.query), a), s.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), s.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1LocalizationtableTablesTableIdPatch: function(i, s, u, c) {
                        return void 0 === c && (c = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                if (null == i) throw new dn("tableId", "Required parameter tableId was null or undefined when calling v1LocalizationtableTablesTableIdPatch.");
                                if (null == s) throw new dn("request", "Required parameter request was null or undefined when calling v1LocalizationtableTablesTableIdPatch.");
                                return a = "/v1/localizationtable/tables/{tableId}".replace("{tableId}", encodeURIComponent(String(i))), t = Gt.Qc(a, !0), l && (o = l.baseOptions), n = fn(fn({
                                    method: "PATCH"
                                }, o), c), r = {}, a = {}, void 0 !== u && (a.gameId = u), r["Content-Type"] = "application/json", t.query = fn(fn(fn({}, t.query), a), c.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), c.headers), o = "string" != typeof s || "application/json" === n.headers["Content-Type"], n.data = o ? JSON.stringify(void 0 !== s ? s : {}) : s || "", [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    }
                }
            }

            function Zn(i) {
                return {
                    v1LocalizationtableAvailableLanguagesGet: function(t) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, $n(i).v1LocalizationtableAvailableLanguagesGet(t)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1LocalizationtableGamesGameIdAssetsGenerationRequestPost: function(t, r) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, $n(i).v1LocalizationtableGamesGameIdAssetsGenerationRequestPost(t, r)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1LocalizationtableGametablesGameIdPatch: function(t, r, a) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, $n(i).v1LocalizationtableGametablesGameIdPatch(t, r, a)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1LocalizationtableTablesGet: function(t, r) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, $n(i).v1LocalizationtableTablesGet(t, r)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1LocalizationtableTablesPost: function(t, r) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, $n(i).v1LocalizationtableTablesPost(t, r)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1LocalizationtableTablesTableIdEntriesGet: function(t, r, a, o) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, $n(i).v1LocalizationtableTablesTableIdEntriesGet(t, r, a, o)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1LocalizationtableTablesTableIdEntriesTranslationHistoryPost: function(t, r, a, o) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, $n(i).v1LocalizationtableTablesTableIdEntriesTranslationHistoryPost(t, r, a, o)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1LocalizationtableTablesTableIdEntryCountGet: function(t, r, a) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, $n(i).v1LocalizationtableTablesTableIdEntryCountGet(t, r, a)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1LocalizationtableTablesTableIdGet: function(t, r) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, $n(i).v1LocalizationtableTablesTableIdGet(t, r)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1LocalizationtableTablesTableIdPatch: function(t, r, a, o) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, $n(i).v1LocalizationtableTablesTableIdPatch(t, r, a, o)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    }
                }
            }
            oe(Kn, zn = ae), Kn.prototype.v1GamePassesGamePassIdDescriptionLanguageCodesLanguageCodePatch = function(e, t, n, r) {
                var a = this;
                return Qn(this.configuration).v1GamePassesGamePassIdDescriptionLanguageCodesLanguageCodePatch(e, t, n, r).then(function(e) {
                    return e(a.axios, a.basePath)
                })
            }, Kn.prototype.v1GamePassesGamePassIdIconsGet = function(e, t, n, r) {
                var a = this;
                return Qn(this.configuration).v1GamePassesGamePassIdIconsGet(e, t, n, r).then(function(e) {
                    return e(a.axios, a.basePath)
                })
            }, Kn.prototype.v1GamePassesGamePassIdIconsLanguageCodesLanguageCodeDelete = function(e, t, n) {
                var r = this;
                return Qn(this.configuration).v1GamePassesGamePassIdIconsLanguageCodesLanguageCodeDelete(e, t, n).then(function(e) {
                    return e(r.axios, r.basePath)
                })
            }, Kn.prototype.v1GamePassesGamePassIdIconsLanguageCodesLanguageCodePost = function(e, t, n, r) {
                var a = this;
                return Qn(this.configuration).v1GamePassesGamePassIdIconsLanguageCodesLanguageCodePost(e, t, n, r).then(function(e) {
                    return e(a.axios, a.basePath)
                })
            }, Kn.prototype.v1GamePassesGamePassIdNameDescriptionGet = function(e, t) {
                var n = this;
                return Qn(this.configuration).v1GamePassesGamePassIdNameDescriptionGet(e, t).then(function(e) {
                    return e(n.axios, n.basePath)
                })
            }, Kn.prototype.v1GamePassesGamePassIdNameDescriptionLanguageCodesLanguageCodeDelete = function(e, t, n) {
                var r = this;
                return Qn(this.configuration).v1GamePassesGamePassIdNameDescriptionLanguageCodesLanguageCodeDelete(e, t, n).then(function(e) {
                    return e(r.axios, r.basePath)
                })
            }, Kn.prototype.v1GamePassesGamePassIdNameDescriptionLanguageCodesLanguageCodePatch = function(e, t, n, r) {
                var a = this;
                return Qn(this.configuration).v1GamePassesGamePassIdNameDescriptionLanguageCodesLanguageCodePatch(e, t, n, r).then(function(e) {
                    return e(a.axios, a.basePath)
                })
            }, Kn.prototype.v1GamePassesGamePassIdNameLanguageCodesLanguageCodePatch = function(e, t, n, r) {
                var a = this;
                return Qn(this.configuration).v1GamePassesGamePassIdNameLanguageCodesLanguageCodePatch(e, t, n, r).then(function(e) {
                    return e(a.axios, a.basePath)
                })
            }, oe(Yn, Wn = ae), Yn.prototype.v1GameThumbnailsGamesGameIdImagesGet = function(e, t, n, r) {
                var a = this;
                return Jn(this.configuration).v1GameThumbnailsGamesGameIdImagesGet(e, t, n, r).then(function(e) {
                    return e(a.axios, a.basePath)
                })
            }, Yn.prototype.v1GameThumbnailsGamesGameIdLanguageCodesLanguageCodeImagePost = function(e, t, n, r) {
                var a = this;
                return Jn(this.configuration).v1GameThumbnailsGamesGameIdLanguageCodesLanguageCodeImagePost(e, t, n, r).then(function(e) {
                    return e(a.axios, a.basePath)
                })
            }, Yn.prototype.v1GameThumbnailsGamesGameIdLanguageCodesLanguageCodeImagesImageIdDelete = function(e, t, n, r) {
                var a = this;
                return Jn(this.configuration).v1GameThumbnailsGamesGameIdLanguageCodesLanguageCodeImagesImageIdDelete(e, t, n, r).then(function(e) {
                    return e(a.axios, a.basePath)
                })
            }, Yn.prototype.v1GameThumbnailsGamesGameIdLanguageCodesLanguageCodeImagesOrderPost = function(e, t, n, r) {
                var a = this;
                return Jn(this.configuration).v1GameThumbnailsGamesGameIdLanguageCodesLanguageCodeImagesOrderPost(e, t, n, r).then(function(e) {
                    return e(a.axios, a.basePath)
                })
            };
            var er, tr, nr, R = (oe(rr, er = ae), rr.prototype.v1LocalizationtableAvailableLanguagesGet = function(e) {
                var t = this;
                return Zn(this.configuration).v1LocalizationtableAvailableLanguagesGet(e).then(function(e) {
                    return e(t.axios, t.basePath)
                })
            }, rr.prototype.v1LocalizationtableGamesGameIdAssetsGenerationRequestPost = function(e, t) {
                var n = this;
                return Zn(this.configuration).v1LocalizationtableGamesGameIdAssetsGenerationRequestPost(e, t).then(function(e) {
                    return e(n.axios, n.basePath)
                })
            }, rr.prototype.v1LocalizationtableGametablesGameIdPatch = function(e, t, n) {
                var r = this;
                return Zn(this.configuration).v1LocalizationtableGametablesGameIdPatch(e, t, n).then(function(e) {
                    return e(r.axios, r.basePath)
                })
            }, rr.prototype.v1LocalizationtableTablesGet = function(e, t) {
                var n = this;
                return Zn(this.configuration).v1LocalizationtableTablesGet(e, t).then(function(e) {
                    return e(n.axios, n.basePath)
                })
            }, rr.prototype.v1LocalizationtableTablesPost = function(e, t) {
                var n = this;
                return Zn(this.configuration).v1LocalizationtableTablesPost(e, t).then(function(e) {
                    return e(n.axios, n.basePath)
                })
            }, rr.prototype.v1LocalizationtableTablesTableIdEntriesGet = function(e, t, n, r) {
                var a = this;
                return Zn(this.configuration).v1LocalizationtableTablesTableIdEntriesGet(e, t, n, r).then(function(e) {
                    return e(a.axios, a.basePath)
                })
            }, rr.prototype.v1LocalizationtableTablesTableIdEntriesTranslationHistoryPost = function(e, t, n, r) {
                var a = this;
                return Zn(this.configuration).v1LocalizationtableTablesTableIdEntriesTranslationHistoryPost(e, t, n, r).then(function(e) {
                    return e(a.axios, a.basePath)
                })
            }, rr.prototype.v1LocalizationtableTablesTableIdEntryCountGet = function(e, t, n) {
                var r = this;
                return Zn(this.configuration).v1LocalizationtableTablesTableIdEntryCountGet(e, t, n).then(function(e) {
                    return e(r.axios, r.basePath)
                })
            }, rr.prototype.v1LocalizationtableTablesTableIdGet = function(e, t) {
                var n = this;
                return Zn(this.configuration).v1LocalizationtableTablesTableIdGet(e, t).then(function(e) {
                    return e(n.axios, n.basePath)
                })
            }, rr.prototype.v1LocalizationtableTablesTableIdPatch = function(e, t, n, r) {
                var a = this;
                return Zn(this.configuration).v1LocalizationtableTablesTableIdPatch(e, t, n, r).then(function(e) {
                    return e(a.axios, a.basePath)
                })
            }, rr);

            function rr() {
                return null !== er && er.apply(this, arguments) || this
            }

            function ar(c) {
                var e = this;
                return {
                    v1NameDescriptionGamesGameIdGet: function(i, s) {
                        return void 0 === s && (s = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                if (null == i) throw new dn("gameId", "Required parameter gameId was null or undefined when calling v1NameDescriptionGamesGameIdGet.");
                                return a = "/v1/name-description/games/{gameId}".replace("{gameId}", encodeURIComponent(String(i))), t = Gt.Qc(a, !0), c && (o = c.baseOptions), n = fn(fn({
                                    method: "GET"
                                }, o), s), r = {}, a = {}, t.query = fn(fn(fn({}, t.query), a), s.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), s.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1NameDescriptionGamesGameIdHistoryPost: function(i, s, u) {
                        return void 0 === u && (u = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                if (null == i) throw new dn("gameId", "Required parameter gameId was null or undefined when calling v1NameDescriptionGamesGameIdHistoryPost.");
                                if (null == s) throw new dn("request", "Required parameter request was null or undefined when calling v1NameDescriptionGamesGameIdHistoryPost.");
                                return r = "/v1/name-description/games/{gameId}/history".replace("{gameId}", encodeURIComponent(String(i))), t = Gt.Qc(r, !0), c && (o = c.baseOptions), n = fn(fn({
                                    method: "POST"
                                }, o), u), a = {}, (r = {})["Content-Type"] = "application/json", t.query = fn(fn(fn({}, t.query), a), u.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), u.headers), o = "string" != typeof s || "application/json" === n.headers["Content-Type"], n.data = o ? JSON.stringify(void 0 !== s ? s : {}) : s || "", [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1NameDescriptionGamesGameIdPatch: function(i, s, u) {
                        return void 0 === u && (u = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                if (null == i) throw new dn("gameId", "Required parameter gameId was null or undefined when calling v1NameDescriptionGamesGameIdPatch.");
                                if (null == s) throw new dn("request", "Required parameter request was null or undefined when calling v1NameDescriptionGamesGameIdPatch.");
                                return r = "/v1/name-description/games/{gameId}".replace("{gameId}", encodeURIComponent(String(i))), t = Gt.Qc(r, !0), c && (o = c.baseOptions), n = fn(fn({
                                    method: "PATCH"
                                }, o), u), a = {}, (r = {})["Content-Type"] = "application/json", t.query = fn(fn(fn({}, t.query), a), u.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), u.headers), o = "string" != typeof s || "application/json" === n.headers["Content-Type"], n.data = o ? JSON.stringify(void 0 !== s ? s : {}) : s || "", [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1NameDescriptionMetadataGet: function(i) {
                        return void 0 === i && (i = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                return t = Gt.Qc("/v1/name-description/metadata", !0), c && (o = c.baseOptions), n = fn(fn({
                                    method: "GET"
                                }, o), i), r = {}, a = {}, t.query = fn(fn(fn({}, t.query), a), i.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), i.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    }
                }
            }

            function or(o) {
                return {
                    v1NameDescriptionGamesGameIdGet: function(t, r) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, ar(o).v1NameDescriptionGamesGameIdGet(t, r)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1NameDescriptionGamesGameIdHistoryPost: function(t, r, a) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, ar(o).v1NameDescriptionGamesGameIdHistoryPost(t, r, a)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1NameDescriptionGamesGameIdPatch: function(t, r, a) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, ar(o).v1NameDescriptionGamesGameIdPatch(t, r, a)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1NameDescriptionMetadataGet: function(t) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, ar(o).v1NameDescriptionMetadataGet(t)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    }
                }
            }

            function ir() {
                return null !== tr && tr.apply(this, arguments) || this
            }

            function sr(l) {
                var e = this;
                return {
                    v1PlayerPoliciesAllValuesGet: function(i) {
                        return void 0 === i && (i = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                return t = Gt.Qc("/v1/player-policies/all-values", !0), l && (o = l.baseOptions), n = fn(fn({
                                    method: "GET"
                                }, o), i), r = {}, a = {}, t.query = fn(fn(fn({}, t.query), a), i.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), i.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1PlayerPoliciesClientGet: function(i) {
                        return void 0 === i && (i = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                return t = Gt.Qc("/v1/player-policies-client", !0), l && (o = l.baseOptions), n = fn(fn({
                                    method: "GET"
                                }, o), i), r = {}, a = {}, t.query = fn(fn(fn({}, t.query), a), i.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), i.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1PlayerPoliciesRccGet: function(i, s, u, c) {
                        return void 0 === c && (c = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                if (null == i) throw new dn("userId", "Required parameter userId was null or undefined when calling v1PlayerPoliciesRccGet.");
                                if (null == s) throw new dn("ipAddress", "Required parameter ipAddress was null or undefined when calling v1PlayerPoliciesRccGet.");
                                if (null == u) throw new dn("userAgent", "Required parameter userAgent was null or undefined when calling v1PlayerPoliciesRccGet.");
                                return t = Gt.Qc("/v1/player-policies-rcc", !0), l && (o = l.baseOptions), n = fn(fn({
                                    method: "GET"
                                }, o), c), r = {}, a = {}, void 0 !== i && (a.userId = i), void 0 !== s && (a.ipAddress = s), void 0 !== u && (a.userAgent = u), t.query = fn(fn(fn({}, t.query), a), c.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), c.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    }
                }
            }

            function ur(i) {
                return {
                    v1PlayerPoliciesAllValuesGet: function(t) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, sr(i).v1PlayerPoliciesAllValuesGet(t)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1PlayerPoliciesClientGet: function(t) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, sr(i).v1PlayerPoliciesClientGet(t)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1PlayerPoliciesRccGet: function(t, r, a, o) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, sr(i).v1PlayerPoliciesRccGet(t, r, a, o)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    }
                }
            }

            function cr() {
                return null !== nr && nr.apply(this, arguments) || this
            }

            function lr(c) {
                var e = this;
                return {
                    v1SourceLanguageGamesGameIdGet: function(i, s) {
                        return void 0 === s && (s = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                if (null == i) throw new dn("gameId", "Required parameter gameId was null or undefined when calling v1SourceLanguageGamesGameIdGet.");
                                return a = "/v1/source-language/games/{gameId}".replace("{gameId}", encodeURIComponent(String(i))), t = Gt.Qc(a, !0), c && (o = c.baseOptions), n = fn(fn({
                                    method: "GET"
                                }, o), s), r = {}, a = {}, t.query = fn(fn(fn({}, t.query), a), s.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), s.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1SourceLanguageGamesGameIdPatch: function(i, s, u) {
                        return void 0 === u && (u = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                if (null == i) throw new dn("gameId", "Required parameter gameId was null or undefined when calling v1SourceLanguageGamesGameIdPatch.");
                                if (null == s) throw new dn("languageCode", "Required parameter languageCode was null or undefined when calling v1SourceLanguageGamesGameIdPatch.");
                                return a = "/v1/source-language/games/{gameId}".replace("{gameId}", encodeURIComponent(String(i))), t = Gt.Qc(a, !0), c && (o = c.baseOptions), n = fn(fn({
                                    method: "PATCH"
                                }, o), u), r = {}, a = {}, void 0 !== s && (a.languageCode = s), t.query = fn(fn(fn({}, t.query), a), u.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), u.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    }
                }
            }

            function dr(o) {
                return {
                    v1SourceLanguageGamesGameIdGet: function(t, r) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, lr(o).v1SourceLanguageGamesGameIdGet(t, r)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1SourceLanguageGamesGameIdPatch: function(t, r, a) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, lr(o).v1SourceLanguageGamesGameIdPatch(t, r, a)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    }
                }
            }
            oe(ir, tr = ae), ir.prototype.v1NameDescriptionGamesGameIdGet = function(e, t) {
                var n = this;
                return or(this.configuration).v1NameDescriptionGamesGameIdGet(e, t).then(function(e) {
                    return e(n.axios, n.basePath)
                })
            }, ir.prototype.v1NameDescriptionGamesGameIdHistoryPost = function(e, t, n) {
                var r = this;
                return or(this.configuration).v1NameDescriptionGamesGameIdHistoryPost(e, t, n).then(function(e) {
                    return e(r.axios, r.basePath)
                })
            }, ir.prototype.v1NameDescriptionGamesGameIdPatch = function(e, t, n) {
                var r = this;
                return or(this.configuration).v1NameDescriptionGamesGameIdPatch(e, t, n).then(function(e) {
                    return e(r.axios, r.basePath)
                })
            }, ir.prototype.v1NameDescriptionMetadataGet = function(e) {
                var t = this;
                return or(this.configuration).v1NameDescriptionMetadataGet(e).then(function(e) {
                    return e(t.axios, t.basePath)
                })
            }, oe(cr, nr = ae), cr.prototype.v1PlayerPoliciesAllValuesGet = function(e) {
                var t = this;
                return ur(this.configuration).v1PlayerPoliciesAllValuesGet(e).then(function(e) {
                    return e(t.axios, t.basePath)
                })
            }, cr.prototype.v1PlayerPoliciesClientGet = function(e) {
                var t = this;
                return ur(this.configuration).v1PlayerPoliciesClientGet(e).then(function(e) {
                    return e(t.axios, t.basePath)
                })
            }, cr.prototype.v1PlayerPoliciesRccGet = function(e, t, n, r) {
                var a = this;
                return ur(this.configuration).v1PlayerPoliciesRccGet(e, t, n, r).then(function(e) {
                    return e(a.axios, a.basePath)
                })
            };
            var hr, z = (oe(vr, hr = ae), vr.prototype.v1SourceLanguageGamesGameIdGet = function(e, t) {
                var n = this;
                return dr(this.configuration).v1SourceLanguageGamesGameIdGet(e, t).then(function(e) {
                    return e(n.axios, n.basePath)
                })
            }, vr.prototype.v1SourceLanguageGamesGameIdPatch = function(e, t, n) {
                var r = this;
                return dr(this.configuration).v1SourceLanguageGamesGameIdPatch(e, t, n).then(function(e) {
                    return e(r.axios, r.basePath)
                })
            }, vr);

            function vr() {
                return null !== hr && hr.apply(this, arguments) || this
            }

            function pr(l) {
                var e = this;
                return {
                    v1SupportedLanguagesGamesGameIdAutomaticTranslationStatusGet: function(i, s) {
                        return void 0 === s && (s = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                if (null == i) throw new dn("gameId", "Required parameter gameId was null or undefined when calling v1SupportedLanguagesGamesGameIdAutomaticTranslationStatusGet.");
                                return a = "/v1/supported-languages/games/{gameId}/automatic-translation-status".replace("{gameId}", encodeURIComponent(String(i))), t = Gt.Qc(a, !0), l && (o = l.baseOptions), n = fn(fn({
                                    method: "GET"
                                }, o), s), r = {}, a = {}, t.query = fn(fn(fn({}, t.query), a), s.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), s.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1SupportedLanguagesGamesGameIdGet: function(i, s) {
                        return void 0 === s && (s = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                if (null == i) throw new dn("gameId", "Required parameter gameId was null or undefined when calling v1SupportedLanguagesGamesGameIdGet.");
                                return a = "/v1/supported-languages/games/{gameId}".replace("{gameId}", encodeURIComponent(String(i))), t = Gt.Qc(a, !0), l && (o = l.baseOptions), n = fn(fn({
                                    method: "GET"
                                }, o), s), r = {}, a = {}, t.query = fn(fn(fn({}, t.query), a), s.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), s.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1SupportedLanguagesGamesGameIdLanguagesLanguageCodeAutomaticTranslationStatusPatch: function(i, s, u, c) {
                        return void 0 === c && (c = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                if (null == i) throw new dn("gameId", "Required parameter gameId was null or undefined when calling v1SupportedLanguagesGamesGameIdLanguagesLanguageCodeAutomaticTranslationStatusPatch.");
                                if (null == s) throw new dn("languageCode", "Required parameter languageCode was null or undefined when calling v1SupportedLanguagesGamesGameIdLanguagesLanguageCodeAutomaticTranslationStatusPatch.");
                                if (null == u) throw new dn("enableAutomaticTranslation", "Required parameter enableAutomaticTranslation was null or undefined when calling v1SupportedLanguagesGamesGameIdLanguagesLanguageCodeAutomaticTranslationStatusPatch.");
                                return r = "/v1/supported-languages/games/{gameId}/languages/{languageCode}/automatic-translation-status".replace("{gameId}", encodeURIComponent(String(i))).replace("{languageCode}", encodeURIComponent(String(s))), t = Gt.Qc(r, !0), l && (o = l.baseOptions), n = fn(fn({
                                    method: "PATCH"
                                }, o), c), a = {}, (r = {})["Content-Type"] = "application/json", t.query = fn(fn(fn({}, t.query), a), c.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), c.headers), o = "string" != typeof u || "application/json" === n.headers["Content-Type"], n.data = o ? JSON.stringify(void 0 !== u ? u : {}) : u || "", [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1SupportedLanguagesGamesGameIdLanguagesLanguageCodeUniverseDisplayInfoAutomaticTranslationSettingsPatch: function(i, s, u, c) {
                        return void 0 === c && (c = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                if (null == i) throw new dn("gameId", "Required parameter gameId was null or undefined when calling v1SupportedLanguagesGamesGameIdLanguagesLanguageCodeUniverseDisplayInfoAutomaticTranslationSettingsPatch.");
                                if (null == s) throw new dn("languageCode", "Required parameter languageCode was null or undefined when calling v1SupportedLanguagesGamesGameIdLanguagesLanguageCodeUniverseDisplayInfoAutomaticTranslationSettingsPatch.");
                                if (null == u) throw new dn("enableUniverseDisplayInfoAutomaticTranslation", "Required parameter enableUniverseDisplayInfoAutomaticTranslation was null or undefined when calling v1SupportedLanguagesGamesGameIdLanguagesLanguageCodeUniverseDisplayInfoAutomaticTranslationSettingsPatch.");
                                return r = "/v1/supported-languages/games/{gameId}/languages/{languageCode}/universe-display-info-automatic-translation-settings".replace("{gameId}", encodeURIComponent(String(i))).replace("{languageCode}", encodeURIComponent(String(s))), t = Gt.Qc(r, !0), l && (o = l.baseOptions), n = fn(fn({
                                    method: "PATCH"
                                }, o), c), a = {}, (r = {})["Content-Type"] = "application/json", t.query = fn(fn(fn({}, t.query), a), c.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), c.headers), o = "string" != typeof u || "application/json" === n.headers["Content-Type"], n.data = o ? JSON.stringify(void 0 !== u ? u : {}) : u || "", [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1SupportedLanguagesGamesGameIdPatch: function(i, s, u) {
                        return void 0 === u && (u = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                if (null == i) throw new dn("gameId", "Required parameter gameId was null or undefined when calling v1SupportedLanguagesGamesGameIdPatch.");
                                if (null == s) throw new dn("languages", "Required parameter languages was null or undefined when calling v1SupportedLanguagesGamesGameIdPatch.");
                                return r = "/v1/supported-languages/games/{gameId}".replace("{gameId}", encodeURIComponent(String(i))), t = Gt.Qc(r, !0), l && (o = l.baseOptions), n = fn(fn({
                                    method: "PATCH"
                                }, o), u), a = {}, (r = {})["Content-Type"] = "application/json", t.query = fn(fn(fn({}, t.query), a), u.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), u.headers), o = "string" != typeof s || "application/json" === n.headers["Content-Type"], n.data = o ? JSON.stringify(void 0 !== s ? s : {}) : s || "", [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1SupportedLanguagesGamesGameIdUniverseDisplayInfoAutomaticTranslationSettingsGet: function(i, s) {
                        return void 0 === s && (s = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                if (null == i) throw new dn("gameId", "Required parameter gameId was null or undefined when calling v1SupportedLanguagesGamesGameIdUniverseDisplayInfoAutomaticTranslationSettingsGet.");
                                return a = "/v1/supported-languages/games/{gameId}/universe-display-info-automatic-translation-settings".replace("{gameId}", encodeURIComponent(String(i))), t = Gt.Qc(a, !0), l && (o = l.baseOptions), n = fn(fn({
                                    method: "GET"
                                }, o), s), r = {}, a = {}, t.query = fn(fn(fn({}, t.query), a), s.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), s.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1SupportedLanguagesMetadataGet: function(i) {
                        return void 0 === i && (i = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                return t = Gt.Qc("/v1/supported-languages/metadata", !0), l && (o = l.baseOptions), n = fn(fn({
                                    method: "GET"
                                }, o), i), r = {}, a = {}, t.query = fn(fn(fn({}, t.query), a), i.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), i.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    }
                }
            }

            function fr(i) {
                return {
                    v1SupportedLanguagesGamesGameIdAutomaticTranslationStatusGet: function(t, r) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, pr(i).v1SupportedLanguagesGamesGameIdAutomaticTranslationStatusGet(t, r)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1SupportedLanguagesGamesGameIdGet: function(t, r) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, pr(i).v1SupportedLanguagesGamesGameIdGet(t, r)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1SupportedLanguagesGamesGameIdLanguagesLanguageCodeAutomaticTranslationStatusPatch: function(t, r, a, o) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, pr(i).v1SupportedLanguagesGamesGameIdLanguagesLanguageCodeAutomaticTranslationStatusPatch(t, r, a, o)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1SupportedLanguagesGamesGameIdLanguagesLanguageCodeUniverseDisplayInfoAutomaticTranslationSettingsPatch: function(t, r, a, o) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, pr(i).v1SupportedLanguagesGamesGameIdLanguagesLanguageCodeUniverseDisplayInfoAutomaticTranslationSettingsPatch(t, r, a, o)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1SupportedLanguagesGamesGameIdPatch: function(t, r, a) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, pr(i).v1SupportedLanguagesGamesGameIdPatch(t, r, a)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1SupportedLanguagesGamesGameIdUniverseDisplayInfoAutomaticTranslationSettingsGet: function(t, r) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, pr(i).v1SupportedLanguagesGamesGameIdUniverseDisplayInfoAutomaticTranslationSettingsGet(t, r)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1SupportedLanguagesMetadataGet: function(t) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, pr(i).v1SupportedLanguagesMetadataGet(t)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    }
                }
            }
            var mr, fe = (oe(gr, mr = ae), gr.prototype.v1SupportedLanguagesGamesGameIdAutomaticTranslationStatusGet = function(e, t) {
                var n = this;
                return fr(this.configuration).v1SupportedLanguagesGamesGameIdAutomaticTranslationStatusGet(e, t).then(function(e) {
                    return e(n.axios, n.basePath)
                })
            }, gr.prototype.v1SupportedLanguagesGamesGameIdGet = function(e, t) {
                var n = this;
                return fr(this.configuration).v1SupportedLanguagesGamesGameIdGet(e, t).then(function(e) {
                    return e(n.axios, n.basePath)
                })
            }, gr.prototype.v1SupportedLanguagesGamesGameIdLanguagesLanguageCodeAutomaticTranslationStatusPatch = function(e, t, n, r) {
                var a = this;
                return fr(this.configuration).v1SupportedLanguagesGamesGameIdLanguagesLanguageCodeAutomaticTranslationStatusPatch(e, t, n, r).then(function(e) {
                    return e(a.axios, a.basePath)
                })
            }, gr.prototype.v1SupportedLanguagesGamesGameIdLanguagesLanguageCodeUniverseDisplayInfoAutomaticTranslationSettingsPatch = function(e, t, n, r) {
                var a = this;
                return fr(this.configuration).v1SupportedLanguagesGamesGameIdLanguagesLanguageCodeUniverseDisplayInfoAutomaticTranslationSettingsPatch(e, t, n, r).then(function(e) {
                    return e(a.axios, a.basePath)
                })
            }, gr.prototype.v1SupportedLanguagesGamesGameIdPatch = function(e, t, n) {
                var r = this;
                return fr(this.configuration).v1SupportedLanguagesGamesGameIdPatch(e, t, n).then(function(e) {
                    return e(r.axios, r.basePath)
                })
            }, gr.prototype.v1SupportedLanguagesGamesGameIdUniverseDisplayInfoAutomaticTranslationSettingsGet = function(e, t) {
                var n = this;
                return fr(this.configuration).v1SupportedLanguagesGamesGameIdUniverseDisplayInfoAutomaticTranslationSettingsGet(e, t).then(function(e) {
                    return e(n.axios, n.basePath)
                })
            }, gr.prototype.v1SupportedLanguagesMetadataGet = function(e) {
                var t = this;
                return fr(this.configuration).v1SupportedLanguagesMetadataGet(e).then(function(e) {
                    return e(t.axios, t.basePath)
                })
            }, gr);

            function gr() {
                return null !== mr && mr.apply(this, arguments) || this
            }

            function Ir(h) {
                var e = this;
                return {
                    v1TranslationAnalyticsGamesGameIdDownloadTranslationAnalyticsReportGet: function(i, s, u, c, l, d) {
                        return void 0 === d && (d = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                if (null == i) throw new dn("gameId", "Required parameter gameId was null or undefined when calling v1TranslationAnalyticsGamesGameIdDownloadTranslationAnalyticsReportGet.");
                                if (null == s) throw new dn("startDateTime", "Required parameter startDateTime was null or undefined when calling v1TranslationAnalyticsGamesGameIdDownloadTranslationAnalyticsReportGet.");
                                if (null == u) throw new dn("endDateTime", "Required parameter endDateTime was null or undefined when calling v1TranslationAnalyticsGamesGameIdDownloadTranslationAnalyticsReportGet.");
                                if (null == c) throw new dn("reportType", "Required parameter reportType was null or undefined when calling v1TranslationAnalyticsGamesGameIdDownloadTranslationAnalyticsReportGet.");
                                if (null == l) throw new dn("reportSubjectTargetId", "Required parameter reportSubjectTargetId was null or undefined when calling v1TranslationAnalyticsGamesGameIdDownloadTranslationAnalyticsReportGet.");
                                return a = "/v1/translation-analytics/games/{gameId}/download-translation-analytics-report".replace("{gameId}", encodeURIComponent(String(i))), t = Gt.Qc(a, !0), h && (o = h.baseOptions), n = fn(fn({
                                    method: "GET"
                                }, o), d), r = {}, a = {}, void 0 !== s && (a.startDateTime = s), void 0 !== u && (a.endDateTime = u), void 0 !== c && (a.reportType = c), void 0 !== l && (a.reportSubjectTargetId = l), t.query = fn(fn(fn({}, t.query), a), d.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), d.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1TranslationAnalyticsGamesGameIdRequestTranslationAnalyticsReportPost: function(i, s, u) {
                        return void 0 === u && (u = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                if (null == i) throw new dn("gameId", "Required parameter gameId was null or undefined when calling v1TranslationAnalyticsGamesGameIdRequestTranslationAnalyticsReportPost.");
                                if (null == s) throw new dn("request", "Required parameter request was null or undefined when calling v1TranslationAnalyticsGamesGameIdRequestTranslationAnalyticsReportPost.");
                                return r = "/v1/translation-analytics/games/{gameId}/request-translation-analytics-report".replace("{gameId}", encodeURIComponent(String(i))), t = Gt.Qc(r, !0), h && (o = h.baseOptions), n = fn(fn({
                                    method: "POST"
                                }, o), u), a = {}, (r = {})["Content-Type"] = "application/json", t.query = fn(fn(fn({}, t.query), a), u.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), u.headers), o = "string" != typeof s || "application/json" === n.headers["Content-Type"], n.data = o ? JSON.stringify(void 0 !== s ? s : {}) : s || "", [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    },
                    v1TranslationAnalyticsMetadataGet: function(i) {
                        return void 0 === i && (i = {}), mn(e, void 0, Promise, function() {
                            var t, n, r, a, o;
                            return gn(this, function(e) {
                                return t = Gt.Qc("/v1/translation-analytics/metadata", !0), h && (o = h.baseOptions), n = fn(fn({
                                    method: "GET"
                                }, o), i), r = {}, a = {}, t.query = fn(fn(fn({}, t.query), a), i.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), i.headers), [2, {
                                    url: Gt.WU(t),
                                    options: n
                                }]
                            })
                        })
                    }
                }
            }

            function yr(u) {
                return {
                    v1TranslationAnalyticsGamesGameIdDownloadTranslationAnalyticsReportGet: function(t, r, a, o, i, s) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, Ir(u).v1TranslationAnalyticsGamesGameIdDownloadTranslationAnalyticsReportGet(t, r, a, o, i, s)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1TranslationAnalyticsGamesGameIdRequestTranslationAnalyticsReportPost: function(t, r, a) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, Ir(u).v1TranslationAnalyticsGamesGameIdRequestTranslationAnalyticsReportPost(t, r, a)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    },
                    v1TranslationAnalyticsMetadataGet: function(t) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, Ir(u).v1TranslationAnalyticsMetadataGet(t)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    }
                }
            }
            var br, Pr, Z = (oe(Gr, br = ae), Gr.prototype.v1TranslationAnalyticsGamesGameIdDownloadTranslationAnalyticsReportGet = function(e, t, n, r, a, o) {
                var i = this;
                return yr(this.configuration).v1TranslationAnalyticsGamesGameIdDownloadTranslationAnalyticsReportGet(e, t, n, r, a, o).then(function(e) {
                    return e(i.axios, i.basePath)
                })
            }, Gr.prototype.v1TranslationAnalyticsGamesGameIdRequestTranslationAnalyticsReportPost = function(e, t, n) {
                var r = this;
                return yr(this.configuration).v1TranslationAnalyticsGamesGameIdRequestTranslationAnalyticsReportPost(e, t, n).then(function(e) {
                    return e(r.axios, r.basePath)
                })
            }, Gr.prototype.v1TranslationAnalyticsMetadataGet = function(e) {
                var t = this;
                return yr(this.configuration).v1TranslationAnalyticsMetadataGet(e).then(function(e) {
                    return e(t.axios, t.basePath)
                })
            }, Gr);

            function Gr() {
                return null !== br && br.apply(this, arguments) || this
            }

            function wr(r) {
                return {
                    v1UiConfigurationsGet: function(t) {
                        return mn(this, void 0, Promise, function() {
                            var n;
                            return gn(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, function(s) {
                                            var e = this;
                                            return {
                                                v1UiConfigurationsGet: function(i) {
                                                    return void 0 === i && (i = {}), mn(e, void 0, Promise, function() {
                                                        var t, n, r, a, o;
                                                        return gn(this, function(e) {
                                                            return t = Gt.Qc("/v1/ui-configurations", !0), s && (o = s.baseOptions), n = fn(fn({
                                                                method: "GET"
                                                            }, o), i), r = {}, a = {}, t.query = fn(fn(fn({}, t.query), a), i.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = fn(fn(fn({}, r), o), i.headers), [2, {
                                                                url: Gt.WU(t),
                                                                options: n
                                                            }]
                                                        })
                                                    })
                                                }
                                            }
                                        }(r).v1UiConfigurationsGet(t)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ln);
                                            t = fn(fn({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    }
                }
            }

            function Cr() {
                return null !== Pr && Pr.apply(this, arguments) || this
            }
            oe(Cr, Pr = ae), Cr.prototype.v1UiConfigurationsGet = function(e) {
                var t = this;
                return wr(this.configuration).v1UiConfigurationsGet(e).then(function(e) {
                    return e(t.axios, t.basePath)
                })
            };
            var Tr, Ar, X = (Tr = function(e, t) {
                    return (Tr = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function(e, t) {
                            e.__proto__ = t
                        } || function(e, t) {
                            for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
                        })(e, t)
                }, function(e, t) {
                    if ("function" != typeof t && null !== t) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");

                    function n() {
                        this.constructor = e
                    }
                    Tr(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                }),
                Sr = m.EnvironmentUrls.localizationTablesApi.replace(/\/+$/, ""),
                K = function(e, t, n) {
                    void 0 === t && (t = Sr), void 0 === n && (n = F), this.basePath = t, this.axios = n, e && (this.configuration = e, this.basePath = e.basePath || this.basePath)
                },
                Rr = (Ar = Error, X(Er, Ar), Er);

            function Er(e, t) {
                t = Ar.call(this, t) || this;
                return t.field = e, t.name = "RequiredError", t
            }

            function Lr(e, t, n) {
                if (null == n) throw new Rr(t, "Required parameter " + t + " was null or undefined when calling " + e + ".")
            }

            function Ur(e) {
                for (var t = [], n = 1; n < arguments.length; n++) t[n - 1] = arguments[n];
                for (var r = new URLSearchParams(e.search), a = 0, o = t; a < o.length; a++) {
                    var i, s = o[a];
                    for (i in s) r.set(i, s[i])
                }
                e.search = r.toString()
            }

            function qr(e, t, n) {
                var r = "string" != typeof e;
                return (r && n && n.isJsonMime ? n.isJsonMime(t.headers["Content-Type"]) : r) ? JSON.stringify(void 0 !== e ? e : {}) : e || ""
            }

            function Or(e) {
                return e.pathname + e.search + e.hash
            }

            function Dr(n, r, a, o) {
                return function(e, t) {
                    void 0 === e && (e = r), void 0 === t && (t = a);
                    t = _r(_r({}, n.options), {
                        url: ((null == o ? void 0 : o.basePath) || t) + n.url
                    });
                    return e.request(t)
                }
            }
            var xr, _r = function() {
                    return (_r = Object.assign || function(e) {
                        for (var t, n = 1, r = arguments.length; n < r; n++)
                            for (var a in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
                        return e
                    }).apply(this, arguments)
                },
                Br = "https://example.com",
                te = (xr = function(e, t) {
                    return (xr = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function(e, t) {
                            e.__proto__ = t
                        } || function(e, t) {
                            for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
                        })(e, t)
                }, function(e, t) {
                    if ("function" != typeof t && null !== t) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");

                    function n() {
                        this.constructor = e
                    }
                    xr(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                }),
                Fr = function() {
                    return (Fr = Object.assign || function(e) {
                        for (var t, n = 1, r = arguments.length; n < r; n++)
                            for (var a in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
                        return e
                    }).apply(this, arguments)
                },
                Nr = function(e, i, s, u) {
                    return new(s = s || Promise)(function(n, t) {
                        function r(e) {
                            try {
                                o(u.next(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function a(e) {
                            try {
                                o(u.throw(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function o(e) {
                            var t;
                            e.done ? n(e.value) : ((t = e.value) instanceof s ? t : new s(function(e) {
                                e(t)
                            })).then(r, a)
                        }
                        o((u = u.apply(e, i || [])).next())
                    })
                },
                kr = function(n, r) {
                    var a, o, i, s = {
                            label: 0,
                            sent: function() {
                                if (1 & i[0]) throw i[1];
                                return i[1]
                            },
                            trys: [],
                            ops: []
                        },
                        e = {
                            next: t(0),
                            throw: t(1),
                            return: t(2)
                        };
                    return "function" == typeof Symbol && (e[Symbol.iterator] = function() {
                        return this
                    }), e;

                    function t(t) {
                        return function(e) {
                            return function(t) {
                                if (a) throw new TypeError("Generator is already executing.");
                                for (; s;) try {
                                    if (a = 1, o && (i = 2 & t[0] ? o.return : t[0] ? o.throw || ((i = o.return) && i.call(o), 0) : o.next) && !(i = i.call(o, t[1])).done) return i;
                                    switch (o = 0, i && (t = [2 & t[0], i.value]), t[0]) {
                                        case 0:
                                        case 1:
                                            i = t;
                                            break;
                                        case 4:
                                            return s.label++, {
                                                value: t[1],
                                                done: !1
                                            };
                                        case 5:
                                            s.label++, o = t[1], t = [0];
                                            continue;
                                        case 7:
                                            t = s.ops.pop(), s.trys.pop();
                                            continue;
                                        default:
                                            if (!(i = 0 < (i = s.trys).length && i[i.length - 1]) && (6 === t[0] || 2 === t[0])) {
                                                s = 0;
                                                continue
                                            }
                                            if (3 === t[0] && (!i || t[1] > i[0] && t[1] < i[3])) {
                                                s.label = t[1];
                                                break
                                            }
                                            if (6 === t[0] && s.label < i[1]) {
                                                s.label = i[1], i = t;
                                                break
                                            }
                                            if (i && s.label < i[2]) {
                                                s.label = i[2], s.ops.push(t);
                                                break
                                            }
                                            i[2] && s.ops.pop(), s.trys.pop();
                                            continue
                                    }
                                    t = r.call(n, s)
                                } catch (e) {
                                    t = [6, e], o = 0
                                } finally {
                                    a = i = 0
                                }
                                if (5 & t[0]) throw t[1];
                                return {
                                    value: t[0] ? t[1] : void 0,
                                    done: !0
                                }
                            }([t, e])
                        }
                    }
                };

            function Mr(i) {
                var s = function(l) {
                    var e = this;
                    return {
                        v1AutoLocalizationTableGamesGameIdAssetsGenerationRequestPost: function(o, i) {
                            return void 0 === i && (i = {}), Nr(e, void 0, Promise, function() {
                                var t, n, r, a;
                                return kr(this, function(e) {
                                    return Lr("v1AutoLocalizationTableGamesGameIdAssetsGenerationRequestPost", "gameId", o), r = "/v1/auto-localization-table/games/{gameId}/assets-generation-request".replace("{gameId}", encodeURIComponent(String(o))), t = new URL(r, Br), l && (a = l.baseOptions), n = Fr(Fr({
                                        method: "POST"
                                    }, a), i), r = {}, Ur(t, {}, i.query), a = a && a.headers ? a.headers : {}, n.headers = Fr(Fr(Fr({}, r), a), i.headers), [2, {
                                        url: Or(t),
                                        options: n
                                    }]
                                })
                            })
                        },
                        v1AutoLocalizationTableGamesGameIdAutoScrapeCleanupRequestPost: function(i, s, u) {
                            return void 0 === u && (u = {}), Nr(e, void 0, Promise, function() {
                                var t, n, r, a, o;
                                return kr(this, function(e) {
                                    return Lr("v1AutoLocalizationTableGamesGameIdAutoScrapeCleanupRequestPost", "gameId", i), Lr("v1AutoLocalizationTableGamesGameIdAutoScrapeCleanupRequestPost", "request", s), r = "/v1/auto-localization-table/games/{gameId}/auto-scrape-cleanup-request".replace("{gameId}", encodeURIComponent(String(i))), t = new URL(r, Br), l && (o = l.baseOptions), n = Fr(Fr({
                                        method: "POST"
                                    }, o), u), a = {}, (r = {})["Content-Type"] = "application/json", Ur(t, a, u.query), o = o && o.headers ? o.headers : {}, n.headers = Fr(Fr(Fr({}, r), o), u.headers), n.data = qr(s, n, l), [2, {
                                        url: Or(t),
                                        options: n
                                    }]
                                })
                            })
                        },
                        v1AutoLocalizationTableGamesGameIdPatch: function(i, s, u, c) {
                            return void 0 === c && (c = {}), Nr(e, void 0, Promise, function() {
                                var t, n, r, a, o;
                                return kr(this, function(e) {
                                    return Lr("v1AutoLocalizationTableGamesGameIdPatch", "gameId", i), Lr("v1AutoLocalizationTableGamesGameIdPatch", "request", s), a = "/v1/auto-localization-table/games/{gameId}".replace("{gameId}", encodeURIComponent(String(i))), t = new URL(a, Br), l && (o = l.baseOptions), n = Fr(Fr({
                                        method: "PATCH"
                                    }, o), c), r = {}, a = {}, null != u && (r["Roblox-Game-Id"] = String(u)), r["Content-Type"] = "application/json", Ur(t, a, c.query), o = o && o.headers ? o.headers : {}, n.headers = Fr(Fr(Fr({}, r), o), c.headers), n.data = qr(s, n, l), [2, {
                                        url: Or(t),
                                        options: n
                                    }]
                                })
                            })
                        }
                    }
                }(i);
                return {
                    v1AutoLocalizationTableGamesGameIdAssetsGenerationRequestPost: function(n, r) {
                        return Nr(this, void 0, Promise, function() {
                            var t;
                            return kr(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, s.v1AutoLocalizationTableGamesGameIdAssetsGenerationRequestPost(n, r)];
                                    case 1:
                                        return t = e.sent(), [2, Dr(t, y(), Sr, i)]
                                }
                            })
                        })
                    },
                    v1AutoLocalizationTableGamesGameIdAutoScrapeCleanupRequestPost: function(n, r, a) {
                        return Nr(this, void 0, Promise, function() {
                            var t;
                            return kr(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, s.v1AutoLocalizationTableGamesGameIdAutoScrapeCleanupRequestPost(n, r, a)];
                                    case 1:
                                        return t = e.sent(), [2, Dr(t, y(), Sr, i)]
                                }
                            })
                        })
                    },
                    v1AutoLocalizationTableGamesGameIdPatch: function(n, r, a, o) {
                        return Nr(this, void 0, Promise, function() {
                            var t;
                            return kr(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, s.v1AutoLocalizationTableGamesGameIdPatch(n, r, a, o)];
                                    case 1:
                                        return t = e.sent(), [2, Dr(t, y(), Sr, i)]
                                }
                            })
                        })
                    }
                }
            }(re = {}).User = "User", re.Group = "Group", (ie = {}).Asc = "Asc", ie.Desc = "Desc", (pe = {}).User = "User", pe.Group = "Group", (I = {}).User = "User", I.Automation = "Automation";
            var jr, zr, Wr = (te(Vr, jr = K), Vr.prototype.v1AutoLocalizationTableGamesGameIdAssetsGenerationRequestPost = function(e, t) {
                var n = this;
                return Mr(this.configuration).v1AutoLocalizationTableGamesGameIdAssetsGenerationRequestPost(e, t).then(function(e) {
                    return e(n.axios, n.basePath)
                })
            }, Vr.prototype.v1AutoLocalizationTableGamesGameIdAutoScrapeCleanupRequestPost = function(e, t, n) {
                var r = this;
                return Mr(this.configuration).v1AutoLocalizationTableGamesGameIdAutoScrapeCleanupRequestPost(e, t, n).then(function(e) {
                    return e(r.axios, r.basePath)
                })
            }, Vr.prototype.v1AutoLocalizationTableGamesGameIdPatch = function(e, t, n, r) {
                var a = this;
                return Mr(this.configuration).v1AutoLocalizationTableGamesGameIdPatch(e, t, n, r).then(function(e) {
                    return e(a.axios, a.basePath)
                })
            }, Vr);

            function Vr() {
                return null !== jr && jr.apply(this, arguments) || this
            }

            function Hr(i) {
                var s = function(l) {
                    var e = this;
                    return {
                        v1LocalizationTableAvailableLanguagesGet: function(o) {
                            return void 0 === o && (o = {}), Nr(e, void 0, Promise, function() {
                                var t, n, r, a;
                                return kr(this, function(e) {
                                    return t = new URL("/v1/localization-table/available-languages", Br), l && (a = l.baseOptions), n = Fr(Fr({
                                        method: "GET"
                                    }, a), o), r = {}, Ur(t, {}, o.query), a = a && a.headers ? a.headers : {}, n.headers = Fr(Fr(Fr({}, r), a), o.headers), [2, {
                                        url: Or(t),
                                        options: n
                                    }]
                                })
                            })
                        },
                        v1LocalizationTableLimitsGet: function(o) {
                            return void 0 === o && (o = {}), Nr(e, void 0, Promise, function() {
                                var t, n, r, a;
                                return kr(this, function(e) {
                                    return t = new URL("/v1/localization-table/limits", Br), l && (a = l.baseOptions), n = Fr(Fr({
                                        method: "GET"
                                    }, a), o), r = {}, Ur(t, {}, o.query), a = a && a.headers ? a.headers : {}, n.headers = Fr(Fr(Fr({}, r), a), o.headers), [2, {
                                        url: Or(t),
                                        options: n
                                    }]
                                })
                            })
                        },
                        v1LocalizationTableMetadataGet: function(o) {
                            return void 0 === o && (o = {}), Nr(e, void 0, Promise, function() {
                                var t, n, r, a;
                                return kr(this, function(e) {
                                    return t = new URL("/v1/localization-table/metadata", Br), l && (a = l.baseOptions), n = Fr(Fr({
                                        method: "GET"
                                    }, a), o), r = {}, Ur(t, {}, o.query), a = a && a.headers ? a.headers : {}, n.headers = Fr(Fr(Fr({}, r), a), o.headers), [2, {
                                        url: Or(t),
                                        options: n
                                    }]
                                })
                            })
                        },
                        v1LocalizationTableTablesAssetIdGet: function(o, i) {
                            return void 0 === i && (i = {}), Nr(e, void 0, Promise, function() {
                                var t, n, r, a;
                                return kr(this, function(e) {
                                    return Lr("v1LocalizationTableTablesAssetIdGet", "assetId", o), r = "/v1/localization-table/tables/{assetId}".replace("{assetId}", encodeURIComponent(String(o))), t = new URL(r, Br), l && (a = l.baseOptions), n = Fr(Fr({
                                        method: "GET"
                                    }, a), i), r = {}, Ur(t, {}, i.query), a = a && a.headers ? a.headers : {}, n.headers = Fr(Fr(Fr({}, r), a), i.headers), [2, {
                                        url: Or(t),
                                        options: n
                                    }]
                                })
                            })
                        },
                        v1LocalizationTableTablesPost: function(i, s) {
                            return void 0 === s && (s = {}), Nr(e, void 0, Promise, function() {
                                var t, n, r, a, o;
                                return kr(this, function(e) {
                                    return Lr("v1LocalizationTableTablesPost", "request", i), t = new URL("/v1/localization-table/tables", Br), l && (o = l.baseOptions), n = Fr(Fr({
                                        method: "POST"
                                    }, o), s), a = {}, (r = {})["Content-Type"] = "application/json", Ur(t, a, s.query), o = o && o.headers ? o.headers : {}, n.headers = Fr(Fr(Fr({}, r), o), s.headers), n.data = qr(i, n, l), [2, {
                                        url: Or(t),
                                        options: n
                                    }]
                                })
                            })
                        },
                        v1LocalizationTableTablesTableIdEntriesGet: function(i, s, u, c) {
                            return void 0 === c && (c = {}), Nr(e, void 0, Promise, function() {
                                var t, n, r, a, o;
                                return kr(this, function(e) {
                                    return Lr("v1LocalizationTableTablesTableIdEntriesGet", "tableId", i), a = "/v1/localization-table/tables/{tableId}/entries".replace("{tableId}", encodeURIComponent(String(i))), t = new URL(a, Br), l && (o = l.baseOptions), n = Fr(Fr({
                                        method: "GET"
                                    }, o), c), r = {}, a = {}, void 0 !== s && (a.cursor = s), void 0 !== u && (a.gameId = u), Ur(t, a, c.query), o = o && o.headers ? o.headers : {}, n.headers = Fr(Fr(Fr({}, r), o), c.headers), [2, {
                                        url: Or(t),
                                        options: n
                                    }]
                                })
                            })
                        },
                        v1LocalizationTableTablesTableIdEntriesTranslationHistoryPost: function(i, s, u, c) {
                            return void 0 === c && (c = {}), Nr(e, void 0, Promise, function() {
                                var t, n, r, a, o;
                                return kr(this, function(e) {
                                    return Lr("v1LocalizationTableTablesTableIdEntriesTranslationHistoryPost", "tableId", i), Lr("v1LocalizationTableTablesTableIdEntriesTranslationHistoryPost", "request", s), a = "/v1/localization-table/tables/{tableId}/entries/translation-history".replace("{tableId}", encodeURIComponent(String(i))), t = new URL(a, Br), l && (o = l.baseOptions), n = Fr(Fr({
                                        method: "POST"
                                    }, o), c), r = {}, a = {}, void 0 !== u && (a.gameId = u), r["Content-Type"] = "application/json", Ur(t, a, c.query), o = o && o.headers ? o.headers : {}, n.headers = Fr(Fr(Fr({}, r), o), c.headers), n.data = qr(s, n, l), [2, {
                                        url: Or(t),
                                        options: n
                                    }]
                                })
                            })
                        },
                        v1LocalizationTableTablesTableIdEntryCountGet: function(i, s, u) {
                            return void 0 === u && (u = {}), Nr(e, void 0, Promise, function() {
                                var t, n, r, a, o;
                                return kr(this, function(e) {
                                    return Lr("v1LocalizationTableTablesTableIdEntryCountGet", "tableId", i), a = "/v1/localization-table/tables/{tableId}/entry-count".replace("{tableId}", encodeURIComponent(String(i))), t = new URL(a, Br), l && (o = l.baseOptions), n = Fr(Fr({
                                        method: "GET"
                                    }, o), u), r = {}, a = {}, void 0 !== s && (a.gameId = s), Ur(t, a, u.query), o = o && o.headers ? o.headers : {}, n.headers = Fr(Fr(Fr({}, r), o), u.headers), [2, {
                                        url: Or(t),
                                        options: n
                                    }]
                                })
                            })
                        },
                        v1LocalizationTableTablesTableIdGet: function(o, i) {
                            return void 0 === i && (i = {}), Nr(e, void 0, Promise, function() {
                                var t, n, r, a;
                                return kr(this, function(e) {
                                    return Lr("v1LocalizationTableTablesTableIdGet", "tableId", o), r = "/v1/localization-table/tables/{tableId}".replace("{tableId}", encodeURIComponent(String(o))), t = new URL(r, Br), l && (a = l.baseOptions), n = Fr(Fr({
                                        method: "GET"
                                    }, a), i), r = {}, Ur(t, {}, i.query), a = a && a.headers ? a.headers : {}, n.headers = Fr(Fr(Fr({}, r), a), i.headers), [2, {
                                        url: Or(t),
                                        options: n
                                    }]
                                })
                            })
                        },
                        v1LocalizationTableTablesTableIdLanguageTranslationCountsGet: function(i, s, u, c) {
                            return void 0 === c && (c = {}), Nr(e, void 0, Promise, function() {
                                var t, n, r, a, o;
                                return kr(this, function(e) {
                                    return Lr("v1LocalizationTableTablesTableIdLanguageTranslationCountsGet", "tableId", i), Lr("v1LocalizationTableTablesTableIdLanguageTranslationCountsGet", "locales", s), a = "/v1/localization-table/tables/{tableId}/language-translation-counts".replace("{tableId}", encodeURIComponent(String(i))), t = new URL(a, Br), l && (o = l.baseOptions), n = Fr(Fr({
                                        method: "GET"
                                    }, o), c), r = {}, a = {}, s && (a.locales = s), void 0 !== u && (a.gameId = u), Ur(t, a, c.query), o = o && o.headers ? o.headers : {}, n.headers = Fr(Fr(Fr({}, r), o), c.headers), [2, {
                                        url: Or(t),
                                        options: n
                                    }]
                                })
                            })
                        },
                        v1LocalizationTableTablesTableIdPatch: function(i, s, u, c) {
                            return void 0 === c && (c = {}), Nr(e, void 0, Promise, function() {
                                var t, n, r, a, o;
                                return kr(this, function(e) {
                                    return Lr("v1LocalizationTableTablesTableIdPatch", "tableId", i), Lr("v1LocalizationTableTablesTableIdPatch", "request", s), a = "/v1/localization-table/tables/{tableId}".replace("{tableId}", encodeURIComponent(String(i))), t = new URL(a, Br), l && (o = l.baseOptions), n = Fr(Fr({
                                        method: "PATCH"
                                    }, o), c), r = {}, a = {}, void 0 !== u && (a.gameId = u), r["Content-Type"] = "application/json", Ur(t, a, c.query), o = o && o.headers ? o.headers : {}, n.headers = Fr(Fr(Fr({}, r), o), c.headers), n.data = qr(s, n, l), [2, {
                                        url: Or(t),
                                        options: n
                                    }]
                                })
                            })
                        }
                    }
                }(i);
                return {
                    v1LocalizationTableAvailableLanguagesGet: function(n) {
                        return Nr(this, void 0, Promise, function() {
                            var t;
                            return kr(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, s.v1LocalizationTableAvailableLanguagesGet(n)];
                                    case 1:
                                        return t = e.sent(), [2, Dr(t, y(), Sr, i)]
                                }
                            })
                        })
                    },
                    v1LocalizationTableLimitsGet: function(n) {
                        return Nr(this, void 0, Promise, function() {
                            var t;
                            return kr(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, s.v1LocalizationTableLimitsGet(n)];
                                    case 1:
                                        return t = e.sent(), [2, Dr(t, y(), Sr, i)]
                                }
                            })
                        })
                    },
                    v1LocalizationTableMetadataGet: function(n) {
                        return Nr(this, void 0, Promise, function() {
                            var t;
                            return kr(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, s.v1LocalizationTableMetadataGet(n)];
                                    case 1:
                                        return t = e.sent(), [2, Dr(t, y(), Sr, i)]
                                }
                            })
                        })
                    },
                    v1LocalizationTableTablesAssetIdGet: function(n, r) {
                        return Nr(this, void 0, Promise, function() {
                            var t;
                            return kr(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, s.v1LocalizationTableTablesAssetIdGet(n, r)];
                                    case 1:
                                        return t = e.sent(), [2, Dr(t, y(), Sr, i)]
                                }
                            })
                        })
                    },
                    v1LocalizationTableTablesPost: function(n, r) {
                        return Nr(this, void 0, Promise, function() {
                            var t;
                            return kr(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, s.v1LocalizationTableTablesPost(n, r)];
                                    case 1:
                                        return t = e.sent(), [2, Dr(t, y(), Sr, i)]
                                }
                            })
                        })
                    },
                    v1LocalizationTableTablesTableIdEntriesGet: function(n, r, a, o) {
                        return Nr(this, void 0, Promise, function() {
                            var t;
                            return kr(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, s.v1LocalizationTableTablesTableIdEntriesGet(n, r, a, o)];
                                    case 1:
                                        return t = e.sent(), [2, Dr(t, y(), Sr, i)]
                                }
                            })
                        })
                    },
                    v1LocalizationTableTablesTableIdEntriesTranslationHistoryPost: function(n, r, a, o) {
                        return Nr(this, void 0, Promise, function() {
                            var t;
                            return kr(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, s.v1LocalizationTableTablesTableIdEntriesTranslationHistoryPost(n, r, a, o)];
                                    case 1:
                                        return t = e.sent(), [2, Dr(t, y(), Sr, i)]
                                }
                            })
                        })
                    },
                    v1LocalizationTableTablesTableIdEntryCountGet: function(n, r, a) {
                        return Nr(this, void 0, Promise, function() {
                            var t;
                            return kr(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, s.v1LocalizationTableTablesTableIdEntryCountGet(n, r, a)];
                                    case 1:
                                        return t = e.sent(), [2, Dr(t, y(), Sr, i)]
                                }
                            })
                        })
                    },
                    v1LocalizationTableTablesTableIdGet: function(n, r) {
                        return Nr(this, void 0, Promise, function() {
                            var t;
                            return kr(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, s.v1LocalizationTableTablesTableIdGet(n, r)];
                                    case 1:
                                        return t = e.sent(), [2, Dr(t, y(), Sr, i)]
                                }
                            })
                        })
                    },
                    v1LocalizationTableTablesTableIdLanguageTranslationCountsGet: function(n, r, a, o) {
                        return Nr(this, void 0, Promise, function() {
                            var t;
                            return kr(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, s.v1LocalizationTableTablesTableIdLanguageTranslationCountsGet(n, r, a, o)];
                                    case 1:
                                        return t = e.sent(), [2, Dr(t, y(), Sr, i)]
                                }
                            })
                        })
                    },
                    v1LocalizationTableTablesTableIdPatch: function(n, r, a, o) {
                        return Nr(this, void 0, Promise, function() {
                            var t;
                            return kr(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, s.v1LocalizationTableTablesTableIdPatch(n, r, a, o)];
                                    case 1:
                                        return t = e.sent(), [2, Dr(t, y(), Sr, i)]
                                }
                            })
                        })
                    }
                }
            }

            function Qr() {
                return null !== zr && zr.apply(this, arguments) || this
            }
            te(Qr, zr = K), Qr.prototype.v1LocalizationTableAvailableLanguagesGet = function(e) {
                var t = this;
                return Hr(this.configuration).v1LocalizationTableAvailableLanguagesGet(e).then(function(e) {
                    return e(t.axios, t.basePath)
                })
            }, Qr.prototype.v1LocalizationTableLimitsGet = function(e) {
                var t = this;
                return Hr(this.configuration).v1LocalizationTableLimitsGet(e).then(function(e) {
                    return e(t.axios, t.basePath)
                })
            }, Qr.prototype.v1LocalizationTableMetadataGet = function(e) {
                var t = this;
                return Hr(this.configuration).v1LocalizationTableMetadataGet(e).then(function(e) {
                    return e(t.axios, t.basePath)
                })
            }, Qr.prototype.v1LocalizationTableTablesAssetIdGet = function(e, t) {
                var n = this;
                return Hr(this.configuration).v1LocalizationTableTablesAssetIdGet(e, t).then(function(e) {
                    return e(n.axios, n.basePath)
                })
            }, Qr.prototype.v1LocalizationTableTablesPost = function(e, t) {
                var n = this;
                return Hr(this.configuration).v1LocalizationTableTablesPost(e, t).then(function(e) {
                    return e(n.axios, n.basePath)
                })
            }, Qr.prototype.v1LocalizationTableTablesTableIdEntriesGet = function(e, t, n, r) {
                var a = this;
                return Hr(this.configuration).v1LocalizationTableTablesTableIdEntriesGet(e, t, n, r).then(function(e) {
                    return e(a.axios, a.basePath)
                })
            }, Qr.prototype.v1LocalizationTableTablesTableIdEntriesTranslationHistoryPost = function(e, t, n, r) {
                var a = this;
                return Hr(this.configuration).v1LocalizationTableTablesTableIdEntriesTranslationHistoryPost(e, t, n, r).then(function(e) {
                    return e(a.axios, a.basePath)
                })
            }, Qr.prototype.v1LocalizationTableTablesTableIdEntryCountGet = function(e, t, n) {
                var r = this;
                return Hr(this.configuration).v1LocalizationTableTablesTableIdEntryCountGet(e, t, n).then(function(e) {
                    return e(r.axios, r.basePath)
                })
            }, Qr.prototype.v1LocalizationTableTablesTableIdGet = function(e, t) {
                var n = this;
                return Hr(this.configuration).v1LocalizationTableTablesTableIdGet(e, t).then(function(e) {
                    return e(n.axios, n.basePath)
                })
            }, Qr.prototype.v1LocalizationTableTablesTableIdLanguageTranslationCountsGet = function(e, t, n, r) {
                var a = this;
                return Hr(this.configuration).v1LocalizationTableTablesTableIdLanguageTranslationCountsGet(e, t, n, r).then(function(e) {
                    return e(a.axios, a.basePath)
                })
            }, Qr.prototype.v1LocalizationTableTablesTableIdPatch = function(e, t, n, r) {
                var a = this;
                return Hr(this.configuration).v1LocalizationTableTablesTableIdPatch(e, t, n, r).then(function(e) {
                    return e(a.axios, a.basePath)
                })
            };
            var Kr, Xr, Jr = new Pn,
                Yr = new Wr,
                $r = {
                    getAutolocalizationConfiguration: function(e) {
                        return Jr.v1AutolocalizationGamesGameIdAutolocalizationtablePost(e, {
                            withCredentials: !0
                        })
                    },
                    setAutolocalizationConfiguration: function(e, t) {
                        t = {
                            isAutolocalizationEnabled: t
                        };
                        return Jr.v1AutolocalizationGamesGameIdSettingsPatch(e, t, {
                            withCredentials: !0
                        })
                    },
                    setUseAutoLocalizationTable: function(e, t) {
                        t = {
                            shouldUseLocalizationTable: t
                        };
                        return Jr.v1AutolocalizationGamesGameIdSettingsPatch(e, t, {
                            withCredentials: !0
                        })
                    },
                    flushAutoLocalizationTable: function(e, t) {
                        t = {
                            maxAgeForFlush: t
                        };
                        return Yr.v1AutoLocalizationTableGamesGameIdAutoScrapeCleanupRequestPost(e, t, {
                            withCredentials: !0
                        })
                    },
                    getMetadata: function() {
                        return Jr.v1AutolocalizationMetadataGet({
                            withCredentials: !0
                        })
                    }
                },
                Zr = new En,
                oe = {
                    getGameFeatureStatus: function(e) {
                        return Zr.v1AutomaticTranslationGamesGameIdFeatureStatusGet(e, {
                            withCredentials: !0
                        })
                    },
                    getTargetLanguages: function(e, t) {
                        return Zr.v1AutomaticTranslationLanguagesLanguageCodeTargetLanguagesGet(e, t, {
                            withCredentials: !0
                        })
                    },
                    getGameAutoLocalizationQuota: function(e) {
                        return Zr.v1AutomaticTranslationGamesGameIdQuotaGet(e, {
                            withCredentials: !0
                        })
                    }
                },
                ae = (Kr = function(e, t) {
                    return (Kr = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function(e, t) {
                            e.__proto__ = t
                        } || function(e, t) {
                            for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
                        })(e, t)
                }, function(e, t) {
                    if ("function" != typeof t && null !== t) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");

                    function n() {
                        this.constructor = e
                    }
                    Kr(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                }),
                ea = m.EnvironmentUrls.gameInternationalizationApi.replace(/\/+$/, ""),
                X = function(e, t, n) {
                    void 0 === t && (t = ea), void 0 === n && (n = F), this.basePath = t, this.axios = n, e && (this.configuration = e, this.basePath = e.basePath || this.basePath)
                },
                ta = (Xr = Error, ae(na, Xr), na);

            function na(e, t) {
                t = Xr.call(this, t) || this;
                return t.field = e, t.name = "RequiredError", t
            }
            var ra, re = (ra = function(e, t) {
                    return (ra = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function(e, t) {
                            e.__proto__ = t
                        } || function(e, t) {
                            for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
                        })(e, t)
                }, function(e, t) {
                    if ("function" != typeof t && null !== t) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");

                    function n() {
                        this.constructor = e
                    }
                    ra(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                }),
                aa = function() {
                    return (aa = Object.assign || function(e) {
                        for (var t, n = 1, r = arguments.length; n < r; n++)
                            for (var a in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
                        return e
                    }).apply(this, arguments)
                },
                oa = function(e, i, s, u) {
                    return new(s = s || Promise)(function(n, t) {
                        function r(e) {
                            try {
                                o(u.next(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function a(e) {
                            try {
                                o(u.throw(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function o(e) {
                            var t;
                            e.done ? n(e.value) : ((t = e.value) instanceof s ? t : new s(function(e) {
                                e(t)
                            })).then(r, a)
                        }
                        o((u = u.apply(e, i || [])).next())
                    })
                },
                ia = function(n, r) {
                    var a, o, i, s = {
                            label: 0,
                            sent: function() {
                                if (1 & i[0]) throw i[1];
                                return i[1]
                            },
                            trys: [],
                            ops: []
                        },
                        e = {
                            next: t(0),
                            throw: t(1),
                            return: t(2)
                        };
                    return "function" == typeof Symbol && (e[Symbol.iterator] = function() {
                        return this
                    }), e;

                    function t(t) {
                        return function(e) {
                            return function(t) {
                                if (a) throw new TypeError("Generator is already executing.");
                                for (; s;) try {
                                    if (a = 1, o && (i = 2 & t[0] ? o.return : t[0] ? o.throw || ((i = o.return) && i.call(o), 0) : o.next) && !(i = i.call(o, t[1])).done) return i;
                                    switch (o = 0, i && (t = [2 & t[0], i.value]), t[0]) {
                                        case 0:
                                        case 1:
                                            i = t;
                                            break;
                                        case 4:
                                            return s.label++, {
                                                value: t[1],
                                                done: !1
                                            };
                                        case 5:
                                            s.label++, o = t[1], t = [0];
                                            continue;
                                        case 7:
                                            t = s.ops.pop(), s.trys.pop();
                                            continue;
                                        default:
                                            if (!(i = 0 < (i = s.trys).length && i[i.length - 1]) && (6 === t[0] || 2 === t[0])) {
                                                s = 0;
                                                continue
                                            }
                                            if (3 === t[0] && (!i || t[1] > i[0] && t[1] < i[3])) {
                                                s.label = t[1];
                                                break
                                            }
                                            if (6 === t[0] && s.label < i[1]) {
                                                s.label = i[1], i = t;
                                                break
                                            }
                                            if (i && s.label < i[2]) {
                                                s.label = i[2], s.ops.push(t);
                                                break
                                            }
                                            i[2] && s.ops.pop(), s.trys.pop();
                                            continue
                                    }
                                    t = r.call(n, s)
                                } catch (e) {
                                    t = [6, e], o = 0
                                } finally {
                                    a = i = 0
                                }
                                if (5 & t[0]) throw t[1];
                                return {
                                    value: t[0] ? t[1] : void 0,
                                    done: !0
                                }
                            }([t, e])
                        }
                    }
                };

            function sa(a) {
                return {
                    v2SupportedLanguagesGamesGameIdGet: function(t, r) {
                        return oa(this, void 0, Promise, function() {
                            var n;
                            return ia(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, function(u) {
                                            var e = this;
                                            return {
                                                v2SupportedLanguagesGamesGameIdGet: function(i, s) {
                                                    return void 0 === s && (s = {}), oa(e, void 0, Promise, function() {
                                                        var t, n, r, a, o;
                                                        return ia(this, function(e) {
                                                            if (null == i) throw new ta("gameId", "Required parameter gameId was null or undefined when calling v2SupportedLanguagesGamesGameIdGet.");
                                                            return a = "/v2/supported-languages/games/{gameId}".replace("{gameId}", encodeURIComponent(String(i))), t = Gt.Qc(a, !0), u && (o = u.baseOptions), n = aa(aa({
                                                                method: "GET"
                                                            }, o), s), r = {}, a = {}, t.query = aa(aa(aa({}, t.query), a), s.query), delete t.search, o = o && o.headers ? o.headers : {}, n.headers = aa(aa(aa({}, r), o), s.headers), [2, {
                                                                url: Gt.WU(t),
                                                                options: n
                                                            }]
                                                        })
                                                    })
                                                }
                                            }
                                        }(a).v2SupportedLanguagesGamesGameIdGet(t, r)];
                                    case 1:
                                        return n = e.sent(), [2, function(e, t) {
                                            void 0 === e && (e = F), void 0 === t && (t = ea);
                                            t = aa(aa({}, n.options), {
                                                url: t + n.url
                                            });
                                            return e.request(t)
                                        }]
                                }
                            })
                        })
                    }
                }
            }(ie = {}).EnUs = "en_us", ie.EsEs = "es_es", ie.FrFr = "fr_fr", ie.IdId = "id_id", ie.ItIt = "it_it", ie.JaJp = "ja_jp", ie.KoKr = "ko_kr", ie.RuRu = "ru_ru", ie.ThTh = "th_th", ie.TrTr = "tr_tr", ie.ViVn = "vi_vn", ie.PtBr = "pt_br", ie.DeDe = "de_de", ie.ZhCn = "zh_cn", ie.ZhTw = "zh_tw", ie.BgBg = "bg_bg", ie.BnBd = "bn_bd", ie.CsCz = "cs_cz", ie.DaDk = "da_dk", ie.ElGr = "el_gr", ie.EtEe = "et_ee", ie.FiFi = "fi_fi", ie.HiIn = "hi_in", ie.HrHr = "hr_hr", ie.HuHu = "hu_hu", ie.KaGe = "ka_ge", ie.KkKz = "kk_kz", ie.KmKh = "km_kh", ie.LtLt = "lt_lt", ie.LvLv = "lv_lv", ie.MsMy = "ms_my", ie.MyMm = "my_mm", ie.NbNo = "nb_no", ie.NlNl = "nl_nl", ie.FilPh = "fil_ph", ie.PlPl = "pl_pl", ie.RoRo = "ro_ro", ie.UkUa = "uk_ua", ie.SiLk = "si_lk", ie.SkSk = "sk_sk", ie.SlSl = "sl_sl", ie.SqAl = "sq_al", ie.BsBa = "bs_ba", ie.SrRs = "sr_rs", ie.SvSe = "sv_se", ie.ZhCjv = "zh_cjv";
            var ua, pe = (re(ca, ua = X), ca.prototype.v2SupportedLanguagesGamesGameIdGet = function(e, t) {
                var n = this;
                return sa(this.configuration).v2SupportedLanguagesGamesGameIdGet(e, t).then(function(e) {
                    return e(n.axios, n.basePath)
                })
            }, ca);

            function ca() {
                return null !== ua && ua.apply(this, arguments) || this
            }
            var la, da, ha = new fe,
                va = new pe,
                pa = new R,
                I = {
                    getGameLanguageRolloutSettings: function() {
                        return ha.v1SupportedLanguagesMetadataGet({
                            withCredentials: !0
                        })
                    },
                    getGameLanguages: function(e) {
                        return ha.v1SupportedLanguagesGamesGameIdGet(e, {
                            withCredentials: !0
                        })
                    },
                    getGameLanguagesV2: function(e) {
                        return va.v2SupportedLanguagesGamesGameIdGet(e, {
                            withCredentials: !0
                        })
                    },
                    addLanguages: function(e, t) {
                        t = t.map(function(e) {
                            return {
                                languageCodeType: pn.Language,
                                languageCode: e
                            }
                        });
                        return ha.v1SupportedLanguagesGamesGameIdPatch(e, t, {
                            withCredentials: !0
                        })
                    },
                    deleteLanguages: function(e, t) {
                        t = t.map(function(e) {
                            return {
                                languageCodeType: pn.Language,
                                languageCode: e,
                                delete: !0
                            }
                        });
                        return ha.v1SupportedLanguagesGamesGameIdPatch(e, t, {
                            withCredentials: !0
                        })
                    },
                    getAvailableLanguages: function() {
                        return pa.v1LocalizationtableAvailableLanguagesGet()
                    },
                    getAutomaticTranslationStatus: function(e) {
                        return ha.v1SupportedLanguagesGamesGameIdAutomaticTranslationStatusGet(e, {
                            withCredentials: !0
                        })
                    },
                    setAutomaticTranslationStatus: function(e, t, n) {
                        return ha.v1SupportedLanguagesGamesGameIdLanguagesLanguageCodeAutomaticTranslationStatusPatch(e, n, t, {
                            withCredentials: !0
                        })
                    },
                    getAutomaticTranslationSwitchesValues: function(e) {
                        return ha.v1SupportedLanguagesGamesGameIdUniverseDisplayInfoAutomaticTranslationSettingsGet(e, {
                            withCredentials: !0
                        })
                    },
                    setAutomaticTranslationSwitchesValue: function(e, t, n) {
                        return ha.v1SupportedLanguagesGamesGameIdLanguagesLanguageCodeUniverseDisplayInfoAutomaticTranslationSettingsPatch(e, n, t, {
                            withCredentials: !0
                        })
                    }
                },
                fa = new z,
                te = {
                    getSourceLanguage: function(e) {
                        return fa.v1SourceLanguageGamesGameIdGet(e, {
                            withCredentials: !0
                        })
                    },
                    updateSourceLanguage: function(e, t) {
                        return fa.v1SourceLanguageGamesGameIdPatch(e, t, {
                            withCredentials: !0
                        })
                    }
                },
                K = (la = function(e, t) {
                    return (la = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function(e, t) {
                            e.__proto__ = t
                        } || function(e, t) {
                            for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
                        })(e, t)
                }, function(e, t) {
                    if ("function" != typeof t && null !== t) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");

                    function n() {
                        this.constructor = e
                    }
                    la(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                }),
                ma = m.EnvironmentUrls.thumbnailsApi.replace(/\/+$/, ""),
                ga = ",",
                Pn = function(e, t, n) {
                    void 0 === t && (t = ma), void 0 === n && (n = F), this.basePath = t, this.axios = n, e && (this.configuration = e, this.basePath = e.basePath || this.basePath)
                },
                Ia = (da = Error, K(ya, da), ya);

            function ya(e, t) {
                t = da.call(this, t) || this;
                return t.field = e, t.name = "RequiredError", t
            }

            function ba(e, t, n) {
                if (null == n) throw new Ia(t, "Required parameter " + t + " was null or undefined when calling " + e + ".")
            }

            function Pa(e) {
                for (var t = [], n = 1; n < arguments.length; n++) t[n - 1] = arguments[n];
                for (var r = new URLSearchParams(e.search), a = 0, o = t; a < o.length; a++) {
                    var i, s = o[a];
                    for (i in s) r.set(i, s[i])
                }
                e.search = r.toString()
            }

            function Ga(e) {
                return e.pathname + e.search + e.hash
            }

            function wa(n, r, a, o) {
                return function(e, t) {
                    void 0 === e && (e = r), void 0 === t && (t = a);
                    t = Ta(Ta({}, n.options), {
                        url: ((null == o ? void 0 : o.basePath) || t) + n.url
                    });
                    return e.request(t)
                }
            }
            var Ca, Ta = function() {
                    return (Ta = Object.assign || function(e) {
                        for (var t, n = 1, r = arguments.length; n < r; n++)
                            for (var a in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
                        return e
                    }).apply(this, arguments)
                },
                Aa = "https://example.com",
                Wr = (Ca = function(e, t) {
                    return (Ca = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function(e, t) {
                            e.__proto__ = t
                        } || function(e, t) {
                            for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
                        })(e, t)
                }, function(e, t) {
                    if ("function" != typeof t && null !== t) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");

                    function n() {
                        this.constructor = e
                    }
                    Ca(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                }),
                Sa = function() {
                    return (Sa = Object.assign || function(e) {
                        for (var t, n = 1, r = arguments.length; n < r; n++)
                            for (var a in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
                        return e
                    }).apply(this, arguments)
                },
                Ra = function(e, i, s, u) {
                    return new(s = s || Promise)(function(n, t) {
                        function r(e) {
                            try {
                                o(u.next(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function a(e) {
                            try {
                                o(u.throw(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function o(e) {
                            var t;
                            e.done ? n(e.value) : ((t = e.value) instanceof s ? t : new s(function(e) {
                                e(t)
                            })).then(r, a)
                        }
                        o((u = u.apply(e, i || [])).next())
                    })
                },
                Ea = function(n, r) {
                    var a, o, i, s = {
                            label: 0,
                            sent: function() {
                                if (1 & i[0]) throw i[1];
                                return i[1]
                            },
                            trys: [],
                            ops: []
                        },
                        e = {
                            next: t(0),
                            throw: t(1),
                            return: t(2)
                        };
                    return "function" == typeof Symbol && (e[Symbol.iterator] = function() {
                        return this
                    }), e;

                    function t(t) {
                        return function(e) {
                            return function(t) {
                                if (a) throw new TypeError("Generator is already executing.");
                                for (; s;) try {
                                    if (a = 1, o && (i = 2 & t[0] ? o.return : t[0] ? o.throw || ((i = o.return) && i.call(o), 0) : o.next) && !(i = i.call(o, t[1])).done) return i;
                                    switch (o = 0, i && (t = [2 & t[0], i.value]), t[0]) {
                                        case 0:
                                        case 1:
                                            i = t;
                                            break;
                                        case 4:
                                            return s.label++, {
                                                value: t[1],
                                                done: !1
                                            };
                                        case 5:
                                            s.label++, o = t[1], t = [0];
                                            continue;
                                        case 7:
                                            t = s.ops.pop(), s.trys.pop();
                                            continue;
                                        default:
                                            if (!(i = 0 < (i = s.trys).length && i[i.length - 1]) && (6 === t[0] || 2 === t[0])) {
                                                s = 0;
                                                continue
                                            }
                                            if (3 === t[0] && (!i || t[1] > i[0] && t[1] < i[3])) {
                                                s.label = t[1];
                                                break
                                            }
                                            if (6 === t[0] && s.label < i[1]) {
                                                s.label = i[1], i = t;
                                                break
                                            }
                                            if (i && s.label < i[2]) {
                                                s.label = i[2], s.ops.push(t);
                                                break
                                            }
                                            i[2] && s.ops.pop(), s.trys.pop();
                                            continue
                                    }
                                    t = r.call(n, s)
                                } catch (e) {
                                    t = [6, e], o = 0
                                } finally {
                                    a = i = 0
                                }
                                if (5 & t[0]) throw t[1];
                                return {
                                    value: t[0] ? t[1] : void 0,
                                    done: !0
                                }
                            }([t, e])
                        }
                    }
                };

            function La(u) {
                var c = function(h) {
                    var e = this;
                    return {
                        v1AssetsGet: function(i, s, u, c, l, d) {
                            return void 0 === d && (d = {}), Ra(e, void 0, Promise, function() {
                                var t, n, r, a, o;
                                return Ea(this, function(e) {
                                    return ba("v1AssetsGet", "assetIds", i), t = new URL("/v1/assets", Aa), h && (o = h.baseOptions), n = Sa(Sa({
                                        method: "GET"
                                    }, o), d), r = {}, a = {}, i && (a.assetIds = i.join(ga)), void 0 !== s && (a.returnPolicy = s), void 0 !== u && (a.size = u), void 0 !== c && (a.format = c), void 0 !== l && (a.isCircular = l), Pa(t, a, d.query), o = o && o.headers ? o.headers : {}, n.headers = Sa(Sa(Sa({}, r), o), d.headers), [2, {
                                        url: Ga(t),
                                        options: n
                                    }]
                                })
                            })
                        },
                        v1AssetsThumbnail3dGet: function(i, s) {
                            return void 0 === s && (s = {}), Ra(e, void 0, Promise, function() {
                                var t, n, r, a, o;
                                return Ea(this, function(e) {
                                    return ba("v1AssetsThumbnail3dGet", "assetId", i), t = new URL("/v1/assets-thumbnail-3d", Aa), h && (o = h.baseOptions), n = Sa(Sa({
                                        method: "GET"
                                    }, o), s), r = {}, a = {}, void 0 !== i && (a.assetId = i), Pa(t, a, s.query), o = o && o.headers ? o.headers : {}, n.headers = Sa(Sa(Sa({}, r), o), s.headers), [2, {
                                        url: Ga(t),
                                        options: n
                                    }]
                                })
                            })
                        }
                    }
                }(u);
                return {
                    v1AssetsGet: function(n, r, a, o, i, s) {
                        return Ra(this, void 0, Promise, function() {
                            var t;
                            return Ea(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, c.v1AssetsGet(n, r, a, o, i, s)];
                                    case 1:
                                        return t = e.sent(), [2, wa(t, y(), ma, u)]
                                }
                            })
                        })
                    },
                    v1AssetsThumbnail3dGet: function(n, r) {
                        return Ra(this, void 0, Promise, function() {
                            var t;
                            return Ea(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, c.v1AssetsThumbnail3dGet(n, r)];
                                    case 1:
                                        return t = e.sent(), [2, wa(t, y(), ma, u)]
                                }
                            })
                        })
                    }
                }
            }(En = {}).Avatar = "Avatar", En.AvatarHeadShot = "AvatarHeadShot", En.GameIcon = "GameIcon", En.BadgeIcon = "BadgeIcon", En.GameThumbnail = "GameThumbnail", En.GamePass = "GamePass", En.Asset = "Asset", En.BundleThumbnail = "BundleThumbnail", En.Outfit = "Outfit", En.GroupIcon = "GroupIcon", En.DeveloperProduct = "DeveloperProduct", En.AvatarBust = "AvatarBust", En.AutoGeneratedAsset = "AutoGeneratedAsset", (ae = {}).Error = "Error", ae.Completed = "Completed", ae.InReview = "InReview", ae.Pending = "Pending", ae.Blocked = "Blocked", (ie = {}).Error = "Error", ie.Completed = "Completed", ie.InReview = "InReview", ie.Pending = "Pending", ie.Blocked = "Blocked";
            var Ua, re = (Wr(qa, Ua = Pn), qa.prototype.v1AssetsGet = function(e, t, n, r, a, o) {
                var i = this;
                return La(this.configuration).v1AssetsGet(e, t, n, r, a, o).then(function(e) {
                    return e(i.axios, i.basePath)
                })
            }, qa.prototype.v1AssetsThumbnail3dGet = function(e, t) {
                var n = this;
                return La(this.configuration).v1AssetsThumbnail3dGet(e, t).then(function(e) {
                    return e(n.axios, n.basePath)
                })
            }, qa);

            function qa() {
                return null !== Ua && Ua.apply(this, arguments) || this
            }

            function Oa(s) {
                var u = function(d) {
                    var e = this;
                    return {
                        v1UsersAvatar3dGet: function(i, s) {
                            return void 0 === s && (s = {}), Ra(e, void 0, Promise, function() {
                                var t, n, r, a, o;
                                return Ea(this, function(e) {
                                    return ba("v1UsersAvatar3dGet", "userId", i), t = new URL("/v1/users/avatar-3d", Aa), d && (o = d.baseOptions), n = Sa(Sa({
                                        method: "GET"
                                    }, o), s), r = {}, a = {}, void 0 !== i && (a.userId = i), Pa(t, a, s.query), o = o && o.headers ? o.headers : {}, n.headers = Sa(Sa(Sa({}, r), o), s.headers), [2, {
                                        url: Ga(t),
                                        options: n
                                    }]
                                })
                            })
                        },
                        v1UsersAvatarBustGet: function(i, s, u, c, l) {
                            return void 0 === l && (l = {}), Ra(e, void 0, Promise, function() {
                                var t, n, r, a, o;
                                return Ea(this, function(e) {
                                    return ba("v1UsersAvatarBustGet", "userIds", i), t = new URL("/v1/users/avatar-bust", Aa), d && (o = d.baseOptions), n = Sa(Sa({
                                        method: "GET"
                                    }, o), l), r = {}, a = {}, i && (a.userIds = i.join(ga)), void 0 !== s && (a.size = s), void 0 !== u && (a.format = u), void 0 !== c && (a.isCircular = c), Pa(t, a, l.query), o = o && o.headers ? o.headers : {}, n.headers = Sa(Sa(Sa({}, r), o), l.headers), [2, {
                                        url: Ga(t),
                                        options: n
                                    }]
                                })
                            })
                        },
                        v1UsersAvatarGet: function(i, s, u, c, l) {
                            return void 0 === l && (l = {}), Ra(e, void 0, Promise, function() {
                                var t, n, r, a, o;
                                return Ea(this, function(e) {
                                    return ba("v1UsersAvatarGet", "userIds", i), t = new URL("/v1/users/avatar", Aa), d && (o = d.baseOptions), n = Sa(Sa({
                                        method: "GET"
                                    }, o), l), r = {}, a = {}, i && (a.userIds = i.join(ga)), void 0 !== s && (a.size = s), void 0 !== u && (a.format = u), void 0 !== c && (a.isCircular = c), Pa(t, a, l.query), o = o && o.headers ? o.headers : {}, n.headers = Sa(Sa(Sa({}, r), o), l.headers), [2, {
                                        url: Ga(t),
                                        options: n
                                    }]
                                })
                            })
                        },
                        v1UsersAvatarHeadshotGet: function(i, s, u, c, l) {
                            return void 0 === l && (l = {}), Ra(e, void 0, Promise, function() {
                                var t, n, r, a, o;
                                return Ea(this, function(e) {
                                    return ba("v1UsersAvatarHeadshotGet", "userIds", i), t = new URL("/v1/users/avatar-headshot", Aa), d && (o = d.baseOptions), n = Sa(Sa({
                                        method: "GET"
                                    }, o), l), r = {}, a = {}, i && (a.userIds = i.join(ga)), void 0 !== s && (a.size = s), void 0 !== u && (a.format = u), void 0 !== c && (a.isCircular = c), Pa(t, a, l.query), o = o && o.headers ? o.headers : {}, n.headers = Sa(Sa(Sa({}, r), o), l.headers), [2, {
                                        url: Ga(t),
                                        options: n
                                    }]
                                })
                            })
                        }
                    }
                }(s);
                return {
                    v1UsersAvatar3dGet: function(n, r) {
                        return Ra(this, void 0, Promise, function() {
                            var t;
                            return Ea(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, u.v1UsersAvatar3dGet(n, r)];
                                    case 1:
                                        return t = e.sent(), [2, wa(t, y(), ma, s)]
                                }
                            })
                        })
                    },
                    v1UsersAvatarBustGet: function(n, r, a, o, i) {
                        return Ra(this, void 0, Promise, function() {
                            var t;
                            return Ea(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, u.v1UsersAvatarBustGet(n, r, a, o, i)];
                                    case 1:
                                        return t = e.sent(), [2, wa(t, y(), ma, s)]
                                }
                            })
                        })
                    },
                    v1UsersAvatarGet: function(n, r, a, o, i) {
                        return Ra(this, void 0, Promise, function() {
                            var t;
                            return Ea(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, u.v1UsersAvatarGet(n, r, a, o, i)];
                                    case 1:
                                        return t = e.sent(), [2, wa(t, y(), ma, s)]
                                }
                            })
                        })
                    },
                    v1UsersAvatarHeadshotGet: function(n, r, a, o, i) {
                        return Ra(this, void 0, Promise, function() {
                            var t;
                            return Ea(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, u.v1UsersAvatarHeadshotGet(n, r, a, o, i)];
                                    case 1:
                                        return t = e.sent(), [2, wa(t, y(), ma, s)]
                                }
                            })
                        })
                    }
                }
            }
            var Da, X = (Wr(xa, Da = Pn), xa.prototype.v1UsersAvatar3dGet = function(e, t) {
                var n = this;
                return Oa(this.configuration).v1UsersAvatar3dGet(e, t).then(function(e) {
                    return e(n.axios, n.basePath)
                })
            }, xa.prototype.v1UsersAvatarBustGet = function(e, t, n, r, a) {
                var o = this;
                return Oa(this.configuration).v1UsersAvatarBustGet(e, t, n, r, a).then(function(e) {
                    return e(o.axios, o.basePath)
                })
            }, xa.prototype.v1UsersAvatarGet = function(e, t, n, r, a) {
                var o = this;
                return Oa(this.configuration).v1UsersAvatarGet(e, t, n, r, a).then(function(e) {
                    return e(o.axios, o.basePath)
                })
            }, xa.prototype.v1UsersAvatarHeadshotGet = function(e, t, n, r, a) {
                var o = this;
                return Oa(this.configuration).v1UsersAvatarHeadshotGet(e, t, n, r, a).then(function(e) {
                    return e(o.axios, o.basePath)
                })
            }, xa);

            function xa() {
                return null !== Da && Da.apply(this, arguments) || this
            }

            function _a(s) {
                var u = function(d) {
                    var e = this;
                    return {
                        v1BadgesIconsGet: function(i, s, u, c, l) {
                            return void 0 === l && (l = {}), Ra(e, void 0, Promise, function() {
                                var t, n, r, a, o;
                                return Ea(this, function(e) {
                                    return ba("v1BadgesIconsGet", "badgeIds", i), t = new URL("/v1/badges/icons", Aa), d && (o = d.baseOptions), n = Sa(Sa({
                                        method: "GET"
                                    }, o), l), r = {}, a = {}, i && (a.badgeIds = i.join(ga)), void 0 !== s && (a.size = s), void 0 !== u && (a.format = u), void 0 !== c && (a.isCircular = c), Pa(t, a, l.query), o = o && o.headers ? o.headers : {}, n.headers = Sa(Sa(Sa({}, r), o), l.headers), [2, {
                                        url: Ga(t),
                                        options: n
                                    }]
                                })
                            })
                        }
                    }
                }(s);
                return {
                    v1BadgesIconsGet: function(n, r, a, o, i) {
                        return Ra(this, void 0, Promise, function() {
                            var t;
                            return Ea(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, u.v1BadgesIconsGet(n, r, a, o, i)];
                                    case 1:
                                        return t = e.sent(), [2, wa(t, y(), ma, s)]
                                }
                            })
                        })
                    }
                }
            }
            var Ba, fe = (Wr(Fa, Ba = Pn), Fa.prototype.v1BadgesIconsGet = function(e, t, n, r, a) {
                var o = this;
                return _a(this.configuration).v1BadgesIconsGet(e, t, n, r, a).then(function(e) {
                    return e(o.axios, o.basePath)
                })
            }, Fa);

            function Fa() {
                return null !== Ba && Ba.apply(this, arguments) || this
            }

            function Na(h) {
                var e = this;
                return {
                    v1BatchPost: function(l, d) {
                        return void 0 === d && (d = {}), Ra(e, void 0, Promise, function() {
                            var o, i, s, u, c;
                            return Ea(this, function(e) {
                                var t, n, r, a;
                                return ba("v1BatchPost", "requests", l), o = new URL("/v1/batch", Aa), h && (c = h.baseOptions), i = Sa(Sa({
                                    method: "POST"
                                }, c), d), u = {}, (s = {})["Content-Type"] = "application/json", Pa(o, u, d.query), c = c && c.headers ? c.headers : {}, i.headers = Sa(Sa(Sa({}, s), c), d.headers), i.data = (n = i, r = h, ((a = "string" != typeof(t = l)) && r && r.isJsonMime ? r.isJsonMime(n.headers["Content-Type"]) : a) ? JSON.stringify(void 0 !== t ? t : {}) : t || ""), [2, {
                                    url: Ga(o),
                                    options: i
                                }]
                            })
                        })
                    }
                }
            }

            function ka(a) {
                var o = Na(a);
                return {
                    v1BatchPost: function(n, r) {
                        return Ra(this, void 0, Promise, function() {
                            var t;
                            return Ea(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, o.v1BatchPost(n, r)];
                                    case 1:
                                        return t = e.sent(), [2, wa(t, y(), ma, a)]
                                }
                            })
                        })
                    }
                }
            }
            var Ma, pe = (Wr(ja, Ma = Pn), ja.prototype.v1BatchPost = function(e, t) {
                var n = this;
                return ka(this.configuration).v1BatchPost(e, t).then(function(e) {
                    return e(n.axios, n.basePath)
                })
            }, ja);

            function ja() {
                return null !== Ma && Ma.apply(this, arguments) || this
            }

            function za(s) {
                var u = function(d) {
                    var e = this;
                    return {
                        v1BundlesThumbnailsGet: function(i, s, u, c, l) {
                            return void 0 === l && (l = {}), Ra(e, void 0, Promise, function() {
                                var t, n, r, a, o;
                                return Ea(this, function(e) {
                                    return ba("v1BundlesThumbnailsGet", "bundleIds", i), t = new URL("/v1/bundles/thumbnails", Aa), d && (o = d.baseOptions), n = Sa(Sa({
                                        method: "GET"
                                    }, o), l), r = {}, a = {}, i && (a.bundleIds = i.join(ga)), void 0 !== s && (a.size = s), void 0 !== u && (a.format = u), void 0 !== c && (a.isCircular = c), Pa(t, a, l.query), o = o && o.headers ? o.headers : {}, n.headers = Sa(Sa(Sa({}, r), o), l.headers), [2, {
                                        url: Ga(t),
                                        options: n
                                    }]
                                })
                            })
                        }
                    }
                }(s);
                return {
                    v1BundlesThumbnailsGet: function(n, r, a, o, i) {
                        return Ra(this, void 0, Promise, function() {
                            var t;
                            return Ea(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, u.v1BundlesThumbnailsGet(n, r, a, o, i)];
                                    case 1:
                                        return t = e.sent(), [2, wa(t, y(), ma, s)]
                                }
                            })
                        })
                    }
                }
            }
            var Wa, R = (Wr(Va, Wa = Pn), Va.prototype.v1BundlesThumbnailsGet = function(e, t, n, r, a) {
                var o = this;
                return za(this.configuration).v1BundlesThumbnailsGet(e, t, n, r, a).then(function(e) {
                    return e(o.axios, o.basePath)
                })
            }, Va);

            function Va() {
                return null !== Wa && Wa.apply(this, arguments) || this
            }

            function Ha(s) {
                var u = function(d) {
                    var e = this;
                    return {
                        v1DeveloperProductsIconsGet: function(i, s, u, c, l) {
                            return void 0 === l && (l = {}), Ra(e, void 0, Promise, function() {
                                var t, n, r, a, o;
                                return Ea(this, function(e) {
                                    return ba("v1DeveloperProductsIconsGet", "developerProductIds", i), t = new URL("/v1/developer-products/icons", Aa), d && (o = d.baseOptions), n = Sa(Sa({
                                        method: "GET"
                                    }, o), l), r = {}, a = {}, i && (a.developerProductIds = i.join(ga)), void 0 !== s && (a.size = s), void 0 !== u && (a.format = u), void 0 !== c && (a.isCircular = c), Pa(t, a, l.query), o = o && o.headers ? o.headers : {}, n.headers = Sa(Sa(Sa({}, r), o), l.headers), [2, {
                                        url: Ga(t),
                                        options: n
                                    }]
                                })
                            })
                        }
                    }
                }(s);
                return {
                    v1DeveloperProductsIconsGet: function(n, r, a, o, i) {
                        return Ra(this, void 0, Promise, function() {
                            var t;
                            return Ea(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, u.v1DeveloperProductsIconsGet(n, r, a, o, i)];
                                    case 1:
                                        return t = e.sent(), [2, wa(t, y(), ma, s)]
                                }
                            })
                        })
                    }
                }
            }
            var Qa, z = (Wr(Ka, Qa = Pn), Ka.prototype.v1DeveloperProductsIconsGet = function(e, t, n, r, a) {
                var o = this;
                return Ha(this.configuration).v1DeveloperProductsIconsGet(e, t, n, r, a).then(function(e) {
                    return e(o.axios, o.basePath)
                })
            }, Ka);

            function Ka() {
                return null !== Qa && Qa.apply(this, arguments) || this
            }

            function Xa(s) {
                var u = function(d) {
                    var e = this;
                    return {
                        v1GamePassesGet: function(i, s, u, c, l) {
                            return void 0 === l && (l = {}), Ra(e, void 0, Promise, function() {
                                var t, n, r, a, o;
                                return Ea(this, function(e) {
                                    return ba("v1GamePassesGet", "gamePassIds", i), t = new URL("/v1/game-passes", Aa), d && (o = d.baseOptions), n = Sa(Sa({
                                        method: "GET"
                                    }, o), l), r = {}, a = {}, i && (a.gamePassIds = i.join(ga)), void 0 !== s && (a.size = s), void 0 !== u && (a.format = u), void 0 !== c && (a.isCircular = c), Pa(t, a, l.query), o = o && o.headers ? o.headers : {}, n.headers = Sa(Sa(Sa({}, r), o), l.headers), [2, {
                                        url: Ga(t),
                                        options: n
                                    }]
                                })
                            })
                        }
                    }
                }(s);
                return {
                    v1GamePassesGet: function(n, r, a, o, i) {
                        return Ra(this, void 0, Promise, function() {
                            var t;
                            return Ea(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, u.v1GamePassesGet(n, r, a, o, i)];
                                    case 1:
                                        return t = e.sent(), [2, wa(t, y(), ma, s)]
                                }
                            })
                        })
                    }
                }
            }
            var Ja, K = (Wr(Ya, Ja = Pn), Ya.prototype.v1GamePassesGet = function(e, t, n, r, a) {
                var o = this;
                return Xa(this.configuration).v1GamePassesGet(e, t, n, r, a).then(function(e) {
                    return e(o.axios, o.basePath)
                })
            }, Ya);

            function Ya() {
                return null !== Ja && Ja.apply(this, arguments) || this
            }

            function $a(c) {
                var l = function(v) {
                    var e = this;
                    return {
                        v1GamesIconsGet: function(i, s, u, c, l, d) {
                            return void 0 === d && (d = {}), Ra(e, void 0, Promise, function() {
                                var t, n, r, a, o;
                                return Ea(this, function(e) {
                                    return ba("v1GamesIconsGet", "universeIds", i), t = new URL("/v1/games/icons", Aa), v && (o = v.baseOptions), n = Sa(Sa({
                                        method: "GET"
                                    }, o), d), r = {}, a = {}, i && (a.universeIds = i.join(ga)), void 0 !== s && (a.returnPolicy = s), void 0 !== u && (a.size = u), void 0 !== c && (a.format = c), void 0 !== l && (a.isCircular = l), Pa(t, a, d.query), o = o && o.headers ? o.headers : {}, n.headers = Sa(Sa(Sa({}, r), o), d.headers), [2, {
                                        url: Ga(t),
                                        options: n
                                    }]
                                })
                            })
                        },
                        v1GamesMultigetThumbnailsGet: function(i, s, u, c, l, d, h) {
                            return void 0 === h && (h = {}), Ra(e, void 0, Promise, function() {
                                var t, n, r, a, o;
                                return Ea(this, function(e) {
                                    return ba("v1GamesMultigetThumbnailsGet", "universeIds", i), t = new URL("/v1/games/multiget/thumbnails", Aa), v && (o = v.baseOptions), n = Sa(Sa({
                                        method: "GET"
                                    }, o), h), r = {}, a = {}, i && (a.universeIds = i.join(ga)), void 0 !== s && (a.countPerUniverse = s), void 0 !== u && (a.defaults = u), void 0 !== c && (a.size = c), void 0 !== l && (a.format = l), void 0 !== d && (a.isCircular = d), Pa(t, a, h.query), o = o && o.headers ? o.headers : {}, n.headers = Sa(Sa(Sa({}, r), o), h.headers), [2, {
                                        url: Ga(t),
                                        options: n
                                    }]
                                })
                            })
                        },
                        v1GamesUniverseIdThumbnailsGet: function(i, s, u, c, l, d) {
                            return void 0 === d && (d = {}), Ra(e, void 0, Promise, function() {
                                var t, n, r, a, o;
                                return Ea(this, function(e) {
                                    return ba("v1GamesUniverseIdThumbnailsGet", "universeId", i), ba("v1GamesUniverseIdThumbnailsGet", "thumbnailIds", s), a = "/v1/games/{universeId}/thumbnails".replace("{universeId}", encodeURIComponent(String(i))), t = new URL(a, Aa), v && (o = v.baseOptions), n = Sa(Sa({
                                        method: "GET"
                                    }, o), d), r = {}, a = {}, s && (a.thumbnailIds = s.join(ga)), void 0 !== u && (a.size = u), void 0 !== c && (a.format = c), void 0 !== l && (a.isCircular = l), Pa(t, a, d.query), o = o && o.headers ? o.headers : {}, n.headers = Sa(Sa(Sa({}, r), o), d.headers), [2, {
                                        url: Ga(t),
                                        options: n
                                    }]
                                })
                            })
                        }
                    }
                }(c);
                return {
                    v1GamesIconsGet: function(n, r, a, o, i, s) {
                        return Ra(this, void 0, Promise, function() {
                            var t;
                            return Ea(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, l.v1GamesIconsGet(n, r, a, o, i, s)];
                                    case 1:
                                        return t = e.sent(), [2, wa(t, y(), ma, c)]
                                }
                            })
                        })
                    },
                    v1GamesMultigetThumbnailsGet: function(n, r, a, o, i, s, u) {
                        return Ra(this, void 0, Promise, function() {
                            var t;
                            return Ea(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, l.v1GamesMultigetThumbnailsGet(n, r, a, o, i, s, u)];
                                    case 1:
                                        return t = e.sent(), [2, wa(t, y(), ma, c)]
                                }
                            })
                        })
                    },
                    v1GamesUniverseIdThumbnailsGet: function(n, r, a, o, i, s) {
                        return Ra(this, void 0, Promise, function() {
                            var t;
                            return Ea(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, l.v1GamesUniverseIdThumbnailsGet(n, r, a, o, i, s)];
                                    case 1:
                                        return t = e.sent(), [2, wa(t, y(), ma, c)]
                                }
                            })
                        })
                    }
                }
            }
            var Za, En = (Wr(eo, Za = Pn), eo.prototype.v1GamesIconsGet = function(e, t, n, r, a, o) {
                var i = this;
                return $a(this.configuration).v1GamesIconsGet(e, t, n, r, a, o).then(function(e) {
                    return e(i.axios, i.basePath)
                })
            }, eo.prototype.v1GamesMultigetThumbnailsGet = function(e, t, n, r, a, o, i) {
                var s = this;
                return $a(this.configuration).v1GamesMultigetThumbnailsGet(e, t, n, r, a, o, i).then(function(e) {
                    return e(s.axios, s.basePath)
                })
            }, eo.prototype.v1GamesUniverseIdThumbnailsGet = function(e, t, n, r, a, o) {
                var i = this;
                return $a(this.configuration).v1GamesUniverseIdThumbnailsGet(e, t, n, r, a, o).then(function(e) {
                    return e(i.axios, i.basePath)
                })
            }, eo);

            function eo() {
                return null !== Za && Za.apply(this, arguments) || this
            }

            function to(s) {
                var u = function(d) {
                    var e = this;
                    return {
                        v1GroupsIconsGet: function(i, s, u, c, l) {
                            return void 0 === l && (l = {}), Ra(e, void 0, Promise, function() {
                                var t, n, r, a, o;
                                return Ea(this, function(e) {
                                    return ba("v1GroupsIconsGet", "groupIds", i), t = new URL("/v1/groups/icons", Aa), d && (o = d.baseOptions), n = Sa(Sa({
                                        method: "GET"
                                    }, o), l), r = {}, a = {}, i && (a.groupIds = i.join(ga)), void 0 !== s && (a.size = s), void 0 !== u && (a.format = u), void 0 !== c && (a.isCircular = c), Pa(t, a, l.query), o = o && o.headers ? o.headers : {}, n.headers = Sa(Sa(Sa({}, r), o), l.headers), [2, {
                                        url: Ga(t),
                                        options: n
                                    }]
                                })
                            })
                        }
                    }
                }(s);
                return {
                    v1GroupsIconsGet: function(n, r, a, o, i) {
                        return Ra(this, void 0, Promise, function() {
                            var t;
                            return Ea(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, u.v1GroupsIconsGet(n, r, a, o, i)];
                                    case 1:
                                        return t = e.sent(), [2, wa(t, y(), ma, s)]
                                }
                            })
                        })
                    }
                }
            }
            var no, ro, ae = (Wr(ao, no = Pn), ao.prototype.v1GroupsIconsGet = function(e, t, n, r, a) {
                var o = this;
                return to(this.configuration).v1GroupsIconsGet(e, t, n, r, a).then(function(e) {
                    return e(o.axios, o.basePath)
                })
            }, ao);

            function ao() {
                return null !== no && no.apply(this, arguments) || this
            }

            function oo(r) {
                var a = function(i) {
                    var e = this;
                    return {
                        v1MetadataGet: function(o) {
                            return void 0 === o && (o = {}), Ra(e, void 0, Promise, function() {
                                var t, n, r, a;
                                return Ea(this, function(e) {
                                    return t = new URL("/v1/metadata", Aa), i && (a = i.baseOptions), n = Sa(Sa({
                                        method: "GET"
                                    }, a), o), r = {}, Pa(t, {}, o.query), a = a && a.headers ? a.headers : {}, n.headers = Sa(Sa(Sa({}, r), a), o.headers), [2, {
                                        url: Ga(t),
                                        options: n
                                    }]
                                })
                            })
                        }
                    }
                }(r);
                return {
                    v1MetadataGet: function(n) {
                        return Ra(this, void 0, Promise, function() {
                            var t;
                            return Ea(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, a.v1MetadataGet(n)];
                                    case 1:
                                        return t = e.sent(), [2, wa(t, y(), ma, r)]
                                }
                            })
                        })
                    }
                }
            }

            function io() {
                return null !== ro && ro.apply(this, arguments) || this
            }

            function so(s) {
                var u = function(d) {
                    var e = this;
                    return {
                        v1UsersOutfitsGet: function(i, s, u, c, l) {
                            return void 0 === l && (l = {}), Ra(e, void 0, Promise, function() {
                                var t, n, r, a, o;
                                return Ea(this, function(e) {
                                    return ba("v1UsersOutfitsGet", "userOutfitIds", i), t = new URL("/v1/users/outfits", Aa), d && (o = d.baseOptions), n = Sa(Sa({
                                        method: "GET"
                                    }, o), l), r = {}, a = {}, i && (a.userOutfitIds = i.join(ga)), void 0 !== s && (a.size = s), void 0 !== u && (a.format = u), void 0 !== c && (a.isCircular = c), Pa(t, a, l.query), o = o && o.headers ? o.headers : {}, n.headers = Sa(Sa(Sa({}, r), o), l.headers), [2, {
                                        url: Ga(t),
                                        options: n
                                    }]
                                })
                            })
                        }
                    }
                }(s);
                return {
                    v1UsersOutfitsGet: function(n, r, a, o, i) {
                        return Ra(this, void 0, Promise, function() {
                            var t;
                            return Ea(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, u.v1UsersOutfitsGet(n, r, a, o, i)];
                                    case 1:
                                        return t = e.sent(), [2, wa(t, y(), ma, s)]
                                }
                            })
                        })
                    }
                }
            }
            Wr(io, ro = Pn), io.prototype.v1MetadataGet = function(e) {
                var t = this;
                return oo(this.configuration).v1MetadataGet(e).then(function(e) {
                    return e(t.axios, t.basePath)
                })
            };
            var uo, co, ie = (Wr(lo, uo = Pn), lo.prototype.v1UsersOutfitsGet = function(e, t, n, r, a) {
                var o = this;
                return so(this.configuration).v1UsersOutfitsGet(e, t, n, r, a).then(function(e) {
                    return e(o.axios, o.basePath)
                })
            }, lo);

            function lo() {
                return null !== uo && uo.apply(this, arguments) || this
            }

            function ho(u) {
                var c = function(h) {
                    var e = this;
                    return {
                        v1PlacesGameiconsGet: function(i, s, u, c, l, d) {
                            return void 0 === d && (d = {}), Ra(e, void 0, Promise, function() {
                                var t, n, r, a, o;
                                return Ea(this, function(e) {
                                    return ba("v1PlacesGameiconsGet", "placeIds", i), t = new URL("/v1/places/gameicons", Aa), h && (o = h.baseOptions), n = Sa(Sa({
                                        method: "GET"
                                    }, o), d), r = {}, a = {}, i && (a.placeIds = i.join(ga)), void 0 !== s && (a.returnPolicy = s), void 0 !== u && (a.size = u), void 0 !== c && (a.format = c), void 0 !== l && (a.isCircular = l), Pa(t, a, d.query), o = o && o.headers ? o.headers : {}, n.headers = Sa(Sa(Sa({}, r), o), d.headers), [2, {
                                        url: Ga(t),
                                        options: n
                                    }]
                                })
                            })
                        }
                    }
                }(u);
                return {
                    v1PlacesGameiconsGet: function(n, r, a, o, i, s) {
                        return Ra(this, void 0, Promise, function() {
                            var t;
                            return Ea(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, c.v1PlacesGameiconsGet(n, r, a, o, i, s)];
                                    case 1:
                                        return t = e.sent(), [2, wa(t, y(), ma, u)]
                                }
                            })
                        })
                    }
                }
            }

            function vo() {
                return null !== co && co.apply(this, arguments) || this
            }
            Wr(vo, co = Pn), vo.prototype.v1PlacesGameiconsGet = function(e, t, n, r, a, o) {
                var i = this;
                return ho(this.configuration).v1PlacesGameiconsGet(e, t, n, r, a, o).then(function(e) {
                    return e(i.axios, i.basePath)
                })
            };
            var po = m.EnvironmentUrls.thumbnailsApi,
                fo = new En,
                mo = new K;
            (En = bo = bo || {}).PlaceHolder = "PlaceHolder", En.AutoGenerated = "AutoGenerated", En.ForceAutoGenerated = "ForceAutoGenerated", (K = wo = wo || {}).Large = "150x150", K.Default = "50x50", (En = Ro = Ro || {}).width768 = "768x432", En.width576 = "576x324", En.width480 = "480x270", En.width384 = "384x216", En.width256 = "256x144", (xo = xo || {}).Png = "Png";
            var go, Io, K = {
                    getIcons: function(e, t, n, r, a) {
                        return fo.v1GamesIconsGet(e, t, n, r, a, {
                            withCredentials: !0
                        })
                    },
                    getUniverseThumbnails: function(e, t, n, r) {
                        return fo.v1GamesMultigetThumbnailsGet(e, 1, !0, t, n, r, {
                            withCredentials: !0
                        }).then(function(e) {
                            var t = e.data,
                                n = e.status,
                                r = e.statusText,
                                a = e.headers,
                                e = e.request;
                            return {
                                data: {
                                    data: null === (t = null == t ? void 0 : t.data) || void 0 === t ? void 0 : t.map(function(e) {
                                        var t = null === (t = e.thumbnails) || void 0 === t ? void 0 : t[0];
                                        return {
                                            targetId: e.universeId,
                                            state: null == t ? void 0 : t.state,
                                            imageUrl: null == t ? void 0 : t.imageUrl
                                        }
                                    })
                                },
                                status: n,
                                statusText: r,
                                headers: a,
                                request: e
                            }
                        })
                    },
                    getAllUniverseThumbnails: function(e, t, n, r, a) {
                        return void 0 === a && (a = 10), fo.v1GamesMultigetThumbnailsGet(e, a, !0, t, n, r, {
                            withCredentials: !0
                        })
                    },
                    getGamePassIcons: function(e, t, n, r) {
                        return mo.v1GamePassesGet(e, t, n, r, {
                            withCredentials: !0
                        })
                    },
                    getThumbnailsByThumbnailIds: function(e, t, n, r, a) {
                        return fo.v1GamesUniverseIdThumbnailsGet(e, t, n, r, a, {
                            withCredentials: !0
                        })
                    },
                    getPlacesGameIcons: function(e, t, n, r, a) {
                        var o = {
                            url: po + "/v1/places/gameicons",
                            withCredentials: !0,
                            retryable: !0
                        };
                        return rt.get(o, {
                            placeIds: e,
                            returnPolicy: t,
                            size: n,
                            format: r,
                            isCircular: a
                        })
                    },
                    ReturnPolicy: bo,
                    Size: wo,
                    GameThumbnailSize: Ro,
                    FileType: xo
                },
                yo = new Z,
                En = {
                    getMetadata: function() {
                        return yo.v1TranslationAnalyticsMetadataGet({
                            withCredentials: !0
                        })
                    },
                    requestReport: function(e, t, n, r, a) {
                        a = {
                            startDateTime: t,
                            endDateTime: n,
                            reportType: r,
                            reportSubjectTargetId: a
                        };
                        return yo.v1TranslationAnalyticsGamesGameIdRequestTranslationAnalyticsReportPost(e, a, {
                            withCredentials: !0
                        })
                    },
                    downloadReport: function(e, t, n, r, a) {
                        return yo.v1TranslationAnalyticsGamesGameIdDownloadTranslationAnalyticsReportGet(e, t, n, r, a, {
                            withCredentials: !0,
                            responseType: "arraybuffer"
                        })
                    }
                },
                bo = (go = function(e, t) {
                    return (go = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function(e, t) {
                            e.__proto__ = t
                        } || function(e, t) {
                            for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
                        })(e, t)
                }, function(e, t) {
                    if ("function" != typeof t && null !== t) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");

                    function n() {
                        this.constructor = e
                    }
                    go(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                }),
                Po = m.EnvironmentUrls.gamesApi.replace(/\/+$/, ""),
                Go = ",",
                wo = function(e, t, n) {
                    void 0 === t && (t = Po), void 0 === n && (n = F), this.basePath = t, this.axios = n, e && (this.configuration = e, this.basePath = e.basePath || this.basePath)
                },
                Co = (Io = Error, bo(To, Io), To);

            function To(e, t) {
                t = Io.call(this, t) || this;
                return t.field = e, t.name = "RequiredError", t
            }
            var Ao, So, Ro = (Ao = function(e, t) {
                    return (Ao = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function(e, t) {
                            e.__proto__ = t
                        } || function(e, t) {
                            for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
                        })(e, t)
                }, function(e, t) {
                    if ("function" != typeof t && null !== t) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");

                    function n() {
                        this.constructor = e
                    }
                    Ao(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                }),
                Eo = function() {
                    return (Eo = Object.assign || function(e) {
                        for (var t, n = 1, r = arguments.length; n < r; n++)
                            for (var a in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
                        return e
                    }).apply(this, arguments)
                };

            function Lo(o) {
                return {
                    v1GamesUniverseIdFavoritesCountGet: function(e, t) {
                        if (void 0 === t && (t = {}), null == e) throw new Co("universeId", "Required parameter universeId was null or undefined when calling v1GamesUniverseIdFavoritesCountGet.");
                        e = "/v1/games/{universeId}/favorites/count".replace("{universeId}", encodeURIComponent(String(e))), e = Gt.Qc(e, !0);
                        o && (n = o.baseOptions);
                        var n = Eo(Eo({
                            method: "GET"
                        }, n), t);
                        return e.query = Eo(Eo(Eo({}, e.query), {}), t.query), delete e.search, n.headers = Eo(Eo({}, {}), t.headers), {
                            url: Gt.WU(e),
                            options: n
                        }
                    },
                    v1GamesUniverseIdFavoritesGet: function(e, t) {
                        if (void 0 === t && (t = {}), null == e) throw new Co("universeId", "Required parameter universeId was null or undefined when calling v1GamesUniverseIdFavoritesGet.");
                        e = "/v1/games/{universeId}/favorites".replace("{universeId}", encodeURIComponent(String(e))), e = Gt.Qc(e, !0);
                        o && (n = o.baseOptions);
                        var n = Eo(Eo({
                            method: "GET"
                        }, n), t);
                        return e.query = Eo(Eo(Eo({}, e.query), {}), t.query), delete e.search, n.headers = Eo(Eo({}, {}), t.headers), {
                            url: Gt.WU(e),
                            options: n
                        }
                    },
                    v1GamesUniverseIdFavoritesPost: function(e, t, n) {
                        if (void 0 === n && (n = {}), null == e) throw new Co("universeId", "Required parameter universeId was null or undefined when calling v1GamesUniverseIdFavoritesPost.");
                        if (null == t) throw new Co("request", "Required parameter request was null or undefined when calling v1GamesUniverseIdFavoritesPost.");
                        var r = "/v1/games/{universeId}/favorites".replace("{universeId}", encodeURIComponent(String(e))),
                            e = Gt.Qc(r, !0);
                        o && (a = o.baseOptions);
                        var r = Eo(Eo({
                                method: "POST"
                            }, a), n),
                            a = {};
                        a["Content-Type"] = "application/json", e.query = Eo(Eo(Eo({}, e.query), {}), n.query), delete e.search, r.headers = Eo(Eo({}, a), n.headers);
                        return r.data = JSON.stringify(void 0 !== t ? t : {}), {
                            url: Gt.WU(e),
                            options: r
                        }
                    }
                }
            }

            function Uo(a) {
                return {
                    v1GamesUniverseIdFavoritesCountGet: function(e, t) {
                        var n = Lo(a).v1GamesUniverseIdFavoritesCountGet(e, t);
                        return function(e, t) {
                            void 0 === e && (e = F), void 0 === t && (t = Po);
                            t = Eo(Eo({}, n.options), {
                                url: t + n.url
                            });
                            return e.request(t)
                        }
                    },
                    v1GamesUniverseIdFavoritesGet: function(e, t) {
                        var n = Lo(a).v1GamesUniverseIdFavoritesGet(e, t);
                        return function(e, t) {
                            void 0 === e && (e = F), void 0 === t && (t = Po);
                            t = Eo(Eo({}, n.options), {
                                url: t + n.url
                            });
                            return e.request(t)
                        }
                    },
                    v1GamesUniverseIdFavoritesPost: function(e, t, n) {
                        var r = Lo(a).v1GamesUniverseIdFavoritesPost(e, t, n);
                        return function(e, t) {
                            void 0 === e && (e = F), void 0 === t && (t = Po);
                            t = Eo(Eo({}, r.options), {
                                url: t + r.url
                            });
                            return e.request(t)
                        }
                    }
                }
            }

            function qo() {
                return null !== So && So.apply(this, arguments) || this
            }

            function Oo(i) {
                return {
                    v1GamesUniverseIdGamePassesGet: function(e, t, n, r, a) {
                        var s, o = (s = i, function(e, t, n, r, a) {
                            if (void 0 === a && (a = {}), null == e) throw new Co("universeId", "Required parameter universeId was null or undefined when calling v1GamesUniverseIdGamePassesGet.");
                            var o = "/v1/games/{universeId}/game-passes".replace("{universeId}", encodeURIComponent(String(e))),
                                e = Gt.Qc(o, !0);
                            s && (i = s.baseOptions);
                            var o = Eo(Eo({
                                    method: "GET"
                                }, i), a),
                                i = {};
                            return void 0 !== t && (i.sortOrder = t), void 0 !== n && (i.limit = n), void 0 !== r && (i.cursor = r), e.query = Eo(Eo(Eo({}, e.query), i), a.query), delete e.search, o.headers = Eo(Eo({}, {}), a.headers), {
                                url: Gt.WU(e),
                                options: o
                            }
                        }(e, t, n, r, a));
                        return function(e, t) {
                            void 0 === e && (e = F), void 0 === t && (t = Po);
                            t = Eo(Eo({}, o.options), {
                                url: t + o.url
                            });
                            return e.request(t)
                        }
                    }
                }
            }(xo = {}).GamesDefaultSorts = "GamesDefaultSorts", xo.GamesAllSorts = "GamesAllSorts", xo.HomeSorts = "HomeSorts", xo.ChatSorts = "ChatSorts", xo.UnifiedHomeSorts = "UnifiedHomeSorts", xo.AbTestSorts = "AbTestSorts", xo.GamesPageAbTestSorts1 = "GamesPageAbTestSorts1", xo.GamesPageAbTestSorts2 = "GamesPageAbTestSorts2", (Z = {}).MorphToR6 = "MorphToR6", Z.PlayerChoice = "PlayerChoice", Z.MorphToR15 = "MorphToR15", (bo = {}).UnplayableOtherReason = "UnplayableOtherReason", bo.Playable = "Playable", bo.GuestProhibited = "GuestProhibited", bo.GameUnapproved = "GameUnapproved", bo.IncorrectConfiguration = "IncorrectConfiguration", bo.UniverseRootPlaceIsPrivate = "UniverseRootPlaceIsPrivate", bo.InsufficientPermissionFriendsOnly = "InsufficientPermissionFriendsOnly", bo.InsufficientPermissionGroupOnly = "InsufficientPermissionGroupOnly", bo.DeviceRestricted = "DeviceRestricted", bo.UnderReview = "UnderReview", bo.PurchaseRequired = "PurchaseRequired", bo.AccountRestricted = "AccountRestricted", bo.TemporarilyUnavailable = "TemporarilyUnavailable", (xo = {}).Facebook = "Facebook", xo.Twitter = "Twitter", xo.YouTube = "YouTube", xo.Twitch = "Twitch", xo.GooglePlus = "GooglePlus", xo.Discord = "Discord", xo.RobloxGroup = "RobloxGroup", xo.Amazon = "Amazon", (Z = {}).Asc = "Asc", Z.Desc = "Desc", (bo = {}).Forward = "Forward", bo.Backward = "Backward", Ro(qo, So = wo), qo.prototype.v1GamesUniverseIdFavoritesCountGet = function(e, t) {
                return Uo(this.configuration).v1GamesUniverseIdFavoritesCountGet(e, t)(this.axios, this.basePath)
            }, qo.prototype.v1GamesUniverseIdFavoritesGet = function(e, t) {
                return Uo(this.configuration).v1GamesUniverseIdFavoritesGet(e, t)(this.axios, this.basePath)
            }, qo.prototype.v1GamesUniverseIdFavoritesPost = function(e, t, n) {
                return Uo(this.configuration).v1GamesUniverseIdFavoritesPost(e, t, n)(this.axios, this.basePath)
            };
            var Do, xo = (Ro(_o, Do = wo), _o.prototype.v1GamesUniverseIdGamePassesGet = function(e, t, n, r, a) {
                return Oo(this.configuration).v1GamesUniverseIdGamePassesGet(e, t, n, r, a)(this.axios, this.basePath)
            }, _o);

            function _o() {
                return null !== Do && Do.apply(this, arguments) || this
            }

            function Bo(y) {
                return {
                    v1GamesGameThumbnailGet: function(e, t, n, r) {
                        if (void 0 === r && (r = {}), null == e) throw new Co("imageToken", "Required parameter imageToken was null or undefined when calling v1GamesGameThumbnailGet.");
                        var a = Gt.Qc("/v1/games/game-thumbnail", !0);
                        y && (i = y.baseOptions);
                        var o = Eo(Eo({
                                method: "GET"
                            }, i), r),
                            i = {};
                        return void 0 !== e && (i.imageToken = e), void 0 !== t && (i.height = t), void 0 !== n && (i.width = n), a.query = Eo(Eo(Eo({}, a.query), i), r.query), delete a.search, o.headers = Eo(Eo({}, {}), r.headers), {
                            url: Gt.WU(a),
                            options: o
                        }
                    },
                    v1GamesGameThumbnailsGet: function(e, t, n, r) {
                        if (void 0 === r && (r = {}), null == e) throw new Co("imageTokens", "Required parameter imageTokens was null or undefined when calling v1GamesGameThumbnailsGet.");
                        var a = Gt.Qc("/v1/games/game-thumbnails", !0);
                        y && (i = y.baseOptions);
                        var o = Eo(Eo({
                                method: "GET"
                            }, i), r),
                            i = {};
                        return e && (i.imageTokens = e), void 0 !== t && (i.height = t), void 0 !== n && (i.width = n), a.query = Eo(Eo(Eo({}, a.query), i), r.query), delete a.search, o.headers = Eo(Eo({}, {}), r.headers), {
                            url: Gt.WU(a),
                            options: o
                        }
                    },
                    v1GamesGamesProductInfoGet: function(e, t) {
                        if (void 0 === t && (t = {}), null == e) throw new Co("universeIds", "Required parameter universeIds was null or undefined when calling v1GamesGamesProductInfoGet.");
                        var n = Gt.Qc("/v1/games/games-product-info", !0);
                        y && (a = y.baseOptions);
                        var r = Eo(Eo({
                                method: "GET"
                            }, a), t),
                            a = {};
                        return e && (a.universeIds = e.join(Go)), n.query = Eo(Eo(Eo({}, n.query), a), t.query), delete n.search, r.headers = Eo(Eo({}, {}), t.headers), {
                            url: Gt.WU(n),
                            options: r
                        }
                    },
                    v1GamesGet: function(e, t) {
                        if (void 0 === t && (t = {}), null == e) throw new Co("universeIds", "Required parameter universeIds was null or undefined when calling v1GamesGet.");
                        var n = Gt.Qc("/v1/games", !0);
                        y && (a = y.baseOptions);
                        var r = Eo(Eo({
                                method: "GET"
                            }, a), t),
                            a = {};
                        return e && (a.universeIds = e.join(Go)), n.query = Eo(Eo(Eo({}, n.query), a), t.query), delete n.search, r.headers = Eo(Eo({}, {}), t.headers), {
                            url: Gt.WU(n),
                            options: r
                        }
                    },
                    v1GamesListGet: function(e, t, n, r, a, o, i, s, u, c, l, d, h, v, p, f) {
                        void 0 === f && (f = {});
                        var m = Gt.Qc("/v1/games/list", !0);
                        y && (I = y.baseOptions);
                        var g = Eo(Eo({
                                method: "GET"
                            }, I), f),
                            I = {};
                        return void 0 !== e && (I["model.sortToken"] = e), void 0 !== t && (I["model.gameFilter"] = t), void 0 !== n && (I["model.timeFilter"] = n), void 0 !== r && (I["model.genreFilter"] = r), void 0 !== a && (I["model.exclusiveStartId"] = a), void 0 !== o && (I["model.sortOrder"] = o), void 0 !== i && (I["model.gameSetTargetId"] = i), void 0 !== s && (I["model.keyword"] = s), void 0 !== u && (I["model.startRows"] = u), void 0 !== c && (I["model.maxRows"] = c), void 0 !== l && (I["model.isKeywordSuggestionEnabled"] = l), void 0 !== d && (I["model.contextCountryRegionId"] = d), void 0 !== h && (I["model.contextUniverseId"] = h), void 0 !== v && (I["model.pageId"] = v), void 0 !== p && (I["model.sortPosition"] = p), m.query = Eo(Eo(Eo({}, m.query), I), f.query), delete m.search, g.headers = Eo(Eo({}, {}), f.headers), {
                            url: Gt.WU(m),
                            options: g
                        }
                    },
                    v1GamesMultigetPlaceDetailsGet: function(e, t) {
                        if (void 0 === t && (t = {}), null == e) throw new Co("placeIds", "Required parameter placeIds was null or undefined when calling v1GamesMultigetPlaceDetailsGet.");
                        var n = Gt.Qc("/v1/games/multiget-place-details", !0);
                        y && (a = y.baseOptions);
                        var r = Eo(Eo({
                                method: "GET"
                            }, a), t),
                            a = {};
                        return e && (a.placeIds = e), n.query = Eo(Eo(Eo({}, n.query), a), t.query), delete n.search, r.headers = Eo(Eo({}, {}), t.headers), {
                            url: Gt.WU(n),
                            options: r
                        }
                    },
                    v1GamesMultigetPlayabilityStatusGet: function(e, t) {
                        if (void 0 === t && (t = {}), null == e) throw new Co("universeIds", "Required parameter universeIds was null or undefined when calling v1GamesMultigetPlayabilityStatusGet.");
                        var n = Gt.Qc("/v1/games/multiget-playability-status", !0);
                        y && (a = y.baseOptions);
                        var r = Eo(Eo({
                                method: "GET"
                            }, a), t),
                            a = {};
                        return e && (a.universeIds = e.join(Go)), n.query = Eo(Eo(Eo({}, n.query), a), t.query), delete n.search, r.headers = Eo(Eo({}, {}), t.headers), {
                            url: Gt.WU(n),
                            options: r
                        }
                    },
                    v1GamesPlaceIdServersServerTypeGet: function(e, t, n, r, a, o) {
                        if (void 0 === o && (o = {}), null == e) throw new Co("placeId", "Required parameter placeId was null or undefined when calling v1GamesPlaceIdServersServerTypeGet.");
                        if (null == t) throw new Co("serverType", "Required parameter serverType was null or undefined when calling v1GamesPlaceIdServersServerTypeGet.");
                        e = "/v1/games/{placeId}/servers/{serverType}".replace("{placeId}", encodeURIComponent(String(e))).replace("{serverType}", encodeURIComponent(String(t))), t = Gt.Qc(e, !0);
                        y && (i = y.baseOptions);
                        var e = Eo(Eo({
                                method: "GET"
                            }, i), o),
                            i = {};
                        return void 0 !== n && (i.sortOrder = n), void 0 !== r && (i.limit = r), void 0 !== a && (i.cursor = a), t.query = Eo(Eo(Eo({}, t.query), i), o.query), delete t.search, e.headers = Eo(Eo({}, {}), o.headers), {
                            url: Gt.WU(t),
                            options: e
                        }
                    },
                    v1GamesPlacesPlaceIdMetadataPost: function(e, t, n) {
                        if (void 0 === n && (n = {}), null == e) throw new Co("placeId", "Required parameter placeId was null or undefined when calling v1GamesPlacesPlaceIdMetadataPost.");
                        if (null == t) throw new Co("request", "Required parameter request was null or undefined when calling v1GamesPlacesPlaceIdMetadataPost.");
                        var r = "/v1/games/places/{placeId}/metadata".replace("{placeId}", encodeURIComponent(String(e))),
                            e = Gt.Qc(r, !0);
                        y && (a = y.baseOptions);
                        var r = Eo(Eo({
                                method: "POST"
                            }, a), n),
                            a = {};
                        a["Content-Type"] = "application/json", e.query = Eo(Eo(Eo({}, e.query), {}), n.query), delete e.search, r.headers = Eo(Eo({}, a), n.headers);
                        return r.data = JSON.stringify(void 0 !== t ? t : {}), {
                            url: Gt.WU(e),
                            options: r
                        }
                    },
                    v1GamesRecommendationsAlgorithmAlgorithmNameGet: function(e, t, n, r) {
                        if (void 0 === r && (r = {}), null == e) throw new Co("algorithmName", "Required parameter algorithmName was null or undefined when calling v1GamesRecommendationsAlgorithmAlgorithmNameGet.");
                        var a = "/v1/games/recommendations/algorithm/{algorithmName}".replace("{algorithmName}", encodeURIComponent(String(e))),
                            e = Gt.Qc(a, !0);
                        y && (o = y.baseOptions);
                        var a = Eo(Eo({
                                method: "GET"
                            }, o), r),
                            o = {};
                        return void 0 !== t && (o["model.paginationKey"] = t), void 0 !== n && (o["model.maxRows"] = n), e.query = Eo(Eo(Eo({}, e.query), o), r.query), delete e.search, a.headers = Eo(Eo({}, {}), r.headers), {
                            url: Gt.WU(e),
                            options: a
                        }
                    },
                    v1GamesRecommendationsGameUniverseIdGet: function(e, t, n, r) {
                        if (void 0 === r && (r = {}), null == e) throw new Co("universeId", "Required parameter universeId was null or undefined when calling v1GamesRecommendationsGameUniverseIdGet.");
                        var a = "/v1/games/recommendations/game/{universeId}".replace("{universeId}", encodeURIComponent(String(e))),
                            e = Gt.Qc(a, !0);
                        y && (o = y.baseOptions);
                        var a = Eo(Eo({
                                method: "GET"
                            }, o), r),
                            o = {};
                        return void 0 !== t && (o["model.paginationKey"] = t), void 0 !== n && (o["model.maxRows"] = n), e.query = Eo(Eo(Eo({}, e.query), o), r.query), delete e.search, a.headers = Eo(Eo({}, {}), r.headers), {
                            url: Gt.WU(e),
                            options: a
                        }
                    },
                    v1GamesSortsGet: function(e, t) {
                        void 0 === t && (t = {});
                        var n = Gt.Qc("/v1/games/sorts", !0);
                        y && (a = y.baseOptions);
                        var r = Eo(Eo({
                                method: "GET"
                            }, a), t),
                            a = {};
                        return void 0 !== e && (a["model.gameSortsContext"] = e), n.query = Eo(Eo(Eo({}, n.query), a), t.query), delete n.search, r.headers = Eo(Eo({}, {}), t.headers), {
                            url: Gt.WU(n),
                            options: r
                        }
                    },
                    v1GamesUniverseIdIconGet: function(e, t) {
                        if (void 0 === t && (t = {}), null == e) throw new Co("universeId", "Required parameter universeId was null or undefined when calling v1GamesUniverseIdIconGet.");
                        e = "/v1/games/{universeId}/icon".replace("{universeId}", encodeURIComponent(String(e))), e = Gt.Qc(e, !0);
                        y && (n = y.baseOptions);
                        var n = Eo(Eo({
                            method: "GET"
                        }, n), t);
                        return e.query = Eo(Eo(Eo({}, e.query), {}), t.query), delete e.search, n.headers = Eo(Eo({}, {}), t.headers), {
                            url: Gt.WU(e),
                            options: n
                        }
                    },
                    v1GamesUniverseIdMediaGet: function(e, t) {
                        if (void 0 === t && (t = {}), null == e) throw new Co("universeId", "Required parameter universeId was null or undefined when calling v1GamesUniverseIdMediaGet.");
                        e = "/v1/games/{universeId}/media".replace("{universeId}", encodeURIComponent(String(e))), e = Gt.Qc(e, !0);
                        y && (n = y.baseOptions);
                        var n = Eo(Eo({
                            method: "GET"
                        }, n), t);
                        return e.query = Eo(Eo(Eo({}, e.query), {}), t.query), delete e.search, n.headers = Eo(Eo({}, {}), t.headers), {
                            url: Gt.WU(e),
                            options: n
                        }
                    }
                }
            }

            function Fo(g) {
                return {
                    v1GamesGameThumbnailGet: function(e, t, n, r) {
                        var a = Bo(g).v1GamesGameThumbnailGet(e, t, n, r);
                        return function(e, t) {
                            void 0 === e && (e = F), void 0 === t && (t = Po);
                            t = Eo(Eo({}, a.options), {
                                url: t + a.url
                            });
                            return e.request(t)
                        }
                    },
                    v1GamesGameThumbnailsGet: function(e, t, n, r) {
                        var a = Bo(g).v1GamesGameThumbnailsGet(e, t, n, r);
                        return function(e, t) {
                            void 0 === e && (e = F), void 0 === t && (t = Po);
                            t = Eo(Eo({}, a.options), {
                                url: t + a.url
                            });
                            return e.request(t)
                        }
                    },
                    v1GamesGamesProductInfoGet: function(e, t) {
                        var n = Bo(g).v1GamesGamesProductInfoGet(e, t);
                        return function(e, t) {
                            void 0 === e && (e = F), void 0 === t && (t = Po);
                            t = Eo(Eo({}, n.options), {
                                url: t + n.url
                            });
                            return e.request(t)
                        }
                    },
                    v1GamesGet: function(e, t) {
                        var n = Bo(g).v1GamesGet(e, t);
                        return function(e, t) {
                            void 0 === e && (e = F), void 0 === t && (t = Po);
                            t = Eo(Eo({}, n.options), {
                                url: t + n.url
                            });
                            return e.request(t)
                        }
                    },
                    v1GamesListGet: function(e, t, n, r, a, o, i, s, u, c, l, d, h, v, p, f) {
                        var m = Bo(g).v1GamesListGet(e, t, n, r, a, o, i, s, u, c, l, d, h, v, p, f);
                        return function(e, t) {
                            void 0 === e && (e = F), void 0 === t && (t = Po);
                            t = Eo(Eo({}, m.options), {
                                url: t + m.url
                            });
                            return e.request(t)
                        }
                    },
                    v1GamesMultigetPlaceDetailsGet: function(e, t) {
                        var n = Bo(g).v1GamesMultigetPlaceDetailsGet(e, t);
                        return function(e, t) {
                            void 0 === e && (e = F), void 0 === t && (t = Po);
                            t = Eo(Eo({}, n.options), {
                                url: t + n.url
                            });
                            return e.request(t)
                        }
                    },
                    v1GamesMultigetPlayabilityStatusGet: function(e, t) {
                        var n = Bo(g).v1GamesMultigetPlayabilityStatusGet(e, t);
                        return function(e, t) {
                            void 0 === e && (e = F), void 0 === t && (t = Po);
                            t = Eo(Eo({}, n.options), {
                                url: t + n.url
                            });
                            return e.request(t)
                        }
                    },
                    v1GamesPlaceIdServersServerTypeGet: function(e, t, n, r, a, o) {
                        var i = Bo(g).v1GamesPlaceIdServersServerTypeGet(e, t, n, r, a, o);
                        return function(e, t) {
                            void 0 === e && (e = F), void 0 === t && (t = Po);
                            t = Eo(Eo({}, i.options), {
                                url: t + i.url
                            });
                            return e.request(t)
                        }
                    },
                    v1GamesPlacesPlaceIdMetadataPost: function(e, t, n) {
                        var r = Bo(g).v1GamesPlacesPlaceIdMetadataPost(e, t, n);
                        return function(e, t) {
                            void 0 === e && (e = F), void 0 === t && (t = Po);
                            t = Eo(Eo({}, r.options), {
                                url: t + r.url
                            });
                            return e.request(t)
                        }
                    },
                    v1GamesRecommendationsAlgorithmAlgorithmNameGet: function(e, t, n, r) {
                        var a = Bo(g).v1GamesRecommendationsAlgorithmAlgorithmNameGet(e, t, n, r);
                        return function(e, t) {
                            void 0 === e && (e = F), void 0 === t && (t = Po);
                            t = Eo(Eo({}, a.options), {
                                url: t + a.url
                            });
                            return e.request(t)
                        }
                    },
                    v1GamesRecommendationsGameUniverseIdGet: function(e, t, n, r) {
                        var a = Bo(g).v1GamesRecommendationsGameUniverseIdGet(e, t, n, r);
                        return function(e, t) {
                            void 0 === e && (e = F), void 0 === t && (t = Po);
                            t = Eo(Eo({}, a.options), {
                                url: t + a.url
                            });
                            return e.request(t)
                        }
                    },
                    v1GamesSortsGet: function(e, t) {
                        var n = Bo(g).v1GamesSortsGet(e, t);
                        return function(e, t) {
                            void 0 === e && (e = F), void 0 === t && (t = Po);
                            t = Eo(Eo({}, n.options), {
                                url: t + n.url
                            });
                            return e.request(t)
                        }
                    },
                    v1GamesUniverseIdIconGet: function(e, t) {
                        var n = Bo(g).v1GamesUniverseIdIconGet(e, t);
                        return function(e, t) {
                            void 0 === e && (e = F), void 0 === t && (t = Po);
                            t = Eo(Eo({}, n.options), {
                                url: t + n.url
                            });
                            return e.request(t)
                        }
                    },
                    v1GamesUniverseIdMediaGet: function(e, t) {
                        var n = Bo(g).v1GamesUniverseIdMediaGet(e, t);
                        return function(e, t) {
                            void 0 === e && (e = F), void 0 === t && (t = Po);
                            t = Eo(Eo({}, n.options), {
                                url: t + n.url
                            });
                            return e.request(t)
                        }
                    }
                }
            }
            var No, ko, Mo, jo, Z = (Ro(zo, No = wo), zo.prototype.v1GamesGameThumbnailGet = function(e, t, n, r) {
                return Fo(this.configuration).v1GamesGameThumbnailGet(e, t, n, r)(this.axios, this.basePath)
            }, zo.prototype.v1GamesGameThumbnailsGet = function(e, t, n, r) {
                return Fo(this.configuration).v1GamesGameThumbnailsGet(e, t, n, r)(this.axios, this.basePath)
            }, zo.prototype.v1GamesGamesProductInfoGet = function(e, t) {
                return Fo(this.configuration).v1GamesGamesProductInfoGet(e, t)(this.axios, this.basePath)
            }, zo.prototype.v1GamesGet = function(e, t) {
                return Fo(this.configuration).v1GamesGet(e, t)(this.axios, this.basePath)
            }, zo.prototype.v1GamesListGet = function(e, t, n, r, a, o, i, s, u, c, l, d, h, v, p, f) {
                return Fo(this.configuration).v1GamesListGet(e, t, n, r, a, o, i, s, u, c, l, d, h, v, p, f)(this.axios, this.basePath)
            }, zo.prototype.v1GamesMultigetPlaceDetailsGet = function(e, t) {
                return Fo(this.configuration).v1GamesMultigetPlaceDetailsGet(e, t)(this.axios, this.basePath)
            }, zo.prototype.v1GamesMultigetPlayabilityStatusGet = function(e, t) {
                return Fo(this.configuration).v1GamesMultigetPlayabilityStatusGet(e, t)(this.axios, this.basePath)
            }, zo.prototype.v1GamesPlaceIdServersServerTypeGet = function(e, t, n, r, a, o) {
                return Fo(this.configuration).v1GamesPlaceIdServersServerTypeGet(e, t, n, r, a, o)(this.axios, this.basePath)
            }, zo.prototype.v1GamesPlacesPlaceIdMetadataPost = function(e, t, n) {
                return Fo(this.configuration).v1GamesPlacesPlaceIdMetadataPost(e, t, n)(this.axios, this.basePath)
            }, zo.prototype.v1GamesRecommendationsAlgorithmAlgorithmNameGet = function(e, t, n, r) {
                return Fo(this.configuration).v1GamesRecommendationsAlgorithmAlgorithmNameGet(e, t, n, r)(this.axios, this.basePath)
            }, zo.prototype.v1GamesRecommendationsGameUniverseIdGet = function(e, t, n, r) {
                return Fo(this.configuration).v1GamesRecommendationsGameUniverseIdGet(e, t, n, r)(this.axios, this.basePath)
            }, zo.prototype.v1GamesSortsGet = function(e, t) {
                return Fo(this.configuration).v1GamesSortsGet(e, t)(this.axios, this.basePath)
            }, zo.prototype.v1GamesUniverseIdIconGet = function(e, t) {
                return Fo(this.configuration).v1GamesUniverseIdIconGet(e, t)(this.axios, this.basePath)
            }, zo.prototype.v1GamesUniverseIdMediaGet = function(e, t) {
                return Fo(this.configuration).v1GamesUniverseIdMediaGet(e, t)(this.axios, this.basePath)
            }, zo);

            function zo() {
                return null !== No && No.apply(this, arguments) || this
            }

            function Wo(a) {
                return {
                    v1GamesUniverseIdSocialLinksListGet: function(e, t) {
                        var r, n = (r = a, function(e, t) {
                            if (void 0 === t && (t = {}), null == e) throw new Co("universeId", "Required parameter universeId was null or undefined when calling v1GamesUniverseIdSocialLinksListGet.");
                            e = "/v1/games/{universeId}/social-links/list".replace("{universeId}", encodeURIComponent(String(e))), e = Gt.Qc(e, !0);
                            r && (n = r.baseOptions);
                            var n = Eo(Eo({
                                method: "GET"
                            }, n), t);
                            return e.query = Eo(Eo(Eo({}, e.query), {}), t.query), delete e.search, n.headers = Eo(Eo({}, {}), t.headers), {
                                url: Gt.WU(e),
                                options: n
                            }
                        }(e, t));
                        return function(e, t) {
                            void 0 === e && (e = F), void 0 === t && (t = Po);
                            t = Eo(Eo({}, n.options), {
                                url: t + n.url
                            });
                            return e.request(t)
                        }
                    }
                }
            }

            function Vo() {
                return null !== ko && ko.apply(this, arguments) || this
            }

            function Ho(o) {
                return {
                    v1GamesVipServersUniverseIdPost: function(e, t, n) {
                        if (void 0 === n && (n = {}), null == e) throw new Co("universeId", "Required parameter universeId was null or undefined when calling v1GamesVipServersUniverseIdPost.");
                        if (null == t) throw new Co("requestBody", "Required parameter requestBody was null or undefined when calling v1GamesVipServersUniverseIdPost.");
                        var r = "/v1/games/vip-servers/{universeId}".replace("{universeId}", encodeURIComponent(String(e))),
                            e = Gt.Qc(r, !0);
                        o && (a = o.baseOptions);
                        var r = Eo(Eo({
                                method: "POST"
                            }, a), n),
                            a = {};
                        a["Content-Type"] = "application/json", e.query = Eo(Eo(Eo({}, e.query), {}), n.query), delete e.search, r.headers = Eo(Eo({}, a), n.headers);
                        return r.data = JSON.stringify(void 0 !== t ? t : {}), {
                            url: Gt.WU(e),
                            options: r
                        }
                    },
                    v1VipServersIdGet: function(e, t) {
                        if (void 0 === t && (t = {}), null == e) throw new Co("id", "Required parameter id was null or undefined when calling v1VipServersIdGet.");
                        e = "/v1/vip-servers/{id}".replace("{id}", encodeURIComponent(String(e))), e = Gt.Qc(e, !0);
                        o && (n = o.baseOptions);
                        var n = Eo(Eo({
                            method: "GET"
                        }, n), t);
                        return e.query = Eo(Eo(Eo({}, e.query), {}), t.query), delete e.search, n.headers = Eo(Eo({}, {}), t.headers), {
                            url: Gt.WU(e),
                            options: n
                        }
                    },
                    v1VipServersIdPatch: function(e, t, n) {
                        if (void 0 === n && (n = {}), null == e) throw new Co("id", "Required parameter id was null or undefined when calling v1VipServersIdPatch.");
                        if (null == t) throw new Co("request", "Required parameter request was null or undefined when calling v1VipServersIdPatch.");
                        var r = "/v1/vip-servers/{id}".replace("{id}", encodeURIComponent(String(e))),
                            e = Gt.Qc(r, !0);
                        o && (a = o.baseOptions);
                        var r = Eo(Eo({
                                method: "PATCH"
                            }, a), n),
                            a = {};
                        a["Content-Type"] = "application/json", e.query = Eo(Eo(Eo({}, e.query), {}), n.query), delete e.search, r.headers = Eo(Eo({}, a), n.headers);
                        return r.data = JSON.stringify(void 0 !== t ? t : {}), {
                            url: Gt.WU(e),
                            options: r
                        }
                    },
                    v1VipServersIdPermissionsPatch: function(e, t, n) {
                        if (void 0 === n && (n = {}), null == e) throw new Co("id", "Required parameter id was null or undefined when calling v1VipServersIdPermissionsPatch.");
                        if (null == t) throw new Co("request", "Required parameter request was null or undefined when calling v1VipServersIdPermissionsPatch.");
                        var r = "/v1/vip-servers/{id}/permissions".replace("{id}", encodeURIComponent(String(e))),
                            e = Gt.Qc(r, !0);
                        o && (a = o.baseOptions);
                        var r = Eo(Eo({
                                method: "PATCH"
                            }, a), n),
                            a = {};
                        a["Content-Type"] = "application/json", e.query = Eo(Eo(Eo({}, e.query), {}), n.query), delete e.search, r.headers = Eo(Eo({}, a), n.headers);
                        return r.data = JSON.stringify(void 0 !== t ? t : {}), {
                            url: Gt.WU(e),
                            options: r
                        }
                    },
                    v1VipServersIdSubscriptionPatch: function(e, t, n) {
                        if (void 0 === n && (n = {}), null == e) throw new Co("id", "Required parameter id was null or undefined when calling v1VipServersIdSubscriptionPatch.");
                        if (null == t) throw new Co("request", "Required parameter request was null or undefined when calling v1VipServersIdSubscriptionPatch.");
                        var r = "/v1/vip-servers/{id}/subscription".replace("{id}", encodeURIComponent(String(e))),
                            e = Gt.Qc(r, !0);
                        o && (a = o.baseOptions);
                        var r = Eo(Eo({
                                method: "PATCH"
                            }, a), n),
                            a = {};
                        a["Content-Type"] = "application/json", e.query = Eo(Eo(Eo({}, e.query), {}), n.query), delete e.search, r.headers = Eo(Eo({}, a), n.headers);
                        return r.data = JSON.stringify(void 0 !== t ? t : {}), {
                            url: Gt.WU(e),
                            options: r
                        }
                    }
                }
            }

            function Qo(a) {
                return {
                    v1GamesVipServersUniverseIdPost: function(e, t, n) {
                        var r = Ho(a).v1GamesVipServersUniverseIdPost(e, t, n);
                        return function(e, t) {
                            void 0 === e && (e = F), void 0 === t && (t = Po);
                            t = Eo(Eo({}, r.options), {
                                url: t + r.url
                            });
                            return e.request(t)
                        }
                    },
                    v1VipServersIdGet: function(e, t) {
                        var n = Ho(a).v1VipServersIdGet(e, t);
                        return function(e, t) {
                            void 0 === e && (e = F), void 0 === t && (t = Po);
                            t = Eo(Eo({}, n.options), {
                                url: t + n.url
                            });
                            return e.request(t)
                        }
                    },
                    v1VipServersIdPatch: function(e, t, n) {
                        var r = Ho(a).v1VipServersIdPatch(e, t, n);
                        return function(e, t) {
                            void 0 === e && (e = F), void 0 === t && (t = Po);
                            t = Eo(Eo({}, r.options), {
                                url: t + r.url
                            });
                            return e.request(t)
                        }
                    },
                    v1VipServersIdPermissionsPatch: function(e, t, n) {
                        var r = Ho(a).v1VipServersIdPermissionsPatch(e, t, n);
                        return function(e, t) {
                            void 0 === e && (e = F), void 0 === t && (t = Po);
                            t = Eo(Eo({}, r.options), {
                                url: t + r.url
                            });
                            return e.request(t)
                        }
                    },
                    v1VipServersIdSubscriptionPatch: function(e, t, n) {
                        var r = Ho(a).v1VipServersIdSubscriptionPatch(e, t, n);
                        return function(e, t) {
                            void 0 === e && (e = F), void 0 === t && (t = Po);
                            t = Eo(Eo({}, r.options), {
                                url: t + r.url
                            });
                            return e.request(t)
                        }
                    }
                }
            }

            function Ko() {
                return null !== Mo && Mo.apply(this, arguments) || this
            }

            function Xo(o) {
                return {
                    v1GamesUniverseIdUserVotesPatch: function(e, t, n) {
                        if (void 0 === n && (n = {}), null == e) throw new Co("universeId", "Required parameter universeId was null or undefined when calling v1GamesUniverseIdUserVotesPatch.");
                        if (null == t) throw new Co("requestBody", "Required parameter requestBody was null or undefined when calling v1GamesUniverseIdUserVotesPatch.");
                        var r = "/v1/games/{universeId}/user-votes".replace("{universeId}", encodeURIComponent(String(e))),
                            e = Gt.Qc(r, !0);
                        o && (a = o.baseOptions);
                        var r = Eo(Eo({
                                method: "PATCH"
                            }, a), n),
                            a = {};
                        a["Content-Type"] = "application/json", e.query = Eo(Eo(Eo({}, e.query), {}), n.query), delete e.search, r.headers = Eo(Eo({}, a), n.headers);
                        return r.data = JSON.stringify(void 0 !== t ? t : {}), {
                            url: Gt.WU(e),
                            options: r
                        }
                    },
                    v1GamesUniverseIdVotesGet: function(e, t) {
                        if (void 0 === t && (t = {}), null == e) throw new Co("universeId", "Required parameter universeId was null or undefined when calling v1GamesUniverseIdVotesGet.");
                        e = "/v1/games/{universeId}/votes".replace("{universeId}", encodeURIComponent(String(e))), e = Gt.Qc(e, !0);
                        o && (n = o.baseOptions);
                        var n = Eo(Eo({
                            method: "GET"
                        }, n), t);
                        return e.query = Eo(Eo(Eo({}, e.query), {}), t.query), delete e.search, n.headers = Eo(Eo({}, {}), t.headers), {
                            url: Gt.WU(e),
                            options: n
                        }
                    },
                    v1GamesUniverseIdVotesUserGet: function(e, t) {
                        if (void 0 === t && (t = {}), null == e) throw new Co("universeId", "Required parameter universeId was null or undefined when calling v1GamesUniverseIdVotesUserGet.");
                        e = "/v1/games/{universeId}/votes/user".replace("{universeId}", encodeURIComponent(String(e))), e = Gt.Qc(e, !0);
                        o && (n = o.baseOptions);
                        var n = Eo(Eo({
                            method: "GET"
                        }, n), t);
                        return e.query = Eo(Eo(Eo({}, e.query), {}), t.query), delete e.search, n.headers = Eo(Eo({}, {}), t.headers), {
                            url: Gt.WU(e),
                            options: n
                        }
                    },
                    v1GamesVotesGet: function(e, t) {
                        if (void 0 === t && (t = {}), null == e) throw new Co("universeIds", "Required parameter universeIds was null or undefined when calling v1GamesVotesGet.");
                        var n = Gt.Qc("/v1/games/votes", !0);
                        o && (a = o.baseOptions);
                        var r = Eo(Eo({
                                method: "GET"
                            }, a), t),
                            a = {};
                        return e && (a.universeIds = e.join(Go)), n.query = Eo(Eo(Eo({}, n.query), a), t.query), delete n.search, r.headers = Eo(Eo({}, {}), t.headers), {
                            url: Gt.WU(n),
                            options: r
                        }
                    }
                }
            }

            function Jo(a) {
                return {
                    v1GamesUniverseIdUserVotesPatch: function(e, t, n) {
                        var r = Xo(a).v1GamesUniverseIdUserVotesPatch(e, t, n);
                        return function(e, t) {
                            void 0 === e && (e = F), void 0 === t && (t = Po);
                            t = Eo(Eo({}, r.options), {
                                url: t + r.url
                            });
                            return e.request(t)
                        }
                    },
                    v1GamesUniverseIdVotesGet: function(e, t) {
                        var n = Xo(a).v1GamesUniverseIdVotesGet(e, t);
                        return function(e, t) {
                            void 0 === e && (e = F), void 0 === t && (t = Po);
                            t = Eo(Eo({}, n.options), {
                                url: t + n.url
                            });
                            return e.request(t)
                        }
                    },
                    v1GamesUniverseIdVotesUserGet: function(e, t) {
                        var n = Xo(a).v1GamesUniverseIdVotesUserGet(e, t);
                        return function(e, t) {
                            void 0 === e && (e = F), void 0 === t && (t = Po);
                            t = Eo(Eo({}, n.options), {
                                url: t + n.url
                            });
                            return e.request(t)
                        }
                    },
                    v1GamesVotesGet: function(e, t) {
                        var n = Xo(a).v1GamesVotesGet(e, t);
                        return function(e, t) {
                            void 0 === e && (e = F), void 0 === t && (t = Po);
                            t = Eo(Eo({}, n.options), {
                                url: t + n.url
                            });
                            return e.request(t)
                        }
                    }
                }
            }

            function Yo() {
                return null !== jo && jo.apply(this, arguments) || this
            }
            Ro(Vo, ko = wo), Vo.prototype.v1GamesUniverseIdSocialLinksListGet = function(e, t) {
                return Wo(this.configuration).v1GamesUniverseIdSocialLinksListGet(e, t)(this.axios, this.basePath)
            }, Ro(Ko, Mo = wo), Ko.prototype.v1GamesVipServersUniverseIdPost = function(e, t, n) {
                return Qo(this.configuration).v1GamesVipServersUniverseIdPost(e, t, n)(this.axios, this.basePath)
            }, Ko.prototype.v1VipServersIdGet = function(e, t) {
                return Qo(this.configuration).v1VipServersIdGet(e, t)(this.axios, this.basePath)
            }, Ko.prototype.v1VipServersIdPatch = function(e, t, n) {
                return Qo(this.configuration).v1VipServersIdPatch(e, t, n)(this.axios, this.basePath)
            }, Ko.prototype.v1VipServersIdPermissionsPatch = function(e, t, n) {
                return Qo(this.configuration).v1VipServersIdPermissionsPatch(e, t, n)(this.axios, this.basePath)
            }, Ko.prototype.v1VipServersIdSubscriptionPatch = function(e, t, n) {
                return Qo(this.configuration).v1VipServersIdSubscriptionPatch(e, t, n)(this.axios, this.basePath)
            }, Ro(Yo, jo = wo), Yo.prototype.v1GamesUniverseIdUserVotesPatch = function(e, t, n) {
                return Jo(this.configuration).v1GamesUniverseIdUserVotesPatch(e, t, n)(this.axios, this.basePath)
            }, Yo.prototype.v1GamesUniverseIdVotesGet = function(e, t) {
                return Jo(this.configuration).v1GamesUniverseIdVotesGet(e, t)(this.axios, this.basePath)
            }, Yo.prototype.v1GamesUniverseIdVotesUserGet = function(e, t) {
                return Jo(this.configuration).v1GamesUniverseIdVotesUserGet(e, t)(this.axios, this.basePath)
            }, Yo.prototype.v1GamesVotesGet = function(e, t) {
                return Jo(this.configuration).v1GamesVotesGet(e, t)(this.axios, this.basePath)
            };
            var $o, Zo, bo = ($o = function(e, t) {
                    return ($o = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function(e, t) {
                            e.__proto__ = t
                        } || function(e, t) {
                            for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
                        })(e, t)
                }, function(e, t) {
                    if ("function" != typeof t && null !== t) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");

                    function n() {
                        this.constructor = e
                    }
                    $o(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                }),
                ei = m.EnvironmentUrls.gamesApi.replace(/\/+$/, ""),
                Ro = function(e, t, n) {
                    void 0 === t && (t = ei), void 0 === n && (n = F), this.basePath = t, this.axios = n, e && (this.configuration = e, this.basePath = e.basePath || this.basePath)
                },
                ti = (Zo = Error, bo(ni, Zo), ni);

            function ni(e, t) {
                t = Zo.call(this, t) || this;
                return t.field = e, t.name = "RequiredError", t
            }

            function ri(e, t, n) {
                if (null == n) throw new ti(t, "Required parameter " + t + " was null or undefined when calling " + e + ".")
            }

            function ai(e) {
                for (var t = [], n = 1; n < arguments.length; n++) t[n - 1] = arguments[n];
                for (var r = new URLSearchParams(e.search), a = 0, o = t; a < o.length; a++) {
                    var i, s = o[a];
                    for (i in s) r.set(i, s[i])
                }
                e.search = r.toString()
            }

            function oi(e) {
                return e.pathname + e.search + e.hash
            }

            function ii(n, r, a, o) {
                return function(e, t) {
                    void 0 === e && (e = r), void 0 === t && (t = a);
                    t = ui(ui({}, n.options), {
                        url: ((null == o ? void 0 : o.basePath) || t) + n.url
                    });
                    return e.request(t)
                }
            }
            var si, ui = function() {
                    return (ui = Object.assign || function(e) {
                        for (var t, n = 1, r = arguments.length; n < r; n++)
                            for (var a in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
                        return e
                    }).apply(this, arguments)
                },
                ci = "https://example.com",
                wo = (si = function(e, t) {
                    return (si = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function(e, t) {
                            e.__proto__ = t
                        } || function(e, t) {
                            for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
                        })(e, t)
                }, function(e, t) {
                    if ("function" != typeof t && null !== t) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");

                    function n() {
                        this.constructor = e
                    }
                    si(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                }),
                li = function() {
                    return (li = Object.assign || function(e) {
                        for (var t, n = 1, r = arguments.length; n < r; n++)
                            for (var a in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
                        return e
                    }).apply(this, arguments)
                },
                di = function(e, i, s, u) {
                    return new(s = s || Promise)(function(n, t) {
                        function r(e) {
                            try {
                                o(u.next(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function a(e) {
                            try {
                                o(u.throw(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function o(e) {
                            var t;
                            e.done ? n(e.value) : ((t = e.value) instanceof s ? t : new s(function(e) {
                                e(t)
                            })).then(r, a)
                        }
                        o((u = u.apply(e, i || [])).next())
                    })
                },
                hi = function(n, r) {
                    var a, o, i, s = {
                            label: 0,
                            sent: function() {
                                if (1 & i[0]) throw i[1];
                                return i[1]
                            },
                            trys: [],
                            ops: []
                        },
                        e = {
                            next: t(0),
                            throw: t(1),
                            return: t(2)
                        };
                    return "function" == typeof Symbol && (e[Symbol.iterator] = function() {
                        return this
                    }), e;

                    function t(t) {
                        return function(e) {
                            return function(t) {
                                if (a) throw new TypeError("Generator is already executing.");
                                for (; s;) try {
                                    if (a = 1, o && (i = 2 & t[0] ? o.return : t[0] ? o.throw || ((i = o.return) && i.call(o), 0) : o.next) && !(i = i.call(o, t[1])).done) return i;
                                    switch (o = 0, i && (t = [2 & t[0], i.value]), t[0]) {
                                        case 0:
                                        case 1:
                                            i = t;
                                            break;
                                        case 4:
                                            return s.label++, {
                                                value: t[1],
                                                done: !1
                                            };
                                        case 5:
                                            s.label++, o = t[1], t = [0];
                                            continue;
                                        case 7:
                                            t = s.ops.pop(), s.trys.pop();
                                            continue;
                                        default:
                                            if (!(i = 0 < (i = s.trys).length && i[i.length - 1]) && (6 === t[0] || 2 === t[0])) {
                                                s = 0;
                                                continue
                                            }
                                            if (3 === t[0] && (!i || t[1] > i[0] && t[1] < i[3])) {
                                                s.label = t[1];
                                                break
                                            }
                                            if (6 === t[0] && s.label < i[1]) {
                                                s.label = i[1], i = t;
                                                break
                                            }
                                            if (i && s.label < i[2]) {
                                                s.label = i[2], s.ops.push(t);
                                                break
                                            }
                                            i[2] && s.ops.pop(), s.trys.pop();
                                            continue
                                    }
                                    t = r.call(n, s)
                                } catch (e) {
                                    t = [6, e], o = 0
                                } finally {
                                    a = i = 0
                                }
                                if (5 & t[0]) throw t[1];
                                return {
                                    value: t[0] ? t[1] : void 0,
                                    done: !0
                                }
                            }([t, e])
                        }
                    }
                };

            function vi(u) {
                var c = function(h) {
                    var e = this;
                    return {
                        v2GamesUniverseIdMediaGet: function(o, i) {
                            return void 0 === i && (i = {}), di(e, void 0, Promise, function() {
                                var t, n, r, a;
                                return hi(this, function(e) {
                                    return ri("v2GamesUniverseIdMediaGet", "universeId", o), r = "/v2/games/{universeId}/media".replace("{universeId}", encodeURIComponent(String(o))), t = new URL(r, ci), h && (a = h.baseOptions), n = li(li({
                                        method: "GET"
                                    }, a), i), r = {}, ai(t, {}, i.query), a = a && a.headers ? a.headers : {}, n.headers = li(li(li({}, r), a), i.headers), [2, {
                                        url: oi(t),
                                        options: n
                                    }]
                                })
                            })
                        },
                        v2GroupsGroupIdGamesGet: function(i, s, u, c, l, d) {
                            return void 0 === d && (d = {}), di(e, void 0, Promise, function() {
                                var t, n, r, a, o;
                                return hi(this, function(e) {
                                    return ri("v2GroupsGroupIdGamesGet", "groupId", i), a = "/v2/groups/{groupId}/games".replace("{groupId}", encodeURIComponent(String(i))), t = new URL(a, ci), h && (o = h.baseOptions), n = li(li({
                                        method: "GET"
                                    }, o), d), r = {}, a = {}, void 0 !== s && (a.accessFilter = s), void 0 !== u && (a.sortOrder = u), void 0 !== c && (a.limit = c), void 0 !== l && (a.cursor = l), ai(t, a, d.query), o = o && o.headers ? o.headers : {}, n.headers = li(li(li({}, r), o), d.headers), [2, {
                                        url: oi(t),
                                        options: n
                                    }]
                                })
                            })
                        },
                        v2GroupsGroupIdGamesV2Get: function(i, s, u, c, l, d) {
                            return void 0 === d && (d = {}), di(e, void 0, Promise, function() {
                                var t, n, r, a, o;
                                return hi(this, function(e) {
                                    return ri("v2GroupsGroupIdGamesV2Get", "groupId", i), a = "/v2/groups/{groupId}/gamesV2".replace("{groupId}", encodeURIComponent(String(i))), t = new URL(a, ci), h && (o = h.baseOptions), n = li(li({
                                        method: "GET"
                                    }, o), d), r = {}, a = {}, void 0 !== s && (a.accessFilter = s), void 0 !== u && (a.sortOrder = u), void 0 !== c && (a.limit = c), void 0 !== l && (a.cursor = l), ai(t, a, d.query), o = o && o.headers ? o.headers : {}, n.headers = li(li(li({}, r), o), d.headers), [2, {
                                        url: oi(t),
                                        options: n
                                    }]
                                })
                            })
                        },
                        v2UsersUserIdFavoriteGamesGet: function(i, s, u, c, l, d) {
                            return void 0 === d && (d = {}), di(e, void 0, Promise, function() {
                                var t, n, r, a, o;
                                return hi(this, function(e) {
                                    return ri("v2UsersUserIdFavoriteGamesGet", "userId", i), a = "/v2/users/{userId}/favorite/games".replace("{userId}", encodeURIComponent(String(i))), t = new URL(a, ci), h && (o = h.baseOptions), n = li(li({
                                        method: "GET"
                                    }, o), d), r = {}, a = {}, void 0 !== s && (a.accessFilter = s), void 0 !== u && (a.sortOrder = u), void 0 !== c && (a.limit = c), void 0 !== l && (a.cursor = l), ai(t, a, d.query), o = o && o.headers ? o.headers : {}, n.headers = li(li(li({}, r), o), d.headers), [2, {
                                        url: oi(t),
                                        options: n
                                    }]
                                })
                            })
                        },
                        v2UsersUserIdGamesGet: function(i, s, u, c, l, d) {
                            return void 0 === d && (d = {}), di(e, void 0, Promise, function() {
                                var t, n, r, a, o;
                                return hi(this, function(e) {
                                    return ri("v2UsersUserIdGamesGet", "userId", i), a = "/v2/users/{userId}/games".replace("{userId}", encodeURIComponent(String(i))), t = new URL(a, ci), h && (o = h.baseOptions), n = li(li({
                                        method: "GET"
                                    }, o), d), r = {}, a = {}, void 0 !== s && (a.accessFilter = s), void 0 !== u && (a.sortOrder = u), void 0 !== c && (a.limit = c), void 0 !== l && (a.cursor = l), ai(t, a, d.query), o = o && o.headers ? o.headers : {}, n.headers = li(li(li({}, r), o), d.headers), [2, {
                                        url: oi(t),
                                        options: n
                                    }]
                                })
                            })
                        }
                    }
                }(u);
                return {
                    v2GamesUniverseIdMediaGet: function(n, r) {
                        return di(this, void 0, Promise, function() {
                            var t;
                            return hi(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, c.v2GamesUniverseIdMediaGet(n, r)];
                                    case 1:
                                        return t = e.sent(), [2, ii(t, y(), ei, u)]
                                }
                            })
                        })
                    },
                    v2GroupsGroupIdGamesGet: function(n, r, a, o, i, s) {
                        return di(this, void 0, Promise, function() {
                            var t;
                            return hi(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, c.v2GroupsGroupIdGamesGet(n, r, a, o, i, s)];
                                    case 1:
                                        return t = e.sent(), [2, ii(t, y(), ei, u)]
                                }
                            })
                        })
                    },
                    v2GroupsGroupIdGamesV2Get: function(n, r, a, o, i, s) {
                        return di(this, void 0, Promise, function() {
                            var t;
                            return hi(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, c.v2GroupsGroupIdGamesV2Get(n, r, a, o, i, s)];
                                    case 1:
                                        return t = e.sent(), [2, ii(t, y(), ei, u)]
                                }
                            })
                        })
                    },
                    v2UsersUserIdFavoriteGamesGet: function(n, r, a, o, i, s) {
                        return di(this, void 0, Promise, function() {
                            var t;
                            return hi(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, c.v2UsersUserIdFavoriteGamesGet(n, r, a, o, i, s)];
                                    case 1:
                                        return t = e.sent(), [2, ii(t, y(), ei, u)]
                                }
                            })
                        })
                    },
                    v2UsersUserIdGamesGet: function(n, r, a, o, i, s) {
                        return di(this, void 0, Promise, function() {
                            var t;
                            return hi(this, function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, c.v2UsersUserIdGamesGet(n, r, a, o, i, s)];
                                    case 1:
                                        return t = e.sent(), [2, ii(t, y(), ei, u)]
                                }
                            })
                        })
                    }
                }
            }(bo = {}).Asc = "Asc", bo.Desc = "Desc", (bo = {}).Forward = "Forward", bo.Backward = "Backward", (bo = {}).Asc = "Asc", bo.Desc = "Desc", (bo = {}).Forward = "Forward", bo.Backward = "Backward", (bo = {}).Image = "Image", bo.TShirt = "TShirt", bo.Audio = "Audio", bo.Mesh = "Mesh", bo.Lua = "Lua", bo.Html = "HTML", bo.Text = "Text", bo.Hat = "Hat", bo.Place = "Place", bo.Model = "Model", bo.Shirt = "Shirt", bo.Pants = "Pants", bo.Decal = "Decal", bo.Avatar = "Avatar", bo.Head = "Head", bo.Face = "Face", bo.Gear = "Gear", bo.Badge = "Badge", bo.GroupEmblem = "GroupEmblem", bo.Animation = "Animation", bo.Arms = "Arms", bo.Legs = "Legs", bo.Torso = "Torso", bo.RightArm = "RightArm", bo.LeftArm = "LeftArm", bo.LeftLeg = "LeftLeg", bo.RightLeg = "RightLeg", bo.Package = "Package", bo.YouTubeVideo = "YouTubeVideo", bo.GamePass = "GamePass", bo.App = "App", bo.Code = "Code", bo.Plugin = "Plugin", bo.SolidModel = "SolidModel", bo.MeshPart = "MeshPart", bo.HairAccessory = "HairAccessory", bo.FaceAccessory = "FaceAccessory", bo.NeckAccessory = "NeckAccessory", bo.ShoulderAccessory = "ShoulderAccessory", bo.FrontAccessory = "FrontAccessory", bo.BackAccessory = "BackAccessory", bo.WaistAccessory = "WaistAccessory", bo.ClimbAnimation = "ClimbAnimation", bo.DeathAnimation = "DeathAnimation", bo.FallAnimation = "FallAnimation", bo.IdleAnimation = "IdleAnimation", bo.JumpAnimation = "JumpAnimation", bo.RunAnimation = "RunAnimation", bo.SwimAnimation = "SwimAnimation", bo.WalkAnimation = "WalkAnimation", bo.PoseAnimation = "PoseAnimation", bo.LocalizationTableManifest = "LocalizationTableManifest", bo.LocalizationTableTranslation = "LocalizationTableTranslation", bo.EmoteAnimation = "EmoteAnimation", bo.Video = "Video", bo.TexturePack = "TexturePack", (bo = {}).User = "User", bo.Group = "Group";
            var pi, wo = (wo(fi, pi = Ro), fi.prototype.v2GamesUniverseIdMediaGet = function(e, t) {
                var n = this;
                return vi(this.configuration).v2GamesUniverseIdMediaGet(e, t).then(function(e) {
                    return e(n.axios, n.basePath)
                })
            }, fi.prototype.v2GroupsGroupIdGamesGet = function(e, t, n, r, a, o) {
                var i = this;
                return vi(this.configuration).v2GroupsGroupIdGamesGet(e, t, n, r, a, o).then(function(e) {
                    return e(i.axios, i.basePath)
                })
            }, fi.prototype.v2GroupsGroupIdGamesV2Get = function(e, t, n, r, a, o) {
                var i = this;
                return vi(this.configuration).v2GroupsGroupIdGamesV2Get(e, t, n, r, a, o).then(function(e) {
                    return e(i.axios, i.basePath)
                })
            }, fi.prototype.v2UsersUserIdFavoriteGamesGet = function(e, t, n, r, a, o) {
                var i = this;
                return vi(this.configuration).v2UsersUserIdFavoriteGamesGet(e, t, n, r, a, o).then(function(e) {
                    return e(i.axios, i.basePath)
                })
            }, fi.prototype.v2UsersUserIdGamesGet = function(e, t, n, r, a, o) {
                var i = this;
                return vi(this.configuration).v2UsersUserIdGamesGet(e, t, n, r, a, o).then(function(e) {
                    return e(i.axios, i.basePath)
                })
            }, fi);

            function fi() {
                return null !== pi && pi.apply(this, arguments) || this
            }
            var mi, gi, Ii = new Z,
                yi = new wo,
                bi = new xo,
                Ro = {
                    getUniverseMedia: function(e) {
                        return yi.v2GamesUniverseIdMediaGet(e, {
                            withCredentials: !0
                        })
                    },
                    getPlayabilityStatus: function(e) {
                        return Ii.v1GamesMultigetPlayabilityStatusGet(e, {
                            withCredentials: !0
                        })
                    },
                    getPlaceDetails: function(e) {
                        return Ii.v1GamesMultigetPlaceDetailsGet(e, {
                            withCredentials: !0
                        })
                    },
                    getProductInfo: function(e) {
                        return Ii.v1GamesGamesProductInfoGet(e, {
                            withCredentials: !0
                        })
                    },
                    getGameDetails: function(e) {
                        return Ii.v1GamesGet(e, {
                            withCredentials: !0
                        })
                    },
                    getGamePasses: function(e, t, n, r) {
                        return bi.v1GamesUniverseIdGamePassesGet(e, t, n, r)
                    },
                    getGamesSorts: function(e) {
                        return Ii.v1GamesSortsGet(e)
                    },
                    getGamesList: function(e, t, n, r, a, o, i, s, u, c, l, d, h, v, p, f) {
                        return Ii.v1GamesListGet(e, t, n, r, a, o, i, s, u, c, l, d, h, v, p, f)
                    }
                },
                Z = (mi = function(e, t) {
                    return (mi = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function(e, t) {
                            e.__proto__ = t
                        } || function(e, t) {
                            for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
                        })(e, t)
                }, function(e, t) {
                    if ("function" != typeof t && null !== t) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");

                    function n() {
                        this.constructor = e
                    }
                    mi(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                }),
                Pi = m.EnvironmentUrls.inventoryApi.replace(/\/+$/, ""),
                wo = function(e, t, n) {
                    void 0 === t && (t = Pi), void 0 === n && (n = F), this.basePath = t, this.axios = n, e && (this.configuration = e, this.basePath = e.basePath || this.basePath)
                },
                Gi = (gi = Error, Z(wi, gi), wi);

            function wi(e, t) {
                t = gi.call(this, t) || this;
                return t.field = e, t.name = "RequiredError", t
            }
            var Ci, xo = (Ci = function(e, t) {
                    return (Ci = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function(e, t) {
                            e.__proto__ = t
                        } || function(e, t) {
                            for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
                        })(e, t)
                }, function(e, t) {
                    if ("function" != typeof t && null !== t) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");

                    function n() {
                        this.constructor = e
                    }
                    Ci(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                }),
                Ti = function() {
                    return (Ti = Object.assign || function(e) {
                        for (var t, n = 1, r = arguments.length; n < r; n++)
                            for (var a in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
                        return e
                    }).apply(this, arguments)
                };

            function Ai(u) {
                return {
                    v2AssetsAssetIdOwnersGet: function(e, t, n, r, a) {
                        if (void 0 === a && (a = {}), null == e) throw new Gi("assetId", "Required parameter assetId was null or undefined when calling v2AssetsAssetIdOwnersGet.");
                        var o = "/v2/assets/{assetId}/owners".replace("{assetId}", encodeURIComponent(String(e))),
                            e = Gt.Qc(o, !0);
                        u && (i = u.baseOptions);
                        var o = Ti(Ti({
                                method: "GET"
                            }, i), a),
                            i = {};
                        return void 0 !== t && (i.sortOrder = t), void 0 !== n && (i.limit = n), void 0 !== r && (i.cursor = r), e.query = Ti(Ti(Ti({}, e.query), i), a.query), delete e.search, o.headers = Ti(Ti({}, {}), a.headers), {
                            url: Gt.WU(e),
                            options: o
                        }
                    },
                    v2RecommendationsAssetTypeIdGet: function(e, t, n, r, a, o) {
                        if (void 0 === o && (o = {}), null == e) throw new Gi("assetTypeId", "Required parameter assetTypeId was null or undefined when calling v2RecommendationsAssetTypeIdGet.");
                        var i = "/v2/recommendations/{assetTypeId}".replace("{assetTypeId}", encodeURIComponent(String(e))),
                            e = Gt.Qc(i, !0);
                        u && (s = u.baseOptions);
                        var i = Ti(Ti({
                                method: "GET"
                            }, s), o),
                            s = {};
                        return void 0 !== t && (s.numItems = t), void 0 !== n && (s.contextAssetId = n), void 0 !== r && (s.thumbWidth = r), void 0 !== a && (s.thumbHeight = a), e.query = Ti(Ti(Ti({}, e.query), s), o.query), delete e.search, i.headers = Ti(Ti({}, {}), o.headers), {
                            url: Gt.WU(e),
                            options: i
                        }
                    }
                }
            }

            function Si(s) {
                return {
                    v2AssetsAssetIdOwnersGet: function(e, t, n, r, a) {
                        var o = Ai(s).v2AssetsAssetIdOwnersGet(e, t, n, r, a);
                        return function(e, t) {
                            void 0 === e && (e = F), void 0 === t && (t = Pi);
                            t = Ti(Ti({}, o.options), {
                                url: t + o.url
                            });
                            return e.request(t)
                        }
                    },
                    v2RecommendationsAssetTypeIdGet: function(e, t, n, r, a, o) {
                        var i = Ai(s).v2RecommendationsAssetTypeIdGet(e, t, n, r, a, o);
                        return function(e, t) {
                            void 0 === e && (e = F), void 0 === t && (t = Pi);
                            t = Ti(Ti({}, i.options), {
                                url: t + i.url
                            });
                            return e.request(t)
                        }
                    }
                }
            }(Z = {}).Asc = "Asc", Z.Desc = "Desc", (Z = {}).Forward = "Forward", Z.Backward = "Backward", (Z = {}).User = "User", Z.Group = "Group", (Z = {}).None = "None", Z.BC = "BC", Z.TBC = "TBC", Z.OBC = "OBC", Z.RobloxPremium = "RobloxPremium";
            var Ri, Ei, Z = (xo(Li, Ri = wo), Li.prototype.v2AssetsAssetIdOwnersGet = function(e, t, n, r, a) {
                return Si(this.configuration).v2AssetsAssetIdOwnersGet(e, t, n, r, a)(this.axios, this.basePath)
            }, Li.prototype.v2RecommendationsAssetTypeIdGet = function(e, t, n, r, a, o) {
                return Si(this.configuration).v2RecommendationsAssetTypeIdGet(e, t, n, r, a, o)(this.axios, this.basePath)
            }, Li);

            function Li() {
                return null !== Ri && Ri.apply(this, arguments) || this
            }

            function Ui(u) {
                return {
                    v2UsersUserIdInventoryAssetTypeIdGet: function(e, t, n, r, a, o) {
                        var s, i = (s = u, function(e, t, n, r, a, o) {
                            if (void 0 === o && (o = {}), null == e) throw new Gi("userId", "Required parameter userId was null or undefined when calling v2UsersUserIdInventoryAssetTypeIdGet.");
                            if (null == t) throw new Gi("assetTypeId", "Required parameter assetTypeId was null or undefined when calling v2UsersUserIdInventoryAssetTypeIdGet.");
                            e = "/v2/users/{userId}/inventory/{assetTypeId}".replace("{userId}", encodeURIComponent(String(e))).replace("{assetTypeId}", encodeURIComponent(String(t))), t = Gt.Qc(e, !0);
                            s && (i = s.baseOptions);
                            var e = Ti(Ti({
                                    method: "GET"
                                }, i), o),
                                i = {};
                            return void 0 !== n && (i.sortOrder = n), void 0 !== r && (i.limit = r), void 0 !== a && (i.cursor = a), t.query = Ti(Ti(Ti({}, t.query), i), o.query), delete t.search, e.headers = Ti(Ti({}, {}), o.headers), {
                                url: Gt.WU(t),
                                options: e
                            }
                        }(e, t, n, r, a, o));
                        return function(e, t) {
                            void 0 === e && (e = F), void 0 === t && (t = Pi);
                            t = Ti(Ti({}, i.options), {
                                url: t + i.url
                            });
                            return e.request(t)
                        }
                    }
                }
            }

            function qi() {
                return null !== Ei && Ei.apply(this, arguments) || this
            }
            xo(qi, Ei = wo), qi.prototype.v2UsersUserIdInventoryAssetTypeIdGet = function(e, t, n, r, a, o) {
                return Ui(this.configuration).v2UsersUserIdInventoryAssetTypeIdGet(e, t, n, r, a, o)(this.axios, this.basePath)
            };
            var Oi, Di, xi = new Z,
                xo = {
                    getRecommendations: function(e, t, n) {
                        return xi.v2RecommendationsAssetTypeIdGet(e, t, n)
                    }
                },
                _i = {
                    getUserKey: function(e) {
                        return "user_" + e
                    },
                    storage: function() {
                        return m.LocalStorage ? m.LocalStorage.isAvailable() : localStorage
                    },
                    getLength: function() {
                        return this.storage() ? localStorage.length : 0
                    },
                    getKey: function(e) {
                        return this.storage() ? localStorage.key(e) : ""
                    },
                    setLocalStorage: function(e, t) {
                        this.storage() && localStorage.setItem(e, JSON.stringify(t))
                    },
                    getLocalStorage: function(e) {
                        if (this.storage()) return JSON.parse(localStorage.getItem(e))
                    },
                    listenLocalStorage: function(e) {
                        this.storage() && void 0 !== e && (window.addEventListener ? window.addEventListener("storage", e, !1) : window.attachEvent("onstorage", e))
                    },
                    removeLocalStorage: function(e) {
                        this.storage() && localStorage.removeItem(e)
                    },
                    saveDataByTimeStamp: function(e, t) {
                        var n = (new Date).getTime(),
                            r = this.getLocalStorage(e);
                        (r = r || {}).data = t, r.timeStamp = n, this.setLocalStorage(e, r)
                    },
                    fetchNonExpiredCachedData: function(e, t) {
                        var n = (new Date).getTime(),
                            r = this.getLocalStorage(e);
                        if (r && r.timeStamp) {
                            if (n - r.timeStamp < (t = t || 3e4)) return r;
                            this.removeLocalStorage(e)
                        }
                        return null
                    }
                },
                wo = (Oi = function(e, t) {
                    return (Oi = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function(e, t) {
                            e.__proto__ = t
                        } || function(e, t) {
                            for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
                        })(e, t)
                }, function(e, t) {
                    if ("function" != typeof t && null !== t) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");

                    function n() {
                        this.constructor = e
                    }
                    Oi(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                }),
                Bi = m.EnvironmentUrls.localeApi.replace(/\/+$/, ""),
                Z = function(e, t, n) {
                    void 0 === t && (t = Bi), void 0 === n && (n = F), this.basePath = t, this.axios = n, e && (this.configuration = e, this.basePath = e.basePath || this.basePath)
                },
                Fi = (Di = Error, wo(Ni, Di), Ni);

            function Ni(e, t) {
                t = Di.call(this, t) || this;
                return t.field = e, t.name = "RequiredError", t
            }

            function ki(o) {
                return {
                    v1CountryRegionsGet: function(e) {
                        void 0 === e && (e = {});
                        var t = Gt.Qc("/v1/country-regions", !0);
                        o && (n = o.baseOptions);
                        var n = Hi(Hi({
                            method: "GET"
                        }, n), e);
                        return t.query = Hi(Hi(Hi({}, t.query), {}), e.query), delete t.search, n.headers = Hi(Hi({}, {}), e.headers), {
                            url: Gt.WU(t),
                            options: n
                        }
                    },
                    v1CountryRegionsUserCountryRegionGet: function(e) {
                        void 0 === e && (e = {});
                        var t = Gt.Qc("/v1/country-regions/user-country-region", !0);
                        o && (n = o.baseOptions);
                        var n = Hi(Hi({
                            method: "GET"
                        }, n), e);
                        return t.query = Hi(Hi(Hi({}, t.query), {}), e.query), delete t.search, n.headers = Hi(Hi({}, {}), e.headers), {
                            url: Gt.WU(t),
                            options: n
                        }
                    },
                    v1CountryRegionsUserCountryRegionPatch: function(e, t) {
                        if (void 0 === t && (t = {}), null == e) throw new Fi("userRequest", "Required parameter userRequest was null or undefined when calling v1CountryRegionsUserCountryRegionPatch.");
                        var n = Gt.Qc("/v1/country-regions/user-country-region", !0);
                        o && (a = o.baseOptions);
                        var r = Hi(Hi({
                                method: "PATCH"
                            }, a), t),
                            a = {};
                        a["Content-Type"] = "application/json", n.query = Hi(Hi(Hi({}, n.query), {}), t.query), delete n.search, r.headers = Hi(Hi({}, a), t.headers);
                        return r.data = JSON.stringify(void 0 !== e ? e : {}), {
                            url: Gt.WU(n),
                            options: r
                        }
                    }
                }
            }

            function Mi(r) {
                return {
                    v1CountryRegionsGet: function(e) {
                        var n = ki(r).v1CountryRegionsGet(e);
                        return function(e, t) {
                            void 0 === e && (e = F), void 0 === t && (t = Bi);
                            t = Hi(Hi({}, n.options), {
                                url: t + n.url
                            });
                            return e.request(t)
                        }
                    },
                    v1CountryRegionsUserCountryRegionGet: function(e) {
                        var n = ki(r).v1CountryRegionsUserCountryRegionGet(e);
                        return function(e, t) {
                            void 0 === e && (e = F), void 0 === t && (t = Bi);
                            t = Hi(Hi({}, n.options), {
                                url: t + n.url
                            });
                            return e.request(t)
                        }
                    },
                    v1CountryRegionsUserCountryRegionPatch: function(e, t) {
                        var n = ki(r).v1CountryRegionsUserCountryRegionPatch(e, t);
                        return function(e, t) {
                            void 0 === e && (e = F), void 0 === t && (t = Bi);
                            t = Hi(Hi({}, n.options), {
                                url: t + n.url
                            });
                            return e.request(t)
                        }
                    }
                }
            }
            var ji, zi, Wi, Vi, wo = (ji = function(e, t) {
                    return (ji = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function(e, t) {
                            e.__proto__ = t
                        } || function(e, t) {
                            for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
                        })(e, t)
                }, function(e, t) {
                    if ("function" != typeof t && null !== t) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");

                    function n() {
                        this.constructor = e
                    }
                    ji(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                }),
                Hi = function() {
                    return (Hi = Object.assign || function(e) {
                        for (var t, n = 1, r = arguments.length; n < r; n++)
                            for (var a in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
                        return e
                    }).apply(this, arguments)
                };

            function Qi() {
                return null !== zi && zi.apply(this, arguments) || this
            }

            function Ki(r) {
                return {
                    v1LanguagesGet: function(e) {
                        void 0 === e && (e = {});
                        var t = Gt.Qc("/v1/languages", !0);
                        r && (n = r.baseOptions);
                        var n = Hi(Hi({
                            method: "GET"
                        }, n), e);
                        return t.query = Hi(Hi(Hi({}, t.query), {}), e.query), delete t.search, n.headers = Hi(Hi({}, {}), e.headers), {
                            url: Gt.WU(t),
                            options: n
                        }
                    },
                    v1LanguagesUserGeneratedContentGet: function(e) {
                        void 0 === e && (e = {});
                        var t = Gt.Qc("/v1/languages/user-generated-content", !0);
                        r && (n = r.baseOptions);
                        var n = Hi(Hi({
                            method: "GET"
                        }, n), e);
                        return t.query = Hi(Hi(Hi({}, t.query), {}), e.query), delete t.search, n.headers = Hi(Hi({}, {}), e.headers), {
                            url: Gt.WU(t),
                            options: n
                        }
                    }
                }
            }

            function Xi(t) {
                return {
                    v1LanguagesGet: function(e) {
                        var n = Ki(t).v1LanguagesGet(e);
                        return function(e, t) {
                            void 0 === e && (e = F), void 0 === t && (t = Bi);
                            t = Hi(Hi({}, n.options), {
                                url: t + n.url
                            });
                            return e.request(t)
                        }
                    },
                    v1LanguagesUserGeneratedContentGet: function(e) {
                        var n = Ki(t).v1LanguagesUserGeneratedContentGet(e);
                        return function(e, t) {
                            void 0 === e && (e = F), void 0 === t && (t = Bi);
                            t = Hi(Hi({}, n.options), {
                                url: t + n.url
                            });
                            return e.request(t)
                        }
                    }
                }
            }

            function Ji() {
                return null !== Wi && Wi.apply(this, arguments) || this
            }

            function Yi(o) {
                return {
                    v1LocalesGet: function(e) {
                        void 0 === e && (e = {});
                        var t = Gt.Qc("/v1/locales", !0);
                        o && (n = o.baseOptions);
                        var n = Hi(Hi({
                            method: "GET"
                        }, n), e);
                        return t.query = Hi(Hi(Hi({}, t.query), {}), e.query), delete t.search, n.headers = Hi(Hi({}, {}), e.headers), {
                            url: Gt.WU(t),
                            options: n
                        }
                    },
                    v1LocalesSetUserSupportedLocalePost: function(e, t) {
                        if (void 0 === t && (t = {}), null == e) throw new Fi("userRequest", "Required parameter userRequest was null or undefined when calling v1LocalesSetUserSupportedLocalePost.");
                        var n = Gt.Qc("/v1/locales/set-user-supported-locale", !0);
                        o && (a = o.baseOptions);
                        var r = Hi(Hi({
                                method: "POST"
                            }, a), t),
                            a = {};
                        a["Content-Type"] = "application/json", n.query = Hi(Hi(Hi({}, n.query), {}), t.query), delete n.search, r.headers = Hi(Hi({}, a), t.headers);
                        return r.data = JSON.stringify(void 0 !== e ? e : {}), {
                            url: Gt.WU(n),
                            options: r
                        }
                    },
                    v1LocalesSupportedLocalesGet: function(e) {
                        void 0 === e && (e = {});
                        var t = Gt.Qc("/v1/locales/supported-locales", !0);
                        o && (n = o.baseOptions);
                        var n = Hi(Hi({
                            method: "GET"
                        }, n), e);
                        return t.query = Hi(Hi(Hi({}, t.query), {}), e.query), delete t.search, n.headers = Hi(Hi({}, {}), e.headers), {
                            url: Gt.WU(t),
                            options: n
                        }
                    },
                    v1LocalesUserLocaleGet: function(e) {
                        void 0 === e && (e = {});
                        var t = Gt.Qc("/v1/locales/user-locale", !0);
                        o && (n = o.baseOptions);
                        var n = Hi(Hi({
                            method: "GET"
                        }, n), e);
                        return t.query = Hi(Hi(Hi({}, t.query), {}), e.query), delete t.search, n.headers = Hi(Hi({}, {}), e.headers), {
                            url: Gt.WU(t),
                            options: n
                        }
                    },
                    v1LocalesUserLocalizationLocusSupportedLocalesGet: function(e) {
                        void 0 === e && (e = {});
                        var t = Gt.Qc("/v1/locales/user-localization-locus-supported-locales", !0);
                        o && (n = o.baseOptions);
                        var n = Hi(Hi({
                            method: "GET"
                        }, n), e);
                        return t.query = Hi(Hi(Hi({}, t.query), {}), e.query), delete t.search, n.headers = Hi(Hi({}, {}), e.headers), {
                            url: Gt.WU(t),
                            options: n
                        }
                    }
                }
            }

            function $i(r) {
                return {
                    v1LocalesGet: function(e) {
                        var n = Yi(r).v1LocalesGet(e);
                        return function(e, t) {
                            void 0 === e && (e = F), void 0 === t && (t = Bi);
                            t = Hi(Hi({}, n.options), {
                                url: t + n.url
                            });
                            return e.request(t)
                        }
                    },
                    v1LocalesSetUserSupportedLocalePost: function(e, t) {
                        var n = Yi(r).v1LocalesSetUserSupportedLocalePost(e, t);
                        return function(e, t) {
                            void 0 === e && (e = F), void 0 === t && (t = Bi);
                            t = Hi(Hi({}, n.options), {
                                url: t + n.url
                            });
                            return e.request(t)
                        }
                    },
                    v1LocalesSupportedLocalesGet: function(e) {
                        var n = Yi(r).v1LocalesSupportedLocalesGet(e);
                        return function(e, t) {
                            void 0 === e && (e = F), void 0 === t && (t = Bi);
                            t = Hi(Hi({}, n.options), {
                                url: t + n.url
                            });
                            return e.request(t)
                        }
                    },
                    v1LocalesUserLocaleGet: function(e) {
                        var n = Yi(r).v1LocalesUserLocaleGet(e);
                        return function(e, t) {
                            void 0 === e && (e = F), void 0 === t && (t = Bi);
                            t = Hi(Hi({}, n.options), {
                                url: t + n.url
                            });
                            return e.request(t)
                        }
                    },
                    v1LocalesUserLocalizationLocusSupportedLocalesGet: function(e) {
                        var n = Yi(r).v1LocalesUserLocalizationLocusSupportedLocalesGet(e);
                        return function(e, t) {
                            void 0 === e && (e = F), void 0 === t && (t = Bi);
                            t = Hi(Hi({}, n.options), {
                                url: t + n.url
                            });
                            return e.request(t)
                        }
                    }
                }
            }

            function Zi() {
                return null !== Vi && Vi.apply(this, arguments) || this
            }
            wo(Qi, zi = Z), Qi.prototype.v1CountryRegionsGet = function(e) {
                return Mi(this.configuration).v1CountryRegionsGet(e)(this.axios, this.basePath)
            }, Qi.prototype.v1CountryRegionsUserCountryRegionGet = function(e) {
                return Mi(this.configuration).v1CountryRegionsUserCountryRegionGet(e)(this.axios, this.basePath)
            }, Qi.prototype.v1CountryRegionsUserCountryRegionPatch = function(e, t) {
                return Mi(this.configuration).v1CountryRegionsUserCountryRegionPatch(e, t)(this.axios, this.basePath)
            }, wo(Ji, Wi = Z), Ji.prototype.v1LanguagesGet = function(e) {
                return Xi(this.configuration).v1LanguagesGet(e)(this.axios, this.basePath)
            }, Ji.prototype.v1LanguagesUserGeneratedContentGet = function(e) {
                return Xi(this.configuration).v1LanguagesUserGeneratedContentGet(e)(this.axios, this.basePath)
            };
            var es, ts = new(wo(Zi, Vi = Z), Zi.prototype.v1LocalesGet = function(e) {
                return $i(this.configuration).v1LocalesGet(e)(this.axios, this.basePath)
            }, Zi.prototype.v1LocalesSetUserSupportedLocalePost = function(e, t) {
                return $i(this.configuration).v1LocalesSetUserSupportedLocalePost(e, t)(this.axios, this.basePath)
            }, Zi.prototype.v1LocalesSupportedLocalesGet = function(e) {
                return $i(this.configuration).v1LocalesSupportedLocalesGet(e)(this.axios, this.basePath)
            }, Zi.prototype.v1LocalesUserLocaleGet = function(e) {
                return $i(this.configuration).v1LocalesUserLocaleGet(e)(this.axios, this.basePath)
            }, Zi.prototype.v1LocalesUserLocalizationLocusSupportedLocalesGet = function(e) {
                return $i(this.configuration).v1LocalesUserLocalizationLocusSupportedLocalesGet(e)(this.axios, this.basePath)
            }, Zi);

            function ns() {
                return ts.v1LocalesGet({
                    withCredentials: !0
                })
            }(es = es || {}).getLocales = "Roblox.Api.Locales.getLocales";
            var rs, Z = {
                    getLocales: ns,
                    getUserLocale: function() {
                        return ts.v1LocalesUserLocalizationLocusSupportedLocalesGet({
                            withCredentials: !0
                        })
                    },
                    setUserLocale: function(e) {
                        e = {
                            supportedLocaleCode: e
                        };
                        return ts.v1LocalesSetUserSupportedLocalePost(e, {
                            withCredentials: !0
                        })
                    },
                    getLocalesWithCache: function(e) {
                        return r = ns, a = es.getLocales, o = e, new Promise(function(t, n) {
                            var e = _i.fetchNonExpiredCachedData(a, o);
                            e ? t(e.data) : r().then(function(e) {
                                _i.saveDataByTimeStamp(a, e.data), t(e.data)
                            }, function(e) {
                                return n(e)
                            })
                        });
                        var r, a, o
                    }
                },
                as = new re,
                os = new R,
                is = new X,
                ss = new ae,
                us = new fe,
                cs = new z,
                ls = new ie,
                ds = new pe,
                ae = {
                    getAssets: function(e, t, n, r, a) {
                        return as.v1AssetsGet(e, t, n, r, a, {
                            withCredentials: !0
                        })
                    },
                    getAvatars: function(e, t, n, r) {
                        return is.v1UsersAvatarGet(e, t, n, r, {
                            withCredentials: !0
                        })
                    },
                    getAvatarHeadshots: function(e, t, n, r) {
                        return is.v1UsersAvatarHeadshotGet(e, t, n, r, {
                            withCredentials: !0
                        })
                    },
                    getGroupIcons: function(e, t, n, r) {
                        return ss.v1GroupsIconsGet(e, t, n, r, {
                            withCredentials: !0
                        })
                    },
                    getBadgeIcons: function(e, t, n, r) {
                        return us.v1BadgesIconsGet(e, t, n, r, {
                            withCredentials: !0
                        })
                    },
                    getDeveloperProductIcons: function(e, t, n, r) {
                        return cs.v1DeveloperProductsIconsGet(e, t, n, r, {
                            withCredentials: !0
                        })
                    },
                    getBundles: function(e, t, n, r) {
                        return os.v1BundlesThumbnailsGet(e, t, n, r, {
                            withCredentials: !0
                        })
                    },
                    getUserOutfits: function(e, t, n, r) {
                        return ls.v1UsersOutfitsGet(e, t, n, r, {
                            withCredentials: !0
                        })
                    },
                    getBatchThumbnails: function(e) {
                        return ds.v1BatchPost(e, {
                            withCredentials: !0
                        })
                    }
                },
                hs = new f;
            (fe = rs = rs || {}).Language = "Language", fe.Locale = "Locale";
            var vs, ps, z = {
                    getTranslationProgress: function(e, t) {
                        return hs.v1GameLocalizationStatusTranslationCountsForLanguageOrLocaleGet(e, t, rs.Language, {
                            withCredentials: !0
                        })
                    }
                },
                ie = (vs = function(e, t) {
                    return (vs = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function(e, t) {
                            e.__proto__ = t
                        } || function(e, t) {
                            for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
                        })(e, t)
                }, function(e, t) {
                    if ("function" != typeof t && null !== t) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");

                    function n() {
                        this.constructor = e
                    }
                    vs(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                }),
                fs = m.EnvironmentUrls.translationRolesApi.replace(/\/+$/, ""),
                pe = function(e, t, n) {
                    void 0 === t && (t = fs), void 0 === n && (n = F), this.basePath = t, this.axios = n, e && (this.configuration = e, this.basePath = e.basePath || this.basePath)
                },
                ms = (ps = Error, ie(gs, ps), gs);

            function gs(e, t) {
                t = ps.call(this, t) || this;
                return t.field = e, t.name = "RequiredError", t
            }
            var Is, ys, f = (Is = function(e, t) {
                    return (Is = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function(e, t) {
                            e.__proto__ = t
                        } || function(e, t) {
                            for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
                        })(e, t)
                }, function(e, t) {
                    if ("function" != typeof t && null !== t) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");

                    function n() {
                        this.constructor = e
                    }
                    Is(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                }),
                bs = function() {
                    return (bs = Object.assign || function(e) {
                        for (var t, n = 1, r = arguments.length; n < r; n++)
                            for (var a in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
                        return e
                    }).apply(this, arguments)
                };

            function Ps(s) {
                return {
                    v1GameLocalizationRolesGamesGameIdCurrentUserRolesGet: function(e, t) {
                        if (void 0 === t && (t = {}), null == e) throw new ms("gameId", "Required parameter gameId was null or undefined when calling v1GameLocalizationRolesGamesGameIdCurrentUserRolesGet.");
                        e = "/v1/game-localization-roles/games/{gameId}/current-user/roles".replace("{gameId}", encodeURIComponent(String(e))), e = Gt.Qc(e, !0);
                        s && (n = s.baseOptions);
                        var n = bs(bs({
                            method: "GET"
                        }, n), t);
                        return e.query = bs(bs(bs({}, e.query), {}), t.query), delete e.search, n.headers = bs(bs({}, {}), t.headers), {
                            url: Gt.WU(e),
                            options: n
                        }
                    },
                    v1GameLocalizationRolesGamesGameIdPatch: function(e, t, n) {
                        if (void 0 === n && (n = {}), null == e) throw new ms("gameId", "Required parameter gameId was null or undefined when calling v1GameLocalizationRolesGamesGameIdPatch.");
                        if (null == t) throw new ms("request", "Required parameter request was null or undefined when calling v1GameLocalizationRolesGamesGameIdPatch.");
                        var r = "/v1/game-localization-roles/games/{gameId}".replace("{gameId}", encodeURIComponent(String(e))),
                            e = Gt.Qc(r, !0);
                        s && (a = s.baseOptions);
                        var r = bs(bs({
                                method: "PATCH"
                            }, a), n),
                            a = {};
                        a["Content-Type"] = "application/json", e.query = bs(bs(bs({}, e.query), {}), n.query), delete e.search, r.headers = bs(bs({}, a), n.headers);
                        return r.data = JSON.stringify(void 0 !== t ? t : {}), {
                            url: Gt.WU(e),
                            options: r
                        }
                    },
                    v1GameLocalizationRolesGamesGameIdRolesRoleAssigneesGet: function(e, t, n) {
                        if (void 0 === n && (n = {}), null == e) throw new ms("gameId", "Required parameter gameId was null or undefined when calling v1GameLocalizationRolesGamesGameIdRolesRoleAssigneesGet.");
                        if (null == t) throw new ms("role", "Required parameter role was null or undefined when calling v1GameLocalizationRolesGamesGameIdRolesRoleAssigneesGet.");
                        t = "/v1/game-localization-roles/games/{gameId}/roles/{role}/assignees".replace("{gameId}", encodeURIComponent(String(e))).replace("{role}", encodeURIComponent(String(t))), t = Gt.Qc(t, !0);
                        s && (r = s.baseOptions);
                        var r = bs(bs({
                            method: "GET"
                        }, r), n);
                        return t.query = bs(bs(bs({}, t.query), {}), n.query), delete t.search, r.headers = bs(bs({}, {}), n.headers), {
                            url: Gt.WU(t),
                            options: r
                        }
                    },
                    v1GameLocalizationRolesRolesRoleCurrentUserGet: function(e, t, n, r, a) {
                        if (void 0 === a && (a = {}), null == e) throw new ms("role", "Required parameter role was null or undefined when calling v1GameLocalizationRolesRolesRoleCurrentUserGet.");
                        var o = "/v1/game-localization-roles/roles/{role}/current-user".replace("{role}", encodeURIComponent(String(e))),
                            e = Gt.Qc(o, !0);
                        s && (i = s.baseOptions);
                        var o = bs(bs({
                                method: "GET"
                            }, i), a),
                            i = {};
                        return void 0 !== t && (i.exclusiveStartKey = t), void 0 !== n && (i.pageSize = n), void 0 !== r && 0 < r && (i.groupId = r), e.query = bs(bs(bs({}, e.query), i), a.query), delete e.search, o.headers = bs(bs({}, {}), a.headers), {
                            url: Gt.WU(e),
                            options: o
                        }
                    }
                }
            }

            function Gs(i) {
                return {
                    v1GameLocalizationRolesGamesGameIdCurrentUserRolesGet: function(e, t) {
                        var n = Ps(i).v1GameLocalizationRolesGamesGameIdCurrentUserRolesGet(e, t);
                        return function(e, t) {
                            void 0 === e && (e = F), void 0 === t && (t = fs);
                            t = bs(bs({}, n.options), {
                                url: t + n.url
                            });
                            return e.request(t)
                        }
                    },
                    v1GameLocalizationRolesGamesGameIdPatch: function(e, t, n) {
                        var r = Ps(i).v1GameLocalizationRolesGamesGameIdPatch(e, t, n);
                        return function(e, t) {
                            void 0 === e && (e = F), void 0 === t && (t = fs);
                            t = bs(bs({}, r.options), {
                                url: t + r.url
                            });
                            return e.request(t)
                        }
                    },
                    v1GameLocalizationRolesGamesGameIdRolesRoleAssigneesGet: function(e, t, n) {
                        var r = Ps(i).v1GameLocalizationRolesGamesGameIdRolesRoleAssigneesGet(e, t, n);
                        return function(e, t) {
                            void 0 === e && (e = F), void 0 === t && (t = fs);
                            t = bs(bs({}, r.options), {
                                url: t + r.url
                            });
                            return e.request(t)
                        }
                    },
                    v1GameLocalizationRolesRolesRoleCurrentUserGet: function(e, t, n, r, a) {
                        var o = Ps(i).v1GameLocalizationRolesRolesRoleCurrentUserGet(e, t, n, r, a);
                        return function(e, t) {
                            void 0 === e && (e = F), void 0 === t && (t = fs);
                            t = bs(bs({}, o.options), {
                                url: t + o.url
                            });
                            return e.request(t)
                        }
                    }
                }
            }

            function ws() {
                return null !== ys && ys.apply(this, arguments) || this
            }(fe = {}).User = "user", fe.Group = "group", fe.GroupRole = "groupRole", (ie = {}).User = "user", ie.Group = "group", ie.GroupRole = "groupRole", (fe = {}).User = "user", fe.Group = "group", fe.GroupRole = "groupRole";
            var Cs, Ts = new(f(ws, ys = pe), ws.prototype.v1GameLocalizationRolesGamesGameIdCurrentUserRolesGet = function(e, t) {
                return Gs(this.configuration).v1GameLocalizationRolesGamesGameIdCurrentUserRolesGet(e, t)(this.axios, this.basePath)
            }, ws.prototype.v1GameLocalizationRolesGamesGameIdPatch = function(e, t, n) {
                return Gs(this.configuration).v1GameLocalizationRolesGamesGameIdPatch(e, t, n)(this.axios, this.basePath)
            }, ws.prototype.v1GameLocalizationRolesGamesGameIdRolesRoleAssigneesGet = function(e, t, n) {
                return Gs(this.configuration).v1GameLocalizationRolesGamesGameIdRolesRoleAssigneesGet(e, t, n)(this.axios, this.basePath)
            }, ws.prototype.v1GameLocalizationRolesRolesRoleCurrentUserGet = function(e, t, n, r, a) {
                return Gs(this.configuration).v1GameLocalizationRolesRolesRoleCurrentUserGet(e, t, n, r, a)(this.axios, this.basePath)
            }, ws);
            (Cs = Cs || {}).Translator = "translator";
            var As, ie = {
                    getGamesListForTranslator: function(e, t, n) {
                        return Ts.v1GameLocalizationRolesRolesRoleCurrentUserGet(Cs.Translator, t, e, n, {
                            withCredentials: !0
                        })
                    }
                },
                Ss = {
                    useCache: !1,
                    expirationWindowMS: 3e4
                };

            function Rs(t, n) {
                return function(e) {
                    e = Math.pow(2, e - 1) * t;
                    return Math.min(n, e)
                }
            }

            function Es(e, t) {
                this.store = new Map, this.useCache = e || !1, this.expirationWindowMS = t || 3e4, this.storeKeyPrefix = "CacheStore:BatchRequestProcessor::"
            }(fe = As = As || {}).processFailure = "processFailure", fe.unretriableFailure = "unretriableFailure", fe.maxAttemptsReached = "maxAttemptsReached";
            var Ls = (Es.prototype.getCacheKey = function(e) {
                    return "" + this.storeKeyPrefix + e
                }, Es.prototype.has = function(e, t) {
                    var n = t.useCache,
                        t = t.expirationWindowMS,
                        e = this.getCacheKey(e);
                    return (n || this.useCache) && localStorage ? !!_i.fetchNonExpiredCachedData(e, t || this.expirationWindowMS) : this.store.has(e)
                }, Es.prototype.set = function(e, t, n) {
                    n = n.useCache, e = this.getCacheKey(e);
                    (n || this.useCache) && localStorage && _i.saveDataByTimeStamp(e, t), this.store.set(e, t)
                }, Es.prototype.get = function(e, t) {
                    var n, r = t.useCache,
                        t = t.expirationWindowMS,
                        e = this.getCacheKey(e);
                    return (r || this.useCache) && localStorage ? null == (n = _i.fetchNonExpiredCachedData(e, t || this.expirationWindowMS)) ? void 0 : n.data : (n && this.store.set(e, null == n ? void 0 : n.data), this.store.get(e))
                }, Es.prototype.delete = function(e) {
                    e = this.getCacheKey(e);
                    localStorage && _i.removeLocalStorage(e), this.store.delete(e)
                }, Es.prototype.clear = function() {
                    if (this.store.clear(), localStorage) {
                        for (var e = [], t = 0; t < localStorage.length; t++) {
                            var n = localStorage.key(t);
                            n.includes(this.storeKeyPrefix) && e.push(n)
                        }
                        for (var r = 0; r < e.length; r++) localStorage.removeItem(e[r])
                    }
                }, Es),
                Us = function() {
                    return (Us = Object.assign || function(e) {
                        for (var t, n = 1, r = arguments.length; n < r; n++)
                            for (var a in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
                        return e
                    }).apply(this, arguments)
                };

            function qs(e, t, n) {
                this.requestQueue = [], this.concurrentRequestCount = 1, this.isQueueActive = !1, this.debug = !1;
                var r = n.cacheProperties,
                    a = n.processBatchWaitTime,
                    o = n.batchSize,
                    i = n.maxRetryAttempts,
                    s = n.getItemExpiration,
                    u = n.getFailureCooldown,
                    c = n.debugMode,
                    l = n.concurrentRequestCount,
                    d = r.useCache,
                    n = r.expirationWindowMS;
                this.cacheProperties = r, this.completeItems = new Ls(d, n), this.processBatchWaitTime = a, this.batchSize = o, this.maxRetryAttempts = i, this.getItemExpiration = s, this.getFailureCooldown = u, this.itemsProcessor = e, this.itemsSerializer = t, this.debug = c || !1, this.processorId = Date.now(), this.concurrentRequestCount = l
            }
            var Os = (qs.prototype.handleBatchResult = function(e, n) {
                var r = this,
                    a = 0,
                    o = (new Date).getTime();
                e.forEach(function(e) {
                    var t;
                    r.completeItems.has(e.key, e.cacheProperties) ? (t = (new Date).getTime(), e.resolve(Us(Us({}, r.completeItems.get(e.key, e.cacheProperties)), {
                        performance: {
                            duration: t - e.startTime.getTime(),
                            retryAttempts: e.retryAttempts
                        }
                    }))) : r.maxRetryAttempts && n !== As.unretriableFailure ? (t = r.getFailureCooldown ? r.getFailureCooldown(e.retryAttempts) : 1e3, a = 0 < a ? Math.min(a, t) : t, ++e.retryAttempts <= r.maxRetryAttempts ? (e.queueAfter = o + t, r.requestQueue.unshift(e)) : e.reject(As.maxAttemptsReached)) : (console.debug(n, e), e.reject(n))
                }), this.processEndTime = Date.now(), this.debug && console.debug(this.processorId + ": process queue ended", {
                    duration: this.processEndTime - this.processStartTime,
                    requestQueue: this.requestQueue,
                    minimumCooldown: a,
                    processBatchWaitTime: this.processBatchWaitTime
                }), 0 < a && setTimeout(function() {
                    return r.processQueue()
                }, a + this.processBatchWaitTime), this.concurrentRequestCount += 1, this.processQueue()
            }, qs.prototype.processQueue = function() {
                var e, r = this;
                if (0 !== this.concurrentRequestCount && !this.isQueueActive) {
                    this.processStartTime = Date.now();
                    var t = [],
                        a = new Map,
                        n = [],
                        o = (new Date).getTime();
                    for (this.isQueueActive = !0; t.length < this.batchSize && 0 < this.requestQueue.length;) {
                        var i, s = this.requestQueue.shift();
                        s.queueAfter > o ? (a.set(s.key, s), n.push(s)) : this.completeItems.has(s.key, s.cacheProperties) ? (i = (new Date).getTime(), s.resolve(Us(Us({}, this.completeItems.get(s.key, s.cacheProperties)), {
                            performance: {
                                duration: i - s.startTime.getTime()
                            }
                        }))) : a.has(s.key) ? n.push(s) : (a.set(s.key, s), t.push(s))
                    }(e = this.requestQueue).push.apply(e, n), this.isQueueActive = !1, t.length <= 0 || (--this.concurrentRequestCount, this.processQueue(), this.debug && console.debug(this.processorId + ": process queue start", {
                        timeSinceLastStart: this.processEndTime ? this.processStartTime - this.processEndTime : 0,
                        startTime: this.processStartTime,
                        requestQueue: this.requestQueue,
                        batch: t.map(function(e) {
                            return e.key
                        })
                    }), this.itemsProcessor(t).then(function(e) {
                        Object.entries(e).forEach(function(e) {
                            var t = e[0],
                                n = e[1],
                                e = a.get(t);
                            r.saveCompleteItem(t, n, null == e ? void 0 : e.cacheProperties)
                        }), r.handleBatchResult(t, As.processFailure)
                    }, function(e) {
                        r.handleBatchResult(t, e)
                    }))
                }
            }, qs.prototype.saveCompleteItem = function(e, t, n) {
                var r = this;
                this.completeItems.set(e, t, n || this.cacheProperties), this.getItemExpiration && setTimeout(function() {
                    r.completeItems.delete(e)
                }, this.getItemExpiration(e))
            }, qs.prototype.queueItem = function(n, r, a) {
                var o = this;
                return new Promise(function(e, t) {
                    o.requestQueue.push({
                        key: r || o.itemsSerializer(n),
                        itemId: n,
                        data: n,
                        retryAttempts: 0,
                        queueAfter: 0,
                        startTime: new Date,
                        cacheProperties: a || o.cacheProperties,
                        resolve: e,
                        reject: t
                    }), setTimeout(function() {
                        return o.processQueue()
                    }, o.processBatchWaitTime)
                })
            }, qs.prototype.invalidateItem = function(e, t) {
                e = t || this.itemsSerializer(e);
                return this.completeItems.delete(e)
            }, qs.prototype.clearCache = function() {
                this.completeItems.clear()
            }, qs);

            function Ds() {
                this.createExponentialBackoffCooldown = Rs
            }
            new(f = (Ds.prototype.createRequestProcessor = function(e, t, n) {
                return n.processBatchWaitTime || (n.processBatchWaitTime = 10), n.maxRetryAttempts || (n.maxRetryAttempts = 2), n.cacheProperties || (n.cacheProperties = Ss), n.concurrentRequestCount || (n.concurrentRequestCount = 1), new Os(e, t, n)
            }, Ds));
            var xs, _s = m.EnvironmentUrls.friendsApi,
                Bs = m.EnvironmentUrls.presenceApi,
                Fs = m.EnvironmentUrls.usersApi;

            function Ns(e, t) {
                return t = _s + "/v1/users/" + t + "/" + e, e === xs.Requests && (t = _s + "/v1/my/friends/requests"), {
                    url: t,
                    retryable: !0,
                    withCredentials: !0
                }
            }

            function ks() {
                return {
                    url: Bs + "/v1/presence/users",
                    retryable: !1,
                    withCredentials: !0
                }
            }

            function Ms(s) {
                return function(e) {
                    var t, n, r = e[0],
                        u = r.key,
                        a = r.data,
                        o = a.userId,
                        c = a.isGuest,
                        i = Ns(s, o),
                        t = (n = (t = a).cursor, e = t.sortOrder, r = t.userSort, o = t.limit, a = t.fetchMutualFriends, t = {}, n && Object.assign(t, {
                            cursor: n
                        }), e && Object.assign(t, {
                            sortOrder: e
                        }), r && Object.assign(t, {
                            userSort: r
                        }), o && Object.assign(t, {
                            limit: o
                        }), a && Object.assign(t, {
                            fetchMutualFriends: a
                        }), t);
                    return rt.get(i, t).then(function(e) {
                        var r = {};
                        if (null == e || !e.data) return r[u] = {
                            userData: []
                        }, r;
                        var t, n = e.data,
                            a = n.data,
                            o = n.previousPageCursor,
                            i = n.nextPageCursor,
                            s = (t = {}, a.forEach(function(e) {
                                t[e.id] = e, t[e.id].profileUrl = "/users/" + e.id + "/profile", t[e.id].presence = {}
                            }), t);
                        if (c) return r[u] = {
                            userData: a,
                            prevCursor: o,
                            nextCursor: i
                        }, r;
                        e = ks(), n = Object.keys(s).map(function(e) {
                            return parseInt(e, 10)
                        });
                        return rt.post(e, {
                            userIds: n
                        }).then(function(e) {
                            var t, n;
                            return t = s, 0 < (null === (e = null === (e = null == (n = e) ? void 0 : n.data) || void 0 === e ? void 0 : e.userPresences) || void 0 === e ? void 0 : e.length) && (n = n.data.userPresences, Ys([], n).forEach(function(e) {
                                t[e.userId].presence = e
                            })), r[u] = {
                                userData: a,
                                prevCursor: o,
                                nextCursor: i
                            }, r
                        }).catch(function(e) {
                            return console.debug(e), r[u] = {
                                userData: a,
                                prevCursor: o,
                                nextCursor: i
                            }, r
                        })
                    }).catch(function(e) {
                        return console.debug(e), {}
                    })
                }
            }

            function js(e) {
                return e = 0 < arguments.length && void 0 !== e ? e : window.location.search, nu.parse(e)
            }

            function zs(e) {
                return e = 0 < arguments.length && void 0 !== e ? e : {}, nu.stringify(e)
            }

            function Ws(e) {
                return m.Endpoints ? m.Endpoints.getAbsoluteUrl(e) : e
            }

            function Vs(e, t) {
                return Ws("".concat(e, "?").concat(zs(t)))
            }

            function Hs() {
                return _i.getLocalStorage(ou)
            }

            function Qs(e) {
                _i.setLocalStorage(ou, e)
            }

            function Ks(t) {
                var e = _i.getLocalStorage(ou) || {},
                    n = Math.floor(Date.now() / 1e3),
                    r = (null === (r = e[iu]) || void 0 === r ? void 0 : r.game) || [];
                (r = r.filter(function(e) {
                    return e.gameId !== t
                })).push({
                    gameId: t,
                    clientEpochTimestamp: n
                }), 20 < r.length && r.shift(), e[iu] = au(au({}, e[iu]), {
                    game: r
                });
                try {
                    Qs(e)
                } catch (e) {
                    console.error("Error setting AuthIntent data:", e)
                }
            }(pe = xs = xs || {}).Friends = "friends", pe.Followers = "followers", pe.Followings = "followings", pe.Requests = "requests", (fe = tu = tu || {}).Alphabetical = "Alphabetical", fe.StatusAlphabetical = "StatusAlphabetical", fe.StatusFrequents = "StatusFrequents";
            var Xs, Js, Ys = function(e, t) {
                    for (var n = 0, r = t.length, a = e.length; n < r; n++, a++) e[a] = t[n];
                    return e
                },
                $s = (new f).createRequestProcessor(function(e) {
                    var t = {
                            url: Fs + "/v1/users",
                            retryable: !0,
                            withCredentials: !0
                        },
                        e = e.map(function(e) {
                            return e.data.userId
                        });
                    return rt.post(t, {
                        userIds: e,
                        excludeBannedUsers: !0
                    }).then(function(e) {
                        var e = e.data.data,
                            t = {};
                        return e.forEach(function(e) {
                            t[e.id] = e
                        }), t
                    })
                }, function(e) {
                    e = e.userId;
                    return null == e ? void 0 : e.toString()
                }, {
                    batchSize: 100,
                    processBatchWaitTime: 1e3
                }),
                Zs = new f,
                eu = new Map,
                pe = function(r) {
                    var a = function(e, t, n) {
                        if (eu.has(e)) return eu.get(e);
                        n = Zs.createRequestProcessor(t, n, {
                            batchSize: 1
                        });
                        return eu.set(e, n), n
                    }(r, Ms(r), function(e) {
                        e = e.userId;
                        return null == e ? void 0 : e.toString()
                    });
                    return function(e, t) {
                        var n, n = r + ":" + (n = e).userId + ":" + n.cursor + ":" + n.sortOrder + ":" + n.userSort + ":" + n.limit;
                        return null != t && t.refreshCache && a.invalidateItem(e, n), a.queueItem(e, n, t)
                    }
                },
                tu = (null === (fe = null === (fe = window.CoreRobloxUtilities) || void 0 === fe ? void 0 : fe.dataStores) || void 0 === fe ? void 0 : fe.userDataStoreV2) || {
                    getFriends: pe(xs.Friends),
                    getFollowers: pe(xs.Followers),
                    getFollowings: pe(xs.Followings),
                    getFriendsRequests: pe(xs.Requests),
                    getUser: function(e) {
                        return $s.queueItem({
                            userId: e
                        })
                    },
                    clearUserDataStoreCache: function() {
                        eu.forEach(function(e) {
                            e.clearCache()
                        })
                    },
                    maxFriendRequestNotificationCount: 500,
                    maxMessagesNotificationCount: 500,
                    FriendsUserSortType: tu
                },
                nu = Vl(6933),
                ru = {
                    getAbsoluteUrl: Ws,
                    parseQueryString: js,
                    composeQueryString: zs,
                    getQueryParam: function(e) {
                        return js()[e]
                    },
                    formatUrl: Gt.WU,
                    resolveUrl: Gt.DB,
                    parseUrl: Gt.Qc,
                    parseUrlAndQueryString: nu.parseUrl,
                    extractQueryString: nu.extract,
                    getGameDetailReferralUrls: function(e) {
                        return Ws("/games/refer?".concat(zs(e)))
                    },
                    getUrlWithQueries: Vs,
                    getUrlWithLocale: function(e, t) {
                        return t ? Vs(e, {
                            locale: t
                        }) : e
                    }
                },
                au = function() {
                    return (au = Object.assign || function(e) {
                        for (var t, n = 1, r = arguments.length; n < r; n++)
                            for (var a in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
                        return e
                    }).apply(this, arguments)
                },
                ou = "RBXAuthIntent",
                iu = "-1",
                ie = {
                    authIntentDataStore: {
                        addGameIdToUnClaimedAuthIntent: Ks,
                        applyUserAuthIntent: function(e) {
                            var t = _i.getLocalStorage(ou);
                            t && t[iu] && (t[e] = t[iu], delete t[iu], Qs(t))
                        },
                        retrieveAuthIntentDataForUser: function() {
                            if (m.CurrentUser.userId) return Hs() && Hs()[m.CurrentUser.userId]
                        },
                        saveGameIntentFromReturnUrl: function() {
                            var e = ru.getQueryParam("returnUrl"),
                                e = /\/games\/(\d+)\//.exec(e);
                            e && Ks(e[1])
                        },
                        saveGameIntentFromCurrentUrl: function() {
                            var e = window.location.href,
                                e = /\/games\/(\d+)\//.exec(e);
                            e && Ks(e[1])
                        },
                        hasUnclaimedAuthIntent: function() {
                            var e = _i.getLocalStorage(ou);
                            return !(!e || !e[iu])
                        }
                    },
                    catalogDataStore: ne,
                    gameAutoLocalizationDataStore: $r,
                    gameAutomaticTranslationDataStore: oe,
                    gameLanguagesDataStore: I,
                    gameSourceLanguageDataStore: te,
                    gameThumbnailsDataStore: K,
                    gameTranslationAnalyticsDataStore: En,
                    gamesDataStore: Ro,
                    hbacIndexedDB: t,
                    inventoryDataStore: xo,
                    localeDataStore: Z,
                    thumbnailsDataStore: ae,
                    translationProgressDataStore: z,
                    translationRolesDataStore: ie,
                    userDataStore: tu,
                    userDataStoreV2: tu
                };

            function su(e, t, n) {
                return {
                    type: "linkResolved",
                    context: "deepLink",
                    params: {
                        linkType: n,
                        linkStatus: e,
                        linkId: t
                    }
                }
            }(tu = Xs = Xs || {}).GameDetails = "game_details", tu.Profile = "profile", tu.Home = "home", tu.Games = "games", tu.Avatar = "avatar", tu.Catalog = "catalog", tu.Friends = "friends", tu.ItemDetails = "item_details", tu.Navigation = "navigation", tu.PlaceId = "placeId", tu.UserId = "userId", tu.ShareLinks = "share_links", tu.Chat = "chat", tu.GiftCards = "gift_cards", tu.NotificationSettings = "notification_settings", tu.AccountInfo = "account_info", tu.PrivacySettings = "privacy_settings", tu.ParentalControls = "parental_controls", tu.SpendingSettings = "spending_settings", tu.Group = "group", tu.ExternalWebUrl = "external_web_link", (tu = Js = Js || {}).Asset = "Asset", tu.Bundle = "Bundle", tu.Look = "Look";
            var uu, cu, lu, du, hu, vu, pu, fu = ((tu = {})[Js.Asset] = "/catalog", tu[Js.Bundle] = "/bundles", tu[Js.Look] = "/looks", tu),
                mu = ((tu = {})[Xs.Home] = "/home", tu[Xs.Games] = "/games", tu[Xs.Avatar] = "/my/avatar", tu[Xs.Catalog] = "/catalog", tu[Xs.Friends] = "/users/friends", tu[Xs.GiftCards] = "/giftcards", tu[Xs.NotificationSettings] = "/my/account#!/notifications", tu[Xs.AccountInfo] = "/my/account#!/info", tu[Xs.PrivacySettings] = "/my/account#!/privacy", tu[Xs.ParentalControls] = "/my/account#!/parental-controls", tu[Xs.SpendingSettings] = "/my/account#!/billing", tu[Xs.Group] = "/groups/{groupId}", tu),
                gu = {
                    Games: "/games",
                    Users: "/users",
                    Groups: "/groups",
                    Profile: "/profile",
                    GameStart: "/games/start",
                    GiftCards: "/giftcards",
                    ExperienceLauncher: "roblox://experiences/start?",
                    Asset: "/catalog",
                    Bundle: "/bundles",
                    Look: "/looks"
                },
                Iu = "DeeplinkParserNavigationFailed",
                yu = "DeeplinkParserInviteResolutionFailed",
                bu = "DeeplinkParserNotificationInviteResolutionFailed",
                Pu = "DeeplinkParserFriendRequestResolutionFailed",
                Gu = "DeeplinkParserProfileShareResolutionFailed",
                wu = "DeeplinkParserScreenshotInviteShareResolutionFailed",
                Cu = "DeeplinkParserPrivateServerLinkResolutionFailed",
                Tu = "DeeplinkParserExperienceDetailsResolutionFailed",
                Au = "DeeplinkParserAvatarItemDetailsResolutionFailed",
                Su = window.EventTracker ? EventTracker : {
                    fireEvent: console.log,
                    start: console.log,
                    endSuccess: console.log,
                    endCancel: console.log,
                    endFailure: console.log
                };
            (uu = uu = uu || {}).Strict = "strict", uu.Lax = "lax", uu.None = "none", (uu = lu = lu || {}).PagingParametersChanged = "Paging parameters were changed", uu.GetItemsFailure = "Unable to get items", uu.InvalidPageNumber = "Invalid page number", (lu = cu = cu || {})[lu.Initialized = 0] = "Initialized", lu[lu.Idle = 1] = "Idle", lu[lu.Loading = 2] = "Loading", (hu = hu = hu || {}).Asc = "Asc", hu.Desc = "Desc", new Intl.DateTimeFormat(void 0, {
                year: "numeric",
                month: "short",
                day: "numeric",
                hour: "numeric",
                minute: "numeric",
                hour12: !0
            }), (hu = du = du || {})[hu.Windows = 0] = "Windows", hu[hu.macOS = 1] = "macOS", hu[hu.Linux = 2] = "Linux", hu[hu.Unix = 3] = "Unix", hu[hu.iOS = 4] = "iOS", hu[hu.Android = 5] = "Android", hu[hu.Unknown = 6] = "Unknown", (vu = vu = vu || {}).Unidentified = "Unidentified", vu.Alt = "Alt", vu.AltGraph = "AltGraph", vu.CapsLock = "CapsLock", vu.Control = "Control", vu.Fn = "Fn", vu.FnLock = "FnLock", vu.Hyper = "Hyper", vu.Meta = "Meta", vu.NumLock = "NumLock", vu.ScrollLock = "ScrollLock", vu.Shift = "Shift", vu.Super = "Super", vu.Symbol = "Symbol", vu.SymbolLock = "SymbolLock", vu.Enter = "Enter", vu.Tab = "Tab", vu.ArrowDown = "ArrowDown", vu.ArrowLeft = "ArrowLeft", vu.ArrowRight = "ArrowRight", vu.ArrowUp = "ArrowUp", vu.End = "End", vu.Home = "Home", vu.PageDown = "PageDown", vu.PageUp = "PageUp", vu.Backspace = "Backspace", vu.Clear = "Clear", vu.Copy = "Copy", vu.CrSel = "CrSel", vu.Cut = "Cut", vu.Delete = "Delete", vu.EraseEof = "EraseEof", vu.ExSel = "ExSel", vu.Insert = "Insert", vu.Paste = "Paste", vu.Redo = "Redo", vu.Undo = "Undo", vu.Accept = "Accept", vu.Again = "Again", vu.Attn = "Attn", vu.Cancel = "Cancel", vu.ContextMenu = "ContextMenu", vu.Escape = "Escape", vu.Execute = "Execute", vu.Find = "Find", vu.Finish = "Finish", vu.Help = "Help", vu.Pause = "Pause", vu.Play = "Play", vu.Props = "Props", vu.Select = "Select", vu.ZoomIn = "ZoomIn", vu.ZoomOut = "ZoomOut", vu.BrightnessDown = "BrightnessDown", vu.BrightnessUp = "BrightnessUp", vu.Eject = "Eject", vu.LogOff = "LogOff", vu.Power = "Power", vu.PowerOff = "PowerOff", vu.PrintScreen = "PrintScreen", vu.Hibernate = "Hibernate", vu.Standby = "Standby", vu.WakeUp = "WakeUp", vu.AllCandidates = "AllCandidates", vu.Alphanumeric = "Alphanumeric", vu.CodeInput = "CodeInput", vu.Compose = "Compose", vu.Convert = "Convert", vu.Dead = "Dead", vu.FinalMode = "FinalMode", vu.GroupFirst = "GroupFirst", vu.GroupLast = "GroupLast", vu.GroupNext = "GroupNext", vu.GroupPrevious = "GroupPrevious", vu.ModeChange = "ModeChange", vu.NextCandidate = "NextCandidate", vu.NonConvert = "NonConvert", vu.PreviousCandidate = "PreviousCandidate", vu.Process = "Process", vu.SingleCandidate = "SingleCandidate", vu.HangulMode = "HangulMode", vu.HanjaMode = "HanjaMode", vu.JunjaMode = "JunjaMode", vu.Eisu = "Eisu", vu.Hankaku = "Hankaku", vu.Hiragana = "Hiragana", vu.HiraganaKatakana = "HiraganaKatakana", vu.KanaMode = "KanaMode", vu.KanjiMode = "KanjiMode", vu.Katakana = "Katakana", vu.Romaji = "Romaji", vu.Zenkaku = "Zenkaku", vu.ZenkakuHanaku = "ZenkakuHanaku", vu.F1 = "F1", vu.F2 = "F2", vu.F3 = "F3", vu.F4 = "F4", vu.F5 = "F5", vu.F6 = "F6", vu.F7 = "F7", vu.F8 = "F8", vu.F9 = "F9", vu.F10 = "F10", vu.F11 = "F11", vu.F12 = "F12", vu.F13 = "F13", vu.F14 = "F14", vu.F15 = "F15", vu.F16 = "F16", vu.F17 = "F17", vu.F18 = "F18", vu.F19 = "F19", vu.F20 = "F20", vu.Soft1 = "Soft1", vu.Soft2 = "Soft2", vu.Soft3 = "Soft3", vu.Soft4 = "Soft4", vu.AppSwitch = "AppSwitch", vu.Call = "Call", vu.Camera = "Camera", vu.CameraFocus = "CameraFocus", vu.EndCall = "EndCall", vu.GoBack = "GoBack", vu.GoHome = "GoHome", vu.HeadsetHook = "HeadsetHook", vu.LastNumberRedial = "LastNumberRedial", vu.Notification = "Notification", vu.MannerMode = "MannerMode", vu.VoiceDial = "VoiceDial", vu.ChannelDown = "ChannelDown", vu.ChannelUp = "ChannelUp", vu.MediaFastForward = "MediaFastForward", vu.MediaPause = "MediaPause", vu.MediaPlay = "MediaPlay", vu.MediaPlayPause = "MediaPlayPause", vu.MediaRecord = "MediaRecord", vu.MediaRewind = "MediaRewind", vu.MediaStop = "MediaStop", vu.MediaTrackNext = "MediaTrackNext", vu.MediaTrackPrevious = "MediaTrackPrevious", vu.AudioBalanceLeft = "AudioBalanceLeft", vu.AudioBalanceRight = "AudioBalanceRight", vu.AudioBassDown = "AudioBassDown", vu.AudioBassBoostDown = "AudioBassBoostDown", vu.AudioBassBoostToggle = "AudioBassBoostToggle", vu.AudioBassBoostUp = "AudioBassBoostUp", vu.AudioBassUp = "AudioBassUp", vu.AudioFaderFront = "AudioFaderFront", vu.AudioFaderRear = "AudioFaderRear", vu.AudioSurroundModeNext = "AudioSurroundModeNext", vu.AudioTrebleDown = "AudioTrebleDown", vu.AudioTrebleUp = "AudioTrebleUp", vu.AudioVolumeDown = "AudioVolumeDown", vu.AudioVolumeMute = "AudioVolumeMute", vu.AudioVolumeUp = "AudioVolumeUp", vu.MicrophoneToggle = "MicrophoneToggle", vu.MicrophoneVolumeDown = "MicrophoneVolumeDown", vu.MicrophoneVolumeMute = "MicrophoneVolumeMute", vu.MicrophoneVolumeUp = "MicrophoneVolumeUp", vu.TV = "TV", vu.TV3DMode = "TV3DMode", vu.TVAntennaCable = "TVAntennaCable", vu.TVAudioDescription = "TVAudioDescription", vu.TVAudioDescriptionMixDown = "TVAudioDescriptionMixDown", vu.TVAudioDescriptionMixUp = "TVAudioDescriptionMixUp", vu.TVContentsMenu = "TVContentsMenu", vu.TVDataService = "TVDataService", vu.TVInput = "TVInput", vu.TVInputComponent1 = "TVInputComponent1", vu.TVInputComponent2 = "TVInputComponent2", vu.TVInputComposite1 = "TVInputComposite1", vu.TVInputComposite2 = "TVInputComposite2", vu.TVInputHDMI1 = "TVInputHDMI1", vu.TVInputHDMI2 = "TVInputHDMI2", vu.TVInputHDMI3 = "TVInputHDMI3", vu.TVInputHDMI4 = "TVInputHDMI4", vu.TVInputVGA1 = "TVInputVGA1", vu.TVMediaContext = "TVMediaContext", vu.TVNetwork = "TVNetwork", vu.TVNumberEntry = "TVNumberEntry", vu.TVPower = "TVPower", vu.TVRadioService = "TVRadioService", vu.TVSatellite = "TVSatellite", vu.TVSatelliteBS = "TVSatelliteBS", vu.TVSatelliteCS = "TVSatelliteCS", vu.TVSatelliteToggle = "TVSatelliteToggle", vu.TVTerrestrialAnalog = "TVTerrestrialAnalog", vu.TVTerrestrialDigital = "TVTerrestrialDigital", vu.TVTimer = "TVTimer", vu.AVRInput = "AVRInput", vu.AVRPower = "AVRPower", vu.ColorF0Red = "ColorF0Red", vu.ColorF1Green = "ColorF1Green", vu.ColorF2Yellow = "ColorF2Yellow", vu.ColorF3Blue = "ColorF3Blue", vu.ColorF4Grey = "ColorF4Grey", vu.ColorF5Brown = "ColorF5Brown", vu.ClosedCaptionToggle = "ClosedCaptionToggle", vu.Dimmer = "Dimmer", vu.DisplaySwap = "DisplaySwap", vu.DVR = "DVR", vu.Exit = "Exit", vu.FavoriteClear0 = "FavoriteClear0", vu.FavoriteClear1 = "FavoriteClear1", vu.FavoriteClear2 = "FavoriteClear2", vu.FavoriteClear3 = "FavoriteClear3", vu.FavoriteRecall0 = "FavoriteRecall0", vu.FavoriteRecall1 = "FavoriteRecall1", vu.FavoriteRecall2 = "FavoriteRecall2", vu.FavoriteRecall3 = "FavoriteRecall3", vu.FavoriteStore0 = "FavoriteStore0", vu.FavoriteStore1 = "FavoriteStore1", vu.FavoriteStore2 = "FavoriteStore2", vu.FavoriteStore3 = "FavoriteStore3", vu.Guide = "Guide", vu.GuideNextDay = "GuideNextDay", vu.GuidePreviousDay = "GuidePreviousDay", vu.Info = "Info", vu.InstantReplay = "InstantReplay", vu.Link = "Link", vu.ListProgram = "ListProgram", vu.LiveContent = "LiveContent", vu.Lock = "Lock", vu.MediaApps = "MediaApps", vu.MediaAudioTrack = "MediaAudioTrack", vu.MediaLast = "MediaLast", vu.MediaSkipBackward = "MediaSkipBackward", vu.MediaSkipForward = "MediaSkipForward", vu.MediaStepBackward = "MediaStepBackward", vu.MediaStepForward = "MediaStepForward", vu.MediaTopMenu = "MediaTopMenu", vu.NavigateIn = "NavigateIn", vu.NavigateNext = "NavigateNext", vu.NavigateOut = "NavigateOut", vu.NavigatePrevious = "NavigatePrevious", vu.NextFavoriteChannel = "NextFavoriteChannel", vu.NextUserProfile = "NextUserProfile", vu.OnDemand = "OnDemand", vu.Pairing = "Pairing", vu.PinPDown = "PinPDown", vu.PinPMove = "PinPMove", vu.PinPToggle = "PinPToggle", vu.PinPUp = "PinPUp", vu.PlaySpeedDown = "PlaySpeedDown", vu.PlaySpeedReset = "PlaySpeedReset", vu.PlaySpeedUp = "PlaySpeedUp", vu.RandomToggle = "RandomToggle", vu.RcLowBattery = "RcLowBattery", vu.RecordSpeedNext = "RecordSpeedNext", vu.RfBypass = "RfBypass", vu.ScanChannelsToggle = "ScanChannelsToggle", vu.ScreenModeNext = "ScreenModeNext", vu.Settings = "Settings", vu.SplitScreenToggle = "SplitScreenToggle", vu.STBInput = "STBInput", vu.STBPower = "STBPower", vu.Subtitle = "Subtitle", vu.Teletext = "Teletext", vu.VideoModeNext = "VideoModeNext", vu.Wink = "Wink", vu.ZoomToggle = "ZoomToggle", vu.SpeechCorrectionList = "SpeechCorrectionList", vu.SpeechInputToggle = "SpeechInputToggle", vu.Close = "Close", vu.New = "New", vu.Open = "Open", vu.Print = "Print", vu.Save = "Save", vu.SpellCheck = "SpellCheck", vu.MailForward = "MailForward", vu.MailReply = "MailReply", vu.MailSend = "MailSend", vu.LaunchCalculator = "LaunchCalculator", vu.LaunchCalendar = "LaunchCalendar", vu.LaunchContacts = "LaunchContacts", vu.LaunchMail = "LaunchMail", vu.LaunchMediaPlayer = "LaunchMediaPlayer", vu.LaunchMusicPlayer = "LaunchMusicPlayer", vu.LaunchMyComputer = "LaunchMyComputer", vu.LaunchPhone = "LaunchPhone", vu.LaunchScreenSaver = "LaunchScreenSaver", vu.LaunchSpreadsheet = "LaunchSpreadsheet", vu.LaunchWebBrowser = "LaunchWebBrowser", vu.LaunchWebCam = "LaunchWebCam", vu.LaunchWordProcessor = "LaunchWordProcessor", vu.LaunchApplication1 = "LaunchApplication1", vu.LaunchApplication2 = "LaunchApplication2", vu.LaunchApplication3 = "LaunchApplication3", vu.LaunchApplication4 = "LaunchApplication4", vu.LaunchApplication5 = "LaunchApplication5", vu.LaunchApplication6 = "LaunchApplication6", vu.LaunchApplication7 = "LaunchApplication7", vu.LaunchApplication8 = "LaunchApplication8", vu.LaunchApplication9 = "LaunchApplication9", vu.LaunchApplication10 = "LaunchApplication10", vu.LaunchApplication11 = "LaunchApplication11", vu.LaunchApplication12 = "LaunchApplication12", vu.LaunchApplication13 = "LaunchApplication13", vu.LaunchApplication14 = "LaunchApplication14", vu.LaunchApplication15 = "LaunchApplication15", vu.LaunchApplication16 = "LaunchApplication16", vu.BrowserBack = "BrowserBack", vu.BrowserFavorites = "BrowserFavorites", vu.BrowserForward = "BrowserForward", vu.BrowserHome = "BrowserHome", vu.BrowserRefresh = "BrowserRefresh", vu.BrowserSearch = "BrowserSearch", vu.BrowserStop = "BrowserStop", vu.Decimal = "Decimal", vu.Key11 = "Key11", vu.Key12 = "Key12", vu.Multiply = "Multiply", vu.Add = "Add", vu.Divide = "Divide", vu.Subtract = "Subtract", vu.Separator = "Separator", (Bu = Bu = Bu || {}).CONNECT = "CONNECT", Bu.DELETE = "DELETE", Bu.GET = "GET", Bu.HEAD = "HEAD", Bu.OPTIONS = "OPTIONS", Bu.PATCH = "PATCH", Bu.POST = "POST", Bu.PUT = "PUT", Bu.TRACE = "TRACE", (Bu = pu = pu || {}).processFailure = "processFailure", Bu.unretriableFailure = "unretriableFailure", Bu.maxAttemptsReached = "maxAttemptsReached";
            for (var Ru, Eu = new Uint8Array(16), Lu = /^(?:[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}|00000000-0000-0000-0000-000000000000)$/i, Uu = function(e) {
                    return "string" == typeof e && Lu.test(e)
                }, qu = [], Ou = 0; Ou < 256; ++Ou) qu.push((Ou + 256).toString(16).substr(1));
            var Du = function(e) {
                var t = (qu[e[(t = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : 0) + 0]] + qu[e[t + 1]] + qu[e[t + 2]] + qu[e[t + 3]] + "-" + qu[e[t + 4]] + qu[e[t + 5]] + "-" + qu[e[t + 6]] + qu[e[t + 7]] + "-" + qu[e[t + 8]] + qu[e[t + 9]] + "-" + qu[e[t + 10]] + qu[e[t + 11]] + qu[e[t + 12]] + qu[e[t + 13]] + qu[e[t + 14]] + qu[e[t + 15]]).toLowerCase();
                if (!Uu(t)) throw TypeError("Stringified UUID is invalid");
                return t
            };

            function xu(e) {
                var t = e.eventName,
                    n = e.ctx,
                    e = e.properties;
                Ae.sendEventWithTarget(t, n, e)
            }

            function _u(e, t, n) {
                Ae.sendGamePlayEvent(e, t, void 0, n)
            }
            var Bu, Fu = function(e, t, n) {
                    var r = (e = e || {}).random || (e.rng || function() {
                        if (!Ru && !(Ru = "undefined" != typeof crypto && crypto.getRandomValues && crypto.getRandomValues.bind(crypto) || "undefined" != typeof msCrypto && "function" == typeof msCrypto.getRandomValues && msCrypto.getRandomValues.bind(msCrypto))) throw new Error("crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported");
                        return Ru(Eu)
                    })();
                    if (r[6] = 15 & r[6] | 64, r[8] = 63 & r[8] | 128, t) {
                        n = n || 0;
                        for (var a = 0; a < 16; ++a) t[n + a] = r[a];
                        return t
                    }
                    return Du(r)
                },
                Nu = {
                    buildPlayGameProperties: function(e, t, n, r, a, o) {
                        return {
                            rootPlaceId: e,
                            placeId: t,
                            gameInstanceId: n,
                            playerId: r,
                            privateServerLinkCode: a,
                            referredByPlayerId: o
                        }
                    },
                    launchGame: function(e, t) {
                        var n, r, a, o, i, s, u, c, l, d, h, v;
                        m.GameLauncher && (o = m.GameLauncher.isJoinAttemptIdEnabled() ? Fu() : void 0, i = t, m.GameLauncher.isJoinAttemptIdEnabled() && (i.properties.joinAttemptId = o), n = e.rootPlaceId, a = e.placeId, h = e.gameInstanceId, r = e.playerId, s = e.privateServerLinkCode, v = e.referredByPlayerId, a === n && h ? (i.properties.gameInstanceId = h, xu(i), _u(i.gamePlayIntentEventCtx, n, o), d = a, t = h, e = o, h = i.gamePlayIntentEventCtx, v = v, m.GameLauncher.joinGameInstance(d, t, !0, !0, e, h, v)) : n && r ? (i.properties.playerId = r, xu(i), _u(i.gamePlayIntentEventCtx, n, o), u = r, c = o, l = i.gamePlayIntentEventCtx, m.GameLauncher.followPlayerIntoGame(u, c, l)) : s ? (xu(i), _u(i.gamePlayIntentEventCtx, a, o), u = a, c = s, l = o, s = i.gamePlayIntentEventCtx, m.GameLauncher.joinPrivateGame(u, null, c, l, s)) : (xu(i), _u(i.gamePlayIntentEventCtx, a, o), a = a, o = o, i = i.gamePlayIntentEventCtx, m.GameLauncher.joinMultiplayerGame(a, !0, !1, o, i)))
                    }
                },
                ku = function(e) {
                    var t, n, r, a = e.userId;
                    a ? ((r = m.DeviceMeta && new m.DeviceMeta) && r.isAndroidApp ? ((t = {
                        userIds: []
                    }).userIds.push(a), null !== (e = m.Hybrid.Chat) && void 0 !== e && e.startChatConversation(t)) : r && r.isIosApp ? null !== (t = m.Hybrid.Navigation) && void 0 !== t && t.startWebChatConversation(a) : r && r.isUWPApp ? null !== (n = m.Hybrid.Navigation) && void 0 !== n && n.startWebChatConversation(a) : r && r.isWin32App ? null !== (n = m.Hybrid.Navigation) && void 0 !== n && n.startWebChatConversation(a) : r && r.isUniversalApp ? null !== (r = m.Hybrid.Navigation) && void 0 !== r && r.startWebChatConversation(a) : $(document).triggerHandler("Roblox.Chat.StartChat", {
                        userId: a
                    }), Ae.sendEventWithTarget("startChatByUser", "click", {
                        userId: a
                    })) : console.log("missing valid params to start web chat")
                },
                Mu = {
                    url: m.EnvironmentUrls.gamesApi + "/v1/games",
                    withCredentials: !0
                },
                ju = function(e) {
                    return rt.get(Mu, {
                        universeIds: [e]
                    }).then(function(e) {
                        return null === (e = null === (e = null === (e = null == e ? void 0 : e.data) || void 0 === e ? void 0 : e.data) || void 0 === e ? void 0 : e[0]) || void 0 === e ? void 0 : e.rootPlaceId
                    })
                },
                zu = {
                    url: m.EnvironmentUrls.shareLinksApi + "/v1/resolve-link",
                    withCredentials: !0
                },
                Wu = function(e, t) {
                    return rt.post(zu, {
                        linkId: e,
                        linkType: t
                    }).then(function(e) {
                        return e
                    })
                };
            (Bu = mc = mc || {}).PROFILE_SHARE = "ProfileShare", Bu.QR_CODE = "QrCode";
            var Vu, Hu = mc;

            function Qu(e) {
                var t = e.articleId,
                    n = e.locale,
                    r = "https://en.help.roblox.com/hc/";
                return !!(e = n) && /^[a-zA-Z0-9-_]+$/.test(e) ? r += function(e) {
                    var t = {
                        "zh-cn": "zh-cn",
                        zh_cn: "zh-cn",
                        "zh-cjv": "zh-cn",
                        zh_cjv: "zh-cn",
                        "zh-hans": "zh-cn",
                        zh_hans: "zh-cn",
                        "zh-tw": "zh-tw",
                        zh_tw: "zh-tw",
                        "zh-hant": "zh-tw",
                        zh_hant: "zh-tw",
                        "en-us": "en-us",
                        en_us: "en-us",
                        en: "en-us",
                        "en-gb": "en-gb",
                        en_gb: "en-gb",
                        "fr-ca": "fr-ca",
                        fr_ca: "fr-ca",
                        nb: "no",
                        "nb-no": "no",
                        nb_no: "no"
                    };
                    if (t[e]) return t[e];
                    e = e.split(/[^a-zA-Z0-9]/).filter(Boolean);
                    return e[0] || "en"
                }(n) : r += "en-us", !!(n = t) && /^[a-zA-Z0-9]+$/.test(n) && (r += "/articles/" + t), r
            }(mc = Vu = Vu || {}).AVATAR_ITEM_DETAILS = "AvatarItemDetails", mc.EXPERIENCE_INVITE = "ExperienceInvite", mc.EXPERIENCE_AFFILIATE = "ExperienceAffiliate", mc.FRIEND_INVITE = "FriendInvite", mc.NOTIFICATION_EXPERIENCE_INVITE = "NotificationExperienceInvite", mc.PROFILE = "Profile", mc.SCREENSHOT_INVITE = "ScreenshotInvite", mc.SERVER = "Server", mc.EXPERIENCE_DETAILS = "ExperienceDetails", (mc = sc = sc || {}).VALID = "Valid", mc.EXPIRED = "Expired", mc.INVITER_NOT_IN_EXPERIENCE = "InviterNotInExperience";
            var Ku = sc;
            (mc = oc = oc || {}).VALID = "Valid", mc.EXPIRED = "Expired", mc.CONSUMED = "Consumed", mc.SENDER_BLOCKED_RECIPIENT = "SenderBlockedRecipient", mc.INVALID = "Invalid";
            var Xu = oc;
            (sc = hc = hc || {}).VALID = "Valid", sc.SENDER_BLOCKED_RECIPIENT = "SenderBlockedRecipient", sc.INVALID = "Invalid";
            var Ju = hc;
            (mc = ac = ac || {}).VALID = "Valid", mc.EXPIRED = "Expired", mc.INVITER_NOT_IN_EXPERIENCE = "InviterNotInExperience";
            var Yu = ac;
            (oc = ic = ic || {}).INVALID = "Invalid", oc.VALID = "Valid", oc.EXPIRED = "Expired";
            var $u = ic;
            (sc = Nc = Nc || {}).INVALID = "Invalid", sc.EXPIRED = "Expired", sc.VALID = "Valid";
            var Zu = Nc;
            (dc = dc || {}).Zendesk = "zendesk";
            var ec = dc;
            (hc = fc = fc || {}).INVALID = "Invalid", hc.EXPIRED = "Expired", hc.VALID = "Valid";
            var tc = fc;
            (mc = zc = zc || {}).INVALID = "Invalid", mc.VALID = "Valid";
            var nc = zc;

            function rc(e) {
                for (var t = [], n = {}, r = cc.exec(e); r;) t.push(r[1]), r = cc.exec(e);
                for (var a = lc.exec(e); a;) {
                    var o = a[1],
                        i = a[2];
                    n[o] = i, a = lc.exec(e)
                }
                return {
                    path: t,
                    params: n
                }
            }
            var ac = function(e) {
                    var t = e.path,
                        r = e.params,
                        e = t[1];
                    if (mu[e]) {
                        i = mu[e];
                        for (var n = Object.keys(r), a = 0; a < n.length; a++) var o = n[a],
                            i = i.replace("{" + o + "}", r[o])
                    } else if (t = r, e === Xs.ItemDetails && t.itemType && t.itemId) i = fu[r.itemType] + "/" + r.itemId;
                    else {
                        if (e === Xs.GameDetails && r.gameId) return ju(r.gameId).then(function(e) {
                            return !!e && (window.location.href = gu.Games + "/" + e, !0)
                        }).catch(function() {
                            return !1
                        });
                        if (e === Xs.Profile) r.userId ? i = gu.Users + "/" + r.userId + gu.Profile : r.groupId && (i = gu.Groups + "/" + r.groupId);
                        else if (e === Xs.GiftCards) i = "" + gu.GiftCards;
                        else if (e === Xs.ShareLinks) switch (r.type) {
                            case Vu.EXPERIENCE_INVITE:
                                if (r.code) return Wu(r.code, Vu.EXPERIENCE_INVITE).then(function(e) {
                                    var t = null === (n = null == e ? void 0 : e.data) || void 0 === n ? void 0 : n.experienceInviteData;
                                    if (!t || !t.placeId) return !1;
                                    var n, e = su(t.status, r.code, Vu.EXPERIENCE_INVITE);
                                    return Ae.sendEventWithTarget(e.type, e.context, e.params), t.status === Ku.VALID && t.instanceId ? (window.location.href = gu.Games + "/" + t.placeId, Nu.launchGame(Nu.buildPlayGameProperties(t.placeId, t.placeId, t.instanceId, void 0, void 0, t.inviterId), (n = t.placeId.toString(), e = r.code, {
                                        eventName: "joinGameFromInviteLink",
                                        ctx: "shareLinks",
                                        gamePlayIntentEventCtx: "shareLinks",
                                        properties: {
                                            linkStatus: t.status,
                                            linkType: "ExperienceInvite",
                                            placeId: n,
                                            linkId: e
                                        }
                                    })), !0) : (t.status === Ku.EXPIRED || t.status === Ku.INVITER_NOT_IN_EXPERIENCE) && (window.location.href = gu.Games + "/" + t.placeId + "?experienceInviteLinkId=" + r.code + "&experienceInviteStatus=" + t.status, !0)
                                }).catch(function() {
                                    return (0, Su.fireEvent)(yu), !1
                                });
                                break;
                            case Vu.NOTIFICATION_EXPERIENCE_INVITE:
                                if (r.code) return Wu(r.code, Vu.NOTIFICATION_EXPERIENCE_INVITE).then(function(e) {
                                    e = null === (t = null == e ? void 0 : e.data) || void 0 === t ? void 0 : t.notificationExperienceInviteData;
                                    if (null != e && e.placeId) {
                                        var t = e.instanceId && e.status === Ku.VALID,
                                            t = gu.ExperienceLauncher + "placeId=" + e.placeId + (e.launchData ? "&launchData=" + encodeURIComponent(encodeURIComponent(e.launchData)) : "") + (t ? "&gameInstanceId=" + e.instanceId : "");
                                        return m.ProtocolHandlerClientInterface.startGameWithDeepLinkUrl(t, e.placeId), !0
                                    }
                                    return !1
                                }).catch(function() {
                                    return (0, Su.fireEvent)(bu), !1
                                });
                                break;
                            case Vu.FRIEND_INVITE:
                                if (r.code) return Wu(r.code, Vu.FRIEND_INVITE).then(function(e) {
                                    e = null === (t = null == e ? void 0 : e.data) || void 0 === t ? void 0 : t.friendInviteData;
                                    if (!e || !e.senderUserId) return !1;
                                    var t = su(e.status, r.code, Vu.FRIEND_INVITE);
                                    return Ae.sendEventWithTarget(t.type, t.context, t.params), (e.status === Xu.VALID || e.status === Xu.CONSUMED || e.status === Xu.EXPIRED) && (window.location.href = gu.Users + "/" + e.senderUserId + gu.Profile, !0)
                                }).catch(function() {
                                    return (0, Su.fireEvent)(Pu), !1
                                });
                                break;
                            case Vu.PROFILE:
                                if (r.code) return Wu(r.code, Vu.PROFILE).then(function(e) {
                                    e = null === (t = null == e ? void 0 : e.data) || void 0 === t ? void 0 : t.profileLinkResolutionResponseData;
                                    if (!e || !e.userId) return !1;
                                    var t = su(e.status, r.code, Vu.PROFILE);
                                    if (Ae.sendEventWithTarget(t.type, t.context, t.params), e.status !== Ju.VALID) return !1;
                                    t = function(e) {
                                        switch (null == e ? void 0 : e.toLowerCase()) {
                                            case Hu.PROFILE_SHARE.toLowerCase():
                                                return Hu.PROFILE_SHARE;
                                            case Hu.QR_CODE.toLowerCase():
                                            default:
                                                return Hu.QR_CODE
                                        }
                                    }(ru.getQueryParam("source"));
                                    return window.location.href = gu.Users + "/" + e.userId + gu.Profile + "?friendshipSourceType=" + t, !0
                                }).catch(function() {
                                    return (0, Su.fireEvent)(Gu), !1
                                });
                                break;
                            case Vu.SCREENSHOT_INVITE:
                                if (r.code) return Wu(r.code, Vu.SCREENSHOT_INVITE).then(function(e) {
                                    e = null === (t = null == e ? void 0 : e.data) || void 0 === t ? void 0 : t.screenshotInviteData;
                                    if (null == e || !e.placeId || ![Yu.EXPIRED, Yu.INVITER_NOT_IN_EXPERIENCE, Yu.VALID].includes(e.status)) return !1;
                                    var t = su(e.status, r.code, Vu.SCREENSHOT_INVITE);
                                    if (Ae.sendEventWithTarget(t.type, t.context, t.params), e.status === Yu.EXPIRED || e.status === Yu.INVITER_NOT_IN_EXPERIENCE) return window.location.href = gu.Games + "/" + e.placeId + "?experienceInviteLinkId=" + r.code + "&experienceInviteStatus=" + e.status, !0;
                                    t = gu.ExperienceLauncher + "placeId=" + e.placeId;
                                    return e.launchData && (t += "&launchData=" + encodeURIComponent(encodeURIComponent(e.launchData))), e.instanceId && (t += "&gameInstanceId=" + e.instanceId), m.ProtocolHandlerClientInterface.startGameWithDeepLinkUrl(t, e.placeId), !0
                                }).catch(function() {
                                    return (0, Su.fireEvent)(wu), !1
                                });
                                break;
                            case Vu.SERVER:
                                if (r.code) return Wu(r.code, Vu.SERVER).then(function(e) {
                                    var n = null === (e = null == e ? void 0 : e.data) || void 0 === e ? void 0 : e.privateServerInviteData;
                                    return !!(n && n.universeId && [$u.VALID, $u.EXPIRED].includes(n.status)) && (ju(n.universeId.toString()).then(function(e) {
                                        if (!e) return !1;
                                        var t = su(n.status, r.code, Vu.SERVER);
                                        return Ae.sendEventWithTarget(t.type, t.context, t.params), window.location.href = gu.Games + "/" + e + "?privateServerLinkCode=" + n.linkCode, !0
                                    }).catch(function() {
                                        return !1
                                    }), !0)
                                }).catch(function() {
                                    return (0, Su.fireEvent)(Cu), !1
                                });
                                break;
                            case Vu.EXPERIENCE_AFFILIATE:
                                if (!r.code) break;
                                return Wu(r.code, Vu.EXPERIENCE_AFFILIATE).then(function(e) {
                                    var n = null === (e = null == e ? void 0 : e.data) || void 0 === e ? void 0 : e.experienceAffiliateData;
                                    return !(!n || !n.universeId || n.status !== nc.VALID) && ju(n.universeId.toString()).then(function(e) {
                                        if (!e) return !1;
                                        var t = su(n.status, r.code, Vu.EXPERIENCE_AFFILIATE);
                                        Ae.sendEventWithTarget(t.type, t.context, t.params);
                                        t = window.location.protocol + "//" + window.location.hostname + window.location.pathname + "?type=" + Vu.EXPERIENCE_AFFILIATE + "&code=" + r.code;
                                        return window.location.href = gu.Games + "/" + e + "?shareLinkSourceType=" + Vu.EXPERIENCE_AFFILIATE + "&referralUrl=" + encodeURIComponent(t), !0
                                    }).catch(function() {
                                        return !1
                                    })
                                }).catch(function() {
                                    return (0, Su.fireEvent)(Tu), !1
                                });
                            case Vu.EXPERIENCE_DETAILS:
                                if (!r.code) break;
                                return Wu(r.code, Vu.EXPERIENCE_DETAILS).then(function(e) {
                                    var n = null === (e = null == e ? void 0 : e.data) || void 0 === e ? void 0 : e.experienceDetailsInviteData;
                                    return !(!n || !n.universeId || n.status !== Zu.VALID) && ju(n.universeId.toString()).then(function(e) {
                                        if (!e) return !1;
                                        var t = su(n.status, r.code, Vu.EXPERIENCE_DETAILS);
                                        return Ae.sendEventWithTarget(t.type, t.context, t.params), window.location.href = gu.Games + "/" + e + "?shareLinkSourceType=" + Vu.EXPERIENCE_DETAILS, !0
                                    }).catch(function() {
                                        return !1
                                    })
                                }).catch(function() {
                                    return (0, Su.fireEvent)(Tu), !1
                                });
                            case Vu.AVATAR_ITEM_DETAILS:
                                if (!r.code) break;
                                return Wu(r.code, Vu.AVATAR_ITEM_DETAILS).then(function(e) {
                                    var t = null === (n = null == e ? void 0 : e.data) || void 0 === n ? void 0 : n.avatarItemDetailsData;
                                    if (!(t && t.itemId && "" !== t.itemId && "0" !== t.itemId && t.itemType && t.itemType in gu && t.status === tc.VALID)) return !1;
                                    var e = t.itemType,
                                        n = su(t.status, r.code, Vu.AVATAR_ITEM_DETAILS);
                                    return Ae.sendEventWithTarget(n.type, n.context, n.params), window.location.href = gu[e] + "/" + t.itemId + "?pid=share&is_retargeting=true&deep_link_value=" + r.code, !0
                                }).catch(function() {
                                    return (0, Su.fireEvent)(Au), !1
                                })
                        } else {
                            if (e === Xs.Chat && r.userId) return ku(r), Promise.resolve(!0);
                            if (e === Xs.ExternalWebUrl) {
                                e = void 0;
                                return r.domain === ec.Zendesk && (e = Qu(r)) && window.open(e, "_blank"), Promise.resolve(!!e)
                            }
                        }
                    }
                    return i ? window.location.href = i : (0, Su.fireEvent)(Iu), Promise.resolve(!!i)
                },
                oc = function(e) {
                    var t = e.params;
                    return t.placeId ? (t.linkCode ? window.location.href = gu.Games + "/" + t.placeId + "?privateServerLinkCode=" + t.linkCode : t.accessCode ? window.location.href = gu.GameStart + "?placeId=" + t.placeId + "&accessCode=" + t.accessCode : t.launchData ? (e = gu.ExperienceLauncher + "placeId=" + t.placeId + (t.launchData ? "&launchData=" + t.launchData : ""), m.ProtocolHandlerClientInterface.startGameWithDeepLinkUrl(e, Number(t.placeId))) : m.GameLauncher.joinMultiplayerGame(parseFloat(t.placeId), !0, !1), Promise.resolve(!0)) : Promise.resolve(!1)
                },
                ic = function(e) {
                    e = e.params.userId;
                    return e && (window.location.href = "/games/start?userId=" + e), Promise.resolve(!!e)
                },
                sc = function(e) {
                    e = e.params.groupId;
                    return e && (window.location.href = "/groups/" + e), Promise.resolve(!!e)
                },
                uc = ((Nc = {})[Xs.Navigation] = ac, Nc[Xs.PlaceId] = oc, Nc[Xs.UserId] = ic, Nc[Xs.Group] = sc, Nc),
                cc = /\/(\w+)/g,
                lc = /(\w+)=([^&=]+)/g,
                dc = {
                    parseDeeplink: rc,
                    navigateToDeepLink: function(e) {
                        var t;
                        if (m.DeviceMeta && (0, m.DeviceMeta)().isIosApp && m.Hybrid) return null !== (t = m.Hybrid.Navigation) && void 0 !== t && t.navigateToFeature(((n = {}).feature = "DeepLink", n.deepLinkUrlPath = e, n), function() {
                            return !0
                        }), Promise.resolve(!0);
                        if (m.DeviceMeta && (0, m.DeviceMeta)().isInApp) return window.location.href = e, Promise.resolve(!0);
                        var n = rc(e),
                            e = uc[n.path[0]];
                        return e ? e(n) : Promise.resolve(!1)
                    }
                },
                hc = {
                    AvatarItemDetailsStatus: tc,
                    ExperienceInviteStatus: Ku,
                    FriendInviteStatus: Xu,
                    ProfileShareStatus: Ju,
                    PrivateServerLinkStatus: $u,
                    ExperienceAffiliateStatus: nc
                };

            function vc(e) {
                return e.replace(/\+/g, "-").replace(/\//g, "_").replace(/=/g, "")
            }

            function pc(e) {
                var t = e.length % 4 ? 4 - e.length % 4 : 0;
                return e.replace(/-/g, "+").replace(/_/g, "/") + "=".repeat(t)
            }
            Object.assign(g(), {
                DeepLinkService: dc,
                ShareLinksType: Vu,
                ShareLinks: hc
            });
            var fc = dc,
                mc = {
                    base64StringToBase64UrlString: vc,
                    base64UrlStringToBase64String: pc,
                    convertPublicKeyParametersToStandardBase64: function(e) {
                        var t = JSON.parse(e);
                        if (t.publicKey.challenge = pc(t.publicKey.challenge), t.publicKey.user && t.publicKey.user.id && (t.publicKey.user.id = pc(t.publicKey.user.id)), t.publicKey.allowCredentials)
                            for (var n = 0; n < t.publicKey.allowCredentials.length; n++) t.publicKey.allowCredentials[n].id = pc(t.publicKey.allowCredentials[n].id);
                        if (t.publicKey.excludeCredentials)
                            for (n = 0; n < t.publicKey.excludeCredentials.length; n++) t.publicKey.excludeCredentials[n].id = pc(t.publicKey.excludeCredentials[n].id);
                        return t
                    },
                    formatCredentialAuthenticationResponseApp: function(e) {
                        var t = JSON.parse(e),
                            e = {
                                id: vc(t.id),
                                type: t.type,
                                response: {
                                    authenticatorData: vc(t.response.authenticatorData),
                                    clientDataJSON: vc(t.response.clientDataJSON)
                                }
                            };
                        return "rawId" in t && (e.rawId = vc(t.rawId)), "signature" in t.response && (e.response.signature = vc(t.response.signature)), "userHandle" in t.response && (e.response.userHandle = vc(t.response.userHandle)), JSON.stringify(e)
                    },
                    formatCredentialRegistrationResponseApp: function(e) {
                        e = JSON.parse(e);
                        return void 0 !== e.rawId ? JSON.stringify({
                            authenticatorAttachment: e.authenticatorAttachment,
                            id: vc(e.id),
                            type: e.type,
                            rawId: vc(e.rawId),
                            response: {
                                attestationObject: vc(e.response.attestationObject),
                                clientDataJSON: vc(e.response.clientDataJSON)
                            }
                        }) : JSON.stringify({
                            authenticatorAttachment: e.authenticatorAttachment,
                            id: vc(e.id),
                            type: e.type,
                            response: {
                                attestationObject: vc(e.response.attestationObject),
                                clientDataJSON: vc(e.response.clientDataJSON)
                            }
                        })
                    },
                    formatCredentialRequestWeb: function(e) {
                        var t = JSON.parse(e);
                        if (t.publicKey.challenge = Pt.base64StringToArrayBuffer(t.publicKey.challenge), t.publicKey.allowCredentials)
                            for (var n = 0; n < t.publicKey.allowCredentials.length; n++) t.publicKey.allowCredentials[n].id = Pt.base64StringToArrayBuffer(t.publicKey.allowCredentials[n].id);
                        if (t.publicKey.user && t.publicKey.user.id && (t.publicKey.user.id = Pt.base64StringToArrayBuffer(t.publicKey.user.id)), t.publicKey.excludeCredentials)
                            for (n = 0; n < t.publicKey.excludeCredentials.length; n++) t.publicKey.excludeCredentials[n].id = Pt.base64StringToArrayBuffer(t.publicKey.excludeCredentials[n].id);
                        return t.publicKey
                    },
                    formatCredentialAuthenticationResponseWeb: function(e) {
                        var t = e.response,
                            n = new Uint8Array(t.authenticatorData),
                            r = new Uint8Array(t.clientDataJSON),
                            a = new Uint8Array(e.rawId),
                            o = new Uint8Array(t.signature),
                            t = new Uint8Array(t.userHandle),
                            t = {
                                id: e.id,
                                rawId: vc(Pt.arrayBufferToBase64String(a)),
                                type: e.type,
                                response: {
                                    authenticatorData: vc(Pt.arrayBufferToBase64String(n)),
                                    clientDataJSON: vc(Pt.arrayBufferToBase64String(r)),
                                    signature: vc(Pt.arrayBufferToBase64String(o)),
                                    userHandle: vc(Pt.arrayBufferToBase64String(t))
                                }
                            };
                        return JSON.stringify(t)
                    },
                    formatCredentialRegistrationResponseWeb: function(e) {
                        var t = e.response,
                            n = new Uint8Array(t.attestationObject),
                            r = new Uint8Array(t.clientDataJSON),
                            t = new Uint8Array(e.rawId);
                        return JSON.stringify({
                            authenticatorAttachment: e.authenticatorAttachment,
                            id: e.id,
                            rawId: vc(Pt.arrayBufferToBase64String(t)),
                            type: e.type,
                            response: {
                                attestationObject: vc(Pt.arrayBufferToBase64String(n)),
                                clientDataJSON: vc(Pt.arrayBufferToBase64String(r))
                            }
                        })
                    }
                },
                gc = (zc = m.Hybrid || {}).Chat,
                Ic = zc.Navigation,
                yc = zc.Overlay,
                bc = zc.Game,
                Pc = zc.Localization;

            function Gc(e) {
                return void 0 === e ? function() {} : e
            }
            var ac = {
                    startChatConversation: function(e, t) {
                        gc && gc.startChatConversation(e, Gc(t))
                    },
                    startWebChatConversation: function(e, t) {
                        Ic && Ic.startWebChatConversation(e, Gc(t))
                    },
                    navigateToFeature: function(e, t) {
                        Ic && Ic.navigateToFeature(e, Gc(t))
                    },
                    openUserProfile: function(e, t) {
                        Ic && Ic.openUserProfile(e, Gc(t))
                    },
                    close: function(e) {
                        yc && yc.close(Gc(e))
                    },
                    launchGame: function(e, t) {
                        bc && bc.launchGame(e, Gc(t))
                    },
                    localization: function(e, t) {
                        Pc && Pc.languageChangeTrigger && Pc.languageChangeTrigger(e, Gc(t))
                    }
                },
                wc = function() {
                    return (wc = Object.assign || function(e) {
                        for (var t, n = 1, r = arguments.length; n < r; n++)
                            for (var a in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
                        return e
                    }).apply(this, arguments)
                };
            (oc = Vc = Vc || {}).GET_CREDENTIALS = "getCredentials", oc.REGISTER_CREDENTIALS = "registerCredentials", oc.CREDENTIALS_PROTOCOL_AVAILABLE = "credentialsProtocolAvailable", oc.GET_INTEGRITY_TOKEN = "getIntegrityToken";
            var Cc, Tc = {},
                Ac = {},
                Sc = 0,
                ic = {
                    FeatureTarget: Vc,
                    injectNativeResponse: function(e, t) {
                        void 0 !== Ac[e] && Ac[e](String(t))
                    },
                    getNativeResponse: function(e, t, n) {
                        var r, a = Sc += 1;
                        return Tc[a] = new Promise(function(t) {
                            Ac[a] = function(e) {
                                t(e), delete Tc[a], delete Ac[a]
                            }
                        }), m.Hybrid && m.Hybrid.Navigation && m.Hybrid.Navigation.navigateToFeature({
                            feature: e,
                            data: wc({
                                callId: a
                            }, t)
                        }, function() {
                            return console.log("Hybrid Response Service: ", "Sent native request:", e)
                        }), Promise.race([(r = n, new Promise(function(e) {
                            return setTimeout(function() {
                                return e(null)
                            }, r)
                        })), Tc[a]])
                    }
                },
                Rc = (m.CurrentUser || {}).userId,
                Ec = {
                    friends: "Friends",
                    followers: "Followers",
                    requests: "Requests",
                    followings: "Followings"
                },
                Lc = {
                    friendsDict: function(e) {
                        return "Roblox.".concat(Ec[e], "Dict.UserId").concat(Rc || 0)
                    }
                };
            (Cc = Cc || {}).EventTracker = "eventTracker";
            var Uc, qc, Oc, Dc, xc, _c, Bc, sc = {
                    getEventTracker: function() {
                        return function(e) {
                            try {
                                var t = window.sessionStorage.getItem(e) || "{}",
                                    t = JSON.parse(t);
                                if (t.constructor === Object) return t
                            } catch (e) {}
                            return {}
                        }(Cc.EventTracker)
                    }
                },
                Fc = m.EnvironmentUrls.metricsApi,
                Nc = function() {
                    var e = document.getElementsByName("performance")[0];
                    return e ? {
                        performanceMetricsBatchWaitTime: function(e) {
                            if (!e) return 0;
                            e = e.split(":");
                            return 1e3 * (60 * parseInt(e[0], 10) * 60 + 60 * parseInt(e[1], 10) + parseInt(e[2], 10))
                        }(e.getAttribute("data-ui-performance-metrics-batch-wait-time")),
                        performanceMetricsBatchSize: parseInt(e.getAttribute("data-ui-performance-metrics-batch-size"), 10)
                    } : {}
                },
                kc = function() {
                    return (kc = Object.assign || function(e) {
                        for (var t, n = 1, r = arguments.length; n < r; n++)
                            for (var a in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
                        return e
                    }).apply(this, arguments)
                },
                Mc = function(e, t) {
                    var n = {};
                    for (a in e) Object.prototype.hasOwnProperty.call(e, a) && t.indexOf(a) < 0 && (n[a] = e[a]);
                    if (null != e && "function" == typeof Object.getOwnPropertySymbols)
                        for (var r = 0, a = Object.getOwnPropertySymbols(e); r < a.length; r++) t.indexOf(a[r]) < 0 && Object.prototype.propertyIsEnumerable.call(e, a[r]) && (n[a[r]] = e[a[r]]);
                    return n
                },
                hc = new f,
                jc = 0,
                zc = (dc = Nc()).performanceMetricsBatchWaitTime,
                oc = dc.performanceMetricsBatchSize,
                Wc = hc.createRequestProcessor(function(e) {
                    var t = {
                            url: Fc + "/v1/performance/measurements",
                            retryable: !0,
                            withCredentials: !0
                        },
                        n = e.map(function(e) {
                            e = e.data, e.taskId, e = Mc(e, ["taskId"]);
                            return kc({}, e)
                        });
                    return rt.post(t, n).then(function() {
                        var t = {};
                        return e.forEach(function(e) {
                            e = e.key;
                            t[e] = !0
                        }), t
                    })
                }, function(e) {
                    e = e.taskId;
                    return null == e ? void 0 : e.toString()
                }, {
                    batchSize: oc || 100,
                    processBatchWaitTime: zc || 1e4
                }),
                Vc = {
                    logMeasurement: function(e) {
                        var t = jc;
                        return jc += 1, Wc.queueItem(kc({
                            taskId: t
                        }, e))
                    }
                },
                Hc = "RBXPaymentsFlowContext",
                Qc = new RegExp("^(?:.*; |)" + Hc + "=([^,]+),([^;]+)(?:;.*|)$");
            (f = Uc = Uc || {}).USER_PURCHASE_FLOW = "UserPurchaseFlow", f.USER_PURCHASE_STATUS = "UserPurchaseStatus", (Nc = qc = qc || {}).WEB_ROBUX_PURCHASE = "WebRobuxPurchase", Nc.WEB_PREMIUM_PURCHASE = "WebPremiumPurchase", Nc.WEB_CATALOG_ROBUX_UPSELL = "WebCatalogRobuxUpsell", Nc.WEB_CATALOG_PREMIUM_UPSELL = "WebCatalogPremiumUpsell", Nc.WEB_CATALOG_COLLECTIVE_ITEM_ROBUX_UPSELL = "WebCatalogCollectiveItemRobuxUpsell", Nc.WEB_CATALOG_BUNDLE_ITEM_ROBUX_UPSELL = "WebCatalogBundleItemRobuxUpsell", Nc.WEB_PAID_GAME_ROBUX_UPSELL = "WebPaidGameRobuxUpsell", Nc.WEB_GAME_PASS_ROBUX_UPSELL = "WebGamePassRobuxUpsell", Nc.WEB_PRIVATE_SERVER_ROBUX_UPSELL = "WebPrivateServerRobuxUpsell", Nc.WEB_CATALOG_CART_ROBUX_UPSELL = "WebCatalogCartRobuxUpsell", Nc.WEBVIEW_ROBUX_PURCHASE = "WebViewRobuxPurchase", Nc.WEBVIEW_PREMIUM_PURCHASE = "WebViewPremiumPurchase", (dc = Oc = Oc || {}).ROBUX_UPSELL = "RobuxUpsell", dc.ROBUX_UPSELL_EXCEED_LARGEST_PACKAGE = "RobuxUpsellExceedLargestPackage", dc.PURCHASE_WARNING = "PurchaseWarning", dc.LEAVE_ROBLOX_WARNING = "LeaveRobloxWarning", dc.PREMIUM_DISCLOSURES = "PremiumDisclosures", dc.PRODUCT_PURCHASE = "ProductPurchase", dc.PRODUCT_PURCHASE_ONE_CLICK_PAY = "ProductPurchaseOneClickPay", dc.PREMIUM_PURCHASE = "PremiumPurchase", dc.MEMBERSHIP = "Membership", dc.MEMBERSHIP_ANGULAR = "MembershipAngular", dc.PREMIUM_UPSELL = "PremiumUpsell", dc.PAYMENT_METHOD = "PaymentMethod", dc.NAVIGATION_MENU = "NavigationMenu", dc.PREPARE_PAYMENT_ERROR_OCCURED = "PreparePaymentErrorOccured", dc.XSOLLA = "Xsolla", dc.XSOLLA_OTHER = "Xsolla Other", dc.XSOLLA_SAVED_PAYMENT_METHOD = "Xsolla SavedCard", dc.PAYPAL_POST_PROCESS = "Paypal Post Process", dc.BRAINTREE_POST_PROCESS = "Braintree Post Process", dc.ROBLOX_CREDIT = "Roblox Credit", dc.ROBLOX_CREDIT_CAPTCHA = "Roblox Credit Captcha", dc.LOADING = "Loading", dc.CHECKOUT_SUCCESS = "Checkout Success", dc.SUCCESS = "Success", dc.ERROR = "Error", dc.NAVIGATION_ROBUX_TEXT = "NavigationRobuxText", dc.NAVIGATION_DROPDOWN_MENU = "NavigationDropdownMenu", dc.LEFT_NAVIGATION_BAR = "LeftNavigationBar", dc.TRANSACTION_PAGE = "TransactionPage", dc.CATALOG_LIST_PAGE = "CatalogListPage", dc.ROBLOX_CREDIT_SETTING_BILLING_PAGE = "RobloxCreditBillingPage", dc.REDEEM_PAGE = "RedeemPage", (hc = Dc = Dc || {}).VIEW_SHOWN = "ViewShown", hc.USER_INPUT = "UserInput", (oc = xc = xc || {}).SUBMIT_ORDER = "Submit Order", oc.REDEEM = "Redeem", oc.BUY_ROBUX = "Buy Robux", oc.BUY_ROBUX_AND_ITEM = "Buy Robux and Item", oc.BUY_GIFT_CARD = "Buy Gift Card", oc.CONTINUE_TO_CASHSTAR = "Continue to Cashstar", oc.CONTINUE_TO_VNG = "Continue to Vng", oc.EXTERNAL_LINK_MODAL = "External Link Modal", oc.CANCEL = "Cancel", oc.CONTINUE = "Continue", oc.BACK = "Back", oc.CARD_NUMBER_FORM = "Card Number Form", oc.PAY_NOW = "Pay Now", oc.PROCEED_TO_CHECKOUT = "Proceed to Checkout", oc.SEND_RECEIPT_TO_EMAIL = "Send receipt to email", oc.OPEN_EXTERNAL_LINK = "External Link", oc.PAYMENT_METHOD_LIST = "Other payment method list", oc.GIFT_CARD = "Gift Card", oc.OK = "OK", oc.PREMIUM = "Premium", oc.GET_PREMIUM = "Get Premium", oc.GO_TO_ROBUX_STORE = "Go To Robux Store", oc.U13_PAYMENT_MODAL = "U13PaymentModal", oc.U13_PARENTAL_CONSENT_WARNING = "U13ParentalConsentWarning", oc.PAYMENT_MODAL_13_TO_17 = "PaymentModal13To17", oc.U13_MONTHLY_THRESHOLD_1_MODAL = "U13MonthlyThreshold1Modal", oc.U13_MONTHLY_THRESHOLD_2_MODAL = "U13MonthlyThreshold2Modal", oc.REQUIRE_EMAIL_VERIFICATION = "RequireEmailVerification", oc.PURCHASE = "PURCHASE", oc.REQUIRE_TWO_STEP_VERIFICATION = "RequireTwoStepVerification", oc.ROBUX_ICON = "Robux Icon", oc.PAGE_REFRESHED = "PageRefreshed", oc.BACK_FORWARD_DETECTED = "Back/Forward Triggered", oc.PAGE_LOADED_FROM_BACK_FORWARD_CACHE = "Back/Forward Triggered & Loaded From Cache", oc.GO_TO_ROBUX_PURCHASE_PAGE = "Go to Robux Purchase Page", oc.BILLING_EMAIL_NOT_PREFILLED = "Billing Email Not Prefilled", oc.CREDIT_CONVERSION = "Credit Conversion", (zc = _c = _c || {}).ABANDONED = "Abandoned", zc.FAILED_PRECHECK = "FailedPrecheck", zc.EXISTING_FLOW_OVERWRITTEN_BY = "ExistingFlowOverwrittenBy", zc.PAYMENT_FLOW_STARTED = "PaymentFlowStarted", zc.BROWSER_PAGE_CHANGED = "BrowserPageChanged", zc.CAPTCHA = "Captcha", zc.SUCCESS = "Success", zc.ERROR = "Error", zc.CONTINUE = "Continue", zc.CANCEL = "Cancel", (f = Bc = Bc || {}).GAME_PASS = "Game Pass", f.PRIVATE_SERVER = "Private Server", f.BUNDLE = "Bundle", f.PACKAGE = "Package", f.PLACE = "Place";
            var Kc, Xc, Jc = {
                WRONG_USAGE_OF_METHOD: (Nc = "UserPaymentFlow") + "WrongUsageOfMethod",
                PRE_LOADED_FROM_COOKIE: Nc + "PreLoadedFromCookie",
                EXISTING_FLOW_OVERWRITTEN_TRIGGERED: Nc + "ExistingFlowOverwrittenTriggered",
                NEW_FLOW_INITIATED_PREFIX: Nc + "NewFlowInitiatedFor",
                WRONG_DATA_IN_COOKIE: Nc + "WrongDataInCookie",
                STATUS_EVENT_TRIGGERED_WITHOUT_CTX: Nc + "StatusEventTriggeredWithoutCtx",
                MID_PURCHASE_STEP_TRIGGERED_WITHOUT_VALID_REFERRER: Nc + "MidPurchaseStepTriggeredWithoutValidReferrer",
                MID_PURCHASE_STEP_TRIGGERED_WITH_REFRESH: Nc + "MidPurchaseStepTriggeredWithRefresh",
                MID_PURCHASE_STEP_TRIGGERED_WITHOUT_VALID_CTX: Nc + "MidPurchaseStepTriggeredWithoutCtx",
                SEND_EVENT_WITHOUT_UUID_OR_CTX: Nc + "SendEventWithoutUuidOrCtx",
                FLOW_ABANDONED_DETECTED: Nc + "FlowAbandoned",
                PAGE_REFRESHED: Nc + "PageRefreshed",
                BACK_FORWARD_DETECTED: Nc + "BackForwardDetected",
                PAGE_LOADED_FROM_BACK_FORWARD_CACHE: Nc + "BackForwardDetectedLoadedFromCache",
                LOAD_PRE_EXISTING_CTX_ERROR: Nc + "LoadPreExistingCtxError",
                SEND_STATUS_EVENT_ERROR: Nc + "SendStatusEventError",
                SEND_USER_EVENT_ERROR: Nc + "SendUserEventError",
                START_FLOW_ERROR: Nc + "StartFlowError",
                EVENTS_REGISTER_ERROR: Nc + "EventsRegisterError",
                PERFORMANCE_NAVIGATION_TYPE_ERROR: Nc + "PerformanceNavigationTypeError"
            };

            function Yc(e, t) {
                this.purchaseFlowUuid = e, this.triggeringContext = t
            }(dc = Kc = Kc || {}).FLOW_CONTINUE = "payment-user-journey:continue", dc.FLOW_REFERRER_VALID = "payment-user-journey:referrer-valid", (hc = Xc = Xc || {}).NAVIGATE = "navigate", hc.RELOAD = "reload", hc.BACK_FORWARD = "back_forward";
            var $c = (Yc.prototype.save = function() {
                    var e = this.purchaseFlowUuid + "," + this.triggeringContext;
                    document.cookie = Hc + "=" + e + "; domain=." + m.EnvironmentUrls.domain + "; path=/; max-age=7200"
                }, Yc.stop = function() {
                    document.cookie = Hc + "=; domain=." + m.EnvironmentUrls.domain + "; path=/; max-age=0"
                }, Yc.loadFromCookie = function() {
                    var e = Qc.exec(document.cookie);
                    return Qc.lastIndex = 0, !Array.isArray(e) || e.length < 3 ? null : new Yc(e[1], e[2])
                }, Yc),
                Zc = "#header li a.robux-menu-btn",
                el = "display-price-container",
                tl = "#item-details #upgrade-button",
                nl = "#item-details .premium-prompt a",
                rl = function() {
                    return (rl = Object.assign || function(e) {
                        for (var t, n = 1, r = arguments.length; n < r; n++)
                            for (var a in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
                        return e
                    }).apply(this, arguments)
                };

            function al() {
                this.purchaseFlowUuid = void 0, this.triggerContext = void 0, this.ENUM_TRIGGERING_CONTEXT = qc, this.ENUM_VIEW_NAME = Oc, this.ENUM_PURCHASE_EVENT_TYPE = Dc, this.ENUM_VIEW_MESSAGE = xc, this.ENUM_PURCHASE_STATUS = _c, this.ENUM_CUSTOM_EVENT = Kc, this.isFlowAbandoned = !0, this.isPageRefreshed = !1, this.isReferrerValid = !1, this.loadPreExistingCtx(), this.setupEventListeners()
            }
            var ol, oc = new(al.prototype.startPaymentFlow = function(e) {
                try {
                    this.startPaymentFlowOrThrow(e)
                } catch (e) {
                    (0, Su.fireEvent)(Jc.START_FLOW_ERROR)
                }
            }, al.prototype.startPaymentFlowOrThrow = function(e) {
                var t = Fu();
                this.purchaseFlowUuid && (this.sendUserPurchaseStatusEvent(e, _c.EXISTING_FLOW_OVERWRITTEN_BY, t), (0, Su.fireEvent)(Jc.EXISTING_FLOW_OVERWRITTEN_TRIGGERED)), this.purchaseFlowUuid = t, this.triggerContext = e, this.writePaymentFlowContextIntoCookie(), this.sendUserPurchaseStatusEvent(e, _c.PAYMENT_FLOW_STARTED), (0, Su.fireEvent)(Jc.NEW_FLOW_INITIATED_PREFIX + this.triggerContext)
            }, al.prototype.startRobuxUpsellFlow = function(e, t, n, r) {
                void 0 === t && (t = !1), void 0 === n && (n = !1), void 0 === r && (r = !1), e === Bc.GAME_PASS ? this.startPaymentFlow(qc.WEB_GAME_PASS_ROBUX_UPSELL) : e === Bc.PLACE ? this.startPaymentFlow(qc.WEB_PAID_GAME_ROBUX_UPSELL) : e === Bc.PRIVATE_SERVER ? this.startPaymentFlow(qc.WEB_PRIVATE_SERVER_ROBUX_UPSELL) : e === Bc.BUNDLE || e === Bc.PACKAGE ? this.startPaymentFlow(qc.WEB_CATALOG_BUNDLE_ITEM_ROBUX_UPSELL) : t ? this.startPaymentFlow(qc.WEB_CATALOG_COLLECTIVE_ITEM_ROBUX_UPSELL) : this.startPaymentFlow(qc.WEB_CATALOG_ROBUX_UPSELL)
            }, al.prototype.sendUserPurchaseFlowEvent = function(e, t, n, r, a) {
                void 0 === t && (t = !1);
                try {
                    this.updateFlowContinueStatus(r), this.sendUserPurchaseFlowEventOrThrow(e, t, n, r, a)
                } catch (e) {
                    (0, Su.fireEvent)(Jc.SEND_USER_EVENT_ERROR)
                }
            }, al.prototype.sendUserPurchaseFlowEventOrThrow = function(e, t, n, r, a) {
                if (void 0 === t && (t = !1), n || r || a) return this.purchaseFlowUuid && this.triggerContext ? t ? this.existsValidReferrer() || this.isPageRefreshed || ((0, Su.fireEvent)(Jc.MID_PURCHASE_STEP_TRIGGERED_WITHOUT_VALID_REFERRER), this.startPaymentFlow(e)) : this.startPaymentFlow(e) : (t && (0, Su.fireEvent)(Jc.MID_PURCHASE_STEP_TRIGGERED_WITHOUT_VALID_CTX), this.startPaymentFlow(e)), void this.sendEvent(Uc.USER_PURCHASE_FLOW, n, r, a);
                (0, Su.fireEvent)(Jc.WRONG_USAGE_OF_METHOD)
            }, al.prototype.sendUserPurchaseStatusEvent = function(e, t, n, r) {
                try {
                    this.sendUserPurchaseStatusEventOrThrow(e, t, n, r)
                } catch (e) {
                    (0, Su.fireEvent)(Jc.SEND_STATUS_EVENT_ERROR)
                }
            }, al.prototype.sendUserPurchaseStatusEventOrThrow = function(e, t, n, r) {
                t || n || r ? (this.purchaseFlowUuid && this.triggerContext || ((0, Su.fireEvent)(Jc.STATUS_EVENT_TRIGGERED_WITHOUT_CTX), this.startPaymentFlow(e)), this.sendEvent(Uc.USER_PURCHASE_STATUS, r, void 0, n, t)) : (0, Su.fireEvent)(Jc.WRONG_USAGE_OF_METHOD)
            }, al.prototype.writePaymentFlowContextIntoCookie = function() {
                this.triggerContext && this.purchaseFlowUuid ? new $c(this.purchaseFlowUuid, this.triggerContext).save() : (0, Su.fireEvent)(Jc.WRONG_DATA_IN_COOKIE)
            }, al.prototype.sendEvent = function(e, t, n, r, a, o) {
                void 0 === o && (o = {}), this.purchaseFlowUuid && this.triggerContext ? m.EventStream.SendEventWithTarget(e, this.triggerContext, rl({
                    purchase_flow_uuid: this.purchaseFlowUuid,
                    view_name: t,
                    purchase_event_type: n,
                    view_message: r,
                    status: a
                }, o), m.EventStream.TargetTypes.WWW) : (0, Su.fireEvent)(Jc.SEND_EVENT_WITHOUT_UUID_OR_CTX)
            }, al.prototype.loadPreExistingCtx = function() {
                try {
                    var e = $c.loadFromCookie();
                    e && (this.purchaseFlowUuid = e.purchaseFlowUuid, this.triggerContext = e.triggeringContext)
                } catch (e) {
                    (0, Su.fireEvent)(Jc.LOAD_PRE_EXISTING_CTX_ERROR)
                }
            }, al.prototype.existsValidReferrer = function() {
                var e = new RegExp("^https://[\\w.]*" + m.EnvironmentUrls.domain + "/");
                return document.referrer && e.test(document.referrer.toLowerCase()) || this.isReferrerValid
            }, al.prototype.updateFlowContinueStatus = function(e) {
                this.isFlowAbandoned = e === Dc.VIEW_SHOWN
            }, al.prototype.handleManuallyContinueFlow = function() {
                this.isFlowAbandoned = !1
            }, al.prototype.handleManuallySetReferrerValid = function() {
                this.isReferrerValid = !0
            }, al.wasPageLoadOfType = function(e) {
                try {
                    return window.performance.getEntriesByType ? window.performance.getEntriesByType("navigation").map(function(e) {
                        return e.type
                    }).includes(e) : al.tryDeprecatedPageLoadOfType(e)
                } catch (e) {
                    return (0, Su.fireEvent)(Jc.PERFORMANCE_NAVIGATION_TYPE_ERROR), !1
                }
            }, al.tryDeprecatedPageLoadOfType = function(e) {
                if (!window.performance.navigation) return !1;
                switch (e) {
                    case Xc.BACK_FORWARD:
                        return window.performance.navigation.type === window.performance.navigation.TYPE_BACK_FORWARD;
                    case Xc.NAVIGATE:
                        return window.performance.navigation.type === window.performance.navigation.TYPE_NAVIGATE;
                    case Xc.RELOAD:
                        return window.performance.navigation.type === window.performance.navigation.TYPE_RELOAD;
                    default:
                        return !1
                }
            }, al.prototype.handleRefresh = function() {
                if (this.purchaseFlowUuid) return al.wasPageLoadOfType(Xc.RELOAD) ? (this.isPageRefreshed = !0, this.sendUserPurchaseStatusEvent(this.triggerContext, _c.BROWSER_PAGE_CHANGED, xc.PAGE_REFRESHED), void(0, Su.fireEvent)(Jc.PAGE_REFRESHED)) : void(this.isPageRefreshed = !1)
            }, al.prototype.handleGoBackForward = function(e) {
                this.purchaseFlowUuid && (e.persisted || al.wasPageLoadOfType(Xc.BACK_FORWARD)) && (this.sendUserPurchaseStatusEvent(this.triggerContext, _c.BROWSER_PAGE_CHANGED, e.persisted ? xc.PAGE_LOADED_FROM_BACK_FORWARD_CACHE : xc.BACK_FORWARD_DETECTED), (0, Su.fireEvent)(e.persisted ? Jc.PAGE_LOADED_FROM_BACK_FORWARD_CACHE : Jc.BACK_FORWARD_DETECTED))
            }, al.prototype.handleLeavingThePage = function() {
                this.purchaseFlowUuid && this.isFlowAbandoned && !this.existsValidReferrer() && ($c.stop(), this.sendUserPurchaseStatusEvent(this.triggerContext, _c.ABANDONED), (0, Su.fireEvent)(Jc.FLOW_ABANDONED_DETECTED))
            }, al.prototype.setupEventListeners = function() {
                try {
                    window.addEventListener("load", this.handleRefresh.bind(this)), window.addEventListener("pageshow", this.handleGoBackForward.bind(this)), window.addEventListener("beforeunload", this.handleLeavingThePage.bind(this)), window.addEventListener(Kc.FLOW_CONTINUE, this.handleManuallyContinueFlow.bind(this)), window.addEventListener(Kc.FLOW_REFERRER_VALID, this.handleManuallySetReferrerValid.bind(this))
                } catch (e) {
                    (0, Su.fireEvent)(Jc.EVENTS_REGISTER_ERROR)
                }
            }, al.prototype.dispatchCustomEvent = function(e) {
                window.dispatchEvent(new CustomEvent(e))
            }, al);
            ol = oc, document.addEventListener("DOMContentLoaded", function() {
                var t, n, e;
                t = ol, null !== (e = document.querySelector(Zc)) && void 0 !== e && e.addEventListener("click", function(e) {
                    t.sendUserPurchaseFlowEvent(t.ENUM_TRIGGERING_CONTEXT.WEB_ROBUX_PURCHASE, !1, t.ENUM_VIEW_NAME.NAVIGATION_MENU, t.ENUM_PURCHASE_EVENT_TYPE.USER_INPUT, e.target.innerText)
                }), document.getElementById(el) || (n = ol, null !== (e = document.querySelector(tl)) && void 0 !== e && e.addEventListener("click", function(e) {
                    n.sendUserPurchaseFlowEvent(n.ENUM_TRIGGERING_CONTEXT.WEB_PREMIUM_PURCHASE, !1, n.ENUM_VIEW_NAME.PREMIUM_UPSELL, n.ENUM_PURCHASE_EVENT_TYPE.USER_INPUT, n.ENUM_VIEW_MESSAGE.GET_PREMIUM)
                }), null !== (e = document.querySelector(nl)) && void 0 !== e && e.addEventListener("click", function(e) {
                    n.sendUserPurchaseFlowEvent(n.ENUM_TRIGGERING_CONTEXT.WEB_PREMIUM_PURCHASE, !1, n.ENUM_VIEW_NAME.PREMIUM_UPSELL, n.ENUM_PURCHASE_EVENT_TYPE.USER_INPUT, e.target.innerText)
                }))
            });
            var zc = oc,
                il = m.EnvironmentUrls.friendsApi,
                sl = m.EnvironmentUrls.presenceApi,
                ul = m.EnvironmentUrls.websiteUrl,
                cl = function(e) {
                    return "".concat(ul, "/users/").concat(e, "/profile")
                },
                ll = function() {
                    return "".concat(sl, "/v1/presence/users")
                },
                dl = 100,
                hl = {
                    friends: function(e) {
                        return "".concat(il, "/v1/users/").concat(e, "/friends")
                    },
                    followers: function(e) {
                        return "".concat(il, "/v1/users/").concat(e, "/followers")
                    },
                    followings: function(e) {
                        return "".concat(il, "/v1/users/").concat(e, "/followings")
                    },
                    friendrequests: function() {
                        return "".concat(il, "/v1/my/friends/requests")
                    }
                };

            function vl(r, a, o) {
                var e = {
                        url: hl[a](m.CurrentUser.userId),
                        retryable: !0,
                        withCredentials: !0
                    },
                    t = {
                        url: ll(),
                        retryable: !0,
                        withCredentials: !0
                    };
                return rt.get(e).then(function(e) {
                    var e = e.data.data || e,
                        n = [];
                    return r[a] = {}, e.forEach(function(e) {
                        var t = e.id;
                        n.push(t), e.profileUrl = cl(t), r[a][t] = e
                    }), rt.buildBatchPromises(n, dl, t, !0).then(function(e) {
                        var t, n;
                        return e && 0 < e.length && (t = [], e.forEach(function(e) {
                            e = e.data.userPresences;
                            t = t.concat(e)
                        }), t.forEach(function(e) {
                            r[a][e.userId].presence = e
                        })), o && (_i.saveDataByTimeStamp(Lc.friendsDict(a), r[a]), n = a, document.addEventListener("Roblox.Logout", function() {
                            _i.removeLocalStorage(Lc.friendsDict(n))
                        })), r[a]
                    })
                })
            }

            function pl(e, t, n) {
                var r = n.expirationMS,
                    a = n.isEnabled;
                if (a) {
                    var o = (n = t, r = r, (r = _i.fetchNonExpiredCachedData(Lc.friendsDict(n), r)) ? r.data : null);
                    if (o) return new Promise(function(e) {
                        e(o)
                    })
                }
                return vl(e, t, a)
            }

            function fl(e, t) {
                for (var n = 0; n < t.length; n++) {
                    var r = t[n];
                    r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
                }
            }

            function ml() {}(f = new(function() {
                function t() {
                    ! function(e) {
                        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                    }(this), this.callbacks = new Set, this.friendsDict = {}
                }
                var e, n, r;
                return e = t, (n = [{
                    key: "unSubscribe",
                    value: function(e) {
                        this.callbacks.delete(e)
                    }
                }, {
                    key: "subscribe",
                    value: function(e, a, t) {
                        var o = this,
                            n = "function" == typeof e,
                            i = t && t.isEnabled;
                        n && this.callbacks.add(e), i && this.friendsDict[a] ? n && e(this.friendsDict[a]) : pl(this.friendsDict, a, t).then(function(t) {
                            var n, r;
                            i && (n = a, (r = t) && document.addEventListener("Roblox.Presence.Update", function(e, t) {
                                t && setTimeout(function() {
                                    t.forEach(function(e) {
                                        var t = e.userId;
                                        r[t] && (r[t].presence = e)
                                    }), _i.saveDataByTimeStamp(Lc.friendsDict(n), r)
                                })
                            })), o.friendsDict[a] = t, o.callbacks.forEach(function(e) {
                                e(t)
                            })
                        })
                    }
                }, {
                    key: "refreshCacheData",
                    value: function(e, t) {
                        t = t.isEnabled;
                        return vl(this.friendsDict, e, t)
                    }
                }]) && fl(e.prototype, n), r && fl(e, r), t
            }())).TYPE = {
                FRIENDS: "friends",
                FOLLOWERS: "followers",
                FOLLOWINGS: "followings",
                FRIENDREQUESTS: "friendrequests"
            }, Nc = f, dc = {
                observeVisibility: function(e, t) {
                    var n = e.element,
                        r = e.threshold;
                    try {
                        var a = new IntersectionObserver(function(e) {
                            e = e[0];
                            t(null == e ? void 0 : e.isIntersecting)
                        }, {
                            threshold: r
                        });
                        return a.observe(n),
                            function() {
                                return a.disconnect()
                            }
                    } catch (e) {}
                    return function() {}
                },
                observeChildrenVisibility: function(e, t) {
                    var n = e.elements,
                        r = e.threshold;
                    try {
                        var a = new window.IntersectionObserver(t, {
                            threshold: r
                        });
                        return n.forEach(function(e) {
                                a.observe(e)
                            }),
                            function() {
                                return a.disconnect()
                            }
                    } catch (e) {}
                    return function() {}
                }
            };
            var gl, Il, hc = (ml.prototype.getAbsoluteUrl = function(e) {
                if ("number" != typeof e) return null;
                var t = m.EnvironmentUrls.websiteUrl,
                    e = ru.formatUrl({
                        pathname: this.getRelativePath(e)
                    });
                return ru.resolveUrl(t, e)
            }, ml.prototype.navigateTo = function(e) {
                e = this.getAbsoluteUrl(e);
                e && window.location.assign(e)
            }, ml);

            function yl() {
                return null !== Il && Il.apply(this, arguments) || this
            }
            var bl, Pl, oc = ((gl = function(e, t) {
                return (gl = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
                    })(e, t)
            }, function(e, t) {
                if ("function" != typeof t && null !== t) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");

                function n() {
                    this.constructor = e
                }
                gl(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
            })(yl, Il = hc), yl.prototype.getRelativePath = function(e) {
                return "/games/" + e
            }, yl.prototype.getReferralPath = function() {
                return "/games/refer"
            }, yl);

            function Gl() {
                return null !== Pl && Pl.apply(this, arguments) || this
            }
            var wl, Cl, f = ((bl = function(e, t) {
                return (bl = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
                    })(e, t)
            }, function(e, t) {
                if ("function" != typeof t && null !== t) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");

                function n() {
                    this.constructor = e
                }
                bl(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
            })(Gl, Pl = hc), Gl.prototype.getRelativePath = function(e) {
                return "/groups/" + e
            }, Gl.prototype.getReferralPath = function() {
                return "/groups/refer"
            }, Gl);

            function Tl() {
                return null !== Cl && Cl.apply(this, arguments) || this
            }
            var hc = ((wl = function(e, t) {
                    return (wl = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function(e, t) {
                            e.__proto__ = t
                        } || function(e, t) {
                            for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
                        })(e, t)
                }, function(e, t) {
                    if ("function" != typeof t && null !== t) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");

                    function n() {
                        this.constructor = e
                    }
                    wl(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                })(Tl, Cl = hc), Tl.prototype.getRelativePath = function(e) {
                    return "/users/" + e + "/profile"
                }, Tl.prototype.getReferralPath = function() {
                    return "/users/refer"
                }, Tl),
                oc = {
                    game: new oc,
                    group: new f,
                    user: new hc
                },
                f = jQuery,
                Al = Vl.n(f),
                Sl = function() {
                    return (Sl = Object.assign || function(e) {
                        for (var t, n = 1, r = arguments.length; n < r; n++)
                            for (var a in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
                        return e
                    }).apply(this, arguments)
                },
                Rl = !1,
                hc = function(e) {
                    !e && Rl || (Al().ajaxPrefilter(function(h) {
                        var v = h.error;
                        return h.error = function(t, e, n) {
                            var r = "Generic Challenge:",
                                a = "rblx-challenge-id",
                                o = "rblx-challenge-type",
                                i = "rblx-challenge-metadata",
                                s = t.getAllResponseHeaders(),
                                u = {};
                            s && s.trim().split(/[\r\n]+/).forEach(function(e) {
                                var t = e.split(": "),
                                    e = t.shift(),
                                    t = t.join(": ");
                                u[e] = t
                            });
                            var c = u["rblx-challenge-id"],
                                l = u["rblx-challenge-type"],
                                d = u["rblx-challenge-metadata"],
                                s = void 0 !== c || void 0 !== l || void 0 !== d;
                            if (void 0 !== c && void 0 !== l && void 0 !== d) {
                                if (g() && g().AccountIntegrityChallengeService) return void g().AccountIntegrityChallengeService.Generic.interceptChallenge({
                                    retryRequest: function(e, t) {
                                        var n;
                                        h.headers = Sl(Sl({}, h.headers), ((n = {})[a] = e, n[o] = l, n[i] = t, n)), Al().ajax(h)
                                    },
                                    containerId: "generic-challenge-container",
                                    challengeId: c,
                                    challengeTypeRaw: l,
                                    challengeMetadataJsonBase64: d
                                }).catch(function(e) {
                                    void 0 !== v && v(t, "error", e)
                                });
                                console.error(r, "Got challenge but challenge component not available")
                            } else s && console.error(r, "Got only partial challenge headers");
                            void 0 !== v && v(t, e, n)
                        }, h
                    }), Rl = !0)
                },
                El = "RBXCatalogUpsellData",
                Ll = /RBXCatalogUpsellData=([^;]+)/,
                Ul = "UpsellUuid",
                ql = /^\/[\w-]+\/\d+$/g;

            function Ol() {
                var e = El + "=;path=/;domain=." + m.EnvironmentUrls.domain + ";expires=Thu, 01 Jan 1970 00:00:01 GMT";
                document.cookie.includes(El) && (document.cookie = e)
            }

            function Dl() {
                var e = Ll.exec(document.cookie),
                    t = ru.getQueryParam(Ul);
                if (!Array.isArray(e) || 2 !== e.length || !t) return Ol(), {};
                var n = decodeURIComponent(e[1]).split(",");
                if (8 !== n.length) return Ol(), {};
                var r = n[0],
                    a = n[1],
                    o = n[2],
                    i = n[3],
                    s = n[4],
                    u = n[5],
                    c = n[6] || void 0,
                    e = n[7] || void 0,
                    n = ql.exec(a);
                return ql.lastIndex = 0, t === r && m.CurrentUser.userId === o && n ? {
                    upsellUuid: r,
                    targetItemUrl: a,
                    userId: o,
                    returnUrl: ru.formatUrl({
                        pathname: a,
                        query: ((a = {})[Ul] = r, a)
                    }),
                    expectedCurrency: i,
                    expectedPrice: s,
                    expectedSellerId: u,
                    userAssetId: c,
                    productId: e
                } : (Ol(), {})
            }
            var f = {
                    expireUpsellCookie: Ol,
                    getUpsellUuid: function() {
                        var e = ru.getQueryParam(Ul);
                        if (e || !document.cookie.includes(El)) {
                            if (e && document.cookie.includes(El))
                                if (e !== Dl().upsellUuid) return void Ol();
                            return e
                        }
                        Ol()
                    },
                    parseUpsellCookie: Dl,
                    constants: {
                        UPSELL_COOKIE_KEY: El,
                        UPSELL_COOKIE_KEY_REGEX: Ll,
                        UPSELL_QUERY_PARAM_KEY: Ul,
                        UPSELL_TARGET_ITEM_URL_COOKIE_DATA_REGEX: ql,
                        UPSELL_TARGET_ITEM_URL_REGEX: /^\/[\w-]+\/\d+/g
                    }
                },
                xl = ["click", "dblclick", "focus", "hover", "keypress", "mousedown", "mouseenter", "mouseover", "scroll", "touchmove", "touchstart"],
                _l = 1e3,
                Bl = 6e5,
                Fl = 2e4,
                Nl = 1,
                kl = "/universal-app-configuration/v1/behaviors/page-heartbeat-v2/content",
                Ml = function(e, i, s, u) {
                    return new(s = s || Promise)(function(n, t) {
                        function r(e) {
                            try {
                                o(u.next(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function a(e) {
                            try {
                                o(u.throw(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function o(e) {
                            var t;
                            e.done ? n(e.value) : ((t = e.value) instanceof s ? t : new s(function(e) {
                                e(t)
                            })).then(r, a)
                        }
                        o((u = u.apply(e, i || [])).next())
                    })
                },
                jl = function(n, r) {
                    var a, o, i, s = {
                            label: 0,
                            sent: function() {
                                if (1 & i[0]) throw i[1];
                                return i[1]
                            },
                            trys: [],
                            ops: []
                        },
                        e = {
                            next: t(0),
                            throw: t(1),
                            return: t(2)
                        };
                    return "function" == typeof Symbol && (e[Symbol.iterator] = function() {
                        return this
                    }), e;

                    function t(t) {
                        return function(e) {
                            return function(t) {
                                if (a) throw new TypeError("Generator is already executing.");
                                for (; s;) try {
                                    if (a = 1, o && (i = 2 & t[0] ? o.return : t[0] ? o.throw || ((i = o.return) && i.call(o), 0) : o.next) && !(i = i.call(o, t[1])).done) return i;
                                    switch (o = 0, i && (t = [2 & t[0], i.value]), t[0]) {
                                        case 0:
                                        case 1:
                                            i = t;
                                            break;
                                        case 4:
                                            return s.label++, {
                                                value: t[1],
                                                done: !1
                                            };
                                        case 5:
                                            s.label++, o = t[1], t = [0];
                                            continue;
                                        case 7:
                                            t = s.ops.pop(), s.trys.pop();
                                            continue;
                                        default:
                                            if (!(i = 0 < (i = s.trys).length && i[i.length - 1]) && (6 === t[0] || 2 === t[0])) {
                                                s = 0;
                                                continue
                                            }
                                            if (3 === t[0] && (!i || t[1] > i[0] && t[1] < i[3])) {
                                                s.label = t[1];
                                                break
                                            }
                                            if (6 === t[0] && s.label < i[1]) {
                                                s.label = i[1], i = t;
                                                break
                                            }
                                            if (i && s.label < i[2]) {
                                                s.label = i[2], s.ops.push(t);
                                                break
                                            }
                                            i[2] && s.ops.pop(), s.trys.pop();
                                            continue
                                    }
                                    t = r.call(n, s)
                                } catch (e) {
                                    t = [6, e], o = 0
                                } finally {
                                    a = i = 0
                                }
                                if (5 & t[0]) throw t[1];
                                return {
                                    value: t[0] ? t[1] : void 0,
                                    done: !0
                                }
                            }([t, e])
                        }
                    }
                },
                zl = (Wl.prototype.createWorker = function() {
                    var e = (null !== (e = m.EnvironmentUrls.websiteUrl) && void 0 !== e ? e : "URL_NOT_FOUND") + "/worker-resources/script/?component=PageHeartbeatWorker&?v=" + this.workerVersion;
                    return new Worker(e)
                }, Wl.prototype.onActiveEvent = function() {
                    this.lastActiveTime = new Date
                }, Wl.prototype.start = function() {
                    var e = this;
                    this.isRunning || (this.worker ? this.worker.postMessage(this.heartbeatPulseIntervalMs) : setInterval(function() {
                        return e.onInterval(e, {})
                    }, this.heartbeatPulseIntervalMs), this.isRunning = !0)
                }, Wl.prototype.onInterval = function(e, t) {
                    var n = new Date,
                        n = new Date(n.getTime() - e.activityTimeoutMs);
                    this.lastActiveTime >= n && (g().EventStream.SendEventWithTarget("pageHeartbeat_v2", "heartbeat" + e.heartbeatCount, {}, g().EventStream.TargetTypes.WWW), e.incrementCount())
                }, Wl.prototype.incrementCount = function() {
                    this.heartbeatCount += 1
                }, Wl);

            function Wl(e, t, n) {
                var r = this;
                this.isRunning = !1, this.lastActiveTime = new Date, this.heartbeatCount = 1, this.heartbeatPulseIntervalMs = e, this.activityTimeoutMs = t, this.workerVersion = n, window.Worker ? (this.worker = this.createWorker(), this.worker && (this.worker.onmessage = function(e) {
                    return r.onInterval(r, e)
                })) : this.worker = null
            }
            window.CoreRobloxUtilities = {
                    cryptoUtil: Pt,
                    boundAuthTokensHttpUtil: Ve,
                    dataStores: ie,
                    entityUrl: oc,
                    eventStreamService: Ae,
                    fido2Util: mc,
                    initializeGenericChallengeInterceptor: hc,
                    paymentFlowAnalyticsService: zc,
                    hybridService: ac,
                    hybridResponseService: ic,
                    localStorageService: _i,
                    localStorageNames: Lc,
                    sessionStorageService: sc,
                    playGameService: Nu,
                    userInfoService: Nc,
                    metricsService: Vc,
                    deepLinkService: fc,
                    elementVisibilityService: dc,
                    upsellUtil: f
                },
                function() {
                    var r;
                    return Ml(this, void 0, Promise, function() {
                        var t, n;
                        return jl(this, function(e) {
                            switch (e.label) {
                                case 0:
                                    return [4, function() {
                                        var n;
                                        return Ml(this, void 0, Promise, function() {
                                            var t;
                                            return jl(this, function(e) {
                                                switch (e.label) {
                                                    case 0:
                                                        t = m.EnvironmentUrls.apiGatewayUrl, e.label = 1;
                                                    case 1:
                                                        return e.trys.push([1, 3, , 4]), [4, rt.get({
                                                            url: "" + t + kl
                                                        })];
                                                    case 2:
                                                        return t = e.sent(), (t = null == t ? void 0 : t.data) ? [2, {
                                                            isEnabled: Boolean(t.isEnabled),
                                                            rolloutPermille: null !== (n = t.rolloutPermille) && void 0 !== n ? n : _l,
                                                            activityTimeoutMs: null !== (n = t.activityTimeoutMs) && void 0 !== n ? n : Bl,
                                                            heartbeatPulseIntervalMs: null !== (n = t.heartbeatPulseIntervalMs) && void 0 !== n ? n : Fl,
                                                            workerVersion: null !== (n = t.workerVersion) && void 0 !== n ? n : Nl
                                                        }] : [2, {
                                                            isEnabled: !0,
                                                            rolloutPermille: _l,
                                                            activityTimeoutMs: Bl,
                                                            heartbeatPulseIntervalMs: Fl,
                                                            workerVersion: Nl
                                                        }];
                                                    case 3:
                                                        return e.sent(), [2, {
                                                            isEnabled: !0,
                                                            rolloutPermille: _l,
                                                            activityTimeoutMs: Bl,
                                                            heartbeatPulseIntervalMs: Fl,
                                                            workerVersion: Nl
                                                        }];
                                                    case 4:
                                                        return [2]
                                                }
                                            })
                                        })
                                    }()];
                                case 1:
                                    return (t = e.sent()).isEnabled && null !== (r = g().CurrentUser) && void 0 !== r && r.userId && parseInt(g().CurrentUser.userId, 10) % 1e3 < t.rolloutPermille ? (n = new zl(t.heartbeatPulseIntervalMs, t.activityTimeoutMs, t.workerVersion), xl.forEach(function(e) {
                                        window.addEventListener(e, function() {
                                            n.onActiveEvent()
                                        })
                                    }), n.start(), [2]) : [2]
                            }
                        })
                    })
                }().catch(console.error)
        }()
}();
//# sourceMappingURL=https://js.rbxcdn.com/ea0b594a4a16338443f1be748b517dd8-coreRobloxUtilities.bundle.min.js.map

/* Bundle detector */
window.Roblox && window.Roblox.BundleDetector && window.Roblox.BundleDetector.bundleDetected("CoreRobloxUtilities");