/*! For license information please see realTime.bundle.min.js.LICENSE.txt */ ! function() {
    var e = {
            746: function(e, t, n) {
                var r = {
                    "./events.js": 307,
                    "./options.js": 430
                };

                function o(e) {
                    var t = i(e);
                    return n(t)
                }

                function i(e) {
                    if (!n.o(r, e)) {
                        var t = new Error("Cannot find module '" + e + "'");
                        throw t.code = "MODULE_NOT_FOUND", t
                    }
                    return r[e]
                }
                o.keys = function() {
                    return Object.keys(r)
                }, o.resolve = i, e.exports = o, o.id = 746
            },
            908: function(e, t, n) {
                var r = {
                    "./debugger.js": 132,
                    "./startDebugger.js": 99
                };

                function o(e) {
                    var t = i(e);
                    return n(t)
                }

                function i(e) {
                    if (!n.o(r, e)) {
                        var t = new Error("Cannot find module '" + e + "'");
                        throw t.code = "MODULE_NOT_FOUND", t
                    }
                    return r[e]
                }
                o.keys = function() {
                    return Object.keys(r)
                }, o.resolve = i, e.exports = o, o.id = 908
            },
            348: function(e, t, n) {
                var r = {
                    "./authenticationNotificationsHandler.js": 455
                };

                function o(e) {
                    var t = i(e);
                    return n(t)
                }

                function i(e) {
                    if (!n.o(r, e)) {
                        var t = new Error("Cannot find module '" + e + "'");
                        throw t.code = "MODULE_NOT_FOUND", t
                    }
                    return r[e]
                }
                o.keys = function() {
                    return Object.keys(r)
                }, o.resolve = i, e.exports = o, o.id = 348
            },
            710: function(e, t, n) {
                var r = {
                    "./crossTabReplicatedSource.js": 986,
                    "./hybridSource.js": 944,
                    "./signalRSource.js": 133
                };

                function o(e) {
                    var t = i(e);
                    return n(t)
                }

                function i(e) {
                    if (!n.o(r, e)) {
                        var t = new Error("Cannot find module '" + e + "'");
                        throw t.code = "MODULE_NOT_FOUND", t
                    }
                    return r[e]
                }
                o.keys = function() {
                    return Object.keys(r)
                }, o.resolve = i, e.exports = o, o.id = 710
            },
            104: function(e, t, n) {
                var r = {
                    "./SignalRAbortAsyncPatch-2.2.2.js": 107,
                    "./jquery.signalR-2.2.2.js": 981
                };

                function o(e) {
                    var t = i(e);
                    return n(t)
                }

                function i(e) {
                    if (!n.o(r, e)) {
                        var t = new Error("Cannot find module '" + e + "'");
                        throw t.code = "MODULE_NOT_FOUND", t
                    }
                    return r[e]
                }
                o.keys = function() {
                    return Object.keys(r)
                }, o.resolve = i, e.exports = o, o.id = 104
            },
            794: function(e, t, n) {
                "use strict";

                function r(e) {
                    return (r = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                        return typeof e
                    } : function(e) {
                        return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                    })(e)
                }

                function o(e, t) {
                    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                }

                function i(e, t) {
                    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
                    e.prototype = Object.create(t && t.prototype, {
                        constructor: {
                            value: e,
                            writable: !0,
                            configurable: !0
                        }
                    }), t && f(e, t)
                }

                function a(e) {
                    var t = l();
                    return function() {
                        var n, r = p(e);
                        if (t) {
                            var o = p(this).constructor;
                            n = Reflect.construct(r, arguments, o)
                        } else n = r.apply(this, arguments);
                        return c(this, n)
                    }
                }

                function c(e, t) {
                    return !t || "object" !== r(t) && "function" != typeof t ? function(e) {
                        if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                        return e
                    }(e) : t
                }

                function s(e) {
                    var t = "function" == typeof Map ? new Map : void 0;
                    return (s = function(e) {
                        if (null === e || (n = e, -1 === Function.toString.call(n).indexOf("[native code]"))) return e;
                        var n;
                        if ("function" != typeof e) throw new TypeError("Super expression must either be null or a function");
                        if (void 0 !== t) {
                            if (t.has(e)) return t.get(e);
                            t.set(e, r)
                        }

                        function r() {
                            return u(e, arguments, p(this).constructor)
                        }
                        return r.prototype = Object.create(e.prototype, {
                            constructor: {
                                value: r,
                                enumerable: !1,
                                writable: !0,
                                configurable: !0
                            }
                        }), f(r, e)
                    })(e)
                }

                function u(e, t, n) {
                    return (u = l() ? Reflect.construct : function(e, t, n) {
                        var r = [null];
                        r.push.apply(r, t);
                        var o = new(Function.bind.apply(e, r));
                        return n && f(o, n.prototype), o
                    }).apply(null, arguments)
                }

                function l() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Date.prototype.toString.call(Reflect.construct(Date, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }

                function f(e, t) {
                    return (f = Object.setPrototypeOf || function(e, t) {
                        return e.__proto__ = t, e
                    })(e, t)
                }

                function p(e) {
                    return (p = Object.setPrototypeOf ? Object.getPrototypeOf : function(e) {
                        return e.__proto__ || Object.getPrototypeOf(e)
                    })(e)
                }
                n.d(t, {
                    oo: function() {
                        return d
                    },
                    W5: function() {
                        return h
                    },
                    _L: function() {
                        return g
                    },
                    jQ: function() {
                        return v
                    },
                    mm: function() {
                        return b
                    },
                    oJ: function() {
                        return m
                    },
                    EG: function() {
                        return y
                    },
                    KO: function() {
                        return _
                    }
                });
                var d = function(e) {
                        i(n, e);
                        var t = a(n);

                        function n(e, r) {
                            var i;
                            o(this, n);
                            var a = (this instanceof n ? this.constructor : void 0).prototype;
                            return (i = t.call(this, "".concat(e, ": Status code '").concat(r, "'"))).statusCode = r, i.__proto__ = a, i
                        }
                        return n
                    }(s(Error)),
                    h = function(e) {
                        i(n, e);
                        var t = a(n);

                        function n() {
                            var e, r = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "A timeout occurred.";
                            o(this, n);
                            var i = (this instanceof n ? this.constructor : void 0).prototype;
                            return (e = t.call(this, r)).__proto__ = i, e
                        }
                        return n
                    }(s(Error)),
                    g = function(e) {
                        i(n, e);
                        var t = a(n);

                        function n() {
                            var e, r = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "An abort occurred.";
                            o(this, n);
                            var i = (this instanceof n ? this.constructor : void 0).prototype;
                            return (e = t.call(this, r)).__proto__ = i, e
                        }
                        return n
                    }(s(Error)),
                    v = function(e) {
                        i(n, e);
                        var t = a(n);

                        function n(e, r) {
                            var i;
                            o(this, n);
                            var a = (this instanceof n ? this.constructor : void 0).prototype;
                            return (i = t.call(this, e)).transport = r, i.errorType = "UnsupportedTransportError", i.__proto__ = a, i
                        }
                        return n
                    }(s(Error)),
                    b = function(e) {
                        i(n, e);
                        var t = a(n);

                        function n(e, r) {
                            var i;
                            o(this, n);
                            var a = (this instanceof n ? this.constructor : void 0).prototype;
                            return (i = t.call(this, e)).transport = r, i.errorType = "DisabledTransportError", i.__proto__ = a, i
                        }
                        return n
                    }(s(Error)),
                    m = function(e) {
                        i(n, e);
                        var t = a(n);

                        function n(e, r) {
                            var i;
                            o(this, n);
                            var a = (this instanceof n ? this.constructor : void 0).prototype;
                            return (i = t.call(this, e)).transport = r, i.errorType = "FailedToStartTransportError", i.__proto__ = a, i
                        }
                        return n
                    }(s(Error)),
                    y = function(e) {
                        i(n, e);
                        var t = a(n);

                        function n(e) {
                            var r;
                            o(this, n);
                            var i = (this instanceof n ? this.constructor : void 0).prototype;
                            return (r = t.call(this, e)).errorType = "FailedToNegotiateWithServerError", r.__proto__ = i, r
                        }
                        return n
                    }(s(Error)),
                    _ = function(e) {
                        i(n, e);
                        var t = a(n);

                        function n(e, r) {
                            var i;
                            o(this, n);
                            var a = (this instanceof n ? this.constructor : void 0).prototype;
                            return (i = t.call(this, e)).innerErrors = r, i.__proto__ = a, i
                        }
                        return n
                    }(s(Error))
            },
            55: function(e, t, n) {
                "use strict";
                n.d(t, {
                    R: function() {
                        return w
                    },
                    A: function() {
                        return S
                    }
                });
                var r = n(621),
                    o = n(185);

                function i(e, t) {
                    for (var n = 0; n < t.length; n++) {
                        var r = t[n];
                        r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
                    }
                }
                var a = function() {
                        function e() {
                            ! function(e, t) {
                                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                            }(this, e)
                        }
                        var t, n, a;
                        return t = e, (n = [{
                            key: "writeHandshakeRequest",
                            value: function(e) {
                                return r.d.write(JSON.stringify(e))
                            }
                        }, {
                            key: "parseHandshakeResponse",
                            value: function(e) {
                                var t, n;
                                if ((0, o.eP)(e)) {
                                    var i = new Uint8Array(e),
                                        a = i.indexOf(r.d.RecordSeparatorCode);
                                    if (-1 === a) throw new Error("Message is incomplete.");
                                    var c = a + 1;
                                    t = String.fromCharCode.apply(null, Array.prototype.slice.call(i.slice(0, c))), n = i.byteLength > c ? i.slice(c).buffer : null
                                } else {
                                    var s = e,
                                        u = s.indexOf(r.d.RecordSeparator);
                                    if (-1 === u) throw new Error("Message is incomplete.");
                                    var l = u + 1;
                                    t = s.substring(0, l), n = s.length > l ? s.substring(l) : null
                                }
                                var f = r.d.parse(t),
                                    p = JSON.parse(f[0]);
                                if (p.type) throw new Error("Expected a handshake response from the server.");
                                return [n, p]
                            }
                        }]) && i(t.prototype, n), a && i(t, a), e
                    }(),
                    c = n(794),
                    s = n(350),
                    u = n(798);

                function l(e, t) {
                    var n;
                    if ("undefined" == typeof Symbol || null == e[Symbol.iterator]) {
                        if (Array.isArray(e) || (n = function(e, t) {
                                if (!e) return;
                                if ("string" == typeof e) return f(e, t);
                                var n = Object.prototype.toString.call(e).slice(8, -1);
                                "Object" === n && e.constructor && (n = e.constructor.name);
                                if ("Map" === n || "Set" === n) return Array.from(e);
                                if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return f(e, t)
                            }(e)) || t && e && "number" == typeof e.length) {
                            n && (e = n);
                            var r = 0,
                                o = function() {};
                            return {
                                s: o,
                                n: function() {
                                    return r >= e.length ? {
                                        done: !0
                                    } : {
                                        done: !1,
                                        value: e[r++]
                                    }
                                },
                                e: function(e) {
                                    throw e
                                },
                                f: o
                            }
                        }
                        throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                    }
                    var i, a = !0,
                        c = !1;
                    return {
                        s: function() {
                            n = e[Symbol.iterator]()
                        },
                        n: function() {
                            var e = n.next();
                            return a = e.done, e
                        },
                        e: function(e) {
                            c = !0, i = e
                        },
                        f: function() {
                            try {
                                a || null == n.return || n.return()
                            } finally {
                                if (c) throw i
                            }
                        }
                    }
                }

                function f(e, t) {
                    (null == t || t > e.length) && (t = e.length);
                    for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
                    return r
                }

                function p(e, t) {
                    for (var n = 0; n < t.length; n++) {
                        var r = t[n];
                        r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
                    }
                }
                var d = function() {
                    function e() {
                        ! function(e, t) {
                            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                        }(this, e), this.observers = []
                    }
                    var t, n, r;
                    return t = e, (n = [{
                        key: "next",
                        value: function(e) {
                            var t, n = l(this.observers);
                            try {
                                for (n.s(); !(t = n.n()).done;) t.value.next(e)
                            } catch (e) {
                                n.e(e)
                            } finally {
                                n.f()
                            }
                        }
                    }, {
                        key: "error",
                        value: function(e) {
                            var t, n = l(this.observers);
                            try {
                                for (n.s(); !(t = n.n()).done;) {
                                    var r = t.value;
                                    r.error && r.error(e)
                                }
                            } catch (e) {
                                n.e(e)
                            } finally {
                                n.f()
                            }
                        }
                    }, {
                        key: "complete",
                        value: function() {
                            var e, t = l(this.observers);
                            try {
                                for (t.s(); !(e = t.n()).done;) {
                                    var n = e.value;
                                    n.complete && n.complete()
                                }
                            } catch (e) {
                                t.e(e)
                            } finally {
                                t.f()
                            }
                        }
                    }, {
                        key: "subscribe",
                        value: function(e) {
                            return this.observers.push(e), new o.WQ(this, e)
                        }
                    }]) && p(t.prototype, n), r && p(t, r), e
                }();

                function h(e, t) {
                    var n;
                    if ("undefined" == typeof Symbol || null == e[Symbol.iterator]) {
                        if (Array.isArray(e) || (n = v(e)) || t && e && "number" == typeof e.length) {
                            n && (e = n);
                            var r = 0,
                                o = function() {};
                            return {
                                s: o,
                                n: function() {
                                    return r >= e.length ? {
                                        done: !0
                                    } : {
                                        done: !1,
                                        value: e[r++]
                                    }
                                },
                                e: function(e) {
                                    throw e
                                },
                                f: o
                            }
                        }
                        throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                    }
                    var i, a = !0,
                        c = !1;
                    return {
                        s: function() {
                            n = e[Symbol.iterator]()
                        },
                        n: function() {
                            var e = n.next();
                            return a = e.done, e
                        },
                        e: function(e) {
                            c = !0, i = e
                        },
                        f: function() {
                            try {
                                a || null == n.return || n.return()
                            } finally {
                                if (c) throw i
                            }
                        }
                    }
                }

                function g(e, t) {
                    return function(e) {
                        if (Array.isArray(e)) return e
                    }(e) || function(e, t) {
                        if ("undefined" == typeof Symbol || !(Symbol.iterator in Object(e))) return;
                        var n = [],
                            r = !0,
                            o = !1,
                            i = void 0;
                        try {
                            for (var a, c = e[Symbol.iterator](); !(r = (a = c.next()).done) && (n.push(a.value), !t || n.length !== t); r = !0);
                        } catch (e) {
                            o = !0, i = e
                        } finally {
                            try {
                                r || null == c.return || c.return()
                            } finally {
                                if (o) throw i
                            }
                        }
                        return n
                    }(e, t) || v(e, t) || function() {
                        throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                    }()
                }

                function v(e, t) {
                    if (e) {
                        if ("string" == typeof e) return b(e, t);
                        var n = Object.prototype.toString.call(e).slice(8, -1);
                        return "Object" === n && e.constructor && (n = e.constructor.name), "Map" === n || "Set" === n ? Array.from(e) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? b(e, t) : void 0
                    }
                }

                function b(e, t) {
                    (null == t || t > e.length) && (t = e.length);
                    for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
                    return r
                }

                function m(e, t, n, r, o, i, a) {
                    try {
                        var c = e[i](a),
                            s = c.value
                    } catch (e) {
                        return void n(e)
                    }
                    c.done ? t(s) : Promise.resolve(s).then(r, o)
                }

                function y(e) {
                    return function() {
                        var t = this,
                            n = arguments;
                        return new Promise((function(r, o) {
                            var i = e.apply(t, n);

                            function a(e) {
                                m(i, r, o, a, c, "next", e)
                            }

                            function c(e) {
                                m(i, r, o, a, c, "throw", e)
                            }
                            a(void 0)
                        }))
                    }
                }

                function _(e, t) {
                    for (var n = 0; n < t.length; n++) {
                        var r = t[n];
                        r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
                    }
                }
                var S;
                ! function(e) {
                    e.Disconnected = "Disconnected", e.Connecting = "Connecting", e.Connected = "Connected", e.Disconnecting = "Disconnecting", e.Reconnecting = "Reconnecting"
                }(S || (S = {}));
                var w = function() {
                    function e(t, n, r, i) {
                        var c = this;
                        ! function(e, t) {
                            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                        }(this, e), this._nextKeepAlive = 0, this._freezeEventListener = function() {
                            c._logger.log(u.i.Warning, "The page is being frozen, this will likely lead to the connection being closed and messages being lost. For more information see the docs at https://docs.microsoft.com/aspnet/core/signalr/javascript-client#bsleep")
                        }, o.j7.isRequired(t, "connection"), o.j7.isRequired(n, "logger"), o.j7.isRequired(r, "protocol"), this.serverTimeoutInMilliseconds = 3e4, this.keepAliveIntervalInMilliseconds = 15e3, this._logger = n, this._protocol = r, this.connection = t, this._reconnectPolicy = i, this._handshakeProtocol = new a, this.connection.onreceive = function(e) {
                            return c._processIncomingData(e)
                        }, this.connection.onclose = function(e) {
                            return c._connectionClosed(e)
                        }, this._callbacks = {}, this._methods = {}, this._closedCallbacks = [], this._reconnectingCallbacks = [], this._reconnectedCallbacks = [], this._invocationId = 0, this._receivedHandshakeResponse = !1, this._connectionState = S.Disconnected, this._connectionStarted = !1, this._cachedPingMessage = this._protocol.writeMessage({
                            type: s.C.Ping
                        })
                    }
                    var t, n, r, i, l, f, p, v;
                    return t = e, n = [{
                        key: "start",
                        value: function() {
                            return this._startPromise = this._startWithStateTransitions(), this._startPromise
                        }
                    }, {
                        key: "_startWithStateTransitions",
                        value: (v = y(regeneratorRuntime.mark((function e() {
                            return regeneratorRuntime.wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        if (this._connectionState === S.Disconnected) {
                                            e.next = 2;
                                            break
                                        }
                                        return e.abrupt("return", Promise.reject(new Error("Cannot start a HubConnection that is not in the 'Disconnected' state.")));
                                    case 2:
                                        return this._connectionState = S.Connecting, this._logger.log(u.i.Debug, "Starting HubConnection."), e.prev = 4, e.next = 7, this._startInternal();
                                    case 7:
                                        o.t4.isBrowser && window.document.addEventListener("freeze", this._freezeEventListener), this._connectionState = S.Connected, this._connectionStarted = !0, this._logger.log(u.i.Debug, "HubConnection connected successfully."), e.next = 18;
                                        break;
                                    case 13:
                                        return e.prev = 13, e.t0 = e.catch(4), this._connectionState = S.Disconnected, this._logger.log(u.i.Debug, "HubConnection failed to start successfully because of error '".concat(e.t0, "'.")), e.abrupt("return", Promise.reject(e.t0));
                                    case 18:
                                    case "end":
                                        return e.stop()
                                }
                            }), e, this, [
                                [4, 13]
                            ])
                        }))), function() {
                            return v.apply(this, arguments)
                        })
                    }, {
                        key: "_startInternal",
                        value: (p = y(regeneratorRuntime.mark((function e() {
                            var t, n, r = this;
                            return regeneratorRuntime.wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        return this._stopDuringStartError = void 0, this._receivedHandshakeResponse = !1, t = new Promise((function(e, t) {
                                            r._handshakeResolver = e, r._handshakeRejecter = t
                                        })), e.next = 5, this.connection.start(this._protocol.transferFormat);
                                    case 5:
                                        return e.prev = 5, n = {
                                            protocol: this._protocol.name,
                                            version: this._protocol.version
                                        }, this._logger.log(u.i.Debug, "Sending handshake request."), e.next = 10, this._sendMessage(this._handshakeProtocol.writeHandshakeRequest(n));
                                    case 10:
                                        return this._logger.log(u.i.Information, "Using HubProtocol '".concat(this._protocol.name, "'.")), this._cleanupTimeout(), this._resetTimeoutPeriod(), this._resetKeepAliveInterval(), e.next = 16, t;
                                    case 16:
                                        if (!this._stopDuringStartError) {
                                            e.next = 18;
                                            break
                                        }
                                        throw this._stopDuringStartError;
                                    case 18:
                                        if (this.connection.features.inherentKeepAlive) {
                                            e.next = 21;
                                            break
                                        }
                                        return e.next = 21, this._sendMessage(this._cachedPingMessage);
                                    case 21:
                                        e.next = 31;
                                        break;
                                    case 23:
                                        return e.prev = 23, e.t0 = e.catch(5), this._logger.log(u.i.Debug, "Hub handshake failed with error '".concat(e.t0, "' during start(). Stopping HubConnection.")), this._cleanupTimeout(), this._cleanupPingTimer(), e.next = 30, this.connection.stop(e.t0);
                                    case 30:
                                        throw e.t0;
                                    case 31:
                                    case "end":
                                        return e.stop()
                                }
                            }), e, this, [
                                [5, 23]
                            ])
                        }))), function() {
                            return p.apply(this, arguments)
                        })
                    }, {
                        key: "stop",
                        value: (f = y(regeneratorRuntime.mark((function e() {
                            var t;
                            return regeneratorRuntime.wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        return t = this._startPromise, this._stopPromise = this._stopInternal(), e.next = 4, this._stopPromise;
                                    case 4:
                                        return e.prev = 4, e.next = 7, t;
                                    case 7:
                                        e.next = 11;
                                        break;
                                    case 9:
                                        e.prev = 9, e.t0 = e.catch(4);
                                    case 11:
                                    case "end":
                                        return e.stop()
                                }
                            }), e, this, [
                                [4, 9]
                            ])
                        }))), function() {
                            return f.apply(this, arguments)
                        })
                    }, {
                        key: "_stopInternal",
                        value: function(e) {
                            return this._connectionState === S.Disconnected ? (this._logger.log(u.i.Debug, "Call to HubConnection.stop(".concat(e, ") ignored because it is already in the disconnected state.")), Promise.resolve()) : this._connectionState === S.Disconnecting ? (this._logger.log(u.i.Debug, "Call to HttpConnection.stop(".concat(e, ") ignored because the connection is already in the disconnecting state.")), this._stopPromise) : (this._connectionState = S.Disconnecting, this._logger.log(u.i.Debug, "Stopping HubConnection."), this._reconnectDelayHandle ? (this._logger.log(u.i.Debug, "Connection stopped during reconnect delay. Done reconnecting."), clearTimeout(this._reconnectDelayHandle), this._reconnectDelayHandle = void 0, this._completeClose(), Promise.resolve()) : (this._cleanupTimeout(), this._cleanupPingTimer(), this._stopDuringStartError = e || new c._L("The connection was stopped before the hub handshake could complete."), this.connection.stop(e)))
                        }
                    }, {
                        key: "stream",
                        value: function(e) {
                            for (var t = this, n = arguments.length, r = new Array(n > 1 ? n - 1 : 0), o = 1; o < n; o++) r[o - 1] = arguments[o];
                            var i, a = this._replaceStreamingParams(r),
                                c = g(a, 2),
                                u = c[0],
                                l = c[1],
                                f = this._createStreamInvocation(e, r, l),
                                p = new d;
                            return p.cancelCallback = function() {
                                var e = t._createCancelInvocation(f.invocationId);
                                return delete t._callbacks[f.invocationId], i.then((function() {
                                    return t._sendWithProtocol(e)
                                }))
                            }, this._callbacks[f.invocationId] = function(e, t) {
                                t ? p.error(t) : e && (e.type === s.C.Completion ? e.error ? p.error(new Error(e.error)) : p.complete() : p.next(e.item))
                            }, i = this._sendWithProtocol(f).catch((function(e) {
                                p.error(e), delete t._callbacks[f.invocationId]
                            })), this._launchStreams(u, i), p
                        }
                    }, {
                        key: "_sendMessage",
                        value: function(e) {
                            return this._resetKeepAliveInterval(), this.connection.send(e)
                        }
                    }, {
                        key: "_sendWithProtocol",
                        value: function(e) {
                            return this._sendMessage(this._protocol.writeMessage(e))
                        }
                    }, {
                        key: "send",
                        value: function(e) {
                            for (var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), r = 1; r < t; r++) n[r - 1] = arguments[r];
                            var o = this._replaceStreamingParams(n),
                                i = g(o, 2),
                                a = i[0],
                                c = i[1],
                                s = this._sendWithProtocol(this._createInvocation(e, n, !0, c));
                            return this._launchStreams(a, s), s
                        }
                    }, {
                        key: "invoke",
                        value: function(e) {
                            for (var t = this, n = arguments.length, r = new Array(n > 1 ? n - 1 : 0), o = 1; o < n; o++) r[o - 1] = arguments[o];
                            var i = this._replaceStreamingParams(r),
                                a = g(i, 2),
                                c = a[0],
                                u = a[1],
                                l = this._createInvocation(e, r, !1, u),
                                f = new Promise((function(e, n) {
                                    t._callbacks[l.invocationId] = function(t, r) {
                                        r ? n(r) : t && (t.type === s.C.Completion ? t.error ? n(new Error(t.error)) : e(t.result) : n(new Error("Unexpected message type: ".concat(t.type))))
                                    };
                                    var r = t._sendWithProtocol(l).catch((function(e) {
                                        n(e), delete t._callbacks[l.invocationId]
                                    }));
                                    t._launchStreams(c, r)
                                }));
                            return f
                        }
                    }, {
                        key: "on",
                        value: function(e, t) {
                            e && t && (e = e.toLowerCase(), this._methods[e] || (this._methods[e] = []), -1 === this._methods[e].indexOf(t) && this._methods[e].push(t))
                        }
                    }, {
                        key: "off",
                        value: function(e, t) {
                            if (e) {
                                e = e.toLowerCase();
                                var n = this._methods[e];
                                if (n)
                                    if (t) {
                                        var r = n.indexOf(t); - 1 !== r && (n.splice(r, 1), 0 === n.length && delete this._methods[e])
                                    } else delete this._methods[e]
                            }
                        }
                    }, {
                        key: "onclose",
                        value: function(e) {
                            e && this._closedCallbacks.push(e)
                        }
                    }, {
                        key: "onreconnecting",
                        value: function(e) {
                            e && this._reconnectingCallbacks.push(e)
                        }
                    }, {
                        key: "onreconnected",
                        value: function(e) {
                            e && this._reconnectedCallbacks.push(e)
                        }
                    }, {
                        key: "_processIncomingData",
                        value: function(e) {
                            if (this._cleanupTimeout(), this._receivedHandshakeResponse || (e = this._processHandshakeResponse(e), this._receivedHandshakeResponse = !0), e) {
                                var t, n = h(this._protocol.parseMessages(e, this._logger));
                                try {
                                    for (n.s(); !(t = n.n()).done;) {
                                        var r = t.value;
                                        switch (r.type) {
                                            case s.C.Invocation:
                                                this._invokeClientMethod(r);
                                                break;
                                            case s.C.StreamItem:
                                            case s.C.Completion:
                                                var i = this._callbacks[r.invocationId];
                                                if (i) {
                                                    r.type === s.C.Completion && delete this._callbacks[r.invocationId];
                                                    try {
                                                        i(r)
                                                    } catch (e) {
                                                        this._logger.log(u.i.Error, "Stream callback threw error: ".concat((0, o.HH)(e)))
                                                    }
                                                }
                                                break;
                                            case s.C.Ping:
                                                break;
                                            case s.C.Close:
                                                this._logger.log(u.i.Information, "Close message received from server.");
                                                var a = r.error ? new Error("Server returned an error on close: " + r.error) : void 0;
                                                !0 === r.allowReconnect ? this.connection.stop(a) : this._stopPromise = this._stopInternal(a);
                                                break;
                                            default:
                                                this._logger.log(u.i.Warning, "Invalid message type: ".concat(r.type, "."))
                                        }
                                    }
                                } catch (e) {
                                    n.e(e)
                                } finally {
                                    n.f()
                                }
                            }
                            this._resetTimeoutPeriod()
                        }
                    }, {
                        key: "_processHandshakeResponse",
                        value: function(e) {
                            var t, n;
                            try {
                                var r = g(this._handshakeProtocol.parseHandshakeResponse(e), 2);
                                n = r[0], t = r[1]
                            } catch (e) {
                                var o = "Error parsing handshake response: " + e;
                                this._logger.log(u.i.Error, o);
                                var i = new Error(o);
                                throw this._handshakeRejecter(i), i
                            }
                            if (t.error) {
                                var a = "Server returned handshake error: " + t.error;
                                this._logger.log(u.i.Error, a);
                                var c = new Error(a);
                                throw this._handshakeRejecter(c), c
                            }
                            return this._logger.log(u.i.Debug, "Server handshake complete."), this._handshakeResolver(), n
                        }
                    }, {
                        key: "_resetKeepAliveInterval",
                        value: function() {
                            this.connection.features.inherentKeepAlive || (this._nextKeepAlive = (new Date).getTime() + this.keepAliveIntervalInMilliseconds, this._cleanupPingTimer())
                        }
                    }, {
                        key: "_resetTimeoutPeriod",
                        value: function() {
                            var e = this;
                            if (!(this.connection.features && this.connection.features.inherentKeepAlive || (this._timeoutHandle = setTimeout((function() {
                                    return e.serverTimeout()
                                }), this.serverTimeoutInMilliseconds), void 0 !== this._pingServerHandle))) {
                                var t = this._nextKeepAlive - (new Date).getTime();
                                t < 0 && (t = 0), this._pingServerHandle = setTimeout(y(regeneratorRuntime.mark((function t() {
                                    return regeneratorRuntime.wrap((function(t) {
                                        for (;;) switch (t.prev = t.next) {
                                            case 0:
                                                if (e._connectionState !== S.Connected) {
                                                    t.next = 9;
                                                    break
                                                }
                                                return t.prev = 1, t.next = 4, e._sendMessage(e._cachedPingMessage);
                                            case 4:
                                                t.next = 9;
                                                break;
                                            case 6:
                                                t.prev = 6, t.t0 = t.catch(1), e._cleanupPingTimer();
                                            case 9:
                                            case "end":
                                                return t.stop()
                                        }
                                    }), t, null, [
                                        [1, 6]
                                    ])
                                }))), t)
                            }
                        }
                    }, {
                        key: "serverTimeout",
                        value: function() {
                            this.connection.stop(new Error("Server timeout elapsed without receiving a message from the server."))
                        }
                    }, {
                        key: "_invokeClientMethod",
                        value: (l = y(regeneratorRuntime.mark((function e(t) {
                            var n, r, o, i, a, c, s, l, f, p, d;
                            return regeneratorRuntime.wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        if (n = t.target.toLowerCase(), r = this._methods[n]) {
                                            e.next = 9;
                                            break
                                        }
                                        if (this._logger.log(u.i.Warning, "No client method with the name '".concat(n, "' found.")), !t.invocationId) {
                                            e.next = 8;
                                            break
                                        }
                                        return this._logger.log(u.i.Warning, "No result given for '".concat(n, "' method and invocation ID '").concat(t.invocationId, "'.")), e.next = 8, this._sendWithProtocol(this._createCompletionMessage(t.invocationId, "Client didn't provide a result.", null));
                                    case 8:
                                        return e.abrupt("return");
                                    case 9:
                                        o = r.slice(), i = !!t.invocationId, l = h(o), e.prev = 12, l.s();
                                    case 14:
                                        if ((f = l.n()).done) {
                                            e.next = 31;
                                            break
                                        }
                                        return p = f.value, e.prev = 16, d = a, e.next = 20, p.apply(this, t.arguments);
                                    case 20:
                                        a = e.sent, i && a && d && (this._logger.log(u.i.Error, "Multiple results provided for '".concat(n, "'. Sending error to server.")), s = this._createCompletionMessage(t.invocationId, "Client provided multiple results.", null)), c = void 0, e.next = 29;
                                        break;
                                    case 25:
                                        e.prev = 25, e.t0 = e.catch(16), c = e.t0, this._logger.log(u.i.Error, "A callback for the method '".concat(n, "' threw error '").concat(e.t0, "'."));
                                    case 29:
                                        e.next = 14;
                                        break;
                                    case 31:
                                        e.next = 36;
                                        break;
                                    case 33:
                                        e.prev = 33, e.t1 = e.catch(12), l.e(e.t1);
                                    case 36:
                                        return e.prev = 36, l.f(), e.finish(36);
                                    case 39:
                                        if (!s) {
                                            e.next = 44;
                                            break
                                        }
                                        return e.next = 42, this._sendWithProtocol(s);
                                    case 42:
                                        e.next = 51;
                                        break;
                                    case 44:
                                        if (!i) {
                                            e.next = 50;
                                            break
                                        }
                                        return c ? s = this._createCompletionMessage(t.invocationId, "".concat(c), null) : void 0 !== a ? s = this._createCompletionMessage(t.invocationId, null, a) : (this._logger.log(u.i.Warning, "No result given for '".concat(n, "' method and invocation ID '").concat(t.invocationId, "'.")), s = this._createCompletionMessage(t.invocationId, "Client didn't provide a result.", null)), e.next = 48, this._sendWithProtocol(s);
                                    case 48:
                                        e.next = 51;
                                        break;
                                    case 50:
                                        a && this._logger.log(u.i.Error, "Result given for '".concat(n, "' method but server is not expecting a result."));
                                    case 51:
                                    case "end":
                                        return e.stop()
                                }
                            }), e, this, [
                                [12, 33, 36, 39],
                                [16, 25]
                            ])
                        }))), function(e) {
                            return l.apply(this, arguments)
                        })
                    }, {
                        key: "_connectionClosed",
                        value: function(e) {
                            this._logger.log(u.i.Debug, "HubConnection.connectionClosed(".concat(e, ") called while in state ").concat(this._connectionState, ".")), this._stopDuringStartError = this._stopDuringStartError || e || new c._L("The underlying connection was closed before the hub handshake could complete."), this._handshakeResolver && this._handshakeResolver(), this._cancelCallbacksWithError(e || new Error("Invocation canceled due to the underlying connection being closed.")), this._cleanupTimeout(), this._cleanupPingTimer(), this._connectionState === S.Disconnecting ? this._completeClose(e) : this._connectionState === S.Connected && this._reconnectPolicy ? this._reconnect(e) : this._connectionState === S.Connected && this._completeClose(e)
                        }
                    }, {
                        key: "_completeClose",
                        value: function(e) {
                            var t = this;
                            if (this._connectionStarted) {
                                this._connectionState = S.Disconnected, this._connectionStarted = !1, o.t4.isBrowser && window.document.removeEventListener("freeze", this._freezeEventListener);
                                try {
                                    this._closedCallbacks.forEach((function(n) {
                                        return n.apply(t, [e])
                                    }))
                                } catch (t) {
                                    this._logger.log(u.i.Error, "An onclose callback called with error '".concat(e, "' threw error '").concat(t, "'."))
                                }
                            }
                        }
                    }, {
                        key: "_reconnect",
                        value: (i = y(regeneratorRuntime.mark((function e(t) {
                            var n, r, o, i, a = this;
                            return regeneratorRuntime.wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        if (n = Date.now(), r = 0, o = void 0 !== t ? t : new Error("Attempting to reconnect due to a unknown error."), null !== (i = this._getNextRetryDelay(r++, 0, o))) {
                                            e.next = 8;
                                            break
                                        }
                                        return this._logger.log(u.i.Debug, "Connection not reconnecting because the IRetryPolicy returned null on the first reconnect attempt."), this._completeClose(t), e.abrupt("return");
                                    case 8:
                                        if (this._connectionState = S.Reconnecting, t ? this._logger.log(u.i.Information, "Connection reconnecting because of error '".concat(t, "'.")) : this._logger.log(u.i.Information, "Connection reconnecting."), 0 === this._reconnectingCallbacks.length) {
                                            e.next = 15;
                                            break
                                        }
                                        try {
                                            this._reconnectingCallbacks.forEach((function(e) {
                                                return e.apply(a, [t])
                                            }))
                                        } catch (e) {
                                            this._logger.log(u.i.Error, "An onreconnecting callback called with error '".concat(t, "' threw error '").concat(e, "'."))
                                        }
                                        if (this._connectionState === S.Reconnecting) {
                                            e.next = 15;
                                            break
                                        }
                                        return this._logger.log(u.i.Debug, "Connection left the reconnecting state in onreconnecting callback. Done reconnecting."), e.abrupt("return");
                                    case 15:
                                        if (null === i) {
                                            e.next = 43;
                                            break
                                        }
                                        return this._logger.log(u.i.Information, "Reconnect attempt number ".concat(r, " will start in ").concat(i, " ms.")), e.next = 19, new Promise((function(e) {
                                            a._reconnectDelayHandle = setTimeout(e, i)
                                        }));
                                    case 19:
                                        if (this._reconnectDelayHandle = void 0, this._connectionState === S.Reconnecting) {
                                            e.next = 23;
                                            break
                                        }
                                        return this._logger.log(u.i.Debug, "Connection left the reconnecting state during reconnect delay. Done reconnecting."), e.abrupt("return");
                                    case 23:
                                        return e.prev = 23, e.next = 26, this._startInternal();
                                    case 26:
                                        if (this._connectionState = S.Connected, this._logger.log(u.i.Information, "HubConnection reconnected successfully."), 0 !== this._reconnectedCallbacks.length) try {
                                            this._reconnectedCallbacks.forEach((function(e) {
                                                return e.apply(a, [a.connection.connectionId])
                                            }))
                                        } catch (e) {
                                            this._logger.log(u.i.Error, "An onreconnected callback called with connectionId '".concat(this.connection.connectionId, "; threw error '").concat(e, "'."))
                                        }
                                        return e.abrupt("return");
                                    case 32:
                                        if (e.prev = 32, e.t0 = e.catch(23), this._logger.log(u.i.Information, "Reconnect attempt failed because of error '".concat(e.t0, "'.")), this._connectionState === S.Reconnecting) {
                                            e.next = 39;
                                            break
                                        }
                                        return this._logger.log(u.i.Debug, "Connection moved to the '".concat(this._connectionState, "' from the reconnecting state during reconnect attempt. Done reconnecting.")), this._connectionState === S.Disconnecting && this._completeClose(), e.abrupt("return");
                                    case 39:
                                        o = e.t0 instanceof Error ? e.t0 : new Error(e.t0.toString()), i = this._getNextRetryDelay(r++, Date.now() - n, o);
                                    case 41:
                                        e.next = 15;
                                        break;
                                    case 43:
                                        this._logger.log(u.i.Information, "Reconnect retries have been exhausted after ".concat(Date.now() - n, " ms and ").concat(r, " failed attempts. Connection disconnecting.")), this._completeClose();
                                    case 45:
                                    case "end":
                                        return e.stop()
                                }
                            }), e, this, [
                                [23, 32]
                            ])
                        }))), function(e) {
                            return i.apply(this, arguments)
                        })
                    }, {
                        key: "_getNextRetryDelay",
                        value: function(e, t, n) {
                            try {
                                return this._reconnectPolicy.nextRetryDelayInMilliseconds({
                                    elapsedMilliseconds: t,
                                    previousRetryCount: e,
                                    retryReason: n
                                })
                            } catch (n) {
                                return this._logger.log(u.i.Error, "IRetryPolicy.nextRetryDelayInMilliseconds(".concat(e, ", ").concat(t, ") threw error '").concat(n, "'.")), null
                            }
                        }
                    }, {
                        key: "_cancelCallbacksWithError",
                        value: function(e) {
                            var t = this,
                                n = this._callbacks;
                            this._callbacks = {}, Object.keys(n).forEach((function(r) {
                                var i = n[r];
                                try {
                                    i(null, e)
                                } catch (n) {
                                    t._logger.log(u.i.Error, "Stream 'error' callback called with '".concat(e, "' threw error: ").concat((0, o.HH)(n)))
                                }
                            }))
                        }
                    }, {
                        key: "_cleanupPingTimer",
                        value: function() {
                            this._pingServerHandle && (clearTimeout(this._pingServerHandle), this._pingServerHandle = void 0)
                        }
                    }, {
                        key: "_cleanupTimeout",
                        value: function() {
                            this._timeoutHandle && clearTimeout(this._timeoutHandle)
                        }
                    }, {
                        key: "_createInvocation",
                        value: function(e, t, n, r) {
                            if (n) return 0 !== r.length ? {
                                arguments: t,
                                streamIds: r,
                                target: e,
                                type: s.C.Invocation
                            } : {
                                arguments: t,
                                target: e,
                                type: s.C.Invocation
                            };
                            var o = this._invocationId;
                            return this._invocationId++, 0 !== r.length ? {
                                arguments: t,
                                invocationId: o.toString(),
                                streamIds: r,
                                target: e,
                                type: s.C.Invocation
                            } : {
                                arguments: t,
                                invocationId: o.toString(),
                                target: e,
                                type: s.C.Invocation
                            }
                        }
                    }, {
                        key: "_launchStreams",
                        value: function(e, t) {
                            var n = this;
                            if (0 !== e.length) {
                                t || (t = Promise.resolve());
                                var r = function(r) {
                                    e[r].subscribe({
                                        complete: function() {
                                            t = t.then((function() {
                                                return n._sendWithProtocol(n._createCompletionMessage(r))
                                            }))
                                        },
                                        error: function(e) {
                                            var o;
                                            o = e instanceof Error ? e.message : e && e.toString ? e.toString() : "Unknown error", t = t.then((function() {
                                                return n._sendWithProtocol(n._createCompletionMessage(r, o))
                                            }))
                                        },
                                        next: function(e) {
                                            t = t.then((function() {
                                                return n._sendWithProtocol(n._createStreamItemMessage(r, e))
                                            }))
                                        }
                                    })
                                };
                                for (var o in e) r(o)
                            }
                        }
                    }, {
                        key: "_replaceStreamingParams",
                        value: function(e) {
                            for (var t = [], n = [], r = 0; r < e.length; r++) {
                                var o = e[r];
                                if (this._isObservable(o)) {
                                    var i = this._invocationId;
                                    this._invocationId++, t[i] = o, n.push(i.toString()), e.splice(r, 1)
                                }
                            }
                            return [t, n]
                        }
                    }, {
                        key: "_isObservable",
                        value: function(e) {
                            return e && e.subscribe && "function" == typeof e.subscribe
                        }
                    }, {
                        key: "_createStreamInvocation",
                        value: function(e, t, n) {
                            var r = this._invocationId;
                            return this._invocationId++, 0 !== n.length ? {
                                arguments: t,
                                invocationId: r.toString(),
                                streamIds: n,
                                target: e,
                                type: s.C.StreamInvocation
                            } : {
                                arguments: t,
                                invocationId: r.toString(),
                                target: e,
                                type: s.C.StreamInvocation
                            }
                        }
                    }, {
                        key: "_createCancelInvocation",
                        value: function(e) {
                            return {
                                invocationId: e,
                                type: s.C.CancelInvocation
                            }
                        }
                    }, {
                        key: "_createStreamItemMessage",
                        value: function(e, t) {
                            return {
                                invocationId: e,
                                item: t,
                                type: s.C.StreamItem
                            }
                        }
                    }, {
                        key: "_createCompletionMessage",
                        value: function(e, t, n) {
                            return t ? {
                                error: t,
                                invocationId: e,
                                type: s.C.Completion
                            } : {
                                invocationId: e,
                                result: n,
                                type: s.C.Completion
                            }
                        }
                    }, {
                        key: "state",
                        get: function() {
                            return this._connectionState
                        }
                    }, {
                        key: "connectionId",
                        get: function() {
                            return this.connection && this.connection.connectionId || null
                        }
                    }, {
                        key: "baseUrl",
                        get: function() {
                            return this.connection.baseUrl || ""
                        },
                        set: function(e) {
                            if (this._connectionState !== S.Disconnected && this._connectionState !== S.Reconnecting) throw new Error("The HubConnection must be in the Disconnected or Reconnecting state to change the url.");
                            if (!e) throw new Error("The HubConnection url must be a valid url.");
                            this.connection.baseUrl = e
                        }
                    }], r = [{
                        key: "create",
                        value: function(t, n, r, o) {
                            return new e(t, n, r, o)
                        }
                    }], n && _(t.prototype, n), r && _(t, r), e
                }()
            },
            350: function(e, t, n) {
                "use strict";
                var r;
                n.d(t, {
                        C: function() {
                            return r
                        }
                    }),
                    function(e) {
                        e[e.Invocation = 1] = "Invocation", e[e.StreamItem = 2] = "StreamItem", e[e.Completion = 3] = "Completion", e[e.StreamInvocation = 4] = "StreamInvocation", e[e.CancelInvocation = 5] = "CancelInvocation", e[e.Ping = 6] = "Ping", e[e.Close = 7] = "Close"
                    }(r || (r = {}))
            },
            798: function(e, t, n) {
                "use strict";
                var r;
                n.d(t, {
                        i: function() {
                            return r
                        }
                    }),
                    function(e) {
                        e[e.Trace = 0] = "Trace", e[e.Debug = 1] = "Debug", e[e.Information = 2] = "Information", e[e.Warning = 3] = "Warning", e[e.Error = 4] = "Error", e[e.Critical = 5] = "Critical", e[e.None = 6] = "None"
                    }(r || (r = {}))
            },
            498: function(e, t, n) {
                "use strict";

                function r(e, t) {
                    for (var n = 0; n < t.length; n++) {
                        var r = t[n];
                        r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
                    }
                }
                n.d(t, {
                    W: function() {
                        return o
                    }
                });
                var o = function() {
                    function e() {
                        ! function(e, t) {
                            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                        }(this, e)
                    }
                    var t, n, o;
                    return t = e, (n = [{
                        key: "log",
                        value: function(e, t) {}
                    }]) && r(t.prototype, n), o && r(t, o), e
                }();
                o.instance = new o
            },
            621: function(e, t, n) {
                "use strict";

                function r(e, t) {
                    for (var n = 0; n < t.length; n++) {
                        var r = t[n];
                        r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
                    }
                }
                n.d(t, {
                    d: function() {
                        return o
                    }
                });
                var o = function() {
                    function e() {
                        ! function(e, t) {
                            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                        }(this, e)
                    }
                    var t, n, o;
                    return t = e, o = [{
                        key: "write",
                        value: function(t) {
                            return "".concat(t).concat(e.RecordSeparator)
                        }
                    }, {
                        key: "parse",
                        value: function(t) {
                            if (t[t.length - 1] !== e.RecordSeparator) throw new Error("Message is incomplete.");
                            var n = t.split(e.RecordSeparator);
                            return n.pop(), n
                        }
                    }], (n = null) && r(t.prototype, n), o && r(t, o), e
                }();
                o.RecordSeparatorCode = 30, o.RecordSeparator = String.fromCharCode(o.RecordSeparatorCode)
            },
            185: function(e, t, n) {
                "use strict";
                n.d(t, {
                    j7: function() {
                        return v
                    },
                    t4: function() {
                        return b
                    },
                    o4: function() {
                        return m
                    },
                    eP: function() {
                        return y
                    },
                    bG: function() {
                        return _
                    },
                    hu: function() {
                        return w
                    },
                    WQ: function() {
                        return C
                    },
                    kw: function() {
                        return k
                    },
                    hS: function() {
                        return T
                    },
                    HH: function() {
                        return P
                    },
                    E9: function() {
                        return j
                    }
                });
                var r = n(798),
                    o = n(498);

                function i(e, t) {
                    var n = Object.keys(e);
                    if (Object.getOwnPropertySymbols) {
                        var r = Object.getOwnPropertySymbols(e);
                        t && (r = r.filter((function(t) {
                            return Object.getOwnPropertyDescriptor(e, t).enumerable
                        }))), n.push.apply(n, r)
                    }
                    return n
                }

                function a(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = null != arguments[t] ? arguments[t] : {};
                        t % 2 ? i(Object(n), !0).forEach((function(t) {
                            c(e, t, n[t])
                        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : i(Object(n)).forEach((function(t) {
                            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                        }))
                    }
                    return e
                }

                function c(e, t, n) {
                    return t in e ? Object.defineProperty(e, t, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : e[t] = n, e
                }

                function s(e, t) {
                    return function(e) {
                        if (Array.isArray(e)) return e
                    }(e) || function(e, t) {
                        if ("undefined" == typeof Symbol || !(Symbol.iterator in Object(e))) return;
                        var n = [],
                            r = !0,
                            o = !1,
                            i = void 0;
                        try {
                            for (var a, c = e[Symbol.iterator](); !(r = (a = c.next()).done) && (n.push(a.value), !t || n.length !== t); r = !0);
                        } catch (e) {
                            o = !0, i = e
                        } finally {
                            try {
                                r || null == c.return || c.return()
                            } finally {
                                if (o) throw i
                            }
                        }
                        return n
                    }(e, t) || function(e, t) {
                        if (!e) return;
                        if ("string" == typeof e) return u(e, t);
                        var n = Object.prototype.toString.call(e).slice(8, -1);
                        "Object" === n && e.constructor && (n = e.constructor.name);
                        if ("Map" === n || "Set" === n) return Array.from(e);
                        if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return u(e, t)
                    }(e, t) || function() {
                        throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                    }()
                }

                function u(e, t) {
                    (null == t || t > e.length) && (t = e.length);
                    for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
                    return r
                }

                function l(e, t, n, r, o, i, a) {
                    try {
                        var c = e[i](a),
                            s = c.value
                    } catch (e) {
                        return void n(e)
                    }
                    c.done ? t(s) : Promise.resolve(s).then(r, o)
                }

                function f(e) {
                    return function() {
                        var t = this,
                            n = arguments;
                        return new Promise((function(r, o) {
                            var i = e.apply(t, n);

                            function a(e) {
                                l(i, r, o, a, c, "next", e)
                            }

                            function c(e) {
                                l(i, r, o, a, c, "throw", e)
                            }
                            a(void 0)
                        }))
                    }
                }

                function p(e) {
                    return (p = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                        return typeof e
                    } : function(e) {
                        return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                    })(e)
                }

                function d(e, t) {
                    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                }

                function h(e, t) {
                    for (var n = 0; n < t.length; n++) {
                        var r = t[n];
                        r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
                    }
                }

                function g(e, t, n) {
                    return t && h(e.prototype, t), n && h(e, n), e
                }
                var v = function() {
                        function e() {
                            d(this, e)
                        }
                        return g(e, null, [{
                            key: "isRequired",
                            value: function(e, t) {
                                if (null == e) throw new Error("The '".concat(t, "' argument is required."))
                            }
                        }, {
                            key: "isNotEmpty",
                            value: function(e, t) {
                                if (!e || e.match(/^\s*$/)) throw new Error("The '".concat(t, "' argument should not be empty."))
                            }
                        }, {
                            key: "isIn",
                            value: function(e, t, n) {
                                if (!(e in t)) throw new Error("Unknown ".concat(n, " value: ").concat(e, "."))
                            }
                        }]), e
                    }(),
                    b = function() {
                        function e() {
                            d(this, e)
                        }
                        return g(e, null, [{
                            key: "isBrowser",
                            get: function() {
                                return "object" === ("undefined" == typeof window ? "undefined" : p(window)) && "object" === p(window.document)
                            }
                        }, {
                            key: "isWebWorker",
                            get: function() {
                                return "object" === ("undefined" == typeof self ? "undefined" : p(self)) && "importScripts" in self
                            }
                        }, {
                            key: "isReactNative",
                            get: function() {
                                return "object" === ("undefined" == typeof window ? "undefined" : p(window)) && void 0 === window.document
                            }
                        }, {
                            key: "isNode",
                            get: function() {
                                return !this.isBrowser && !this.isWebWorker && !this.isReactNative
                            }
                        }]), e
                    }();

                function m(e, t) {
                    var n = "";
                    return y(e) ? (n = "Binary data of length ".concat(e.byteLength), t && (n += ". Content: '".concat(function(e) {
                        var t = new Uint8Array(e),
                            n = "";
                        return t.forEach((function(e) {
                            n += "0x".concat(e < 16 ? "0" : "").concat(e.toString(16), " ")
                        })), n.substr(0, n.length - 1)
                    }(e), "'"))) : "string" == typeof e && (n = "String data of length ".concat(e.length), t && (n += ". Content: '".concat(e, "'"))), n
                }

                function y(e) {
                    return e && "undefined" != typeof ArrayBuffer && (e instanceof ArrayBuffer || e.constructor && "ArrayBuffer" === e.constructor.name)
                }

                function _(e, t, n, r, o, i) {
                    return S.apply(this, arguments)
                }

                function S() {
                    return (S = f(regeneratorRuntime.mark((function e(t, n, o, i, c, u) {
                        var l, f, p, d, h, g, v;
                        return regeneratorRuntime.wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return l = {}, f = T(), p = s(f, 2), d = p[0], h = p[1], l[d] = h, t.log(r.i.Trace, "(".concat(n, " transport) sending data. ").concat(m(c, u.logMessageContent), ".")), g = y(c) ? "arraybuffer" : "text", e.next = 7, o.post(i, {
                                        content: c,
                                        headers: a(a({}, l), u.headers),
                                        responseType: g,
                                        timeout: u.timeout,
                                        withCredentials: u.withCredentials
                                    });
                                case 7:
                                    v = e.sent, t.log(r.i.Trace, "(".concat(n, " transport) request complete. Response status: ").concat(v.statusCode, "."));
                                case 9:
                                case "end":
                                    return e.stop()
                            }
                        }), e)
                    })))).apply(this, arguments)
                }

                function w(e) {
                    return void 0 === e ? new k(r.i.Information) : null === e ? o.W.instance : void 0 !== e.log ? e : new k(e)
                }
                var C = function() {
                        function e(t, n) {
                            d(this, e), this._subject = t, this._observer = n
                        }
                        return g(e, [{
                            key: "dispose",
                            value: function() {
                                var e = this._subject.observers.indexOf(this._observer);
                                e > -1 && this._subject.observers.splice(e, 1), 0 === this._subject.observers.length && this._subject.cancelCallback && this._subject.cancelCallback().catch((function(e) {}))
                            }
                        }]), e
                    }(),
                    k = function() {
                        function e(t) {
                            d(this, e), this._minLevel = t, this.out = console
                        }
                        return g(e, [{
                            key: "log",
                            value: function(e, t) {
                                if (e >= this._minLevel) {
                                    var n = "[".concat((new Date).toISOString(), "] ").concat(r.i[e], ": ").concat(t);
                                    switch (e) {
                                        case r.i.Critical:
                                        case r.i.Error:
                                            this.out.error(n);
                                            break;
                                        case r.i.Warning:
                                            this.out.warn(n);
                                            break;
                                        case r.i.Information:
                                            this.out.info(n);
                                            break;
                                        default:
                                            this.out.log(n)
                                    }
                                }
                            }
                        }]), e
                    }();

                function T() {
                    var e = "X-SignalR-User-Agent";
                    return b.isNode && (e = "User-Agent"), [e, E("7.0.4", R(), I(), O())]
                }

                function E(e, t, n, r) {
                    var o = "Microsoft SignalR/",
                        i = e.split(".");
                    return o += "".concat(i[0], ".").concat(i[1]), o += " (".concat(e, "; "), o += t && "" !== t ? "".concat(t, "; ") : "Unknown OS; ", o += "".concat(n), o += r ? "; ".concat(r) : "; Unknown Runtime Version", o += ")"
                }

                function R() {
                    if (!b.isNode) return "";
                    switch (process.platform) {
                        case "win32":
                            return "Windows NT";
                        case "darwin":
                            return "macOS";
                        case "linux":
                            return "Linux";
                        default:
                            return process.platform
                    }
                }

                function O() {
                    if (b.isNode) return process.versions.node
                }

                function I() {
                    return b.isNode ? "NodeJS" : "Browser"
                }

                function P(e) {
                    return e.stack ? e.stack : e.message ? e.message : "".concat(e)
                }

                function j() {
                    if ("undefined" != typeof globalThis) return globalThis;
                    if ("undefined" != typeof self) return self;
                    if ("undefined" != typeof window) return window;
                    if (void 0 !== n.g) return n.g;
                    throw new Error("could not find global")
                }
            },
            544: function(e) {
                function t(e) {
                    return e.replace(/([a-z])([A-Z])/g, "$1-$2").toLowerCase()
                }

                function n(e) {
                    return e.split("/").pop().replace(".html", "")
                }
                var r = {
                    importFilesUnderPath: function(e) {
                        e.keys().forEach(e)
                    },
                    templateCacheGenerator: function(e, r, o, i) {
                        return e.module(r, []).run(["$templateCache", function(e) {
                            o && o.keys().forEach((function(r) {
                                var i = t(n(r));
                                e.put(i, o(r))
                            })), i && i.keys().forEach((function(r) {
                                var o = t(n(r));
                                e.put(o, i(r).replace(/<\/?script[^>]*>/gi, ""))
                            }))
                        }])
                    }
                };
                e.exports = r
            },
            307: function(e, t, n) {
                "use strict";
                n.r(t);
                t.default = {
                    Notification: "Roblox.RealTime.Events.Notification",
                    ConnectionEvent: "Roblox.RealTime.Events.ConnectionEvent",
                    RequestForConnectionStatus: "Roblox.RealTime.Events.RequestForConnectionStatus"
                }
            },
            430: function(e, t, n) {
                "use strict";
                n.r(t), t.default = {
                    hybridSourceDisabled: null
                }
            },
            132: function(e, t, n) {
                "use strict";
                n.r(t);
                var r, o, i = n(283),
                    a = !1,
                    c = [],
                    s = function(e, t) {
                        try {
                            if (console && console.log && console.log("REALTIME DEBUGGER: ".concat(e)), a) {
                                var n = t || "black",
                                    o = new Date,
                                    i = "".concat(o.getHours(), ":").concat(o.getMinutes(), ":").concat(o.getSeconds(), ": ");
                                r.append("<div style='color:".concat(n, "; margin-bottom:2px; border-bottom:1px solid black; font-size: 11px;'>").concat(i).concat(e, "</div>")), r.scrollTop(r[0].scrollHeight)
                            } else c.push(e)
                        } catch (e) {}
                    },
                    u = function() {
                        r.toggle()
                    },
                    l = function() {
                        var e = o.IsConnected();
                        s("SignalrR Connected:".concat(e)), f(e)
                    },
                    f = function(e) {
                        var t = e ? "green" : "red";
                        $("#realtimeDebuggerCheckStatusButton").css("background-color", t)
                    },
                    p = function() {
                        (o = i.Z.GetClient()).SetLogger(s), o.SetVerboseLogging(!0), $((function() {
                            $("body").prepend("<div id='realtimeDebuggerControlPanel' style=' position: fixed; z-index: 2147483647; background-color: #aaaaaa; right: 24px; top: 24px; opacity: 0.9; '><button id='realtimeDebuggerCheckStatusButton'>?</button><button id='realtimeDebuggerToggleLogButton'>+/-</button></div><div id='realtimeDebuggerLog' style='display: none; position: fixed; z-index: 2147483647; background-color: #aaaaaa; right: 24px; top: 44px; opacity: 0.9; height: 70%; width: 70%; overflow-y: scroll;'/>"), r = $("#realtimeDebuggerLog"), a = !0;
                            for (var e = 0; e < c.length; e++) s(c[e]);
                            c = [], $("#realtimeDebuggerCheckStatusButton").click(l), $("#realtimeDebuggerToggleLogButton").click(u), o.Subscribe("ChatNotifications", (function(e) {
                                s(JSON.stringify(e), "darkblue")
                            })), o.SubscribeToConnectionEvents((function() {
                                s("Connection Event: connected"), f(!0)
                            }), (function() {
                                s("Connection Event: reconnected"), f(!0)
                            }), (function() {
                                s("Connection Event: disconnected"), f(!1)
                            }), "ChatNotifications"), l()
                        }))
                    };
                t.default = {
                    debuggerInit: p
                }
            },
            99: function(e, t, n) {
                "use strict";
                n.r(t);
                var r = n(792),
                    o = n(132);
                $((function() {
                    r.RealTimeSettings && "True" === r.RealTimeSettings.IsDebuggerEnabled && o.default.debuggerInit()
                }))
            },
            455: function(e, t, n) {
                "use strict";
                n.r(t);
                var r = n(792),
                    o = n(283);
                $((function() {
                    o.Z.GetClient().Subscribe("AuthenticationNotifications", (function(e) {
                        if ("SignOut" === e.Type) {
                            var t = "/authentication/is-logged-in";
                            r.Endpoints && (t = r.Endpoints.generateAbsoluteUrl(t, null, !0)), $.ajax({
                                url: t,
                                method: "GET",
                                error: function(e) {
                                    401 === e.status && window.location.reload()
                                }
                            })
                        }
                    }))
                }))
            },
            52: function(e, t, n) {
                "use strict";
                var r = n(792),
                    o = n(283),
                    i = n(764),
                    a = n(511);
                t.Z = function(e) {
                    var t = null,
                        n = {},
                        c = {},
                        s = {},
                        u = {},
                        l = {},
                        f = [],
                        p = null,
                        d = !1,
                        h = function(e, t) {
                            e = "RealTime Client: ".concat(e), t && !d || p && p(e)
                        },
                        g = null,
                        v = function r() {
                            t && (h("Stopping current source: ".concat(t.Name)), t.Stop(), t = null, function() {
                                if (n.constructor === Object && Object.keys(n).length > 0)
                                    for (var e in n) n[e].isConnected && (n[e].isConnected = !1, k(e))
                            }());
                            for (var i = o.Z.GetSettings(), a = 0; a < e.length; a++) {
                                var c = new e[a](i, h);
                                if (h("Attempting to start a new source: ".concat(c.Name)), c.Start(r, (function(e) {
                                        b(c, e)
                                    }), (function(e) {
                                        S(c, e)
                                    }))) {
                                    h("New source started: ".concat(c.Name)), t = c;
                                    break
                                }
                            }
                            null === t && h("No source can be started!")
                        },
                        b = function(e, n) {
                            if (e === t) {
                                var r = n.namespace,
                                    i = n.detail;
                                if (o.Z.GetSettings().isRealtimeWebAnalyticsEnabled) try {
                                    var s = JSON.stringify(n.detail).length;
                                    a.Z.maybeSendEventToDataLake(r, i, s)
                                } catch (e) {
                                    h("Error sending realtime event to datalake for notification [".concat(r, "]:").concat(e))
                                }
                                var u = c[r];
                                if (u)
                                    for (var l = 0; l < u.length; l++) try {
                                        u[l](i)
                                    } catch (e) {
                                        h("Error running subscribed event handler for notification [".concat(r, "]:").concat(e))
                                    }
                                g && g.UpdateSequenceNumber(r, n.namespaceSequenceNumber)
                            }
                        },
                        m = function(e) {
                            if (!e) {
                                var t = !1;
                                for (var r in n) n[r] && n[r].isConnected && (t = !0);
                                return {
                                    isConnected: t
                                }
                            }
                            return n[e] || (n[e] = {
                                isConnected: !1,
                                hasEverBeenConnected: !1
                            }), n[e]
                        },
                        y = function(e, n) {
                            var o = g ? g.IsDataRefreshRequired(e, n) : null,
                                i = m(e);
                            if (i.isConnected && o === g.RefreshRequiredEnum.IS_REQUIRED && (h("Have detected messages were missed. Triggering reconnect logic. Data Reload Required: ".concat(o)), i.isConnected = !1, k(e)), !i.isConnected)
                                if (i.isConnected = !0, i.hasEverBeenConnected) C(null === o || o === g.RefreshRequiredEnum.IS_REQUIRED || o === g.RefreshRequiredEnum.UNCLEAR, e);
                                else {
                                    var a = o !== g.RefreshRequiredEnum.NOT_REQUIRED;
                                    if (i.hasEverBeenConnected = !0, r.Performance) {
                                        var c = "signalR_".concat(t.Name, "_connected");
                                        r.Performance.logSinglePerformanceMark(c)
                                    }
                                    w(a, e)
                                }
                        },
                        _ = function(e) {
                            var t = m(e);
                            t.isConnected && (t.isConnected = !1, k(e))
                        },
                        S = function(e, r) {
                            if (e === t)
                                if (r.isConnected) {
                                    if (T(), r.namespace) {
                                        var o = r.namespace,
                                            i = r.namespaceSequenceNumber;
                                        y(o, i)
                                    } else if (r.namespaceSequenceNumbersObj)
                                        for (var o in r.namespaceSequenceNumbersObj) {
                                            i = r.namespaceSequenceNumbersObj[o];
                                            y(o, i)
                                        }
                                } else if (r.namespace) {
                                o = r.namespace;
                                _(o)
                            } else if (r.namespaceSequenceNumbersObj)
                                for (var o in r.namespaceSequenceNumbersObj) _(o);
                            else
                                for (var o in n) _(o)
                        },
                        w = function(e, t) {
                            if (h("Client Connected!"), t) try {
                                if (s[t])
                                    for (r = 0; r < s[t].length; r++) s[t][r](e)
                            } catch (e) {
                                h("Error running subscribed event handler for connected:".concat(e))
                            } else
                                for (var n in s) try {
                                    if (s[n])
                                        for (var r = 0; r < s[n].length; r++) s[n][r](e)
                                } catch (e) {
                                    h("Error running subscribed event handler for connected:".concat(e))
                                }
                        },
                        C = function(e, t) {
                            if (h("Client Reconnected! Data Reload Required: ".concat(e)), t) try {
                                if (l[t])
                                    for (r = 0; l[t].length > 0; r++) l[t][r](e)
                            } catch (e) {
                                h("Error running subscribed event handler for reconnected:".concat(e))
                            } else
                                for (var n in l) try {
                                    if (l[n])
                                        for (var r = 0; l[n].length > 0; r++) l[n][r](e)
                                } catch (e) {
                                    h("Error running subscribed event handler for reconnected:".concat(e))
                                }
                        },
                        k = function(e) {
                            if (h("Client Disconnected!"), e) try {
                                if (u[e])
                                    for (n = 0; u[e].length > 0; n++) u[e][n]()
                            } catch (e) {
                                h("Error running subscribed event handler for disconnected:".concat(e))
                            } else
                                for (var t in u) try {
                                    if (u[t])
                                        for (var n = 0; u[t].length > 0; n++) u[t][n]()
                                } catch (e) {
                                    h("Error running subscribed event handler for disconnected:".concat(e))
                                }
                        },
                        T = function() {
                            f.forEach((function(e) {
                                e()
                            }))
                        };
                    i.Z && (g = new i.Z(o.Z.IsLocalStorageEnabled(), o.Z.IsEventPublishingEnabled())), v(), r.Performance && r.Performance.setPerformanceMark("signalR_initialized"), this.Subscribe = function(e, t) {
                        c[e] || (c[e] = []), c[e].push(t)
                    }, this.Unsubscribe = function(e, t) {
                        if (c[e]) {
                            var n = c[e],
                                r = n.indexOf(t);
                            r >= 0 && n.splice(r, 1)
                        }
                    }, this.SubscribeToConnectionEvents = function(e, t, n, r) {
                        if (!r) return !1;
                        e && (s[r] || (s[r] = []), s[r].push(e)), t && (l[r] || (l[r] = []), l[r].push(t)), n && (u[r] || (u[r] = []), u[r].push(n))
                    }, this.DetectSignalConnection = function(e) {
                        f.push(e)
                    }, this.IsConnected = function(e) {
                        return m(e).isConnected
                    }, this.SetLogger = function(e) {
                        p = e
                    }, this.SetVerboseLogging = function(e) {
                        d = e
                    }
                }
            },
            269: function(e, t, n) {
                "use strict";
                n.d(t, {
                    Z: function() {
                        return ct
                    }
                });
                var r = n(792);

                function o(e) {
                    return function(e) {
                        if (Array.isArray(e)) return i(e)
                    }(e) || function(e) {
                        if ("undefined" != typeof Symbol && Symbol.iterator in Object(e)) return Array.from(e)
                    }(e) || function(e, t) {
                        if (!e) return;
                        if ("string" == typeof e) return i(e, t);
                        var n = Object.prototype.toString.call(e).slice(8, -1);
                        "Object" === n && e.constructor && (n = e.constructor.name);
                        if ("Map" === n || "Set" === n) return Array.from(e);
                        if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return i(e, t)
                    }(e) || function() {
                        throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                    }()
                }

                function i(e, t) {
                    (null == t || t > e.length) && (t = e.length);
                    for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
                    return r
                }

                function a(e, t) {
                    for (var n = 0; n < t.length; n++) {
                        var r = t[n];
                        r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
                    }
                }
                var c = [0, 2e3, 1e4, 3e4, null],
                    s = function() {
                        function e(t) {
                            ! function(e, t) {
                                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                            }(this, e), this._retryDelays = void 0 !== t ? [].concat(o(t), [null]) : c
                        }
                        var t, n, r;
                        return t = e, (n = [{
                            key: "nextRetryDelayInMilliseconds",
                            value: function(e) {
                                return this._retryDelays[e.previousRetryCount]
                            }
                        }]) && a(t.prototype, n), r && a(t, r), e
                    }();
                var u = function e() {
                    ! function(e, t) {
                        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                    }(this, e)
                };

                function l(e, t) {
                    var n = Object.keys(e);
                    if (Object.getOwnPropertySymbols) {
                        var r = Object.getOwnPropertySymbols(e);
                        t && (r = r.filter((function(t) {
                            return Object.getOwnPropertyDescriptor(e, t).enumerable
                        }))), n.push.apply(n, r)
                    }
                    return n
                }

                function f(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = null != arguments[t] ? arguments[t] : {};
                        t % 2 ? l(Object(n), !0).forEach((function(t) {
                            p(e, t, n[t])
                        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : l(Object(n)).forEach((function(t) {
                            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                        }))
                    }
                    return e
                }

                function p(e, t, n) {
                    return t in e ? Object.defineProperty(e, t, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : e[t] = n, e
                }

                function d(e, t) {
                    for (var n = 0; n < t.length; n++) {
                        var r = t[n];
                        r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
                    }
                }

                function h(e, t) {
                    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                }
                u.Authorization = "Authorization", u.Cookie = "Cookie";
                var g = function e(t, n, r) {
                        h(this, e), this.statusCode = t, this.statusText = n, this.content = r
                    },
                    v = function() {
                        function e() {
                            h(this, e)
                        }
                        var t, n, r;
                        return t = e, (n = [{
                            key: "get",
                            value: function(e, t) {
                                return this.send(f(f({}, t), {}, {
                                    method: "GET",
                                    url: e
                                }))
                            }
                        }, {
                            key: "post",
                            value: function(e, t) {
                                return this.send(f(f({}, t), {}, {
                                    method: "POST",
                                    url: e
                                }))
                            }
                        }, {
                            key: "delete",
                            value: function(e, t) {
                                return this.send(f(f({}, t), {}, {
                                    method: "DELETE",
                                    url: e
                                }))
                            }
                        }, {
                            key: "getCookieString",
                            value: function(e) {
                                return ""
                            }
                        }]) && d(t.prototype, n), r && d(t, r), e
                    }();

                function b(e) {
                    return (b = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                        return typeof e
                    } : function(e) {
                        return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                    })(e)
                }

                function m(e, t, n, r, o, i, a) {
                    try {
                        var c = e[i](a),
                            s = c.value
                    } catch (e) {
                        return void n(e)
                    }
                    c.done ? t(s) : Promise.resolve(s).then(r, o)
                }

                function y(e, t) {
                    for (var n = 0; n < t.length; n++) {
                        var r = t[n];
                        r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
                    }
                }

                function _(e, t) {
                    return (_ = Object.setPrototypeOf || function(e, t) {
                        return e.__proto__ = t, e
                    })(e, t)
                }

                function S(e) {
                    var t = function() {
                        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                        if (Reflect.construct.sham) return !1;
                        if ("function" == typeof Proxy) return !0;
                        try {
                            return Date.prototype.toString.call(Reflect.construct(Date, [], (function() {}))), !0
                        } catch (e) {
                            return !1
                        }
                    }();
                    return function() {
                        var n, r = C(e);
                        if (t) {
                            var o = C(this).constructor;
                            n = Reflect.construct(r, arguments, o)
                        } else n = r.apply(this, arguments);
                        return w(this, n)
                    }
                }

                function w(e, t) {
                    return !t || "object" !== b(t) && "function" != typeof t ? function(e) {
                        if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                        return e
                    }(e) : t
                }

                function C(e) {
                    return (C = Object.setPrototypeOf ? Object.getPrototypeOf : function(e) {
                        return e.__proto__ || Object.getPrototypeOf(e)
                    })(e)
                }
                var k = function(e) {
                        ! function(e, t) {
                            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
                            e.prototype = Object.create(t && t.prototype, {
                                constructor: {
                                    value: e,
                                    writable: !0,
                                    configurable: !0
                                }
                            }), t && _(e, t)
                        }(c, e);
                        var t, n, r, o, i, a = S(c);

                        function c(e, t) {
                            var n;
                            return function(e, t) {
                                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                            }(this, c), (n = a.call(this))._innerClient = e, n._accessTokenFactory = t, n
                        }
                        return t = c, (n = [{
                            key: "send",
                            value: (o = regeneratorRuntime.mark((function e(t) {
                                var n, r;
                                return regeneratorRuntime.wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            if (n = !0, !this._accessTokenFactory || this._accessToken && !(t.url && t.url.indexOf("/negotiate?") > 0)) {
                                                e.next = 6;
                                                break
                                            }
                                            return n = !1, e.next = 5, this._accessTokenFactory();
                                        case 5:
                                            this._accessToken = e.sent;
                                        case 6:
                                            return this._setAuthorizationHeader(t), e.next = 9, this._innerClient.send(t);
                                        case 9:
                                            if (r = e.sent, !n || 401 !== r.statusCode || !this._accessTokenFactory) {
                                                e.next = 18;
                                                break
                                            }
                                            return e.next = 13, this._accessTokenFactory();
                                        case 13:
                                            return this._accessToken = e.sent, this._setAuthorizationHeader(t), e.next = 17, this._innerClient.send(t);
                                        case 17:
                                            return e.abrupt("return", e.sent);
                                        case 18:
                                            return e.abrupt("return", r);
                                        case 19:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e, this)
                            })), i = function() {
                                var e = this,
                                    t = arguments;
                                return new Promise((function(n, r) {
                                    var i = o.apply(e, t);

                                    function a(e) {
                                        m(i, n, r, a, c, "next", e)
                                    }

                                    function c(e) {
                                        m(i, n, r, a, c, "throw", e)
                                    }
                                    a(void 0)
                                }))
                            }, function(e) {
                                return i.apply(this, arguments)
                            })
                        }, {
                            key: "_setAuthorizationHeader",
                            value: function(e) {
                                e.headers || (e.headers = {}), this._accessToken ? e.headers[u.Authorization] = "Bearer ".concat(this._accessToken) : this._accessTokenFactory && e.headers[u.Authorization] && delete e.headers[u.Authorization]
                            }
                        }, {
                            key: "getCookieString",
                            value: function(e) {
                                return this._innerClient.getCookieString(e)
                            }
                        }]) && y(t.prototype, n), r && y(t, r), c
                    }(v),
                    T = n(794),
                    E = n(798),
                    R = n(185);

                function O(e) {
                    return (O = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                        return typeof e
                    } : function(e) {
                        return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                    })(e)
                }

                function I(e, t) {
                    var n = Object.keys(e);
                    if (Object.getOwnPropertySymbols) {
                        var r = Object.getOwnPropertySymbols(e);
                        t && (r = r.filter((function(t) {
                            return Object.getOwnPropertyDescriptor(e, t).enumerable
                        }))), n.push.apply(n, r)
                    }
                    return n
                }

                function P(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = null != arguments[t] ? arguments[t] : {};
                        t % 2 ? I(Object(n), !0).forEach((function(t) {
                            j(e, t, n[t])
                        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : I(Object(n)).forEach((function(t) {
                            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                        }))
                    }
                    return e
                }

                function j(e, t, n) {
                    return t in e ? Object.defineProperty(e, t, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : e[t] = n, e
                }

                function x(e, t, n, r, o, i, a) {
                    try {
                        var c = e[i](a),
                            s = c.value
                    } catch (e) {
                        return void n(e)
                    }
                    c.done ? t(s) : Promise.resolve(s).then(r, o)
                }

                function D(e, t) {
                    for (var n = 0; n < t.length; n++) {
                        var r = t[n];
                        r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
                    }
                }

                function A(e, t) {
                    return (A = Object.setPrototypeOf || function(e, t) {
                        return e.__proto__ = t, e
                    })(e, t)
                }

                function N(e) {
                    var t = function() {
                        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                        if (Reflect.construct.sham) return !1;
                        if ("function" == typeof Proxy) return !0;
                        try {
                            return Date.prototype.toString.call(Reflect.construct(Date, [], (function() {}))), !0
                        } catch (e) {
                            return !1
                        }
                    }();
                    return function() {
                        var n, r = M(e);
                        if (t) {
                            var o = M(this).constructor;
                            n = Reflect.construct(r, arguments, o)
                        } else n = r.apply(this, arguments);
                        return H(this, n)
                    }
                }

                function H(e, t) {
                    return !t || "object" !== O(t) && "function" != typeof t ? function(e) {
                        if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                        return e
                    }(e) : t
                }

                function M(e) {
                    return (M = Object.setPrototypeOf ? Object.getPrototypeOf : function(e) {
                        return e.__proto__ || Object.getPrototypeOf(e)
                    })(e)
                }
                var q = function(e) {
                    ! function(e, t) {
                        if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
                        e.prototype = Object.create(t && t.prototype, {
                            constructor: {
                                value: e,
                                writable: !0,
                                configurable: !0
                            }
                        }), t && A(e, t)
                    }(c, e);
                    var t, n, r, o, i, a = N(c);

                    function c(e) {
                        var t;
                        if (function(e, t) {
                                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                            }(this, c), (t = a.call(this))._logger = e, "undefined" == typeof fetch) {
                            var n = require;
                            t._jar = new(n("tough-cookie").CookieJar), t._fetchType = n("node-fetch"), t._fetchType = n("fetch-cookie")(t._fetchType, t._jar)
                        } else t._fetchType = fetch.bind((0, R.E9)());
                        if ("undefined" == typeof AbortController) {
                            var r = require;
                            t._abortControllerType = r("abort-controller")
                        } else t._abortControllerType = AbortController;
                        return t
                    }
                    return t = c, (n = [{
                        key: "send",
                        value: (o = regeneratorRuntime.mark((function e(t) {
                            var n, r, o, i, a, c, s, u, l = this;
                            return regeneratorRuntime.wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        if (!t.abortSignal || !t.abortSignal.aborted) {
                                            e.next = 2;
                                            break
                                        }
                                        throw new T._L;
                                    case 2:
                                        if (t.method) {
                                            e.next = 4;
                                            break
                                        }
                                        throw new Error("No method defined.");
                                    case 4:
                                        if (t.url) {
                                            e.next = 6;
                                            break
                                        }
                                        throw new Error("No url defined.");
                                    case 6:
                                        return n = new this._abortControllerType, t.abortSignal && (t.abortSignal.onabort = function() {
                                            n.abort(), r = new T._L
                                        }), o = null, t.timeout && (i = t.timeout, o = setTimeout((function() {
                                            n.abort(), l._logger.log(E.i.Warning, "Timeout from HTTP request."), r = new T.W5
                                        }), i)), "" === t.content && (t.content = void 0), t.content && (t.headers = t.headers || {}, (0, R.eP)(t.content) ? t.headers["Content-Type"] = "application/octet-stream" : t.headers["Content-Type"] = "text/plain;charset=UTF-8"), e.prev = 12, e.next = 15, this._fetchType(t.url, {
                                            body: t.content,
                                            cache: "no-cache",
                                            credentials: !0 === t.withCredentials ? "include" : "same-origin",
                                            headers: P({
                                                "X-Requested-With": "XMLHttpRequest"
                                            }, t.headers),
                                            method: t.method,
                                            mode: "cors",
                                            redirect: "follow",
                                            signal: n.signal
                                        });
                                    case 15:
                                        a = e.sent, e.next = 24;
                                        break;
                                    case 18:
                                        if (e.prev = 18, e.t0 = e.catch(12), !r) {
                                            e.next = 22;
                                            break
                                        }
                                        throw r;
                                    case 22:
                                        throw this._logger.log(E.i.Warning, "Error from HTTP request. ".concat(e.t0, ".")), e.t0;
                                    case 24:
                                        return e.prev = 24, o && clearTimeout(o), t.abortSignal && (t.abortSignal.onabort = null), e.finish(24);
                                    case 28:
                                        if (a.ok) {
                                            e.next = 33;
                                            break
                                        }
                                        return e.next = 31, L(a, "text");
                                    case 31:
                                        throw c = e.sent, new T.oo(c || a.statusText, a.status);
                                    case 33:
                                        return s = L(a, t.responseType), e.next = 36, s;
                                    case 36:
                                        return u = e.sent, e.abrupt("return", new g(a.status, a.statusText, u));
                                    case 38:
                                    case "end":
                                        return e.stop()
                                }
                            }), e, this, [
                                [12, 18, 24, 28]
                            ])
                        })), i = function() {
                            var e = this,
                                t = arguments;
                            return new Promise((function(n, r) {
                                var i = o.apply(e, t);

                                function a(e) {
                                    x(i, n, r, a, c, "next", e)
                                }

                                function c(e) {
                                    x(i, n, r, a, c, "throw", e)
                                }
                                a(void 0)
                            }))
                        }, function(e) {
                            return i.apply(this, arguments)
                        })
                    }, {
                        key: "getCookieString",
                        value: function(e) {
                            var t = "";
                            return R.t4.isNode && this._jar && this._jar.getCookies(e, (function(e, n) {
                                return t = n.join("; ")
                            })), t
                        }
                    }]) && D(t.prototype, n), r && D(t, r), c
                }(v);

                function L(e, t) {
                    var n;
                    switch (t) {
                        case "arraybuffer":
                            n = e.arrayBuffer();
                            break;
                        case "text":
                            n = e.text();
                            break;
                        case "blob":
                        case "document":
                        case "json":
                            throw new Error("".concat(t, " is not supported."));
                        default:
                            n = e.text()
                    }
                    return n
                }

                function U(e) {
                    return (U = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                        return typeof e
                    } : function(e) {
                        return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                    })(e)
                }

                function W(e, t) {
                    for (var n = 0; n < t.length; n++) {
                        var r = t[n];
                        r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
                    }
                }

                function F(e, t) {
                    return (F = Object.setPrototypeOf || function(e, t) {
                        return e.__proto__ = t, e
                    })(e, t)
                }

                function B(e) {
                    var t = function() {
                        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                        if (Reflect.construct.sham) return !1;
                        if ("function" == typeof Proxy) return !0;
                        try {
                            return Date.prototype.toString.call(Reflect.construct(Date, [], (function() {}))), !0
                        } catch (e) {
                            return !1
                        }
                    }();
                    return function() {
                        var n, r = z(e);
                        if (t) {
                            var o = z(this).constructor;
                            n = Reflect.construct(r, arguments, o)
                        } else n = r.apply(this, arguments);
                        return Q(this, n)
                    }
                }

                function Q(e, t) {
                    return !t || "object" !== U(t) && "function" != typeof t ? function(e) {
                        if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                        return e
                    }(e) : t
                }

                function z(e) {
                    return (z = Object.setPrototypeOf ? Object.getPrototypeOf : function(e) {
                        return e.__proto__ || Object.getPrototypeOf(e)
                    })(e)
                }
                var G = function(e) {
                    ! function(e, t) {
                        if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
                        e.prototype = Object.create(t && t.prototype, {
                            constructor: {
                                value: e,
                                writable: !0,
                                configurable: !0
                            }
                        }), t && F(e, t)
                    }(i, e);
                    var t, n, r, o = B(i);

                    function i(e) {
                        var t;
                        return function(e, t) {
                            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                        }(this, i), (t = o.call(this))._logger = e, t
                    }
                    return t = i, (n = [{
                        key: "send",
                        value: function(e) {
                            var t = this;
                            return e.abortSignal && e.abortSignal.aborted ? Promise.reject(new T._L) : e.method ? e.url ? new Promise((function(n, r) {
                                var o = new XMLHttpRequest;
                                o.open(e.method, e.url, !0), o.withCredentials = void 0 === e.withCredentials || e.withCredentials, o.setRequestHeader("X-Requested-With", "XMLHttpRequest"), "" === e.content && (e.content = void 0), e.content && ((0, R.eP)(e.content) ? o.setRequestHeader("Content-Type", "application/octet-stream") : o.setRequestHeader("Content-Type", "text/plain;charset=UTF-8"));
                                var i = e.headers;
                                i && Object.keys(i).forEach((function(e) {
                                    o.setRequestHeader(e, i[e])
                                })), e.responseType && (o.responseType = e.responseType), e.abortSignal && (e.abortSignal.onabort = function() {
                                    o.abort(), r(new T._L)
                                }), e.timeout && (o.timeout = e.timeout), o.onload = function() {
                                    e.abortSignal && (e.abortSignal.onabort = null), o.status >= 200 && o.status < 300 ? n(new g(o.status, o.statusText, o.response || o.responseText)) : r(new T.oo(o.response || o.responseText || o.statusText, o.status))
                                }, o.onerror = function() {
                                    t._logger.log(E.i.Warning, "Error from HTTP request. ".concat(o.status, ": ").concat(o.statusText, ".")), r(new T.oo(o.statusText, o.status))
                                }, o.ontimeout = function() {
                                    t._logger.log(E.i.Warning, "Timeout from HTTP request."), r(new T.W5)
                                }, o.send(e.content)
                            })) : Promise.reject(new Error("No url defined.")) : Promise.reject(new Error("No method defined."))
                        }
                    }]) && W(t.prototype, n), r && W(t, r), i
                }(v);

                function J(e) {
                    return (J = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                        return typeof e
                    } : function(e) {
                        return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                    })(e)
                }

                function K(e, t) {
                    for (var n = 0; n < t.length; n++) {
                        var r = t[n];
                        r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
                    }
                }

                function $(e, t) {
                    return ($ = Object.setPrototypeOf || function(e, t) {
                        return e.__proto__ = t, e
                    })(e, t)
                }

                function Z(e) {
                    var t = function() {
                        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                        if (Reflect.construct.sham) return !1;
                        if ("function" == typeof Proxy) return !0;
                        try {
                            return Date.prototype.toString.call(Reflect.construct(Date, [], (function() {}))), !0
                        } catch (e) {
                            return !1
                        }
                    }();
                    return function() {
                        var n, r = X(e);
                        if (t) {
                            var o = X(this).constructor;
                            n = Reflect.construct(r, arguments, o)
                        } else n = r.apply(this, arguments);
                        return V(this, n)
                    }
                }

                function V(e, t) {
                    return !t || "object" !== J(t) && "function" != typeof t ? function(e) {
                        if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                        return e
                    }(e) : t
                }

                function X(e) {
                    return (X = Object.setPrototypeOf ? Object.getPrototypeOf : function(e) {
                        return e.__proto__ || Object.getPrototypeOf(e)
                    })(e)
                }
                var Y, ee, te = function(e) {
                    ! function(e, t) {
                        if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
                        e.prototype = Object.create(t && t.prototype, {
                            constructor: {
                                value: e,
                                writable: !0,
                                configurable: !0
                            }
                        }), t && $(e, t)
                    }(i, e);
                    var t, n, r, o = Z(i);

                    function i(e) {
                        var t;
                        if (function(e, t) {
                                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                            }(this, i), t = o.call(this), "undefined" != typeof fetch || R.t4.isNode) t._httpClient = new q(e);
                        else {
                            if ("undefined" == typeof XMLHttpRequest) throw new Error("No usable HttpClient found.");
                            t._httpClient = new G(e)
                        }
                        return t
                    }
                    return t = i, (n = [{
                        key: "send",
                        value: function(e) {
                            return e.abortSignal && e.abortSignal.aborted ? Promise.reject(new T._L) : e.method ? e.url ? this._httpClient.send(e) : Promise.reject(new Error("No url defined.")) : Promise.reject(new Error("No method defined."))
                        }
                    }, {
                        key: "getCookieString",
                        value: function(e) {
                            return this._httpClient.getCookieString(e)
                        }
                    }]) && K(t.prototype, n), r && K(t, r), i
                }(v);

                function ne(e, t) {
                    for (var n = 0; n < t.length; n++) {
                        var r = t[n];
                        r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
                    }
                }! function(e) {
                    e[e.None = 0] = "None", e[e.WebSockets = 1] = "WebSockets", e[e.ServerSentEvents = 2] = "ServerSentEvents", e[e.LongPolling = 4] = "LongPolling"
                }(Y || (Y = {})),
                function(e) {
                    e[e.Text = 1] = "Text", e[e.Binary = 2] = "Binary"
                }(ee || (ee = {}));
                var re = function() {
                    function e() {
                        ! function(e, t) {
                            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                        }(this, e), this._isAborted = !1, this.onabort = null
                    }
                    var t, n, r;
                    return t = e, (n = [{
                        key: "abort",
                        value: function() {
                            this._isAborted || (this._isAborted = !0, this.onabort && this.onabort())
                        }
                    }, {
                        key: "signal",
                        get: function() {
                            return this
                        }
                    }, {
                        key: "aborted",
                        get: function() {
                            return this._isAborted
                        }
                    }]) && ne(t.prototype, n), r && ne(t, r), e
                }();

                function oe(e, t) {
                    var n = Object.keys(e);
                    if (Object.getOwnPropertySymbols) {
                        var r = Object.getOwnPropertySymbols(e);
                        t && (r = r.filter((function(t) {
                            return Object.getOwnPropertyDescriptor(e, t).enumerable
                        }))), n.push.apply(n, r)
                    }
                    return n
                }

                function ie(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = null != arguments[t] ? arguments[t] : {};
                        t % 2 ? oe(Object(n), !0).forEach((function(t) {
                            ae(e, t, n[t])
                        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : oe(Object(n)).forEach((function(t) {
                            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                        }))
                    }
                    return e
                }

                function ae(e, t, n) {
                    return t in e ? Object.defineProperty(e, t, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : e[t] = n, e
                }

                function ce(e, t) {
                    return function(e) {
                        if (Array.isArray(e)) return e
                    }(e) || function(e, t) {
                        if ("undefined" == typeof Symbol || !(Symbol.iterator in Object(e))) return;
                        var n = [],
                            r = !0,
                            o = !1,
                            i = void 0;
                        try {
                            for (var a, c = e[Symbol.iterator](); !(r = (a = c.next()).done) && (n.push(a.value), !t || n.length !== t); r = !0);
                        } catch (e) {
                            o = !0, i = e
                        } finally {
                            try {
                                r || null == c.return || c.return()
                            } finally {
                                if (o) throw i
                            }
                        }
                        return n
                    }(e, t) || function(e, t) {
                        if (!e) return;
                        if ("string" == typeof e) return se(e, t);
                        var n = Object.prototype.toString.call(e).slice(8, -1);
                        "Object" === n && e.constructor && (n = e.constructor.name);
                        if ("Map" === n || "Set" === n) return Array.from(e);
                        if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return se(e, t)
                    }(e, t) || function() {
                        throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                    }()
                }

                function se(e, t) {
                    (null == t || t > e.length) && (t = e.length);
                    for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
                    return r
                }

                function ue(e, t, n, r, o, i, a) {
                    try {
                        var c = e[i](a),
                            s = c.value
                    } catch (e) {
                        return void n(e)
                    }
                    c.done ? t(s) : Promise.resolve(s).then(r, o)
                }

                function le(e) {
                    return function() {
                        var t = this,
                            n = arguments;
                        return new Promise((function(r, o) {
                            var i = e.apply(t, n);

                            function a(e) {
                                ue(i, r, o, a, c, "next", e)
                            }

                            function c(e) {
                                ue(i, r, o, a, c, "throw", e)
                            }
                            a(void 0)
                        }))
                    }
                }

                function fe(e, t) {
                    for (var n = 0; n < t.length; n++) {
                        var r = t[n];
                        r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
                    }
                }
                var pe = function() {
                    function e(t, n, r) {
                        ! function(e, t) {
                            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                        }(this, e), this._httpClient = t, this._logger = n, this._pollAbort = new re, this._options = r, this._running = !1, this.onreceive = null, this.onclose = null
                    }
                    var t, n, r, o, i, a, c;
                    return t = e, (n = [{
                        key: "connect",
                        value: (c = le(regeneratorRuntime.mark((function e(t, n) {
                            var r, o, i, a, c, s, u, l;
                            return regeneratorRuntime.wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        if (R.j7.isRequired(t, "url"), R.j7.isRequired(n, "transferFormat"), R.j7.isIn(n, ee, "transferFormat"), this._url = t, this._logger.log(E.i.Trace, "(LongPolling transport) Connecting."), n !== ee.Binary || "undefined" == typeof XMLHttpRequest || "string" == typeof(new XMLHttpRequest).responseType) {
                                            e.next = 7;
                                            break
                                        }
                                        throw new Error("Binary protocols over XmlHttpRequest not implementing advanced features are not supported.");
                                    case 7:
                                        return r = (0, R.hS)(), o = ce(r, 2), i = o[0], a = o[1], c = ie(ae({}, i, a), this._options.headers), s = {
                                            abortSignal: this._pollAbort.signal,
                                            headers: c,
                                            timeout: 1e5,
                                            withCredentials: this._options.withCredentials
                                        }, n === ee.Binary && (s.responseType = "arraybuffer"), u = "".concat(t, "&_=").concat(Date.now()), this._logger.log(E.i.Trace, "(LongPolling transport) polling: ".concat(u, ".")), e.next = 15, this._httpClient.get(u, s);
                                    case 15:
                                        200 !== (l = e.sent).statusCode ? (this._logger.log(E.i.Error, "(LongPolling transport) Unexpected response code: ".concat(l.statusCode, ".")), this._closeError = new T.oo(l.statusText || "", l.statusCode), this._running = !1) : this._running = !0, this._receiving = this._poll(this._url, s);
                                    case 18:
                                    case "end":
                                        return e.stop()
                                }
                            }), e, this)
                        }))), function(e, t) {
                            return c.apply(this, arguments)
                        })
                    }, {
                        key: "_poll",
                        value: (a = le(regeneratorRuntime.mark((function e(t, n) {
                            var r, o;
                            return regeneratorRuntime.wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        e.prev = 0;
                                    case 1:
                                        if (!this._running) {
                                            e.next = 16;
                                            break
                                        }
                                        return e.prev = 2, r = "".concat(t, "&_=").concat(Date.now()), this._logger.log(E.i.Trace, "(LongPolling transport) polling: ".concat(r, ".")), e.next = 7, this._httpClient.get(r, n);
                                    case 7:
                                        204 === (o = e.sent).statusCode ? (this._logger.log(E.i.Information, "(LongPolling transport) Poll terminated by server."), this._running = !1) : 200 !== o.statusCode ? (this._logger.log(E.i.Error, "(LongPolling transport) Unexpected response code: ".concat(o.statusCode, ".")), this._closeError = new T.oo(o.statusText || "", o.statusCode), this._running = !1) : o.content ? (this._logger.log(E.i.Trace, "(LongPolling transport) data received. ".concat((0, R.o4)(o.content, this._options.logMessageContent), ".")), this.onreceive && this.onreceive(o.content)) : this._logger.log(E.i.Trace, "(LongPolling transport) Poll timed out, reissuing."), e.next = 14;
                                        break;
                                    case 11:
                                        e.prev = 11, e.t0 = e.catch(2), this._running ? e.t0 instanceof T.W5 ? this._logger.log(E.i.Trace, "(LongPolling transport) Poll timed out, reissuing.") : (this._closeError = e.t0, this._running = !1) : this._logger.log(E.i.Trace, "(LongPolling transport) Poll errored after shutdown: ".concat(e.t0.message));
                                    case 14:
                                        e.next = 1;
                                        break;
                                    case 16:
                                        return e.prev = 16, this._logger.log(E.i.Trace, "(LongPolling transport) Polling complete."), this.pollAborted || this._raiseOnClose(), e.finish(16);
                                    case 20:
                                    case "end":
                                        return e.stop()
                                }
                            }), e, this, [
                                [0, , 16, 20],
                                [2, 11]
                            ])
                        }))), function(e, t) {
                            return a.apply(this, arguments)
                        })
                    }, {
                        key: "send",
                        value: (i = le(regeneratorRuntime.mark((function e(t) {
                            return regeneratorRuntime.wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        if (this._running) {
                                            e.next = 2;
                                            break
                                        }
                                        return e.abrupt("return", Promise.reject(new Error("Cannot send until the transport is connected")));
                                    case 2:
                                        return e.abrupt("return", (0, R.bG)(this._logger, "LongPolling", this._httpClient, this._url, t, this._options));
                                    case 3:
                                    case "end":
                                        return e.stop()
                                }
                            }), e, this)
                        }))), function(e) {
                            return i.apply(this, arguments)
                        })
                    }, {
                        key: "stop",
                        value: (o = le(regeneratorRuntime.mark((function e() {
                            var t, n, r, o, i, a;
                            return regeneratorRuntime.wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        return this._logger.log(E.i.Trace, "(LongPolling transport) Stopping polling."), this._running = !1, this._pollAbort.abort(), e.prev = 3, e.next = 6, this._receiving;
                                    case 6:
                                        return this._logger.log(E.i.Trace, "(LongPolling transport) sending DELETE request to ".concat(this._url, ".")), t = {}, n = (0, R.hS)(), r = ce(n, 2), o = r[0], i = r[1], t[o] = i, a = {
                                            headers: ie(ie({}, t), this._options.headers),
                                            timeout: this._options.timeout,
                                            withCredentials: this._options.withCredentials
                                        }, e.next = 13, this._httpClient.delete(this._url, a);
                                    case 13:
                                        this._logger.log(E.i.Trace, "(LongPolling transport) DELETE request sent.");
                                    case 14:
                                        return e.prev = 14, this._logger.log(E.i.Trace, "(LongPolling transport) Stop finished."), this._raiseOnClose(), e.finish(14);
                                    case 18:
                                    case "end":
                                        return e.stop()
                                }
                            }), e, this, [
                                [3, , 14, 18]
                            ])
                        }))), function() {
                            return o.apply(this, arguments)
                        })
                    }, {
                        key: "_raiseOnClose",
                        value: function() {
                            if (this.onclose) {
                                var e = "(LongPolling transport) Firing onclose event.";
                                this._closeError && (e += " Error: " + this._closeError), this._logger.log(E.i.Trace, e), this.onclose(this._closeError)
                            }
                        }
                    }, {
                        key: "pollAborted",
                        get: function() {
                            return this._pollAbort.aborted
                        }
                    }]) && fe(t.prototype, n), r && fe(t, r), e
                }();

                function de(e, t) {
                    var n = Object.keys(e);
                    if (Object.getOwnPropertySymbols) {
                        var r = Object.getOwnPropertySymbols(e);
                        t && (r = r.filter((function(t) {
                            return Object.getOwnPropertyDescriptor(e, t).enumerable
                        }))), n.push.apply(n, r)
                    }
                    return n
                }

                function he(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = null != arguments[t] ? arguments[t] : {};
                        t % 2 ? de(Object(n), !0).forEach((function(t) {
                            ge(e, t, n[t])
                        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : de(Object(n)).forEach((function(t) {
                            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                        }))
                    }
                    return e
                }

                function ge(e, t, n) {
                    return t in e ? Object.defineProperty(e, t, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : e[t] = n, e
                }

                function ve(e, t) {
                    return function(e) {
                        if (Array.isArray(e)) return e
                    }(e) || function(e, t) {
                        if ("undefined" == typeof Symbol || !(Symbol.iterator in Object(e))) return;
                        var n = [],
                            r = !0,
                            o = !1,
                            i = void 0;
                        try {
                            for (var a, c = e[Symbol.iterator](); !(r = (a = c.next()).done) && (n.push(a.value), !t || n.length !== t); r = !0);
                        } catch (e) {
                            o = !0, i = e
                        } finally {
                            try {
                                r || null == c.return || c.return()
                            } finally {
                                if (o) throw i
                            }
                        }
                        return n
                    }(e, t) || function(e, t) {
                        if (!e) return;
                        if ("string" == typeof e) return be(e, t);
                        var n = Object.prototype.toString.call(e).slice(8, -1);
                        "Object" === n && e.constructor && (n = e.constructor.name);
                        if ("Map" === n || "Set" === n) return Array.from(e);
                        if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return be(e, t)
                    }(e, t) || function() {
                        throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                    }()
                }

                function be(e, t) {
                    (null == t || t > e.length) && (t = e.length);
                    for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
                    return r
                }

                function me(e, t, n, r, o, i, a) {
                    try {
                        var c = e[i](a),
                            s = c.value
                    } catch (e) {
                        return void n(e)
                    }
                    c.done ? t(s) : Promise.resolve(s).then(r, o)
                }

                function ye(e) {
                    return function() {
                        var t = this,
                            n = arguments;
                        return new Promise((function(r, o) {
                            var i = e.apply(t, n);

                            function a(e) {
                                me(i, r, o, a, c, "next", e)
                            }

                            function c(e) {
                                me(i, r, o, a, c, "throw", e)
                            }
                            a(void 0)
                        }))
                    }
                }

                function _e(e, t) {
                    for (var n = 0; n < t.length; n++) {
                        var r = t[n];
                        r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
                    }
                }
                var Se = function() {
                    function e(t, n, r, o) {
                        ! function(e, t) {
                            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                        }(this, e), this._httpClient = t, this._accessToken = n, this._logger = r, this._options = o, this.onreceive = null, this.onclose = null
                    }
                    var t, n, r, o, i;
                    return t = e, (n = [{
                        key: "connect",
                        value: (i = ye(regeneratorRuntime.mark((function e(t, n) {
                            var r = this;
                            return regeneratorRuntime.wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        return R.j7.isRequired(t, "url"), R.j7.isRequired(n, "transferFormat"), R.j7.isIn(n, ee, "transferFormat"), this._logger.log(E.i.Trace, "(SSE transport) Connecting."), this._url = t, this._accessToken && (t += (t.indexOf("?") < 0 ? "?" : "&") + "access_token=".concat(encodeURIComponent(this._accessToken))), e.abrupt("return", new Promise((function(e, o) {
                                            var i = !1;
                                            if (n === ee.Text) {
                                                var a;
                                                if (R.t4.isBrowser || R.t4.isWebWorker) a = new r._options.EventSource(t, {
                                                    withCredentials: r._options.withCredentials
                                                });
                                                else {
                                                    var c = r._httpClient.getCookieString(t),
                                                        s = {};
                                                    s.Cookie = c;
                                                    var u = ve((0, R.hS)(), 2),
                                                        l = u[0],
                                                        f = u[1];
                                                    s[l] = f, a = new r._options.EventSource(t, {
                                                        withCredentials: r._options.withCredentials,
                                                        headers: he(he({}, s), r._options.headers)
                                                    })
                                                }
                                                try {
                                                    a.onmessage = function(e) {
                                                        if (r.onreceive) try {
                                                            r._logger.log(E.i.Trace, "(SSE transport) data received. ".concat((0, R.o4)(e.data, r._options.logMessageContent), ".")), r.onreceive(e.data)
                                                        } catch (e) {
                                                            return void r._close(e)
                                                        }
                                                    }, a.onerror = function(e) {
                                                        i ? r._close() : o(new Error("EventSource failed to connect. The connection could not be found on the server, either the connection ID is not present on the server, or a proxy is refusing/buffering the connection. If you have multiple servers check that sticky sessions are enabled."))
                                                    }, a.onopen = function() {
                                                        r._logger.log(E.i.Information, "SSE connected to ".concat(r._url)), r._eventSource = a, i = !0, e()
                                                    }
                                                } catch (e) {
                                                    return void o(e)
                                                }
                                            } else o(new Error("The Server-Sent Events transport only supports the 'Text' transfer format"))
                                        })));
                                    case 7:
                                    case "end":
                                        return e.stop()
                                }
                            }), e, this)
                        }))), function(e, t) {
                            return i.apply(this, arguments)
                        })
                    }, {
                        key: "send",
                        value: (o = ye(regeneratorRuntime.mark((function e(t) {
                            return regeneratorRuntime.wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        if (this._eventSource) {
                                            e.next = 2;
                                            break
                                        }
                                        return e.abrupt("return", Promise.reject(new Error("Cannot send until the transport is connected")));
                                    case 2:
                                        return e.abrupt("return", (0, R.bG)(this._logger, "SSE", this._httpClient, this._url, t, this._options));
                                    case 3:
                                    case "end":
                                        return e.stop()
                                }
                            }), e, this)
                        }))), function(e) {
                            return o.apply(this, arguments)
                        })
                    }, {
                        key: "stop",
                        value: function() {
                            return this._close(), Promise.resolve()
                        }
                    }, {
                        key: "_close",
                        value: function(e) {
                            this._eventSource && (this._eventSource.close(), this._eventSource = void 0, this.onclose && this.onclose(e))
                        }
                    }]) && _e(t.prototype, n), r && _e(t, r), e
                }();

                function we(e, t) {
                    var n = Object.keys(e);
                    if (Object.getOwnPropertySymbols) {
                        var r = Object.getOwnPropertySymbols(e);
                        t && (r = r.filter((function(t) {
                            return Object.getOwnPropertyDescriptor(e, t).enumerable
                        }))), n.push.apply(n, r)
                    }
                    return n
                }

                function Ce(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = null != arguments[t] ? arguments[t] : {};
                        t % 2 ? we(Object(n), !0).forEach((function(t) {
                            ke(e, t, n[t])
                        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : we(Object(n)).forEach((function(t) {
                            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                        }))
                    }
                    return e
                }

                function ke(e, t, n) {
                    return t in e ? Object.defineProperty(e, t, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : e[t] = n, e
                }

                function Te(e, t) {
                    return function(e) {
                        if (Array.isArray(e)) return e
                    }(e) || function(e, t) {
                        if ("undefined" == typeof Symbol || !(Symbol.iterator in Object(e))) return;
                        var n = [],
                            r = !0,
                            o = !1,
                            i = void 0;
                        try {
                            for (var a, c = e[Symbol.iterator](); !(r = (a = c.next()).done) && (n.push(a.value), !t || n.length !== t); r = !0);
                        } catch (e) {
                            o = !0, i = e
                        } finally {
                            try {
                                r || null == c.return || c.return()
                            } finally {
                                if (o) throw i
                            }
                        }
                        return n
                    }(e, t) || function(e, t) {
                        if (!e) return;
                        if ("string" == typeof e) return Ee(e, t);
                        var n = Object.prototype.toString.call(e).slice(8, -1);
                        "Object" === n && e.constructor && (n = e.constructor.name);
                        if ("Map" === n || "Set" === n) return Array.from(e);
                        if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return Ee(e, t)
                    }(e, t) || function() {
                        throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                    }()
                }

                function Ee(e, t) {
                    (null == t || t > e.length) && (t = e.length);
                    for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
                    return r
                }

                function Re(e, t, n, r, o, i, a) {
                    try {
                        var c = e[i](a),
                            s = c.value
                    } catch (e) {
                        return void n(e)
                    }
                    c.done ? t(s) : Promise.resolve(s).then(r, o)
                }

                function Oe(e, t) {
                    for (var n = 0; n < t.length; n++) {
                        var r = t[n];
                        r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
                    }
                }
                var Ie = function() {
                    function e(t, n, r, o, i, a) {
                        ! function(e, t) {
                            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                        }(this, e), this._logger = r, this._accessTokenFactory = n, this._logMessageContent = o, this._webSocketConstructor = i, this._httpClient = t, this.onreceive = null, this.onclose = null, this._headers = a
                    }
                    var t, n, r, o, i;
                    return t = e, (n = [{
                        key: "connect",
                        value: (o = regeneratorRuntime.mark((function e(t, n) {
                            var r, o = this;
                            return regeneratorRuntime.wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        if (R.j7.isRequired(t, "url"), R.j7.isRequired(n, "transferFormat"), R.j7.isIn(n, ee, "transferFormat"), this._logger.log(E.i.Trace, "(WebSockets transport) Connecting."), !this._accessTokenFactory) {
                                            e.next = 8;
                                            break
                                        }
                                        return e.next = 7, this._accessTokenFactory();
                                    case 7:
                                        r = e.sent;
                                    case 8:
                                        return e.abrupt("return", new Promise((function(e, i) {
                                            var a;
                                            t = t.replace(/^http/, "ws");
                                            var c = o._httpClient.getCookieString(t),
                                                s = !1;
                                            if (R.t4.isNode || R.t4.isReactNative) {
                                                var l = {},
                                                    f = Te((0, R.hS)(), 2),
                                                    p = f[0],
                                                    d = f[1];
                                                l[p] = d, r && (l[u.Authorization] = "Bearer ".concat(r)), c && (l[u.Cookie] = c), a = new o._webSocketConstructor(t, void 0, {
                                                    headers: Ce(Ce({}, l), o._headers)
                                                })
                                            } else r && (t += (t.indexOf("?") < 0 ? "?" : "&") + "access_token=".concat(encodeURIComponent(r)));
                                            a || (a = new o._webSocketConstructor(t)), n === ee.Binary && (a.binaryType = "arraybuffer"), a.onopen = function(n) {
                                                o._logger.log(E.i.Information, "WebSocket connected to ".concat(t, ".")), o._webSocket = a, s = !0, e()
                                            }, a.onerror = function(e) {
                                                var t = null;
                                                t = "undefined" != typeof ErrorEvent && e instanceof ErrorEvent ? e.error : "There was an error with the transport", o._logger.log(E.i.Information, "(WebSockets transport) ".concat(t, "."))
                                            }, a.onmessage = function(e) {
                                                if (o._logger.log(E.i.Trace, "(WebSockets transport) data received. ".concat((0, R.o4)(e.data, o._logMessageContent), ".")), o.onreceive) try {
                                                    o.onreceive(e.data)
                                                } catch (e) {
                                                    return void o._close(e)
                                                }
                                            }, a.onclose = function(e) {
                                                if (s) o._close(e);
                                                else {
                                                    var t = null;
                                                    t = "undefined" != typeof ErrorEvent && e instanceof ErrorEvent ? e.error : "WebSocket failed to connect. The connection could not be found on the server, either the endpoint may not be a SignalR endpoint, the connection ID is not present on the server, or there is a proxy blocking WebSockets. If you have multiple servers check that sticky sessions are enabled.", i(new Error(t))
                                                }
                                            }
                                        })));
                                    case 9:
                                    case "end":
                                        return e.stop()
                                }
                            }), e, this)
                        })), i = function() {
                            var e = this,
                                t = arguments;
                            return new Promise((function(n, r) {
                                var i = o.apply(e, t);

                                function a(e) {
                                    Re(i, n, r, a, c, "next", e)
                                }

                                function c(e) {
                                    Re(i, n, r, a, c, "throw", e)
                                }
                                a(void 0)
                            }))
                        }, function(e, t) {
                            return i.apply(this, arguments)
                        })
                    }, {
                        key: "send",
                        value: function(e) {
                            return this._webSocket && this._webSocket.readyState === this._webSocketConstructor.OPEN ? (this._logger.log(E.i.Trace, "(WebSockets transport) sending data. ".concat((0, R.o4)(e, this._logMessageContent), ".")), this._webSocket.send(e), Promise.resolve()) : Promise.reject("WebSocket is not in the OPEN state")
                        }
                    }, {
                        key: "stop",
                        value: function() {
                            return this._webSocket && this._close(void 0), Promise.resolve()
                        }
                    }, {
                        key: "_close",
                        value: function(e) {
                            this._webSocket && (this._webSocket.onclose = function() {}, this._webSocket.onmessage = function() {}, this._webSocket.onerror = function() {}, this._webSocket.close(), this._webSocket = void 0), this._logger.log(E.i.Trace, "(WebSockets transport) socket closed."), this.onclose && (!this._isCloseEvent(e) || !1 !== e.wasClean && 1e3 === e.code ? e instanceof Error ? this.onclose(e) : this.onclose() : this.onclose(new Error("WebSocket closed with status code: ".concat(e.code, " (").concat(e.reason || "no reason given", ")."))))
                        }
                    }, {
                        key: "_isCloseEvent",
                        value: function(e) {
                            return e && "boolean" == typeof e.wasClean && "number" == typeof e.code
                        }
                    }]) && Oe(t.prototype, n), r && Oe(t, r), e
                }();

                function Pe(e) {
                    return (Pe = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                        return typeof e
                    } : function(e) {
                        return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                    })(e)
                }

                function je(e, t) {
                    var n;
                    if ("undefined" == typeof Symbol || null == e[Symbol.iterator]) {
                        if (Array.isArray(e) || (n = He(e)) || t && e && "number" == typeof e.length) {
                            n && (e = n);
                            var r = 0,
                                o = function() {};
                            return {
                                s: o,
                                n: function() {
                                    return r >= e.length ? {
                                        done: !0
                                    } : {
                                        done: !1,
                                        value: e[r++]
                                    }
                                },
                                e: function(e) {
                                    throw e
                                },
                                f: o
                            }
                        }
                        throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                    }
                    var i, a = !0,
                        c = !1;
                    return {
                        s: function() {
                            n = e[Symbol.iterator]()
                        },
                        n: function() {
                            var e = n.next();
                            return a = e.done, e
                        },
                        e: function(e) {
                            c = !0, i = e
                        },
                        f: function() {
                            try {
                                a || null == n.return || n.return()
                            } finally {
                                if (c) throw i
                            }
                        }
                    }
                }

                function xe(e, t) {
                    var n = Object.keys(e);
                    if (Object.getOwnPropertySymbols) {
                        var r = Object.getOwnPropertySymbols(e);
                        t && (r = r.filter((function(t) {
                            return Object.getOwnPropertyDescriptor(e, t).enumerable
                        }))), n.push.apply(n, r)
                    }
                    return n
                }

                function De(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = null != arguments[t] ? arguments[t] : {};
                        t % 2 ? xe(Object(n), !0).forEach((function(t) {
                            Ae(e, t, n[t])
                        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : xe(Object(n)).forEach((function(t) {
                            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                        }))
                    }
                    return e
                }

                function Ae(e, t, n) {
                    return t in e ? Object.defineProperty(e, t, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : e[t] = n, e
                }

                function Ne(e, t) {
                    return function(e) {
                        if (Array.isArray(e)) return e
                    }(e) || function(e, t) {
                        if ("undefined" == typeof Symbol || !(Symbol.iterator in Object(e))) return;
                        var n = [],
                            r = !0,
                            o = !1,
                            i = void 0;
                        try {
                            for (var a, c = e[Symbol.iterator](); !(r = (a = c.next()).done) && (n.push(a.value), !t || n.length !== t); r = !0);
                        } catch (e) {
                            o = !0, i = e
                        } finally {
                            try {
                                r || null == c.return || c.return()
                            } finally {
                                if (o) throw i
                            }
                        }
                        return n
                    }(e, t) || He(e, t) || function() {
                        throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                    }()
                }

                function He(e, t) {
                    if (e) {
                        if ("string" == typeof e) return Me(e, t);
                        var n = Object.prototype.toString.call(e).slice(8, -1);
                        return "Object" === n && e.constructor && (n = e.constructor.name), "Map" === n || "Set" === n ? Array.from(e) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? Me(e, t) : void 0
                    }
                }

                function Me(e, t) {
                    (null == t || t > e.length) && (t = e.length);
                    for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
                    return r
                }

                function qe(e, t, n, r, o, i, a) {
                    try {
                        var c = e[i](a),
                            s = c.value
                    } catch (e) {
                        return void n(e)
                    }
                    c.done ? t(s) : Promise.resolve(s).then(r, o)
                }

                function Le(e) {
                    return function() {
                        var t = this,
                            n = arguments;
                        return new Promise((function(r, o) {
                            var i = e.apply(t, n);

                            function a(e) {
                                qe(i, r, o, a, c, "next", e)
                            }

                            function c(e) {
                                qe(i, r, o, a, c, "throw", e)
                            }
                            a(void 0)
                        }))
                    }
                }

                function Ue(e, t) {
                    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                }

                function We(e, t) {
                    for (var n = 0; n < t.length; n++) {
                        var r = t[n];
                        r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
                    }
                }

                function Fe(e, t, n) {
                    return t && We(e.prototype, t), n && We(e, n), e
                }
                var Be = function() {
                    function e(t) {
                        var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                        if (Ue(this, e), this._stopPromiseResolver = function() {}, this.features = {}, this._negotiateVersion = 1, R.j7.isRequired(t, "url"), this._logger = (0, R.hu)(n.logger), this.baseUrl = this._resolveUrl(t), (n = n || {}).logMessageContent = void 0 !== n.logMessageContent && n.logMessageContent, "boolean" != typeof n.withCredentials && void 0 !== n.withCredentials) throw new Error("withCredentials option was not a 'boolean' or 'undefined' value");
                        n.withCredentials = void 0 === n.withCredentials || n.withCredentials, n.timeout = void 0 === n.timeout ? 1e5 : n.timeout;
                        var r = null,
                            o = null;
                        if (R.t4.isNode) {
                            var i = require;
                            r = i("ws"), o = i("eventsource")
                        }
                        R.t4.isNode || "undefined" == typeof WebSocket || n.WebSocket ? R.t4.isNode && !n.WebSocket && r && (n.WebSocket = r) : n.WebSocket = WebSocket, R.t4.isNode || "undefined" == typeof EventSource || n.EventSource ? R.t4.isNode && !n.EventSource && void 0 !== o && (n.EventSource = o) : n.EventSource = EventSource, this._httpClient = new k(n.httpClient || new te(this._logger), n.accessTokenFactory), this._connectionState = "Disconnected", this._connectionStarted = !1, this._options = n, this.onreceive = null, this.onclose = null
                    }
                    var t, n, r, o, i, a;
                    return Fe(e, [{
                        key: "start",
                        value: (a = Le(regeneratorRuntime.mark((function e(t) {
                            var n, r;
                            return regeneratorRuntime.wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        if (t = t || ee.Binary, R.j7.isIn(t, ee, "transferFormat"), this._logger.log(E.i.Debug, "Starting connection with transfer format '".concat(ee[t], "'.")), "Disconnected" === this._connectionState) {
                                            e.next = 5;
                                            break
                                        }
                                        return e.abrupt("return", Promise.reject(new Error("Cannot start an HttpConnection that is not in the 'Disconnected' state.")));
                                    case 5:
                                        return this._connectionState = "Connecting", this._startInternalPromise = this._startInternal(t), e.next = 9, this._startInternalPromise;
                                    case 9:
                                        if ("Disconnecting" !== this._connectionState) {
                                            e.next = 17;
                                            break
                                        }
                                        return n = "Failed to start the HttpConnection before stop() was called.", this._logger.log(E.i.Error, n), e.next = 14, this._stopPromise;
                                    case 14:
                                        return e.abrupt("return", Promise.reject(new T._L(n)));
                                    case 17:
                                        if ("Connected" === this._connectionState) {
                                            e.next = 21;
                                            break
                                        }
                                        return r = "HttpConnection.startInternal completed gracefully but didn't enter the connection into the connected state!", this._logger.log(E.i.Error, r), e.abrupt("return", Promise.reject(new T._L(r)));
                                    case 21:
                                        this._connectionStarted = !0;
                                    case 22:
                                    case "end":
                                        return e.stop()
                                }
                            }), e, this)
                        }))), function(e) {
                            return a.apply(this, arguments)
                        })
                    }, {
                        key: "send",
                        value: function(e) {
                            return "Connected" !== this._connectionState ? Promise.reject(new Error("Cannot send data if the connection is not in the 'Connected' State.")) : (this._sendQueue || (this._sendQueue = new Qe(this.transport)), this._sendQueue.send(e))
                        }
                    }, {
                        key: "stop",
                        value: (i = Le(regeneratorRuntime.mark((function e(t) {
                            var n = this;
                            return regeneratorRuntime.wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        if ("Disconnected" !== this._connectionState) {
                                            e.next = 3;
                                            break
                                        }
                                        return this._logger.log(E.i.Debug, "Call to HttpConnection.stop(".concat(t, ") ignored because the connection is already in the disconnected state.")), e.abrupt("return", Promise.resolve());
                                    case 3:
                                        if ("Disconnecting" !== this._connectionState) {
                                            e.next = 6;
                                            break
                                        }
                                        return this._logger.log(E.i.Debug, "Call to HttpConnection.stop(".concat(t, ") ignored because the connection is already in the disconnecting state.")), e.abrupt("return", this._stopPromise);
                                    case 6:
                                        return this._connectionState = "Disconnecting", this._stopPromise = new Promise((function(e) {
                                            n._stopPromiseResolver = e
                                        })), e.next = 10, this._stopInternal(t);
                                    case 10:
                                        return e.next = 12, this._stopPromise;
                                    case 12:
                                    case "end":
                                        return e.stop()
                                }
                            }), e, this)
                        }))), function(e) {
                            return i.apply(this, arguments)
                        })
                    }, {
                        key: "_stopInternal",
                        value: (o = Le(regeneratorRuntime.mark((function e(t) {
                            return regeneratorRuntime.wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        return this._stopError = t, e.prev = 1, e.next = 4, this._startInternalPromise;
                                    case 4:
                                        e.next = 8;
                                        break;
                                    case 6:
                                        e.prev = 6, e.t0 = e.catch(1);
                                    case 8:
                                        if (!this.transport) {
                                            e.next = 21;
                                            break
                                        }
                                        return e.prev = 9, e.next = 12, this.transport.stop();
                                    case 12:
                                        e.next = 18;
                                        break;
                                    case 14:
                                        e.prev = 14, e.t1 = e.catch(9), this._logger.log(E.i.Error, "HttpConnection.transport.stop() threw error '".concat(e.t1, "'.")), this._stopConnection();
                                    case 18:
                                        this.transport = void 0, e.next = 22;
                                        break;
                                    case 21:
                                        this._logger.log(E.i.Debug, "HttpConnection.transport is undefined in HttpConnection.stop() because start() failed.");
                                    case 22:
                                    case "end":
                                        return e.stop()
                                }
                            }), e, this, [
                                [1, 6],
                                [9, 14]
                            ])
                        }))), function(e) {
                            return o.apply(this, arguments)
                        })
                    }, {
                        key: "_startInternal",
                        value: (r = Le(regeneratorRuntime.mark((function e(t) {
                            var n, r, o, i = this;
                            return regeneratorRuntime.wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        if (n = this.baseUrl, this._accessTokenFactory = this._options.accessTokenFactory, this._httpClient._accessTokenFactory = this._accessTokenFactory, e.prev = 3, !this._options.skipNegotiation) {
                                            e.next = 14;
                                            break
                                        }
                                        if (this._options.transport !== Y.WebSockets) {
                                            e.next = 11;
                                            break
                                        }
                                        return this.transport = this._constructTransport(Y.WebSockets), e.next = 9, this._startTransport(n, t);
                                    case 9:
                                        e.next = 12;
                                        break;
                                    case 11:
                                        throw new Error("Negotiation can only be skipped when using the WebSocket transport directly.");
                                    case 12:
                                        e.next = 33;
                                        break;
                                    case 14:
                                        r = null, o = 0;
                                    case 16:
                                        return e.next = 18, this._getNegotiationResponse(n);
                                    case 18:
                                        if (r = e.sent, "Disconnecting" !== this._connectionState && "Disconnected" !== this._connectionState) {
                                            e.next = 21;
                                            break
                                        }
                                        throw new T._L("The connection was stopped during negotiation.");
                                    case 21:
                                        if (!r.error) {
                                            e.next = 23;
                                            break
                                        }
                                        throw new Error(r.error);
                                    case 23:
                                        if (!r.ProtocolVersion) {
                                            e.next = 25;
                                            break
                                        }
                                        throw new Error("Detected a connection attempt to an ASP.NET SignalR Server. This client only supports connecting to an ASP.NET Core SignalR Server. See https://aka.ms/signalr-core-differences for details.");
                                    case 25:
                                        r.url && (n = r.url), r.accessToken && function() {
                                            var e = r.accessToken;
                                            i._accessTokenFactory = function() {
                                                return e
                                            }, i._httpClient._accessToken = e, i._httpClient._accessTokenFactory = void 0
                                        }(), o++;
                                    case 28:
                                        if (r.url && o < 100) {
                                            e.next = 16;
                                            break
                                        }
                                    case 29:
                                        if (100 !== o || !r.url) {
                                            e.next = 31;
                                            break
                                        }
                                        throw new Error("Negotiate redirection limit exceeded.");
                                    case 31:
                                        return e.next = 33, this._createTransport(n, this._options.transport, r, t);
                                    case 33:
                                        this.transport instanceof pe && (this.features.inherentKeepAlive = !0), "Connecting" === this._connectionState && (this._logger.log(E.i.Debug, "The HttpConnection connected successfully."), this._connectionState = "Connected"), e.next = 44;
                                        break;
                                    case 37:
                                        return e.prev = 37, e.t0 = e.catch(3), this._logger.log(E.i.Error, "Failed to start the connection: " + e.t0), this._connectionState = "Disconnected", this.transport = void 0, this._stopPromiseResolver(), e.abrupt("return", Promise.reject(e.t0));
                                    case 44:
                                    case "end":
                                        return e.stop()
                                }
                            }), e, this, [
                                [3, 37]
                            ])
                        }))), function(e) {
                            return r.apply(this, arguments)
                        })
                    }, {
                        key: "_getNegotiationResponse",
                        value: (n = Le(regeneratorRuntime.mark((function e(t) {
                            var n, r, o, i, a, c, s, u, l;
                            return regeneratorRuntime.wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        return n = {}, r = (0, R.hS)(), o = Ne(r, 2), i = o[0], a = o[1], n[i] = a, c = this._resolveNegotiateUrl(t), this._logger.log(E.i.Debug, "Sending negotiation request: ".concat(c, ".")), e.prev = 5, e.next = 8, this._httpClient.post(c, {
                                            content: "",
                                            headers: De(De({}, n), this._options.headers),
                                            timeout: this._options.timeout,
                                            withCredentials: this._options.withCredentials
                                        });
                                    case 8:
                                        if (200 === (s = e.sent).statusCode) {
                                            e.next = 11;
                                            break
                                        }
                                        return e.abrupt("return", Promise.reject(new Error("Unexpected status code returned from negotiate '".concat(s.statusCode, "'"))));
                                    case 11:
                                        return (!(u = JSON.parse(s.content)).negotiateVersion || u.negotiateVersion < 1) && (u.connectionToken = u.connectionId), e.abrupt("return", u);
                                    case 16:
                                        return e.prev = 16, e.t0 = e.catch(5), l = "Failed to complete negotiation with the server: " + e.t0, e.t0 instanceof T.oo && 404 === e.t0.statusCode && (l += " Either this is not a SignalR endpoint or there is a proxy blocking the connection."), this._logger.log(E.i.Error, l), e.abrupt("return", Promise.reject(new T.EG(l)));
                                    case 22:
                                    case "end":
                                        return e.stop()
                                }
                            }), e, this, [
                                [5, 16]
                            ])
                        }))), function(e) {
                            return n.apply(this, arguments)
                        })
                    }, {
                        key: "_createConnectUrl",
                        value: function(e, t) {
                            return t ? e + (-1 === e.indexOf("?") ? "?" : "&") + "id=".concat(t) : e
                        }
                    }, {
                        key: "_createTransport",
                        value: (t = Le(regeneratorRuntime.mark((function e(t, n, r, o) {
                            var i, a, c, s, u, l, f, p, d;
                            return regeneratorRuntime.wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        if (i = this._createConnectUrl(t, r.connectionToken), !this._isITransport(n)) {
                                            e.next = 8;
                                            break
                                        }
                                        return this._logger.log(E.i.Debug, "Connection was provided an instance of ITransport, using that directly."), this.transport = n, e.next = 6, this._startTransport(i, o);
                                    case 6:
                                        return this.connectionId = r.connectionId, e.abrupt("return");
                                    case 8:
                                        a = [], c = r.availableTransports || [], s = r, u = je(c), e.prev = 12, u.s();
                                    case 14:
                                        if ((l = u.n()).done) {
                                            e.next = 53;
                                            break
                                        }
                                        if (f = l.value, !((p = this._resolveTransportOrError(f, n, o)) instanceof Error)) {
                                            e.next = 22;
                                            break
                                        }
                                        a.push("".concat(f.transport, " failed:")), a.push(p), e.next = 51;
                                        break;
                                    case 22:
                                        if (!this._isITransport(p)) {
                                            e.next = 51;
                                            break
                                        }
                                        if (this.transport = p, s) {
                                            e.next = 35;
                                            break
                                        }
                                        return e.prev = 25, e.next = 28, this._getNegotiationResponse(t);
                                    case 28:
                                        s = e.sent, e.next = 34;
                                        break;
                                    case 31:
                                        return e.prev = 31, e.t0 = e.catch(25), e.abrupt("return", Promise.reject(e.t0));
                                    case 34:
                                        i = this._createConnectUrl(t, s.connectionToken);
                                    case 35:
                                        return e.prev = 35, e.next = 38, this._startTransport(i, o);
                                    case 38:
                                        return this.connectionId = s.connectionId, e.abrupt("return");
                                    case 42:
                                        if (e.prev = 42, e.t1 = e.catch(35), this._logger.log(E.i.Error, "Failed to start the transport '".concat(f.transport, "': ").concat(e.t1)), s = void 0, a.push(new T.oJ("".concat(f.transport, " failed: ").concat(e.t1), Y[f.transport])), "Connecting" === this._connectionState) {
                                            e.next = 51;
                                            break
                                        }
                                        return d = "Failed to select transport before stop() was called.", this._logger.log(E.i.Debug, d), e.abrupt("return", Promise.reject(new T._L(d)));
                                    case 51:
                                        e.next = 14;
                                        break;
                                    case 53:
                                        e.next = 58;
                                        break;
                                    case 55:
                                        e.prev = 55, e.t2 = e.catch(12), u.e(e.t2);
                                    case 58:
                                        return e.prev = 58, u.f(), e.finish(58);
                                    case 61:
                                        if (!(a.length > 0)) {
                                            e.next = 63;
                                            break
                                        }
                                        return e.abrupt("return", Promise.reject(new T.KO("Unable to connect to the server with any of the available transports. ".concat(a.join(" ")), a)));
                                    case 63:
                                        return e.abrupt("return", Promise.reject(new Error("None of the transports supported by the client are supported by the server.")));
                                    case 64:
                                    case "end":
                                        return e.stop()
                                }
                            }), e, this, [
                                [12, 55, 58, 61],
                                [25, 31],
                                [35, 42]
                            ])
                        }))), function(e, n, r, o) {
                            return t.apply(this, arguments)
                        })
                    }, {
                        key: "_constructTransport",
                        value: function(e) {
                            switch (e) {
                                case Y.WebSockets:
                                    if (!this._options.WebSocket) throw new Error("'WebSocket' is not supported in your environment.");
                                    return new Ie(this._httpClient, this._accessTokenFactory, this._logger, this._options.logMessageContent, this._options.WebSocket, this._options.headers || {});
                                case Y.ServerSentEvents:
                                    if (!this._options.EventSource) throw new Error("'EventSource' is not supported in your environment.");
                                    return new Se(this._httpClient, this._httpClient._accessToken, this._logger, this._options);
                                case Y.LongPolling:
                                    return new pe(this._httpClient, this._logger, this._options);
                                default:
                                    throw new Error("Unknown transport: ".concat(e, "."))
                            }
                        }
                    }, {
                        key: "_startTransport",
                        value: function(e, t) {
                            var n = this;
                            return this.transport.onreceive = this.onreceive, this.transport.onclose = function(e) {
                                return n._stopConnection(e)
                            }, this.transport.connect(e, t)
                        }
                    }, {
                        key: "_resolveTransportOrError",
                        value: function(e, t, n) {
                            var r = Y[e.transport];
                            if (null == r) return this._logger.log(E.i.Debug, "Skipping transport '".concat(e.transport, "' because it is not supported by this client.")), new Error("Skipping transport '".concat(e.transport, "' because it is not supported by this client."));
                            if (! function(e, t) {
                                    return !e || 0 != (t & e)
                                }(t, r)) return this._logger.log(E.i.Debug, "Skipping transport '".concat(Y[r], "' because it was disabled by the client.")), new T.mm("'".concat(Y[r], "' is disabled by the client."), r);
                            if (!(e.transferFormats.map((function(e) {
                                    return ee[e]
                                })).indexOf(n) >= 0)) return this._logger.log(E.i.Debug, "Skipping transport '".concat(Y[r], "' because it does not support the requested transfer format '").concat(ee[n], "'.")), new Error("'".concat(Y[r], "' does not support ").concat(ee[n], "."));
                            if (r === Y.WebSockets && !this._options.WebSocket || r === Y.ServerSentEvents && !this._options.EventSource) return this._logger.log(E.i.Debug, "Skipping transport '".concat(Y[r], "' because it is not supported in your environment.'")), new T.jQ("'".concat(Y[r], "' is not supported in your environment."), r);
                            this._logger.log(E.i.Debug, "Selecting transport '".concat(Y[r], "'."));
                            try {
                                return this._constructTransport(r)
                            } catch (e) {
                                return e
                            }
                        }
                    }, {
                        key: "_isITransport",
                        value: function(e) {
                            return e && "object" === Pe(e) && "connect" in e
                        }
                    }, {
                        key: "_stopConnection",
                        value: function(e) {
                            var t = this;
                            if (this._logger.log(E.i.Debug, "HttpConnection.stopConnection(".concat(e, ") called while in state ").concat(this._connectionState, ".")), this.transport = void 0, e = this._stopError || e, this._stopError = void 0, "Disconnected" !== this._connectionState) {
                                if ("Connecting" === this._connectionState) throw this._logger.log(E.i.Warning, "Call to HttpConnection.stopConnection(".concat(e, ") was ignored because the connection is still in the connecting state.")), new Error("HttpConnection.stopConnection(".concat(e, ") was called while the connection is still in the connecting state."));
                                if ("Disconnecting" === this._connectionState && this._stopPromiseResolver(), e ? this._logger.log(E.i.Error, "Connection disconnected with error '".concat(e, "'.")) : this._logger.log(E.i.Information, "Connection disconnected."), this._sendQueue && (this._sendQueue.stop().catch((function(e) {
                                        t._logger.log(E.i.Error, "TransportSendQueue.stop() threw error '".concat(e, "'."))
                                    })), this._sendQueue = void 0), this.connectionId = void 0, this._connectionState = "Disconnected", this._connectionStarted) {
                                    this._connectionStarted = !1;
                                    try {
                                        this.onclose && this.onclose(e)
                                    } catch (t) {
                                        this._logger.log(E.i.Error, "HttpConnection.onclose(".concat(e, ") threw error '").concat(t, "'."))
                                    }
                                }
                            } else this._logger.log(E.i.Debug, "Call to HttpConnection.stopConnection(".concat(e, ") was ignored because the connection is already in the disconnected state."))
                        }
                    }, {
                        key: "_resolveUrl",
                        value: function(e) {
                            if (0 === e.lastIndexOf("https://", 0) || 0 === e.lastIndexOf("http://", 0)) return e;
                            if (!R.t4.isBrowser) throw new Error("Cannot resolve '".concat(e, "'."));
                            var t = window.document.createElement("a");
                            return t.href = e, this._logger.log(E.i.Information, "Normalizing '".concat(e, "' to '").concat(t.href, "'.")), t.href
                        }
                    }, {
                        key: "_resolveNegotiateUrl",
                        value: function(e) {
                            var t = e.indexOf("?"),
                                n = e.substring(0, -1 === t ? e.length : t);
                            return "/" !== n[n.length - 1] && (n += "/"), n += "negotiate", -1 === (n += -1 === t ? "" : e.substring(t)).indexOf("negotiateVersion") && (n += -1 === t ? "?" : "&", n += "negotiateVersion=" + this._negotiateVersion), n
                        }
                    }]), e
                }();
                var Qe = function() {
                        function e(t) {
                            Ue(this, e), this._transport = t, this._buffer = [], this._executing = !0, this._sendBufferedData = new ze, this._transportResult = new ze, this._sendLoopPromise = this._sendLoop()
                        }
                        var t;
                        return Fe(e, [{
                            key: "send",
                            value: function(e) {
                                return this._bufferData(e), this._transportResult || (this._transportResult = new ze), this._transportResult.promise
                            }
                        }, {
                            key: "stop",
                            value: function() {
                                return this._executing = !1, this._sendBufferedData.resolve(), this._sendLoopPromise
                            }
                        }, {
                            key: "_bufferData",
                            value: function(e) {
                                if (this._buffer.length && Pe(this._buffer[0]) !== Pe(e)) throw new Error("Expected data to be of type ".concat(Pe(this._buffer), " but was of type ").concat(Pe(e)));
                                this._buffer.push(e), this._sendBufferedData.resolve()
                            }
                        }, {
                            key: "_sendLoop",
                            value: (t = Le(regeneratorRuntime.mark((function t() {
                                var n, r;
                                return regeneratorRuntime.wrap((function(t) {
                                    for (;;) switch (t.prev = t.next) {
                                        case 0:
                                            return t.next = 3, this._sendBufferedData.promise;
                                        case 3:
                                            if (this._executing) {
                                                t.next = 6;
                                                break
                                            }
                                            return this._transportResult && this._transportResult.reject("Connection stopped."), t.abrupt("break", 22);
                                        case 6:
                                            return this._sendBufferedData = new ze, n = this._transportResult, this._transportResult = void 0, r = "string" == typeof this._buffer[0] ? this._buffer.join("") : e._concatBuffers(this._buffer), this._buffer.length = 0, t.prev = 11, t.next = 14, this._transport.send(r);
                                        case 14:
                                            n.resolve(), t.next = 20;
                                            break;
                                        case 17:
                                            t.prev = 17, t.t0 = t.catch(11), n.reject(t.t0);
                                        case 20:
                                            t.next = 0;
                                            break;
                                        case 22:
                                        case "end":
                                            return t.stop()
                                    }
                                }), t, this, [
                                    [11, 17]
                                ])
                            }))), function() {
                                return t.apply(this, arguments)
                            })
                        }], [{
                            key: "_concatBuffers",
                            value: function(e) {
                                var t, n = e.map((function(e) {
                                        return e.byteLength
                                    })).reduce((function(e, t) {
                                        return e + t
                                    })),
                                    r = new Uint8Array(n),
                                    o = 0,
                                    i = je(e);
                                try {
                                    for (i.s(); !(t = i.n()).done;) {
                                        var a = t.value;
                                        r.set(new Uint8Array(a), o), o += a.byteLength
                                    }
                                } catch (e) {
                                    i.e(e)
                                } finally {
                                    i.f()
                                }
                                return r.buffer
                            }
                        }]), e
                    }(),
                    ze = function() {
                        function e() {
                            var t = this;
                            Ue(this, e), this.promise = new Promise((function(e, n) {
                                var r;
                                return r = [e, n], t._resolver = r[0], t._rejecter = r[1], r
                            }))
                        }
                        return Fe(e, [{
                            key: "resolve",
                            value: function() {
                                this._resolver()
                            }
                        }, {
                            key: "reject",
                            value: function(e) {
                                this._rejecter(e)
                            }
                        }]), e
                    }(),
                    Ge = n(55),
                    Je = n(350),
                    Ke = n(498),
                    $e = n(621);

                function Ze(e, t) {
                    var n;
                    if ("undefined" == typeof Symbol || null == e[Symbol.iterator]) {
                        if (Array.isArray(e) || (n = function(e, t) {
                                if (!e) return;
                                if ("string" == typeof e) return Ve(e, t);
                                var n = Object.prototype.toString.call(e).slice(8, -1);
                                "Object" === n && e.constructor && (n = e.constructor.name);
                                if ("Map" === n || "Set" === n) return Array.from(e);
                                if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return Ve(e, t)
                            }(e)) || t && e && "number" == typeof e.length) {
                            n && (e = n);
                            var r = 0,
                                o = function() {};
                            return {
                                s: o,
                                n: function() {
                                    return r >= e.length ? {
                                        done: !0
                                    } : {
                                        done: !1,
                                        value: e[r++]
                                    }
                                },
                                e: function(e) {
                                    throw e
                                },
                                f: o
                            }
                        }
                        throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                    }
                    var i, a = !0,
                        c = !1;
                    return {
                        s: function() {
                            n = e[Symbol.iterator]()
                        },
                        n: function() {
                            var e = n.next();
                            return a = e.done, e
                        },
                        e: function(e) {
                            c = !0, i = e
                        },
                        f: function() {
                            try {
                                a || null == n.return || n.return()
                            } finally {
                                if (c) throw i
                            }
                        }
                    }
                }

                function Ve(e, t) {
                    (null == t || t > e.length) && (t = e.length);
                    for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
                    return r
                }

                function Xe(e, t) {
                    for (var n = 0; n < t.length; n++) {
                        var r = t[n];
                        r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
                    }
                }
                var Ye = function() {
                    function e() {
                        ! function(e, t) {
                            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                        }(this, e), this.name = "json", this.version = 1, this.transferFormat = ee.Text
                    }
                    var t, n, r;
                    return t = e, (n = [{
                        key: "parseMessages",
                        value: function(e, t) {
                            if ("string" != typeof e) throw new Error("Invalid input for JSON hub protocol. Expected a string.");
                            if (!e) return [];
                            null === t && (t = Ke.W.instance);
                            var n, r = [],
                                o = Ze($e.d.parse(e));
                            try {
                                for (o.s(); !(n = o.n()).done;) {
                                    var i = n.value,
                                        a = JSON.parse(i);
                                    if ("number" != typeof a.type) throw new Error("Invalid payload.");
                                    switch (a.type) {
                                        case Je.C.Invocation:
                                            this._isInvocationMessage(a);
                                            break;
                                        case Je.C.StreamItem:
                                            this._isStreamItemMessage(a);
                                            break;
                                        case Je.C.Completion:
                                            this._isCompletionMessage(a);
                                            break;
                                        case Je.C.Ping:
                                        case Je.C.Close:
                                            break;
                                        default:
                                            t.log(E.i.Information, "Unknown message type '" + a.type + "' ignored.");
                                            continue
                                    }
                                    r.push(a)
                                }
                            } catch (e) {
                                o.e(e)
                            } finally {
                                o.f()
                            }
                            return r
                        }
                    }, {
                        key: "writeMessage",
                        value: function(e) {
                            return $e.d.write(JSON.stringify(e))
                        }
                    }, {
                        key: "_isInvocationMessage",
                        value: function(e) {
                            this._assertNotEmptyString(e.target, "Invalid payload for Invocation message."), void 0 !== e.invocationId && this._assertNotEmptyString(e.invocationId, "Invalid payload for Invocation message.")
                        }
                    }, {
                        key: "_isStreamItemMessage",
                        value: function(e) {
                            if (this._assertNotEmptyString(e.invocationId, "Invalid payload for StreamItem message."), void 0 === e.item) throw new Error("Invalid payload for StreamItem message.")
                        }
                    }, {
                        key: "_isCompletionMessage",
                        value: function(e) {
                            if (e.result && e.error) throw new Error("Invalid payload for Completion message.");
                            !e.result && e.error && this._assertNotEmptyString(e.error, "Invalid payload for Completion message."), this._assertNotEmptyString(e.invocationId, "Invalid payload for Completion message.")
                        }
                    }, {
                        key: "_assertNotEmptyString",
                        value: function(e, t) {
                            if ("string" != typeof e || "" === e) throw new Error(t)
                        }
                    }]) && Xe(t.prototype, n), r && Xe(t, r), e
                }();

                function et(e, t) {
                    var n = Object.keys(e);
                    if (Object.getOwnPropertySymbols) {
                        var r = Object.getOwnPropertySymbols(e);
                        t && (r = r.filter((function(t) {
                            return Object.getOwnPropertyDescriptor(e, t).enumerable
                        }))), n.push.apply(n, r)
                    }
                    return n
                }

                function tt(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = null != arguments[t] ? arguments[t] : {};
                        t % 2 ? et(Object(n), !0).forEach((function(t) {
                            nt(e, t, n[t])
                        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : et(Object(n)).forEach((function(t) {
                            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                        }))
                    }
                    return e
                }

                function nt(e, t, n) {
                    return t in e ? Object.defineProperty(e, t, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : e[t] = n, e
                }

                function rt(e) {
                    return (rt = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                        return typeof e
                    } : function(e) {
                        return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                    })(e)
                }

                function ot(e, t) {
                    for (var n = 0; n < t.length; n++) {
                        var r = t[n];
                        r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
                    }
                }
                var it = {
                    trace: E.i.Trace,
                    debug: E.i.Debug,
                    info: E.i.Information,
                    information: E.i.Information,
                    warn: E.i.Warning,
                    warning: E.i.Warning,
                    error: E.i.Error,
                    critical: E.i.Critical,
                    none: E.i.None
                };
                var at = function() {
                    function e() {
                        ! function(e, t) {
                            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                        }(this, e)
                    }
                    var t, n, r;
                    return t = e, (n = [{
                        key: "configureLogging",
                        value: function(e) {
                            if (R.j7.isRequired(e, "logging"), void 0 !== e.log) this.logger = e;
                            else if ("string" == typeof e) {
                                var t = function(e) {
                                    var t = it[e.toLowerCase()];
                                    if (void 0 !== t) return t;
                                    throw new Error("Unknown log level: ".concat(e))
                                }(e);
                                this.logger = new R.kw(t)
                            } else this.logger = new R.kw(e);
                            return this
                        }
                    }, {
                        key: "withUrl",
                        value: function(e, t) {
                            return R.j7.isRequired(e, "url"), R.j7.isNotEmpty(e, "url"), this.url = e, "object" === rt(t) ? this.httpConnectionOptions = tt(tt({}, this.httpConnectionOptions), t) : this.httpConnectionOptions = tt(tt({}, this.httpConnectionOptions), {}, {
                                transport: t
                            }), this
                        }
                    }, {
                        key: "withHubProtocol",
                        value: function(e) {
                            return R.j7.isRequired(e, "protocol"), this.protocol = e, this
                        }
                    }, {
                        key: "withAutomaticReconnect",
                        value: function(e) {
                            if (this.reconnectPolicy) throw new Error("A reconnectPolicy has already been set.");
                            return e ? Array.isArray(e) ? this.reconnectPolicy = new s(e) : this.reconnectPolicy = e : this.reconnectPolicy = new s, this
                        }
                    }, {
                        key: "build",
                        value: function() {
                            var e = this.httpConnectionOptions || {};
                            if (void 0 === e.logger && (e.logger = this.logger), !this.url) throw new Error("The 'HubConnectionBuilder.withUrl' method must be called before building the connection.");
                            var t = new Be(this.url, e);
                            return Ge.R.create(t, this.logger || Ke.W.instance, this.protocol || new Ye, this.reconnectPolicy)
                        }
                    }]) && ot(t.prototype, n), r && ot(t, r), e
                }();
                var ct = function(e, t, n, o, i, a) {
                    var c = this;
                    c.Start = f, c.Stop = function() {
                        s && (s.onclose((function() {})), s.stop(), s = null);
                        n(!1)
                    }, c.Restart = function() {
                        null === s ? f() : s.stop()
                    }, c.IsConnected = function() {
                        return u
                    };
                    var s = null,
                        u = !1,
                        l = function() {
                            if (!r.Utilities) return !1;
                            var e = new r.Utilities.ExponentialBackoffSpecification({
                                    firstAttemptDelay: 2e3,
                                    firstAttemptRandomnessFactor: 3,
                                    subsequentDelayBase: 1e4,
                                    subsequentDelayRandomnessFactor: .5,
                                    maximumDelayBase: 3e5
                                }),
                                t = new r.Utilities.ExponentialBackoffSpecification({
                                    firstAttemptDelay: 2e4,
                                    firstAttemptRandomnessFactor: .5,
                                    subsequentDelayBase: 4e4,
                                    subsequentDelayRandomnessFactor: .5,
                                    maximumDelayBase: 3e5
                                });
                            return new r.Utilities.ExponentialBackoff(e, (function(e) {
                                var t = e.GetLastResetTime();
                                return !!(t && t + 6e4 > (new Date).getTime())
                            }), t)
                        }();

                    function f() {
                        (s = (new at).withUrl(e.notificationsUrl, {
                            transport: Y.WebSockets,
                            skipNegotiation: !0
                        }).build()).on("notification", o), s.on("subscriptionStatus", i), s.onclose((function() {
                            ! function(t) {
                                if (e.isRealtimeWebAnalyticsConnectionEventsEnabled && a(t), t === Ge.A.Disconnected) {
                                    var n = l.StartNewAttempt();
                                    d("In Disconnection handler. Will attempt Reconnect after ".concat(n, "ms")), setTimeout((function() {
                                        null != s && s.start().then((function() {
                                            p(s.state)
                                        })).catch((function(e) {
                                            d("Connection after Disconnection unsuccessful. err:")
                                        }))
                                    }), n)
                                }
                            }(s.state)
                        })), (s = s).start().then((function() {
                            p(s.state)
                        })).catch((function(e) {
                            d("FAILED to connect to Core SignalR")
                        }))
                    }

                    function p(t) {
                        t === Ge.A.Connected ? (e.isRealtimeWebAnalyticsConnectionEventsEnabled && a(t), u = !0, n(!0)) : t === Ge.R.Disconnected && (u = !1, n(!1))
                    }

                    function d(e) {
                        t && t(e)
                    }
                }
            },
            283: function(e, t, n) {
                "use strict";
                var r, o, i, a, c = n(792),
                    s = n(133),
                    u = n(944),
                    l = n(986),
                    f = n(52),
                    p = (r = null, o = function() {
                        var e = [];
                        if (u.default) {
                            var t = c.DeviceMeta && new c.DeviceMeta,
                                n = !!t && t.isAndroidApp,
                                r = !!t && t.isIosApp;
                            0 == n && 0 == r && e.push(u.default)
                        }
                        return l.default && e.push(l.default), s.default && e.push(s.default), new f.Z(e)
                    }, i = null, {
                        GetClient: function() {
                            return null === r && (r = o()), r
                        },
                        GetNotificationsUrl: function() {
                            return a().notificationsUrl
                        },
                        GetMaximumConnectionTime: function() {
                            return a().maxConnectionTimeInMs
                        },
                        IsEventPublishingEnabled: function() {
                            return a().isEventPublishingEnabled
                        },
                        IsLocalStorageEnabled: function() {
                            return c.LocalStorage ? c.LocalStorage.isAvailable() && a().isLocalStorageEnabled : localStorage && a().isLocalStorageEnabled
                        },
                        GetUserId: function() {
                            return a().userId
                        },
                        GetSettings: a = function() {
                            return null === i && (i = {}, c.RealTimeSettings ? (i.notificationsUrl = c.RealTimeSettings.NotificationsEndpoint, i.maxConnectionTimeInMs = parseInt(c.RealTimeSettings.MaxConnectionTime), i.isEventPublishingEnabled = c.RealTimeSettings.IsEventPublishingEnabled, i.isDisconnectOnSlowConnectionDisabled = c.RealTimeSettings.IsDisconnectOnSlowConnectionDisabled, i.userId = c.CurrentUser ? parseInt(c.CurrentUser.userId) : -1, i.isSignalRClientTransportRestrictionEnabled = c.RealTimeSettings.IsSignalRClientTransportRestrictionEnabled, i.isLocalStorageEnabled = c.RealTimeSettings.IsLocalStorageInRealTimeEnabled, i.notificationsClientType = c.RealTimeSettings.NotificationsClientType, i.isRealtimeWebAnalyticsEnabled = c.RealTimeSettings.IsRealtimeWebAnalyticsEnabled, i.isRealtimeWebAnalyticsConnectionEventsEnabled = c.RealTimeSettings.IsRealtimeWebAnalyticsConnectionEventsEnabled) : (i.notificationsUrl = "https://realtime.roblox.com", i.maxConnectionTimeInMs = 216e5, i.isEventPublishingEnabled = !1, i.isDisconnectOnSlowConnectionDisabled = !1, i.userId = c.CurrentUser ? parseInt(c.CurrentUser.userId) : -1, i.isSignalRClientTransportRestrictionEnabled = !1, i.isLocalStorageEnabled = !1, i.notificationsClientType = "SignalR", i.isRealtimeWebAnalyticsEnabled = !1, i.isRealtimeWebAnalyticsConnectionEventsEnabled = !1)), i
                        }
                    });
                t.Z = p
            },
            797: function(e, t, n) {
                "use strict";
                var r = n(792);
                t.Z = function(e, t, n, o, i) {
                    var a = this;
                    a.Start = p, a.Stop = function() {
                        u && ($(u).unbind(), u.stop(), u = null);
                        n(!1)
                    }, a.Restart = function() {
                        null === u ? p() : u.stop()
                    }, a.IsConnected = function() {
                        return l
                    };
                    var c = {
                            0: "connecting",
                            1: "connected",
                            2: "reconnecting",
                            4: "disconnected"
                        },
                        s = 1,
                        u = null,
                        l = !1,
                        f = function() {
                            if (!r.Utilities) return !1;
                            var e = new r.Utilities.ExponentialBackoffSpecification({
                                    firstAttemptDelay: 2e3,
                                    firstAttemptRandomnessFactor: 3,
                                    subsequentDelayBase: 1e4,
                                    subsequentDelayRandomnessFactor: .5,
                                    maximumDelayBase: 3e5
                                }),
                                t = new r.Utilities.ExponentialBackoffSpecification({
                                    firstAttemptDelay: 2e4,
                                    firstAttemptRandomnessFactor: .5,
                                    subsequentDelayBase: 4e4,
                                    subsequentDelayRandomnessFactor: .5,
                                    maximumDelayBase: 3e5
                                });
                            return new r.Utilities.ExponentialBackoff(e, (function(e) {
                                var t = e.GetLastResetTime();
                                return !!(t && t + 6e4 > (new Date).getTime())
                            }), t)
                        }();

                    function p() {
                        var t, n, r;
                        t = e.notificationsUrl, n = $.hubConnection("".concat(t, "/notifications"), {
                            useDefaultPath: !1
                        }), (r = n.createHubProxy("userNotificationHub")).on("notification", o), r.on("subscriptionStatus", i), n.stateChanged(h), n.disconnected(g), n.reconnecting(v), (u = n).start(d()).done((function() {
                            b("Connected to SignalR [".concat(u.transport.name, "]"))
                        })).fail((function(e) {
                            b("FAILED to connect to SignalR [".concat(e, "]"))
                        }))
                    }

                    function d() {
                        var t = {
                            pingInterval: null
                        };
                        return e.isSignalRClientTransportRestrictionEnabled && (t.transport = window.WebSocket ? ["webSockets"] : ["webSockets", "longPolling"]), t
                    }

                    function h(e) {
                        e.newState === s ? (l = !0, n(!0)) : e.oldState === s && l && (l = !1, n(!1)), b("Connection Status changed from [".concat(c[e.oldState], "] to [").concat(c[e.newState], "]"))
                    }

                    function g() {
                        var e = f.StartNewAttempt();
                        b("In disconnected handler. Will attempt Reconnect after ".concat(e, "ms")), setTimeout((function() {
                            if (1 === f.GetAttemptCount()) {
                                var e = "userId: ".concat(r.CurrentUser) && r.CurrentUser.userId;
                                "undefined" != typeof GoogleAnalyticsEvents && GoogleAnalyticsEvents.FireEvent(["SignalR", "Attempting to Reconnect", e])
                            }
                            b("Attempting to Reconnect [".concat(f.GetAttemptCount(), "]...")), null != u && u.start(d()).done((function() {
                                f.Reset(), b("Connected Again!")
                            })).fail((function() {
                                b("Failed to Reconnect!")
                            }))
                        }), e)
                    }

                    function v() {
                        b("In reconnecting handler. Attempt to force disconnect."), u.stop()
                    }

                    function b(e) {
                        t && t(e)
                    }
                }
            },
            764: function(e, t, n) {
                "use strict";
                var r = n(792),
                    o = n(283);

                function i(e) {
                    return (i = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                        return typeof e
                    } : function(e) {
                        return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                    })(e)
                }
                t.Z = function(e, t, n) {
                    var a = {
                            IS_REQUIRED: 1,
                            NOT_REQUIRED: 2,
                            UNCLEAR: 3
                        },
                        c = "realTimeCheckIfDataReloadRequired",
                        s = "realTimeUpdateLatestSequenceNumber",
                        u = "SequenceOutOfOrder",
                        l = "SequenceNumberMissed",
                        f = "SequenceNumberMatched",
                        p = "InvalidSequenceNumber",
                        d = "MissingNotificationInformation",
                        h = null;

                    function g(e) {
                        "function" == typeof n && n(e)
                    }

                    function v() {
                        return "Roblox.RealTime.StateTracker.LastNamespaceSequenceNumberProcessed_U_" + o.Z.GetUserId()
                    }

                    function b(t, n) {
                        h && h.namespaceSequenceNumbersObj || (h = {
                            namespaceSequenceNumbersObj: {}
                        }), h.namespaceSequenceNumbersObj[t] = n, h.TimeStamp = Date.now(), e && localStorage.setItem(v(), JSON.stringify(h))
                    }

                    function m(e, n, o) {
                        try {
                            t && r.EventStream && ("object" !== i(o) && (o = {}), o.ua = navigator.userAgent, r.EventStream.SendEvent(e, n, o))
                        } catch (e) {
                            g("Error pushing to Event Stream")
                        }
                    }
                    var y = function() {
                        return h
                    };
                    ! function() {
                        if (g("StateTracker Initialized"), e) {
                            var t = localStorage.getItem(v());
                            t && (h = function(e) {
                                try {
                                    return JSON.parse(e)
                                } catch (e) {
                                    return g("Error parsing jsonString"), null
                                }
                            }(t))
                        }
                    }(), this.IsDataRefreshRequired = function(e, t) {
                        o.Z.GetSettings();
                        if ("number" != typeof t) return m(c, p, {
                            rld: !0
                        }), a.UNCLEAR;
                        var n = y();
                        if (void 0 === n || null == n) return m(c, d, {
                            rld: !0
                        }), b(e, t), a.UNCLEAR;
                        var r = n.namespaceSequenceNumbersObj[e];
                        return 0 === t && 0 !== r ? (b(e, t), m(c, u, {
                            rld: !0
                        }), a.IS_REQUIRED) : t < 0 && r >= 0 ? a.UNCLEAR : t === r ? (b(e, t), m(c, f, {
                            rld: !1
                        }), a.NOT_REQUIRED) : (m(c, l, {
                            rld: !0
                        }), t > r ? (b(e, t), m(c, u, {
                            rld: !0
                        }), a.IS_REQUIRED) : (r || b(e, t), a.UNCLEAR))
                    }, this.UpdateSequenceNumber = function(e, t) {
                        if ("number" == typeof t) {
                            var n = y();
                            "object" === i(n) && null != n && n.namespaceSequenceNumbersObj && n.namespaceSequenceNumbersObj[e] > t && m(s, u), b(e, t)
                        } else m(s, p)
                    }, this.GetLatestState = y, this.RefreshRequiredEnum = a
                }
            },
            986: function(e, t, n) {
                "use strict";
                n.r(t);
                var r = n(792),
                    o = n(307);
                t.default = function(e, t) {
                    var n, i, a, c = "Roblox.RealTime.Sources.CrossTabReplicatedSource",
                        s = !1,
                        u = function(e, n) {
                            t && t("CrossTabReplicatedSource: ".concat(e), n)
                        },
                        l = function() {
                            return r.CrossTabCommunication && r.CrossTabCommunication.Kingmaker && r.CrossTabCommunication.PubSub ? r.CrossTabCommunication.Kingmaker.IsAvailable() ? !r.CrossTabCommunication.Kingmaker.IsMasterTab() || (u("This is the master tab - it needs to send the events, not listen to them"), !1) : (u("CrossTabCommunication.Kingmaker not available - cannot pick a master tab"), !1) : (u("CrossTabCommunication dependencies are not present"), !1)
                        };
                    this.IsAvailable = l, this.Start = function(e, t, f) {
                        return !!l() && (s = !0, n = e, i = t, a = f, r.CrossTabCommunication.Kingmaker.SubscribeToMasterChange((function(e) {
                            e && s && n && (u("Tab has been promoted to master tab - triggering end of this source"), n())
                        })), r.CrossTabCommunication.PubSub.Subscribe(o.default.Notification, c, (function(e) {
                            u("Notification Received: ".concat(e), !0), e && i(JSON.parse(e))
                        })), r.CrossTabCommunication.PubSub.Subscribe(o.default.ConnectionEvent, c, (function(e) {
                            u("Connection Event Received: ".concat(e)), e && a(JSON.parse(e))
                        })), r.CrossTabCommunication.PubSub.Publish(o.default.RequestForConnectionStatus, o.default.RequestForConnectionStatus), !0)
                    }, this.Stop = function() {
                        u("Stopping. Unsubscribing from Cross-Tab events"), s = !1, r.CrossTabCommunication.PubSub.Unsubscribe(o.default.Notification, c), r.CrossTabCommunication.PubSub.Unsubscribe(o.default.ConnectionEvent, c)
                    }, this.Name = "CrossTabReplicatedSource"
                }
            },
            944: function(e, t, n) {
                "use strict";
                n.r(t);
                var r = n(792),
                    o = n(430);
                t.default = function(e, t) {
                    var n, i, a, c, s = !0,
                        u = function(e, n) {
                            t && t("HybridSource: ".concat(e), n)
                        },
                        l = function() {
                            return r.Hybrid && r.Hybrid.RealTime && r.Hybrid.RealTime.supports ? r.Hybrid.RealTime.isConnected && r.Hybrid.RealTime.onNotification && r.Hybrid.RealTime.onConnectionEvent ? null !== r.Hybrid && void 0 !== r.Hybrid && r.Hybrid.Bridge ? !o.default.hybridSourceDisabled || (u("Roblox.Hybrid has previously told us it is not supported. Will not try again"), !1) : (u("Roblox.Hybrid.Bridge is missing"), !1) : (u("Roblox.Hybrid.RealTime module does not provide all required methods. Cannot use Hybrid Source"), !1) : (u("Roblox.Hybrid or its RealTime module not present. Cannot use Hybrid Source"), !1)
                        },
                        f = function e() {
                            c = (new Date).getTime(), setTimeout((function() {
                                s && ((new Date).getTime() - c > 8e3 && (u("possible resume from suspension detected: polling for status"), h()), e())
                            }), 5e3)
                        },
                        p = function(e) {
                            if (e && e.params) {
                                var t = (JSON.parse(e.params.detail) || {}).sequenceNumber || 0,
                                    n = {
                                        namespace: e.params.namespace || "",
                                        detail: JSON.parse(e.params.detail) || {},
                                        sequenceNumber: e.params.sequenceNumber || -1,
                                        namespaceSequenceNumber: t
                                    };
                                u("Relaying parsed notification: ".concat(JSON.stringify(n)), !0), i(n)
                            } else u("onNotification event without sufficient data")
                        },
                        d = function(e) {
                            e && e.params ? (u("ConnectionEvent received: ".concat(JSON.stringify(e)), !0), a({
                                isConnected: e.params.isConnected || !1,
                                sequenceNumber: e.params.sequenceNumber || -1,
                                namespaceSequenceNumbersObj: e.params.namespaceSequenceNumbers || {}
                            })) : u("onConnectionEvent event without sufficient data")
                        },
                        h = function() {
                            r.Hybrid.RealTime.isConnected((function(e, t) {
                                e && t ? (u("ConnectionStatus response received: ".concat(JSON.stringify(t))), a({
                                    isConnected: t.isConnected,
                                    sequenceNumber: t.sequenceNumber || 0,
                                    namespaceSequenceNumbers: t.namespaceSequenceNumbers
                                })) : (u("ConnectionStatus request failed! Aborting attempt to use HybridSource"), n && n())
                            }))
                        };
                    this.IsAvailable = l, this.Start = function(e, t, c) {
                        return u("Starting"), !!l() && (n = e, i = t, a = c, r.Hybrid.RealTime.supports("isConnected", (function(e) {
                            e ? (u("Roblox.Hybrid.RealTime isConnected is supported. Subscribing to events"), r.Hybrid.RealTime.onNotification.subscribe(p), r.Hybrid.RealTime.onConnectionEvent.subscribe(d), h()) : (u("Roblox.Hybrid.RealTime isConnected not supported. Aborting attempt to use HybridSource"), o.default.hybridSourceDisabled = !0, n && n())
                        })), f(), !0)
                    }, this.Stop = function() {
                        u("Stopping. Detaching from native events"), r.Hybrid.RealTime.onNotification.unsubscribe(p), r.Hybrid.RealTime.onConnectionEvent.unsubscribe(d), s = !1
                    }, this.Name = "HybridSource"
                }
            },
            133: function(e, t, n) {
                "use strict";
                n.r(t);
                var r = n(792),
                    o = n(55),
                    i = n(307),
                    a = n(797),
                    c = n(269),
                    s = n(511);

                function u(e, t, n) {
                    return t in e ? Object.defineProperty(e, t, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : e[t] = n, e
                }
                t.default = function(e, t) {
                    var n, l, f, p = "ConnectionLost",
                        d = "Reconnected",
                        h = "Subscribed",
                        g = !1,
                        v = !1,
                        b = null,
                        m = !1,
                        y = null,
                        _ = -1,
                        S = {},
                        w = null,
                        C = "",
                        k = function(e, n) {
                            t && t("SignalRSource: ".concat(e), n)
                        },
                        T = function(e, t, n) {
                            var o = JSON.parse(t),
                                a = o.SequenceNumber || 0,
                                c = {
                                    namespace: e,
                                    detail: o,
                                    sequenceNumber: n,
                                    namespaceSequenceNumber: a
                                };
                            k("Notification received: ".concat(JSON.stringify(c)), !0), _ = n || -1, S[e] = a || -1, l(c), v && (k("Replicating Notification"), r.CrossTabCommunication.PubSub.Publish(i.default.Notification, JSON.stringify(c)))
                        },
                        E = function(e, t) {
                            g = e;
                            var n = {
                                    isConnected: e
                                },
                                o = t ? t.SequenceNumber : null,
                                a = t ? t.NamespaceSequenceNumbers : {};
                            if (a = a || {}, null !== o ? (n.sequenceNumber = o, _ = o) : _ = -1, a.constructor === Object && Object.keys(a).length > 0) n.namespaceSequenceNumbersObj = a, S = a;
                            else if (Object.keys(S).length > 0 && e && 0 === Object.keys(a).length) {
                                for (var c in S) Object.prototype.hasOwnProperty.call(S, c) && (S[c] = 0);
                                n.namespaceSequenceNumbersObj = S
                            }
                            k("Sending Connection Event: ".concat(JSON.stringify(n))), f(n), v && (k("Replicating Connection Event."), r.CrossTabCommunication.PubSub.Publish(i.default.ConnectionEvent, JSON.stringify(n)))
                        },
                        R = function() {
                            $(window).unbind("focus.enforceMaxTimeout"), null !== b && (clearTimeout(b), b = null)
                        },
                        O = function t() {
                            R(), b = setTimeout((function() {
                                E(!1), w.Stop(), $(window).unbind("focus.enforceMaxTimeout").bind("focus.enforceMaxTimeout", (function() {
                                    w.Start(), t()
                                }))
                            }), e.maxConnectionTimeInMs)
                        },
                        I = function(e) {
                            null !== y && (clearTimeout(y), y = null), e.MillisecondsBeforeHandlingReconnect > 0 ? (k("Waiting ".concat(e.MillisecondsBeforeHandlingReconnect, "ms to send Reconnected signal")), setTimeout((function() {
                                w.IsConnected() && E(!0, e)
                            }), e.MillisecondsBeforeHandlingReconnect)) : w.IsConnected() && E(!0, e)
                        },
                        P = function(e, t) {
                            var n, r, i = (u(n = {}, o.A.Connecting, 0), u(n, o.A.Connected, 1), u(n, o.A.Reconnecting, 2), u(n, o.A.Disconnected, 3), u(n, "NO_CONNECTION_UPDATE", 4), n);
                            s.Z.sendConnectionEventToDataLake(null !== (r = i[e]) && void 0 !== r ? r : i.NO_CONNECTION_UPDATE, C, t)
                        },
                        j = function(e) {
                            e && (C = e)
                        },
                        x = function(t, n) {
                            try {
                                k("Status Update Received: [".concat(t, "]").concat(n))
                            } catch (e) {}
                            if (e.isRealtimeWebAnalyticsConnectionEventsEnabled) {
                                if (t === p) k("Server Backend Connection Lost!"), w.Restart();
                                else if (t === d) {
                                    k("Server reconnected");
                                    var r = JSON.parse(n);
                                    j(r.ConnectionId), I(r)
                                } else if (t === h) {
                                    var o = JSON.parse(n);
                                    j(o.ConnectionId), k("Server connected"), m || (m = !0, o.MillisecondsBeforeHandlingReconnect = 0), I(o)
                                }
                                P("NO_CONNECTION_UPDATE", t)
                            } else if (t === p) k("Server Backend Connection Lost!"), w.Restart();
                            else if (t === d) k("Server reconnected"), I(JSON.parse(n));
                            else if (t === h) {
                                var i = JSON.parse(n);
                                k("Server connected"), m || (m = !0, i.MillisecondsBeforeHandlingReconnect = 0), I(i)
                            }
                        },
                        D = function(e) {
                            e ? y = setTimeout((function() {
                                y = null, w.IsConnected() && (m = !0, E(!0))
                            }), 2e3) : E(!1)
                        };
                    this.IsAvailable = function() {
                        return !0
                    }, this.Start = function(o, s, u) {
                        return n = o, l = s, f = u,
                            function() {
                                if (!r.CrossTabCommunication || !r.CrossTabCommunication.Kingmaker || !r.CrossTabCommunication.PubSub) return k("CrossTabCommunication dependencies required for replication are not present - will not replicate notifications"), void(v = !1);
                                r.CrossTabCommunication.Kingmaker.SubscribeToMasterChange((function(e) {
                                    v = e, e || n()
                                })), v = r.CrossTabCommunication.Kingmaker.IsMasterTab(), r.CrossTabCommunication.PubSub.Subscribe(i.default.RequestForConnectionStatus, "Roblox.RealTime.Sources.SignalRSource", (function() {
                                    if (v) {
                                        var e = {
                                            isConnected: g,
                                            sequenceNumber: _,
                                            namespaceSequenceNumbersObj: S
                                        };
                                        k("Responding to request for connection status: ".concat(JSON.stringify(e))), r.CrossTabCommunication.PubSub.Publish(i.default.ConnectionEvent, JSON.stringify(e))
                                    }
                                }))
                            }(), "CoreSignalR" === e.notificationsClientType ? (w = new c.Z(e, t, D, T, x, P), k("Started Core SignalR connection")) : (w = new a.Z(e, t, D, T, x), k("Started Legacy SignalR connection")), w.Start(), O(), !0
                    }, this.Stop = function() {
                        R(), w && w.Stop()
                    }, this.Name = "SignalRSource"
                }
            },
            511: function(e, t, n) {
                "use strict";
                var r = n(792);
                t.Z = {
                    maybeSendEventToDataLake: function(e, t, n) {
                        if (r.EventStream) {
                            var o = Array.isArray(t),
                                i = o ? t[0] : t,
                                a = i.SequenceNumber,
                                c = i.ShouldSendToEventStream,
                                s = i.RealtimeMessageIdentifier;
                            c && r.EventStream.SendEventWithTarget("RealtimeHandleEvent", "RealtimeHandleEventContext", {
                                localTimestampMilliseconds: Date.now(),
                                namespaceId: e,
                                sequenceNumber: parseInt(a, 10),
                                payloadSize: n,
                                bulkMessageCount: o ? t.length : 1,
                                messageIdentifier: s
                            }, r.EventStream.TargetTypes.WWW)
                        }
                    },
                    sendConnectionEventToDataLake: function(e, t, n) {
                        r.EventStream && r.EventStream.SendEventWithTarget("RealtimeWebConnectionChange", "RealtimeWebConnectionChangeContext", {
                            localTimestampMilliseconds: Date.now(),
                            connectionState: e,
                            connectionId: t,
                            subscriptionStatus: n
                        }, r.EventStream.TargetTypes.WWW)
                    }
                }
            },
            107: function() {
                ! function() {
                    "use strict";
                    if ($.signalR && ("2.2.0" === $.signalR.version || "2.2.2" === $.signalR.version)) {
                        var e = $.signalR.transports.webSockets.abort;
                        $.signalR.transports.webSockets.abort = function(t, n) {
                            e(t, !0)
                        };
                        var t = $.signalR.transports.longPolling.abort;
                        $.signalR.transports.longPolling.abort = function(e, n) {
                            t(e, !0)
                        }
                    }
                }()
            },
            981: function() {
                function e(t) {
                    return (e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                        return typeof e
                    } : function(e) {
                        return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                    })(t)
                }! function(e, t, n) {
                    var r = {
                        nojQuery: "jQuery was not found. Please ensure jQuery is referenced before the SignalR client JavaScript file.",
                        noTransportOnInit: "No transport could be initialized successfully. Try specifying a different transport or none at all for auto initialization.",
                        errorOnNegotiate: "Error during negotiation request.",
                        stoppedWhileLoading: "The connection was stopped during page load.",
                        stoppedWhileNegotiating: "The connection was stopped during the negotiate request.",
                        errorParsingNegotiateResponse: "Error parsing negotiate response.",
                        errorDuringStartRequest: "Error during start request. Stopping the connection.",
                        stoppedDuringStartRequest: "The connection was stopped during the start request.",
                        errorParsingStartResponse: "Error parsing start response: '{0}'. Stopping the connection.",
                        invalidStartResponse: "Invalid start response: '{0}'. Stopping the connection.",
                        protocolIncompatible: "You are using a version of the client that isn't compatible with the server. Client version {0}, server version {1}.",
                        sendFailed: "Send failed.",
                        parseFailed: "Failed at parsing response: {0}",
                        longPollFailed: "Long polling request failed.",
                        eventSourceFailedToConnect: "EventSource failed to connect.",
                        eventSourceError: "Error raised by EventSource",
                        webSocketClosed: "WebSocket closed.",
                        pingServerFailedInvalidResponse: "Invalid ping response when pinging server: '{0}'.",
                        pingServerFailed: "Failed to ping server.",
                        pingServerFailedStatusCode: "Failed to ping server.  Server responded with status code {0}, stopping the connection.",
                        pingServerFailedParse: "Failed to parse ping server response, stopping the connection.",
                        noConnectionTransport: "Connection is in an invalid state, there is no transport active.",
                        webSocketsInvalidState: "The Web Socket transport is in an invalid state, transitioning into reconnecting.",
                        reconnectTimeout: "Couldn't reconnect within the configured timeout of {0} ms, disconnecting.",
                        reconnectWindowTimeout: "The client has been inactive since {0} and it has exceeded the inactivity timeout of {1} ms. Stopping the connection."
                    };
                    if ("function" != typeof e) throw new Error(r.nojQuery);
                    var o, i, a, c, s = "complete" === t.document.readyState,
                        u = e(t),
                        l = "__Negotiate Aborted__",
                        f = {
                            onStart: "onStart",
                            onStarting: "onStarting",
                            onReceived: "onReceived",
                            onError: "onError",
                            onConnectionSlow: "onConnectionSlow",
                            onReconnecting: "onReconnecting",
                            onReconnect: "onReconnect",
                            onStateChanged: "onStateChanged",
                            onDisconnect: "onDisconnect"
                        },
                        p = function(t, n, r) {
                            return n === t.state && (t.state = r, e(t).triggerHandler(f.onStateChanged, [{
                                oldState: n,
                                newState: r
                            }]), !0)
                        },
                        d = function(e) {
                            return e._.keepAliveData.activated && e.transport.supportsKeepAlive(e)
                        };

                    function h(e, t) {
                        return t.match(/:\d+$/) ? t : t + ":" + function(e) {
                            return "http:" === e ? 80 : "https:" === e ? 443 : void 0
                        }(e)
                    }

                    function g(t, n) {
                        var r = this,
                            o = [];
                        r.tryBuffer = function(n) {
                            return t.state === e.signalR.connectionState.connecting && (o.push(n), !0)
                        }, r.drain = function() {
                            if (t.state === e.signalR.connectionState.connected)
                                for (; o.length > 0;) n(o.shift())
                        }, r.clear = function() {
                            o = []
                        }
                    }(o = function(e, t, n) {
                        return new o.fn.init(e, t, n)
                    })._ = {
                        defaultContentType: "application/x-www-form-urlencoded; charset=UTF-8",
                        ieVersion: ("Microsoft Internet Explorer" === t.navigator.appName && (c = /MSIE ([0-9]+\.[0-9]+)/.exec(t.navigator.userAgent)) && (a = t.parseFloat(c[1])), a),
                        error: function(e, t, n) {
                            var r = new Error(e);
                            return r.source = t, void 0 !== n && (r.context = n), r
                        },
                        transportError: function(e, t, n, r) {
                            var o = this.error(e, n, r);
                            return o.transport = t ? t.name : undefined, o
                        },
                        format: function() {
                            for (var e = arguments[0], t = 0; t < arguments.length - 1; t++) e = e.replace("{" + t + "}", arguments[t + 1]);
                            return e
                        },
                        firefoxMajorVersion: function(e) {
                            var t = e.match(/Firefox\/(\d+)/);
                            return !t || !t.length || t.length < 2 ? 0 : parseInt(t[1], 10)
                        },
                        configurePingInterval: function(n) {
                            var r = n._.config,
                                i = function(t) {
                                    e(n).triggerHandler(f.onError, [t])
                                };
                            r && !n._.pingIntervalId && r.pingInterval && (n._.pingIntervalId = t.setInterval((function() {
                                o.transports._logic.pingServer(n).fail(i)
                            }), r.pingInterval))
                        }
                    }, o.events = f, o.resources = r, o.ajaxDefaults = {
                        processData: !0,
                        timeout: null,
                        async: !0,
                        global: !1,
                        cache: !1
                    }, o.changeState = p, o.isDisconnecting = function(e) {
                        return e.state === o.connectionState.disconnected
                    }, o.connectionState = {
                        connecting: 0,
                        connected: 1,
                        reconnecting: 2,
                        disconnected: 4
                    }, o.hub = {
                        start: function() {
                            throw new Error("SignalR: Error loading hubs. Ensure your hubs reference is correct, e.g. <script src='/signalr/js'><\/script>.")
                        }
                    }, "function" == typeof u.on ? u.on("load", (function() {
                        s = !0
                    })) : u.load((function() {
                        s = !0
                    })), o.fn = o.prototype = {
                        init: function(t, n, r) {
                            var o = e(this);
                            this.url = t, this.qs = n, this.lastError = null, this._ = {
                                keepAliveData: {},
                                connectingMessageBuffer: new g(this, (function(e) {
                                    o.triggerHandler(f.onReceived, [e])
                                })),
                                lastMessageAt: (new Date).getTime(),
                                lastActiveAt: (new Date).getTime(),
                                beatInterval: 5e3,
                                beatHandle: null,
                                totalTransportConnectTimeout: 0
                            }, "boolean" == typeof r && (this.logging = r)
                        },
                        _parseResponse: function(e) {
                            return e && "string" == typeof e ? this.json.parse(e) : e
                        },
                        _originalJson: t.JSON,
                        json: t.JSON,
                        isCrossDomain: function(n, r) {
                            var o;
                            return n = e.trim(n), r = r || t.location, 0 === n.indexOf("http") && ((o = t.document.createElement("a")).href = n, o.protocol + h(o.protocol, o.host) !== r.protocol + h(r.protocol, r.host))
                        },
                        ajaxDataType: "text",
                        contentType: "application/json; charset=UTF-8",
                        logging: !1,
                        state: o.connectionState.disconnected,
                        clientProtocol: "1.5",
                        reconnectDelay: 2e3,
                        transportConnectTimeout: 0,
                        disconnectTimeout: 3e4,
                        reconnectWindow: 3e4,
                        keepAliveWarnAt: 2 / 3,
                        start: function(n, i) {
                            var a, c = this,
                                h = {
                                    pingInterval: 3e5,
                                    waitForPageLoad: !0,
                                    transport: "auto",
                                    jsonp: !1
                                },
                                g = c._deferral || e.Deferred(),
                                v = t.document.createElement("a");
                            if (c.lastError = null, c._deferral = g, !c.json) throw new Error("SignalR: No JSON parser found. Please ensure json2.js is referenced before the SignalR.js file if you need to support clients without native JSON parsing support, e.g. IE<8.");
                            if ("function" === e.type(n) ? i = n : "object" === e.type(n) && (e.extend(h, n), "function" === e.type(h.callback) && (i = h.callback)), h.transport = function(t, n) {
                                    if (e.isArray(t)) {
                                        for (var r = t.length - 1; r >= 0; r--) {
                                            var i = t[r];
                                            "string" === e.type(i) && o.transports[i] || (n.log("Invalid transport: " + i + ", removing it from the transports list."), t.splice(r, 1))
                                        }
                                        0 === t.length && (n.log("No transports remain within the specified transport array."), t = null)
                                    } else if (o.transports[t] || "auto" === t) {
                                        if ("auto" === t && o._.ieVersion <= 8) return ["longPolling"]
                                    } else n.log("Invalid transport: " + t.toString() + "."), t = null;
                                    return t
                                }(h.transport, c), !h.transport) throw new Error("SignalR: Invalid transport(s) specified, aborting start.");
                            if (c._.config = h, !s && !0 === h.waitForPageLoad) return c._.deferredStartHandler = function() {
                                c.start(n, i)
                            }, u.bind("load", c._.deferredStartHandler), g.promise();
                            if (c.state === o.connectionState.connecting) return g.promise();
                            if (!1 === p(c, o.connectionState.disconnected, o.connectionState.connecting)) return g.resolve(c), g.promise();
                            ! function(n) {
                                var r, i;
                                n._.configuredStopReconnectingTimeout || (i = function(t) {
                                    var n = o._.format(o.resources.reconnectTimeout, t.disconnectTimeout);
                                    t.log(n), e(t).triggerHandler(f.onError, [o._.error(n, "TimeoutException")]), t.stop(!1, !1)
                                }, n.reconnecting((function() {
                                    var e = this;
                                    e.state === o.connectionState.reconnecting && (r = t.setTimeout((function() {
                                        i(e)
                                    }), e.disconnectTimeout))
                                })), n.stateChanged((function(e) {
                                    e.oldState === o.connectionState.reconnecting && t.clearTimeout(r)
                                })), n._.configuredStopReconnectingTimeout = !0)
                            }(c), v.href = c.url, v.protocol && ":" !== v.protocol ? (c.protocol = v.protocol, c.host = v.host) : (c.protocol = t.document.location.protocol, c.host = v.host || t.document.location.host), c.baseUrl = c.protocol + "//" + c.host, c.wsProtocol = "https:" === c.protocol ? "wss://" : "ws://", "auto" === h.transport && !0 === h.jsonp && (h.transport = "longPolling"), 0 === c.url.indexOf("//") && (c.url = t.location.protocol + c.url, c.log("Protocol relative URL detected, normalizing it to '" + c.url + "'.")), this.isCrossDomain(c.url) && (c.log("Auto detected cross domain url."), "auto" === h.transport && (h.transport = ["webSockets", "serverSentEvents", "longPolling"]), void 0 === h.withCredentials && (h.withCredentials = !0), h.jsonp || (h.jsonp = !e.support.cors, h.jsonp && c.log("Using jsonp because this browser doesn't support CORS.")), c.contentType = o._.defaultContentType), c.withCredentials = h.withCredentials, c.ajaxDataType = h.jsonp ? "jsonp" : "text", e(c).bind(f.onStart, (function(t, n) {
                                "function" === e.type(i) && i.call(c), g.resolve(c)
                            })), c._.initHandler = o.transports._logic.initHandler(c), a = function(n, i) {
                                var s = o._.error(r.noTransportOnInit);
                                if ((i = i || 0) >= n.length) return 0 === i ? c.log("No transports supported by the server were selected.") : 1 === i ? c.log("No fallback transports were selected.") : c.log("Fallback transports exhausted."), e(c).triggerHandler(f.onError, [s]), g.reject(s), void c.stop();
                                if (c.state !== o.connectionState.disconnected) {
                                    var l = n[i],
                                        h = o.transports[l],
                                        v = function() {
                                            a(n, i + 1)
                                        };
                                    c.transport = h;
                                    try {
                                        c._.initHandler.start(h, (function() {
                                            var n = o._.firefoxMajorVersion(t.navigator.userAgent) >= 11,
                                                r = !!c.withCredentials && n;
                                            c.log("The start request succeeded. Transitioning to the connected state."), d(c) && o.transports._logic.monitorKeepAlive(c), o.transports._logic.startHeartbeat(c), o._.configurePingInterval(c), p(c, o.connectionState.connecting, o.connectionState.connected) || c.log("WARNING! The connection was not in the connecting state."), c._.connectingMessageBuffer.drain(), e(c).triggerHandler(f.onStart), u.bind("unload", (function() {
                                                c.log("Window unloading, stopping the connection."), c.stop(r)
                                            })), n && u.bind("beforeunload", (function() {
                                                t.setTimeout((function() {
                                                    c.stop(r)
                                                }), 0)
                                            }))
                                        }), v)
                                    } catch (e) {
                                        c.log(h.name + " transport threw '" + e.message + "' when attempting to start."), v()
                                    }
                                }
                            };
                            var b = c.url + "/negotiate",
                                m = function(t, n) {
                                    var i = o._.error(r.errorOnNegotiate, t, n._.negotiateRequest);
                                    e(n).triggerHandler(f.onError, i), g.reject(i), n.stop()
                                };
                            return e(c).triggerHandler(f.onStarting), b = o.transports._logic.prepareQueryString(c, b), c.log("Negotiating with '" + b + "'."), c._.negotiateRequest = o.transports._logic.ajax(c, {
                                url: b,
                                error: function(e, t) {
                                    t !== l ? m(e, c) : g.reject(o._.error(r.stoppedWhileNegotiating, null, c._.negotiateRequest))
                                },
                                success: function(t) {
                                    var n, i, s, u = [],
                                        l = [];
                                    try {
                                        n = c._parseResponse(t)
                                    } catch (e) {
                                        return void m(o._.error(r.errorParsingNegotiateResponse, e), c)
                                    }
                                    if (i = c._.keepAliveData, c.appRelativeUrl = n.Url, c.id = n.ConnectionId, c.token = n.ConnectionToken, c.webSocketServerUrl = n.WebSocketServerUrl, c._.pollTimeout = 1e3 * n.ConnectionTimeout + 1e4, c.disconnectTimeout = 1e3 * n.DisconnectTimeout, c._.totalTransportConnectTimeout = c.transportConnectTimeout + 1e3 * n.TransportConnectTimeout, n.KeepAliveTimeout ? (i.activated = !0, i.timeout = 1e3 * n.KeepAliveTimeout, i.timeoutWarning = i.timeout * c.keepAliveWarnAt, c._.beatInterval = (i.timeout - i.timeoutWarning) / 3) : i.activated = !1, c.reconnectWindow = c.disconnectTimeout + (i.timeout || 0), !n.ProtocolVersion || n.ProtocolVersion !== c.clientProtocol) return s = o._.error(o._.format(r.protocolIncompatible, c.clientProtocol, n.ProtocolVersion)), e(c).triggerHandler(f.onError, [s]), void g.reject(s);
                                    e.each(o.transports, (function(e) {
                                        if (0 === e.indexOf("_") || "webSockets" === e && !n.TryWebSockets) return !0;
                                        l.push(e)
                                    })), e.isArray(h.transport) ? e.each(h.transport, (function(t, n) {
                                        e.inArray(n, l) >= 0 && u.push(n)
                                    })) : "auto" === h.transport ? u = l : e.inArray(h.transport, l) >= 0 && u.push(h.transport), a(u)
                                }
                            }), g.promise()
                        },
                        starting: function(t) {
                            var n = this;
                            return e(n).bind(f.onStarting, (function(e, r) {
                                t.call(n)
                            })), n
                        },
                        send: function(e) {
                            var t = this;
                            if (t.state === o.connectionState.disconnected) throw new Error("SignalR: Connection must be started before data can be sent. Call .start() before .send()");
                            if (t.state === o.connectionState.connecting) throw new Error("SignalR: Connection has not been fully initialized. Use .start().done() or .start().fail() to run logic after the connection has started.");
                            return t.transport.send(t, e), t
                        },
                        received: function(t) {
                            var n = this;
                            return e(n).bind(f.onReceived, (function(e, r) {
                                t.call(n, r)
                            })), n
                        },
                        stateChanged: function(t) {
                            var n = this;
                            return e(n).bind(f.onStateChanged, (function(e, r) {
                                t.call(n, r)
                            })), n
                        },
                        error: function(t) {
                            var n = this;
                            return e(n).bind(f.onError, (function(e, r, o) {
                                n.lastError = r, t.call(n, r, o)
                            })), n
                        },
                        disconnected: function(t) {
                            var n = this;
                            return e(n).bind(f.onDisconnect, (function(e, r) {
                                t.call(n)
                            })), n
                        },
                        connectionSlow: function(t) {
                            var n = this;
                            return e(n).bind(f.onConnectionSlow, (function(e, r) {
                                t.call(n)
                            })), n
                        },
                        reconnecting: function(t) {
                            var n = this;
                            return e(n).bind(f.onReconnecting, (function(e, r) {
                                t.call(n)
                            })), n
                        },
                        reconnected: function(t) {
                            var n = this;
                            return e(n).bind(f.onReconnect, (function(e, r) {
                                t.call(n)
                            })), n
                        },
                        stop: function(n, i) {
                            var a = this,
                                c = a._deferral;
                            return a._.deferredStartHandler && u.unbind("load", a._.deferredStartHandler), delete a._.config, delete a._.deferredStartHandler, s || a._.config && !0 !== a._.config.waitForPageLoad ? a.state !== o.connectionState.disconnected ? (a.log("Stopping connection."), t.clearTimeout(a._.beatHandle), t.clearInterval(a._.pingIntervalId), a.transport && (a.transport.stop(a), !1 !== i && a.transport.abort(a, n), d(a) && o.transports._logic.stopMonitoringKeepAlive(a), a.transport = null), a._.negotiateRequest && (a._.negotiateRequest.abort(l), delete a._.negotiateRequest), a._.initHandler && a._.initHandler.stop(), delete a._deferral, delete a.messageId, delete a.groupsToken, delete a.id, delete a._.pingIntervalId, delete a._.lastMessageAt, delete a._.lastActiveAt, a._.connectingMessageBuffer.clear(), e(a).unbind(f.onStart), p(a, a.state, o.connectionState.disconnected), e(a).triggerHandler(f.onDisconnect), a) : void 0 : (a.log("Stopping connection prior to negotiate."), void(c && c.reject(o._.error(r.stoppedWhileLoading))))
                        },
                        log: function(e) {
                            ! function(e, n) {
                                var r;
                                !1 !== n && void 0 !== t.console && (r = "[" + (new Date).toTimeString() + "] SignalR: " + e, t.console.debug ? t.console.debug(r) : t.console.log && t.console.log(r))
                            }(e, this.logging)
                        }
                    }, o.fn.init.prototype = o.fn, o.noConflict = function() {
                        return e.connection === o && (e.connection = i), o
                    }, e.connection && (i = e.connection), e.connection = e.signalR = o
                }(window.jQuery, window),
                function(t, n, r) {
                    var o, i = t.signalR,
                        a = t.signalR.events,
                        c = t.signalR.changeState,
                        s = "__Start Aborted__";

                    function u(e) {
                        e._.keepAliveData.monitoring && function(e) {
                            var n, r = e._.keepAliveData;
                            e.state === i.connectionState.connected && ((n = (new Date).getTime() - e._.lastMessageAt) >= r.timeout ? (e.log("Keep alive timed out.  Notifying transport that connection has been lost."), e.transport.lostConnection(e)) : n >= r.timeoutWarning ? r.userNotified || (e.log("Keep alive has been missed, connection may be dead/slow."), t(e).triggerHandler(a.onConnectionSlow), r.userNotified = !0) : r.userNotified = !1)
                        }(e), o.markActive(e) && (e._.beatHandle = n.setTimeout((function() {
                            u(e)
                        }), e._.beatInterval))
                    }

                    function l(e, t) {
                        var n = e.url + t;
                        return e.transport && (n += "?transport=" + e.transport.name), o.prepareQueryString(e, n)
                    }

                    function f(e) {
                        this.connection = e, this.startRequested = !1, this.startCompleted = !1, this.connectionStopped = !1
                    }
                    i.transports = {}, f.prototype = {
                        start: function(e, t, r) {
                            var o = this,
                                i = o.connection,
                                a = !1;
                            o.startRequested || o.connectionStopped ? i.log("WARNING! " + e.name + " transport cannot be started. Initialization ongoing or completed.") : (i.log(e.name + " transport starting."), e.start(i, (function() {
                                a || o.initReceived(e, t)
                            }), (function(t) {
                                return a || (a = !0, o.transportFailed(e, t, r)), !o.startCompleted || o.connectionStopped
                            })), o.transportTimeoutHandle = n.setTimeout((function() {
                                a || (a = !0, i.log(e.name + " transport timed out when trying to connect."), o.transportFailed(e, undefined, r))
                            }), i._.totalTransportConnectTimeout))
                        },
                        stop: function() {
                            this.connectionStopped = !0, n.clearTimeout(this.transportTimeoutHandle), i.transports._logic.tryAbortStartRequest(this.connection)
                        },
                        initReceived: function(e, t) {
                            var r = this,
                                o = r.connection;
                            r.startRequested ? o.log("WARNING! The client received multiple init messages.") : r.connectionStopped || (r.startRequested = !0, n.clearTimeout(r.transportTimeoutHandle), o.log(e.name + " transport connected. Initiating start request."), i.transports._logic.ajaxStart(o, (function() {
                                r.startCompleted = !0, t()
                            })))
                        },
                        transportFailed: function(e, r, o) {
                            var c, s = this.connection,
                                u = s._deferral;
                            this.connectionStopped || (n.clearTimeout(this.transportTimeoutHandle), this.startRequested ? this.startCompleted || (c = i._.error(i.resources.errorDuringStartRequest, r), s.log(e.name + " transport failed during the start request. Stopping the connection."), t(s).triggerHandler(a.onError, [c]), u && u.reject(c), s.stop()) : (e.stop(s), s.log(e.name + " transport failed to connect. Attempting to fall back."), o()))
                        }
                    }, o = i.transports._logic = {
                        ajax: function(e, n) {
                            return t.ajax(t.extend(!0, {}, t.signalR.ajaxDefaults, {
                                type: "GET",
                                data: {},
                                xhrFields: {
                                    withCredentials: e.withCredentials
                                },
                                contentType: e.contentType,
                                dataType: e.ajaxDataType
                            }, n))
                        },
                        pingServer: function(e) {
                            var n, r, a = t.Deferred();
                            return e.transport ? (n = e.url + "/ping", n = o.addQs(n, e.qs), r = o.ajax(e, {
                                url: n,
                                success: function(t) {
                                    var n;
                                    try {
                                        n = e._parseResponse(t)
                                    } catch (t) {
                                        return a.reject(i._.transportError(i.resources.pingServerFailedParse, e.transport, t, r)), void e.stop()
                                    }
                                    "pong" === n.Response ? a.resolve() : a.reject(i._.transportError(i._.format(i.resources.pingServerFailedInvalidResponse, t), e.transport, null, r))
                                },
                                error: function(t) {
                                    401 === t.status || 403 === t.status ? (a.reject(i._.transportError(i._.format(i.resources.pingServerFailedStatusCode, t.status), e.transport, t, r)), e.stop()) : a.reject(i._.transportError(i.resources.pingServerFailed, e.transport, t, r))
                                }
                            })) : a.reject(i._.transportError(i.resources.noConnectionTransport, e.transport)), a.promise()
                        },
                        prepareQueryString: function(e, t) {
                            var r;
                            return r = o.addQs(t, "clientProtocol=" + e.clientProtocol), r = o.addQs(r, e.qs), e.token && (r += "&connectionToken=" + n.encodeURIComponent(e.token)), e.data && (r += "&connectionData=" + n.encodeURIComponent(e.data)), r
                        },
                        addQs: function(n, r) {
                            var o, i = -1 !== n.indexOf("?") ? "&" : "?";
                            if (!r) return n;
                            if ("object" === e(r)) return n + i + t.param(r);
                            if ("string" == typeof r) return "?" !== (o = r.charAt(0)) && "&" !== o || (i = ""), n + i + r;
                            throw new Error("Query string property must be either a string or object.")
                        },
                        getUrl: function(e, t, r, i, a) {
                            var c = ("webSockets" === t ? "" : e.baseUrl) + e.appRelativeUrl,
                                s = "transport=" + t;
                            return !a && e.groupsToken && (s += "&groupsToken=" + n.encodeURIComponent(e.groupsToken)), r ? (c += i ? "/poll" : "/reconnect", !a && e.messageId && (s += "&messageId=" + n.encodeURIComponent(e.messageId))) : c += "/connect", c += "?" + s, c = o.prepareQueryString(e, c), a || (c += "&tid=" + Math.floor(11 * Math.random())), c
                        },
                        maximizePersistentResponse: function(e) {
                            return {
                                MessageId: e.C,
                                Messages: e.M,
                                Initialized: void 0 !== e.S,
                                ShouldReconnect: void 0 !== e.T,
                                LongPollDelay: e.L,
                                GroupsToken: e.G
                            }
                        },
                        updateGroups: function(e, t) {
                            t && (e.groupsToken = t)
                        },
                        stringifySend: function(e, t) {
                            return "string" == typeof t || null == t ? t : e.json.stringify(t)
                        },
                        ajaxSend: function(e, n) {
                            var r, c = o.stringifySend(e, n),
                                s = l(e, "/send"),
                                u = function(e, o) {
                                    t(o).triggerHandler(a.onError, [i._.transportError(i.resources.sendFailed, o.transport, e, r), n])
                                };
                            return r = o.ajax(e, {
                                url: s,
                                type: "jsonp" === e.ajaxDataType ? "GET" : "POST",
                                contentType: i._.defaultContentType,
                                data: {
                                    data: c
                                },
                                success: function(t) {
                                    var n;
                                    if (t) {
                                        try {
                                            n = e._parseResponse(t)
                                        } catch (t) {
                                            return u(t, e), void e.stop()
                                        }
                                        o.triggerReceived(e, n)
                                    }
                                },
                                error: function(t, n) {
                                    "abort" !== n && "parsererror" !== n && u(t, e)
                                }
                            })
                        },
                        ajaxAbort: function(e, t) {
                            if (void 0 !== e.transport) {
                                t = void 0 === t || t;
                                var n = l(e, "/abort");
                                o.ajax(e, {
                                    url: n,
                                    async: t,
                                    timeout: 1e3,
                                    type: "POST"
                                }), e.log("Fired ajax abort async = " + t + ".")
                            }
                        },
                        ajaxStart: function(e, n) {
                            var r = function(t) {
                                    var n = e._deferral;
                                    n && n.reject(t)
                                },
                                c = function(n) {
                                    e.log("The start request failed. Stopping the connection."), t(e).triggerHandler(a.onError, [n]), r(n), e.stop()
                                };
                            e._.startRequest = o.ajax(e, {
                                url: l(e, "/start"),
                                success: function(t, r, o) {
                                    var a;
                                    try {
                                        a = e._parseResponse(t)
                                    } catch (e) {
                                        return void c(i._.error(i._.format(i.resources.errorParsingStartResponse, t), e, o))
                                    }
                                    "started" === a.Response ? n() : c(i._.error(i._.format(i.resources.invalidStartResponse, t), null, o))
                                },
                                error: function(t, n, o) {
                                    n !== s ? c(i._.error(i.resources.errorDuringStartRequest, o, t)) : (e.log("The start request aborted because connection.stop() was called."), r(i._.error(i.resources.stoppedDuringStartRequest, null, t)))
                                }
                            })
                        },
                        tryAbortStartRequest: function(e) {
                            e._.startRequest && (e._.startRequest.abort(s), delete e._.startRequest)
                        },
                        tryInitialize: function(e, t, n) {
                            t.Initialized && n ? n() : t.Initialized && e.log("WARNING! The client received an init message after reconnecting.")
                        },
                        triggerReceived: function(e, n) {
                            e._.connectingMessageBuffer.tryBuffer(n) || t(e).triggerHandler(a.onReceived, [n])
                        },
                        processMessages: function(e, n, r) {
                            var i;
                            o.markLastMessage(e), n && (i = o.maximizePersistentResponse(n), o.updateGroups(e, i.GroupsToken), i.MessageId && (e.messageId = i.MessageId), i.Messages && (t.each(i.Messages, (function(t, n) {
                                o.triggerReceived(e, n)
                            })), o.tryInitialize(e, i, r)))
                        },
                        monitorKeepAlive: function(e) {
                            var n = e._.keepAliveData;
                            n.monitoring ? e.log("Tried to monitor keep alive but it's already being monitored.") : (n.monitoring = !0, o.markLastMessage(e), e._.keepAliveData.reconnectKeepAliveUpdate = function() {
                                o.markLastMessage(e)
                            }, t(e).bind(a.onReconnect, e._.keepAliveData.reconnectKeepAliveUpdate), e.log("Now monitoring keep alive with a warning timeout of " + n.timeoutWarning + ", keep alive timeout of " + n.timeout + " and disconnecting timeout of " + e.disconnectTimeout))
                        },
                        stopMonitoringKeepAlive: function(e) {
                            var n = e._.keepAliveData;
                            n.monitoring && (n.monitoring = !1, t(e).unbind(a.onReconnect, e._.keepAliveData.reconnectKeepAliveUpdate), e._.keepAliveData = {}, e.log("Stopping the monitoring of the keep alive."))
                        },
                        startHeartbeat: function(e) {
                            e._.lastActiveAt = (new Date).getTime(), u(e)
                        },
                        markLastMessage: function(e) {
                            e._.lastMessageAt = (new Date).getTime()
                        },
                        markActive: function(e) {
                            return !!o.verifyLastActive(e) && (e._.lastActiveAt = (new Date).getTime(), !0)
                        },
                        isConnectedOrReconnecting: function(e) {
                            return e.state === i.connectionState.connected || e.state === i.connectionState.reconnecting
                        },
                        ensureReconnectingState: function(e) {
                            return !0 === c(e, i.connectionState.connected, i.connectionState.reconnecting) && t(e).triggerHandler(a.onReconnecting), e.state === i.connectionState.reconnecting
                        },
                        clearReconnectTimeout: function(e) {
                            e && e._.reconnectTimeout && (n.clearTimeout(e._.reconnectTimeout), delete e._.reconnectTimeout)
                        },
                        verifyLastActive: function(e) {
                            if ((new Date).getTime() - e._.lastActiveAt >= e.reconnectWindow) {
                                var n = i._.format(i.resources.reconnectWindowTimeout, new Date(e._.lastActiveAt), e.reconnectWindow);
                                return e.log(n), t(e).triggerHandler(a.onError, [i._.error(n, "TimeoutException")]), e.stop(!1, !1), !1
                            }
                            return !0
                        },
                        reconnect: function(e, t) {
                            var r = i.transports[t];
                            if (o.isConnectedOrReconnecting(e) && !e._.reconnectTimeout) {
                                if (!o.verifyLastActive(e)) return;
                                e._.reconnectTimeout = n.setTimeout((function() {
                                    o.verifyLastActive(e) && (r.stop(e), o.ensureReconnectingState(e) && (e.log(t + " reconnecting."), r.start(e)))
                                }), e.reconnectDelay)
                            }
                        },
                        handleParseFailure: function(e, n, r, o, c) {
                            var s = i._.transportError(i._.format(i.resources.parseFailed, n), e.transport, r, c);
                            o && o(s) ? e.log("Failed to parse server response while attempting to connect.") : (t(e).triggerHandler(a.onError, [s]), e.stop())
                        },
                        initHandler: function(e) {
                            return new f(e)
                        },
                        foreverFrame: {
                            count: 0,
                            connections: {}
                        }
                    }
                }(window.jQuery, window),
                function(e, t, n) {
                    var r = e.signalR,
                        o = e.signalR.events,
                        i = e.signalR.changeState,
                        a = r.transports._logic;
                    r.transports.webSockets = {
                        name: "webSockets",
                        supportsKeepAlive: function() {
                            return !0
                        },
                        send: function(t, n) {
                            var i = a.stringifySend(t, n);
                            try {
                                t.socket.send(i)
                            } catch (i) {
                                e(t).triggerHandler(o.onError, [r._.transportError(r.resources.webSocketsInvalidState, t.transport, i, t.socket), n])
                            }
                        },
                        start: function(n, c, s) {
                            var u, l = !1,
                                f = this,
                                p = !c,
                                d = e(n);
                            t.WebSocket ? n.socket || (u = n.webSocketServerUrl ? n.webSocketServerUrl : n.wsProtocol + n.host, u += a.getUrl(n, this.name, p), n.log("Connecting to websocket endpoint '" + u + "'."), n.socket = new t.WebSocket(u), n.socket.onopen = function() {
                                l = !0, n.log("Websocket opened."), a.clearReconnectTimeout(n), !0 === i(n, r.connectionState.reconnecting, r.connectionState.connected) && d.triggerHandler(o.onReconnect)
                            }, n.socket.onclose = function(t) {
                                var i;
                                this === n.socket && (l && void 0 !== t.wasClean && !1 === t.wasClean ? (i = r._.transportError(r.resources.webSocketClosed, n.transport, t), n.log("Unclean disconnect from websocket: " + (t.reason || "[no reason given]."))) : n.log("Websocket closed."), s && s(i) || (i && e(n).triggerHandler(o.onError, [i]), f.reconnect(n)))
                            }, n.socket.onmessage = function(t) {
                                var r;
                                try {
                                    r = n._parseResponse(t.data)
                                } catch (e) {
                                    return void a.handleParseFailure(n, t.data, e, s, t)
                                }
                                r && (e.isEmptyObject(r) || r.M ? a.processMessages(n, r, c) : a.triggerReceived(n, r))
                            }) : s()
                        },
                        reconnect: function(e) {
                            a.reconnect(e, this.name)
                        },
                        lostConnection: function(e) {
                            this.reconnect(e)
                        },
                        stop: function(e) {
                            a.clearReconnectTimeout(e), e.socket && (e.log("Closing the Websocket."), e.socket.close(), e.socket = null)
                        },
                        abort: function(e, t) {
                            a.ajaxAbort(e, t)
                        }
                    }
                }(window.jQuery, window),
                function(e, t, n) {
                    var r = e.signalR,
                        o = e.signalR.events,
                        i = e.signalR.changeState,
                        a = r.transports._logic,
                        c = function(e) {
                            t.clearTimeout(e._.reconnectAttemptTimeoutHandle), delete e._.reconnectAttemptTimeoutHandle
                        };
                    r.transports.serverSentEvents = {
                        name: "serverSentEvents",
                        supportsKeepAlive: function() {
                            return !0
                        },
                        timeOut: 3e3,
                        start: function(n, s, u) {
                            var l, f = this,
                                p = !1,
                                d = e(n),
                                h = !s;
                            if (n.eventSource && (n.log("The connection already has an event source. Stopping it."), n.stop()), t.EventSource) {
                                l = a.getUrl(n, this.name, h);
                                try {
                                    n.log("Attempting to connect to SSE endpoint '" + l + "'."), n.eventSource = new t.EventSource(l, {
                                        withCredentials: n.withCredentials
                                    })
                                } catch (e) {
                                    return n.log("EventSource failed trying to connect with error " + e.Message + "."), void(u ? u() : (d.triggerHandler(o.onError, [r._.transportError(r.resources.eventSourceFailedToConnect, n.transport, e)]), h && f.reconnect(n)))
                                }
                                h && (n._.reconnectAttemptTimeoutHandle = t.setTimeout((function() {
                                    !1 === p && n.eventSource.readyState !== t.EventSource.OPEN && f.reconnect(n)
                                }), f.timeOut)), n.eventSource.addEventListener("open", (function(e) {
                                    n.log("EventSource connected."), c(n), a.clearReconnectTimeout(n), !1 === p && (p = !0, !0 === i(n, r.connectionState.reconnecting, r.connectionState.connected) && d.triggerHandler(o.onReconnect))
                                }), !1), n.eventSource.addEventListener("message", (function(e) {
                                    var t;
                                    if ("initialized" !== e.data) {
                                        try {
                                            t = n._parseResponse(e.data)
                                        } catch (t) {
                                            return void a.handleParseFailure(n, e.data, t, u, e)
                                        }
                                        a.processMessages(n, t, s)
                                    }
                                }), !1), n.eventSource.addEventListener("error", (function(e) {
                                    var i = r._.transportError(r.resources.eventSourceError, n.transport, e);
                                    this === n.eventSource && (u && u(i) || (n.log("EventSource readyState: " + n.eventSource.readyState + "."), e.eventPhase === t.EventSource.CLOSED ? (n.log("EventSource reconnecting due to the server connection ending."), f.reconnect(n)) : (n.log("EventSource error."), d.triggerHandler(o.onError, [i]))))
                                }), !1)
                            } else u && (n.log("This browser doesn't support SSE."), u())
                        },
                        reconnect: function(e) {
                            a.reconnect(e, this.name)
                        },
                        lostConnection: function(e) {
                            this.reconnect(e)
                        },
                        send: function(e, t) {
                            a.ajaxSend(e, t)
                        },
                        stop: function(e) {
                            c(e), a.clearReconnectTimeout(e), e && e.eventSource && (e.log("EventSource calling close()."), e.eventSource.close(), e.eventSource = null, delete e.eventSource)
                        },
                        abort: function(e, t) {
                            a.ajaxAbort(e, t)
                        }
                    }
                }(window.jQuery, window),
                function(e, t, n) {
                    var r, o, i = e.signalR,
                        a = e.signalR.events,
                        c = e.signalR.changeState,
                        s = i.transports._logic,
                        u = function() {
                            var e = t.document.createElement("iframe");
                            return e.setAttribute("style", "position:absolute;top:0;left:0;width:0;height:0;visibility:hidden;"), e
                        },
                        l = (r = null, o = 0, {
                            prevent: function() {
                                i._.ieVersion <= 8 && (0 === o && (r = t.setInterval((function() {
                                    var e = u();
                                    t.document.body.appendChild(e), t.document.body.removeChild(e), e = null
                                }), 1e3)), o++)
                            },
                            cancel: function() {
                                1 === o && t.clearInterval(r), o > 0 && o--
                            }
                        });
                    i.transports.foreverFrame = {
                        name: "foreverFrame",
                        supportsKeepAlive: function() {
                            return !0
                        },
                        iframeClearThreshold: 50,
                        start: function(e, n, r) {
                            var o, i = this,
                                a = s.foreverFrame.count += 1,
                                c = u(),
                                f = function() {
                                    e.log("Forever frame iframe finished loading and is no longer receiving messages."), r && r() || i.reconnect(e)
                                };
                            t.EventSource ? r && (e.log("Forever Frame is not supported by SignalR on browsers with SSE support."), r()) : (c.setAttribute("data-signalr-connection-id", e.id), l.prevent(), o = s.getUrl(e, this.name), o += "&frameId=" + a, t.document.documentElement.appendChild(c), e.log("Binding to iframe's load event."), c.addEventListener ? c.addEventListener("load", f, !1) : c.attachEvent && c.attachEvent("onload", f), c.src = o, s.foreverFrame.connections[a] = e, e.frame = c, e.frameId = a, n && (e.onSuccess = function() {
                                e.log("Iframe transport started."), n()
                            }))
                        },
                        reconnect: function(e) {
                            var n = this;
                            s.isConnectedOrReconnecting(e) && s.verifyLastActive(e) && t.setTimeout((function() {
                                if (s.verifyLastActive(e) && e.frame && s.ensureReconnectingState(e)) {
                                    var t = e.frame,
                                        r = s.getUrl(e, n.name, !0) + "&frameId=" + e.frameId;
                                    e.log("Updating iframe src to '" + r + "'."), t.src = r
                                }
                            }), e.reconnectDelay)
                        },
                        lostConnection: function(e) {
                            this.reconnect(e)
                        },
                        send: function(e, t) {
                            s.ajaxSend(e, t)
                        },
                        receive: function(t, n) {
                            var r, o, a;
                            if (t.json !== t._originalJson && (n = t._originalJson.stringify(n)), a = t._parseResponse(n), s.processMessages(t, a, t.onSuccess), t.state === e.signalR.connectionState.connected && (t.frameMessageCount = (t.frameMessageCount || 0) + 1, t.frameMessageCount > i.transports.foreverFrame.iframeClearThreshold && (t.frameMessageCount = 0, (r = t.frame.contentWindow || t.frame.contentDocument) && r.document && r.document.body)))
                                for (o = r.document.body; o.firstChild;) o.removeChild(o.firstChild)
                        },
                        stop: function(e) {
                            var n = null;
                            if (l.cancel(), e.frame) {
                                if (e.frame.stop) e.frame.stop();
                                else try {
                                    (n = e.frame.contentWindow || e.frame.contentDocument).document && n.document.execCommand && n.document.execCommand("Stop")
                                } catch (t) {
                                    e.log("Error occurred when stopping foreverFrame transport. Message = " + t.message + ".")
                                }
                                e.frame.parentNode === t.document.documentElement && t.document.documentElement.removeChild(e.frame), delete s.foreverFrame.connections[e.frameId], e.frame = null, e.frameId = null, delete e.frame, delete e.frameId, delete e.onSuccess, delete e.frameMessageCount, e.log("Stopping forever frame.")
                            }
                        },
                        abort: function(e, t) {
                            s.ajaxAbort(e, t)
                        },
                        getConnection: function(e) {
                            return s.foreverFrame.connections[e]
                        },
                        started: function(t) {
                            !0 === c(t, i.connectionState.reconnecting, i.connectionState.connected) && e(t).triggerHandler(a.onReconnect)
                        }
                    }
                }(window.jQuery, window),
                function(e, t, n) {
                    var r = e.signalR,
                        o = e.signalR.events,
                        i = e.signalR.changeState,
                        a = e.signalR.isDisconnecting,
                        c = r.transports._logic;
                    r.transports.longPolling = {
                        name: "longPolling",
                        supportsKeepAlive: function() {
                            return !1
                        },
                        reconnectDelay: 3e3,
                        start: function(n, s, u) {
                            var l = this,
                                f = function() {
                                    f = e.noop, n.log("LongPolling connected."), s ? s() : n.log("WARNING! The client received an init message after reconnecting.")
                                },
                                p = function(e) {
                                    return !!u(e) && (n.log("LongPolling failed to connect."), !0)
                                },
                                d = n._,
                                h = 0,
                                g = function(n) {
                                    t.clearTimeout(d.reconnectTimeoutId), d.reconnectTimeoutId = null, !0 === i(n, r.connectionState.reconnecting, r.connectionState.connected) && (n.log("Raising the reconnect event"), e(n).triggerHandler(o.onReconnect))
                                };
                            n.pollXhr && (n.log("Polling xhr requests already exists, aborting."), n.stop()), n.messageId = null, d.reconnectTimeoutId = null, d.pollTimeoutId = t.setTimeout((function() {
                                ! function i(s, u) {
                                    var v = !(null === s.messageId),
                                        b = !u,
                                        m = c.getUrl(s, l.name, v, b, !0),
                                        y = {};
                                    s.messageId && (y.messageId = s.messageId), s.groupsToken && (y.groupsToken = s.groupsToken), !0 !== a(s) && (n.log("Opening long polling request to '" + m + "'."), s.pollXhr = c.ajax(n, {
                                        xhrFields: {
                                            onprogress: function() {
                                                c.markLastMessage(n)
                                            }
                                        },
                                        url: m,
                                        type: "POST",
                                        contentType: r._.defaultContentType,
                                        data: y,
                                        timeout: n._.pollTimeout,
                                        success: function(r) {
                                            var o, u, l, v = 0;
                                            n.log("Long poll complete."), h = 0;
                                            try {
                                                o = n._parseResponse(r)
                                            } catch (e) {
                                                return void c.handleParseFailure(s, r, e, p, s.pollXhr)
                                            }
                                            null !== d.reconnectTimeoutId && g(s), o && (u = c.maximizePersistentResponse(o)), c.processMessages(s, o, f), u && "number" === e.type(u.LongPollDelay) && (v = u.LongPollDelay), !0 !== a(s) && ((l = u && u.ShouldReconnect) && !c.ensureReconnectingState(s) || (v > 0 ? d.pollTimeoutId = t.setTimeout((function() {
                                                i(s, l)
                                            }), v) : i(s, l)))
                                        },
                                        error: function(a, u) {
                                            var f = r._.transportError(r.resources.longPollFailed, n.transport, a, s.pollXhr);
                                            if (t.clearTimeout(d.reconnectTimeoutId), d.reconnectTimeoutId = null, "abort" !== u) {
                                                if (!p(f)) {
                                                    if (h++, n.state !== r.connectionState.reconnecting && (n.log("An error occurred using longPolling. Status = " + u + ".  Response = " + a.responseText + "."), e(s).triggerHandler(o.onError, [f])), (n.state === r.connectionState.connected || n.state === r.connectionState.reconnecting) && !c.verifyLastActive(n)) return;
                                                    if (!c.ensureReconnectingState(s)) return;
                                                    d.pollTimeoutId = t.setTimeout((function() {
                                                        i(s, !0)
                                                    }), l.reconnectDelay)
                                                }
                                            } else n.log("Aborted xhr request.")
                                        }
                                    }), v && !0 === u && (d.reconnectTimeoutId = t.setTimeout((function() {
                                        g(s)
                                    }), Math.min(1e3 * (Math.pow(2, h) - 1), 36e5))))
                                }(n)
                            }), 250)
                        },
                        lostConnection: function(e) {
                            e.pollXhr && e.pollXhr.abort("lostConnection")
                        },
                        send: function(e, t) {
                            c.ajaxSend(e, t)
                        },
                        stop: function(e) {
                            t.clearTimeout(e._.pollTimeoutId), t.clearTimeout(e._.reconnectTimeoutId), delete e._.pollTimeoutId, delete e._.reconnectTimeoutId, e.pollXhr && (e.pollXhr.abort(), e.pollXhr = null, delete e.pollXhr)
                        },
                        abort: function(e, t) {
                            c.ajaxAbort(e, t)
                        }
                    }
                }(window.jQuery, window),
                function(e, t, n) {
                    var r = e.signalR;

                    function o(e) {
                        return e + ".hubProxy"
                    }

                    function i(e, t, n) {
                        var r, o = e.length,
                            i = [];
                        for (r = 0; r < o; r += 1) e.hasOwnProperty(r) && (i[r] = t.call(n, e[r], r, e));
                        return i
                    }

                    function a(t) {
                        return e.isFunction(t) || "undefined" === e.type(t) ? null : t
                    }

                    function c(e) {
                        for (var t in e)
                            if (e.hasOwnProperty(t)) return !0;
                        return !1
                    }

                    function s(e, t) {
                        var n, r = e._.invocationCallbacks;
                        for (var o in c(r) && e.log("Clearing hub invocation callbacks with error: " + t + "."), e._.invocationCallbackId = 0, delete e._.invocationCallbacks, e._.invocationCallbacks = {}, r)(n = r[o]).method.call(n.scope, {
                            E: t
                        })
                    }

                    function u(e, t) {
                        return new u.fn.init(e, t)
                    }

                    function l(t, n) {
                        var r = {
                            qs: null,
                            logging: !1,
                            useDefaultPath: !0
                        };
                        return e.extend(r, n), t && !r.useDefaultPath || (t = (t || "") + "/signalr"), new l.fn.init(t, r)
                    }
                    u.fn = u.prototype = {
                        init: function(e, t) {
                            this.state = {}, this.connection = e, this.hubName = t, this._ = {
                                callbackMap: {}
                            }
                        },
                        constructor: u,
                        hasSubscriptions: function() {
                            return c(this._.callbackMap)
                        },
                        on: function(t, n) {
                            var r = this,
                                i = r._.callbackMap;
                            return i[t = t.toLowerCase()] || (i[t] = {}), i[t][n] = function(e, t) {
                                n.apply(r, t)
                            }, e(r).bind(o(t), i[t][n]), r
                        },
                        off: function(t, n) {
                            var r, i = this,
                                a = i._.callbackMap;
                            return (r = a[t = t.toLowerCase()]) && (r[n] ? (e(i).unbind(o(t), r[n]), delete r[n], c(r) || delete a[t]) : n || (e(i).unbind(o(t)), delete a[t])), i
                        },
                        invoke: function(t) {
                            var n = this,
                                o = n.connection,
                                c = e.makeArray(arguments).slice(1),
                                s = i(c, a),
                                u = {
                                    H: n.hubName,
                                    M: t,
                                    A: s,
                                    I: o._.invocationCallbackId
                                },
                                l = e.Deferred(),
                                f = function(i) {
                                    var a, c, s = n._maximizeHubResponse(i);
                                    e.extend(n.state, s.State), s.Progress ? l.notifyWith ? l.notifyWith(n, [s.Progress.Data]) : o._.progressjQueryVersionLogged || (o.log("A hub method invocation progress update was received but the version of jQuery in use (" + e.prototype.jquery + ") does not support progress updates. Upgrade to jQuery 1.7+ to receive progress notifications."), o._.progressjQueryVersionLogged = !0) : s.Error ? (s.StackTrace && o.log(s.Error + "\n" + s.StackTrace + "."), a = s.IsHubException ? "HubException" : "Exception", (c = r._.error(s.Error, a)).data = s.ErrorData, o.log(n.hubName + "." + t + " failed to execute. Error: " + c.message), l.rejectWith(n, [c])) : (o.log("Invoked " + n.hubName + "." + t), l.resolveWith(n, [s.Result]))
                                };
                            return o._.invocationCallbacks[o._.invocationCallbackId.toString()] = {
                                scope: n,
                                method: f
                            }, o._.invocationCallbackId += 1, e.isEmptyObject(n.state) || (u.S = n.state), o.log("Invoking " + n.hubName + "." + t), o.send(u), l.promise()
                        },
                        _maximizeHubResponse: function(e) {
                            return {
                                State: e.S,
                                Result: e.R,
                                Progress: e.P ? {
                                    Id: e.P.I,
                                    Data: e.P.D
                                } : null,
                                Id: e.I,
                                IsHubException: e.H,
                                Error: e.E,
                                StackTrace: e.T,
                                ErrorData: e.D
                            }
                        }
                    }, u.fn.init.prototype = u.fn, l.fn = l.prototype = e.connection(), l.fn.init = function(t, n) {
                        var r = {
                                qs: null,
                                logging: !1,
                                useDefaultPath: !0
                            },
                            i = this;
                        e.extend(r, n), e.signalR.fn.init.call(i, t, r.qs, r.logging), i.proxies = {}, i._.invocationCallbackId = 0, i._.invocationCallbacks = {}, i.received((function(t) {
                            var n, r, a, c, s, u;
                            t && (void 0 !== t.P ? (a = t.P.I.toString(), (c = i._.invocationCallbacks[a]) && c.method.call(c.scope, t)) : void 0 !== t.I ? (a = t.I.toString(), (c = i._.invocationCallbacks[a]) && (i._.invocationCallbacks[a] = null, delete i._.invocationCallbacks[a], c.method.call(c.scope, t))) : (n = this._maximizeClientHubInvocation(t), i.log("Triggering client hub event '" + n.Method + "' on hub '" + n.Hub + "'."), s = n.Hub.toLowerCase(), u = n.Method.toLowerCase(), r = this.proxies[s], e.extend(r.state, n.State), e(r).triggerHandler(o(u), [n.Args])))
                        })), i.error((function(e, t) {
                            var n, r;
                            t && (n = t.I, (r = i._.invocationCallbacks[n]) && (i._.invocationCallbacks[n] = null, delete i._.invocationCallbacks[n], r.method.call(r.scope, {
                                E: e
                            })))
                        })), i.reconnecting((function() {
                            i.transport && "webSockets" === i.transport.name && s(i, "Connection started reconnecting before invocation result was received.")
                        })), i.disconnected((function() {
                            s(i, "Connection was disconnected before invocation result was received.")
                        }))
                    }, l.fn._maximizeClientHubInvocation = function(e) {
                        return {
                            Hub: e.H,
                            Method: e.M,
                            Args: e.A,
                            State: e.S
                        }
                    }, l.fn._registerSubscribedHubs = function() {
                        var t = this;
                        t._subscribedToHubs || (t._subscribedToHubs = !0, t.starting((function() {
                            var n = [];
                            e.each(t.proxies, (function(e) {
                                this.hasSubscriptions() && (n.push({
                                    name: e
                                }), t.log("Client subscribed to hub '" + e + "'."))
                            })), 0 === n.length && t.log("No hubs have been subscribed to.  The client will not receive data from hubs.  To fix, declare at least one client side function prior to connection start for each hub you wish to subscribe to."), t.data = t.json.stringify(n)
                        })))
                    }, l.fn.createHubProxy = function(e) {
                        e = e.toLowerCase();
                        var t = this.proxies[e];
                        return t || (t = u(this, e), this.proxies[e] = t), this._registerSubscribedHubs(), t
                    }, l.fn.init.prototype = l.fn, e.hubConnection = l
                }(window.jQuery, window), window.jQuery.signalR.version = "2.2.2"
            },
            792: function(e) {
                "use strict";
                e.exports = Roblox
            }
        },
        t = {};

    function n(r) {
        if (t[r]) return t[r].exports;
        var o = t[r] = {
            exports: {}
        };
        return e[r](o, o.exports, n), o.exports
    }
    n.n = function(e) {
            var t = e && e.__esModule ? function() {
                return e.default
            } : function() {
                return e
            };
            return n.d(t, {
                a: t
            }), t
        }, n.d = function(e, t) {
            for (var r in t) n.o(t, r) && !n.o(e, r) && Object.defineProperty(e, r, {
                enumerable: !0,
                get: t[r]
            })
        }, n.g = function() {
            if ("object" == typeof globalThis) return globalThis;
            try {
                return this || new Function("return this")()
            } catch (e) {
                if ("object" == typeof window) return window
            }
        }(), n.o = function(e, t) {
            return Object.prototype.hasOwnProperty.call(e, t)
        }, n.r = function(e) {
            "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
                value: "Module"
            }), Object.defineProperty(e, "__esModule", {
                value: !0
            })
        },
        function() {
            "use strict";
            var e = n(544),
                t = n(283);
            n(52), n(797), n(269), n(764);
            (0, e.importFilesUnderPath)(n(104)), (0, e.importFilesUnderPath)(n(746)), (0, e.importFilesUnderPath)(n(710)), (0, e.importFilesUnderPath)(n(908)), (0, e.importFilesUnderPath)(n(348)), window.Roblox.RealTime = {
                Factory: t.Z
            }
        }()
}();
//# sourceMappingURL=https://js.rbxcdn.com/dcad94e52a21670ad13d2a6fc6a56765-realTime.bundle.min.js.map

/* Bundle detector */
window.Roblox && window.Roblox.BundleDetector && window.Roblox.BundleDetector.bundleDetected("RealTime");