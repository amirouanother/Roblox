! function() {
    "use strict";
    var e, t, n, r = Roblox,
        o = {
            currentPageName: null === r.MetaDataValues || void 0 === r.MetaDataValues ? void 0 : r.MetaDataValues.getPageName(),
            defaultIntervalTime: 5e3,
            activeEvents: ["focus", "click", "hover", "scroll", "mouseover", "mouseenter", "mousedown", "dblclick", "keypress", "touchstart", "touchmove"],
            inactiveEvents: ["blur"]
        },
        i = CoreUtilities,
        a = function(e) {
            var t = r.EnvironmentUrls.presenceApi,
                n = {
                    url: "".concat(t, "/v1/presence/register-app-presence"),
                    withCredentials: !0
                },
                o = {
                    location: e
                };
            return i.httpService.post(n, o)
        },
        u = o.activeEvents,
        c = o.inactiveEvents,
        l = o.currentPageName;
    (e = o.defaultIntervalTime, t = !1, n = null, {
        init: function() {
            var r;
            r = document.getElementById("presence-registration-bootstrap-data"), e = Number.isNaN(null == r ? void 0 : r.dataset.interval) ? 3e3 : parseInt(null == r ? void 0 : r.dataset.interval, 10), "True" === (null == r ? void 0 : r.dataset.isEnabled) && (u.forEach((function(e) {
                window.addEventListener(e, (function() {
                    n = e, t = !0
                }))
            })), c.forEach((function(e) {
                return window.addEventListener(e, (function() {
                    t = !1, n = null, console.debug("-------------Inactive -------------")
                })), t
            })), setInterval((function() {
                t && (console.debug("-----------".concat(n, "------------ Active")), a(l).then((function() {})).catch((function(e) {
                    console.debug(e)
                }))), t = !1
            }), e))
        }
    }).init();
    var s = 3e4,
        f = ["click", "dblclick", "focus", "hover", "keypress", "mousedown", "mouseenter", "mouseover", "scroll", "touchmove", "touchstart"],
        v = ["blur"],
        h = function(e, t, n, r) {
            return new(n || (n = Promise))((function(o, i) {
                function a(e) {
                    try {
                        c(r.next(e))
                    } catch (e) {
                        i(e)
                    }
                }

                function u(e) {
                    try {
                        c(r.throw(e))
                    } catch (e) {
                        i(e)
                    }
                }

                function c(e) {
                    var t;
                    e.done ? o(e.value) : (t = e.value, t instanceof n ? t : new n((function(e) {
                        e(t)
                    }))).then(a, u)
                }
                c((r = r.apply(e, t || [])).next())
            }))
        },
        p = function(e, t) {
            var n, r, o, i, a = {
                label: 0,
                sent: function() {
                    if (1 & o[0]) throw o[1];
                    return o[1]
                },
                trys: [],
                ops: []
            };
            return i = {
                next: u(0),
                throw: u(1),
                return: u(2)
            }, "function" == typeof Symbol && (i[Symbol.iterator] = function() {
                return this
            }), i;

            function u(i) {
                return function(u) {
                    return function(i) {
                        if (n) throw new TypeError("Generator is already executing.");
                        for (; a;) try {
                            if (n = 1, r && (o = 2 & i[0] ? r.return : i[0] ? r.throw || ((o = r.return) && o.call(r), 0) : r.next) && !(o = o.call(r, i[1])).done) return o;
                            switch (r = 0, o && (i = [2 & i[0], o.value]), i[0]) {
                                case 0:
                                case 1:
                                    o = i;
                                    break;
                                case 4:
                                    return a.label++, {
                                        value: i[1],
                                        done: !1
                                    };
                                case 5:
                                    a.label++, r = i[1], i = [0];
                                    continue;
                                case 7:
                                    i = a.ops.pop(), a.trys.pop();
                                    continue;
                                default:
                                    if (!(o = a.trys, (o = o.length > 0 && o[o.length - 1]) || 6 !== i[0] && 2 !== i[0])) {
                                        a = 0;
                                        continue
                                    }
                                    if (3 === i[0] && (!o || i[1] > o[0] && i[1] < o[3])) {
                                        a.label = i[1];
                                        break
                                    }
                                    if (6 === i[0] && a.label < o[1]) {
                                        a.label = o[1], o = i;
                                        break
                                    }
                                    if (o && a.label < o[2]) {
                                        a.label = o[2], a.ops.push(i);
                                        break
                                    }
                                    o[2] && a.ops.pop(), a.trys.pop();
                                    continue
                            }
                            i = t.call(e, a)
                        } catch (e) {
                            i = [6, e], r = 0
                        } finally {
                            n = o = 0
                        }
                        if (5 & i[0]) throw i[1];
                        return {
                            value: i[0] ? i[1] : void 0,
                            done: !0
                        }
                    }([i, u])
                }
            }
        };
    var d = function() {
            var e;
            return h(this, void 0, void 0, (function() {
                var t, n;
                return p(this, (function(o) {
                    switch (o.label) {
                        case 0:
                            t = r.EnvironmentUrls.apiGatewayUrl, o.label = 1;
                        case 1:
                            return o.trys.push([1, 3, , 4]), [4, i.httpService.post({
                                url: t + "/user-heartbeats-api/pulse",
                                withCredentials: !0
                            }, {
                                clientSideTimestampEpochMs: Date.now(),
                                sessionInfo: {
                                    sessionId: (a = /sessionid=([a-f0-9-]{36})/.exec(document.cookie), a && a.length >= 2 ? a[1] : "unknown")
                                },
                                locationInfo: {
                                    robloxWebsiteLocationInfo: {
                                        url: null === (e = window.location) || void 0 === e ? void 0 : e.href
                                    }
                                }
                            })];
                        case 2:
                            return o.sent(), [3, 4];
                        case 3:
                            return n = o.sent(), console.error(n), [3, 4];
                        case 4:
                            return [2]
                    }
                    var a
                }))
            }))
        },
        b = function(e, t, n, r) {
            return new(n || (n = Promise))((function(o, i) {
                function a(e) {
                    try {
                        c(r.next(e))
                    } catch (e) {
                        i(e)
                    }
                }

                function u(e) {
                    try {
                        c(r.throw(e))
                    } catch (e) {
                        i(e)
                    }
                }

                function c(e) {
                    var t;
                    e.done ? o(e.value) : (t = e.value, t instanceof n ? t : new n((function(e) {
                        e(t)
                    }))).then(a, u)
                }
                c((r = r.apply(e, t || [])).next())
            }))
        },
        y = function(e, t) {
            var n, r, o, i, a = {
                label: 0,
                sent: function() {
                    if (1 & o[0]) throw o[1];
                    return o[1]
                },
                trys: [],
                ops: []
            };
            return i = {
                next: u(0),
                throw: u(1),
                return: u(2)
            }, "function" == typeof Symbol && (i[Symbol.iterator] = function() {
                return this
            }), i;

            function u(i) {
                return function(u) {
                    return function(i) {
                        if (n) throw new TypeError("Generator is already executing.");
                        for (; a;) try {
                            if (n = 1, r && (o = 2 & i[0] ? r.return : i[0] ? r.throw || ((o = r.return) && o.call(r), 0) : r.next) && !(o = o.call(r, i[1])).done) return o;
                            switch (r = 0, o && (i = [2 & i[0], o.value]), i[0]) {
                                case 0:
                                case 1:
                                    o = i;
                                    break;
                                case 4:
                                    return a.label++, {
                                        value: i[1],
                                        done: !1
                                    };
                                case 5:
                                    a.label++, r = i[1], i = [0];
                                    continue;
                                case 7:
                                    i = a.ops.pop(), a.trys.pop();
                                    continue;
                                default:
                                    if (!(o = a.trys, (o = o.length > 0 && o[o.length - 1]) || 6 !== i[0] && 2 !== i[0])) {
                                        a = 0;
                                        continue
                                    }
                                    if (3 === i[0] && (!o || i[1] > o[0] && i[1] < o[3])) {
                                        a.label = i[1];
                                        break
                                    }
                                    if (6 === i[0] && a.label < o[1]) {
                                        a.label = o[1], o = i;
                                        break
                                    }
                                    if (o && a.label < o[2]) {
                                        a.label = o[2], a.ops.push(i);
                                        break
                                    }
                                    o[2] && a.ops.pop(), a.trys.pop();
                                    continue
                            }
                            i = t.call(e, a)
                        } catch (e) {
                            i = [6, e], r = 0
                        } finally {
                            n = o = 0
                        }
                        if (5 & i[0]) throw i[1];
                        return {
                            value: i[0] ? i[1] : void 0,
                            done: !0
                        }
                    }([i, u])
                }
            }
        },
        w = function() {
            function e(e) {
                this.isActive = !1, this.intervalTimeMs = 0, this.timeoutActive = !1, this.intervalTimeMs = e
            }
            return e.prototype.start = function() {
                return this.sendPulseAndSetTimeout()
            }, e.prototype.onActiveEvent = function() {
                return b(this, void 0, Promise, (function() {
                    return y(this, (function(e) {
                        switch (e.label) {
                            case 0:
                                return this.timeoutActive ? [3, 2] : [4, this.sendPulseAndSetTimeout()];
                            case 1:
                                return e.sent(), [3, 3];
                            case 2:
                                this.isActive = !0, e.label = 3;
                            case 3:
                                return [2]
                        }
                    }))
                }))
            }, e.prototype.onInactiveEvent = function() {
                this.isActive = !1
            }, e.prototype.sendPulseAndSetTimeout = function() {
                return b(this, void 0, Promise, (function() {
                    var e = this;
                    return y(this, (function(t) {
                        switch (t.label) {
                            case 0:
                                return this.timeoutActive = !0, [4, d()];
                            case 1:
                                return t.sent(), setTimeout((function() {
                                    return e.onTimeout()
                                }), this.intervalTimeMs), [2]
                        }
                    }))
                }))
            }, e.prototype.onTimeout = function() {
                return b(this, void 0, Promise, (function() {
                    return y(this, (function(e) {
                        switch (e.label) {
                            case 0:
                                return this.isActive ? [4, this.sendPulseAndSetTimeout()] : [3, 2];
                            case 1:
                                return e.sent(), this.isActive = !1, [3, 3];
                            case 2:
                                this.timeoutActive = !1, e.label = 3;
                            case 3:
                                return [2]
                        }
                    }))
                }))
            }, e
        }(),
        m = function(e, t, n, r) {
            return new(n || (n = Promise))((function(o, i) {
                function a(e) {
                    try {
                        c(r.next(e))
                    } catch (e) {
                        i(e)
                    }
                }

                function u(e) {
                    try {
                        c(r.throw(e))
                    } catch (e) {
                        i(e)
                    }
                }

                function c(e) {
                    var t;
                    e.done ? o(e.value) : (t = e.value, t instanceof n ? t : new n((function(e) {
                        e(t)
                    }))).then(a, u)
                }
                c((r = r.apply(e, t || [])).next())
            }))
        },
        g = function(e, t) {
            var n, r, o, i, a = {
                label: 0,
                sent: function() {
                    if (1 & o[0]) throw o[1];
                    return o[1]
                },
                trys: [],
                ops: []
            };
            return i = {
                next: u(0),
                throw: u(1),
                return: u(2)
            }, "function" == typeof Symbol && (i[Symbol.iterator] = function() {
                return this
            }), i;

            function u(i) {
                return function(u) {
                    return function(i) {
                        if (n) throw new TypeError("Generator is already executing.");
                        for (; a;) try {
                            if (n = 1, r && (o = 2 & i[0] ? r.return : i[0] ? r.throw || ((o = r.return) && o.call(r), 0) : r.next) && !(o = o.call(r, i[1])).done) return o;
                            switch (r = 0, o && (i = [2 & i[0], o.value]), i[0]) {
                                case 0:
                                case 1:
                                    o = i;
                                    break;
                                case 4:
                                    return a.label++, {
                                        value: i[1],
                                        done: !1
                                    };
                                case 5:
                                    a.label++, r = i[1], i = [0];
                                    continue;
                                case 7:
                                    i = a.ops.pop(), a.trys.pop();
                                    continue;
                                default:
                                    if (!(o = a.trys, (o = o.length > 0 && o[o.length - 1]) || 6 !== i[0] && 2 !== i[0])) {
                                        a = 0;
                                        continue
                                    }
                                    if (3 === i[0] && (!o || i[1] > o[0] && i[1] < o[3])) {
                                        a.label = i[1];
                                        break
                                    }
                                    if (6 === i[0] && a.label < o[1]) {
                                        a.label = o[1], o = i;
                                        break
                                    }
                                    if (o && a.label < o[2]) {
                                        a.label = o[2], a.ops.push(i);
                                        break
                                    }
                                    o[2] && a.ops.pop(), a.trys.pop();
                                    continue
                            }
                            i = t.call(e, a)
                        } catch (e) {
                            i = [6, e], r = 0
                        } finally {
                            n = o = 0
                        }
                        if (5 & i[0]) throw i[1];
                        return {
                            value: i[0] ? i[1] : void 0,
                            done: !0
                        }
                    }([i, u])
                }
            }
        };
    var E = {
            loadGuacConfig: function() {
                var e, t;
                return m(this, void 0, Promise, (function() {
                    var n, o, a, u;
                    return g(this, (function(c) {
                        switch (c.label) {
                            case 0:
                                n = r.EnvironmentUrls.apiGatewayUrl, c.label = 1;
                            case 1:
                                return c.trys.push([1, 3, , 4]), [4, i.httpService.get({
                                    url: n + "/universal-app-configuration/v1/behaviors/user-heartbeats/content"
                                })];
                            case 2:
                                return o = c.sent(), (a = null == o ? void 0 : o.data) ? [2, {
                                    isEnabled: Boolean(a.isEnabled),
                                    rolloutPercentage: null !== (e = a.rolloutPercentage) && void 0 !== e ? e : 0,
                                    intervalTimeMs: null !== (t = a.intervalTimeMs) && void 0 !== t ? t : s
                                }] : [2, {
                                    isEnabled: !1,
                                    rolloutPercentage: 0,
                                    intervalTimeMs: s
                                }];
                            case 3:
                                return u = c.sent(), console.error(u), [2, {
                                    isEnabled: !1,
                                    rolloutPercentage: 0,
                                    intervalTimeMs: s
                                }];
                            case 4:
                                return [2]
                        }
                    }))
                }))
            }
        },
        k = function(e, t, n, r) {
            return new(n || (n = Promise))((function(o, i) {
                function a(e) {
                    try {
                        c(r.next(e))
                    } catch (e) {
                        i(e)
                    }
                }

                function u(e) {
                    try {
                        c(r.throw(e))
                    } catch (e) {
                        i(e)
                    }
                }

                function c(e) {
                    var t;
                    e.done ? o(e.value) : (t = e.value, t instanceof n ? t : new n((function(e) {
                        e(t)
                    }))).then(a, u)
                }
                c((r = r.apply(e, t || [])).next())
            }))
        },
        x = function(e, t) {
            var n, r, o, i, a = {
                label: 0,
                sent: function() {
                    if (1 & o[0]) throw o[1];
                    return o[1]
                },
                trys: [],
                ops: []
            };
            return i = {
                next: u(0),
                throw: u(1),
                return: u(2)
            }, "function" == typeof Symbol && (i[Symbol.iterator] = function() {
                return this
            }), i;

            function u(i) {
                return function(u) {
                    return function(i) {
                        if (n) throw new TypeError("Generator is already executing.");
                        for (; a;) try {
                            if (n = 1, r && (o = 2 & i[0] ? r.return : i[0] ? r.throw || ((o = r.return) && o.call(r), 0) : r.next) && !(o = o.call(r, i[1])).done) return o;
                            switch (r = 0, o && (i = [2 & i[0], o.value]), i[0]) {
                                case 0:
                                case 1:
                                    o = i;
                                    break;
                                case 4:
                                    return a.label++, {
                                        value: i[1],
                                        done: !1
                                    };
                                case 5:
                                    a.label++, r = i[1], i = [0];
                                    continue;
                                case 7:
                                    i = a.ops.pop(), a.trys.pop();
                                    continue;
                                default:
                                    if (!(o = a.trys, (o = o.length > 0 && o[o.length - 1]) || 6 !== i[0] && 2 !== i[0])) {
                                        a = 0;
                                        continue
                                    }
                                    if (3 === i[0] && (!o || i[1] > o[0] && i[1] < o[3])) {
                                        a.label = i[1];
                                        break
                                    }
                                    if (6 === i[0] && a.label < o[1]) {
                                        a.label = o[1], o = i;
                                        break
                                    }
                                    if (o && a.label < o[2]) {
                                        a.label = o[2], a.ops.push(i);
                                        break
                                    }
                                    o[2] && a.ops.pop(), a.trys.pop();
                                    continue
                            }
                            i = t.call(e, a)
                        } catch (e) {
                            i = [6, e], r = 0
                        } finally {
                            n = o = 0
                        }
                        if (5 & i[0]) throw i[1];
                        return {
                            value: i[0] ? i[1] : void 0,
                            done: !0
                        }
                    }([i, u])
                }
            }
        };
    (function() {
        return k(this, void 0, Promise, (function() {
            var e, t;
            return x(this, (function(n) {
                switch (n.label) {
                    case 0:
                        return [4, E.loadGuacConfig()];
                    case 1:
                        return (e = n.sent()).isEnabled && (null === r.CurrentUser || void 0 === r.CurrentUser ? void 0 : r.CurrentUser.userId) && parseInt(r.CurrentUser.userId, 10) % 100 < e.rolloutPercentage ? (t = new w(e.intervalTimeMs), f.forEach((function(e) {
                            window.addEventListener(e, (function() {
                                t.onActiveEvent().catch(console.error)
                            }))
                        })), v.forEach((function(e) {
                            window.addEventListener(e, (function() {
                                t.onInactiveEvent()
                            }))
                        })), [4, t.start()]) : [3, 3];
                    case 2:
                        n.sent(), n.label = 3;
                    case 3:
                        return [2]
                }
            }))
        }))
    })().catch(console.error)
}();
//# sourceMappingURL=https://js.rbxcdn.com/586e4d10b1045d83070bbdc231189b10-presenceRegistration.bundle.min.js.map

/* Bundle detector */
window.Roblox && window.Roblox.BundleDetector && window.Roblox.BundleDetector.bundleDetected("PresenceRegistration");