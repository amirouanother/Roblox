! function() {
    var n = {
            2483: function(e, r, n) {
                var t = {
                    "./resources.js": 3534
                };

                function a(e) {
                    e = i(e);
                    return n(e)
                }

                function i(e) {
                    if (n.o(t, e)) return t[e];
                    e = new Error("Cannot find module '" + e + "'");
                    throw e.code = "MODULE_NOT_FOUND", e
                }
                a.keys = function() {
                    return Object.keys(t)
                }, a.resolve = i, (e.exports = a).id = 2483
            },
            7696: function(e, r, n) {
                var t = {
                    "./friendsListController.js": 9101,
                    "./peopleController.js": 3758,
                    "./peopleInfoCardController.js": 4124,
                    "./peopleListContainerController.js": 822
                };

                function a(e) {
                    e = i(e);
                    return n(e)
                }

                function i(e) {
                    if (n.o(t, e)) return t[e];
                    e = new Error("Cannot find module '" + e + "'");
                    throw e.code = "MODULE_NOT_FOUND", e
                }
                a.keys = function() {
                    return Object.keys(t)
                }, a.resolve = i, (e.exports = a).id = 7696
            },
            3861: function(e, r, n) {
                var t = {
                    "./peopleDirective.js": 8762,
                    "./peopleListContainerDirective.js": 2939,
                    "./peopleListDirective.js": 7166
                };

                function a(e) {
                    e = i(e);
                    return n(e)
                }

                function i(e) {
                    if (n.o(t, e)) return t[e];
                    e = new Error("Cannot find module '" + e + "'");
                    throw e.code = "MODULE_NOT_FOUND", e
                }
                a.keys = function() {
                    return Object.keys(t)
                }, a.resolve = i, (e.exports = a).id = 3861
            },
            9102: function(e, r, n) {
                var t = {
                    "./friendsService.js": 8962,
                    "./gamesService.js": 64,
                    "./layoutService.js": 8280,
                    "./utilityService.js": 2752
                };

                function a(e) {
                    e = i(e);
                    return n(e)
                }

                function i(e) {
                    if (n.o(t, e)) return t[e];
                    e = new Error("Cannot find module '" + e + "'");
                    throw e.code = "MODULE_NOT_FOUND", e
                }
                a.keys = function() {
                    return Object.keys(t)
                }, a.resolve = i, (e.exports = a).id = 9102
            },
            2082: function(e, r, n) {
                var t = {
                    "./directives/templates/people.html": 6311,
                    "./directives/templates/peopleInfoCard.html": 7625,
                    "./directives/templates/peopleList.html": 4862,
                    "./directives/templates/peopleListContainer.html": 5641
                };

                function a(e) {
                    e = i(e);
                    return n(e)
                }

                function i(e) {
                    if (n.o(t, e)) return t[e];
                    e = new Error("Cannot find module '" + e + "'");
                    throw e.code = "MODULE_NOT_FOUND", e
                }
                a.keys = function() {
                    return Object.keys(t)
                }, a.resolve = i, (e.exports = a).id = 2082
            },
            3544: function(e) {
                function i(e) {
                    return e.replace(/([a-z])([A-Z])/g, "$1-$2").toLowerCase()
                }

                function s(e) {
                    return e.split("/").pop().replace(".html", "")
                }
                var r = {
                    importFilesUnderPath: function(e) {
                        e.keys().forEach(e)
                    },
                    templateCacheGenerator: function(e, r, t, a) {
                        return e.module(r, []).run(["$templateCache", function(n) {
                            t && t.keys().forEach(function(e) {
                                var r = i(s(e));
                                n.put(r, t(e))
                            }), a && a.keys().forEach(function(e) {
                                var r = i(s(e));
                                n.put(r, a(e).replace(/<\/?script[^>]*>/gi, ""))
                            })
                        }])
                    }
                };
                e.exports = r
            },
            3534: function(e, r, n) {
                "use strict";
                n.r(r);
                var t = n(792),
                    n = n(7420),
                    t = {
                        templateUrls: {
                            peopleListContainer: "people-list-container",
                            peopleList: "people-list",
                            peopleInfoCard: "people-info-card",
                            people: "people"
                        },
                        apiSets: {
                            getFriendsListUrl: {
                                url: t.EnvironmentUrls ? "".concat(t.EnvironmentUrls.friendsApi, "/v1/users/{userId}/friends") : "/v1/users/{userId}/friends",
                                retryable: !0,
                                withCredentials: !0
                            },
                            getMetadataUrl: {
                                url: t.EnvironmentUrls ? "".concat(t.EnvironmentUrls.friendsApi, "/v1/metadata") : "/v1/metadata",
                                retryable: !0,
                                withCredentials: !0
                            },
                            getPresences: {
                                url: t.EnvironmentUrls ? "".concat(t.EnvironmentUrls.presenceApi, "/v1/presence/users") : "/v1/presence/users",
                                retryable: !0,
                                withCredentials: !0
                            },
                            multiGetPlaceDetails: {
                                url: t.EnvironmentUrls ? "".concat(t.EnvironmentUrls.gamesApi, "/v1/games/multiget-place-details") : "/v1/games/multiget-place-details",
                                retryable: !0,
                                withCredentials: !0
                            },
                            multiGetGameIcons: {
                                url: t.EnvironmentUrls ? "".concat(t.EnvironmentUrls.gamesApi, "/v1/games/game-thumbnails") : "/v1/games/game-thumbnails",
                                retryable: !0,
                                withCredentials: !0
                            }
                        },
                        apiParams: {
                            avatarMultiGetLimit: 100,
                            presenceMultiGetLimit: 100
                        },
                        gameIconSize: {
                            lg: {
                                width: 150,
                                height: 150
                            }
                        },
                        eventStreamParams: {
                            goToProfileFromAvatar: {
                                name: "goToProfileFromAvatar",
                                ctx: "click"
                            },
                            goToProfileInPeopleList: {
                                name: "goToProfileFromPeopleList",
                                ctx: "click"
                            },
                            openPeopleList: {
                                name: "openPeopleList",
                                ctx: "hover"
                            },
                            goToChatInPeopleList: {
                                name: "goToChatFromPeopleList",
                                ctx: "click"
                            },
                            joinGameInPeopleList: {
                                name: "joinGameInPeopleList",
                                ctx: "click"
                            },
                            goToGameDetailFromAvatar: {
                                name: "goToGameDetailFromAvatar",
                                ctx: "click"
                            },
                            goToGameDetailInPeopleList: {
                                name: "goToGameDetailInPeopleList",
                                ctx: "click"
                            },
                            gamePlayIntentInPeopleList: {
                                ctx: "peopleListInHomePage"
                            },
                            gameImpressions: {
                                name: "gameImpressions",
                                ctx: "hover"
                            },
                            sessionInfoTypes: {
                                homePageSessionInfo: "homePageSessionInfo"
                            },
                            pageContexts: {
                                peopleListInHomePage: "peopleListInHomePage"
                            }
                        },
                        hoverPopoverParams: {
                            isOpen: !1,
                            triggerSelector: "",
                            hoverPopoverSelector: "",
                            isDisabled: !!t.DeviceMeta && (!(0, t.DeviceMeta)().isDesktop || (0, t.DeviceMeta)().isUWPApp)
                        },
                        reasonProhibitedMessage: {
                            None: "None",
                            PurchaseRequired: "PurchaseRequired"
                        },
                        peopleInfoCardContainerClass: "card-with-game"
                    };
                n.Z.constant("resources", t), r.default = t
            },
            9101: function(e, r, n) {
                "use strict";
                n.r(r);
                var t = n(5734),
                    s = n.n(t),
                    n = n(7420);

                function a(a, e, r, t, i, n) {
                    a.clickAvatar = function(e, r) {
                        var n = i.eventStreamParams.goToProfileFromAvatar,
                            r = {
                                friendId: e.id,
                                presentStatus: e.presence.userPresenceType,
                                position: r
                            };
                        e.presence.rootPlaceId && (r.rootPlaceId = e.presence.rootPlaceId), t.sendEventWithTarget(n.name, n.ctx, r)
                    }, a.clickPlaceLink = function(e, r) {
                        var n = i.eventStreamParams.goToGameDetailFromAvatar,
                            e = {
                                friendId: e.id,
                                position: r,
                                rootPlaceId: e.presence.rootPlaceId
                            };
                        t.sendEventWithTarget(n.name, n.ctx, e)
                    }, a.updatePresenceStatus = function(e) {
                        for (var r = [], n = 0; n < e.length; n++) {
                            var t = e[n];
                            t.rootPlaceId && !a.library.placesDict[t.rootPlaceId] && r.push(t.rootPlaceId), a.updatePresenceData(t)
                        }
                        0 < r.length && s().isFunction(a.setPlaceDetails) && a.setPlaceDetails(r)
                    }, a.listenToPresenceUpdate = function() {
                        document.addEventListener("Roblox.Presence.Update", function(e) {
                            null != e && e.detail && n(function() {
                                a.updatePresenceStatus(e.detail)
                            })
                        })
                    }, a.init = function() {
                        a.listenToPresenceUpdate()
                    }, a.init()
                }
                a.$inject = ["$scope", "$log", "$document", "eventStreamService", "resources", "$timeout"], n.Z.controller("friendsListController", a), r.default = a
            },
            3758: function(e, r, n) {
                "use strict";
                n.r(r);
                var t = n(5734),
                    a = n.n(t),
                    n = n(7420);

                function i(e, r, n) {
                    e.setupHoverPopover = function() {
                        e.peopleInfoCardPlacement = "bottom", e.peopleInfoCardTemplateUrl = n.templateUrls.peopleInfoCard, e.peopleInfoCardContainerClass = e.friend.presence && e.friend.presence.placeUrl ? n.peopleInfoCardContainerClass : "", e.hoverPopoverParams = a().copy(n.hoverPopoverParams), e.hoverPopoverParams.triggerSelector = "#people-".concat(e.friend.id), e.hoverPopoverParams.hoverPopoverSelector = ".people-info-".concat(e.friend.id), e.hoverPopoverParams.isDisabled = e.hoverPopoverParams.isDisabled || !e.library.isForCurrentUsersFriends
                    }, e.init = function() {
                        e.setupHoverPopover()
                    }, e.init()
                }
                i.$inject = ["$scope", "$log", "resources"], n.Z.controller("peopleController", i), r.default = i
            },
            4124: function(e, r, n) {
                "use strict";
                n.r(r), n.d(r, {
                    default: function() {
                        return a
                    }
                });
                var n = n(7420),
                    o = CoreUtilities,
                    p = CoreRobloxUtilities;

                function t(l, e, c, d, n, s, r, t, u) {
                    l.sendEventStream = function(e, r) {
                        (r = r || {}).friendId = l.friend.id, r.position = l.$index, t.sendEventWithTarget(e.name, e.ctx, r)
                    }, l.sendGamePlayEvent = function(e) {
                        t.sendGamePlayEvent(c.eventStreamParams.gamePlayIntentInPeopleList.ctx, e)
                    }, l.sendGameImpressionEvent = function(e, r, n) {
                        var t = c.eventStreamParams.pageContexts,
                            a = p.sessionStorageService.getEventTracker().homePageSessionInfo,
                            a = {
                                universeIds: JSON.stringify([e]),
                                rootPlaceIds: JSON.stringify([r]),
                                absPositions: JSON.stringify([0]),
                                sortPos: 0,
                                page: t.peopleListInHomePage,
                                homePageSessionInfo: a
                            };
                        l.sendEventStream(c.eventStreamParams.gameImpressions, a)
                    }, l.clickBtn = function(e) {
                        var r = l.friend.presence.rootPlaceId,
                            n = l.library.placesDict[r],
                            t = d.playButtons,
                            a = {
                                rootPlaceId: r
                            },
                            i = c.eventStreamParams;
                        switch (n.buttonLayout.type) {
                            case t.join.type:
                                var s = l.friend.presence.gameId,
                                    o = l.friend.id,
                                    o = u.buildPlayGameProperties(r, l.friend.presence.placeId, s, o);
                                a.gameInstanceId = s, a.friendId = l.friend.id, a.position = l.$index;
                                s = {
                                    eventName: i.joinGameInPeopleList.name,
                                    ctx: i.joinGameInPeopleList.ctx,
                                    properties: a,
                                    gamePlayIntentEventCtx: c.eventStreamParams.gamePlayIntentInPeopleList.ctx
                                };
                                u.launchGame(o, s);
                                break;
                            case t.details.type:
                                l.goToGameDetails(e)
                        }
                    }, l.goToGameDetails = function(e) {
                        var r = c.eventStreamParams,
                            n = l.friend.presence,
                            t = n.rootPlaceId,
                            a = n.universeId,
                            i = n.userId,
                            n = r.pageContexts.peopleListInHomePage,
                            e = {
                                rootPlaceId: t,
                                fromWhere: e,
                                page: n
                            };
                        l.sendEventStream(r.goToGameDetailInPeopleList, e);
                        t = {
                            page: n,
                            friendId: i,
                            universeId: a,
                            placeId: t,
                            position: 0,
                            homePageSessionInfo: p.sessionStorageService.getEventTracker().homePageSessionInfo
                        }, t = "".concat(l.friend.presence.placeUrl, "?").concat(o.urlService.composeQueryString(t));
                        s.location.href = o.urlService.getAbsoluteUrl(t)
                    }, l.goToChat = function() {
                        var e = l.friend.id;
                        l.sendEventStream(c.eventStreamParams.goToChatInPeopleList);
                        var r = n.buildPermissionVerifier({});
                        n.startChat(e, r)
                    }, l.goToProfilePage = function() {
                        l.sendEventStream(c.eventStreamParams.goToProfileInPeopleList), s.location.href = o.urlService.getAbsoluteUrl(l.friend.profileUrl)
                    }, l.init = function() {
                        l.sendEventStream(c.eventStreamParams.openPeopleList);
                        var e = l.friend.presence;
                        null != e && e.universeId && null != e && e.rootPlaceId && l.sendGameImpressionEvent(e.universeId, e.rootPlaceId, l.$index)
                    }, l.init()
                }
                t.$inject = ["$scope", "$log", "resources", "layoutService", "chatDispatchService", "$window", "gamesService", "eventStreamService", "playGameService"], n.Z.controller("peopleInfoCardController", t);
                var a = t
            },
            822: function(e, r, n) {
                "use strict";
                n.r(r), n.d(r, {
                    default: function() {
                        return a
                    }
                });
                var r = n(5734),
                    u = n.n(r),
                    p = n(792),
                    f = RobloxBadges,
                    m = RobloxUserProfiles,
                    r = n(7420),
                    v = n(3790);

                function t(s, e, r, n, t, a, i, o, l) {
                    function c() {
                        var e = (0, v.j)();
                        return !(null !== e || !p.CurrentUser) || e === p.CurrentUser.userId
                    }

                    function d() {
                        try {
                            (0, f.initRobloxBadgesFrameworkAgnostic)({
                                overrideIconClass: "verified-badge-icon-friends-carousel"
                            })
                        } catch (e) {}
                    }
                    s.setPlaceDetails = function(e) {
                        a.multiGetPlaceDetails(e).then(function(e) {
                            u().forEach(e, function(e, r) {
                                if (e) switch ((s.library.placesDict[r] = e).reasonProhibited) {
                                    case i.reasonProhibitedMessage.None:
                                        s.library.placesDict[r].buttonLayout = u().copy(t.playButtons.join);
                                        break;
                                    case i.reasonProhibitedMessage.PurchaseRequired:
                                        s.library.placesDict[r].requiredPurchase = !0;
                                    default:
                                        s.library.placesDict[r].buttonLayout = u().copy(t.playButtons.details)
                                }
                            })
                        })
                    }, s.safelyUpdatePresenceData = function(e, r) {
                        e ? (r && !r.userId && (r = {
                            lastLocation: "Website",
                            userId: e,
                            userPresenceType: 0
                        }, s.layout.invalidPresenceData = !0), r && s.updatePresenceData(r)) : s.layout.invalidPresenceData = !0
                    }, s.updatePresenceData = function(e) {
                        var r = t.presenceTypes;
                        switch (e.userPresenceType) {
                            case r.online.status:
                                e.className = t.presenceTypes.online.className;
                                break;
                            case r.ingame.status:
                                e.className = t.presenceTypes.ingame.className, e.rootPlaceId && (e.placeUrl = t.getGameDetailsPageUrl(e.rootPlaceId));
                                break;
                            case r.instudio.status:
                                e.className = t.presenceTypes.instudio.className, e.rootPlaceId && (e.placeUrl = t.getGameDetailsPageUrl(e.rootPlaceId))
                        }
                        s.library.friendsDict[e.userId] || (s.library.friendsDict[e.userId] = {}), s.library.friendsDict[e.userId].presence = e
                    }, s.buildFriendsInfo = function(a, e) {
                        e.shouldGetPresenceData ? r.getPresences(a).then(function(e) {
                            var t = [];
                            u().forEach(e, function(e, r) {
                                var n = e.rootPlaceId;
                                n && !s.library.placesDict[n] && t.push(n), s.safelyUpdatePresenceData(a[r], e)
                            }), 0 < t.length && s.setPlaceDetails(t), s.layout.isAllFriendsDataLoaded = !0, d()
                        }) : (s.library.isForCurrentUsersFriends || a.sort(function(e, r) {
                            e = s.library.friendsDict[e], r = s.library.friendsDict[r];
                            return e.name.toLowerCase() > r.name.toLowerCase() ? 1 : -1
                        }), s.library.friendIds = a, s.layout.isAllFriendsDataLoaded = !0, d())
                    }, s.buildFriendsList = function(e) {
                        s.layout.namesLoading = !0, r.getFriendsList(e).then(function(e) {
                            var a = e.data || e,
                                n = [];
                            u().forEach(a, function(e) {
                                var r = e.id;
                                n.indexOf(r) < 0 && n.push(r), e.profileUrl = t.getProfilePageUrl(r), e.hasVerifiedBadge = e.hasVerifiedBadge, s.library.friendsDict[r] = e
                            });
                            e = [m.UserProfileField.Names.CombinedName];
                            l.watchUserProfiles(n, e).subscribe(function(e) {
                                var r = e.loading,
                                    n = e.error,
                                    t = e.data;
                                s.layout.namesLoading = r, s.error = n, u().forEach(a, function(e) {
                                    e.nameToDisplay = t[e.id].names.combinedName
                                })
                            }), s.buildFriendsInfo(n, {
                                shouldGetPresenceData: s.library.isForCurrentUsersFriends
                            }), s.library.numOfFriends = a.length
                        }, function(e) {
                            s.layout.friendsError = !0, s.layout.isAllFriendsDataLoaded = !0
                        })
                    }, s.setup = function() {
                        s.library = {
                            friendsDict: {},
                            friendIds: [],
                            isForCurrentUsersFriends: c(),
                            placesDict: {},
                            numOfFriends: null
                        }, s.layout = t
                    }, s.buildFriendsListFromSharedService = function(i) {
                        s.layout.invalidPresenceData = !1, s.layout.namesLoading = !0, s.$evalAsync(function() {
                            var n, t, a, e;
                            null != i && i.length && (n = [], t = [], a = 0, u().forEach(i, function(e) {
                                var r = e.id;
                                s.library.friendsDict[r] = e, n.push(r);
                                r = e.presence.rootPlaceId;
                                r && !s.library.placesDict[r] && t.push(r), s.safelyUpdatePresenceData(e.id, e.presence), a += 1
                            }), s.library.numOfFriends = a, s.library.friendIds = n, e = [m.UserProfileField.Names.CombinedName], l.watchUserProfiles(n, e).subscribe(function(e) {
                                var r = e.loading,
                                    n = e.error,
                                    t = e.data;
                                s.layout.namesLoading = r, s.error = n, u().forEach(i, function(e) {
                                    e.nameToDisplay = t[e.id].names.combinedName
                                })
                            }), 0 < t.length && s.setPlaceDetails(t)), s.layout.isAllFriendsDataLoaded = !0, d()
                        })
                    }, s.init = function() {
                        s.setup();
                        var e = null !== (e = (0, v.j)()) && void 0 !== e ? e : p.CurrentUser.userId;
                        c() ? o.getFriendsPresence().then(function(e) {
                            s.buildFriendsListFromSharedService(e)
                        }, function(e) {
                            console.debug(e), s.layout.friendsError = !0, s.layout.isAllFriendsDataLoaded = !0
                        }) : s.buildFriendsList(e)
                    }, s.init()
                }
                t.$inject = ["$scope", "$log", "friendsService", "utilityService", "layoutService", "gamesService", "resources", "usersPresenceService", "userProfilesService"], r.Z.controller("peopleListContainerController", t);
                var a = t
            },
            8762: function(e, r, n) {
                "use strict";
                n.r(r);
                n = n(7420);

                function t(e) {
                    return {
                        restrict: "A",
                        scope: !0,
                        replace: !0,
                        templateUrl: e.templateUrls.people
                    }
                }
                t.$inject = ["resources"], n.Z.directive("people", t), r.default = t
            },
            2939: function(e, r, n) {
                "use strict";
                n.r(r);
                n = n(7420);

                function t(e, r) {
                    return {
                        restrict: "A",
                        scope: !0,
                        replace: !0,
                        templateUrl: e.templateUrls.peopleListContainer,
                        link: function() {
                            r.isFriendsListLoaded = !0
                        }
                    }
                }
                t.$inject = ["resources", "$rootScope"], n.Z.directive("peopleListContainer", t), r.default = t
            },
            7166: function(e, r, n) {
                "use strict";
                n.r(r);
                n = n(7420);

                function t(e) {
                    return {
                        restrict: "A",
                        scope: !0,
                        replace: !0,
                        templateUrl: e.templateUrls.peopleList
                    }
                }
                t.$inject = ["resources"], n.Z.directive("peopleList", t), r.default = t
            },
            6454: function(e, r, n) {
                "use strict";
                var t = n(5734),
                    a = n.n(t),
                    i = n(3544),
                    t = n(7420);
                (0, i.importFilesUnderPath)(n(2483)), (0, i.importFilesUnderPath)(n(3861)), (0, i.importFilesUnderPath)(n(7696)), (0, i.importFilesUnderPath)(n(9102));
                n = n(2082), (0, i.templateCacheGenerator)(a(), "peopleListHtmlTemplateApp", n);
                a().element("#people-list-container").hasClass("no-self-bootstrap") && (window.peopleList = t.Z)
            },
            7420: function(e, r, n) {
                "use strict";
                var t = n(792),
                    a = n(5734),
                    a = n.n(a)().module("peopleList", ["peopleListHtmlTemplateApp", "robloxApp", "ui.bootstrap", "thumbnails", "userProfiles"]).config(["languageResourceProvider", function(e) {
                        var r = (new t.TranslationResourceProvider).getTranslationResource("Feature.PeopleList");
                        e.setTranslationResources([r])
                    }]);
                r.Z = a
            },
            8962: function(e, r, n) {
                "use strict";
                n.r(r);
                n = n(7420);

                function t(l, n, c, t) {
                    var a = n.apiSets;
                    return {
                        getFriendsList: function(e) {
                            var r = a.getFriendsListUrl.url;
                            return a.getFriendsListUrl.url = t("formatString")(r, {
                                userId: e
                            }), c.httpGet(a.getFriendsListUrl)
                        },
                        buildBatchPromises: function(e, r, n, t) {
                            for (var a = [], i = 0, s = e.slice(i, r); 0 < s.length;) {
                                var o = {
                                    userIds: s
                                };
                                t ? a.push(c.httpPost(n, o)) : a.push(c.httpGet(n, o)), i++, s = e.slice(i * r, i * r + r)
                            }
                            return l.all(a)
                        },
                        getPresences: function(e) {
                            var r = n.apiParams.presenceMultiGetLimit;
                            return this.buildBatchPromises(e, r, a.getPresences, !0).then(function(e) {
                                if (e && 0 < e.length) {
                                    var r = [];
                                    return angular.forEach(e, function(e) {
                                        e = e.userPresences;
                                        r = r.concat(e)
                                    }), r
                                }
                                return null
                            })
                        },
                        getMetadata: function(e) {
                            e = {
                                targetUserId: e
                            };
                            return c.httpGet(a.getMetadataUrl, e)
                        }
                    }
                }
                t.$inject = ["$q", "resources", "httpService", "$filter"], n.Z.factory("friendsService", t), r.default = t
            },
            64: function(e, r, n) {
                "use strict";
                n.r(r);
                var a = n(792),
                    n = n(7420);

                function t(e, r, n) {
                    var t = r.apiSets;
                    return {
                        joinGame: function(e, r) {
                            a.GameLauncher.joinGameInstance(e, r, !0, !0)
                        },
                        multiGetPlaceDetails: function(e) {
                            e = {
                                placeIds: e
                            };
                            return n.httpGet(t.multiGetPlaceDetails, e).then(function(e) {
                                var r = [],
                                    n = {};
                                return angular.forEach(e, function(e) {
                                    e && e.imageToken && r.push(e.imageToken), n[e.placeId] = e
                                }), n
                            })
                        }
                    }
                }
                t.$inject = ["$q", "resources", "httpService"], n.Z.factory("gamesService", t), r.default = t
            },
            8280: function(e, r, n) {
                "use strict";
                n.r(r);
                var t = n(7420),
                    i = n(3790);

                function a(e, r, n, t) {
                    var a = e;
                    return {
                        sectionTitle: a.get("Heading.Friends"),
                        seeAllBtnText: a.get("Heading.SeeAll"),
                        maxNumberOfFriendsDisplayed: 24,
                        isAllFriendsDataLoaded: !1,
                        isAvatarDataLoaded: !1,
                        presenceTypes: {
                            offline: {
                                status: 0,
                                className: ""
                            },
                            online: {
                                status: 1,
                                className: "icon-online"
                            },
                            ingame: {
                                status: 2,
                                className: "icon-game"
                            },
                            instudio: {
                                status: 3,
                                className: "icon-studio"
                            }
                        },
                        getFriendsPageUrl: function() {
                            var e = (0, i.j)();
                            return null !== e ? r.getAbsoluteUrl("/users/".concat(e, "/friends")) : r.getAbsoluteUrl("/users/friends")
                        },
                        getGameDetailsPageUrl: function(e) {
                            e = n("formatString")("/games/{placeId}/gamename", {
                                placeId: e
                            });
                            return r.getAbsoluteUrl(e)
                        },
                        getProfilePageUrl: function(e) {
                            e = n("formatString")("/users/{userId}/profile", {
                                userId: e
                            });
                            return r.getAbsoluteUrl(e)
                        },
                        playButtons: {
                            join: {
                                type: "join",
                                text: a.get("Action.Join"),
                                className: "btn-growth-sm",
                                isPlayable: !0
                            },
                            buy: {
                                type: "buy",
                                text: a.get("Action.Buy"),
                                className: "btn-primary-sm",
                                isPlayable: !1
                            },
                            details: {
                                type: "details",
                                text: a.get("Action.ViewDetails"),
                                className: "btn-control-sm",
                                isPlayable: !1
                            }
                        },
                        interactionLabels: {
                            chat: function(e) {
                                return a.get("Label.Chat", {
                                    username: e
                                })
                            },
                            viewProfile: a.get("Label.ViewProfile")
                        },
                        thumbnailTypes: t.thumbnailTypes
                    }
                }
                a.$inject = ["languageResource", "urlService", "$filter", "thumbnailConstants"], t.Z.factory("layoutService", a), r.default = a
            },
            2752: function(e, r, n) {
                "use strict";
                n.r(r);
                n = n(7420);

                function t(o, l, e) {
                    return {
                        sortFriendsByOnlineOffline: function(r) {
                            var e = o("orderBy"),
                                n = [],
                                t = [];
                            angular.forEach(r.friendsDict, function(e) {
                                (e.presence && 0 < e.presence.userPresenceType ? n : t).push(e)
                            }), n = e(n, "+name"), t = e(t, "+name"), (n = n.concat(t)).forEach(function(e) {
                                r.friendIds.push(e.id)
                            })
                        },
                        sortFriendsByPresenceType: function(r) {
                            var e = o("orderBy"),
                                n = [],
                                t = [],
                                a = [],
                                i = [],
                                s = l.presenceTypes;
                            angular.forEach(r.friendsDict, function(e) {
                                if (!e.presence) return !1;
                                switch (e.presence.userPresenceType) {
                                    case s.online.status:
                                        n.push(e);
                                        break;
                                    case s.offline.status:
                                        t.push(e);
                                        break;
                                    case s.ingame.status:
                                        a.push(e);
                                        break;
                                    case s.instudio.status:
                                        i.push(e)
                                }
                            }), n = e(n, "+name"), t = e(t, "+name"), a = e(a, "+name"), i = e(i, "+name"), (a = (a = (a = a.concat(n)).concat(i)).concat(t)).forEach(function(e) {
                                r.friendIds.indexOf(e.id) < 0 && r.friendIds.push(e.id)
                            })
                        }
                    }
                }
                t.$inject = ["$filter", "layoutService", "$log"], n.Z.factory("utilityService", t), r.default = t
            },
            3790: function(e, r, n) {
                "use strict";

                function t() {
                    var e = /\/users\/(\d+)\//g.exec(window.location.pathname);
                    return e ? e[1] : null
                }
                n.d(r, {
                    j: function() {
                        return t
                    }
                })
            },
            6311: function(e) {
                e.exports = '<div ng-controller="peopleController"> <div class="avatar-container"> <a href="{{friend.profileUrl}}" class="text-link friend-link" ng-click="clickAvatar(friend, $index)" popover-trigger=" \'none\' " popover-class="people-info-card-container {{peopleInfoCardContainerClass}} people-info-{{friend.id}}" popover-placement="{{peopleInfoCardPlacement}}" popover-append-to-body="true" popover-is-open="hoverPopoverParams.isOpen" hover-popover-params="hoverPopoverParams" hover-popover uib-popover-template="\'{{peopleInfoCardTemplateUrl}}\'"> <div class="avatar avatar-card-fullbody"> <span class="avatar-card-link friend-avatar" ng-class="{\'icon-placeholder-avatar-headshot\': !friend.avatar.imageUrl}"> <thumbnail-2d class="avatar-card-image" thumbnail-type="layout.thumbnailTypes.avatarHeadshot" thumbnail-target-id="friend.id"></thumbnail-2d> </span> </div> <div ng-class="{\'shimmer\': layout.namesLoading}" class="friend-parent-container"> <div class="friend-name-container"> <span class="text-overflow friend-name font-caption-header" ng-bind="friend.nameToDisplay" title="{{friend.nameToDisplay}}"></span> <span ng-class="{\'hide\': !friend.hasVerifiedBadge || layout.namesLoading}"> <span class="verified-badge-icon-friends-carousel" data-size="CaptionHeader" data-overrideimgclass="verified-badge-icon-friends-carousel-rendered"> </span> </span> </div> </div> <div class="text-overflow xsmall text-label place-name" ng-if="friend.presence.placeUrl" ng-bind="library.placesDict[friend.presence.rootPlaceId].name"></div> </a> <a class="friend-status place-link" ng-href="{{friend.presence.placeUrl}}" ng-if="friend.presence.placeUrl" ng-click="clickPlaceLink(friend, $index)"> <span class="avatar-status friend-status {{friend.presence.className}}" title="{{friend.presence.lastLocation}}"></span> </a> <span ng-if="!friend.presence.placeUrl" class="avatar-status friend-status {{friend.presence.className}}" title="{{friend.presence.lastLocation}}"></span> </div> </div>'
            },
            7625: function(e) {
                e.exports = '<div ng-controller="peopleInfoCardController" ng-class="{\'card-with-game\': friend.presence.placeUrl}"> <div class="border-bottom place-container" ng-show="friend.presence.placeUrl"> <span ng-click="goToGameDetails(\'icon\')"> <thumbnail-2d class="cursor-pointer place-icon" thumbnail-type="layout.thumbnailTypes.gameIcon" thumbnail-target-id="library.placesDict[friend.presence.rootPlaceId].universeId"></thumbnail-2d> </span> <div class="place-info-container"> <div class="place-info"> <span class="text-subject cursor-pointer place-title" ng-bind="library.placesDict[friend.presence.rootPlaceId].name" ng-click="goToGameDetails(\'link\')"></span> <div class="icon-text-wrapper" ng-show="library.placesDict[friend.presence.rootPlaceId].requiredPurchase"> <span class="icon-robux"></span> <span class="text-robux" ng-bind="library.placesDict[friend.presence.rootPlaceId].price"></span> </div> </div> <div class="place-btn-container"> <button class="btn-full-width place-btn {{library.placesDict[friend.presence.rootPlaceId].buttonLayout.className}}" ng-click="clickBtn(\'btn\')"> {{library.placesDict[friend.presence.rootPlaceId].buttonLayout.text}} </button> </div> </div> </div> <ul class="dropdown-menu interaction-container"> <li class="interaction-item" ng-click="goToChat()"> <span class="icon icon-chat-gray"></span> <span class="text-overflow border-bottom label" ng-bind="layout.interactionLabels.chat(friend.nameToDisplay)" title="{{layout.interactionLabels.chat(friend.nameToDisplay)}}"></span> </li> <li class="interaction-item" ng-click="goToProfilePage()"> <span class="icon icon-viewdetails"></span> <span class="label" ng-bind="layout.interactionLabels.viewProfile"></span> </li> </ul> </div>'
            },
            4862: function(e) {
                e.exports = '<ul class="hlist" ng-controller="friendsListController"> <li id="people-{{friend.id}}" rbx-user-id="{{friend.id}}" class="list-item friend" ng-repeat="friend in library.friendsDict | orderList: library.friendIds | limitTo: layout.maxNumberOfFriendsDisplayed"> <div people></div> </li> </ul> '
            },
            5641: function(e) {
                e.exports = '<div ng-controller="peopleListContainerController"> <div class="col-xs-12 people-list-container" ng-show="layout.isAllFriendsDataLoaded && library.numOfFriends > 0 || layout.friendsError"> <div class="section home-friends"> <div class="container-header people-list-header"> <h2> {{layout.sectionTitle}}<span ng-show="library.numOfFriends !== null" class="friends-count">({{library.numOfFriends}})</span> </h2> <span ng-show="layout.invalidPresenceData" class="presence-error"> <span class="icon-warning"></span> <span class="text-error" ng-bind="\'Label.PresenceError\' | translate"></span> </span> <a href="{{layout.getFriendsPageUrl()}}" class="btn-secondary-xs btn-more see-all-link-icon">{{layout.seeAllBtnText}}</a> </div> <div class="section-content remove-panel people-list"> <p ng-show="layout.friendsError" class="section-content-off" ng-bind="\'Label.FriendsError\' | translate"></p> <div people-list ng-class="{\'invisible\': !layout.isAllFriendsDataLoaded}"></div> <span class="spinner spinner-default" ng-show="!layout.isAllFriendsDataLoaded"></span> </div> </div> </div> <div class="col-xs-12 people-list-container" ng-hide="layout.isAllFriendsDataLoaded"> <div class="section home-friends"> <div class="container-header people-list-header"> <h2>{{layout.sectionTitle}}</h2> </div> <div class="section-content remove-panel people-list"> <span class="spinner spinner-default"></span> </div> </div> </div> </div> '
            },
            792: function(e) {
                "use strict";
                e.exports = Roblox
            },
            5734: function(e) {
                "use strict";
                e.exports = angular
            }
        },
        t = {};

    function a(e) {
        if (t[e]) return t[e].exports;
        var r = t[e] = {
            exports: {}
        };
        return n[e](r, r.exports, a), r.exports
    }
    a.n = function(e) {
        var r = e && e.__esModule ? function() {
            return e.default
        } : function() {
            return e
        };
        return a.d(r, {
            a: r
        }), r
    }, a.d = function(e, r) {
        for (var n in r) a.o(r, n) && !a.o(e, n) && Object.defineProperty(e, n, {
            enumerable: !0,
            get: r[n]
        })
    }, a.o = function(e, r) {
        return Object.prototype.hasOwnProperty.call(e, r)
    }, a.r = function(e) {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(e, "__esModule", {
            value: !0
        })
    }, a(6454)
}();
//# sourceMappingURL=https://js.rbxcdn.com/afeb00a3f39c65f49749e8105de0b5c6-peopleList.bundle.min.js.map

/* Bundle detector */
window.Roblox && window.Roblox.BundleDetector && window.Roblox.BundleDetector.bundleDetected("PeopleList");