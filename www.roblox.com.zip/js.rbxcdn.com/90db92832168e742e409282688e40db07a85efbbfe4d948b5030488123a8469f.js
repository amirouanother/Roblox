! function() {
    "use strict";
    var e = {
            n: function(t) {
                var n = t && t.__esModule ? function() {
                    return t.default
                } : function() {
                    return t
                };
                return e.d(n, {
                    a: n
                }), n
            },
            d: function(t, n) {
                for (var r in n) e.o(n, r) && !e.o(t, r) && Object.defineProperty(t, r, {
                    enumerable: !0,
                    get: n[r]
                })
            },
            o: function(e, t) {
                return Object.prototype.hasOwnProperty.call(e, t)
            },
            r: function(e) {
                "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
                    value: "Module"
                }), Object.defineProperty(e, "__esModule", {
                    value: !0
                })
            }
        },
        t = {};
    e.r(t), e.d(t, {
        getState: function() {
            return j
        },
        lock: function() {
            return Z
        },
        unlock: function() {
            return J
        }
    });
    var n = {};
    e.r(n), e.d(n, {
        getMetadata: function() {
            return re
        }
    });
    var r = {};
    e.r(r), e.d(r, {
        getEmailConfiguration: function() {
            return le
        },
        updateForCurrentUser: function() {
            return se
        }
    });
    var o = {};
    e.r(o), e.d(o, {
        getDetailsForUniverseIds: function() {
            return Ee
        }
    });
    var i = {};
    e.r(i), e.d(i, {
        getMySettingsInfo: function() {
            return ve
        }
    });
    var a = {};
    e.r(a), e.d(a, {
        getMetadata: function() {
            return De
        },
        resendCode: function() {
            return Ie
        },
        sendCodeForUser: function() {
            return Re
        },
        validateCode: function() {
            return Ue
        }
    });
    var u = {};
    e.r(u), e.d(u, {
        changeForCurrentUser: function() {
            return Ye
        },
        resetSendPrompted: function() {
            return Ge
        },
        validate: function() {
            return Ke
        }
    });
    var c = {};
    e.r(c), e.d(c, {
        getPhoneConfiguration: function() {
            return Ze
        }
    });
    var s = {};
    e.r(s), e.d(s, {
        disconnectPlaystation: function() {
            return ct
        },
        getPlaystationConnection: function() {
            return ut
        }
    });
    var l = {};
    e.r(l), e.d(l, {
        getAllForCurrentUser: function() {
            return vt
        },
        updateForCurrentUser: function() {
            return At
        }
    });
    var d = {};
    e.r(d), e.d(d, {
        verifyPuzzle: function() {
            return Pt
        }
    });
    var p = {};
    e.r(p), e.d(p, {
        getPuzzle: function() {
            return Mt
        },
        verifyPuzzle: function() {
            return kt
        }
    });
    var f = {};
    e.r(f), e.d(f, {
        generateToken: function() {
            return Wt
        }
    });
    var E = {};
    e.r(E), e.d(E, {
        verifyPuzzle: function() {
            return jt
        }
    });
    var m = {};
    e.r(m), e.d(m, {
        answerQuestion: function() {
            return un
        },
        getQuestion: function() {
            return an
        }
    });
    var h = {};
    e.r(h), e.d(h, {
        getSessions: function() {
            return Nn
        },
        logoutFromAllSessionsAndReauthenticate: function() {
            return On
        },
        logoutSession: function() {
            return Tn
        }
    });
    var S = {};
    e.r(S), e.d(S, {
        getIconsForUniverseIds: function() {
            return In
        }
    });
    var v = {};
    e.r(v), e.d(v, {
        deleteSecurityKey: function() {
            return Or
        },
        disableAuthenticator: function() {
            return dr
        },
        disableEmailTwoStepVerification: function() {
            return ur
        },
        disableSmsTwoStepVerification: function() {
            return vr
        },
        enableAuthenticator: function() {
            return cr
        },
        enableEmailTwoStepVerification: function() {
            return or
        },
        enableSecurityKey: function() {
            return Ar
        },
        enableSmsTwoStepVerification: function() {
            return mr
        },
        enableVerifyAuthenticator: function() {
            return sr
        },
        enableVerifySecurityKey: function() {
            return _r
        },
        generateRecoveryCodes: function() {
            return Er
        },
        generateResaleFrictionChallenge: function() {
            return Ir
        },
        generateSpendFrictionChallenge: function() {
            return wr
        },
        generateTradeFrictionChallenge: function() {
            return Rr
        },
        getMetadata: function() {
            return nr
        },
        getRecoveryCodesStatus: function() {
            return fr
        },
        getResaleFrictionStatus: function() {
            return Pr
        },
        getSecurityKeyOptions: function() {
            return Nr
        },
        getSpendFrictionStatus: function() {
            return yr
        },
        getTradeFrictionStatus: function() {
            return Cr
        },
        getUserConfiguration: function() {
            return rr
        },
        listSecurityKey: function() {
            return br
        },
        redeemResaleFrictionChallenge: function() {
            return gr
        },
        redeemSpendFrictionChallenge: function() {
            return Ur
        },
        redeemTradeFrictionChallenge: function() {
            return Dr
        },
        retractCrossDevice: function() {
            return kr
        },
        retryCrossDevice: function() {
            return Lr
        },
        sendEmailCode: function() {
            return ir
        },
        sendSmsCode: function() {
            return hr
        },
        verifyAuthenticatorCode: function() {
            return lr
        },
        verifyCrossDevice: function() {
            return Mr
        },
        verifyEmailCode: function() {
            return ar
        },
        verifyRecoveryCode: function() {
            return pr
        },
        verifySecurityKeyCredential: function() {
            return Tr
        },
        verifySmsCode: function() {
            return Sr
        }
    });
    var A = {};
    e.r(A), e.d(A, {
        getSettingsUiPolicy: function() {
            return Yr
        }
    });
    var _ = {};
    e.r(_), e.d(_, {
        disconnectXbox: function() {
            return Jr
        },
        getXboxConnection: function() {
            return jr
        }
    });
    var N = {};
    e.r(N), e.d(N, {
        recordMetric: function() {
            return no
        }
    });
    var T = {};
    e.r(T), e.d(T, {
        getPatToken: function() {
            return so
        }
    });
    var O = {};
    e.r(O), e.d(O, {
        continueChallenge: function() {
            return So
        }
    });
    var b = {};
    e.r(b), e.d(b, {
        deletePasskeyBatch: function() {
            return Po
        },
        finishPasskeyRegistration: function() {
            return Co
        },
        listAllCredentials: function() {
            return wo
        },
        startPasskeyRegistration: function() {
            return yo
        }
    });
    var y = {};
    e.r(y), e.d(y, {
        getNativeResponse: function() {
            return Uo
        },
        getNavigatorCredentials: function() {
            return Do
        }
    });
    var C, P, w = Roblox,
        R = e.n(w),
        I = React,
        U = e.n(I),
        D = ReactDOM,
        g = CoreUtilities,
        L = function(e) {
            return {
                isError: !1,
                value: e
            }
        },
        M = L,
        k = function(e, t, n) {
            return void 0 === n && (n = null), {
                isError: !0,
                error: e,
                errorRaw: t,
                errorStatusCode: n
            }
        },
        x = function(e, t) {
            return e.isError ? e : L(t(e.value))
        },
        F = function(e, t, n, r) {
            return new(n || (n = Promise))((function(o, i) {
                function a(e) {
                    try {
                        c(r.next(e))
                    } catch (e) {
                        i(e)
                    }
                }

                function u(e) {
                    try {
                        c(r.throw(e))
                    } catch (e) {
                        i(e)
                    }
                }

                function c(e) {
                    var t;
                    e.done ? o(e.value) : (t = e.value, t instanceof n ? t : new n((function(e) {
                        e(t)
                    }))).then(a, u)
                }
                c((r = r.apply(e, t || [])).next())
            }))
        },
        V = function(e, t) {
            var n, r, o, i, a = {
                label: 0,
                sent: function() {
                    if (1 & o[0]) throw o[1];
                    return o[1]
                },
                trys: [],
                ops: []
            };
            return i = {
                next: u(0),
                throw: u(1),
                return: u(2)
            }, "function" == typeof Symbol && (i[Symbol.iterator] = function() {
                return this
            }), i;

            function u(i) {
                return function(u) {
                    return function(i) {
                        if (n) throw new TypeError("Generator is already executing.");
                        for (; a;) try {
                            if (n = 1, r && (o = 2 & i[0] ? r.return : i[0] ? r.throw || ((o = r.return) && o.call(r), 0) : r.next) && !(o = o.call(r, i[1])).done) return o;
                            switch (r = 0, o && (i = [2 & i[0], o.value]), i[0]) {
                                case 0:
                                case 1:
                                    o = i;
                                    break;
                                case 4:
                                    return a.label++, {
                                        value: i[1],
                                        done: !1
                                    };
                                case 5:
                                    a.label++, r = i[1], i = [0];
                                    continue;
                                case 7:
                                    i = a.ops.pop(), a.trys.pop();
                                    continue;
                                default:
                                    if (!(o = a.trys, (o = o.length > 0 && o[o.length - 1]) || 6 !== i[0] && 2 !== i[0])) {
                                        a = 0;
                                        continue
                                    }
                                    if (3 === i[0] && (!o || i[1] > o[0] && i[1] < o[3])) {
                                        a.label = i[1];
                                        break
                                    }
                                    if (6 === i[0] && a.label < o[1]) {
                                        a.label = o[1], o = i;
                                        break
                                    }
                                    if (o && a.label < o[2]) {
                                        a.label = o[2], a.ops.push(i);
                                        break
                                    }
                                    o[2] && a.ops.pop(), a.trys.pop();
                                    continue
                            }
                            i = t.call(e, a)
                        } catch (e) {
                            i = [6, e], r = 0
                        } finally {
                            n = o = 0
                        }
                        if (5 & i[0]) throw i[1];
                        return {
                            value: i[0] ? i[1] : void 0,
                            done: !0
                        }
                    }([i, u])
                }
            }
        },
        H = function(e) {
            return "object" != typeof e ? null : function(e) {
                var t = [];
                if (!e || "object" != typeof e) return [];
                var n = e.errors;
                return n instanceof Array ? (n.forEach((function(e) {
                    if (e && "object" == typeof e) {
                        var n = e.code;
                        "number" == typeof n && t.push(n)
                    }
                })), t) : []
            }(e.data)[0] || null
        },
        W = function(e, t) {
            return null == e ? null : Object.values(e).includes(t) ? t : null
        },
        B = function(e, t, n) {
            return F(void 0, void 0, Promise, (function() {
                var r, o, i, a;
                return V(this, (function(u) {
                    switch (u.label) {
                        case 0:
                            return u.trys.push([0, 2, , 3]), [4, e];
                        case 1:
                            return r = u.sent(), void 0 !== n ? [2, M(n(r.data))] : [2, M(r.data)];
                        case 2:
                            return o = u.sent(), i = H(o), a = function(e) {
                                if ("object" != typeof e || null === e) return null;
                                var t = e.status || null;
                                return "number" != typeof t ? null : t
                            }(o), [2, k(W(t, i), o, a)];
                        case 3:
                            return [2]
                    }
                }))
            }))
        },
        Y = function(e, t, n, r) {
            return void 0 === n && (n = H), F(void 0, void 0, Promise, (function() {
                var o, i, a;
                return V(this, (function(u) {
                    switch (u.label) {
                        case 0:
                            return u.trys.push([0, 2, , 3]), [4, e];
                        case 1:
                            return o = u.sent(), void 0 !== r ? [2, M(r(o))] : [2, M(o)];
                        case 2:
                            return i = u.sent(), a = n(i), [2, k(W(t, a), i, 0)];
                        case 3:
                            return [2]
                    }
                }))
            }))
        },
        G = null !== (C = w.EnvironmentUrls.authApi) && void 0 !== C ? C : "URL_NOT_FOUND";
    ! function(e) {
        e[e.NO_ACCOUNT_PIN = 1] = "NO_ACCOUNT_PIN", e[e.ACCOUNT_LOCKED = 2] = "ACCOUNT_LOCKED", e[e.FLOODED = 3] = "FLOODED", e[e.INCORRECT_PIN = 4] = "INCORRECT_PIN"
    }(P || (P = {}));
    var K, Q, X = {
            withCredentials: !0,
            url: G + "/v1/account/pin",
            timeout: 1e4
        },
        q = {
            withCredentials: !0,
            url: G + "/v1/account/pin/unlock",
            timeout: 1e4
        },
        z = {
            withCredentials: !0,
            url: G + "/v1/account/pin/lock",
            timeout: 1e4
        },
        j = function() {
            return B(g.httpService.get(X), P)
        },
        J = function(e) {
            return B(g.httpService.post(q, {
                pin: e
            }), P)
        },
        Z = function() {
            return B(g.httpService.post(z), P)
        },
        $ = (null !== (K = w.EnvironmentUrls.apiGatewayCdnUrl) && void 0 !== K ? K : "URL_NOT_FOUND") + "/captcha";
    ! function(e) {
        e[e.UNKNOWN = 0] = "UNKNOWN"
    }(Q || (Q = {}));
    var ee, te, ne = {
            url: $ + "/v1/metadata",
            timeout: 6e4
        },
        re = function() {
            return B(g.httpService.get(ne, {}), Q)
        },
        oe = null !== (ee = w.EnvironmentUrls.accountSettingsApi) && void 0 !== ee ? ee : "URL_NOT_FOUND";
    ! function(e) {
        e[e.FEATURE_DISABLED = 2] = "FEATURE_DISABLED", e[e.TOO_MANY_ACCOUNTS_ON_EMAIL = 3] = "TOO_MANY_ACCOUNTS_ON_EMAIL", e[e.TOO_MANY_ATTEMPTS_TO_UPDATE_EMAIL = 6] = "TOO_MANY_ATTEMPTS_TO_UPDATE_EMAIL", e[e.INVALID_EMAIL_ADDRESS = 9] = "INVALID_EMAIL_ADDRESS"
    }(te || (te = {}));
    var ie, ae, ue = {
            withCredentials: !0,
            url: oe + "/v1/email",
            timeout: 1e4
        },
        ce = {
            withCredentials: !0,
            url: oe + "/v1/email",
            timeout: 1e4
        },
        se = function(e) {
            return B(g.httpService.post(ue, {
                emailAddress: e,
                skipVerificationEmail: !0
            }), te)
        },
        le = function() {
            return B(g.httpService.get(ce), te)
        },
        de = null !== (ie = w.EnvironmentUrls.gamesApi) && void 0 !== ie ? ie : "URL_NOT_FOUND";
    ! function(e) {
        e[e.UNKNOWN = 0] = "UNKNOWN"
    }(ae || (ae = {}));
    var pe, fe = {
            url: de + "/v1/games",
            timeout: 1e4
        },
        Ee = function(e) {
            return B(g.httpService.get(fe, {
                universeIds: e
            }), ae)
        };
    ! function(e) {
        e[e.UNKNOWN = 0] = "UNKNOWN"
    }(pe || (pe = {}));
    var me, he, Se = {
            withCredentials: !0,
            url: "/my/settings/json",
            timeout: 1e4
        },
        ve = function() {
            return B(g.httpService.get(Se, {}), pe)
        },
        Ae = (null !== (me = w.EnvironmentUrls.apiGatewayUrl) && void 0 !== me ? me : "URL_NOT_FOUND") + "/otp-service";
    ! function(e) {
        e[e.NO_ERROR = 0] = "NO_ERROR", e[e.UNKNOWN = 1] = "UNKNOWN", e[e.INVALID_CODE = 2] = "INVALID_CODE", e[e.INVALID_SESSION_TOKEN = 3] = "INVALID_SESSION_TOKEN", e[e.CODE_EXPIRED = 4] = "CODE_EXPIRED", e[e.UNVALIDATED_SESSION_TOKEN = 5] = "UNVALIDATED_SESSION_TOKEN", e[e.TOO_MANY_REQUESTS = 6] = "TOO_MANY_REQUESTS", e[e.CONTACT_MALFORMED = 7] = "CONTACT_MALFORMED", e[e.VPN_REQUIRED = 8] = "VPN_REQUIRED", e[e.UNAUTHENTICATED = 9] = "UNAUTHENTICATED", e[e.METHOD_UNAVAILABLE = 10] = "METHOD_UNAVAILABLE"
    }(he || (he = {}));
    var _e, Ne, Te, Oe = {
            withCredentials: !0,
            url: Ae + "/v1/sendCodeForUser",
            timeout: 1e4
        },
        be = {
            withCredentials: !0,
            url: Ae + "/v1/resendCode",
            timeout: 1e4
        },
        ye = {
            withCredentials: !0,
            url: Ae + "/v1/validateCode",
            timeout: 1e4
        },
        Ce = {
            withCredentials: !0,
            url: Ae + "/v1/metadata",
            timeout: 1e4
        };
    ! function(e) {
        e.Unset = "Unset", e.Email = "Email"
    }(_e || (_e = {})),
    function(e) {
        e.Reauth = "Reauth", e.Challenge = "Challenge"
    }(Ne || (Ne = {})),
    function(e) {
        e.Default = "Default"
    }(Te || (Te = {}));
    var Pe, we, Re = function(e) {
            return B(g.httpService.post(Oe, {
                contactType: e,
                origin: Ne.Reauth,
                messageVariant: Te.Default
            }), he)
        },
        Ie = function(e, t) {
            return B(g.httpService.post(be, {
                contactType: e,
                origin: Ne.Reauth,
                otpSessionToken: t
            }), he)
        },
        Ue = function(e, t, n) {
            return B(g.httpService.post(ye, {
                contactType: e,
                origin: Ne.Reauth,
                passCode: n,
                otpSessionToken: t
            }), he)
        },
        De = function(e) {
            return B(g.httpService.get(Ce, {
                Origin: e
            }), he)
        },
        ge = null !== (Pe = w.EnvironmentUrls.authApi) && void 0 !== Pe ? Pe : "URL_NOT_FOUND";
    ! function(e) {
        e[e.FLOODED = 2] = "FLOODED", e[e.INVALID_PASSWORD = 7] = "INVALID_PASSWORD", e[e.INVALID_CURRENT_PASSWORD = 8] = "INVALID_CURRENT_PASSWORD", e[e.PIN_LOCKED = 9] = "PIN_LOCKED"
    }(we || (we = {}));
    var Le, Me = {
        withCredentials: !0,
        url: ge + "/v2/user/passwords/change",
        timeout: 1e4
    };
    ! function(e) {
        e[e.USER_DOES_NOT_HAVE_EMAIL = 22] = "USER_DOES_NOT_HAVE_EMAIL"
    }(Le || (Le = {}));
    var ke, xe = {
        withCredentials: !0,
        url: ge + "/v2/passwords/reset/send-prompted",
        timeout: 1e4
    };
    ! function(e) {
        e[e.VALID_PASSWORD = 0] = "VALID_PASSWORD", e[e.WEAK_PASSWORD = 1] = "WEAK_PASSWORD", e[e.SHORT_PASSWORD = 2] = "SHORT_PASSWORD", e[e.PASSWORD_SAME_AS_USERNAME = 3] = "PASSWORD_SAME_AS_USERNAME", e[e.FORBIDDEN_PASSWORD = 4] = "FORBIDDEN_PASSWORD", e[e.DUMB_STRINGS = 5] = "DUMB_STRINGS"
    }(ke || (ke = {}));
    var Fe, Ve, He = {
            withCredentials: !0,
            url: ge + "/v2/passwords/validate",
            timeout: 1e4
        },
        We = function(e, t, n, r) {
            return new(n || (n = Promise))((function(o, i) {
                function a(e) {
                    try {
                        c(r.next(e))
                    } catch (e) {
                        i(e)
                    }
                }

                function u(e) {
                    try {
                        c(r.throw(e))
                    } catch (e) {
                        i(e)
                    }
                }

                function c(e) {
                    var t;
                    e.done ? o(e.value) : (t = e.value, t instanceof n ? t : new n((function(e) {
                        e(t)
                    }))).then(a, u)
                }
                c((r = r.apply(e, t || [])).next())
            }))
        },
        Be = function(e, t) {
            var n, r, o, i, a = {
                label: 0,
                sent: function() {
                    if (1 & o[0]) throw o[1];
                    return o[1]
                },
                trys: [],
                ops: []
            };
            return i = {
                next: u(0),
                throw: u(1),
                return: u(2)
            }, "function" == typeof Symbol && (i[Symbol.iterator] = function() {
                return this
            }), i;

            function u(i) {
                return function(u) {
                    return function(i) {
                        if (n) throw new TypeError("Generator is already executing.");
                        for (; a;) try {
                            if (n = 1, r && (o = 2 & i[0] ? r.return : i[0] ? r.throw || ((o = r.return) && o.call(r), 0) : r.next) && !(o = o.call(r, i[1])).done) return o;
                            switch (r = 0, o && (i = [2 & i[0], o.value]), i[0]) {
                                case 0:
                                case 1:
                                    o = i;
                                    break;
                                case 4:
                                    return a.label++, {
                                        value: i[1],
                                        done: !1
                                    };
                                case 5:
                                    a.label++, r = i[1], i = [0];
                                    continue;
                                case 7:
                                    i = a.ops.pop(), a.trys.pop();
                                    continue;
                                default:
                                    if (!(o = a.trys, (o = o.length > 0 && o[o.length - 1]) || 6 !== i[0] && 2 !== i[0])) {
                                        a = 0;
                                        continue
                                    }
                                    if (3 === i[0] && (!o || i[1] > o[0] && i[1] < o[3])) {
                                        a.label = i[1];
                                        break
                                    }
                                    if (6 === i[0] && a.label < o[1]) {
                                        a.label = o[1], o = i;
                                        break
                                    }
                                    if (o && a.label < o[2]) {
                                        a.label = o[2], a.ops.push(i);
                                        break
                                    }
                                    o[2] && a.ops.pop(), a.trys.pop();
                                    continue
                            }
                            i = t.call(e, a)
                        } catch (e) {
                            i = [6, e], r = 0
                        } finally {
                            n = o = 0
                        }
                        if (5 & i[0]) throw i[1];
                        return {
                            value: i[0] ? i[1] : void 0,
                            done: !0
                        }
                    }([i, u])
                }
            }
        },
        Ye = function(e, t) {
            return B(g.httpService.post(Me, {
                currentPassword: e,
                newPassword: t
            }), we)
        },
        Ge = function() {
            return B(g.httpService.post(xe), Le)
        },
        Ke = function(e, t) {
            return We(void 0, void 0, Promise, (function() {
                return Be(this, (function(n) {
                    return [2, B(g.httpService.post(He, {
                        username: e,
                        password: t
                    }), null).then((function(e) {
                        return x(e, (function(e) {
                            return W(ke, e.code)
                        }))
                    }))]
                }))
            }))
        },
        Qe = null !== (Fe = w.EnvironmentUrls.accountInformationApi) && void 0 !== Fe ? Fe : "URL_NOT_FOUND";
    ! function(e) {
        e[e.UNKNOWN = 0] = "UNKNOWN"
    }(Ve || (Ve = {}));
    var Xe, qe, ze = {
            withCredentials: !0,
            url: Qe + "/v1/phone",
            timeout: 1e4
        },
        je = function(e, t, n, r) {
            return new(n || (n = Promise))((function(o, i) {
                function a(e) {
                    try {
                        c(r.next(e))
                    } catch (e) {
                        i(e)
                    }
                }

                function u(e) {
                    try {
                        c(r.throw(e))
                    } catch (e) {
                        i(e)
                    }
                }

                function c(e) {
                    var t;
                    e.done ? o(e.value) : (t = e.value, t instanceof n ? t : new n((function(e) {
                        e(t)
                    }))).then(a, u)
                }
                c((r = r.apply(e, t || [])).next())
            }))
        },
        Je = function(e, t) {
            var n, r, o, i, a = {
                label: 0,
                sent: function() {
                    if (1 & o[0]) throw o[1];
                    return o[1]
                },
                trys: [],
                ops: []
            };
            return i = {
                next: u(0),
                throw: u(1),
                return: u(2)
            }, "function" == typeof Symbol && (i[Symbol.iterator] = function() {
                return this
            }), i;

            function u(i) {
                return function(u) {
                    return function(i) {
                        if (n) throw new TypeError("Generator is already executing.");
                        for (; a;) try {
                            if (n = 1, r && (o = 2 & i[0] ? r.return : i[0] ? r.throw || ((o = r.return) && o.call(r), 0) : r.next) && !(o = o.call(r, i[1])).done) return o;
                            switch (r = 0, o && (i = [2 & i[0], o.value]), i[0]) {
                                case 0:
                                case 1:
                                    o = i;
                                    break;
                                case 4:
                                    return a.label++, {
                                        value: i[1],
                                        done: !1
                                    };
                                case 5:
                                    a.label++, r = i[1], i = [0];
                                    continue;
                                case 7:
                                    i = a.ops.pop(), a.trys.pop();
                                    continue;
                                default:
                                    if (!(o = a.trys, (o = o.length > 0 && o[o.length - 1]) || 6 !== i[0] && 2 !== i[0])) {
                                        a = 0;
                                        continue
                                    }
                                    if (3 === i[0] && (!o || i[1] > o[0] && i[1] < o[3])) {
                                        a.label = i[1];
                                        break
                                    }
                                    if (6 === i[0] && a.label < o[1]) {
                                        a.label = o[1], o = i;
                                        break
                                    }
                                    if (o && a.label < o[2]) {
                                        a.label = o[2], a.ops.push(i);
                                        break
                                    }
                                    o[2] && a.ops.pop(), a.trys.pop();
                                    continue
                            }
                            i = t.call(e, a)
                        } catch (e) {
                            i = [6, e], r = 0
                        } finally {
                            n = o = 0
                        }
                        if (5 & i[0]) throw i[1];
                        return {
                            value: i[0] ? i[1] : void 0,
                            done: !0
                        }
                    }([i, u])
                }
            }
        },
        Ze = function() {
            return je(void 0, void 0, Promise, (function() {
                return Je(this, (function(e) {
                    return [2, B(g.httpService.get(ze, {}), Ve)]
                }))
            }))
        },
        $e = null !== (Xe = w.EnvironmentUrls.authApi) && void 0 !== Xe ? Xe : "URL_NOT_FOUND";
    ! function(e) {
        e[e.UNKNOWN = 0] = "UNKNOWN"
    }(qe || (qe = {}));
    var et, tt, nt, rt, ot, it = {
            withCredentials: !0,
            url: $e + "/v1/" + "palisades-live/is-live",
            timeout: 1e4
        },
        at = {
            withCredentials: !0,
            url: $e + "/v1/" + "palisades-live/disconnect",
            timeout: 1e4
        },
        ut = function() {
            return B(g.httpService.get(it, {}), qe)
        },
        ct = function() {
            return B(g.httpService.post(at, {}), qe)
        },
        st = (null !== (et = w.EnvironmentUrls.apiGatewayUrl) && void 0 !== et ? et : "URL_NOT_FOUND") + "/account-security-service";
    ! function(e) {
        e[e.UNKNOWN = 1] = "UNKNOWN", e[e.REQUEST_TYPE_WAS_INVALID = 2] = "REQUEST_TYPE_WAS_INVALID", e[e.PROMPT_ASSIGNMENT_WAS_NOT_UPDATED = 3] = "PROMPT_ASSIGNMENT_WAS_NOT_UPDATED", e[e.UNKNOWN_PROMPT_TYPE = 4] = "UNKNOWN_PROMPT_TYPE"
    }(tt || (tt = {})),
    function(e) {
        e.TEXT_ONLY_BANNER = "DISPLAY_TYPE_TEXT_ONLY_BANNER"
    }(nt || (nt = {})),
    function(e) {
        e.GLOBAL = "PAGE_RESTRICTION_GLOBAL", e.HOME_PAGE_ONLY = "PAGE_RESTRICTION_HOME_PAGE"
    }(rt || (rt = {})),
    function(e) {
        e.CHANGE_PASSWORD__SUSPECTED_COMPROMISE = "PROMPT_TYPE_CHANGE_PASSWORD__SUSPECTED_COMPROMISE", e.CHANGE_PASSWORD__BREACHED_CREDENTIAL = "PROMPT_TYPE_CHANGE_PASSWORD__BREACHED_CREDENTIAL", e.AUTHENTICATOR_UPSELL = "PROMPT_TYPE_AUTHENTICATOR_UPSELL", e.ACCOUNT_RESTORES_POLICY_UPDATE = "PROMPT_TYPE_ACCOUNT_RESTORES_POLICY_UPDATE", e.ACCOUNT_RESTORES_POLICY_UPDATE_V2 = "PROMPT_TYPE_ACCOUNT_RESTORES_POLICY_UPDATE_V2", e.ACCOUNT_RESTORES_POLICY_UPDATE_V3 = "PROMPT_TYPE_ACCOUNT_RESTORES_POLICY_UPDATE_V3", e.ACCOUNT_RESTORES_POLICY_UPSELL = "PROMPT_TYPE_ACCOUNT_RESTORES_POLICY_UPSELL", e.BROADER_AUTHENTICATOR_UPSELL = "PROMPT_TYPE_BROADER_AUTHENTICATOR_UPSELL", e.EMAIL_2SV_UPSELL = "PROMPT_TYPE_EMAIL_2SV_UPSELL"
    }(ot || (ot = {}));
    var lt, dt = {
        withCredentials: !0,
        url: st + "/v1/prompt-assignments",
        timeout: 1e4
    };
    ! function(e) {
        e.DISMISS_PROMPT = "DISMISS_PROMPT", e.DISABLE_PROMPT = "DISABLE_PROMPT"
    }(lt || (lt = {}));
    var pt, ft, Et = {
            withCredentials: !0,
            url: st + "/v1/prompt-assignments",
            timeout: 1e4
        },
        mt = function() {
            return (mt = Object.assign || function(e) {
                for (var t, n = 1, r = arguments.length; n < r; n++)
                    for (var o in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                return e
            }).apply(this, arguments)
        },
        ht = function(e, t, n, r) {
            return new(n || (n = Promise))((function(o, i) {
                function a(e) {
                    try {
                        c(r.next(e))
                    } catch (e) {
                        i(e)
                    }
                }

                function u(e) {
                    try {
                        c(r.throw(e))
                    } catch (e) {
                        i(e)
                    }
                }

                function c(e) {
                    var t;
                    e.done ? o(e.value) : (t = e.value, t instanceof n ? t : new n((function(e) {
                        e(t)
                    }))).then(a, u)
                }
                c((r = r.apply(e, t || [])).next())
            }))
        },
        St = function(e, t) {
            var n, r, o, i, a = {
                label: 0,
                sent: function() {
                    if (1 & o[0]) throw o[1];
                    return o[1]
                },
                trys: [],
                ops: []
            };
            return i = {
                next: u(0),
                throw: u(1),
                return: u(2)
            }, "function" == typeof Symbol && (i[Symbol.iterator] = function() {
                return this
            }), i;

            function u(i) {
                return function(u) {
                    return function(i) {
                        if (n) throw new TypeError("Generator is already executing.");
                        for (; a;) try {
                            if (n = 1, r && (o = 2 & i[0] ? r.return : i[0] ? r.throw || ((o = r.return) && o.call(r), 0) : r.next) && !(o = o.call(r, i[1])).done) return o;
                            switch (r = 0, o && (i = [2 & i[0], o.value]), i[0]) {
                                case 0:
                                case 1:
                                    o = i;
                                    break;
                                case 4:
                                    return a.label++, {
                                        value: i[1],
                                        done: !1
                                    };
                                case 5:
                                    a.label++, r = i[1], i = [0];
                                    continue;
                                case 7:
                                    i = a.ops.pop(), a.trys.pop();
                                    continue;
                                default:
                                    if (!(o = a.trys, (o = o.length > 0 && o[o.length - 1]) || 6 !== i[0] && 2 !== i[0])) {
                                        a = 0;
                                        continue
                                    }
                                    if (3 === i[0] && (!o || i[1] > o[0] && i[1] < o[3])) {
                                        a.label = i[1];
                                        break
                                    }
                                    if (6 === i[0] && a.label < o[1]) {
                                        a.label = o[1], o = i;
                                        break
                                    }
                                    if (o && a.label < o[2]) {
                                        a.label = o[2], a.ops.push(i);
                                        break
                                    }
                                    o[2] && a.ops.pop(), a.trys.pop();
                                    continue
                            }
                            i = t.call(e, a)
                        } catch (e) {
                            i = [6, e], r = 0
                        } finally {
                            n = o = 0
                        }
                        if (5 & i[0]) throw i[1];
                        return {
                            value: i[0] ? i[1] : void 0,
                            done: !0
                        }
                    }([i, u])
                }
            }
        },
        vt = function() {
            return ht(void 0, void 0, Promise, (function() {
                var e;
                return St(this, (function(t) {
                    switch (t.label) {
                        case 0:
                            return [4, B(g.httpService.get(dt, {
                                shouldReturnMetadata: !0
                            }), tt)];
                        case 1:
                            return (e = t.sent()).isError ? [2, e] : [2, e = mt(mt({}, e), {
                                value: e.value.filter((function(e) {
                                    return e.isGeneric ? Object.values(nt).includes(e.metadata.displayType) : Object.values(ot).includes(e.promptType)
                                }))
                            })]
                    }
                }))
            }))
        },
        At = function(e, t) {
            return B(g.httpService.post(Et, {
                action: e,
                promptType: t
            }), tt)
        },
        _t = (null !== (pt = w.EnvironmentUrls.apiGatewayUrl) && void 0 !== pt ? pt : "URL_NOT_FOUND") + "/proof-of-space";
    ! function(e) {
        e[e.UNKNOWN = 0] = "UNKNOWN", e[e.INTERNAL_ERROR = 1] = "INTERNAL_ERROR", e[e.INVALID_REQUEST = 2] = "INVALID_REQUEST", e[e.INVALID_SESSION = 3] = "INVALID_SESSION"
    }(ft || (ft = {}));
    var Nt, Tt, Ot, bt = {
            withCredentials: !0,
            url: _t + "/v1/verify",
            timeout: 1e4
        },
        yt = function(e, t, n, r) {
            return new(n || (n = Promise))((function(o, i) {
                function a(e) {
                    try {
                        c(r.next(e))
                    } catch (e) {
                        i(e)
                    }
                }

                function u(e) {
                    try {
                        c(r.throw(e))
                    } catch (e) {
                        i(e)
                    }
                }

                function c(e) {
                    var t;
                    e.done ? o(e.value) : (t = e.value, t instanceof n ? t : new n((function(e) {
                        e(t)
                    }))).then(a, u)
                }
                c((r = r.apply(e, t || [])).next())
            }))
        },
        Ct = function(e, t) {
            var n, r, o, i, a = {
                label: 0,
                sent: function() {
                    if (1 & o[0]) throw o[1];
                    return o[1]
                },
                trys: [],
                ops: []
            };
            return i = {
                next: u(0),
                throw: u(1),
                return: u(2)
            }, "function" == typeof Symbol && (i[Symbol.iterator] = function() {
                return this
            }), i;

            function u(i) {
                return function(u) {
                    return function(i) {
                        if (n) throw new TypeError("Generator is already executing.");
                        for (; a;) try {
                            if (n = 1, r && (o = 2 & i[0] ? r.return : i[0] ? r.throw || ((o = r.return) && o.call(r), 0) : r.next) && !(o = o.call(r, i[1])).done) return o;
                            switch (r = 0, o && (i = [2 & i[0], o.value]), i[0]) {
                                case 0:
                                case 1:
                                    o = i;
                                    break;
                                case 4:
                                    return a.label++, {
                                        value: i[1],
                                        done: !1
                                    };
                                case 5:
                                    a.label++, r = i[1], i = [0];
                                    continue;
                                case 7:
                                    i = a.ops.pop(), a.trys.pop();
                                    continue;
                                default:
                                    if (!(o = a.trys, (o = o.length > 0 && o[o.length - 1]) || 6 !== i[0] && 2 !== i[0])) {
                                        a = 0;
                                        continue
                                    }
                                    if (3 === i[0] && (!o || i[1] > o[0] && i[1] < o[3])) {
                                        a.label = i[1];
                                        break
                                    }
                                    if (6 === i[0] && a.label < o[1]) {
                                        a.label = o[1], o = i;
                                        break
                                    }
                                    if (o && a.label < o[2]) {
                                        a.label = o[2], a.ops.push(i);
                                        break
                                    }
                                    o[2] && a.ops.pop(), a.trys.pop();
                                    continue
                            }
                            i = t.call(e, a)
                        } catch (e) {
                            i = [6, e], r = 0
                        } finally {
                            n = o = 0
                        }
                        if (5 & i[0]) throw i[1];
                        return {
                            value: i[0] ? i[1] : void 0,
                            done: !0
                        }
                    }([i, u])
                }
            }
        },
        Pt = function(e, t) {
            return yt(void 0, void 0, Promise, (function() {
                return Ct(this, (function(n) {
                    return [2, B(g.httpService.post(bt, {
                        challengeId: e,
                        solution: t
                    }), ft)]
                }))
            }))
        },
        wt = (null !== (Nt = w.EnvironmentUrls.apiGatewayUrl) && void 0 !== Nt ? Nt : "URL_NOT_FOUND") + "/proof-of-work-service";
    ! function(e) {
        e[e.UNKNOWN = 0] = "UNKNOWN", e[e.REQUEST_INVALID = 1] = "REQUEST_INVALID", e[e.SESSION_INACTIVE = 2] = "SESSION_INACTIVE"
    }(Tt || (Tt = {})),
    function(e) {
        e[e.TIME_LOCK = 0] = "TIME_LOCK"
    }(Ot || (Ot = {}));
    var Rt, It, Ut = {
            withCredentials: !0,
            url: wt + "/v1/pow-puzzle",
            timeout: 1e4
        },
        Dt = {
            withCredentials: !0,
            url: wt + "/v1/pow-puzzle",
            timeout: 1e4
        },
        gt = function(e, t, n, r) {
            return new(n || (n = Promise))((function(o, i) {
                function a(e) {
                    try {
                        c(r.next(e))
                    } catch (e) {
                        i(e)
                    }
                }

                function u(e) {
                    try {
                        c(r.throw(e))
                    } catch (e) {
                        i(e)
                    }
                }

                function c(e) {
                    var t;
                    e.done ? o(e.value) : (t = e.value, t instanceof n ? t : new n((function(e) {
                        e(t)
                    }))).then(a, u)
                }
                c((r = r.apply(e, t || [])).next())
            }))
        },
        Lt = function(e, t) {
            var n, r, o, i, a = {
                label: 0,
                sent: function() {
                    if (1 & o[0]) throw o[1];
                    return o[1]
                },
                trys: [],
                ops: []
            };
            return i = {
                next: u(0),
                throw: u(1),
                return: u(2)
            }, "function" == typeof Symbol && (i[Symbol.iterator] = function() {
                return this
            }), i;

            function u(i) {
                return function(u) {
                    return function(i) {
                        if (n) throw new TypeError("Generator is already executing.");
                        for (; a;) try {
                            if (n = 1, r && (o = 2 & i[0] ? r.return : i[0] ? r.throw || ((o = r.return) && o.call(r), 0) : r.next) && !(o = o.call(r, i[1])).done) return o;
                            switch (r = 0, o && (i = [2 & i[0], o.value]), i[0]) {
                                case 0:
                                case 1:
                                    o = i;
                                    break;
                                case 4:
                                    return a.label++, {
                                        value: i[1],
                                        done: !1
                                    };
                                case 5:
                                    a.label++, r = i[1], i = [0];
                                    continue;
                                case 7:
                                    i = a.ops.pop(), a.trys.pop();
                                    continue;
                                default:
                                    if (!(o = a.trys, (o = o.length > 0 && o[o.length - 1]) || 6 !== i[0] && 2 !== i[0])) {
                                        a = 0;
                                        continue
                                    }
                                    if (3 === i[0] && (!o || i[1] > o[0] && i[1] < o[3])) {
                                        a.label = i[1];
                                        break
                                    }
                                    if (6 === i[0] && a.label < o[1]) {
                                        a.label = o[1], o = i;
                                        break
                                    }
                                    if (o && a.label < o[2]) {
                                        a.label = o[2], a.ops.push(i);
                                        break
                                    }
                                    o[2] && a.ops.pop(), a.trys.pop();
                                    continue
                            }
                            i = t.call(e, a)
                        } catch (e) {
                            i = [6, e], r = 0
                        } finally {
                            n = o = 0
                        }
                        if (5 & i[0]) throw i[1];
                        return {
                            value: i[0] ? i[1] : void 0,
                            done: !0
                        }
                    }([i, u])
                }
            }
        },
        Mt = function(e) {
            return B(g.httpService.get(Ut, {
                sessionID: e
            }), Tt)
        },
        kt = function(e, t) {
            return gt(void 0, void 0, Promise, (function() {
                return Lt(this, (function(n) {
                    return [2, B(g.httpService.post(Dt, {
                        sessionID: e,
                        solution: t
                    }), Tt)]
                }))
            }))
        },
        xt = (null !== (Rt = w.EnvironmentUrls.apiGatewayUrl) && void 0 !== Rt ? Rt : "URL_NOT_FOUND") + "/reauthentication-service";
    ! function(e) {
        e[e.UNKNOWN = 1] = "UNKNOWN", e[e.REQUEST_TYPE_WAS_INVALID = 2] = "REQUEST_TYPE_WAS_INVALID", e[e.PASSWORD_INCORRECT = 3] = "PASSWORD_INCORRECT", e[e.OTP_EMAIL_REDEEM_FAILURE = 4] = "OTP_EMAIL_REDEEM_FAILURE"
    }(It || (It = {}));
    var Ft, Vt, Ht = {
            withCredentials: !0,
            url: xt + "/v1/token/generate",
            timeout: 1e4
        },
        Wt = function(e) {
            return B(g.httpService.post(Ht, e), It)
        },
        Bt = (null !== (Ft = w.EnvironmentUrls.apiGatewayUrl) && void 0 !== Ft ? Ft : "URL_NOT_FOUND") + "/rostile";
    ! function(e) {
        e[e.UNKNOWN = 0] = "UNKNOWN", e[e.INTERNAL_ERROR = 1] = "INTERNAL_ERROR", e[e.INVALID_REQUEST = 2] = "INVALID_REQUEST", e[e.INVALID_SESSION = 3] = "INVALID_SESSION"
    }(Vt || (Vt = {}));
    var Yt, Gt, Kt, Qt, Xt = {
            withCredentials: !0,
            url: Bt + "/v1/verify",
            timeout: 1e4
        },
        qt = function(e, t, n, r) {
            return new(n || (n = Promise))((function(o, i) {
                function a(e) {
                    try {
                        c(r.next(e))
                    } catch (e) {
                        i(e)
                    }
                }

                function u(e) {
                    try {
                        c(r.throw(e))
                    } catch (e) {
                        i(e)
                    }
                }

                function c(e) {
                    var t;
                    e.done ? o(e.value) : (t = e.value, t instanceof n ? t : new n((function(e) {
                        e(t)
                    }))).then(a, u)
                }
                c((r = r.apply(e, t || [])).next())
            }))
        },
        zt = function(e, t) {
            var n, r, o, i, a = {
                label: 0,
                sent: function() {
                    if (1 & o[0]) throw o[1];
                    return o[1]
                },
                trys: [],
                ops: []
            };
            return i = {
                next: u(0),
                throw: u(1),
                return: u(2)
            }, "function" == typeof Symbol && (i[Symbol.iterator] = function() {
                return this
            }), i;

            function u(i) {
                return function(u) {
                    return function(i) {
                        if (n) throw new TypeError("Generator is already executing.");
                        for (; a;) try {
                            if (n = 1, r && (o = 2 & i[0] ? r.return : i[0] ? r.throw || ((o = r.return) && o.call(r), 0) : r.next) && !(o = o.call(r, i[1])).done) return o;
                            switch (r = 0, o && (i = [2 & i[0], o.value]), i[0]) {
                                case 0:
                                case 1:
                                    o = i;
                                    break;
                                case 4:
                                    return a.label++, {
                                        value: i[1],
                                        done: !1
                                    };
                                case 5:
                                    a.label++, r = i[1], i = [0];
                                    continue;
                                case 7:
                                    i = a.ops.pop(), a.trys.pop();
                                    continue;
                                default:
                                    if (!(o = a.trys, (o = o.length > 0 && o[o.length - 1]) || 6 !== i[0] && 2 !== i[0])) {
                                        a = 0;
                                        continue
                                    }
                                    if (3 === i[0] && (!o || i[1] > o[0] && i[1] < o[3])) {
                                        a.label = i[1];
                                        break
                                    }
                                    if (6 === i[0] && a.label < o[1]) {
                                        a.label = o[1], o = i;
                                        break
                                    }
                                    if (o && a.label < o[2]) {
                                        a.label = o[2], a.ops.push(i);
                                        break
                                    }
                                    o[2] && a.ops.pop(), a.trys.pop();
                                    continue
                            }
                            i = t.call(e, a)
                        } catch (e) {
                            i = [6, e], r = 0
                        } finally {
                            n = o = 0
                        }
                        if (5 & i[0]) throw i[1];
                        return {
                            value: i[0] ? i[1] : void 0,
                            done: !0
                        }
                    }([i, u])
                }
            }
        },
        jt = function(e, t) {
            return qt(void 0, void 0, Promise, (function() {
                return zt(this, (function(n) {
                    return [2, B(g.httpService.post(Xt, {
                        challengeId: e,
                        solution: t
                    }), Vt)]
                }))
            }))
        },
        Jt = (null !== (Yt = w.EnvironmentUrls.apiGatewayUrl) && void 0 !== Yt ? Yt : "URL_NOT_FOUND") + "/account-security-service";
    ! function(e) {
        e[e.UNKNOWN = 1] = "UNKNOWN", e[e.REQUEST_TYPE_WAS_INVALID = 2] = "REQUEST_TYPE_WAS_INVALID", e[e.SECURITY_QUESTIONS_DISABLED = 3] = "SECURITY_QUESTIONS_DISABLED", e[e.SESSION_INACTIVE = 4] = "SESSION_INACTIVE", e[e.QUESTION_NOT_FOUND = 5] = "QUESTION_NOT_FOUND", e[e.ANSWER_WRONG_FORMAT = 6] = "ANSWER_WRONG_FORMAT"
    }(Gt || (Gt = {})),
    function(e) {
        e[e.INVALID = 0] = "INVALID", e[e.MOST_RECENT_GAMES_PLAYED = 1] = "MOST_RECENT_GAMES_PLAYED"
    }(Kt || (Kt = {})),
    function(e) {
        e[e.PICK_ALL_CORRECT_CHOICES = 0] = "PICK_ALL_CORRECT_CHOICES", e[e.PICK_C_CORRECT_CHOICES = 1] = "PICK_C_CORRECT_CHOICES"
    }(Qt || (Qt = {}));
    var Zt, $t, en, tn, nn, rn = {
            withCredentials: !0,
            url: Jt + "/v1/security-question",
            timeout: 1e4
        },
        on = {
            withCredentials: !0,
            url: Jt + "/v1/security-question",
            timeout: 1e4
        },
        an = function(e, t) {
            return B(g.httpService.get(rn, {
                userId: e,
                sessionId: t
            }), Gt)
        },
        un = function(e, t, n) {
            return B(g.httpService.post(on, {
                userId: e,
                answer: t,
                sessionId: n
            }), Gt)
        },
        cn = "URL_NOT_FOUND",
        sn = null !== (Zt = w.EnvironmentUrls.apiGatewayUrl) && void 0 !== Zt ? Zt : cn,
        ln = null !== ($t = w.EnvironmentUrls.authApi) && void 0 !== $t ? $t : cn,
        dn = sn + "/token-metadata-service";
    ! function(e) {
        e[e.UNKNOWN = 1] = "UNKNOWN", e[e.REQUEST_TYPE_WAS_INVALID = 2] = "REQUEST_TYPE_WAS_INVALID", e[e.ATTEMPT_TO_INVALIDATE_CURRENT_TOKEN = 3] = "ATTEMPT_TO_INVALIDATE_CURRENT_TOKEN"
    }(en || (en = {})),
    function(e) {
        e[e.UNKNOWN = 1] = "UNKNOWN"
    }(tn || (tn = {})),
    function(e) {
        e.UNKNOWN = "Unknown", e.APP = "App", e.BROWSER = "Browser", e.STUDIO = "Studio"
    }(nn || (nn = {}));
    var pn, fn, En, mn, hn = {
            withCredentials: !0,
            url: dn + "/v1/sessions",
            timeout: 1e4
        },
        Sn = {
            withCredentials: !0,
            url: dn + "/v1/logout",
            timeout: 1e4
        },
        vn = {
            withCredentials: !0,
            url: ln + "/v1/logoutfromallsessionsandreauthenticate",
            timeout: 1e4
        },
        An = function(e, t, n, r) {
            return new(n || (n = Promise))((function(o, i) {
                function a(e) {
                    try {
                        c(r.next(e))
                    } catch (e) {
                        i(e)
                    }
                }

                function u(e) {
                    try {
                        c(r.throw(e))
                    } catch (e) {
                        i(e)
                    }
                }

                function c(e) {
                    var t;
                    e.done ? o(e.value) : (t = e.value, t instanceof n ? t : new n((function(e) {
                        e(t)
                    }))).then(a, u)
                }
                c((r = r.apply(e, t || [])).next())
            }))
        },
        _n = function(e, t) {
            var n, r, o, i, a = {
                label: 0,
                sent: function() {
                    if (1 & o[0]) throw o[1];
                    return o[1]
                },
                trys: [],
                ops: []
            };
            return i = {
                next: u(0),
                throw: u(1),
                return: u(2)
            }, "function" == typeof Symbol && (i[Symbol.iterator] = function() {
                return this
            }), i;

            function u(i) {
                return function(u) {
                    return function(i) {
                        if (n) throw new TypeError("Generator is already executing.");
                        for (; a;) try {
                            if (n = 1, r && (o = 2 & i[0] ? r.return : i[0] ? r.throw || ((o = r.return) && o.call(r), 0) : r.next) && !(o = o.call(r, i[1])).done) return o;
                            switch (r = 0, o && (i = [2 & i[0], o.value]), i[0]) {
                                case 0:
                                case 1:
                                    o = i;
                                    break;
                                case 4:
                                    return a.label++, {
                                        value: i[1],
                                        done: !1
                                    };
                                case 5:
                                    a.label++, r = i[1], i = [0];
                                    continue;
                                case 7:
                                    i = a.ops.pop(), a.trys.pop();
                                    continue;
                                default:
                                    if (!(o = a.trys, (o = o.length > 0 && o[o.length - 1]) || 6 !== i[0] && 2 !== i[0])) {
                                        a = 0;
                                        continue
                                    }
                                    if (3 === i[0] && (!o || i[1] > o[0] && i[1] < o[3])) {
                                        a.label = i[1];
                                        break
                                    }
                                    if (6 === i[0] && a.label < o[1]) {
                                        a.label = o[1], o = i;
                                        break
                                    }
                                    if (o && a.label < o[2]) {
                                        a.label = o[2], a.ops.push(i);
                                        break
                                    }
                                    o[2] && a.ops.pop(), a.trys.pop();
                                    continue
                            }
                            i = t.call(e, a)
                        } catch (e) {
                            i = [6, e], r = 0
                        } finally {
                            n = o = 0
                        }
                        if (5 & i[0]) throw i[1];
                        return {
                            value: i[0] ? i[1] : void 0,
                            done: !0
                        }
                    }([i, u])
                }
            }
        },
        Nn = function(e, t) {
            return An(void 0, void 0, Promise, (function() {
                return _n(this, (function(n) {
                    return [2, B(g.httpService.get(hn, {
                        nextCursor: e,
                        desiredLimit: t
                    }), en)]
                }))
            }))
        },
        Tn = function(e) {
            return An(void 0, void 0, Promise, (function() {
                return _n(this, (function(t) {
                    return [2, B(g.httpService.post(Sn, {
                        token: e
                    }), en)]
                }))
            }))
        },
        On = function(e) {
            return An(void 0, void 0, Promise, (function() {
                return _n(this, (function(t) {
                    return [2, B(g.httpService.post(vn, {
                        secureAuthenticationIntent: e
                    }), tn)]
                }))
            }))
        },
        bn = null !== (pn = w.EnvironmentUrls.thumbnailsApi) && void 0 !== pn ? pn : "URL_NOT_FOUND";
    ! function(e) {
        e[e.UNKNOWN = 0] = "UNKNOWN"
    }(fn || (fn = {})),
    function(e) {
        e.PNG = "Png", e.JPEG = "Jpeg"
    }(En || (En = {})),
    function(e) {
        e.ERROR = "Error", e.COMPLETED = "Completed", e.IN_REVIEW = "InReview", e.PENDING = "Pending", e.BLOCKED = "Blocked"
    }(mn || (mn = {}));
    var yn, Cn, Pn, wn, Rn = {
            url: bn + "/v1/games/icons",
            timeout: 1e4
        },
        In = function(e, t, n, r) {
            return B(g.httpService.get(Rn, {
                universeIds: e,
                size: t,
                format: n,
                isCircular: r
            }), fn)
        },
        Un = CoreRobloxUtilities,
        Dn = "URL_NOT_FOUND",
        gn = null !== (yn = w.EnvironmentUrls.twoStepVerificationApi) && void 0 !== yn ? yn : Dn,
        Ln = null !== (Cn = w.EnvironmentUrls.economyApi) && void 0 !== Cn ? Cn : Dn,
        Mn = null !== (Pn = w.EnvironmentUrls.tradesApi) && void 0 !== Pn ? Pn : Dn,
        kn = 1e4;
    ! function(e) {
        e[e.UNKNOWN = 0] = "UNKNOWN", e[e.INVALID_CHALLENGE_ID = 1] = "INVALID_CHALLENGE_ID", e[e.INVALID_USER_ID = 2] = "INVALID_USER_ID", e[e.INVALID_EMAIL = 3] = "INVALID_EMAIL", e[e.INVALID_PASSWORD = 4] = "INVALID_PASSWORD", e[e.TOO_MANY_REQUESTS = 5] = "TOO_MANY_REQUESTS", e[e.PIN_LOCKED = 6] = "PIN_LOCKED", e[e.FEATURE_DISABLED = 7] = "FEATURE_DISABLED", e[e.NOT_ALLOWED = 8] = "NOT_ALLOWED", e[e.INVALID_CONFIGURATION = 9] = "INVALID_CONFIGURATION", e[e.INVALID_CODE = 10] = "INVALID_CODE", e[e.CONFIGURATION_ALREADY_ENABLED = 11] = "CONFIGURATION_ALREADY_ENABLED", e[e.INVALID_SETUP_TOKEN = 12] = "INVALID_SETUP_TOKEN", e[e.REAUTHENTICATION_REQUIRED = 13] = "REAUTHENTICATION_REQUIRED", e[e.INVALID_PHONE_NUMBER = 15] = "INVALID_PHONE_NUMBER", e[e.EXCEEDED_REGISTERED_KEYS_LIMIT = 16] = "EXCEEDED_REGISTERED_KEYS_LIMIT", e[e.INVALID_CREDENTIAL_NICKNAME = 17] = "INVALID_CREDENTIAL_NICKNAME", e[e.AUTHENTICATOR_CODE_ALREADY_USED = 18] = "AUTHENTICATOR_CODE_ALREADY_USED", e[e.CHALLENGE_DENIED = 19] = "CHALLENGE_DENIED", e[e.CROSS_DEVICE_DIALOG_EXPIRED = 20] = "CROSS_DEVICE_DIALOG_EXPIRED"
    }(wn || (wn = {}));
    var xn, Fn, Vn = {
            url: gn + "/v1/metadata",
            withCredentials: !0,
            timeout: kn
        },
        Hn = function(e) {
            return {
                withCredentials: !0,
                url: gn + "/v1/users/" + e + "/configuration/email/enable",
                timeout: kn
            }
        },
        Wn = function(e) {
            return {
                withCredentials: !0,
                url: gn + "/v1/users/" + e + "/configuration/authenticator/enable-verify",
                timeout: kn
            }
        },
        Bn = function(e) {
            return {
                withCredentials: !0,
                url: gn + "/v1/users/" + e + "/configuration/sms/enable",
                timeout: kn
            }
        },
        Yn = function(e) {
            return {
                withCredentials: !0,
                url: gn + "/v1/users/" + e + "/configuration/security-key/enable-verify",
                timeout: kn
            }
        },
        Gn = {
            withCredentials: !0,
            url: Ln + "/v2/spend-friction/two-step-verification/status",
            timeout: kn
        },
        Kn = {
            withCredentials: !0,
            url: Mn + "/v1/trade-friction/two-step-verification/status",
            timeout: kn
        },
        Qn = {
            withCredentials: !0,
            url: Ln + "/v2/resale-friction/two-step-verification/status",
            timeout: kn
        },
        Xn = {
            withCredentials: !0,
            url: Ln + "/v2/spend-friction/two-step-verification/generate",
            timeout: kn
        },
        qn = {
            withCredentials: !0,
            url: Mn + "/v1/trade-friction/two-step-verification/generate",
            timeout: kn
        },
        zn = {
            withCredentials: !0,
            url: Ln + "/v2/resale-friction/two-step-verification/generate",
            timeout: kn
        },
        jn = {
            withCredentials: !0,
            url: Ln + "/v2/spend-friction/two-step-verification/redeem",
            timeout: kn
        },
        Jn = {
            withCredentials: !0,
            url: Mn + "/v1/trade-friction/two-step-verification/redeem",
            timeout: kn
        },
        Zn = {
            withCredentials: !0,
            url: Ln + "/v2/resale-friction/two-step-verification/redeem",
            timeout: kn
        },
        $n = function(e, t, n, r) {
            return new(n || (n = Promise))((function(o, i) {
                function a(e) {
                    try {
                        c(r.next(e))
                    } catch (e) {
                        i(e)
                    }
                }

                function u(e) {
                    try {
                        c(r.throw(e))
                    } catch (e) {
                        i(e)
                    }
                }

                function c(e) {
                    var t;
                    e.done ? o(e.value) : (t = e.value, t instanceof n ? t : new n((function(e) {
                        e(t)
                    }))).then(a, u)
                }
                c((r = r.apply(e, t || [])).next())
            }))
        },
        er = function(e, t) {
            var n, r, o, i, a = {
                label: 0,
                sent: function() {
                    if (1 & o[0]) throw o[1];
                    return o[1]
                },
                trys: [],
                ops: []
            };
            return i = {
                next: u(0),
                throw: u(1),
                return: u(2)
            }, "function" == typeof Symbol && (i[Symbol.iterator] = function() {
                return this
            }), i;

            function u(i) {
                return function(u) {
                    return function(i) {
                        if (n) throw new TypeError("Generator is already executing.");
                        for (; a;) try {
                            if (n = 1, r && (o = 2 & i[0] ? r.return : i[0] ? r.throw || ((o = r.return) && o.call(r), 0) : r.next) && !(o = o.call(r, i[1])).done) return o;
                            switch (r = 0, o && (i = [2 & i[0], o.value]), i[0]) {
                                case 0:
                                case 1:
                                    o = i;
                                    break;
                                case 4:
                                    return a.label++, {
                                        value: i[1],
                                        done: !1
                                    };
                                case 5:
                                    a.label++, r = i[1], i = [0];
                                    continue;
                                case 7:
                                    i = a.ops.pop(), a.trys.pop();
                                    continue;
                                default:
                                    if (!(o = a.trys, (o = o.length > 0 && o[o.length - 1]) || 6 !== i[0] && 2 !== i[0])) {
                                        a = 0;
                                        continue
                                    }
                                    if (3 === i[0] && (!o || i[1] > o[0] && i[1] < o[3])) {
                                        a.label = i[1];
                                        break
                                    }
                                    if (6 === i[0] && a.label < o[1]) {
                                        a.label = o[1], o = i;
                                        break
                                    }
                                    if (o && a.label < o[2]) {
                                        a.label = o[2], a.ops.push(i);
                                        break
                                    }
                                    o[2] && a.ops.pop(), a.trys.pop();
                                    continue
                            }
                            i = t.call(e, a)
                        } catch (e) {
                            i = [6, e], r = 0
                        } finally {
                            n = o = 0
                        }
                        if (5 & i[0]) throw i[1];
                        return {
                            value: i[0] ? i[1] : void 0,
                            done: !0
                        }
                    }([i, u])
                }
            }
        },
        tr = Un.cryptoUtil.generateSecureAuthIntent,
        nr = function(e) {
            return B(g.httpService.get(Vn, e || {}), wn)
        },
        rr = function(e, t) {
            return B(g.httpService.get(function(e) {
                return {
                    withCredentials: !0,
                    url: gn + "/v1/users/" + e + "/configuration",
                    timeout: kn
                }
            }(e), t || {}), wn)
        },
        or = function(e) {
            return $n(void 0, void 0, Promise, (function() {
                var t;
                return er(this, (function(n) {
                    switch (n.label) {
                        case 0:
                            return [4, tr()];
                        case 1:
                            return t = n.sent(), [2, B(g.httpService.post(Hn(e), {
                                secureAuthenticationIntent: t
                            }), wn)]
                    }
                }))
            }))
        },
        ir = function(e, t) {
            return B(g.httpService.post(function(e) {
                return {
                    withCredentials: !0,
                    url: gn + "/v1/users/" + e + "/challenges/email/send-code",
                    timeout: kn
                }
            }(e), t), wn)
        },
        ar = function(e, t) {
            return B(g.httpService.post(function(e) {
                return {
                    withCredentials: !0,
                    url: gn + "/v1/users/" + e + "/challenges/email/verify",
                    timeout: kn
                }
            }(e), t), wn)
        },
        ur = function(e) {
            return B(g.httpService.post(function(e) {
                return {
                    withCredentials: !0,
                    url: gn + "/v1/users/" + e + "/configuration/email/disable",
                    timeout: kn
                }
            }(e), {}), wn)
        },
        cr = function(e) {
            return B(g.httpService.post(function(e) {
                return {
                    withCredentials: !0,
                    url: gn + "/v1/users/" + e + "/configuration/authenticator/enable",
                    timeout: kn
                }
            }(e), {}), wn)
        },
        sr = function(e, t, n) {
            return $n(void 0, void 0, Promise, (function() {
                var r;
                return er(this, (function(o) {
                    switch (o.label) {
                        case 0:
                            return [4, tr()];
                        case 1:
                            return r = o.sent(), [2, B(g.httpService.post(Wn(e), {
                                setupToken: t,
                                code: n,
                                secureAuthenticationIntent: r
                            }), wn)]
                    }
                }))
            }))
        },
        lr = function(e, t) {
            return B(g.httpService.post(function(e) {
                return {
                    withCredentials: !0,
                    url: gn + "/v1/users/" + e + "/challenges/authenticator/verify",
                    timeout: kn
                }
            }(e), t), wn)
        },
        dr = function(e) {
            return B(g.httpService.post(function(e) {
                return {
                    withCredentials: !0,
                    url: gn + "/v1/users/" + e + "/configuration/authenticator/disable",
                    timeout: kn
                }
            }(e), {}), wn)
        },
        pr = function(e, t) {
            return B(g.httpService.post(function(e) {
                return {
                    withCredentials: !0,
                    url: gn + "/v1/users/" + e + "/challenges/recovery-codes/verify",
                    timeout: kn
                }
            }(e), t), wn)
        },
        fr = function(e) {
            return B(g.httpService.get(function(e) {
                return {
                    withCredentials: !0,
                    url: gn + "/v1/users/" + e + "/recovery-codes",
                    timeout: kn
                }
            }(e)), wn)
        },
        Er = function(e) {
            return B(g.httpService.post(function(e) {
                return {
                    withCredentials: !0,
                    url: gn + "/v1/users/" + e + "/recovery-codes/regenerate",
                    timeout: kn
                }
            }(e), {
                password: "password"
            }), wn)
        },
        mr = function(e) {
            return $n(void 0, void 0, Promise, (function() {
                var t;
                return er(this, (function(n) {
                    switch (n.label) {
                        case 0:
                            return [4, tr()];
                        case 1:
                            return t = n.sent(), [2, B(g.httpService.post(Bn(e), {
                                secureAuthenticationIntent: t
                            }), wn)]
                    }
                }))
            }))
        },
        hr = function(e, t) {
            return B(g.httpService.post(function(e) {
                return {
                    withCredentials: !0,
                    url: gn + "/v1/users/" + e + "/challenges/sms/send-code",
                    timeout: kn
                }
            }(e), t), wn)
        },
        Sr = function(e, t) {
            return B(g.httpService.post(function(e) {
                return {
                    withCredentials: !0,
                    url: gn + "/v1/users/" + e + "/challenges/sms/verify",
                    timeout: kn
                }
            }(e), t), wn)
        },
        vr = function(e) {
            return B(g.httpService.post(function(e) {
                return {
                    withCredentials: !0,
                    url: gn + "/v1/users/" + e + "/configuration/sms/disable",
                    timeout: kn
                }
            }(e), {}), wn)
        },
        Ar = function(e) {
            return B(g.httpService.post(function(e) {
                return {
                    withCredentials: !0,
                    url: gn + "/v1/users/" + e + "/configuration/security-key/enable",
                    timeout: kn
                }
            }(e), {}), wn, (function(e) {
                return {
                    creationOptions: JSON.parse(e.creationOptions),
                    sessionId: e.sessionId
                }
            }))
        },
        _r = function(e, t, n, r) {
            return $n(void 0, void 0, Promise, (function() {
                var o;
                return er(this, (function(i) {
                    switch (i.label) {
                        case 0:
                            return [4, tr()];
                        case 1:
                            return o = i.sent(), [2, B(g.httpService.post(Yn(e), {
                                sessionId: t,
                                credentialNickname: n,
                                attestationResponse: r,
                                secureAuthenticationIntent: o
                            }), wn)]
                    }
                }))
            }))
        },
        Nr = function(e, t) {
            return B(g.httpService.post(function(e) {
                return {
                    withCredentials: !0,
                    url: gn + "/v1/users/" + e + "/challenges/security-key/verify-start",
                    timeout: kn
                }
            }(e), t), wn)
        },
        Tr = function(e, t) {
            return B(g.httpService.post(function(e) {
                return {
                    withCredentials: !0,
                    url: gn + "/v1/users/" + e + "/challenges/security-key/verify-finish",
                    timeout: kn
                }
            }(e), t), wn)
        },
        Or = function(e, t) {
            return B(g.httpService.post(function(e) {
                return {
                    withCredentials: !0,
                    url: gn + "/v1/users/" + e + "/configuration/security-key/disable",
                    timeout: kn
                }
            }(e), {
                credentialNicknames: t
            }), wn)
        },
        br = function(e) {
            return B(g.httpService.post(function(e) {
                return {
                    withCredentials: !0,
                    url: gn + "/v1/users/" + e + "/configuration/security-key/list",
                    timeout: kn
                }
            }(e), {}), wn)
        },
        yr = function() {
            return B(g.httpService.get(Gn, {}), wn)
        },
        Cr = function() {
            return B(g.httpService.get(Kn, {}), wn)
        },
        Pr = function() {
            return B(g.httpService.get(Qn, {}), wn)
        },
        wr = function() {
            return B(g.httpService.post(Xn, {}), wn)
        },
        Rr = function() {
            return B(g.httpService.post(qn, {}), wn)
        },
        Ir = function() {
            return B(g.httpService.post(zn, {}), wn)
        },
        Ur = function(e, t) {
            return B(g.httpService.post(jn, {
                challengeToken: e,
                verificationToken: t
            }), wn)
        },
        Dr = function(e, t) {
            return B(g.httpService.post(Jn, {
                challengeToken: e,
                verificationToken: t
            }), wn)
        },
        gr = function(e, t) {
            return B(g.httpService.post(Zn, {
                challengeToken: e,
                verificationToken: t
            }), wn)
        },
        Lr = function(e, t) {
            return B(g.httpService.post(function(e) {
                return {
                    withCredentials: !0,
                    url: gn + "/v1/users/" + e + "/challenges/cross-device/retry",
                    timeout: kn
                }
            }(e), t), wn)
        },
        Mr = function(e, t) {
            return B(g.httpService.post(function(e) {
                return {
                    withCredentials: !0,
                    url: gn + "/v1/users/" + e + "/challenges/cross-device/verify",
                    timeout: kn
                }
            }(e), t), wn)
        },
        kr = function(e, t) {
            return B(g.httpService.post(function(e) {
                return {
                    withCredentials: !0,
                    url: gn + "/v1/users/" + e + "/challenges/cross-device/retract",
                    timeout: kn
                }
            }(e), t), wn)
        },
        xr = null !== (xn = w.EnvironmentUrls.universalAppConfigurationApi) && void 0 !== xn ? xn : "URL_NOT_FOUND";
    ! function(e) {
        e[e.INTERNAL_ERROR = 9] = "INTERNAL_ERROR"
    }(Fn || (Fn = {}));
    var Fr, Vr, Hr = {
            withCredentials: !0,
            url: xr + "/v1/behaviors/account-settings-ui/content",
            timeout: 1e4
        },
        Wr = function(e, t, n, r) {
            return new(n || (n = Promise))((function(o, i) {
                function a(e) {
                    try {
                        c(r.next(e))
                    } catch (e) {
                        i(e)
                    }
                }

                function u(e) {
                    try {
                        c(r.throw(e))
                    } catch (e) {
                        i(e)
                    }
                }

                function c(e) {
                    var t;
                    e.done ? o(e.value) : (t = e.value, t instanceof n ? t : new n((function(e) {
                        e(t)
                    }))).then(a, u)
                }
                c((r = r.apply(e, t || [])).next())
            }))
        },
        Br = function(e, t) {
            var n, r, o, i, a = {
                label: 0,
                sent: function() {
                    if (1 & o[0]) throw o[1];
                    return o[1]
                },
                trys: [],
                ops: []
            };
            return i = {
                next: u(0),
                throw: u(1),
                return: u(2)
            }, "function" == typeof Symbol && (i[Symbol.iterator] = function() {
                return this
            }), i;

            function u(i) {
                return function(u) {
                    return function(i) {
                        if (n) throw new TypeError("Generator is already executing.");
                        for (; a;) try {
                            if (n = 1, r && (o = 2 & i[0] ? r.return : i[0] ? r.throw || ((o = r.return) && o.call(r), 0) : r.next) && !(o = o.call(r, i[1])).done) return o;
                            switch (r = 0, o && (i = [2 & i[0], o.value]), i[0]) {
                                case 0:
                                case 1:
                                    o = i;
                                    break;
                                case 4:
                                    return a.label++, {
                                        value: i[1],
                                        done: !1
                                    };
                                case 5:
                                    a.label++, r = i[1], i = [0];
                                    continue;
                                case 7:
                                    i = a.ops.pop(), a.trys.pop();
                                    continue;
                                default:
                                    if (!(o = a.trys, (o = o.length > 0 && o[o.length - 1]) || 6 !== i[0] && 2 !== i[0])) {
                                        a = 0;
                                        continue
                                    }
                                    if (3 === i[0] && (!o || i[1] > o[0] && i[1] < o[3])) {
                                        a.label = i[1];
                                        break
                                    }
                                    if (6 === i[0] && a.label < o[1]) {
                                        a.label = o[1], o = i;
                                        break
                                    }
                                    if (o && a.label < o[2]) {
                                        a.label = o[2], a.ops.push(i);
                                        break
                                    }
                                    o[2] && a.ops.pop(), a.trys.pop();
                                    continue
                            }
                            i = t.call(e, a)
                        } catch (e) {
                            i = [6, e], r = 0
                        } finally {
                            n = o = 0
                        }
                        if (5 & i[0]) throw i[1];
                        return {
                            value: i[0] ? i[1] : void 0,
                            done: !0
                        }
                    }([i, u])
                }
            }
        },
        Yr = function() {
            return Wr(void 0, void 0, Promise, (function() {
                return Br(this, (function(e) {
                    return [2, B(g.httpService.get(Hr, {}), Fn)]
                }))
            }))
        },
        Gr = null !== (Fr = w.EnvironmentUrls.authApi) && void 0 !== Fr ? Fr : "URL_NOT_FOUND";
    ! function(e) {
        e[e.UNKNOWN = 0] = "UNKNOWN"
    }(Vr || (Vr = {}));
    var Kr, Qr, Xr, qr = {
            withCredentials: !0,
            url: Gr + "/v1/xbox/connection",
            timeout: 1e4
        },
        zr = {
            withCredentials: !0,
            url: Gr + "/v1/xbox/disconnect",
            timeout: 1e4
        },
        jr = function() {
            return B(g.httpService.get(qr, {}), Vr)
        },
        Jr = function() {
            return B(g.httpService.post(zr, {}), Vr)
        },
        Zr = (null !== (Kr = w.EnvironmentUrls.apiGatewayUrl) && void 0 !== Kr ? Kr : "URL_NOT_FOUND") + "/account-security-service";
    ! function(e) {
        e[e.UNKNOWN = 1] = "UNKNOWN", e[e.REQUEST_TYPE_WAS_INVALID = 2] = "REQUEST_TYPE_WAS_INVALID", e[e.INVAID_METRIC_NAME = 3] = "INVAID_METRIC_NAME", e[e.INVALID_METRIC_LABELS = 4] = "INVALID_METRIC_LABELS"
    }(Qr || (Qr = {})),
    function(e) {
        e.Event2sv = "event_2sv", e.SolveTime2sv = "solve_time_2sv", e.EventCaptcha = "event_captcha", e.SolveTimeCaptcha = "solve_time_captcha", e.EventPat = "event_pat", e.SolveTimePat = "solve_time_pat", e.EventPos = "event_pos", e.PuzzleComputeTimePos = "puzzle_compute_time_pos", e.SolveTimePos = "solve_time_pos", e.EventPow = "event_pow", e.PuzzleComputeTimePow = "puzzle_compute_time_pow", e.SolveTimePow = "solve_time_pow", e.EventRostile = "event_rostile", e.SolveTimeRostile = "solve_time_rostile", e.EventSecurityQuestion = "event_security_question", e.EventGeneric = "event_generic", e.EventReauthentication = "event_reauthentication", e.SolveTimeReauthentication = "solve_time_reauthentication", e.EventDeviceIntegrity = "event_device_integrity", e.SolveTimeDeviceIntegrity = "solve_time_device_integrity", e.EventPhoneVerification = "event_phone_verification", e.SolveTimePhoneVerification = "solve_time_phone_verification", e.EventEmailVerification = "event_email_verification", e.SolveTimeEmailVerification = "solve_time_email_verification"
    }(Xr || (Xr = {}));
    var $r, eo, to = {
            withCredentials: !0,
            url: Zr + "/v1/metrics/record",
            timeout: 1e4
        },
        no = function(e) {
            return B(g.httpService.post(to, e), Qr)
        },
        ro = (null !== ($r = w.EnvironmentUrls.apiGatewayUrl) && void 0 !== $r ? $r : "URL_NOT_FOUND") + "/private-access-token";
    ! function(e) {
        e[e.UNKNOWN = 0] = "UNKNOWN"
    }(eo || (eo = {}));
    var oo, io, ao = {
            withCredentials: !0,
            url: ro + "/v1/getPATToken",
            timeout: 1e4
        },
        uo = function(e, t, n, r) {
            return new(n || (n = Promise))((function(o, i) {
                function a(e) {
                    try {
                        c(r.next(e))
                    } catch (e) {
                        i(e)
                    }
                }

                function u(e) {
                    try {
                        c(r.throw(e))
                    } catch (e) {
                        i(e)
                    }
                }

                function c(e) {
                    var t;
                    e.done ? o(e.value) : (t = e.value, t instanceof n ? t : new n((function(e) {
                        e(t)
                    }))).then(a, u)
                }
                c((r = r.apply(e, t || [])).next())
            }))
        },
        co = function(e, t) {
            var n, r, o, i, a = {
                label: 0,
                sent: function() {
                    if (1 & o[0]) throw o[1];
                    return o[1]
                },
                trys: [],
                ops: []
            };
            return i = {
                next: u(0),
                throw: u(1),
                return: u(2)
            }, "function" == typeof Symbol && (i[Symbol.iterator] = function() {
                return this
            }), i;

            function u(i) {
                return function(u) {
                    return function(i) {
                        if (n) throw new TypeError("Generator is already executing.");
                        for (; a;) try {
                            if (n = 1, r && (o = 2 & i[0] ? r.return : i[0] ? r.throw || ((o = r.return) && o.call(r), 0) : r.next) && !(o = o.call(r, i[1])).done) return o;
                            switch (r = 0, o && (i = [2 & i[0], o.value]), i[0]) {
                                case 0:
                                case 1:
                                    o = i;
                                    break;
                                case 4:
                                    return a.label++, {
                                        value: i[1],
                                        done: !1
                                    };
                                case 5:
                                    a.label++, r = i[1], i = [0];
                                    continue;
                                case 7:
                                    i = a.ops.pop(), a.trys.pop();
                                    continue;
                                default:
                                    if (!(o = a.trys, (o = o.length > 0 && o[o.length - 1]) || 6 !== i[0] && 2 !== i[0])) {
                                        a = 0;
                                        continue
                                    }
                                    if (3 === i[0] && (!o || i[1] > o[0] && i[1] < o[3])) {
                                        a.label = i[1];
                                        break
                                    }
                                    if (6 === i[0] && a.label < o[1]) {
                                        a.label = o[1], o = i;
                                        break
                                    }
                                    if (o && a.label < o[2]) {
                                        a.label = o[2], a.ops.push(i);
                                        break
                                    }
                                    o[2] && a.ops.pop(), a.trys.pop();
                                    continue
                            }
                            i = t.call(e, a)
                        } catch (e) {
                            i = [6, e], r = 0
                        } finally {
                            n = o = 0
                        }
                        if (5 & i[0]) throw i[1];
                        return {
                            value: i[0] ? i[1] : void 0,
                            done: !0
                        }
                    }([i, u])
                }
            }
        },
        so = function(e) {
            return uo(void 0, void 0, Promise, (function() {
                return co(this, (function(t) {
                    return [2, B(g.httpService.post(ao, {
                        challengeId: e
                    }), eo)]
                }))
            }))
        },
        lo = (null !== (oo = w.EnvironmentUrls.apiGatewayUrl) && void 0 !== oo ? oo : "URL_NOT_FOUND") + "/challenge";
    ! function(e) {
        e[e.UNKNOWN = 1] = "UNKNOWN"
    }(io || (io = {}));
    var po, fo, Eo = {
            withCredentials: !0,
            url: lo + "/v1/continue",
            timeout: 1e4
        },
        mo = function(e, t, n, r) {
            return new(n || (n = Promise))((function(o, i) {
                function a(e) {
                    try {
                        c(r.next(e))
                    } catch (e) {
                        i(e)
                    }
                }

                function u(e) {
                    try {
                        c(r.throw(e))
                    } catch (e) {
                        i(e)
                    }
                }

                function c(e) {
                    var t;
                    e.done ? o(e.value) : (t = e.value, t instanceof n ? t : new n((function(e) {
                        e(t)
                    }))).then(a, u)
                }
                c((r = r.apply(e, t || [])).next())
            }))
        },
        ho = function(e, t) {
            var n, r, o, i, a = {
                label: 0,
                sent: function() {
                    if (1 & o[0]) throw o[1];
                    return o[1]
                },
                trys: [],
                ops: []
            };
            return i = {
                next: u(0),
                throw: u(1),
                return: u(2)
            }, "function" == typeof Symbol && (i[Symbol.iterator] = function() {
                return this
            }), i;

            function u(i) {
                return function(u) {
                    return function(i) {
                        if (n) throw new TypeError("Generator is already executing.");
                        for (; a;) try {
                            if (n = 1, r && (o = 2 & i[0] ? r.return : i[0] ? r.throw || ((o = r.return) && o.call(r), 0) : r.next) && !(o = o.call(r, i[1])).done) return o;
                            switch (r = 0, o && (i = [2 & i[0], o.value]), i[0]) {
                                case 0:
                                case 1:
                                    o = i;
                                    break;
                                case 4:
                                    return a.label++, {
                                        value: i[1],
                                        done: !1
                                    };
                                case 5:
                                    a.label++, r = i[1], i = [0];
                                    continue;
                                case 7:
                                    i = a.ops.pop(), a.trys.pop();
                                    continue;
                                default:
                                    if (!(o = a.trys, (o = o.length > 0 && o[o.length - 1]) || 6 !== i[0] && 2 !== i[0])) {
                                        a = 0;
                                        continue
                                    }
                                    if (3 === i[0] && (!o || i[1] > o[0] && i[1] < o[3])) {
                                        a.label = i[1];
                                        break
                                    }
                                    if (6 === i[0] && a.label < o[1]) {
                                        a.label = o[1], o = i;
                                        break
                                    }
                                    if (o && a.label < o[2]) {
                                        a.label = o[2], a.ops.push(i);
                                        break
                                    }
                                    o[2] && a.ops.pop(), a.trys.pop();
                                    continue
                            }
                            i = t.call(e, a)
                        } catch (e) {
                            i = [6, e], r = 0
                        } finally {
                            n = o = 0
                        }
                        if (5 & i[0]) throw i[1];
                        return {
                            value: i[0] ? i[1] : void 0,
                            done: !0
                        }
                    }([i, u])
                }
            }
        },
        So = function(e, t, n) {
            return mo(void 0, void 0, Promise, (function() {
                return ho(this, (function(r) {
                    return [2, B(g.httpService.post(Eo, {
                        challengeId: e,
                        challengeType: t,
                        challengeMetadata: n
                    }), io)]
                }))
            }))
        },
        vo = null !== (po = w.EnvironmentUrls.authApi) && void 0 !== po ? po : "URL_NOT_FOUND",
        Ao = 1e4;
    ! function(e) {
        e[e.UNKNOWN = 0] = "UNKNOWN", e[e.EXCEEDED_REGISTERED_KEYS_LIMIT = 1] = "EXCEEDED_REGISTERED_KEYS_LIMIT", e[e.FEATURE_DISABLED = 2] = "FEATURE_DISABLED", e[e.INVALID_CREDENTIAL_NICKNAME = 3] = "INVALID_CREDENTIAL_NICKNAME"
    }(fo || (fo = {}));
    var _o, No = {
            withCredentials: !0,
            url: vo + "/v1/passkey/StartRegistration",
            timeout: Ao
        },
        To = {
            withCredentials: !0,
            url: vo + "/v1/passkey/FinishRegistration",
            timeout: Ao
        },
        Oo = {
            withCredentials: !0,
            url: vo + "/v1/passkey/DeleteCredentialBatch",
            timeout: Ao
        },
        bo = {
            withCredentials: !0,
            url: vo + "/v1/passkey/ListCredentials",
            timeout: Ao
        },
        yo = function() {
            return B(g.httpService.post(No, {}), fo, (function(e) {
                return {
                    creationOptions: JSON.parse(e.creationOptions),
                    sessionId: e.sessionId
                }
            }))
        },
        Co = function(e, t, n) {
            return B(g.httpService.post(To, {
                sessionId: e,
                credentialNickname: t,
                attestationResponse: n
            }), fo)
        },
        Po = function(e) {
            return B(g.httpService.post(Oo, {
                credentialNicknames: e
            }), fo)
        },
        wo = function() {
            return B(g.httpService.post(bo, {
                all: !0
            }), fo)
        };
    ! function(e) {
        e[e.UNKNOWN = 0] = "UNKNOWN", e[e.CANCELLATION_ERROR = 1] = "CANCELLATION_ERROR", e[e.INTERRUPTED_ERROR = 2] = "INTERRUPTED_ERROR", e[e.INVALID_REQUEST = 3] = "INVALID_REQUEST", e[e.JSON_EXCEPTION = 4] = "JSON_EXCEPTION", e[e.CREDENTIALS_PROTOCOL_NOT_SUPPORTED = 5] = "CREDENTIALS_PROTOCOL_NOT_SUPPORTED", e[e.NO_CREDENTIALS_FOUND = 6] = "NO_CREDENTIALS_FOUND", e[e.INVALID_STATE_ERROR = 11] = "INVALID_STATE_ERROR"
    }(_o || (_o = {}));
    var Ro, Io = function(e) {
            return e.code
        },
        Uo = function(e, t, n) {
            return Y(Un.hybridResponseService.getNativeResponse(e, t, n), _o, Io, (function(e) {
                if (null === e) return null;
                var t = JSON.parse(e);
                if (void 0 !== t.errorCode) throw {
                    name: "getNativeResponse Error",
                    message: t.errorMsg,
                    code: t.errorCode
                };
                return !(w.DeviceMeta && (0, w.DeviceMeta)().isInApp && (0, w.DeviceMeta)().isAndroidApp) ? Un.fido2Util.formatCredentialAuthenticationResponseApp(e) : e
            }))
        },
        Do = function(e) {
            return Y(navigator.credentials.get(e), _o).then((function(e) {
                return x(e, (function(e) {
                    return null === e ? null : Un.fido2Util.formatCredentialAuthenticationResponseWeb(e)
                }))
            }))
        },
        go = function() {
            this.accountPin = t, this.captcha = n, this.email = r, this.fido2 = y, this.games = o, this.metrics = N, this.myAccount = i, this.otp = a, this.password = u, this.phone = c, this.playstation = s, this.promptAssignments = l, this.securityQuestions = m, this.sessionManagement = h, this.reauthentication = f, this.rostile = E, this.thumbnails = S, this.twoStepVerification = v, this.universalAppConfiguration = A, this.proofOfSpace = d, this.proofOfWork = p, this.xbox = _, this.privateAccessToken = T, this.genericChallenge = O, this.authApi = b
        },
        Lo = ReactUtilities,
        Mo = "Account Security Prompt:",
        ko = "authpopup",
        xo = "/my/account#!/security?src=",
        Fo = "https://en.help.roblox.com/hc/articles/212459863-Add-2-Step-Verification-to-Your-Account",
        Vo = "accountSecurityPromptEvent",
        Ho = {
            modalStateViewed: "modalStateViewed"
        },
        Wo = ReactStyleGuide,
        Bo = function(e, t) {
            switch (t) {
                case ke.VALID_PASSWORD:
                    return null;
                case ke.WEAK_PASSWORD:
                    return e.Message.Error.PasswordValidation.WeakPassword;
                case ke.SHORT_PASSWORD:
                    return e.Message.Error.PasswordValidation.ShortPassword;
                case ke.PASSWORD_SAME_AS_USERNAME:
                    return e.Message.Error.PasswordValidation.PasswordSameAsUsername;
                case ke.FORBIDDEN_PASSWORD:
                    return e.Message.Error.PasswordValidation.ForbiddenPassword;
                case ke.DUMB_STRINGS:
                    return e.Message.Error.PasswordValidation.DumbStrings;
                default:
                    return e.Message.Error.PasswordValidation.Default
            }
        },
        Yo = function(e, t) {
            switch (t) {
                case P.NO_ACCOUNT_PIN:
                    return e.Message.Error.Pin.NoAccountPin;
                case P.ACCOUNT_LOCKED:
                    return e.Message.Error.Pin.AccountLocked;
                case P.FLOODED:
                    return e.Message.Error.Pin.Flooded;
                case P.INCORRECT_PIN:
                    return e.Message.Error.Pin.IncorrectPin;
                default:
                    return e.Message.Error.Pin.Default
            }
        };
    ! function(e) {
        e.NONE = "NONE", e.CHANGE_PASSWORD_INTRO = "CHANGE_PASSWORD_INTRO", e.CHANGE_PASSWORD_FORM = "CHANGE_PASSWORD_FORM", e.CHANGE_PASSWORD_CONFIRMATION = "CHANGE_PASSWORD_CONFIRMATION", e.CHANGE_PASSWORD_DISMISS_CONFIRMATION = "CHANGE_PASSWORD_DISMISS_CONFIRMATION", e.ACCOUNT_PIN_FORM = "ACCOUNT_PIN_FORM", e.ACCOUNT_PIN_FORM_EXPIRED = "ACCOUNT_PIN_FORM_EXPIRED", e.AUTHENTICATOR_UPSELL_OPENING = "AUTHENTICATOR_UPSELL_OPENING", e.AUTHENTICATOR_UPSELL_DOWNLOAD_APPS = "AUTHENTICATOR_UPSELL_DOWNLOAD_APPS", e.ACCOUNT_RESTORE_POLICY_UPSELL = "ACCOUNT_RESTORE_POLICY_UPSELL", e.EMAIL_2SV_UPSELL = "EMAIL_2SV_UPSELL"
    }(Ro || (Ro = {}));
    var Go, Ko = Ro;
    ! function(e) {
        e[e.DISMISS_TEMPORARY = 0] = "DISMISS_TEMPORARY", e[e.DISMISS_FOREVER = 1] = "DISMISS_FOREVER", e[e.SET_FLOW_COMPLETE = 2] = "SET_FLOW_COMPLETE", e[e.SET_MODAL_STATE = 3] = "SET_MODAL_STATE", e[e.SET_EMAIL_ADDRESS = 4] = "SET_EMAIL_ADDRESS", e[e.SET_ACCOUNT_PIN_UNLOCKED_UNTIL = 5] = "SET_ACCOUNT_PIN_UNLOCKED_UNTIL"
    }(Go || (Go = {}));
    var Qo, Xo = function() {
            return (Xo = Object.assign || function(e) {
                for (var t, n = 1, r = arguments.length; n < r; n++)
                    for (var o in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                return e
            }).apply(this, arguments)
        },
        qo = function(e, t) {
            var n = Xo({}, e);
            switch (t.type) {
                case Go.DISMISS_TEMPORARY:
                case Go.DISMISS_FOREVER:
                    return n.isFlowComplete = !0, n;
                case Go.SET_MODAL_STATE:
                    return n.lastModalState = e.modalState, n.modalState = t.modalState, n.modalState === Ko.ACCOUNT_PIN_FORM_EXPIRED ? n.accountPinUnlockedUntil = null : n.modalState === Ko.CHANGE_PASSWORD_CONFIRMATION && (n.isFlowComplete = !0), n;
                case Go.SET_EMAIL_ADDRESS:
                    return n.emailAddress = t.emailAddress, n;
                case Go.SET_ACCOUNT_PIN_UNLOCKED_UNTIL:
                    return n.accountPinUnlockedUntil = t.accountPinUnlockedUntil, n;
                default:
                    return e
            }
        },
        zo = (0, I.createContext)(null),
        jo = function(e) {
            var t = e.promptAssignment,
                n = e.username,
                r = e.isUserUnder13,
                o = e.eventService,
                i = e.requestService,
                a = e.translate,
                u = e.children,
                c = Ko.NONE,
                s = t.promptType === ot.BROADER_AUTHENTICATOR_UPSELL && !0 !== t.isGeneric && !t.metadata.showBanner,
                l = t.promptType === ot.EMAIL_2SV_UPSELL && !0 !== t.isGeneric && !t.metadata.showBanner;
            t.promptType === ot.AUTHENTICATOR_UPSELL || s ? c = Ko.AUTHENTICATOR_UPSELL_OPENING : t.promptType === ot.ACCOUNT_RESTORES_POLICY_UPSELL ? c = Ko.ACCOUNT_RESTORE_POLICY_UPSELL : t.promptType === ot.EMAIL_2SV_UPSELL && l && (c = Ko.EMAIL_2SV_UPSELL);
            var d = (0, I.useState)((function() {
                    return function(e, t) {
                        return {
                            Action: {
                                AbortDismissForeverAddEmail: e("Action.AbortDismissForeverAddEmail"),
                                AbortDismissForeverChangePassword: e("Action.AbortDismissForeverChangePassword"),
                                AccountRestoreOpenSettings: e("Action.OpenSettings"),
                                AuthenticatorUpsellSetupAuthenticatorButtonMessage: e("Label.AuthenticatorUpsellSetupAuthenticatorButtonMessage"),
                                AuthenticatorUpsellNextButtonMessage: e("Action.AuthenticatorUpsellNextButtonMessage"),
                                ChangeEmail: e("Action.ChangeEmail"),
                                ConfirmDismissForeverAddEmail: e("Action.ConfirmDismissForeverAddEmail"),
                                ConfirmDismissForeverChangePassword: e("Action.ConfirmDismissForeverChangePassword"),
                                ContinueAddEmail: e("Action.ContinueAddEmail"),
                                ContinueChangePassword: e("Action.ContinueChangePassword"),
                                DismissForever: e("Action.DismissForever"),
                                RemindMeLater: e("Action.RemindMeLater"),
                                ResendPasswordResetEmail: e("Action.ResendPasswordResetEmail"),
                                SecureAccount: e("Action.SecureAccount"),
                                SetUpAuthenticatorInBanner: e("Action.SetUpAuthenticatorInBanner"),
                                SetUpAuthenticatorAccountRestoresPolicyUpsell: e("Action.SetUpAuthenticatorAccountRestoresPolicyUpsell"),
                                SetUpEmail2SV: e("Action.SetUpEmail2SV"),
                                SubmitChangePassword: e("Action.SubmitChangePassword"),
                                UnlockAccountPin: e("Action.UnlockAccountPin")
                            },
                            Message: {
                                Error: {
                                    Email: {
                                        FeatureDisabled: e("Message.Error.Email.FeatureDisabled"),
                                        TooManyAccountsOnEmail: e("Message.Error.Email.TooManyAccountsOnEmail"),
                                        TooManyAttemptsToUpdateEmail: e("Message.Error.Email.TooManyAttemptsToUpdateEmail"),
                                        InvalidEmailAddress: e("Message.Error.Email.InvalidEmailAddress"),
                                        Default: e("Message.Error.Email.Default")
                                    },
                                    Input: {
                                        InvalidEmail: e("Message.Error.Input.InvalidEmail"),
                                        PasswordsDoNotMatch: e("Message.Error.Input.PasswordsDoNotMatch")
                                    },
                                    Passwords: {
                                        Flooded: e("Message.Error.Password.Flooded"),
                                        InvalidPassword: e("Message.Error.Password.InvalidPassword"),
                                        InvalidCurrentPassword: e("Message.Error.Password.InvalidCurrentPassword"),
                                        PinLocked: e("Message.Error.Password.PinLocked"),
                                        Default: e("Message.Error.Password.Default")
                                    },
                                    PasswordReset: {
                                        UserDoesNotHaveEmail: e("Message.Error.PasswordReset.UserDoesNotHaveEmail"),
                                        Default: e("Message.Error.PasswordReset.Default")
                                    },
                                    PasswordValidation: {
                                        WeakPassword: e("Message.Error.PasswordValidation.WeakPassword"),
                                        ShortPassword: e("Message.Error.PasswordValidation.ShortPassword"),
                                        PasswordSameAsUsername: e("Message.Error.PasswordValidation.PasswordSameAsUsername"),
                                        ForbiddenPassword: e("Message.Error.PasswordValidation.ForbiddenPassword"),
                                        DumbStrings: e("Message.Error.PasswordValidation.DumbStrings"),
                                        Default: e("Message.Error.PasswordValidation.Default")
                                    },
                                    Pin: {
                                        NoAccountPin: e("Message.Error.Pin.NoAccountPin"),
                                        AccountLocked: e("Message.Error.Pin.AccountLocked"),
                                        Flooded: e("Message.Error.Pin.Flooded"),
                                        IncorrectPin: e("Message.Error.Pin.IncorrectPin"),
                                        Default: e("Message.Error.Pin.Default")
                                    },
                                    PromptAssignments: {
                                        Default: e("Message.Error.PromptAssignments.Default")
                                    }
                                }
                            },
                            Description: {
                                AccountRestoresPolicyUpdateV3: function(t) {
                                    return e("Description.AccountRestoresPolicyUpdateV3", {
                                        linkStart: '<a href="' + t + '" class="text-link" target="_blank">',
                                        linkEnd: "</a>"
                                    })
                                },
                                AccountRestoresPolicyUpsellMessageBody: function(t) {
                                    return e("Description.AccountRestoresPolicyUpsellMessageBody", {
                                        linkStartSettings: '<a href="' + t + '" class="text-link" target="_blank">',
                                        linkEndSettings: "</a>"
                                    })
                                },
                                AccountRestoresPolicyWithDate: function(t) {
                                    return e("Description.AccountRestoresPolicyWithDate", {
                                        date: t
                                    })
                                },
                                AddYourEmail: e(t ? "Description.AddYourEmailUnder13" : "Description.AddYourEmail"),
                                AreYouSureDismissForeverAddEmail: e(t ? "Description.AreYouSureDismissForeverAddEmailUnder13" : "Description.AreYouSureDismissForeverAddEmail"),
                                AreYouSureDismissForeverChangePassword: e("Description.AreYouSureDismissForeverChangePassword"),
                                AuthenticatorSetupPrompt: function(t) {
                                    return e("Description.AuthenticatorSetupPrompt", {
                                        linkStart: '<a href="' + t + '" class="text-link" target="_blank">',
                                        linkEnd: "</a>"
                                    })
                                },
                                AuthenticatorSetupPromptNew: function(t) {
                                    return e("Description.AuthenticatorSetupPromptNew", {
                                        linkStart: '<a href="' + t + '" class="text-link" target="_blank">',
                                        linkEnd: "</a>"
                                    })
                                },
                                ChangeYourPassword: e("Description.ChangeYourPassword"),
                                ChangeYourPasswordImmediately: e("Description.ChangeYourPasswordImmediately"),
                                ChangeYourPasswordSuccess: e("Description.ChangeYourPasswordSuccess"),
                                CheckYourEmail: function(n) {
                                    return e(t ? "Description.CheckYourEmailUnder13" : "Description.CheckYourEmail", {
                                        emailAddress: "<b>" + n + "</b>"
                                    })
                                },
                                Email2SVUpsellMessageBody: function(t) {
                                    return e("Description.Email2SVUpsellMessageBody", {
                                        linkStart: '<a href="' + t + '" class="text-link" target="_blank">',
                                        linkEnd: "</a>"
                                    })
                                },
                                EnterYourAccountPin: e("Description.EnterYourAccountPin"),
                                GenericTextOnlyBanner: function(t) {
                                    return e(t)
                                },
                                LearnMoreHere: function(t) {
                                    return e("Description.LearnMoreHere", {
                                        linkStart: '<a href="' + t + '" class="text-link" target="_blank">',
                                        linkEnd: "</a>"
                                    })
                                },
                                NoChangeForceReset: function(t) {
                                    return e(t <= 1 ? "Description.NoChangeForceResetSingular" : "Description.NoChangeForceReset", {
                                        days: t,
                                        boldStart: "<b>",
                                        boldEnd: "</b>"
                                    }).replace("1", t < 1 ? "< 1" : "1")
                                },
                                ReceiveSecurityCodesMessage: e("Description.ReceiveSecurityCodesMessage"),
                                UnusualActivity: e("Description.UnusualActivity")
                            },
                            Header: {
                                AccountPinExpired: e("Header.AccountPinExpired"),
                                AccountPinRequired: e("Header.AccountPinRequired"),
                                AccountRestoresPolicyUpdate: e("Header.AccountRestoresPolicyUpdate"),
                                AccountRestoresPolicyUpdateV3: e("Header.AccountRestoresPolicyUpdateV3"),
                                AccountRestoresPolicyUpsell: e("Header.AccountRestoresPolicyUpsell"),
                                AddYourEmail: e(t ? "Header.AddYourEmailUnder13" : "Header.AddYourEmail"),
                                AreYouSure: e("Header.AreYouSure"),
                                AuthenticatorUpsellDownloadAuthenticator: e("Header.AuthenticatorUpsellDownloadAuthenticator"),
                                AuthenticatorUpsellWelcomeMessage: e("Header.AuthenticatorUpsellWelcomeMessage"),
                                BoostYourAccountSecurity: e("Header.BoostYourAccountSecurity"),
                                ChangeYourPassword: e("Header.ChangeYourPassword"),
                                CheckYourEmail: e(t ? "Header.CheckYourEmailUnder13" : "Header.CheckYourEmail"),
                                CreateAStrongPassword: e("Header.CreateAStrongPassword"),
                                GenericTextOnlyBanner: function(t) {
                                    return e(t)
                                },
                                Email2SVUpsell: e("Header.Email2SVUpsell"),
                                KeepYourAccountSafeLong: e("Header.KeepYourAccountSafeLong"),
                                Success: e("Header.Success"),
                                UnusualActivityDetected: e("Header.UnusualActivityDetected"),
                                YourPasswordMightBeStolen: e("Header.YourPasswordMightBeStolen")
                            },
                            Label: {
                                AccountPin: e("Label.AccountPin"),
                                AtLeastCharacters: function(t) {
                                    return e("Label.AtLeastCharacters", {
                                        count: t
                                    })
                                },
                                AuthenticatorUpsellBadActorHeadline: e("Label.AuthenticatorUpsellBadActorHeadline"),
                                AuthenticatorUpsellBadActorMessage: e("Label.AuthenticatorUpsellBadActorMessage"),
                                AuthenticatorUpsellDownloadInstruction: e("Label.AuthenticatorUpsellDownloadInstruction"),
                                AuthenticatorUpsellGoogleOption: e("Label.AuthenticatorUpsellGoogleOption"),
                                AuthenticatorUpsellMicrosoftOption: e("Label.AuthenticatorUpsellMicrosoftOption"),
                                AuthenticatorUpsellProtectRobuxHeadline: e("Label.AuthenticatorUpsellProtectRobuxHeadline"),
                                AuthenticatorUpsellProtectRobuxMessage: e("Label.AuthenticatorUpsellProtectRobuxMessage"),
                                AuthenticatorUpsellTwilioOption: e("Label.AuthenticatorUpsellTwilioOption"),
                                AuthenticatorUpsellTwoFactorHeadline: e("Label.AuthenticatorUpsellTwoFactorHeadline"),
                                AuthenticatorUpsellTwoFactorMessage: e("Label.AuthenticatorUpsellTwoFactorMessage"),
                                ConfirmNewPassword: e("Label.ConfirmNewPassword"),
                                CurrentPassword: e("Label.CurrentPassword"),
                                IForgotMyPassword: e("Label.IForgotMyPassword"),
                                MinutesSeconds: function(t, n) {
                                    return e("Label.MinutesSeconds", {
                                        minutes: t,
                                        seconds: n
                                    })
                                },
                                NewPassword: e("Label.NewPassword"),
                                TimeRemaining: e("Label.TimeRemaining"),
                                UseAUniquePassword: e("Label.UseAUniquePassword"),
                                YourEmail: e(t ? "Label.YourEmailUnder13" : "Label.YourEmail")
                            }
                        }
                    }(a, r)
                }))[0],
                p = (0, I.useState)((function() {
                    return {
                        promptAssignment: t,
                        username: n,
                        resources: d,
                        requestService: i,
                        isFlowComplete: !1,
                        modalState: c,
                        lastModalState: null,
                        emailAddress: "",
                        accountPinUnlockedUntil: null
                    }
                }))[0],
                f = (0, I.useReducer)(qo, p),
                E = f[0],
                m = f[1];
            return (0, I.useEffect)((function() {
                return function(e, t, n) {
                    t !== n && e.sendModalStateViewedEvent(t)
                }(o, E.modalState, E.lastModalState)
            }), [o, E.modalState, E.lastModalState]), U().createElement(zo.Provider, {
                value: {
                    state: E,
                    dispatch: m
                }
            }, u)
        },
        Jo = function() {
            var e = (0, I.useContext)(zo);
            if (null === e) throw new Error("AccountSecurityPromptContext was not provided in the current scope");
            return e
        },
        Zo = function(e) {
            var t = parseInt(e, 10);
            if (Number.isNaN(t) || !Number.isSafeInteger(t)) return 14;
            var n = Math.max(0, t - Date.now());
            return Math.floor(n / 864e5)
        },
        $o = function(e, t, n, r) {
            return new(n || (n = Promise))((function(o, i) {
                function a(e) {
                    try {
                        c(r.next(e))
                    } catch (e) {
                        i(e)
                    }
                }

                function u(e) {
                    try {
                        c(r.throw(e))
                    } catch (e) {
                        i(e)
                    }
                }

                function c(e) {
                    var t;
                    e.done ? o(e.value) : (t = e.value, t instanceof n ? t : new n((function(e) {
                        e(t)
                    }))).then(a, u)
                }
                c((r = r.apply(e, t || [])).next())
            }))
        },
        ei = function(e, t) {
            var n, r, o, i, a = {
                label: 0,
                sent: function() {
                    if (1 & o[0]) throw o[1];
                    return o[1]
                },
                trys: [],
                ops: []
            };
            return i = {
                next: u(0),
                throw: u(1),
                return: u(2)
            }, "function" == typeof Symbol && (i[Symbol.iterator] = function() {
                return this
            }), i;

            function u(i) {
                return function(u) {
                    return function(i) {
                        if (n) throw new TypeError("Generator is already executing.");
                        for (; a;) try {
                            if (n = 1, r && (o = 2 & i[0] ? r.return : i[0] ? r.throw || ((o = r.return) && o.call(r), 0) : r.next) && !(o = o.call(r, i[1])).done) return o;
                            switch (r = 0, o && (i = [2 & i[0], o.value]), i[0]) {
                                case 0:
                                case 1:
                                    o = i;
                                    break;
                                case 4:
                                    return a.label++, {
                                        value: i[1],
                                        done: !1
                                    };
                                case 5:
                                    a.label++, r = i[1], i = [0];
                                    continue;
                                case 7:
                                    i = a.ops.pop(), a.trys.pop();
                                    continue;
                                default:
                                    if (!(o = a.trys, (o = o.length > 0 && o[o.length - 1]) || 6 !== i[0] && 2 !== i[0])) {
                                        a = 0;
                                        continue
                                    }
                                    if (3 === i[0] && (!o || i[1] > o[0] && i[1] < o[3])) {
                                        a.label = i[1];
                                        break
                                    }
                                    if (6 === i[0] && a.label < o[1]) {
                                        a.label = o[1], o = i;
                                        break
                                    }
                                    if (o && a.label < o[2]) {
                                        a.label = o[2], a.ops.push(i);
                                        break
                                    }
                                    o[2] && a.ops.pop(), a.trys.pop();
                                    continue
                            }
                            i = t.call(e, a)
                        } catch (e) {
                            i = [6, e], r = 0
                        } finally {
                            n = o = 0
                        }
                        if (5 & i[0]) throw i[1];
                        return {
                            value: i[0] ? i[1] : void 0,
                            done: !0
                        }
                    }([i, u])
                }
            }
        },
        ti = function() {
            var e = Jo(),
                t = e.state,
                n = t.promptAssignment,
                r = t.resources,
                o = t.requestService,
                i = e.dispatch,
                a = (0, I.useState)(!1),
                u = a[0],
                c = a[1],
                s = function() {
                    return $o(void 0, void 0, Promise, (function() {
                        var e;
                        return ei(this, (function(t) {
                            switch (t.label) {
                                case 0:
                                    return c(!0), [4, o.promptAssignments.updateForCurrentUser(lt.DISABLE_PROMPT, n.promptType)];
                                case 1:
                                    return (e = t.sent()).isError && (c(!1), console.warn(Mo, "Disabling prompt failed with error", e.error && tt[e.error])), i({
                                        type: Go.DISMISS_FOREVER
                                    }), [2]
                            }
                        }))
                    }))
                },
                l = function() {
                    return $o(void 0, void 0, Promise, (function() {
                        var e;
                        return ei(this, (function(t) {
                            switch (t.label) {
                                case 0:
                                    return c(!0), [4, o.promptAssignments.updateForCurrentUser(lt.DISMISS_PROMPT, n.promptType)];
                                case 1:
                                    return (e = t.sent()).isError && (c(!1), console.warn(Mo, "Dismissing prompt failed with error", e.error && tt[e.error])), i({
                                        type: Go.DISMISS_TEMPORARY
                                    }), [2]
                            }
                        }))
                    }))
                },
                d = [ot.BROADER_AUTHENTICATOR_UPSELL.toString(), ot.ACCOUNT_RESTORES_POLICY_UPDATE_V3.toString(), ot.EMAIL_2SV_UPSELL.toString()].includes(n.promptType.toString()),
                p = !d,
                f = ot.ACCOUNT_RESTORES_POLICY_UPDATE_V3 !== n.promptType,
                E = ot.CHANGE_PASSWORD__SUSPECTED_COMPROMISE === n.promptType,
                m = [ot.CHANGE_PASSWORD__SUSPECTED_COMPROMISE.toString(), ot.ACCOUNT_RESTORES_POLICY_UPDATE.toString(), ot.ACCOUNT_RESTORES_POLICY_UPDATE_V2.toString(), ot.ACCOUNT_RESTORES_POLICY_UPDATE_V3.toString(), ot.BROADER_AUTHENTICATOR_UPSELL.toString(), ot.EMAIL_2SV_UPSELL.toString()].includes(n.promptType.toString());
            n.isGeneric && (p = n.metadata.showAlertIcon, f = !1, E = !1, m = n.metadata.showXButtonForDisable);
            var h, S, v = r.Action.SubmitChangePassword;
            if (n.promptType === ot.ACCOUNT_RESTORES_POLICY_UPDATE || n.promptType === ot.ACCOUNT_RESTORES_POLICY_UPDATE_V2 ? v = r.Action.AccountRestoreOpenSettings : n.promptType === ot.BROADER_AUTHENTICATOR_UPSELL ? v = r.Action.SetUpAuthenticatorInBanner : n.promptType === ot.EMAIL_2SV_UPSELL && (v = r.Action.SetUpEmail2SV), n.isGeneric) switch (n.metadata.displayType) {
                case nt.TEXT_ONLY_BANNER:
                    h = r.Description.GenericTextOnlyBanner(n.metadata.headerResource);
                    break;
                default:
                    h = ""
            } else switch (n.promptType) {
                case ot.CHANGE_PASSWORD__SUSPECTED_COMPROMISE:
                    h = r.Header.UnusualActivityDetected;
                    break;
                case ot.CHANGE_PASSWORD__BREACHED_CREDENTIAL:
                    h = r.Header.YourPasswordMightBeStolen;
                    break;
                case ot.ACCOUNT_RESTORES_POLICY_UPDATE:
                    h = r.Header.AccountRestoresPolicyUpdate;
                    break;
                case ot.ACCOUNT_RESTORES_POLICY_UPDATE_V2:
                    h = r.Header.KeepYourAccountSafeLong;
                    break;
                case ot.ACCOUNT_RESTORES_POLICY_UPDATE_V3:
                    h = r.Header.AccountRestoresPolicyUpdateV3;
                    break;
                case ot.BROADER_AUTHENTICATOR_UPSELL:
                    h = r.Header.BoostYourAccountSecurity;
                    break;
                case ot.EMAIL_2SV_UPSELL:
                    h = r.Header.Email2SVUpsell;
                    break;
                default:
                    h = ""
            }
            if (n.isGeneric) switch (n.metadata.displayType) {
                case nt.TEXT_ONLY_BANNER:
                    S = r.Header.GenericTextOnlyBanner(n.metadata.bodyResource);
                    break;
                default:
                    S = ""
            } else switch (n.promptType) {
                case ot.ACCOUNT_RESTORES_POLICY_UPDATE:
                    var A = new Date(n.metadata.accountRestoresPolicyEffectiveTimestamp).toLocaleDateString(void 0, {
                        year: "numeric",
                        month: "short",
                        day: "numeric"
                    });
                    S = r.Description.AccountRestoresPolicyWithDate(A) + " " + r.Description.AuthenticatorSetupPrompt(Fo);
                    break;
                case ot.ACCOUNT_RESTORES_POLICY_UPDATE_V2:
                    S = r.Description.AuthenticatorSetupPromptNew(Fo);
                    break;
                case ot.ACCOUNT_RESTORES_POLICY_UPDATE_V3:
                    S = r.Description.AccountRestoresPolicyUpdateV3(xo);
                    break;
                case ot.CHANGE_PASSWORD__SUSPECTED_COMPROMISE:
                    S = r.Description.UnusualActivity + " " + r.Description.ChangeYourPassword;
                    break;
                case ot.CHANGE_PASSWORD__BREACHED_CREDENTIAL:
                    S = r.Description.ChangeYourPasswordImmediately + " " + r.Description.NoChangeForceReset(Zo(n.metadata.forceResetTimestamp)) + " " + r.Description.LearnMoreHere("https://en.help.roblox.com/hc/articles/4416940180500-Why-am-I-seeing-a-banner-asking-me-to-change-my-password-");
                    break;
                case ot.BROADER_AUTHENTICATOR_UPSELL:
                    S = r.Description.ReceiveSecurityCodesMessage;
                    break;
                case ot.EMAIL_2SV_UPSELL:
                    S = r.Description.Email2SVUpsellMessageBody(xo);
                    break;
                default:
                    S = ""
            }
            return "" === h || "" === S ? U().createElement(U().Fragment, null) : U().createElement("div", {
                className: "security-banner-wrapper"
            }, U().createElement("div", {
                className: "security-banner"
            }, U().createElement("div", {
                className: "banner-start"
            }, p && U().createElement("div", {
                className: "banner-icon"
            }, U().createElement("div", {
                className: "icon-warning"
            })), d && U().createElement("div", {
                className: "banner-icon-lock"
            }), U().createElement("div", {
                className: "banner-content"
            }, U().createElement("h2", {
                className: "banner-header"
            }, h), U().createElement("div", {
                className: "banner-description",
                dangerouslySetInnerHTML: {
                    __html: S
                }
            })), m && U().createElement("button", {
                type: "button",
                className: "close banner-close",
                "aria-label": r.Action.RemindMeLater,
                onClick: l
            }, U().createElement("span", {
                className: "icon-close"
            }))), U().createElement("div", {
                className: "banner-buttons"
            }, E && U().createElement("span", {
                className: "banner-button"
            }, U().createElement("button", {
                type: "button",
                className: "btn-secondary-md",
                "aria-label": r.Action.DismissForever,
                onClick: function() {
                    i({
                        type: Go.SET_MODAL_STATE,
                        modalState: Ko.CHANGE_PASSWORD_DISMISS_CONFIRMATION
                    })
                },
                disabled: u
            }, r.Action.DismissForever)), f && U().createElement("span", {
                className: "banner-button banner-button-last"
            }, U().createElement("button", {
                type: "button",
                className: "btn-cta-md",
                "aria-label": v,
                onClick: function() {
                    return $o(void 0, void 0, void 0, (function() {
                        return ei(this, (function(e) {
                            switch (e.label) {
                                case 0:
                                    return n.promptType !== ot.ACCOUNT_RESTORES_POLICY_UPDATE && n.promptType !== ot.ACCOUNT_RESTORES_POLICY_UPDATE_V2 ? [3, 2] : [4, s()];
                                case 1:
                                    return e.sent(), window.open("/my/account#!/security?src=authpopup", "_self"), [3, 3];
                                case 2:
                                    n.promptType === ot.BROADER_AUTHENTICATOR_UPSELL ? i({
                                        type: Go.SET_MODAL_STATE,
                                        modalState: Ko.AUTHENTICATOR_UPSELL_OPENING
                                    }) : n.promptType === ot.EMAIL_2SV_UPSELL ? window.open("/my/account#!/security?src=emailhighlight", "_self") : i({
                                        type: Go.SET_MODAL_STATE,
                                        modalState: Ko.CHANGE_PASSWORD_INTRO
                                    }), e.label = 3;
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                },
                disabled: u
            }, v)), m && U().createElement(I.Fragment, null, u ? U().createElement("span", {
                className: "banner-close icon-close spinner-circle"
            }) : U().createElement("button", {
                type: "button",
                className: "close banner-close",
                "aria-label": r.Action.RemindMeLater,
                onClick: function() {
                    return $o(void 0, void 0, Promise, (function() {
                        return ei(this, (function(e) {
                            switch (e.label) {
                                case 0:
                                    return n.promptType === ot.ACCOUNT_RESTORES_POLICY_UPDATE || n.promptType === ot.ACCOUNT_RESTORES_POLICY_UPDATE_V2 || n.promptType === ot.ACCOUNT_RESTORES_POLICY_UPDATE_V3 || n.isGeneric && n.metadata.displayType === nt.TEXT_ONLY_BANNER ? [4, s()] : [3, 2];
                                case 1:
                                    return e.sent(), [3, 4];
                                case 2:
                                    return [4, l()];
                                case 3:
                                    e.sent(), e.label = 4;
                                case 4:
                                    return [2]
                            }
                        }))
                    }))
                }
            }, U().createElement("span", {
                className: "icon-close"
            }))))))
        },
        ni = function(e, t, n, r) {
            return new(n || (n = Promise))((function(o, i) {
                function a(e) {
                    try {
                        c(r.next(e))
                    } catch (e) {
                        i(e)
                    }
                }

                function u(e) {
                    try {
                        c(r.throw(e))
                    } catch (e) {
                        i(e)
                    }
                }

                function c(e) {
                    var t;
                    e.done ? o(e.value) : (t = e.value, t instanceof n ? t : new n((function(e) {
                        e(t)
                    }))).then(a, u)
                }
                c((r = r.apply(e, t || [])).next())
            }))
        },
        ri = function(e, t) {
            var n, r, o, i, a = {
                label: 0,
                sent: function() {
                    if (1 & o[0]) throw o[1];
                    return o[1]
                },
                trys: [],
                ops: []
            };
            return i = {
                next: u(0),
                throw: u(1),
                return: u(2)
            }, "function" == typeof Symbol && (i[Symbol.iterator] = function() {
                return this
            }), i;

            function u(i) {
                return function(u) {
                    return function(i) {
                        if (n) throw new TypeError("Generator is already executing.");
                        for (; a;) try {
                            if (n = 1, r && (o = 2 & i[0] ? r.return : i[0] ? r.throw || ((o = r.return) && o.call(r), 0) : r.next) && !(o = o.call(r, i[1])).done) return o;
                            switch (r = 0, o && (i = [2 & i[0], o.value]), i[0]) {
                                case 0:
                                case 1:
                                    o = i;
                                    break;
                                case 4:
                                    return a.label++, {
                                        value: i[1],
                                        done: !1
                                    };
                                case 5:
                                    a.label++, r = i[1], i = [0];
                                    continue;
                                case 7:
                                    i = a.ops.pop(), a.trys.pop();
                                    continue;
                                default:
                                    if (!(o = a.trys, (o = o.length > 0 && o[o.length - 1]) || 6 !== i[0] && 2 !== i[0])) {
                                        a = 0;
                                        continue
                                    }
                                    if (3 === i[0] && (!o || i[1] > o[0] && i[1] < o[3])) {
                                        a.label = i[1];
                                        break
                                    }
                                    if (6 === i[0] && a.label < o[1]) {
                                        a.label = o[1], o = i;
                                        break
                                    }
                                    if (o && a.label < o[2]) {
                                        a.label = o[2], a.ops.push(i);
                                        break
                                    }
                                    o[2] && a.ops.pop(), a.trys.pop();
                                    continue
                            }
                            i = t.call(e, a)
                        } catch (e) {
                            i = [6, e], r = 0
                        } finally {
                            n = o = 0
                        }
                        if (5 & i[0]) throw i[1];
                        return {
                            value: i[0] ? i[1] : void 0,
                            done: !0
                        }
                    }([i, u])
                }
            }
        },
        oi = function(e, t) {
            return function(n) {
                return ni(void 0, void 0, Promise, (function() {
                    return ri(this, (function(r) {
                        switch (r.label) {
                            case 0:
                                return "Enter" === n.key && t ? (n.preventDefault(), n.stopPropagation(), [4, e()]) : [3, 2];
                            case 1:
                                r.sent(), r.label = 2;
                            case 2:
                                return [2]
                        }
                    }))
                }))
            }
        },
        ii = function() {
            return Promise.resolve(null)
        },
        ai = function(e, t, n, r) {
            return function(o) {
                return ni(void 0, void 0, void 0, (function() {
                    var i;
                    return ri(this, (function(a) {
                        switch (a.label) {
                            case 0:
                                return [4, e.password.validate(n, o)];
                            case 1:
                                return (i = a.sent()).isError ? [2, r] : [2, Bo(t, i.value)]
                        }
                    }))
                }))
            }
        },
        ui = function(e, t) {
            return function(n) {
                return ni(void 0, void 0, void 0, (function() {
                    return ri(this, (function(r) {
                        return n === t ? [2, Promise.resolve(null)] : [2, Promise.resolve(e)]
                    }))
                }))
            }
        },
        ci = function() {
            for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
            return function(t) {
                return ni(void 0, void 0, void 0, (function() {
                    var n, r;
                    return ri(this, (function(o) {
                        switch (o.label) {
                            case 0:
                                n = 0, o.label = 1;
                            case 1:
                                return n < e.length ? [4, e[n](t)] : [3, 4];
                            case 2:
                                if (null !== (r = o.sent())) return [2, r];
                                o.label = 3;
                            case 3:
                                return n += 1, [3, 1];
                            case 4:
                                return [2, null]
                        }
                    }))
                }))
            }
        },
        si = function(e, t, n, r, o, i) {
            return function(a) {
                return ni(void 0, void 0, Promise, (function() {
                    var u, c;
                    return ri(this, (function(s) {
                        switch (s.label) {
                            case 0:
                                return u = a.currentTarget.value, void 0 === t || t.test(u) || (u = e), void 0 !== i && i(u), r(u), c = o, [4, n(u)];
                            case 1:
                                return c.apply(void 0, [s.sent()]), [2]
                        }
                    }))
                }))
            }
        },
        li = function(e) {
            var t = e.id,
                n = e.inputType,
                r = e.placeholder,
                o = e.disabled,
                i = e.value,
                a = e.error,
                u = e.canSubmit,
                c = e.validate,
                s = e.setValue,
                l = e.setError,
                d = e.handleSubmit,
                p = e.onChange,
                f = e.label,
                E = e.bottomLabel,
                m = e.inputMode,
                h = e.autoComplete,
                S = e.maxLength,
                v = e.validCharactersRegEx,
                A = e.hideFeedback,
                _ = e.concealInput,
                N = e.autoFocus,
                T = "" !== i && null === a,
                O = "" !== i && null !== a,
                b = T || O;
            return U().createElement("div", {
                className: "input-control-wrapper"
            }, f && U().createElement("label", {
                className: "text-label xsmall",
                htmlFor: t
            }, f), U().createElement(Wo.FormGroup, {
                controlId: t,
                className: (b ? "form-has-feedback" : "") + " " + (T ? "form-has-success" : "") + " " + (O ? "form-has-error" : "")
            }, U().createElement(Wo.FormControl, {
                as: "input",
                className: "input-field" + (_ && i.length > 0 ? " input-field-concealed" : ""),
                type: n,
                inputMode: m,
                autoComplete: h,
                maxLength: S,
                disabled: o,
                value: i,
                placeholder: r,
                onChange: si(i, v, c, s, l, p),
                onKeyDown: oi(d, u),
                autoFocus: N
            }), !o && !A && T && U().createElement("span", {
                className: "icon-checkmark-on"
            }), !o && !A && O && U().createElement("span", {
                className: "icon-close"
            }), U().createElement("div", {
                className: "form-control-label bottom-label xsmall"
            }, !o && O ? a : E || " ")))
        },
        di = function(e) {
            var t = e.positiveButton,
                n = e.negativeButton,
                r = e.children;
            return U().createElement(Wo.Modal.Footer, null, U().createElement("div", {
                className: "modal-modern-footer-buttons"
            }, null !== n && U().createElement("button", {
                type: "button",
                className: "btn-secondary-md modal-modern-footer-button",
                "aria-label": n.label,
                disabled: !n.enabled,
                onClick: n.action
            }, n.content), U().createElement("button", {
                type: "button",
                className: "btn-cta-md modal-modern-footer-button",
                "aria-label": t.label,
                disabled: !t.enabled,
                onClick: t.action
            }, t.content)), r)
        };
    ! function(e) {
        e.BACK = "BACK", e.CLOSE = "CLOSE", e.HIDDEN = "HIDDEN"
    }(Qo || (Qo = {}));
    var pi = function(e) {
            var t = e.headerText,
                n = e.buttonType,
                r = e.buttonAction,
                o = e.buttonEnabled,
                i = e.headerInfo;
            return U().createElement(Wo.Modal.Header, {
                useBaseBootstrapComponent: !0
            }, function(e, t, n) {
                switch (e) {
                    case Qo.BACK:
                        return U().createElement("button", {
                            type: "button",
                            className: "modal-modern-header-button",
                            onClick: t,
                            disabled: !n
                        }, U().createElement("span", {
                            className: "icon-back"
                        }));
                    case Qo.CLOSE:
                        return U().createElement("button", {
                            type: "button",
                            className: "modal-modern-header-button",
                            onClick: t,
                            disabled: !n
                        }, U().createElement("span", {
                            className: "icon-close"
                        }));
                    case Qo.HIDDEN:
                    default:
                        return U().createElement("div", null)
                }
            }(n, r, o), U().createElement(Wo.Modal.Title, null, t), U().createElement("div", {
                className: "modal-modern-header-info"
            }, i))
        },
        fi = function(e) {
            return function() {
                return e({
                    type: Go.SET_MODAL_STATE,
                    modalState: Ko.CHANGE_PASSWORD_INTRO
                })
            }
        },
        Ei = function(e, t, n, r) {
            return new(n || (n = Promise))((function(o, i) {
                function a(e) {
                    try {
                        c(r.next(e))
                    } catch (e) {
                        i(e)
                    }
                }

                function u(e) {
                    try {
                        c(r.throw(e))
                    } catch (e) {
                        i(e)
                    }
                }

                function c(e) {
                    var t;
                    e.done ? o(e.value) : (t = e.value, t instanceof n ? t : new n((function(e) {
                        e(t)
                    }))).then(a, u)
                }
                c((r = r.apply(e, t || [])).next())
            }))
        },
        mi = function(e, t) {
            var n, r, o, i, a = {
                label: 0,
                sent: function() {
                    if (1 & o[0]) throw o[1];
                    return o[1]
                },
                trys: [],
                ops: []
            };
            return i = {
                next: u(0),
                throw: u(1),
                return: u(2)
            }, "function" == typeof Symbol && (i[Symbol.iterator] = function() {
                return this
            }), i;

            function u(i) {
                return function(u) {
                    return function(i) {
                        if (n) throw new TypeError("Generator is already executing.");
                        for (; a;) try {
                            if (n = 1, r && (o = 2 & i[0] ? r.return : i[0] ? r.throw || ((o = r.return) && o.call(r), 0) : r.next) && !(o = o.call(r, i[1])).done) return o;
                            switch (r = 0, o && (i = [2 & i[0], o.value]), i[0]) {
                                case 0:
                                case 1:
                                    o = i;
                                    break;
                                case 4:
                                    return a.label++, {
                                        value: i[1],
                                        done: !1
                                    };
                                case 5:
                                    a.label++, r = i[1], i = [0];
                                    continue;
                                case 7:
                                    i = a.ops.pop(), a.trys.pop();
                                    continue;
                                default:
                                    if (!(o = a.trys, (o = o.length > 0 && o[o.length - 1]) || 6 !== i[0] && 2 !== i[0])) {
                                        a = 0;
                                        continue
                                    }
                                    if (3 === i[0] && (!o || i[1] > o[0] && i[1] < o[3])) {
                                        a.label = i[1];
                                        break
                                    }
                                    if (6 === i[0] && a.label < o[1]) {
                                        a.label = o[1], o = i;
                                        break
                                    }
                                    if (o && a.label < o[2]) {
                                        a.label = o[2], a.ops.push(i);
                                        break
                                    }
                                    o[2] && a.ops.pop(), a.trys.pop();
                                    continue
                            }
                            i = t.call(e, a)
                        } catch (e) {
                            i = [6, e], r = 0
                        } finally {
                            n = o = 0
                        }
                        if (5 & i[0]) throw i[1];
                        return {
                            value: i[0] ? i[1] : void 0,
                            done: !0
                        }
                    }([i, u])
                }
            }
        },
        hi = function() {
            var e = Jo(),
                t = e.state,
                n = t.resources,
                r = t.requestService,
                o = t.modalState,
                i = e.dispatch,
                a = (0, I.useState)(""),
                u = a[0],
                c = a[1],
                s = (0, I.useState)(null),
                l = s[0],
                d = s[1],
                p = (0, I.useState)(null),
                f = p[0],
                E = p[1],
                m = (0, I.useState)(!1),
                h = m[0],
                S = m[1],
                v = function() {
                    return Ei(void 0, void 0, void 0, (function() {
                        var e;
                        return mi(this, (function(t) {
                            switch (t.label) {
                                case 0:
                                    return E(null), S(!0), [4, r.accountPin.unlock(u)];
                                case 1:
                                    return (e = t.sent()).isError ? (S(!1), E(Yo(n, e.error)), [2]) : (i({
                                        type: Go.SET_ACCOUNT_PIN_UNLOCKED_UNTIL,
                                        accountPinUnlockedUntil: Date.now() + 1e3 * e.value.unlockedUntil
                                    }), i({
                                        type: Go.SET_MODAL_STATE,
                                        modalState: Ko.CHANGE_PASSWORD_FORM
                                    }), [2])
                            }
                        }))
                    }))
                },
                A = null === l && "" !== u,
                _ = {
                    content: h ? U().createElement("span", {
                        className: "spinner spinner-xs spinner-no-margin"
                    }) : n.Action.UnlockAccountPin,
                    label: n.Action.UnlockAccountPin,
                    enabled: !h && A,
                    action: v
                };
            return U().createElement(U().Fragment, null, U().createElement(pi, {
                headerText: o === Ko.ACCOUNT_PIN_FORM_EXPIRED ? n.Header.AccountPinExpired : n.Header.AccountPinRequired,
                buttonType: Qo.BACK,
                buttonAction: fi(i),
                buttonEnabled: !h,
                headerInfo: null
            }), U().createElement(Wo.Modal.Body, null, U().createElement("div", {
                className: "modal-lock-icon"
            }), U().createElement("p", {
                className: "modal-margin-bottom-xlarge"
            }, n.Description.EnterYourAccountPin), U().createElement(li, {
                id: "inputAccountPin",
                label: n.Label.AccountPin,
                inputType: "password",
                autoComplete: "off",
                placeholder: "",
                disabled: h,
                value: u,
                setValue: c,
                error: l || f,
                setError: d,
                validate: ii,
                canSubmit: A,
                handleSubmit: v,
                onChange: function() {
                    return E(null)
                }
            })), U().createElement(di, {
                positiveButton: _,
                negativeButton: null
            }))
        },
        Si = function(e, t, n, r) {
            return new(n || (n = Promise))((function(o, i) {
                function a(e) {
                    try {
                        c(r.next(e))
                    } catch (e) {
                        i(e)
                    }
                }

                function u(e) {
                    try {
                        c(r.throw(e))
                    } catch (e) {
                        i(e)
                    }
                }

                function c(e) {
                    var t;
                    e.done ? o(e.value) : (t = e.value, t instanceof n ? t : new n((function(e) {
                        e(t)
                    }))).then(a, u)
                }
                c((r = r.apply(e, t || [])).next())
            }))
        },
        vi = function(e, t) {
            var n, r, o, i, a = {
                label: 0,
                sent: function() {
                    if (1 & o[0]) throw o[1];
                    return o[1]
                },
                trys: [],
                ops: []
            };
            return i = {
                next: u(0),
                throw: u(1),
                return: u(2)
            }, "function" == typeof Symbol && (i[Symbol.iterator] = function() {
                return this
            }), i;

            function u(i) {
                return function(u) {
                    return function(i) {
                        if (n) throw new TypeError("Generator is already executing.");
                        for (; a;) try {
                            if (n = 1, r && (o = 2 & i[0] ? r.return : i[0] ? r.throw || ((o = r.return) && o.call(r), 0) : r.next) && !(o = o.call(r, i[1])).done) return o;
                            switch (r = 0, o && (i = [2 & i[0], o.value]), i[0]) {
                                case 0:
                                case 1:
                                    o = i;
                                    break;
                                case 4:
                                    return a.label++, {
                                        value: i[1],
                                        done: !1
                                    };
                                case 5:
                                    a.label++, r = i[1], i = [0];
                                    continue;
                                case 7:
                                    i = a.ops.pop(), a.trys.pop();
                                    continue;
                                default:
                                    if (!(o = a.trys, (o = o.length > 0 && o[o.length - 1]) || 6 !== i[0] && 2 !== i[0])) {
                                        a = 0;
                                        continue
                                    }
                                    if (3 === i[0] && (!o || i[1] > o[0] && i[1] < o[3])) {
                                        a.label = i[1];
                                        break
                                    }
                                    if (6 === i[0] && a.label < o[1]) {
                                        a.label = o[1], o = i;
                                        break
                                    }
                                    if (o && a.label < o[2]) {
                                        a.label = o[2], a.ops.push(i);
                                        break
                                    }
                                    o[2] && a.ops.pop(), a.trys.pop();
                                    continue
                            }
                            i = t.call(e, a)
                        } catch (e) {
                            i = [6, e], r = 0
                        } finally {
                            n = o = 0
                        }
                        if (5 & i[0]) throw i[1];
                        return {
                            value: i[0] ? i[1] : void 0,
                            done: !0
                        }
                    }([i, u])
                }
            }
        },
        Ai = function(e) {
            var t = e.closeModal,
                n = Jo().state,
                r = n.resources,
                o = n.requestService,
                i = n.promptAssignment,
                a = (0, I.useState)(null),
                u = a[0],
                c = a[1],
                s = (0, I.useState)(!1),
                l = s[0],
                d = s[1],
                p = function() {
                    return Si(void 0, void 0, void 0, (function() {
                        var e;
                        return vi(this, (function(t) {
                            switch (t.label) {
                                case 0:
                                    return [4, o.promptAssignments.updateForCurrentUser(lt.DISMISS_PROMPT, i.promptType)];
                                case 1:
                                    return (e = t.sent()).isError && console.warn(Mo, "Dismissing Account Restores Policy Upsell prompt failed with error", e.error && tt[e.error]), [2]
                            }
                        }))
                    }))
                },
                f = {
                    content: l ? U().createElement("span", {
                        className: "spinner spinner-xs spinner-no-margin"
                    }) : r.Action.SetUpAuthenticatorAccountRestoresPolicyUpsell,
                    label: r.Action.SetUpAuthenticatorAccountRestoresPolicyUpsell,
                    enabled: !l,
                    action: function() {
                        return Si(void 0, void 0, void 0, (function() {
                            return vi(this, (function(e) {
                                switch (e.label) {
                                    case 0:
                                        return c(null), d(!0), [4, p()];
                                    case 1:
                                        return e.sent(), window.open("/my/account#!/security?src=authpopup", "_self"), [2]
                                }
                            }))
                        }))
                    }
                };
            return U().createElement(U().Fragment, null, U().createElement(pi, {
                headerText: r.Header.AccountRestoresPolicyUpsell,
                buttonType: Qo.CLOSE,
                buttonAction: function() {
                    return Si(void 0, void 0, void 0, (function() {
                        return vi(this, (function(e) {
                            switch (e.label) {
                                case 0:
                                    return t(), [4, p()];
                                case 1:
                                    return e.sent(), [2]
                            }
                        }))
                    }))
                },
                buttonEnabled: !0,
                headerInfo: null
            }), U().createElement(Wo.Modal.Body, null, U().createElement("div", {
                className: "modal-lock-icon"
            }), U().createElement("p", {
                className: "modal-margin-bottom-sm",
                dangerouslySetInnerHTML: {
                    __html: r.Description.AccountRestoresPolicyUpsellMessageBody(xo)
                }
            }), U().createElement("p", {
                className: "text-error xsmall"
            }, u)), U().createElement(di, {
                positiveButton: f,
                negativeButton: null
            }))
        },
        _i = function(e, t, n, r) {
            return new(n || (n = Promise))((function(o, i) {
                function a(e) {
                    try {
                        c(r.next(e))
                    } catch (e) {
                        i(e)
                    }
                }

                function u(e) {
                    try {
                        c(r.throw(e))
                    } catch (e) {
                        i(e)
                    }
                }

                function c(e) {
                    var t;
                    e.done ? o(e.value) : (t = e.value, t instanceof n ? t : new n((function(e) {
                        e(t)
                    }))).then(a, u)
                }
                c((r = r.apply(e, t || [])).next())
            }))
        },
        Ni = function(e, t) {
            var n, r, o, i, a = {
                label: 0,
                sent: function() {
                    if (1 & o[0]) throw o[1];
                    return o[1]
                },
                trys: [],
                ops: []
            };
            return i = {
                next: u(0),
                throw: u(1),
                return: u(2)
            }, "function" == typeof Symbol && (i[Symbol.iterator] = function() {
                return this
            }), i;

            function u(i) {
                return function(u) {
                    return function(i) {
                        if (n) throw new TypeError("Generator is already executing.");
                        for (; a;) try {
                            if (n = 1, r && (o = 2 & i[0] ? r.return : i[0] ? r.throw || ((o = r.return) && o.call(r), 0) : r.next) && !(o = o.call(r, i[1])).done) return o;
                            switch (r = 0, o && (i = [2 & i[0], o.value]), i[0]) {
                                case 0:
                                case 1:
                                    o = i;
                                    break;
                                case 4:
                                    return a.label++, {
                                        value: i[1],
                                        done: !1
                                    };
                                case 5:
                                    a.label++, r = i[1], i = [0];
                                    continue;
                                case 7:
                                    i = a.ops.pop(), a.trys.pop();
                                    continue;
                                default:
                                    if (!(o = a.trys, (o = o.length > 0 && o[o.length - 1]) || 6 !== i[0] && 2 !== i[0])) {
                                        a = 0;
                                        continue
                                    }
                                    if (3 === i[0] && (!o || i[1] > o[0] && i[1] < o[3])) {
                                        a.label = i[1];
                                        break
                                    }
                                    if (6 === i[0] && a.label < o[1]) {
                                        a.label = o[1], o = i;
                                        break
                                    }
                                    if (o && a.label < o[2]) {
                                        a.label = o[2], a.ops.push(i);
                                        break
                                    }
                                    o[2] && a.ops.pop(), a.trys.pop();
                                    continue
                            }
                            i = t.call(e, a)
                        } catch (e) {
                            i = [6, e], r = 0
                        } finally {
                            n = o = 0
                        }
                        if (5 & i[0]) throw i[1];
                        return {
                            value: i[0] ? i[1] : void 0,
                            done: !0
                        }
                    }([i, u])
                }
            }
        },
        Ti = function(e) {
            var t = e.closeModal,
                n = Jo().state,
                r = n.resources,
                o = n.requestService,
                i = n.promptAssignment,
                a = (0, I.useState)(null),
                u = a[0],
                c = a[1],
                s = (0, I.useState)(!1),
                l = s[0],
                d = s[1],
                p = function() {
                    return _i(void 0, void 0, void 0, (function() {
                        var e;
                        return Ni(this, (function(t) {
                            switch (t.label) {
                                case 0:
                                    return [4, o.promptAssignments.updateForCurrentUser(lt.DISMISS_PROMPT, i.promptType)];
                                case 1:
                                    return (e = t.sent()).isError && console.warn(Mo, "Dismissing Authenticator Upsell prompt failed with error", e.error && tt[e.error]), [2]
                            }
                        }))
                    }))
                },
                f = {
                    content: l ? U().createElement("span", {
                        className: "spinner spinner-xs spinner-no-margin"
                    }) : r.Action.AuthenticatorUpsellNextButtonMessage,
                    label: r.Action.AuthenticatorUpsellNextButtonMessage,
                    enabled: !l,
                    action: function() {
                        return _i(void 0, void 0, void 0, (function() {
                            return Ni(this, (function(e) {
                                switch (e.label) {
                                    case 0:
                                        return c(null), d(!0), [4, p()];
                                    case 1:
                                        return e.sent(), window.open("/my/account#!/security?src=authpopup", "_self"), [2]
                                }
                            }))
                        }))
                    }
                };
            return U().createElement(U().Fragment, null, U().createElement(pi, {
                headerText: r.Header.AuthenticatorUpsellDownloadAuthenticator,
                buttonType: Qo.CLOSE,
                buttonAction: function() {
                    return _i(void 0, void 0, void 0, (function() {
                        return Ni(this, (function(e) {
                            switch (e.label) {
                                case 0:
                                    return t(), [4, p()];
                                case 1:
                                    return e.sent(), [2]
                            }
                        }))
                    }))
                },
                buttonEnabled: !l,
                headerInfo: null
            }), U().createElement(Wo.Modal.Body, null, U().createElement("div", null, U().createElement("p", null, r.Label.AuthenticatorUpsellDownloadInstruction)), U().createElement("div", {
                className: "authenticator-upsell-download-grid"
            }, U().createElement("div", {
                className: "grid-container"
            }, U().createElement("div", {
                className: "grid-item"
            }, U().createElement("div", {
                className: "modal-checkmark-icon"
            })), U().createElement("div", {
                className: "grid-item"
            }, U().createElement("div", null, r.Label.AuthenticatorUpsellMicrosoftOption)), U().createElement("div", {
                className: "grid-item"
            }, U().createElement("div", {
                className: "modal-checkmark-icon"
            })), U().createElement("div", {
                className: "grid-item"
            }, U().createElement("div", null, r.Label.AuthenticatorUpsellGoogleOption)), U().createElement("div", {
                className: "grid-item"
            }, U().createElement("div", {
                className: "modal-checkmark-icon"
            })), U().createElement("div", {
                className: "grid-item"
            }, U().createElement("div", null, r.Label.AuthenticatorUpsellTwilioOption)))), U().createElement("p", {
                className: "text-error xsmall"
            }, u)), U().createElement(di, {
                positiveButton: f,
                negativeButton: null
            }))
        },
        Oi = function(e, t, n, r) {
            return new(n || (n = Promise))((function(o, i) {
                function a(e) {
                    try {
                        c(r.next(e))
                    } catch (e) {
                        i(e)
                    }
                }

                function u(e) {
                    try {
                        c(r.throw(e))
                    } catch (e) {
                        i(e)
                    }
                }

                function c(e) {
                    var t;
                    e.done ? o(e.value) : (t = e.value, t instanceof n ? t : new n((function(e) {
                        e(t)
                    }))).then(a, u)
                }
                c((r = r.apply(e, t || [])).next())
            }))
        },
        bi = function(e, t) {
            var n, r, o, i, a = {
                label: 0,
                sent: function() {
                    if (1 & o[0]) throw o[1];
                    return o[1]
                },
                trys: [],
                ops: []
            };
            return i = {
                next: u(0),
                throw: u(1),
                return: u(2)
            }, "function" == typeof Symbol && (i[Symbol.iterator] = function() {
                return this
            }), i;

            function u(i) {
                return function(u) {
                    return function(i) {
                        if (n) throw new TypeError("Generator is already executing.");
                        for (; a;) try {
                            if (n = 1, r && (o = 2 & i[0] ? r.return : i[0] ? r.throw || ((o = r.return) && o.call(r), 0) : r.next) && !(o = o.call(r, i[1])).done) return o;
                            switch (r = 0, o && (i = [2 & i[0], o.value]), i[0]) {
                                case 0:
                                case 1:
                                    o = i;
                                    break;
                                case 4:
                                    return a.label++, {
                                        value: i[1],
                                        done: !1
                                    };
                                case 5:
                                    a.label++, r = i[1], i = [0];
                                    continue;
                                case 7:
                                    i = a.ops.pop(), a.trys.pop();
                                    continue;
                                default:
                                    if (!(o = a.trys, (o = o.length > 0 && o[o.length - 1]) || 6 !== i[0] && 2 !== i[0])) {
                                        a = 0;
                                        continue
                                    }
                                    if (3 === i[0] && (!o || i[1] > o[0] && i[1] < o[3])) {
                                        a.label = i[1];
                                        break
                                    }
                                    if (6 === i[0] && a.label < o[1]) {
                                        a.label = o[1], o = i;
                                        break
                                    }
                                    if (o && a.label < o[2]) {
                                        a.label = o[2], a.ops.push(i);
                                        break
                                    }
                                    o[2] && a.ops.pop(), a.trys.pop();
                                    continue
                            }
                            i = t.call(e, a)
                        } catch (e) {
                            i = [6, e], r = 0
                        } finally {
                            n = o = 0
                        }
                        if (5 & i[0]) throw i[1];
                        return {
                            value: i[0] ? i[1] : void 0,
                            done: !0
                        }
                    }([i, u])
                }
            }
        },
        yi = function(e) {
            var t = e.closeModal,
                n = Jo(),
                r = n.state,
                o = r.resources,
                i = r.requestService,
                a = r.promptAssignment,
                u = n.dispatch,
                c = (0, I.useState)(null),
                s = c[0],
                l = c[1],
                d = (0, I.useState)(!1),
                p = d[0],
                f = d[1],
                E = {
                    content: p ? U().createElement("span", {
                        className: "spinner spinner-xs spinner-no-margin"
                    }) : o.Action.AuthenticatorUpsellSetupAuthenticatorButtonMessage,
                    label: o.Action.AuthenticatorUpsellSetupAuthenticatorButtonMessage,
                    enabled: !p,
                    action: function() {
                        return Oi(void 0, void 0, void 0, (function() {
                            var e;
                            return bi(this, (function(t) {
                                switch (t.label) {
                                    case 0:
                                        return l(null), f(!0), [4, i.accountPin.getState()];
                                    case 1:
                                        return (e = t.sent()).isError ? (f(!1), l(Yo(o, e.error)), [2]) : (u({
                                            type: Go.SET_MODAL_STATE,
                                            modalState: Ko.AUTHENTICATOR_UPSELL_DOWNLOAD_APPS
                                        }), [2])
                                }
                            }))
                        }))
                    }
                };
            return U().createElement(U().Fragment, null, U().createElement(pi, {
                headerText: o.Header.AuthenticatorUpsellWelcomeMessage,
                buttonType: Qo.CLOSE,
                buttonAction: function() {
                    return Oi(void 0, void 0, void 0, (function() {
                        return bi(this, (function(e) {
                            switch (e.label) {
                                case 0:
                                    return t(), [4, Oi(void 0, void 0, void 0, (function() {
                                        var e;
                                        return bi(this, (function(t) {
                                            switch (t.label) {
                                                case 0:
                                                    return [4, i.promptAssignments.updateForCurrentUser(lt.DISMISS_PROMPT, a.promptType)];
                                                case 1:
                                                    return (e = t.sent()).isError && console.warn(Mo, "Dismissing Authenticator Upsell prompt failed with error", e.error && tt[e.error]), [2]
                                            }
                                        }))
                                    }))];
                                case 1:
                                    return e.sent(), [2]
                            }
                        }))
                    }))
                },
                buttonEnabled: !p,
                headerInfo: null
            }), U().createElement(Wo.Modal.Body, null, U().createElement("div", {
                className: "authenticator-upsell-intro-grid"
            }, U().createElement("div", {
                className: "grid-container"
            }, U().createElement("div", {
                className: "grid-item"
            }, U().createElement("div", {
                className: "modal-two-factors-icon"
            })), U().createElement("div", {
                className: "grid-item"
            }, U().createElement("b", null, o.Label.AuthenticatorUpsellTwoFactorHeadline), U().createElement("div", null, o.Label.AuthenticatorUpsellTwoFactorMessage)), U().createElement("div", {
                className: "grid-item"
            }, U().createElement("div", {
                className: "modal-protect-icon"
            })), U().createElement("div", {
                className: "grid-item"
            }, U().createElement("b", null, o.Label.AuthenticatorUpsellProtectRobuxHeadline), U().createElement("div", null, o.Label.AuthenticatorUpsellProtectRobuxMessage)), U().createElement("div", {
                className: "grid-item"
            }, U().createElement("div", {
                className: "modal-keep-bad-icon"
            })), U().createElement("div", {
                className: "grid-item"
            }, U().createElement("b", null, o.Label.AuthenticatorUpsellBadActorHeadline), U().createElement("div", null, o.Label.AuthenticatorUpsellBadActorMessage)))), U().createElement("p", {
                className: "text-error xsmall"
            }, s)), U().createElement(di, {
                positiveButton: E,
                negativeButton: null
            }))
        },
        Ci = function(e) {
            var t = e.closeModal,
                n = Jo().state.resources;
            return U().createElement(U().Fragment, null, U().createElement(pi, {
                headerText: n.Header.Success,
                buttonType: Qo.CLOSE,
                buttonAction: t,
                buttonEnabled: !0,
                headerInfo: null
            }), U().createElement(Wo.Modal.Body, null, U().createElement("div", {
                className: "modal-lock-icon"
            }), U().createElement("p", {
                className: "modal-margin-bottom-large"
            }, n.Description.ChangeYourPasswordSuccess)))
        },
        Pi = function(e, t, n, r) {
            return new(n || (n = Promise))((function(o, i) {
                function a(e) {
                    try {
                        c(r.next(e))
                    } catch (e) {
                        i(e)
                    }
                }

                function u(e) {
                    try {
                        c(r.throw(e))
                    } catch (e) {
                        i(e)
                    }
                }

                function c(e) {
                    var t;
                    e.done ? o(e.value) : (t = e.value, t instanceof n ? t : new n((function(e) {
                        e(t)
                    }))).then(a, u)
                }
                c((r = r.apply(e, t || [])).next())
            }))
        },
        wi = function(e, t) {
            var n, r, o, i, a = {
                label: 0,
                sent: function() {
                    if (1 & o[0]) throw o[1];
                    return o[1]
                },
                trys: [],
                ops: []
            };
            return i = {
                next: u(0),
                throw: u(1),
                return: u(2)
            }, "function" == typeof Symbol && (i[Symbol.iterator] = function() {
                return this
            }), i;

            function u(i) {
                return function(u) {
                    return function(i) {
                        if (n) throw new TypeError("Generator is already executing.");
                        for (; a;) try {
                            if (n = 1, r && (o = 2 & i[0] ? r.return : i[0] ? r.throw || ((o = r.return) && o.call(r), 0) : r.next) && !(o = o.call(r, i[1])).done) return o;
                            switch (r = 0, o && (i = [2 & i[0], o.value]), i[0]) {
                                case 0:
                                case 1:
                                    o = i;
                                    break;
                                case 4:
                                    return a.label++, {
                                        value: i[1],
                                        done: !1
                                    };
                                case 5:
                                    a.label++, r = i[1], i = [0];
                                    continue;
                                case 7:
                                    i = a.ops.pop(), a.trys.pop();
                                    continue;
                                default:
                                    if (!(o = a.trys, (o = o.length > 0 && o[o.length - 1]) || 6 !== i[0] && 2 !== i[0])) {
                                        a = 0;
                                        continue
                                    }
                                    if (3 === i[0] && (!o || i[1] > o[0] && i[1] < o[3])) {
                                        a.label = i[1];
                                        break
                                    }
                                    if (6 === i[0] && a.label < o[1]) {
                                        a.label = o[1], o = i;
                                        break
                                    }
                                    if (o && a.label < o[2]) {
                                        a.label = o[2], a.ops.push(i);
                                        break
                                    }
                                    o[2] && a.ops.pop(), a.trys.pop();
                                    continue
                            }
                            i = t.call(e, a)
                        } catch (e) {
                            i = [6, e], r = 0
                        } finally {
                            n = o = 0
                        }
                        if (5 & i[0]) throw i[1];
                        return {
                            value: i[0] ? i[1] : void 0,
                            done: !0
                        }
                    }([i, u])
                }
            }
        },
        Ri = function() {
            var e = Jo(),
                t = e.state,
                n = t.username,
                r = t.resources,
                o = t.requestService,
                i = t.accountPinUnlockedUntil,
                a = e.dispatch,
                u = (0, I.useState)(""),
                c = u[0],
                s = u[1],
                l = (0, I.useState)(null),
                d = l[0],
                p = l[1],
                f = (0, I.useState)(""),
                E = f[0],
                m = f[1],
                h = (0, I.useState)(null),
                S = h[0],
                v = h[1],
                A = (0, I.useState)(""),
                _ = A[0],
                N = A[1],
                T = (0, I.useState)(null),
                O = T[0],
                b = T[1],
                y = (0, I.useState)(null),
                C = y[0],
                w = y[1],
                R = (0, I.useState)(!1),
                D = R[0],
                g = R[1],
                L = (0, I.useState)(!1),
                M = L[0],
                k = L[1],
                x = (0, I.useState)(0),
                F = x[0],
                V = x[1],
                H = (0, I.useState)(0),
                W = H[0],
                B = H[1],
                Y = function() {
                    return w(null)
                },
                G = function() {
                    for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
                    return function(t) {
                        e.forEach((function(e) {
                            return e(t)
                        }))
                    }
                },
                K = function() {
                    return Pi(void 0, void 0, void 0, (function() {
                        var e, t;
                        return wi(this, (function(n) {
                            switch (n.label) {
                                case 0:
                                    return w(null), k(!0), [4, o.password.changeForCurrentUser(c, E)];
                                case 1:
                                    return (e = n.sent()).isError ? (k(!1), e.error === we.PIN_LOCKED ? (a({
                                        type: Go.SET_MODAL_STATE,
                                        modalState: Ko.ACCOUNT_PIN_FORM_EXPIRED
                                    }), [2]) : (e.error === we.INVALID_CURRENT_PASSWORD ? g(!0) : g(!1), w(function(e, t) {
                                        switch (t) {
                                            case we.FLOODED:
                                                return e.Message.Error.Passwords.Flooded;
                                            case we.INVALID_PASSWORD:
                                                return e.Message.Error.Passwords.InvalidPassword;
                                            case we.INVALID_CURRENT_PASSWORD:
                                                return e.Message.Error.Passwords.InvalidCurrentPassword;
                                            case we.PIN_LOCKED:
                                                return e.Message.Error.Passwords.PinLocked;
                                            default:
                                                return e.Message.Error.Passwords.Default
                                        }
                                    }(r, e.error)), [2])) : null === i ? [3, 3] : [4, o.accountPin.lock()];
                                case 2:
                                    (t = n.sent()).isError && t.error !== P.ACCOUNT_LOCKED || a({
                                        type: Go.SET_ACCOUNT_PIN_UNLOCKED_UNTIL,
                                        accountPinUnlockedUntil: null
                                    }), n.label = 3;
                                case 3:
                                    return a({
                                        type: Go.SET_MODAL_STATE,
                                        modalState: Ko.CHANGE_PASSWORD_CONFIRMATION
                                    }), [2]
                            }
                        }))
                    }))
                };
            (0, I.useEffect)((function() {
                var e, t = function() {
                    if (null !== i)
                        if (Date.now() < i) {
                            var t = (i - Date.now()) / 1e3;
                            V(Math.floor(t / 60)), B(Math.floor(t % 60))
                        } else a({
                            type: Go.SET_MODAL_STATE,
                            modalState: Ko.ACCOUNT_PIN_FORM_EXPIRED
                        });
                    else clearInterval(e)
                };
                return t(), e = setInterval(t, 1e3),
                    function() {
                        return clearInterval(e)
                    }
            }), [i, V, B, a]);
            var Q = "" !== c && null === d && "" !== E && null === S && "" !== _ && null === O,
                X = {
                    content: M ? U().createElement("span", {
                        className: "spinner spinner-xs spinner-no-margin"
                    }) : r.Action.SubmitChangePassword,
                    label: r.Action.SubmitChangePassword,
                    enabled: !M && Q,
                    action: K
                },
                q = U().createElement("a", {
                    href: "https://en.help.roblox.com/hc/articles/203313070-I-Forgot-My-Password",
                    className: "bottom-label-link",
                    target: "_blank",
                    rel: "noreferrer"
                }, r.Label.IForgotMyPassword),
                z = U().createElement(I.Fragment, null, U().createElement("div", {
                    className: "shield-check-icon xsmall"
                }), U().createElement("div", {
                    className: "bottom-label-text-with-start-margin text-label xsmall"
                }, r.Label.UseAUniquePassword));
            return U().createElement(U().Fragment, null, U().createElement(pi, {
                headerText: r.Header.CreateAStrongPassword,
                buttonType: Qo.BACK,
                buttonAction: fi(a),
                buttonEnabled: !M,
                headerInfo: null !== i ? U().createElement(U().Fragment, null, U().createElement("p", {
                    className: "small modal-modern-header-info-line"
                }, r.Label.TimeRemaining), U().createElement("p", {
                    className: "small modal-modern-header-info-line",
                    style: {
                        fontFamily: "monospace, monospace"
                    }
                }, F.toString().padStart(2, "0"), ":", W.toString().padStart(2, "0"))) : null
            }), U().createElement(Wo.Modal.Body, null, U().createElement(li, {
                id: "inputCurrentPassword",
                label: r.Label.CurrentPassword,
                bottomLabel: q,
                inputType: "password",
                autoComplete: "current-password",
                placeholder: "",
                disabled: M,
                value: c,
                setValue: s,
                error: d || D && C || null,
                setError: p,
                validate: ii,
                canSubmit: Q,
                handleSubmit: K,
                onChange: Y
            }), U().createElement(li, {
                id: "inputNewPassword",
                label: r.Label.NewPassword,
                bottomLabel: z,
                inputType: "password",
                autoComplete: "new-password",
                placeholder: r.Label.AtLeastCharacters(8),
                disabled: M,
                value: E,
                setValue: m,
                error: S,
                setError: G((function() {
                    return b(null)
                }), v),
                validate: ci(ai(o, r, n, r.Message.Error.PasswordValidation.Default), "" !== _ ? ui(r.Message.Error.Input.PasswordsDoNotMatch, _) : ii),
                canSubmit: Q,
                handleSubmit: K,
                onChange: Y
            }), U().createElement(li, {
                id: "inputNewPasswordAgain",
                label: r.Label.ConfirmNewPassword,
                inputType: "password",
                autoComplete: "new-password",
                placeholder: "",
                disabled: M,
                value: _,
                setValue: N,
                error: O || !D && C || null,
                setError: G((function() {
                    return v(null)
                }), b),
                validate: ci(ui(r.Message.Error.Input.PasswordsDoNotMatch, E), ai(o, r, n, r.Message.Error.PasswordValidation.Default)),
                canSubmit: Q,
                handleSubmit: K,
                onChange: Y
            })), U().createElement(di, {
                positiveButton: X,
                negativeButton: null
            }))
        },
        Ii = function(e, t, n, r) {
            return new(n || (n = Promise))((function(o, i) {
                function a(e) {
                    try {
                        c(r.next(e))
                    } catch (e) {
                        i(e)
                    }
                }

                function u(e) {
                    try {
                        c(r.throw(e))
                    } catch (e) {
                        i(e)
                    }
                }

                function c(e) {
                    var t;
                    e.done ? o(e.value) : (t = e.value, t instanceof n ? t : new n((function(e) {
                        e(t)
                    }))).then(a, u)
                }
                c((r = r.apply(e, t || [])).next())
            }))
        },
        Ui = function(e, t) {
            var n, r, o, i, a = {
                label: 0,
                sent: function() {
                    if (1 & o[0]) throw o[1];
                    return o[1]
                },
                trys: [],
                ops: []
            };
            return i = {
                next: u(0),
                throw: u(1),
                return: u(2)
            }, "function" == typeof Symbol && (i[Symbol.iterator] = function() {
                return this
            }), i;

            function u(i) {
                return function(u) {
                    return function(i) {
                        if (n) throw new TypeError("Generator is already executing.");
                        for (; a;) try {
                            if (n = 1, r && (o = 2 & i[0] ? r.return : i[0] ? r.throw || ((o = r.return) && o.call(r), 0) : r.next) && !(o = o.call(r, i[1])).done) return o;
                            switch (r = 0, o && (i = [2 & i[0], o.value]), i[0]) {
                                case 0:
                                case 1:
                                    o = i;
                                    break;
                                case 4:
                                    return a.label++, {
                                        value: i[1],
                                        done: !1
                                    };
                                case 5:
                                    a.label++, r = i[1], i = [0];
                                    continue;
                                case 7:
                                    i = a.ops.pop(), a.trys.pop();
                                    continue;
                                default:
                                    if (!(o = a.trys, (o = o.length > 0 && o[o.length - 1]) || 6 !== i[0] && 2 !== i[0])) {
                                        a = 0;
                                        continue
                                    }
                                    if (3 === i[0] && (!o || i[1] > o[0] && i[1] < o[3])) {
                                        a.label = i[1];
                                        break
                                    }
                                    if (6 === i[0] && a.label < o[1]) {
                                        a.label = o[1], o = i;
                                        break
                                    }
                                    if (o && a.label < o[2]) {
                                        a.label = o[2], a.ops.push(i);
                                        break
                                    }
                                    o[2] && a.ops.pop(), a.trys.pop();
                                    continue
                            }
                            i = t.call(e, a)
                        } catch (e) {
                            i = [6, e], r = 0
                        } finally {
                            n = o = 0
                        }
                        if (5 & i[0]) throw i[1];
                        return {
                            value: i[0] ? i[1] : void 0,
                            done: !0
                        }
                    }([i, u])
                }
            }
        },
        Di = function(e) {
            var t = e.closeModal,
                n = Jo(),
                r = n.state,
                o = r.promptAssignment,
                i = r.resources,
                a = r.requestService,
                u = n.dispatch,
                c = (0, I.useState)(null),
                s = c[0],
                l = c[1],
                d = (0, I.useState)(!1),
                p = d[0],
                f = d[1],
                E = "An unexpected issue occurred while displaying this text.";
            o.isGeneric || (E = o.promptType !== ot.CHANGE_PASSWORD__BREACHED_CREDENTIAL ? i.Description.UnusualActivity + " " + i.Description.ChangeYourPassword : i.Description.ChangeYourPasswordImmediately + " " + i.Description.NoChangeForceReset(Zo(o.metadata.forceResetTimestamp)));
            var m = {
                content: p ? U().createElement("span", {
                    className: "spinner spinner-xs spinner-no-margin"
                }) : i.Action.ContinueChangePassword,
                label: i.Action.ContinueChangePassword,
                enabled: !p,
                action: function() {
                    return Ii(void 0, void 0, void 0, (function() {
                        var e, t;
                        return Ui(this, (function(n) {
                            switch (n.label) {
                                case 0:
                                    return l(null), f(!0), [4, a.accountPin.getState()];
                                case 1:
                                    return (e = n.sent()).isError ? (f(!1), l(Yo(i, e.error)), [2]) : (t = null !== e.value.unlockedUntil && e.value.unlockedUntil > 0, !e.value.isEnabled || t ? (u({
                                        type: Go.SET_ACCOUNT_PIN_UNLOCKED_UNTIL,
                                        accountPinUnlockedUntil: null !== e.value.unlockedUntil ? Date.now() + 1e3 * e.value.unlockedUntil : null
                                    }), u({
                                        type: Go.SET_MODAL_STATE,
                                        modalState: Ko.CHANGE_PASSWORD_FORM
                                    }), [2]) : (u({
                                        type: Go.SET_MODAL_STATE,
                                        modalState: Ko.ACCOUNT_PIN_FORM
                                    }), [2]))
                            }
                        }))
                    }))
                }
            };
            return U().createElement(U().Fragment, null, U().createElement(pi, {
                headerText: i.Header.ChangeYourPassword,
                buttonType: Qo.CLOSE,
                buttonAction: t,
                buttonEnabled: !p,
                headerInfo: null
            }), U().createElement(Wo.Modal.Body, null, U().createElement("div", {
                className: "modal-lock-icon"
            }), U().createElement("p", {
                className: "modal-margin-bottom",
                dangerouslySetInnerHTML: {
                    __html: E
                }
            }), U().createElement("p", {
                className: "text-error xsmall"
            }, s)), U().createElement(di, {
                positiveButton: m,
                negativeButton: null
            }))
        },
        gi = function(e, t, n, r) {
            return new(n || (n = Promise))((function(o, i) {
                function a(e) {
                    try {
                        c(r.next(e))
                    } catch (e) {
                        i(e)
                    }
                }

                function u(e) {
                    try {
                        c(r.throw(e))
                    } catch (e) {
                        i(e)
                    }
                }

                function c(e) {
                    var t;
                    e.done ? o(e.value) : (t = e.value, t instanceof n ? t : new n((function(e) {
                        e(t)
                    }))).then(a, u)
                }
                c((r = r.apply(e, t || [])).next())
            }))
        },
        Li = function(e, t) {
            var n, r, o, i, a = {
                label: 0,
                sent: function() {
                    if (1 & o[0]) throw o[1];
                    return o[1]
                },
                trys: [],
                ops: []
            };
            return i = {
                next: u(0),
                throw: u(1),
                return: u(2)
            }, "function" == typeof Symbol && (i[Symbol.iterator] = function() {
                return this
            }), i;

            function u(i) {
                return function(u) {
                    return function(i) {
                        if (n) throw new TypeError("Generator is already executing.");
                        for (; a;) try {
                            if (n = 1, r && (o = 2 & i[0] ? r.return : i[0] ? r.throw || ((o = r.return) && o.call(r), 0) : r.next) && !(o = o.call(r, i[1])).done) return o;
                            switch (r = 0, o && (i = [2 & i[0], o.value]), i[0]) {
                                case 0:
                                case 1:
                                    o = i;
                                    break;
                                case 4:
                                    return a.label++, {
                                        value: i[1],
                                        done: !1
                                    };
                                case 5:
                                    a.label++, r = i[1], i = [0];
                                    continue;
                                case 7:
                                    i = a.ops.pop(), a.trys.pop();
                                    continue;
                                default:
                                    if (!(o = a.trys, (o = o.length > 0 && o[o.length - 1]) || 6 !== i[0] && 2 !== i[0])) {
                                        a = 0;
                                        continue
                                    }
                                    if (3 === i[0] && (!o || i[1] > o[0] && i[1] < o[3])) {
                                        a.label = i[1];
                                        break
                                    }
                                    if (6 === i[0] && a.label < o[1]) {
                                        a.label = o[1], o = i;
                                        break
                                    }
                                    if (o && a.label < o[2]) {
                                        a.label = o[2], a.ops.push(i);
                                        break
                                    }
                                    o[2] && a.ops.pop(), a.trys.pop();
                                    continue
                            }
                            i = t.call(e, a)
                        } catch (e) {
                            i = [6, e], r = 0
                        } finally {
                            n = o = 0
                        }
                        if (5 & i[0]) throw i[1];
                        return {
                            value: i[0] ? i[1] : void 0,
                            done: !0
                        }
                    }([i, u])
                }
            }
        },
        Mi = function(e) {
            var t = e.closeModal,
                n = Jo(),
                r = n.state,
                o = r.promptAssignment,
                i = r.resources,
                a = r.requestService,
                u = n.dispatch,
                c = (0, I.useState)(!1),
                s = c[0],
                l = c[1],
                d = i.Description.AreYouSureDismissForeverChangePassword,
                p = i.Action.ConfirmDismissForeverChangePassword,
                f = i.Action.AbortDismissForeverChangePassword,
                E = {
                    content: f,
                    label: f,
                    enabled: !s,
                    action: function() {
                        u({
                            type: Go.SET_MODAL_STATE,
                            modalState: Ko.CHANGE_PASSWORD_INTRO
                        })
                    }
                },
                m = {
                    content: s ? U().createElement("span", {
                        className: "spinner spinner-xs spinner-no-margin"
                    }) : p,
                    label: p,
                    enabled: !s,
                    action: function() {
                        return gi(void 0, void 0, void 0, (function() {
                            var e;
                            return Li(this, (function(n) {
                                switch (n.label) {
                                    case 0:
                                        return l(!0), [4, a.promptAssignments.updateForCurrentUser(lt.DISABLE_PROMPT, o.promptType)];
                                    case 1:
                                        return (e = n.sent()).isError ? (l(!1), console.warn(Mo, "Disabling prompt failed with error", e.error && tt[e.error]), [2]) : (u({
                                            type: Go.DISMISS_FOREVER
                                        }), t(), [2])
                                }
                            }))
                        }))
                    }
                };
            return U().createElement(U().Fragment, null, U().createElement(pi, {
                headerText: i.Header.AreYouSure,
                buttonType: Qo.HIDDEN,
                buttonAction: t,
                buttonEnabled: !0,
                headerInfo: null
            }), U().createElement(Wo.Modal.Body, null, U().createElement("div", {
                className: "modal-lock-icon"
            }), U().createElement("p", null, d)), U().createElement(di, {
                positiveButton: E,
                negativeButton: m
            }))
        },
        ki = function(e, t, n, r) {
            return new(n || (n = Promise))((function(o, i) {
                function a(e) {
                    try {
                        c(r.next(e))
                    } catch (e) {
                        i(e)
                    }
                }

                function u(e) {
                    try {
                        c(r.throw(e))
                    } catch (e) {
                        i(e)
                    }
                }

                function c(e) {
                    var t;
                    e.done ? o(e.value) : (t = e.value, t instanceof n ? t : new n((function(e) {
                        e(t)
                    }))).then(a, u)
                }
                c((r = r.apply(e, t || [])).next())
            }))
        },
        xi = function(e, t) {
            var n, r, o, i, a = {
                label: 0,
                sent: function() {
                    if (1 & o[0]) throw o[1];
                    return o[1]
                },
                trys: [],
                ops: []
            };
            return i = {
                next: u(0),
                throw: u(1),
                return: u(2)
            }, "function" == typeof Symbol && (i[Symbol.iterator] = function() {
                return this
            }), i;

            function u(i) {
                return function(u) {
                    return function(i) {
                        if (n) throw new TypeError("Generator is already executing.");
                        for (; a;) try {
                            if (n = 1, r && (o = 2 & i[0] ? r.return : i[0] ? r.throw || ((o = r.return) && o.call(r), 0) : r.next) && !(o = o.call(r, i[1])).done) return o;
                            switch (r = 0, o && (i = [2 & i[0], o.value]), i[0]) {
                                case 0:
                                case 1:
                                    o = i;
                                    break;
                                case 4:
                                    return a.label++, {
                                        value: i[1],
                                        done: !1
                                    };
                                case 5:
                                    a.label++, r = i[1], i = [0];
                                    continue;
                                case 7:
                                    i = a.ops.pop(), a.trys.pop();
                                    continue;
                                default:
                                    if (!(o = a.trys, (o = o.length > 0 && o[o.length - 1]) || 6 !== i[0] && 2 !== i[0])) {
                                        a = 0;
                                        continue
                                    }
                                    if (3 === i[0] && (!o || i[1] > o[0] && i[1] < o[3])) {
                                        a.label = i[1];
                                        break
                                    }
                                    if (6 === i[0] && a.label < o[1]) {
                                        a.label = o[1], o = i;
                                        break
                                    }
                                    if (o && a.label < o[2]) {
                                        a.label = o[2], a.ops.push(i);
                                        break
                                    }
                                    o[2] && a.ops.pop(), a.trys.pop();
                                    continue
                            }
                            i = t.call(e, a)
                        } catch (e) {
                            i = [6, e], r = 0
                        } finally {
                            n = o = 0
                        }
                        if (5 & i[0]) throw i[1];
                        return {
                            value: i[0] ? i[1] : void 0,
                            done: !0
                        }
                    }([i, u])
                }
            }
        },
        Fi = function(e) {
            var t = e.closeModal,
                n = Jo().state,
                r = n.resources,
                o = n.requestService,
                i = n.promptAssignment,
                a = (0, I.useState)(null),
                u = a[0],
                c = a[1],
                s = (0, I.useState)(!1),
                l = s[0],
                d = s[1],
                p = function() {
                    return ki(void 0, void 0, void 0, (function() {
                        var e;
                        return xi(this, (function(t) {
                            switch (t.label) {
                                case 0:
                                    return [4, o.promptAssignments.updateForCurrentUser(lt.DISMISS_PROMPT, i.promptType)];
                                case 1:
                                    return (e = t.sent()).isError && console.warn(Mo, "Dismissing Account Restores Policy Upsell prompt failed with error", e.error && tt[e.error]), [2]
                            }
                        }))
                    }))
                },
                f = {
                    content: l ? U().createElement("span", {
                        className: "spinner spinner-xs spinner-no-margin"
                    }) : r.Action.SetUpEmail2SV,
                    label: r.Action.SetUpEmail2SV,
                    enabled: !l,
                    action: function() {
                        return ki(void 0, void 0, void 0, (function() {
                            return xi(this, (function(e) {
                                switch (e.label) {
                                    case 0:
                                        return c(null), d(!0), [4, p()];
                                    case 1:
                                        return e.sent(), window.open("/my/account#!/security?src=emailhighlight", "_self"), [2]
                                }
                            }))
                        }))
                    }
                };
            return U().createElement(U().Fragment, null, U().createElement(pi, {
                headerText: r.Header.Email2SVUpsell,
                buttonType: Qo.CLOSE,
                buttonAction: function() {
                    return ki(void 0, void 0, void 0, (function() {
                        return xi(this, (function(e) {
                            switch (e.label) {
                                case 0:
                                    return t(), [4, p()];
                                case 1:
                                    return e.sent(), [2]
                            }
                        }))
                    }))
                },
                buttonEnabled: !0,
                headerInfo: null
            }), U().createElement(Wo.Modal.Body, null, U().createElement("div", {
                className: "modal-lock-icon"
            }), U().createElement("p", {
                className: "modal-margin-bottom-sm",
                dangerouslySetInnerHTML: {
                    __html: r.Description.Email2SVUpsellMessageBody(xo)
                }
            }), U().createElement("p", {
                className: "text-error xsmall"
            }, u)), U().createElement(di, {
                positiveButton: f,
                negativeButton: null
            }))
        },
        Vi = function() {
            var e = Jo(),
                t = e.state,
                n = t.isFlowComplete,
                r = t.modalState,
                o = t.promptAssignment,
                i = e.dispatch,
                a = (0, I.useState)(!0),
                u = a[0],
                c = a[1],
                s = function() {
                    return c(!1)
                },
                l = function(e) {
                    switch (e) {
                        case Ko.CHANGE_PASSWORD_INTRO:
                            return {
                                innerFragment: Di,
                                canClickBackdropToClose: !0
                            };
                        case Ko.CHANGE_PASSWORD_FORM:
                            return {
                                innerFragment: Ri,
                                canClickBackdropToClose: !1
                            };
                        case Ko.ACCOUNT_PIN_FORM:
                        case Ko.ACCOUNT_PIN_FORM_EXPIRED:
                            return {
                                innerFragment: hi,
                                canClickBackdropToClose: !1
                            };
                        case Ko.CHANGE_PASSWORD_CONFIRMATION:
                            return {
                                innerFragment: Ci,
                                canClickBackdropToClose: !0
                            };
                        case Ko.CHANGE_PASSWORD_DISMISS_CONFIRMATION:
                            return {
                                innerFragment: Mi,
                                canClickBackdropToClose: !1
                            };
                        case Ko.AUTHENTICATOR_UPSELL_OPENING:
                            return {
                                innerFragment: yi,
                                canClickBackdropToClose: !1
                            };
                        case Ko.AUTHENTICATOR_UPSELL_DOWNLOAD_APPS:
                            return {
                                innerFragment: Ti,
                                canClickBackdropToClose: !1
                            };
                        case Ko.ACCOUNT_RESTORE_POLICY_UPSELL:
                            return {
                                innerFragment: Ai,
                                canClickBackdropToClose: !1
                            };
                        case Ko.EMAIL_2SV_UPSELL:
                            return {
                                innerFragment: Fi,
                                canClickBackdropToClose: !1
                            };
                        default:
                            return null
                    }
                }(r),
                d = o.promptType === ot.AUTHENTICATOR_UPSELL || o.promptType === ot.ACCOUNT_RESTORES_POLICY_UPSELL || o.promptType === ot.BROADER_AUTHENTICATOR_UPSELL && !0 !== o.isGeneric && !o.metadata.showBanner || o.promptType === ot.EMAIL_2SV_UPSELL && !0 !== o.isGeneric && !o.metadata.showBanner;
            return U().createElement(U().Fragment, null, !n && !d && U().createElement(ti, null), l && U().createElement(Wo.Modal, {
                className: "modal-modern modal-modern-security-prompt",
                show: u,
                onHide: s,
                onExited: function() {
                    i({
                        type: Go.SET_MODAL_STATE,
                        modalState: Ko.NONE
                    }), c(!0)
                },
                backdrop: l.canClickBackdropToClose ? void 0 : "static"
            }, U().createElement(l.innerFragment, {
                closeModal: s
            })))
        },
        Hi = (0, Lo.withTranslations)((function(e) {
            var t = e.promptAssignment,
                n = e.username,
                r = e.isUserUnder13,
                o = e.eventService,
                i = e.requestService,
                a = e.translate;
            return U().createElement(jo, {
                promptAssignment: t,
                username: n,
                isUserUnder13: r,
                eventService: o,
                requestService: i,
                translate: a
            }, U().createElement(Vi, null))
        }), {
            common: [],
            feature: "Feature.AccountSecurityPrompt"
        }),
        Wi = function() {
            function e(e) {
                this.promptType = e
            }
            return e.prototype.sendModalStateViewedEvent = function(e) {
                R().EventStream.SendEventWithTarget(Vo, Ho.modalStateViewed, {
                    promptType: this.promptType,
                    state: e
                }, R().EventStream.TargetTypes.WWW)
            }, e
        }(),
        Bi = function(e, t, n, r) {
            return new(n || (n = Promise))((function(o, i) {
                function a(e) {
                    try {
                        c(r.next(e))
                    } catch (e) {
                        i(e)
                    }
                }

                function u(e) {
                    try {
                        c(r.throw(e))
                    } catch (e) {
                        i(e)
                    }
                }

                function c(e) {
                    var t;
                    e.done ? o(e.value) : (t = e.value, t instanceof n ? t : new n((function(e) {
                        e(t)
                    }))).then(a, u)
                }
                c((r = r.apply(e, t || [])).next())
            }))
        },
        Yi = function(e, t) {
            var n, r, o, i, a = {
                label: 0,
                sent: function() {
                    if (1 & o[0]) throw o[1];
                    return o[1]
                },
                trys: [],
                ops: []
            };
            return i = {
                next: u(0),
                throw: u(1),
                return: u(2)
            }, "function" == typeof Symbol && (i[Symbol.iterator] = function() {
                return this
            }), i;

            function u(i) {
                return function(u) {
                    return function(i) {
                        if (n) throw new TypeError("Generator is already executing.");
                        for (; a;) try {
                            if (n = 1, r && (o = 2 & i[0] ? r.return : i[0] ? r.throw || ((o = r.return) && o.call(r), 0) : r.next) && !(o = o.call(r, i[1])).done) return o;
                            switch (r = 0, o && (i = [2 & i[0], o.value]), i[0]) {
                                case 0:
                                case 1:
                                    o = i;
                                    break;
                                case 4:
                                    return a.label++, {
                                        value: i[1],
                                        done: !1
                                    };
                                case 5:
                                    a.label++, r = i[1], i = [0];
                                    continue;
                                case 7:
                                    i = a.ops.pop(), a.trys.pop();
                                    continue;
                                default:
                                    if (!(o = a.trys, (o = o.length > 0 && o[o.length - 1]) || 6 !== i[0] && 2 !== i[0])) {
                                        a = 0;
                                        continue
                                    }
                                    if (3 === i[0] && (!o || i[1] > o[0] && i[1] < o[3])) {
                                        a.label = i[1];
                                        break
                                    }
                                    if (6 === i[0] && a.label < o[1]) {
                                        a.label = o[1], o = i;
                                        break
                                    }
                                    if (o && a.label < o[2]) {
                                        a.label = o[2], a.ops.push(i);
                                        break
                                    }
                                    o[2] && a.ops.pop(), a.trys.pop();
                                    continue
                            }
                            i = t.call(e, a)
                        } catch (e) {
                            i = [6, e], r = 0
                        } finally {
                            n = o = 0
                        }
                        if (5 & i[0]) throw i[1];
                        return {
                            value: i[0] ? i[1] : void 0,
                            done: !0
                        }
                    }([i, u])
                }
            }
        },
        Gi = new go,
        Ki = function(e, t, n) {
            var r = document.getElementById("account-security-prompt-container");
            if (null !== r) {
                (0, D.unmountComponentAtNode)(r);
                var o = new Wi(e.promptType);
                (0, D.render)(U().createElement(Hi, {
                    promptAssignment: e,
                    username: t,
                    isUserUnder13: n,
                    eventService: o,
                    requestService: Gi
                }), r)
            }
        };
    w.CurrentUser && w.CurrentUser.isAuthenticated && "unknown" === (0, w.DeviceMeta)().appType && (Object.assign(R(), {
        AccountSecurityPrompt: {
            render: Ki,
            PromptType: ot
        }
    }), Bi(void 0, void 0, Promise, (function() {
        var e, t, n, r, o;
        return Yi(this, (function(i) {
            switch (i.label) {
                case 0:
                    return [4, Gi.promptAssignments.getAllForCurrentUser()];
                case 1:
                    if ((e = i.sent()).isError) return console.warn(Mo, "Retrieving prompt assignments failed with error", e.error && tt[e.error]), [2];
                    if (0 === (t = e.value).length) return console.log(Mo, "No assignments were retrieved"), [2];
                    if (window.location.href.includes(ko) || window.location.href.includes(".com/my/account")) return [2];
                    for (n = null, r = 0; r < t.length; r++) {
                        if ((o = t[r]).promptType !== ot.BROADER_AUTHENTICATOR_UPSELL && o.promptType !== ot.EMAIL_2SV_UPSELL || !1 !== o.isGeneric || o.metadata.pageRestriction !== rt.HOME_PAGE_ONLY || window.location.href.includes(".com/home")) {
                            n = o;
                            break
                        }
                        n = null
                    }
                    return null === n || Ki(n, w.CurrentUser.name, w.CurrentUser.isUnder13), [2]
            }
        }))
    })))
}();
//# sourceMappingURL=https://js.rbxcdn.com/32dd11e1afa11a1ed8be3df86144991b-accountSecurityPrompt.bundle.min.js.map

/* Bundle detector */
window.Roblox && window.Roblox.BundleDetector && window.Roblox.BundleDetector.bundleDetected("AccountSecurityPrompt");