//# sourceMappingURL=https://js.rbxcdn.com/ae32946efe2d289e9e62b887f7079d04-builder.bundle.min.js.map

/* Bundle detector */
window.Roblox && window.Roblox.BundleDetector && window.Roblox.BundleDetector.bundleDetected("Builder");