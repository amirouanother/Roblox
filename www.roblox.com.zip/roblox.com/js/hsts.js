/*
Do not remove this script.
It is being used as a way to serve the Strict-Transport-Security header to browsers on the root domain https://roblox.com
This is necessary to tell browsers that includeSubDomains applies to all roblox.com subdomains
*/